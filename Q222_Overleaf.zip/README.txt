Compile main.tex for the article, Supplement.tex for the complete proofs,
or Uniform_C1_Certificate.tex for the self-contained new local lemma.
Use pdfLaTeX, compiling twice to resolve references. All sources and
bibliographies are included. The written proofs require no numerical solver.
