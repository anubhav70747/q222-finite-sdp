Finite semidefinite representation of the simplest quantum correlation set

MAIN DOCUMENT: main.tex
COMPLETE PROOFS: Supplement.tex
Compiler: pdfLaTeX. Compile either root twice for cross-references.
Overleaf: upload this source directory or the separate Overleaf ZIP, choose
main.tex as the main document; choose Supplement.tex to build the companion.
No external image files, bibliography processor or numerical solver is needed.

The article is 9 pages and the companion is
438 pages. The companion includes every local
certificate needed by the qualitative theorem. The accepted abstract is in
abstract.tex and is included without modification by main.tex.

The theorem establishes existence of a finite SDP representation. The actual
global matrices and matrix size have not been evaluated. Author names and
affiliations have not been supplied and must be added before submission.
