"""Compile the delivered source archive in a separate local directory."""
from pathlib import Path
import json, zipfile, subprocess, re
from pypdf import PdfReader

root=Path(__file__).resolve().parents[1]
build=root/'analysis/delivery_build'
build.mkdir(exist_ok=True)
assert build.resolve().is_relative_to(root.resolve())
with zipfile.ZipFile(root/'delivery/Q222_Overleaf_Source.zip') as z:
    for name in z.namelist():
        assert (build/name).resolve().is_relative_to(build.resolve())
    z.extractall(build)
exe=Path('C:/Users/anubh/AppData/Local/Programs/MiKTeX/miktex/bin/x64/pdflatex.exe')
result={}
for name in ('main','Supplement'):
    codes=[]
    for i in range(2):
        r=subprocess.run([str(exe),'-interaction=nonstopmode','-halt-on-error',name+'.tex'],cwd=build,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
        (build/f'{name}_run_{i+1}.txt').write_bytes(r.stdout)
        codes.append(r.returncode)
        assert r.returncode==0, (name,i)
    log=(build/f'{name}.log').read_text(errors='replace')
    errors=[line for line in log.splitlines() if re.search(r'Overfull|undefined references|LaTeX Error|Fatal error|multiply defined|Label\(s\) may have changed',line)]
    assert not errors,(name,errors)
    pages=len(PdfReader(build/f'{name}.pdf').pages)
    expected=len(PdfReader(root/'paper'/f'{name}.pdf').pages)
    assert pages==expected,(name,pages,expected)
    result[name]={'return_codes':codes,'critical_messages':errors,'pages':pages,'matches_delivered_page_count':True}
assert (build/'abstract.tex').read_bytes()==(root/'paper/abstract.tex').read_bytes()
result['abstract_matches_accepted_text']=True
(root/'analysis/clean_delivery_build.json').write_text(json.dumps(result,indent=2))
print(json.dumps(result,indent=2))
