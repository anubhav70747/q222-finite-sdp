Run individual check_*.py files with Python and SymPy installed.
The scripts use exact symbolic calculations, not numerical SDP solvers.
The c1_completion/check_uh_sigma_inf.py script also runs the parent-level
check_r21_c1_independent.py. Preserve this folder structure. Each script
writes its result JSON beside itself. Existing JSON files are prior receipts.
Coverage CSVs and audit reports record analytical reading; executing the
symbolic scripts does not reproduce that mathematical review.
