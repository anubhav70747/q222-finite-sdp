Q222 manuscript and complete proof package — 22 October 2026

Read Q222_Paper.pdf, then Q222_Complete_Proofs.pdf for all local calculations.
manuscript/ contains the complete TeX sources and build instructions.
verification/ contains the scoped analytical review, selected exact checks,
baseline source bodies, refinement crosswalk and editorial changes.
prior_extraction/ preserves the earlier supplied extraction work unchanged.

The current result is qualitative finite-SDP existence. An explicit global
pencil and its size remain constructive questions. Read verification/
final_audit.txt for the analytical review's scope and production checks.
This is a prepared manuscript package; it has not been submitted.
