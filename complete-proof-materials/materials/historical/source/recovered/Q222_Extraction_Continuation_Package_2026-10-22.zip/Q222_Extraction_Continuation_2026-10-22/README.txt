Q222 FINITE-LIFT EXTRACTION CONTINUATION
22 October 2026

CURRENT STATUS
The full finite semidefinite lift has not been extracted. The two universal
source-coverage gates, G1 and G2, remain OPEN. The evaluated order-13744
candidate has a proved quantum forward inclusion and an open reverse
inclusion. This archive is the complete current extraction work package;
it must not be described as a completed exact full-Q222 representation.

START HERE
1. Q222_Extraction_Continuation_2026-10-22.pdf
   The new analytical report, exact reductions, scoped counterexamples,
   and the original nineteen-item checklist with unchanged statuses.
2. CHECKLIST.txt or CHECKLIST.json
   Every original obligation, acceptance condition, dependency and evidence
   path. New scoped results are recorded separately from universal gates.
3. VERIFICATION.txt and REPLAY_RESULTS.json
   What was checked, what the checks establish, and what remains open.

WHAT IS NEW
- The actual enlarged C1 and C2 membership problems are each exactly
  equivalent to two cubic 8x8 matrix polynomials with 106 source-dependent
  selector coefficients. Both matrices must be PSD for every u>=0 after
  those coefficients have been chosen. Universal physical-source coverage
  has not been proved.
- A full-parent, pointwise six-variable PSD completion is evaluated. One
  exact physical C1 source has no all-real polynomial skew selector at any
  degree within that particular architecture.
- A positive physical C1 source refutes every four-effect selector with a
  common positive polynomial denominator of degree at most two. The same
  source has an explicit feasible Gram in the actual enlarged C1 array.
- A strictly positive regular rational C2 source refutes the cubic-over-
  (1+u) four-effect selector. A separate literal n=0 source excludes every
  positive common polynomial denominator of degree at most two. These are
  restricted-selector counterexamples, not counterexamples to G1 or G2.
- Full C2 physicality is reduced exactly to a quadratic/quartic sign
  condition, including every zero-coefficient face. The included routine
  decides this condition exactly for rational nonnegative source data.
- The complete C2 canonical parent is rigid under constant invertible
  state congruences and positive angle dilations preserving canonical form.
- C1 endpoint determinants and the remaining scalar radical are factored
  exactly. The resulting scalar obstruction has its own stated scope.

DIRECTORY GUIDE
baseline/
  The preceding extraction release, retained byte for byte: its 34-page
  report, original and corrected source data, actual global candidate,
  exact exclusions of the older order-8368 and order-10736 candidates,
  closedness and regular-contact reductions, complete matching maps,
  normalized dual failure formulas, and all prior verification records.
  Its provenance subdirectory retains the recovered checkpoint archives.

continuation/alternative/
  The full-parent one-angle completion, exact all-real polynomial-selector
  obstruction, equivalent 106-coordinate enlarged gate, literal rational
  coefficient maps, input files, and two portable exact checkers.

continuation/c1/
  The four-effect selector obstruction, endpoint factorization, actual
  enlarged Gram at the counterexample, and independent review records.

continuation/c2/
  Constant-congruence rigidity, both restricted-selector counterexamples,
  their exact checkers, and independent reviews of the other new results.

continuation/root/
  Complete C2 radial physicality theorem, exact rational membership code,
  checker and generated data, plus the report's opening scope statement.

publication/
  A typesetting copy of one frozen proof. PUBLICATION_TRANSFORMS.json
  records its sole change: an equivalent fraction command. The original
  mathematical proof remains unchanged in continuation/alternative/.

qa/
  The final PDF compile and visual-review records, scope review and release
  custody checks. File integrity is not a substitute for G1 or G2.

REPRODUCTION
Python 3.12.14 and SymPy 1.14.0 were used for the recorded replays.

  python verify.py

This checks every manifest-bound file, the preserved baseline payloads,
the original checklist statuses, and the six bound replay records. It uses
only the Python standard library and does not solve any open theorem.

  python -m pip install -r requirements.txt
  python verify.py --replay

The replay option runs all six new exact suites in an isolated temporary
copy, checks the named receipt fields, and compares regenerated coefficient
data byte for byte. Timing fields are not used as mathematical evidence.
The delivered originals are not rewritten. The older release retains its
own verify.py and reproduction instructions under baseline/.

For an exact rational physical C2 membership decision, in the source order
(d,n,m,C,A,D,alpha), run for example:

  python continuation/root/c2_radial.py 1 7/8 9/8 1/18 11/8 9/8 1/18

The output includes exact sign polynomials and rational sign-cell samples.
It decides physical source membership, not enlarged Gram membership.

To rebuild the report from this directory, use a LaTeX installation with
the standard amsmath, mathtools, geometry, hyperref, booktabs, tabularx,
longtable, xurl, lmodern and microtype packages:

  latexmk -pdf Q222_Extraction_Continuation_2026-10-22.tex

REMAINING ACCEPTANCE CONDITIONS
G1: Prove that every source in the explicit regular C1 domain is admitted
    by the actual enlarged cone in at least one prescribed orientation.
G2: Prove that every source in the explicit regular C2 domain is admitted
    by its actual enlarged cone.
A04: Apply the retained boundary and full source assembly arguments to
     prove the global reverse inclusion.
V02: Release as exact only after both inclusions are unconditional.

The current candidate has total PSD order 13744, 29920 auxiliary variables,
2928 blocks, maximum block order 15, and 153248 nonzero rational
upper-triangle COO records. These are candidate sizes, not an established
exact lift-size bound for Q222.

A different universally adequate finite square space could replace this
sufficient G1/G2 route. Such a construction needs a finite square space and
the finite span of its pairwise products, not a multiplication-closed
finite-dimensional algebra of all test functions.

The qualitative R21 tensor-SOS existence argument was not re-audited in
this extraction continuation. The work here does not establish the final
constructive extraction. Review was analytical lead review, separate-agent
review within the same model system, and targeted exact symbolic
corroboration; it is not external peer review or proof-assistant formal
verification.
