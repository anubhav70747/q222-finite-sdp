#!/usr/bin/env python3
"""Hash the new scoped routing deliverables; no theorem is promoted by hashing."""
from pathlib import Path
import json,hashlib

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def rec(path,base=HERE):
    p=base/path
    return {'path':path,'sha256':sha(p),'bytes':p.stat().st_size}
def assertion_count(receipt):
    saved=json.loads((HERE/receipt).read_text())
    count=saved.get('checks_passed')
    if count is None:return None
    checks=saved.get('checks',saved.get('exact_checks'))
    if not isinstance(count,int) or not isinstance(checks,list) or count!=len(checks):
        raise ValueError('Inconsistent literal assertion count: '+receipt)
    return count

# Explicit portable replay inputs.  This inventory does not run the checkers
# or change their original, elapsed-time-bearing receipts.
specs=[
 ('check_remembered_ray_global_transfer.py','REMEMBERED_RAY_GLOBAL_TRANSFER.json','routing',[],
  'Physicality, full global eligibility and exact old two-frame separation.'),
 ('compile_enlarged_global_candidate.py','compiled_enlarged/GLOBAL_COMPILATION_RECEIPT.json','routing',['enlarged_compiler_core.py'],
  'Evaluate the new enlarged outer candidate; not a universal adequacy proof.'),
 ('check_enlarged_global_compiler.py','CHECK_ENLARGED_GLOBAL_COMPILER.json','routing',[],
  'Independent full-parent, coefficient-space and emitted-pencil readback.'),
 ('check_normalized_dual_gate_independent.py','NORMALIZED_DUAL_GATE_INDEPENDENT_REVIEW.json','package',[],
  'Finite normalized-dual/contact inputs and scoped equivalence; no emptiness decision.')]
replays=[]
for script,receipt,path_base,modules,scope in specs:
    saved=json.loads((HERE/receipt).read_text())
    count=assertion_count(receipt)
    paths=['routing/'+script]+['routing/'+m for m in modules]
    for item in saved['inputs']:
        paths.append(('routing/' if path_base=='routing' else '')+item['path'])
    if script=='check_normalized_dual_gate_independent.py':paths.append('normalized_dual_gate.tex')
    deps=[rec(p,ROOT) for p in sorted(set(paths))]
    replays.append({'command':'python routing/'+script,'recorded_receipt':rec('routing/'+receipt,ROOT),
      'recorded_assertion_count':count,'scope':scope,'dependencies':deps,
      'writes':['routing/'+receipt]+[('routing/' if path_base=='routing' else '')+r['path'] for r in saved.get('outputs',[])]})
(HERE/'PORTABLE_CHECKER_INVENTORY.json').write_text(json.dumps({
 'path_base':'finite_lift_checklist_2026-10-22 package root',
 'runtime':'Python3 and SymPy1.14; standard library otherwise. No solver, network, credentials or historical unbundled inputs.',
 'execution':'Run in a fresh package copy to preserve receipt hashes. All commands resolve data relative to their script, not cwd.',
 'dependency_order':'The compiler regenerates the outputs read by the enlarged checker. The normalized-dual checker additionally reads the supplied root dual_gate exports and root proof.',
 'replays':replays,
 'count_rule':'Counts overlap and are not added. A null count denotes the compiler, not another proof-total.',
 'not_a_gate':'Successful replay does not decide G1 or G2.'},indent=2)+'\n')

proofs=['current_global_candidate_correction.tex','enlarged_global_candidate.tex']
checks=['REMEMBERED_RAY_GLOBAL_TRANSFER.json','CHECK_ENLARGED_GLOBAL_COMPILER.json',
        'NORMALIZED_DUAL_GATE_INDEPENDENT_REVIEW.json',
        'C1_REGULAR_GATE_ANALYTICAL_REVIEW.json','C2_REGULAR_GATE_ANALYTICAL_REVIEW.json']
cross=['c1/two_frame_correction.tex','c1/CHECK_TWO_FRAME_CORRECTION.json',
       'c1/c1_regular_contact_reduction.tex','c1/C1_REGULAR_CONTACT_DOMAIN.json','c1/CHECK_C1_REGULAR_CONTACT_REDUCTION.json',
       'c2/c2_regular_contact_reduction.tex','c2/check_c2_regular_contact_reduction.json',
       'c2/c2_reciprocal_fixed_sector.tex','c2/C2_RECIPROCAL_FIXED_SECTOR.coo.json',
       'c2/check_c2_reciprocal_fixed_sector.py','c2/check_c2_reciprocal_fixed_sector.json',
       'normalized_dual_gate.tex','dual_gate/C1_NORMALIZED_DUAL_FAILURE_SYSTEM.json',
       'dual_gate/C2_NORMALIZED_DUAL_FAILURE_SYSTEM.json','dual_gate/CHECK_NORMALIZED_DUAL_GATE.json']
status={
 'status':'SCOPED_ROUTING_WORK_COMPLETE_GLOBAL_EXTRACTION_OPEN',
 'date':'2026-10-22',
 'proved_correction':'Both previous global pencils N8368 andN10736 are strictly outer for the actual current coefficient arrays. Their old files remain immutable.',
 'new_candidate':{'matrix_order':13744,'auxiliaries':29920,'blocks':2928,'maximum_block_order':15,'rational_COO_entries':153248,
                  'forward_inclusion':'PROVED','reverse_inclusion':'OPEN','exact_Q222_size_bound':False},
 'central_open_gates':['G1: universal enlarged C1 two-orientation coverage on the exact regular domain.',
                       'G2: universal enlarged C2 coverage on the exact regular domain.'],
 'scoped_completed_results':['Exact current old-candidate refutation and full global transfer.',
                            'New safe enlarged global candidate with every coefficient and required source face.',
                            'Independent raw-array/Pauli/trace-adjoint readback and strict qualification.',
                            'Independent analytical review of both regular-cap/boundary reductions.',
                            'Independent normalized-dual finite-data/equivalence review; emptiness remains undecided.',
                            'Detailed remaining E1–E3 acceptance checklist, with no completion percentage.'],
 'exact_replay_counts_separate':[
    {'receipt':'REMEMBERED_RAY_GLOBAL_TRANSFER.json','assertions':assertion_count('REMEMBERED_RAY_GLOBAL_TRANSFER.json'),'scope':'Exact physicality, both old-frame duals, extremality, all global maps and moments.'},
    {'receipt':'CHECK_ENLARGED_GLOBAL_COMPILER.json','assertions':assertion_count('CHECK_ENLARGED_GLOBAL_COMPILER.json'),'scope':'Independent new enlarged whole-parent, full matching and emitted affine readback.'},
    {'receipt':'NORMALIZED_DUAL_GATE_INDEPENDENT_REVIEW.json','assertions':assertion_count('NORMALIZED_DUAL_GATE_INDEPENDENT_REVIEW.json'),'scope':'Exact compact dual-base/contact input only; no universal gate decision.'}],
 'assertion_count_rule':'Counts overlap and are not added. They do not measure completeness of G1 orG2.',
 'proofs':[rec(p) for p in proofs],
 'reviews_and_receipts':[rec(p) for p in checks],
 'actual_pencil':rec('compiled_enlarged/GLOBAL_CANONICAL_OUTER_PENCIL.coo.json'),
 'technical_checklist':rec('REMAINING_EXTRACTION_CHECKLIST.json'),
 'portable_replay_inventory':rec('PORTABLE_CHECKER_INVENTORY.json'),
 'receipt_reconciliation':rec('receipt_audit/RECEIPT_RECONCILIATION.json'),
 'cross_package_inputs':[rec(p,ROOT) for p in cross],
 'limitations':['No explicit nonquantum behavior/auxiliary vector is printed for the old global refutation.',
                'No universal enlarged PSD selector or failure-system emptiness proof is supplied.',
                'No claimed refutation of C160, the enlarged candidate, or existence of all finite SDP lifts.']}
(HERE/'ROUTING_STATUS.json').write_text(json.dumps(status,indent=2)+'\n')
records=[]
for p in sorted(HERE.rglob('*')):
    if not p.is_file() or p.name=='MANIFEST_ROUTING.json' or '__pycache__' in p.parts:continue
    records.append(rec(str(p.relative_to(HERE))))
(HERE/'MANIFEST_ROUTING.json').write_text(json.dumps({'status':'FROZEN_SCOPED_ARTIFACT_HASHES',
 'path_base':'routing directory','files':records,
 'not_a_mathematical_gate':'File custody does not establish the open universal coverage assertions.'},indent=2)+'\n')
print(json.dumps({'status':status['status'],'files':len(records),'manifest_sha256':sha(HERE/'MANIFEST_ROUTING.json'),
                  'routing_status_sha256':sha(HERE/'ROUTING_STATUS.json')},indent=2))
