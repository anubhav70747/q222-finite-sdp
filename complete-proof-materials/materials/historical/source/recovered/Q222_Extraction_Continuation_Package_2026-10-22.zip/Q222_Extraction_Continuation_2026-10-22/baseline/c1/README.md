# Exact correction of the two-orientation C1 status

The actual recovered order-31 C1 cone `R1` **and its two-orientation sum
`R1 + sigma(R1)` are incomplete**. The current and recovered historical
numerical arrays are identical. A common exact rational dual functional is
nonnegative on both frames and equals `-1` on a strictly positive globally
physical source.

## Current completed work

- `two_frame_correction.tex`: all-angle physicality, full-parent normalization,
  common dual separation and exact scope of the correction.
- `inputs/C1_RAMIFIED_PRIMAL.coo.json`: unchanged copy of the current candidate.
- `inputs/HISTORICAL_C1_RAMIFIED_PRIMAL.coo.json`: recovered historical source;
  only the `scope` and `whole_master_equality` metadata fields differ.
- `inputs/C1_SATURATED_CONE_SEPARATOR.json`: unchanged historical rational
  witness, independently replayed against the current arrays.
- `check_two_frame_correction.py` and `CHECK_TWO_FRAME_CORRECTION.json`:
  fresh exact replay, **PASS 583**. No numerical optimization is used.

The source order is `(d,m,C,A,D,alpha,beta)`. The separator uses the **full**
polynomial physical parent `P=(1+u²)(1+v²)M`, which is four times the
quarter-parent in the local C1 proof formulas. Both its visible traces and its
79 auxiliary annihilation conditions are checked separately in each frame.

Run from any working directory, with SymPy available:

```sh
python3 /absolute/path/to/c1/check_two_frame_correction.py
```

The script writes only its adjacent receipt. To preserve delivered receipt
bytes, replay an isolated copy of this directory.

## What this changes

The former statement that two-orientation C1 completeness was open is now
corrected to **refuted for this exact pencil**. The exact sigma-fixed order-18
sector lift from the preceding release is unaffected. Neither a universal
finite SDP representation nor its impossibility follows from this correction.

The immediately subsequent historical archive contains a different order-59
multiplier frame and an exact repair of this source. The fresh independent
replay is complete: `check_enlarged_c1_repair.py` passes **8,844** exact checks.
It verifies the full affine family, all four rational PSD factorizations,
the old-frame inclusion, and the actual 302-by-7 selector for a
full-dimensional monotone source chamber. Repairing this source does not
establish a global converse.

## The precise remaining mathematical gate

`c1_regular_contact_reduction.tex` proves the entire source reduction,
including analytic positive-event sharp caps, a dense regular five-shape
domain, all deficit strengths, every literal zero-event face, and closedness
of the actual larger two-orientation cone. The focused checker passes
**352** exact checks. On each regular sharp ray, the six independent contact
equations prove extremality, so the two-orientation sum succeeds exactly when
at least one orientation succeeds.

`c1_enlarged_contact_selector_contract.tex` states that remaining assertion
as **CS8**. The actual exported constant map has 148 coefficient rows, 392
compressed Gram entries, rank 142, and 250 free variables. The compressed
orders are `(13,14,13,14)`. The data include the full physical source target
map, pivot and free maps, and all contact compatibility rows. Its exact
builder passes **20** assertions, including the full symbolic reflected
parent and all six transformed contact residuals.

What remains is to prove that, **for every source in this explicit regular
five-shape domain**, one of the two complete 250-variable PSD fibers is
feasible. This universal statement is open. The boundary and regularity
reductions are proved; they do not replace this statement.

The main current files are:

- `enlarged_c1_exact_repair.tex` and `CHECK_ENLARGED_C1_REPAIR.json`;
- `c1_regular_contact_reduction.tex`, `C1_REGULAR_CONTACT_DOMAIN.json`, and
  `CHECK_C1_REGULAR_CONTACT_REDUCTION.json`;
- `c1_enlarged_contact_selector_contract.tex`,
  `C1_ENLARGED_REGULAR_CONTACT_SYSTEM.json`, and
  `CHECK_C1_ENLARGED_CONTACT_SYSTEM.json`;
- `STATUS.json`, which distinguishes completed scoped results from the
  outstanding global reverse inclusion.

Every checker is solver-free. Run each script with Python and SymPy from
any working directory. The independent C2 review script additionally reads
the sibling `../c2` directory, which is a declared review dependency.

## Provenance

The historical inputs were recovered from
`Q222_Two_Frame_Refutation_2026-09-27.zip`, under its own `sources/` and
`data/` directories. The new checker and explanatory theorem are fresh work
dated 22 October 2026. No earlier frozen release or recovered archive was
modified. `TWO_FRAME_CORRECTION_DEPENDENCIES.json` binds the actual bytes.
