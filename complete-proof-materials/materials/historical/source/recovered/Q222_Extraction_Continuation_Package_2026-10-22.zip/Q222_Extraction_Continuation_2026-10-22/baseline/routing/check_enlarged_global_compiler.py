#!/usr/bin/env python3
"""Independent exact readback of the NEW enlarged global affine pencil.

This checker reads the emitted COO data and proves every trace-adjoint
equation. It does not import or call the compiler. Python3 + SymPy suffice.
It certifies an outer pencil and a conditional compiler, not Q equality.
"""
from pathlib import Path
from collections import defaultdict
import hashlib,json,time
from fractions import Fraction
import sympy as s

HERE=Path(__file__).resolve().parent
start=time.time();checks=[];check_names=set();tested_files=set()
def read(path):
    tested_files.add(path);return json.loads(path.read_text())
def ck(name,p):
    if not p:raise AssertionError(name)
    if name not in check_names:
        checks.append(name);check_names.add(name)
def zero(name,M):
    ck(name,all(z==0 for z in M))
def mat(d):
    M=s.zeros(d['rows'],d['columns'])
    for i,j,v in d['entries']:M[i,j]+=s.Rational(v)
    return M
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def event(a,b,x,y):
    z=s.zeros(9,1);z[0]=1;z[1+x]=a;z[3+y]=b;z[5+2*x+y]=a*b
    return z
def action(g):
    return s.Matrix([[(1 if a>0 else -1) if j==abs(a)-1 else 0 for j in range(9)] for a in g])
def labels(sizes):
    return [(b,i,j) for b,n in enumerate(sizes) for i in range(n) for j in range(i,n)]
def blocks(vec,labs,sizes):
    out=[s.zeros(n) for n in sizes]
    for a,(b,i,j) in zip(vec,labs):out[b][i,j]=out[b][j,i]=a
    return out
def pd(name,M):
    zero(name+' exact symmetry',M-M.T)
    rows=[[Fraction(str(M[i,j])) for j in range(M.cols)] for i in range(M.rows)]
    pivots=[]
    for k in range(M.rows):
        z=rows[k][k]
        ck(name+' positive pivot '+str(k),z>0);pivots.append(str(z))
        for i in range(k+1,M.rows):
            for j in range(i,M.rows):
                rows[i][j]-=rows[i][k]*rows[k][j]/z
                rows[j][i]=rows[i][j]
    return pivots

H=s.Matrix([1,0,0,0,0,-s.Rational(1,2),s.Rational(1,2),-s.Rational(1,2),-s.Rational(1,2)])
event_names=['lambda','n','m','C','A','D','alpha','beta']
event_args=[(1,1,0,1),(1,-1,0,0),(1,-1,1,1),(-1,1,1,0),(-1,1,0,0),(-1,1,1,1),(-1,-1,0,1),(1,-1,1,0)]
J=s.Matrix.hstack(H,*[event(*arg) for arg in event_args])
full_order=['d']+event_names
orders={'C1':['d','m','C','A','D','alpha','beta'],
        'C2':['d','n','m','C','A','D','alpha'],
        'CF_ADJ':['d','n','C','A','D','alpha','beta'],
        'CF_OPP':['d','n','m','C','A','D','beta']}

def expected_source_matrix(family,declared):
    sizes=declared['source_block_sizes'];labs=labels(sizes);lookup={x:i for i,x in enumerate(labs)}
    if family in ('C1','C2'):
        raw=read(HERE/'inputs'/(family+'_ENLARGED_PRIMAL.coo.json'))
        L=s.zeros(len(labs),len(raw['variables']))
        for k,i,j,q in raw['entries']:
            b=next(b for b,B in enumerate(raw['blocks']) if B['offset']<=i<B['offset']+B['order'])
            o=raw['blocks'][b]['offset']
            ck(family+' COO local entry is upper triangular',o<=i<=j<o+raw['blocks'][b]['order'])
            L[lookup[(b,i-o,j-o)],k-1]+=s.Rational(q)
        for i in range(1,7):L[lookup[(4+i,0,0)],i]=1
        return L
    variables=s.symbols(' '.join(orders[family]));c=dict(zip(orders[family],variables))
    d,n,C,A,D,beta=[c[x] for x in ('d','n','C','A','D','beta')]
    if family=='CF_ADJ':
        alpha=c['alpha'];aux=s.symbols('z0 z1 z2')
        K0=s.diag(4*C+4*D+2*d,4*A,4*alpha)
        K2=s.diag(4*C,4*A+4*alpha+2*d,4*D)
        K1=s.Matrix([[0,0,-4*D-2*d],[0,0,-4*alpha-2*d],[-4*D-2*d,-4*alpha-2*d,0]])
        S=s.Matrix([[0,aux[0],aux[1]],[-aux[0],0,aux[2]],[-aux[1],-aux[2],0]])
        BB=[K0.row_join(K1/2+S).col_join((K1/2-S).row_join(K2))]
    else:
        m=c['m'];aux=(s.Symbol('zeta'),);p=4*C+4*D+2*d;q=4*m+4*beta+2*d;r=4*D+2*d
        BB=[s.Matrix([[4*m,-4*m,aux[0]],[-4*m,q+4*n,q],[aux[0],q,q]]),
            s.Matrix([[p+4*A,4*D,-p],[4*D,4*D,-4*m-r-aux[0]],[-p,-4*m-r-aux[0],p]])]
    BB += [s.Matrix([[x]]) for x in variables]
    E=s.Matrix([BB[b][i,j] for b,i,j in labs])
    L=E.jacobian((*variables,*aux))
    zero(family+' exact complete source expression',E-L*s.Matrix((*variables,*aux)))
    return L

matching_records=[]
def verify_full_parent_and_matching(family,L,labs):
    """Read every actual coefficient from the new array, independent of compiler."""
    raw=read(HERE/'inputs'/(family+'_ENLARGED_PRIMAL.coo.json'))
    ck(family+' enlarged testing multiplier explicitly specified',raw['multiplier']=='(1+u)(1+v)')
    u,v,W,X,Y,Z=s.symbols('u v W X Y Z')
    variables=(u,v,W,X,Y,Z);state=s.Matrix([W,X,Y,Z])
    eye=s.eye(2);zz=s.diag(1,-1);xx=s.Matrix([[0,1],[1,0]])
    du,dv=1+u*u,1+v*v
    aa=[zz,((1-u*u)*zz+2*u*xx)/du]
    bb=[zz,((1-v*v)*zz+2*v*xx)/dv]
    kron=s.kronecker_product
    core=s.eye(4)-(kron(aa[0],bb[0])-kron(aa[0],bb[1])+kron(aa[1],bb[0])+kron(aa[1],bb[1]))/2
    ev=dict(zip(event_names,event_args))
    operators=[core]
    for name in orders[family][1:]:
        a,b,x,y=ev[name]
        operators.append(kron(eye+a*aa[x],eye+b*bb[y]))
    bare=[s.Poly(s.cancel(du*dv*(state.T*M*state)[0]),*variables) for M in operators]
    target=[s.Poly((1+u)*(1+v)*P.as_expr(),*variables).as_dict() for P in bare]
    target += [{} for _ in range(raw['auxiliary_count'])]
    bins=defaultdict(list)
    for row,(b,i,j) in enumerate(labs):
        if b>=4:continue
        st,a,bv=raw['features'][b][i]
        st2,a2,bv2=raw['features'][b][j]
        wu,wv=raw['weights'][b]
        exponent=[a+a2+wu,bv+bv2+wv,0,0,0,0]
        exponent[2+st]+=1;exponent[2+st2]+=1
        bins[tuple(exponent)].append((row,1 if i==j else 2))
    for k,want in enumerate(target):
        got={e:sum(factor*L[row,k] for row,factor in rows) for e,rows in bins.items()}
        ck(family+' complete Pauli-parent matching column '+str(k),
           all(got.get(e,0)==want.get(e,0) for e in set(got)|set(want)))
    ngram=sum(len(rows) for rows in bins.values())
    ck(family+' every nontrivial Gram coordinate belongs to one nonempty disjoint coefficient bin',ngram==450)
    ck(family+' exact complete polynomial matching rank is148',len(bins)==148)
    ck(family+' complete matching kernel dimension equals309 source/auxiliary coordinates',ngram+7-len(bins)==L.cols==309)
    # The later independent adjoint rank check proves rank(L)=309.
    # Together these identities identify the whole matching kernel.
    for k,P in enumerate(bare):
        F=P.as_expr()
        ck(family+' unmultiplied Alice gauge '+str(k),s.expand(F.subs({u:-u,Y:-Y,Z:-Z},simultaneous=True)-F)==0)
        ck(family+' unmultiplied Bob gauge '+str(k),s.expand(F.subs({v:-v,X:-X,Z:-Z},simultaneous=True)-F)==0)
    matching_records.append({'family':family,'gram_coordinates':ngram,'matching_rank':len(bins),
                             'source_plus_auxiliary_dimension':L.cols,'source_auxiliaries':raw['auxiliary_count'],
                             'verified_full_source_columns':7,'verified_auxiliary_columns':raw['auxiliary_count'],
                             'multiplier':'(1+u)(1+v)','full_parent_built_independently_from':'literal original Pauli measurement and all retained event operators'})

moment_records=[]
for family in ('C1','C2'):
    raw=read(HERE/'inputs'/(family+'_ENLARGED_PRIMAL.coo.json'))
    for b,ff in enumerate(raw['features']):
        MM=s.zeros(len(ff));testrows=[]
        wu,wv=raw['weights'][b]
        for u in (1,2):
            for v in (1,2):
                for state in range(4):
                    row=s.Matrix([u**i*v**j if a==state else 0 for a,i,j in ff])
                    MM+=u**wu*v**wv*row*row.T;testrows.append(list(map(str,row)))
        pivots=pd(family+' feature evaluation moment block '+str(b),MM)
        moment_records.append({'family':family,'block':b,'moment':[[str(x) for x in MM.row(i)] for i in range(MM.rows)],'positive_LDL_pivots':pivots})

summary=[]
for dirname in ('compiled_enlarged',):
    base=HERE/dirname;maps=read(base/'GLOBAL_SOURCE_MAPS.json');pencil=read(base/'GLOBAL_CANONICAL_OUTER_PENCIL.coo.json')
    zero(dirname+' exact original nine-coordinate source map',s.Matrix(maps['full_source_map']).applyfunc(s.Rational)-J)
    ck(dirname+' original eight visible coordinates',pencil['visible_coordinates']==['a0','a1','b0','b1','E00','E01','E10','E11'])
    ck(dirname+' enlarged forward-only status retained',pencil['quantum_forward_inclusion'] is True and pencil['quantum_reverse_inclusion_proved'] is False)
    local={}
    for family in orders:
        d=read(base/(family+'_QUALIFIED_DUAL.json'))
        ck(dirname+' '+family+' original source order',d['source_coefficient_order']==orders[family])
        L=expected_source_matrix(family,d);zero(dirname+' '+family+' actual source COO map',L-mat(d['source_coefficient_matrix']))
        labs=labels(d['source_block_sizes']);ck(dirname+' '+family+' exact upper triangle order',list(map(list,labs))==d['upper_triangle_order'])
        if family in ('C1','C2'):verify_full_parent_and_matching(family,L,labs)
        A=L.T*s.diag(*[1 if i==j else 2 for b,i,j in labs])
        P,N=mat(d['dual_visible_part']),mat(d['dual_free_part'])
        target=s.zeros(A.rows,7);target[:7,:]=s.eye(7)
        zero(dirname+' '+family+' complete visible trace-adjoint equations',A*P-target)
        zero(dirname+' '+family+' complete auxiliary trace-adjoint equations',A*N)
        free=d['dual_free_rows'];zero(dirname+' '+family+' free-coordinate identity',N[free,:]-s.eye(len(free)))
        ck(dirname+' '+family+' full rank and exact nullity',A.rank()==A.rows and A.cols-A.rows==N.cols)
        witness=s.Matrix(list(map(s.Rational,d['source_strict_witness'])))
        ck(dirname+' '+family+' all source signs strictly positive',all(x>0 for x in witness[:7]))
        for b,M in enumerate(blocks(L*witness,labs,d['source_block_sizes'])):pd(dirname+' '+family+' current-source Slater block '+str(b),M)
        local[family]=(A,labs,free,d['source_block_sizes'])
    owner={};offsets={};maxend=0
    for B in pencil['blocks']:
        for i in range(B['offset'],B['offset']+B['order']):
            ck(dirname+' disjoint matrix blocks',i not in owner);owner[i]=B
        maxend=max(maxend,B['offset']+B['order'])
    ck(dirname+' complete declared matrix order',len(owner)==maxend==pencil['matrix_order'])
    matrices={};seen=set()
    for rec in maps['components']:
        f=rec['family'];A,labs,free,sizes=local[f]
        lookup={};offset=rec['matrix_offset']
        for b,n in enumerate(sizes):
            for i in range(n):
                for j in range(i,n):lookup[(offset+i,offset+j)]=labs.index((b,i,j))
            offset+=n
        matrices[rec['component']]=(rec,lookup,s.zeros(len(labs),9+rec['auxiliary_count']))
    events={e['offset']:s.zeros(9,1) for e in maps['nonsignaling_event_blocks']}
    for k,i,j,raw in pencil['entries']:
        ck(dirname+' unique valid upper COO slot',(k,i,j) not in seen and 0<=i<=j<pencil['matrix_order']);seen.add((k,i,j))
        Bi,Bj=owner[i],owner[j]
        ck(dirname+' no cross-block entries',Bi is Bj)
        val=s.Rational(raw);component=Bi['component']
        if component=='nonsignaling_event':
            ck(dirname+' literal original event block has no auxiliary',i==j and 0<=k<9);events[i][k]+=val
            continue
        rec,lookup,DD=matrices[component]
        if k<9:col=k
        else:
            aux=k-9-rec['auxiliary_offset']
            ck(dirname+' component uses only its own auxiliaries',0<=aux<rec['auxiliary_count']);col=9+aux
        DD[lookup[(i,j)],col]+=val
    aux_end=0
    for rec,lookup,DD in matrices.values():
        f=rec['family'];A,labs,free,sizes=local[f]
        G=action(rec['point_action']);JJ=G.T*J[:,[full_order.index(x) for x in orders[f]]]
        zero(dirname+' component '+str(rec['component'])+' full source-to-original map',JJ-s.Matrix(rec['source_to_original_affine']).applyfunc(s.Rational))
        target=s.zeros(A.rows,9);target[:7,:]=JJ.T
        zero(dirname+' component '+str(rec['component'])+' actual emitted visible adjoint equations',A*DD[:,:9]-target)
        zero(dirname+' component '+str(rec['component'])+' actual emitted auxiliary adjoint equations',A*DD[:,9:])
        zero(dirname+' component '+str(rec['component'])+' exact complete auxiliary parameterization',DD[free,9:]-s.eye(len(free)))
        ck(dirname+' ordered disjoint auxiliary intervals',rec['auxiliary_offset']==aux_end);aux_end+=rec['auxiliary_count']
    ck(dirname+' exact total auxiliary count',aux_end==pencil['auxiliary_count'])
    for e in maps['nonsignaling_event_blocks']:zero(dirname+' original nonsignaling event '+str(e['event']),events[e['offset']]-event(*e['event']))
    expected=(13744,29920,2928,153248)
    ck(dirname+' all evaluated dimension and sparsity counts',(pencil['matrix_order'],pencil['auxiliary_count'],len(pencil['blocks']),len(pencil['entries']))==expected)
    counts={f:sum(rec['family']==f for rec in maps['components']) for f in orders}
    ck(dirname+' exact source frame counts',counts=={'C1':128,'C2':64,'CF_ADJ':64,'CF_OPP':32})
    ck(dirname+' exactly16 original event inequalities',len(events)==16)
    ck(dirname+' largest actual PSD block order15',max(B['order'] for B in pencil['blocks'])==15)
    summary.append({'directory':dirname,'matrix_order':expected[0],'auxiliaries':expected[1],'blocks':expected[2],'coo_entries':expected[3]})

out={'status':'PASS_INDEPENDENT_EXACT_ENLARGED_AFFINE_READBACK',
     'scope':'Every source-to-original map, source orthant, strict Slater witness, trace-adjoint equation and eliminated affine coefficient is exact. This is a quantum outer pencil. This verifier proves no global reverse inclusion.',
     'all_frame_exactness_condition':'Sufficient: C1_physical = K1_enlarged+sigma1(K1_enlarged), and C2_physical = K2_enlarged. Neither equality is asserted or claimed necessary for global exactness.',
     'groups':summary,'checks_passed':len(checks),'exact_checks':checks,
     'feature_moment_scope':'The 16 rational test evaluations give a positive definite moment in every feature block. They prove closedness/bounded Gram fibres of each finite certificate cone, not completeness of the feature family.',
     'positive_feature_moments':moment_records,
     'whole_parent_and_complete_matching':matching_records,
     'inputs':[{'path':str(p.relative_to(HERE)),'sha256':sha(p)} for p in sorted(tested_files)],
     'checker':{'path':Path(__file__).name,'sha256':sha(Path(__file__))},'seconds':time.time()-start}
(HERE/'CHECK_ENLARGED_GLOBAL_COMPILER.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'checks':len(checks),'dimensions':summary,'seconds':out['seconds']}))
