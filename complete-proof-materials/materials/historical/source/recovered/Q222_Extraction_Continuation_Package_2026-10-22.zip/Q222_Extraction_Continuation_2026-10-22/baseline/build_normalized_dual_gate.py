#!/usr/bin/env python3
"""Export and check the exact compact dual bases for the two OPEN gates.

No universal feasibility, infeasibility, or quantifier-elimination result is
claimed.  This script verifies the finite algebra specifying the problem.
Requires SymPy; it reads only the adjacent, already evaluated source arrays.
"""
from pathlib import Path
from itertools import product
import hashlib
import json
import sympy as s

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'dual_gate'
OUT.mkdir(exist_ok=True)
checks = []

def ck(value, label):
    if not bool(value):
        raise AssertionError(label)
    checks.append(label)

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def enc(M):
    return {'rows': M.rows, 'cols': M.cols,
            'entries': [[int(i), int(j), str(M[i,j])]
                        for i,j in sorted(M.todok())]}

def positive_pivots(M):
    M = s.Matrix(M)
    pivots = []
    while M.rows:
        p = M[0,0]
        ck(p > 0, 'strict rational moment LDL pivot')
        pivots.append(str(p))
        M = M[1:,1:] - M[1:,0] * M[0,1:] / p
    return pivots

def vectorize(blocks, labels):
    return s.Matrix([blocks[b][i,j] for b,i,j in labels])

u,v,a,b,t = s.symbols('u v a b t')
psi = s.Matrix([a,b,t,1])
results = {}
for fam, dirname in [('C1','c1'), ('C2','c2')]:
    path = ROOT / dirname / 'inputs' / (fam+'_ENLARGED_PRIMAL.coo.json')
    dat = json.loads(path.read_text())
    ck(dat['matrix_order']==59 and dat['auxiliary_count']==302,
       fam+' actual enlarged source dimensions')
    blocks = [dict(x) for x in dat['blocks']]
    entries = [list(x) for x in dat['entries']]
    for i in range(6):
        blocks.append({'index':5+i,'offset':59+i,'order':1})
        entries.append([i+2,59+i,59+i,'1'])
    where = {i:(g,i-bb['offset']) for g,bb in enumerate(blocks)
             for i in range(bb['offset'],bb['offset']+bb['order'])}
    labels = [(g,i,j) for g,bb in enumerate(blocks)
              for i in range(bb['order']) for j in range(i,bb['order'])]
    idx = {k:i for i,k in enumerate(labels)}
    adj = s.MutableSparseMatrix(309,457,{})
    for k,i,j,val in entries:
        ck(k > 0, fam+' homogeneous source coefficient')
        g,ii=where[i]; gg,jj=where[j]
        ck(g==gg,fam+' block-local coefficient')
        adj[k-1,idx[g,ii,jj]] += s.Rational(val)*(1 if ii==jj else 2)
    trace = s.Matrix([[1 if i==j else 0 for g,i,j in labels]])
    # A 302x302 diagonal invertible auxiliary minor is supplied by the
    # actual free entries.  This certifies rank without a sampled rank test.
    freecols=[idx[tuple(x)] for x in dat['free_positions']]
    minor=adj[7:,:][:,freecols]
    ck(minor.is_diagonal(),fam+' independent auxiliary trace minor diagonal')
    ck(all(minor[i,i] != 0 for i in range(302)),
       fam+' exact auxiliary rank302')
    ck(all(adj[i,j]==0 for i in range(7,309)
           for j,(g,ii,jj) in enumerate(labels) if g>=4),
       fam+' source sign coordinates absent in auxiliary equations')

    moments=[]
    for feats,weight in zip(dat['features'],dat['weights']):
        M=s.zeros(len(feats))
        for uu,vv,state in product([1,2],[1,2],range(4)):
            z=s.Matrix([s.Integer(uu)**p*s.Integer(vv)**q if st==state else 0
                        for st,p,q in feats])
            M += s.Integer(uu)**weight[0]*s.Integer(vv)**weight[1]*(z*z.T)
        moments.append(M)
    moments += [s.ones(1) for _ in range(7)]
    pivots=[positive_pivots(M) for M in moments]
    norm=sum(s.trace(M) for M in moments)
    ym=vectorize(moments,labels)/norm
    ck(adj[7:,:]*ym == s.zeros(302,1),fam+' complete strict dual auxiliary annihilation')
    ck((trace*ym)[0] == 1,fam+' strict dual trace normalization')

    if fam=='C1':
        seed=json.loads((ROOT/'c1'/'remembered_contact_source.json').read_text())
        coeff=list(map(s.Rational,seed['source']))
        uu=s.Rational(seed['contact']['u']); vv=s.Rational(seed['contact']['v'])
        state=list(map(s.Rational,seed['contact']['state']))
    else:
        seed=json.loads((ROOT/'c2'/'c2_regular_contact_seed.json').read_text())
        coeff=list(map(s.Rational,seed['coefficients']))
        uu,vv=map(s.Rational,seed['contact_angles'])
        state=list(map(s.Rational,seed['state']))
    contact=[]
    for feats,weight in zip(dat['features'],dat['weights']):
        z=s.Matrix([state[st]*uu**p*vv**q for st,p,q in feats])
        contact.append(uu**weight[0]*vv**weight[1]*(z*z.T))
    contact += [s.zeros(1) for _ in range(7)]
    cnorm=sum(s.trace(M) for M in contact)
    ck(cnorm>0,fam+' contact dual nonzero')
    yc=vectorize(contact,labels)/cnorm
    ck(adj[7:,:]*yc == s.zeros(302,1),fam+' actual contact annihilates every auxiliary')
    ck((trace*yc)[0] == 1,fam+' contact dual trace normalization')
    ck((s.Matrix(coeff).T*adj[:7,:]*yc)[0] == 0,
       fam+' exact sharp contact gives objective zero, not a lower bound')

    # Reconstruct the complete seven full-parent coefficient matrices from
    # the actual coefficient identity, then print all42 contact polynomials.
    parents=[]
    for k in range(1,8):
        G=[s.zeros(bb['order']) for bb in blocks[:4]]
        for kk,i,j,val in entries:
            if kk!=k: continue
            g,ii=where[i]; gg,jj=where[j]
            if g>=4: continue
            G[g][ii,jj]+=s.Rational(val)
            if ii!=jj: G[g][jj,ii]+=s.Rational(val)
        P=s.zeros(4)
        for feats,weight,Q in zip(dat['features'],dat['weights'],G):
            V=s.zeros(len(feats),4)
            for row,(st,pu,pv) in enumerate(feats): V[row,st]=u**pu*v**pv
            P += u**weight[0]*v**weight[1]*V.T*Q*V
        for ii,jj in product(range(4),repeat=2):
            q,rem=s.div(s.Poly(s.expand(P[ii,jj]),u,v),s.Poly((1+u)*(1+v),u,v))
            ck(rem.is_zero,fam+' full testing multiplier divides each coefficient entry')
            P[ii,jj]=q.as_expr()
        parents.append(P)
    J=s.Matrix.hstack(*[(P*psi).col_join(s.Matrix([
         (psi.T*P.diff(u)*psi)[0],(psi.T*P.diff(v)*psi)[0]])) for P in parents])
    Js=J.subs({u:uu,v:vv,a:state[0]/state[3],b:state[1]/state[3],t:state[2]/state[3]})
    ck(Js*s.Matrix(coeff)==s.zeros(6,1),fam+' all six uneliminated contact equations')
    ck(Js[:,1:].det()!=0,fam+' exact seed event minor nonzero')

    export={
      'family':fam,'status':'EXACT_FINITE_GATE_INPUT; UNIVERSAL_EMPTINESS_NOT_DECIDED',
      'source_array_sha256':sha(path),'source_order':(['d','m','C','A','D','alpha','beta']
                         if fam=='C1' else ['d','n','m','C','A','D','alpha']),
      'block_orders':[bb['order'] for bb in blocks], 'total_psd_order':65,
      'upper_dual_coordinates':labels,'coordinate_count':457,
      'auxiliary_rank':302,'normalized_affine_hull_dimension':154,
      'trace_convention':'Upper triangle coordinates; off-diagonals multiplied by2 in trace rows.',
      'visible_adjoint':enc(adj[:7,:]),'auxiliary_adjoint':enc(adj[7:,:]),
      'trace_row':enc(trace),
      'dual_base':'Every Y block PSD; auxiliary_adjoint*y=0; trace_row*y=1.',
      'strict_rational_dual_point':[str(x) for x in ym],
      'strict_point_unnormalized_ldl_pivots':pivots,
      'contact_variables':['u','v','a','b','t'],
      'full_parent_coefficient_matrices':[enc(P) for P in parents],
      'contact_matrix_polynomials':[[str(s.expand(J[i,j])) for j in range(7)] for i in range(6)],
      'uneliminated_regular_source_predicate':[
        'u>0','v>0','a*b*t!=0','det(J[:,1:])!=0',
        'c0=1','c1>0','c2>0','c3>0','c4>0','c5>0','c6>0','J*c=0'],
      'failure_predicate':('RegularSource(c,theta) AND Y,Z in dual_base AND '
          'c^T visible_adjoint Y<0 AND sigma(c)^T visible_adjoint Z<0'
          if fam=='C1' else 'RegularSource(c,theta) AND Y in dual_base AND c^T visible_adjoint Y<0'),
      'sigma_zero_based_source_permutation':([0,2,1,5,6,3,4] if fam=='C1' else None),
      'seed_coefficients':[str(x) for x in coeff],
      'seed_normalized_contact_dual':[str(x) for x in yc],
      'seed_objective':'0',
      'acceptance':'A proof that the failure predicate has NO real solution, or a universal primal construction; not a finite sample.'
    }
    dest=OUT/(fam+'_NORMALIZED_DUAL_FAILURE_SYSTEM.json')
    dest.write_text(json.dumps(export,indent=2)+'\n')
    results[fam]={'source_sha256':sha(path),'export_sha256':sha(dest),
                  'source_primal_auxiliaries':302,'regular_contact_primal_free_coordinates':250,
                  'normalized_dual_affine_dimension':154,
                  'universal_gate':'OPEN','physical_seed_dual_objective':'0'}

receipt={'status':'PASS','scope':'Exact finite dual-base/contact input only; neither universal gate decided.',
         'assertions':len(checks),'families':results,'checks':checks,
         'script_sha256':sha(Path(__file__))}
(OUT/'CHECK_NORMALIZED_DUAL_GATE.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['status','scope','assertions','families']},indent=2))
