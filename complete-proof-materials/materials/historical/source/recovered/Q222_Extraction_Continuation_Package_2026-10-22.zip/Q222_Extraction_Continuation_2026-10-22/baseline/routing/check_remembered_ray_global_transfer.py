#!/usr/bin/env python3
"""Independently verify the reported contact ray and its global eligibility.

This script proves physicality, exact extremality, which frames of the
actual N8368/N10736 compilers can contain the ray, and the exact common
two-frame separator against the actual current C1 coefficient arrays.
It does not infer any premise from a historical status or filename.
"""
from pathlib import Path
import hashlib,json,time
from fractions import Fraction
import sympy as s

HERE=Path(__file__).resolve().parent
START=time.time();CHECKS=[]
def check(name,condition):
    if not condition:raise AssertionError(name)
    CHECKS.append(name)
def zero(name,value):
    if not isinstance(value,s.MatrixBase):value=[value]
    check(name,all(s.cancel(z)==0 for z in value))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def strings(M):return [[str(z) for z in M.row(i)] for i in range(M.rows)]
def event(a,b,x,y):
    z=s.zeros(9,1);z[0]=1;z[1+x]=a;z[3+y]=b;z[5+2*x+y]=a*b
    return z
def positive_ldl(name,Q):
    """Exact rational Schur elimination, avoiding symbolic factor swell."""
    a=[[Fraction(str(z)) for z in Q.row(i)] for i in range(Q.rows)]
    pivots=[]
    for k in range(len(a)):
        pivot=a[k][k]
        check(name+' pivot%d is strictly positive'%k,pivot>0)
        pivots.append(str(pivot))
        for i in range(k+1,len(a)):
            for j in range(i,len(a)):
                a[i][j]-=a[i][k]*a[k][j]/pivot
                a[j][i]=a[i][j]
    return pivots

source_path=HERE/'inputs/remembered_contact_source.json'
record=json.loads(source_path.read_text())
check('Canonical C1 source order is explicit',record['source_order']==['d','m','C','A','D','alpha','beta'])
c=s.Matrix(list(map(s.Rational,record['source'])))
check('All seven exact source coefficients are strictly positive',all(z>0 for z in c))
check('The signed core coefficient is normalized to one',c[0]==1)
p=s.Rational(record['contact']['u']);q=s.Rational(record['contact']['v'])
psi=s.Matrix(list(map(s.Rational,record['contact']['state'])))
check('The remembered contact is precisely the stated finite positive experiment',
      p==s.Rational(1,13) and q==16 and psi==s.Matrix([140,-s.Rational(1,32),s.Rational(1,50),1]))

H=s.Matrix([1,0,0,0,0,-s.Rational(1,2),s.Rational(1,2),-s.Rational(1,2),-s.Rational(1,2)])
ev=[(1,1,0,1),(1,-1,0,0),(1,-1,1,1),(-1,1,1,0),(-1,1,0,0),(-1,1,1,1),(-1,-1,0,1),(1,-1,1,0)]
J=s.Matrix.hstack(H,*[event(*x) for x in ev])
J1=J[:,[0,3,4,5,6,7,8]]
f=J1*c

u,v,W,X,Y,Z=s.symbols('u v W X Y Z')
cv=s.symbols('d la n m C A D alpha beta')
d,la,n,m,C,A,D,alpha,beta=cv
Du,Dv=1+u*u,1+v*v
F=4*la*Du*(W+v*X)**2+4*n*Du*Dv*X**2+4*m*(v*W-X+u*v*Y-u*Z)**2
F+=4*C*Dv*(u*W-Y)**2+4*A*Du*Dv*Y**2
F+=(4*D+2*d)*(u*W+u*v*X-Y-v*Z)**2+(4*alpha+2*d)*Du*(v*Y-Z)**2
F+=(4*beta+2*d)*Dv*(X+u*Z)**2-2*d*Du*Dv*Z**2
P=s.hessian(F,(W,X,Y,Z))/2
fullc=J.inv()*f
zero('The original nine-coordinate source has exactly the C1 omission pair',
     fullc-s.Matrix([c[0],0,0,*list(c[1:])]))
M=P.subs(dict(zip(cv,fullc)));at={u:p,v:q}
zero('Every original-parent state contact equation',M.subs(at)*psi)
zero('Both original-parent angular contact equations',
     s.Matrix([(psi.T*M.diff(z).subs(at)*psi)[0] for z in (u,v)]))

I=s.eye(2);xx=s.Matrix([[0,1],[1,0]]);zz=s.diag(1,-1)
AA=[zz,((1-u*u)*zz+2*u*xx)/Du]
BB=[zz,((1-v*v)*zz+2*v*xx)/Dv]
OO=[s.eye(4)]+[s.kronecker_product(T,I) for T in AA]+[s.kronecker_product(I,T) for T in BB]+[s.kronecker_product(T,R) for T in AA for R in BB]
bell=sum((z*T for z,T in zip(f,OO)),s.zeros(4))
zero('The entire original Bell operator reproduces the untruncated parent',M-Du*Dv*bell)

det=s.cancel(M.det(method='domain-ge')/(Du**2*Dv**2))
pol=s.Poly(det,u,v,domain=s.QQ)
outer=[];center=s.S.Zero
for (i,j),z in pol.terms():
    check('Determinant exponent (%d,%d) is even'%(i,j),i%2==j%2==0)
    ex=(i//2-1,j//2-1)
    if ex==(0,0):center+=z
    else:outer.append((*ex,z))
check('Exactly six outer Laurent coefficients are strictly positive',
      len(outer)==6 and all(z>0 for i,j,z in outer))
weights=[(i,j,s.cancel(z*(p*p)**i*(q*q)**j)) for i,j,z in outer]
zero('The exact positive contact weights cancel the Laurent center',center+sum(z for i,j,z in weights))
zero('The exact positive contact weights have zero exponent barycenter',
     s.Matrix([sum(i*z for i,j,z in weights),sum(j*z for i,j,z in weights)]))
zero('Three retained positive event rows span the WXY hard block',
     s.Matrix([[v,-1,u*v],[u,0,-1],[0,0,1]]).det()-u)
SA=s.diag(1,1,-1,-1);SB=s.diag(1,-1,1,-1)
zero('The complete Alice sign congruence',P.subs(u,-u)-SA*P*SA)
zero('The complete Bob sign congruence',P.subs(v,-v)-SB*P*SB)

K=P.subs(at)*psi
angular=s.Matrix([(psi.T*P.diff(z).subs(at)*psi)[0] for z in (u,v)])
R=K.col_join(angular).jacobian(cv)*J.inv()
check('The six original-affine contact equations have rank six',R.rank()==6)
zeros=[];detvals=[];prs=[]
for bits in range(16):
    z=[s.Integer(1) if bits&(1<<i) else s.Integer(-1) for i in range(4)]
    pt=s.Matrix([1,*z,z[0]*z[2],z[0]*z[3],z[1]*z[2],z[1]*z[3]])
    val=(f.T*pt)[0];detvals.append({'point':list(map(str,pt)),'value':str(val)})
    if val==0:zeros.append(pt)
    if s.prod(z)==-1:
        pr=s.Matrix([1,0,0,0,0,*z]);prs.append((pr,(f.T*pr)[0]))
check('Exactly two deterministic zeros, all other deterministic values strict',
      len(zeros)==2 and sum(1 for z in detvals if s.Rational(z['value'])>0)==14)
RR=R.col_join(s.Matrix.vstack(*[z.T for z in zeros]))
pivots=RR.rref()[1]
check('The full original-affine contact and zero system has rank eight',len(pivots)==8)
zero('The physical support spans the nullspace of all eight constraints',RR*f)
minor=RR[:,list(pivots)].det()
check('An explicit eight by eight exact minor is nonzero',minor!=0)
check('Exactly one PR point is negative and its value is minus one',
      [z for _,z in prs if z<0]==[-1] and all(z!=0 for _,z in prs))
print('Exact physicality and rank-eight contact verified.',flush=True)

# The historical array has different status prose, but exactly the same
# mathematical coefficient data as the current array.  Verify that fact
# and independently replay the full, uncompressed dual certificate.
coo_path=HERE/'inputs/C1_RAMIFIED_PRIMAL.coo.json'
hist_coo_path=HERE/'inputs/historical_C1_RAMIFIED_PRIMAL.coo.json'
coo=json.loads(coo_path.read_text());hist_coo=json.loads(hist_coo_path.read_text())
for key in ('weights','features','variables','visible_count','auxiliary_count','matrix_order','blocks','entries'):
    check('Historical/current C1 exact numerical agreement: '+key,coo[key]==hist_coo[key])
check('The only historical/current C1 differences are status prose',
      {k for k in set(coo)|set(hist_coo) if coo.get(k)!=hist_coo.get(k)}=={'scope','whole_master_equality'})
sep_path=HERE/'inputs/historical_C1_SATURATED_CONE_SEPARATOR.json'
sep=json.loads(sep_path.read_text())
zero('The recovered common separator uses exactly this physical source',
     s.Matrix(list(map(s.Rational,sep['coefficients'])))-c)
ell=s.Matrix(list(map(s.Rational,sep['common_separator'])))
physical_eval=s.Matrix(list(map(s.Rational,sep['physical_evaluation_coefficients'])))
cv1=(d,m,C,A,D,alpha,beta)
actual_eval=s.Matrix([(psi.T*P.diff(z).subs(at)*psi)[0] for z in cv1])
zero('Historical evaluation is the full current parent, not the quarter-parent',
     physical_eval-actual_eval)
zero('The common functional is exactly 93424 times the full evaluation minus d',
     ell-93424*actual_eval+s.Matrix([1,0,0,0,0,0,0]))
zero('The common separator has exact source pairing minus one',(ell.T*c)[0]+1)
sigma_indices=[0,2,1,5,6,3,4]
dual_records=[]
for item in sep['orientation_certificates']:
    orientation=item['orientation']
    blocks=[s.Matrix(block).applyfunc(s.Rational) for block in item['dual_blocks']]
    check('Orientation%d full block orders are14,6,6,4'%orientation,
          [Q.rows for Q in blocks]==[14,6,6,4])
    piv=[]
    for b,Q in enumerate(blocks):
        zero('Orientation%d block%d is symmetric'%(orientation,b),Q-Q.T)
        piv.append(positive_ldl('Orientation%d block%d'%(orientation,b),Q))
    functional=s.zeros(86,1)
    for k,i,j,value in coo['entries']:
        if i==30:
            check('Original scalar block is exactly nonnegative d',j==30 and k==1 and s.Rational(value)==1)
            continue
        b=next(b for b,B in enumerate(coo['blocks'][:4])
               if B['offset']<=i<=j<B['offset']+B['order'])
        off=coo['blocks'][b]['offset']
        functional[k-1]+=s.Rational(value)*(1 if i==j else 2)*blocks[b][i-off,j-off]
    zero('Orientation%d annihilates all79 current auxiliary directions'%orientation,functional[7:,:])
    target=ell if orientation==0 else s.Matrix([ell[i] for i in sigma_indices])
    residual=s.Rational(item['scalar_residual'])
    check('Orientation%d scalar residual equals positive one'%orientation,residual==1)
    zero('Orientation%d every visible trace equation equals target minus d'%orientation,
         target-functional[:7,:]-s.Matrix([residual,0,0,0,0,0,0]))
    dual_records.append({'orientation':orientation,'full_block_positive_LDL_pivots':piv,
                         'scalar_d_residual':str(residual),
                         'appended_six_source_orthant_multipliers':[0]*6})
check('The recovered certificate includes exactly both orientations',
      {x['orientation'] for x in dual_records}=={0,1})
print('Both complete exact common-separator certificates verified.',flush=True)

eligible=[];map_inputs=[]
for filename,N in [('GLOBAL_SOURCE_MAPS_N8368.json',8368),('GLOBAL_SOURCE_MAPS_N10736.json',10736)]:
    path=HERE/'inputs'/filename;map_inputs.append(path)
    maps=json.loads(path.read_text())
    zero('N%d full original coefficient dictionary'%N,s.Matrix(maps['full_source_map']).applyfunc(s.Rational)-J)
    fit=[]
    for rec in maps['components']:
        JJ=s.Matrix(rec['source_to_original_affine']).applyfunc(s.Rational)
        try:cc,free=JJ.gauss_jordan_solve(f)
        except ValueError:continue
        if all(z>=0 for z in cc):
            check('N%d eligible component has a unique source preimage'%N,free.rows==0)
            fit.append((rec,cc))
    check('N%d has exactly the two eligible C1 stabilizer frames'%N,
          len(fit)==2 and all(rec['family']=='C1' for rec,cc in fit))
    sigma=s.Matrix([c[0],c[2],c[1],c[5],c[6],c[3],c[4]])
    check('N%d eligible preimages are exactly c and sigma1(c)'%N,
          {tuple(cc) for rec,cc in fit}=={tuple(c),tuple(sigma)})
    check('N%d contains every16 original event inequalities'%N,
          len(maps['nonsignaling_event_blocks'])==16)
    for evrec in maps['nonsignaling_event_blocks']:
        ee=s.Matrix(list(map(s.Rational,evrec['affine_coefficients'])))
        zero('N%d literal event matches its original probability'%N,ee-event(*evrec['event']))
        check('N%d an event ray cannot be a multiple of the excluded support'%N,
              ee[0]*f-f[0]*ee!=s.zeros(9,1))
    eligible.append({'N':N,'component_count':len(maps['components']),
                     'eligible':[{'component':rec['component'],'bell_group_index':rec['bell_group_index'],
                                  'family':rec['family'],'point_action':rec['point_action'],
                                  'canonical_source':list(map(str,cc))} for rec,cc in fit]})
print('All actual current global source maps screened.',flush=True)

# The old192-frame handoff and the current192 canonical part use the same
# C1 maps. C2 may select the opposite member of its proved invariant pair.
hist_maps_path=HERE/'inputs/historical_FULL_NONSYMMETRIC_FRAME_LIST.json'
hist_maps=json.loads(hist_maps_path.read_text())
current_maps=json.loads(map_inputs[0].read_text())
key=lambda M:tuple(tuple(s.Rational(x) for x in row) for row in M)
old_c1={key(x['affine_embedding']) for x in hist_maps['frames'] if x['family']=='C1'}
new_c1={key(x['source_to_original_affine']) for x in current_maps['components'] if x['family']=='C1'}
check('All128 historical C1 affine maps equal the current128 literal maps',
      len(old_c1)==128 and old_c1==new_c1)
hist_mapping=[]
current_by_family={}
for now in current_maps['components']:
    current_by_family.setdefault(now['family'],[]).append((now,key(now['source_to_original_affine'])))
for rec in hist_maps['frames']:
    old=key(rec['affine_embedding'])
    matches=[]
    for now,new in current_by_family[rec['family']]:
        if old==new:matches.append({'component':now['component'],'source_permutation':'identity'})
        elif rec['family']=='C2' and old==tuple(tuple(row[j] for j in [0,1,5,6,4,2,3]) for row in new):
            matches.append({'component':now['component'],'source_permutation':'sigma2'})
    check('Historical frame '+rec['id']+' has an exact current canonical match',len(matches)==1)
    hist_mapping.append({'historical_id':rec['id'],'family':rec['family'],**matches[0]})

# Positive finite evaluation moments independently corroborate the
# bounded-Gram closedness premise used in the printed global argument.
moments=[]
for fam in ('C1','C2'):
    raw=json.loads((HERE/'inputs'/('%s_RAMIFIED_PRIMAL.coo.json'%fam)).read_text())
    for b,ff in enumerate(raw['features']):
        MM=s.zeros(len(ff));wu,wv=raw['weights'][b]
        for uu in (1,2):
            for vv in (1,2):
                for state in range(4):
                    row=s.Matrix([uu**i*vv**j if a==state else 0 for a,i,j in ff])
                    MM+=uu**wu*vv**wv*row*row.T
        piv=positive_ldl(fam+' block%d finite evaluation moment'%b,MM)
        moments.append({'family':fam,'block':b,'LDL_pivots':piv})

out={
 'status':'PASS_EXACT_CURRENT_N8368_AND_N10736_GLOBAL_REFUTATION',
 'global_strictness':'BOTH_CURRENT_PENCILS_ARE_STRICTLY_OUTER',
 'not_concluded':['Failure of any enlarged testing-feature candidate','Failure of C160','Nonexistence of a finite SDP lift of Q222'],
 'checks_passed':len(CHECKS),'checks':CHECKS,
 'source':list(map(str,c)),'original_affine_support':list(map(str,f)),
 'contact':record['contact'],
 'physicality_proof':'The six positive Laurent contact weights have zero exponent barycenter and cancel the center, so weighted AM-GM proves determinant nonnegativity. The three positive m,C,A rows give a strict WXY principal block for u,v>0. The full matrix is PSD by Schur complement; exact sign congruences and homogeneous continuity cover every real/projective test.',
 'positive_laurent_contact_weights':[[i,j,str(z)] for i,j,z in weights],
 'contact_and_zero_constraint_matrix':strings(RR),
 'rank_eight_pivot_columns':list(pivots),'nonzero_rank_eight_minor':str(minor),
 'deterministic_values':detvals,'PR_values':[{'point':list(map(str,pt)),'value':str(z)} for pt,z in prs],
 'compiler_correspondence':eligible,
 'historical_to_current_frame_mapping':hist_mapping,
 'common_separator':list(map(str,ell)),
 'source_separator_pairing':'-1',
 'dual_certificates':dual_records,
 'positive_evaluation_moments':moments,
 'transfer_lemma':'In a physical conic decomposition of this support every summand vanishes at the exact contact and two deterministic zeros. Rank eight forces every summand to lie on its ray. The actual global compiler maps allow only c and sigma1(c) in C1 frames, both excluded by the common exact separator. Positive finite evaluation moments and bounded closed-face diagonal entries imply each certificate cone is closed. The positive affine constant bounds every summand in the finite global sum, so this sum is closed. Bipolar separation and the16 event rays yield a normalized nonquantum behavior in each outer pencil. No explicit behavior/auxiliary assignment is claimed.',
 'inputs':[{'path':str(path.relative_to(HERE)),'sha256':sha(path)} for path in [source_path,coo_path,hist_coo_path,sep_path,hist_maps_path,HERE/'inputs/C2_RAMIFIED_PRIMAL.coo.json',*map_inputs]],
 'checker':{'path':Path(__file__).name,'sha256':sha(Path(__file__))},
 'seconds':time.time()-START}
(HERE/'REMEMBERED_RAY_GLOBAL_TRANSFER.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'checks':len(CHECKS),'global_strictness':out['global_strictness'],
                  'eligible_components':eligible,'seconds':out['seconds']},indent=2))
