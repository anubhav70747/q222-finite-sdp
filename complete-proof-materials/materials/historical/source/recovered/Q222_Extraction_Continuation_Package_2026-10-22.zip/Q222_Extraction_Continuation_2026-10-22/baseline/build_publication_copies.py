#!/usr/bin/env python3
"""Create line-wrap-only publication copies, preserving checked originals."""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "publication"
OUT.mkdir(exist_ok=True)
records = []

def convert(source, replacements, description):
    original = ROOT / source
    text = original.read_text()
    for old, new in replacements:
        if text.count(old) != 1:
            raise RuntimeError(f"Expected exactly one layout target in {source}")
        text = text.replace(old, new)
    target = OUT / original.name
    target.write_text(text)
    records.append({
        "original": source,
        "original_sha256": hashlib.sha256(original.read_bytes()).hexdigest(),
        "publication_copy": str(target.relative_to(ROOT)),
        "publication_sha256": hashlib.sha256(target.read_bytes()).hexdigest(),
        "change_scope": description,
        "mathematical_content_changed": False,
    })

convert("c1/two_frame_correction.tex", [
    (r"$(1,1,+,-),(1,0,-,+),(0,0,-,+),(1,1,-,+),(0,1,-,-),(1,0,+,-)$,",
     r"\[ (1,1,+,-),\ (1,0,-,+),\ (0,0,-,+),\ (1,1,-,+),\ (0,1,-,-),\ (1,0,+,-), \]"),
    (r""" c_* =\left(1,
 \frac{1166523000}{31661820415017653},
 \frac{322803000}{186199784281},
 \frac{218288946200}{1359122513},
 \frac{90943434293}{222507771414},
 \frac{248802430236}{3300726103},
 \frac{205476973}{51646655494}\right),""",
     r""" \begin{aligned}
 d_*&=1,&m_*&=\frac{1166523000}{31661820415017653},
 &C_*&=\frac{322803000}{186199784281},\\
 A_*&=\frac{218288946200}{1359122513},
 &D_*&=\frac{90943434293}{222507771414},\\
 \alpha_*&=\frac{248802430236}{3300726103},
 &\beta_*&=\frac{205476973}{51646655494}.
 \end{aligned}"""),
], "Line-break the six-event list; display the seven unchanged rational source coordinates in aligned rows.")

convert("routing/enlarged_global_candidate.tex", [
    (r""" [k,i,j,a]:\quad a\text{ contributes to matrix entry }(i,j),\quad
 k=0\text{ constant},\quad k=1,\ldots,8\text{ original visible},
 \quad k=9+r\text{ auxiliary }r.""",
     r""" \begin{gathered}
 [k,i,j,a]:\quad a\text{ contributes to matrix entry }(i,j),\\
 k=0\text{ constant},\quad k=1,\ldots,8\text{ original visible},\\
 k=9+r\text{ auxiliary }r.
 \end{gathered}"""),
], "Line-break the unchanged COO record convention into three display rows.")

(ROOT / "PUBLICATION_TRANSFORMS.json").write_text(json.dumps({
    "scope": "Presentation-only copies; exact checkers and dependency records retain the unchanged originals.",
    "files": records,
}, indent=2) + "\n")
print(json.dumps({"publication_copies": len(records), "status": "PASS"}))
