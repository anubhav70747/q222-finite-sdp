Q222: corrected global candidates and the remaining extraction route
2026-10-22

CURRENT RESULT

The old two-orientation C1 certificate cone is too small. The previously
released order-8368 and order-10736 global pencils are both strictly outer
approximations of the full Q222 body. This is proved for the actual current
coefficient arrays and every component of those global constructions.

A NEW enlarged candidate is fully evaluated here. It has total PSD order
13744, 29920 auxiliaries, 2928 blocks, largest block order 15, and 153248
rational upper-triangle coefficient records. Its original visible order is
(a0,a1,b0,b1,E00,E01,E10,E11). Its quantum forward inclusion is proved.
Its quantum reverse inclusion is NOT proved.

There are two central open mathematical gates: universal enlarged C1
two-orientation PSD coverage and universal enlarged C2 PSD coverage. The
regular-contact and closedness theorems reduce all source boundaries to
these gates; they do not supply a universal PSD selection. The finite dual
failure systems specify exact acceptance problems and remain undecided.

MAIN FILES

current_global_candidate_correction.tex
  RG1–RG19: exact physical source, common two-frame separator, rank-eight
  extremality, all 288/352 actual source maps, closedness and strict global
  outer containment. No explicit nonquantum behavior/auxiliary vector is
  claimed. 448-check actual replay: REMEMBERED_RAY_GLOBAL_TRANSFER.json.

enlarged_global_candidate.tex
  EG1–EG13: full (1+u)(1+v) times parent, legal fixed testing features,
  complete affine matching, attained dualization, actual enlarged matrices,
  forward inclusion and the precise conditional global reverse theorem.

compiled_enlarged/GLOBAL_CANONICAL_OUTER_PENCIL.coo.json
  Complete evaluated affine pencil. Each record [k,i,j,value] is an upper
  triangle entry, mirrored once when i!=j. k=0 is the constant matrix;
  k=1..8 are the original visible coordinates; k=9+r is auxiliary r.

compiled_enlarged/GLOBAL_SOURCE_MAPS.json
  Every original affine source map, physical Bell action, block offset,
  auxiliary interval, coefficient sign and event block.

compiled_enlarged/{C1,C2,CF_ADJ,CF_OPP}_QUALIFIED_DUAL.json
  Exact canonical source maps, strict rational witnesses, trace-adjoint
  elimination and complete particular/nullspace parameterizations.

CHECK_ENLARGED_GLOBAL_COMPILER.json
  2192-check independent raw-array readback. The checker does not import the
  compiler. It rebuilds original Pauli operators and every source/auxiliary
  coefficient, matching ranks, strict witnesses and all emitted adjoints.

NORMALIZED_DUAL_GATE_INDEPENDENT_REVIEW.json
  263-check independent check of the finite decision inputs, including all 42
  original contact polynomials per family. Analytical review accepts DG1–DG9
  only as exact reformulations; neither failure system is solved.

C1_REGULAR_GATE_ANALYTICAL_REVIEW.json
C2_REGULAR_GATE_ANALYTICAL_REVIEW.json
  Independent complete proof reads of the regular-cap/boundary reductions.
  Their sibling exact-check receipts are attributed separately. No extra
  replay is asserted by these analytical review files.

The adjacent c2/ workstream also completes SF1–SF12 for the entire
D=m, alpha=C sector: PSD blocks4 and5, nine auxiliaries, total order18
in seven source coordinates (or14 in five independent sector coordinates).
Its own642-check receipt and the root analytical review support that scoped
result. It does not prove universal enlarged C2 coverage, and this routing
inventory claims no separate sector replay.

REMAINING_EXTRACTION_CHECKLIST.json
  Detailed source/extraction dependencies and the unchanged E1–E3 acceptance
  criteria. The package-root CHECKLIST.json is the primary release checklist.
  There is no completion percentage and no aggregate assertion total.

PORTABLE_CHECKER_INVENTORY.json
  Exact script, runtime-input, helper-module and receipt hashes for every
  routing replay. All paths are relative to the supplied package root.

receipt_audit/RECEIPT_RECONCILIATION.json
  Records the retained isolated replay that replaced a stale360-check
  receipt. The unchanged checker actually executes448 checks, with385
  distinct labels. The old receipt used32 matrix-level LDL labels; the
  current execution uses120 pivot-level labels. All other mathematical
  payload fields are identical. The stale receipt is preserved solely as
  an audit record, not current verification evidence.

REPLAY

Python 3 and SymPy 1.14 are sufficient. No solver, credential, network request,
or unbundled mathematical input is needed. Run from an isolated copy if
preserving the recorded receipt hashes, because the exact checkers write
new receipts with fresh elapsed times.

  python check_remembered_ray_global_transfer.py
  python compile_enlarged_global_candidate.py
  python check_enlarged_global_compiler.py
  python check_normalized_dual_gate_independent.py

The last checker reads the adjacent package-root dual_gate/ exports and
normalized_dual_gate.tex. All other mathematical inputs are under inputs/.
The new compiler writes only compiled_enlarged/ in this new work directory.
The previous released inputs and outputs are not modified.

CUSTODY AND SCOPE

INPUT_CUSTODY.json binds unchanged historical/current input copies.
ENLARGED_COMPILER_PROVENANCE.json identifies the earlier compiler primitives
from which the new portable implementation was derived. Those historical
locations are provenance, not runtime file dependencies.

Some copied historical proof and discovery files retain old status prose.
In particular inputs/global_source_compiler_and_obstruction.tex supplies
the original dictionary, support generation, dualization and closedness
arguments, but its earlier open-status paragraphs are superseded by RG19.
The old current-array JSON files remain unchanged even though exactness is
now refuted. A remembered-source discovery record is not a proof premise;
the new exact physicality and separator checks supply its verification.

The counterexample does not refute the enlarged construction, C160, or the
existence of some finite SDP lift. Exact sector lifts and valid coefficient
identities from prior releases remain valid at their stated scopes.
