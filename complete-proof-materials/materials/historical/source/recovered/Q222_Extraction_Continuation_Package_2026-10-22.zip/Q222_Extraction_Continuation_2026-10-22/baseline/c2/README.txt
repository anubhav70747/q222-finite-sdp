C2 FINITE-LIFT CHECKLIST AND EXACT NEW RESULTS
2026-10-22

This directory contains two complete mathematical results, not a claim
that the full finite lift of the quantum set has been extracted.

1. c2_regular_contact_reduction.tex (GR1-GR17)

For any closed convex sound C2 certificate cone containing the six event
rays, exactness on the explicitly printed five-parameter regular contact
domain is equivalent to exactness on the whole nonnegative-coefficient
C2 cone. The proof establishes finite sharp contacts, true analytic
density, and all literal coefficient-zero and angle-endpoint limits.
The old and enlarged actual Gram dictionaries satisfy every premise.

The actual constant contact systems are evaluated in:
  c2_old_regular_contact_system.json
  c2_enlarged_regular_contact_system.json

Their remaining free dimensions are 55 and 250, respectively. These are
complete affine solution spaces. Universal PSD feasibility of either
space over every point of Theta_reg remains unproved. No generic-density
claim or separate hidden boundary hypothesis is left in that gate.

2. c2_reciprocal_fixed_sector.tex (SF1-SF12)

The full physical C2 slice D=m and alpha=C has an exact evaluated affine
lift. The original seven visible coordinates use PSD blocks of orders
4 and 5, plus nine scalar orthant/equality blocks: total order18 and
nine auxiliary variables. In its five independent visible coordinates
the total order is14. Both inclusions include every singular or zero
coefficient face.

  C2_RECIPROCAL_FIXED_SECTOR.coo.json

is the literal rational coefficient array. Entry format is
  [variable_index, global_row, global_column, rational_coefficient].
Variable indices are one-based in the printed variables list; index0
would denote a constant. Only upper-triangle entries are stored and
each off-diagonal is mirrored once. Block offsets are supplied.

The reverse inclusion uses the degree-bounded matrix Fejer-Riesz theorem
on the real line, verified against A. Zalar, arXiv1503.06034v1, Theorem1.2,
page1. It includes positive semidefinite, possibly singular polynomial
matrices. This standard analytical theorem is stated explicitly in the
proof and receipt. The finite checker does not claim to reprove it.

REPLAY

Requires Python3 and SymPy only; no optimization solver or network.
Run from any working directory:
  python3 /absolute/path/to/c2/check_c2_regular_contact_reduction.py
  python3 /absolute/path/to/c2/check_c2_reciprocal_fixed_sector.py

The current shared-workspace runtime command is:
  PYTHONDONTWRITEBYTECODE=1 \
  PYTHONPATH=/workspace/scratch/88a271344190/reconstruction/python_deps \
  python3 /absolute/path/to/checker.py

The first checker passes75 exact assertions and rewrites the two contact
systems, seed and receipt deterministically. The second passes642 exact
assertions, including each rational affine entry, and rewrites the
sector COO and receipt deterministically. Paths in generated records
are local-relative. All original historical inputs remain unmodified.

STATUS

STATUS.json supplies the exact current C2 subchecklist and file hashes.
qa/VISUAL_REVIEW.json records actual inspection of all four GR pages
and all three SF pages; those PDFs are standalone layout previews.

The enlarged 250-free-coordinate universal PSD selection is still the
primary C2 gate. The sector theorem is an exact restricted lift, not a
proof of that selection and not a proof of the old two-angle Gram cone.
The separate C160 outer model remains another unproved reverse-inclusion
route. No matrix-size optimality or extension-degree claim is made.
