Q222 — PRECISE EXTRACTION CHECKLIST AND VERIFIED PROGRESS
22 October 2026

FULL FINITE-LIFT EXTRACTION IS NOT COMPLETE.

Start with Q222_Extraction_Checklist_and_Progress_2026-10-22.pdf and
CHECKLIST.txt. CHECKLIST.json is the machine-readable primary ledger.
The two central remaining universal statements are G1 and G2. These
are coverage gates for the chosen enlarged dictionaries; a different
adequate finite construction may replace this route.

RESULTS AND CORRECTIONS

1. The actual old two-orientation C1 candidate is refuted. The preceding
   order-8368 and order-10736 global candidates are both strictly outer.
   The exact physical source, both separating dual certificates and the
   full component/extremality/closedness transfer are included.

2. A new evaluated global outer pencil has total PSD order 13744,
   29920 auxiliaries, 2928 blocks, largest block order 15, and 153248
   rational upper-triangle records. Quantum forward inclusion is proved.
   Reverse inclusion remains OPEN; 13744 is not a proved exact lift-size
   bound for the full quantum set.

3. Both C1 and C2 now have complete sharp-cap, regular-contact, density,
   source interpolation and boundary reductions. Actual Gram closedness
   is proved. The universal regular-contact admission statements are
   still open: each compressed fiber has 250 free coordinates. Writing
   this affine fiber does not establish its PSD feasibility.

4. The C1 enlarged frame repairs the known excluded physical source,
   with an exact certificate and explicit monotone-chamber selector.
   This is not a universal C1 selector.

5. The C2 source sector D=m, alpha=C has a complete exact lift, including
   all coefficient-zero faces. It uses blocks of orders 4 and 5 with
   nine auxiliaries. Including scalar source/equality constraints gives
   total order 18 in seven source coordinates, or 14 in five independent
   coordinates. Both inclusions are proved. This is a source-sector
   result, not a full-Q222 behavior representation.

6. Compact trace-one dual systems specify the remaining failures exactly.
   Each dual base has affine dimension 154. No global emptiness decision
   or quantifier-elimination certificate for either system is claimed.

FILES

  c1/             C1 proofs, literal source arrays, exact certificates,
                  complete contact maps, scripts and peer reviews.
  c2/             C2 regular reduction, exact reciprocity-fixed sector,
                  coefficient arrays, checkers and scoped review.
  routing/        Old global strictness proof and complete enlarged global
                  construction, source maps, qualified duals and readback.
  dual_gate/      Two full finite normalized dual failure systems.
  publication/    Two layout-only TeX copies; checked originals retained.
  qa/             Combined PDF inspection record and compile diagnostics.
  provenance/     Unchanged August ZIP and preceding frozen extraction ZIP.
                  Their superseded statuses are explained separately.

The combined PDF does not reprint every retained prerequisite. Those
proof sources are bundled in routing/inputs, including the physical
reduction, exact closed faces and finite-contact support reduction.
This package is not a recreation of the missing 549-page R21 original,
and does not re-audit the entire inherited qualitative existence proof.

VERIFY

  python verify.py

This uses only the Python standard library. It checks every manifest
entry, required evidence paths, publication-copy bindings and the crucial
scope invariants: G1/G2 open, both old candidates strictly outer, and the
new global reverse inclusion unproved.

For focused exact algebra replay, install requirements.txt in your Python
environment and run:

  python verify.py --replay exact

There are eleven suites. Each runs in its own temporary package copy so
that regenerated receipts cannot alter the delivered records. Replays
require Python 3 and SymPy 1.14. No numerical SDP solver or network is
used. Allow several minutes, particularly for the old global strictness
checker. Optional --jobs 1 reduces simultaneous memory/CPU use. Optional
--report /path/to/new_report.json writes a new replay record.

The counts overlap and are not added. Exact code checks corroborate
finite identities and arrays; analytic cap, density, closedness and
separation arguments require mathematical review. The eleven PASS results
do not prove universal G1/G2 or the full reverse inclusion.

READ THE MATRIX DATA

  python read_pencil.py
  python read_pencil.py --entry 0 0
  python read_pencil.py --entry 0 0 --coefficient 1
  python read_pencil.py --pencil c2-sector

Indices are zero-based. Direction k=0 is the affine constant, followed by
visible/source directions and then auxiliary directions. Every entry
record contains an exact rational string. Off-diagonal upper-triangle
records are mirrored exactly once. The reader can also evaluate an
individual small block with --block and a --values JSON direction map;
it does not allocate a dense 13744-by-13744 matrix or solve feasibility.

REBUILD THE PDF

  python build_publication_copies.py
  python build_checklist.py --release-verified
  latexmk -pdf -interaction=nonstopmode -halt-on-error \
    Q222_Extraction_Checklist_and_Progress_2026-10-22.tex

The --release-verified flag requires the delivered successful replay and
visual-review records; omitting it produces a release-pending checklist.
Rebuilding may change PDF metadata. The original hash manifest describes
the delivered bytes, so use a separate copy when rebuilding.

REVIEW SCOPE

Analytical lead review and independent-agent reviews in the same model
system, supplemented by targeted exact symbolic corroboration. This is
not external peer review or proof-assistant formal verification.
