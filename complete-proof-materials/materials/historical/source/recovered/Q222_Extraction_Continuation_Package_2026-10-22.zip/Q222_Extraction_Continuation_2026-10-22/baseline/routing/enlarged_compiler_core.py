#!/usr/bin/env python3
"""Exact support-cone primitives for the enlarged global candidate.

Derived from the frozen previous global compiler; every historical input
and earlier output remains unchanged.  This module verifies the complete
(1+u)(1+v) times parent, appends six event signs, and re-solves strict
Slater witnesses and the entire trace-adjoint equations.

Compile both canonical certificate cones and exact closed faces globally.

The result is an evaluated rational OUTER pencil in the original eight
behavior coordinates.  Exactness is conditional on the two printed whole-
canonical-cone converse statements.  No status flag or numerical solver is
used as a mathematical premise.  Requires Python 3 and SymPy only.
"""
from collections import defaultdict, deque
import argparse
from pathlib import Path
import hashlib
import json
import time
import sympy as s

HERE = Path(__file__).resolve().parent
INPUTS = HERE/'inputs'
OUT = HERE/'compiled_enlarged'
OUT.mkdir(exist_ok=True)
HALF = s.Rational(1, 2)
FULL_ORDER = ['d','lambda','n','m','C','A','D','alpha','beta']
Q_ORDER = ['constant','a0','a1','b0','b1','E00','E01','E10','E11']
EVENTS = {
    'lambda':(1,1,0,1), 'n':(1,-1,0,0), 'm':(1,-1,1,1),
    'C':(-1,1,1,0), 'A':(-1,1,0,0), 'D':(-1,1,1,1),
    'alpha':(-1,-1,0,1), 'beta':(1,-1,1,0),
}
FAMILIES = {
    'C1': {'order':['d','m','C','A','D','alpha','beta'], 'omissions':['lambda','n']},
    'C2': {'order':['d','n','m','C','A','D','alpha'], 'omissions':['lambda','beta']},
    'CF_ADJ': {'order':['d','n','C','A','D','alpha','beta'], 'omissions':['lambda','m']},
    'CF_OPP': {'order':['d','n','m','C','A','D','beta'], 'omissions':['lambda','alpha']},
}
checks = defaultdict(list)


def ck(group, name, condition):
    if condition is not True and condition != s.true:
        raise AssertionError(group+': '+name)
    checks[group].append(name)


def equal(group, name, expression):
    values = list(expression) if isinstance(expression,s.MatrixBase) else [expression]
    ck(group,name,all(s.expand(value)==0 for value in values))


def dump(path, data):
    path.write_text(json.dumps(data,indent=2)+'\n')


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def event_vector(a,b,x,y):
    v = s.zeros(9,1)
    v[0]=1;v[1+x]=a;v[3+y]=b;v[5+2*x+y]=a*b
    return v


H = s.Matrix([1,0,0,0,0,-HALF,HALF,-HALF,-HALF])
EVENT_VECTORS = {name:event_vector(*event) for name,event in EVENTS.items()}
JFULL = s.Matrix.hstack(H,*[EVENT_VECTORS[name] for name in FULL_ORDER[1:]])


def source_map(family):
    return JFULL[:,[FULL_ORDER.index(name) for name in FAMILIES[family]['order']]]


def signed_permutation_matrix(g):
    return s.Matrix([[((1 if value>0 else -1) if j==abs(value)-1 else 0)
                      for j in range(9)] for value in g])


def compose(g,h):
    return tuple((1 if value>0 else -1)*h[abs(value)-1] for value in g)


def bell_group():
    ident = tuple(range(1,10))
    def perm(swaps=(), flips=()):
        g=list(ident)
        for a,b in swaps:g[a],g[b]=g[b],g[a]
        for a in flips:g[a]=-g[a]
        return tuple(g)
    generators=[
        perm([(1,2),(5,7),(6,8)]),
        perm([(3,4),(5,6),(7,8)]),
        perm(flips=(1,5,6)),perm(flips=(2,7,8)),
        perm(flips=(3,5,7)),perm(flips=(4,6,8)),
        perm([(1,3),(2,4),(6,7)]),
    ]
    queue=deque([ident]);seen={ident}
    while queue:
        g=queue.popleft()
        for h in generators:
            v=compose(h,g)
            if v not in seen:seen.add(v);queue.append(v)
    return sorted(seen)


def upper_labels(sizes):
    return [(b,i,j) for b,size in enumerate(sizes) for i in range(size) for j in range(i,size)]


def upper_to_blocks(vector,labels,sizes):
    blocks=[s.zeros(size) for size in sizes]
    for value,(b,i,j) in zip(vector,labels):
        blocks[b][i,j]=value;blocks[b][j,i]=value
    return blocks


def matrix_rows_json(matrix):
    return [[str(v) for v in matrix.row(i)] for i in range(matrix.rows)]


def matrix_from_rows(rows):
    return s.Matrix([[s.Rational(x) for x in row] for row in rows])


def coefficient_matrix_json(matrix):
    return {'rows':matrix.rows,'columns':matrix.cols,
        'entries':[[i,j,str(matrix[i,j])] for i in range(matrix.rows)
                   for j in range(matrix.cols) if matrix[i,j]]}


def certify_pd(family,block,number):
    L,D=block.LDLdecomposition(hermitian=False)
    ck('strict_feasibility',f'{family} block {number}: exact positive LDL pivots',
       all(x>0 for x in D.diagonal()))
    equal('strict_feasibility',f'{family} block {number}: full LDL reconstruction',L*D*L.T-block)
    return {'L':matrix_rows_json(L),'D':list(map(str,D.diagonal()))}


def physical_parent(coefficient_order):
    u,v,W,X,Y,Z=s.symbols('u v W X Y Z')
    coefficient=s.symbols(' '.join(coefficient_order))
    c={name:s.S.Zero for name in FULL_ORDER}
    c.update(dict(zip(coefficient_order,coefficient)))
    d,la,n,m,C,A,D,alpha,beta=[c[name] for name in FULL_ORDER]
    du,dv=1+u*u,1+v*v
    F=4*la*du*(W+v*X)**2+4*n*du*dv*X*X
    F+=4*m*(v*W-X+u*v*Y-u*Z)**2+4*C*dv*(u*W-Y)**2+4*A*du*dv*Y*Y
    F+=(4*D+2*d)*(u*W+u*v*X-Y-v*Z)**2
    F+=(4*alpha+2*d)*du*(v*Y-Z)**2+(4*beta+2*d)*dv*(X+u*Z)**2-2*d*du*dv*Z*Z
    return coefficient,(u,v,W,X,Y,Z),s.expand(F)


def verify_ramified_identity(family,data):
    c,vars,F=physical_parent(FAMILIES[family]['order'])
    ck('input_schema',family+' testing-only multiplier is exact',data['multiplier']=='(1+u)(1+v)')
    enlarged=s.expand((1+vars[0])*(1+vars[1])*F)
    targets=[s.Poly(s.diff(enlarged,var),*vars).as_dict() for var in c]
    targets += [{} for _ in range(data['auxiliary_count'])]
    terms=[defaultdict(lambda:s.S.Zero) for _ in data['variables']]
    for k,gi,gj,raw in data['entries']:
        ck('input_schema',family+' no affine constant entry',k>0)
        block=next(b for b in data['blocks'] if b['offset']<=gi<b['offset']+b['order'])
        b=block['index']
        ck('input_schema',family+' entries stay within their declared block',
           block['offset']<=gj<block['offset']+block['order'])
        if b==4:continue
        ii,jj=gi-block['offset'],gj-block['offset']
        st,p,q=data['features'][b][ii];st2,p2,q2=data['features'][b][jj]
        wu,wv=data['weights'][b]
        exponent=[p+p2+wu,q+q2+wv,0,0,0,0]
        exponent[2+st]+=1;exponent[2+st2]+=1
        terms[k-1][tuple(exponent)] += s.Rational(raw)*(1 if ii==jj else 2)
    for k,(actual,want) in enumerate(zip(terms,targets)):
        support=set(actual)|set(want)
        ck('full_parent_identities',f'{family} complete coefficient column {k}',
           all(actual.get(ex,0)==want.get(ex,0) for ex in support))
    signs={vars[0]:-vars[0],vars[4]:-vars[4],vars[5]:-vars[5]}
    equal('full_parent_identities',family+' exact Alice sign gauge',F.subs(signs,simultaneous=True)-F)
    signs={vars[1]:-vars[1],vars[3]:-vars[3],vars[5]:-vars[5]}
    equal('full_parent_identities',family+' exact Bob sign gauge',F.subs(signs,simultaneous=True)-F)


def enlarged_primal(family):
    data=json.loads((INPUTS/(family+'_ENLARGED_PRIMAL.coo.json')).read_text())
    verify_ramified_identity(family,data)
    sizes=[b['order'] for b in data['blocks']]+[1]*6
    labels=upper_labels(sizes);idx={label:i for i,label in enumerate(labels)}
    L=s.zeros(len(labels),len(data['variables']))
    for k,gi,gj,raw in data['entries']:
        block=next(b for b in data['blocks'] if b['offset']<=gi<b['offset']+b['order'])
        label=(block['index'],gi-block['offset'],gj-block['offset'])
        L[idx[label],k-1]+=s.Rational(raw)
    for i in range(1,7):L[idx[(4+i,0,0)],i]=1
    saved=json.loads((INPUTS/(family+'_ENLARGED_SLATER.json')).read_text())
    c=s.Matrix(list(map(s.Rational,saved['coefficient_values'])))
    blocks=[matrix_from_rows(rows) for rows in saved['grams']]
    blocks+=[s.Matrix([[c[0]]])]+[s.Matrix([[c[i]]]) for i in range(1,7)]
    target=s.Matrix([blocks[b][i,j] for b,i,j in labels])
    # The stored Gram is authoritative mathematical data; its old auxiliary
    # coordinates need not match the current COO parameterization.
    y,free=L[:,7:].gauss_jordan_solve(target-L[:,:7]*c)
    ck('strict_feasibility',family+' strict witness has unique current auxiliary coordinates',free.rows==0)
    witness=c.col_join(y)
    equal('strict_feasibility',family+' exact current-COO strict witness',L*witness-target)
    ck('strict_feasibility',family+' every original coefficient sign strictly positive',all(v>0 for v in c))
    factors=[certify_pd(family,block,i) for i,block in enumerate(blocks)]
    return {'sizes':sizes,'labels':labels,'L':L,'witness':witness,'factors':factors,
            'coefficient_order':FAMILIES[family]['order'],'auxiliary_names':data['variables'][7:]}


def closed_primal(family):
    order=FAMILIES[family]['order'];cv=s.symbols(' '.join(order));c=dict(zip(order,cv))
    d,n,C,A,D,beta=[c[k] for k in ('d','n','C','A','D','beta')]
    if family=='CF_ADJ':
        alpha=c['alpha'];z=s.symbols('s01 s02 s12')
        K0=s.diag(4*C+4*D+2*d,4*A,4*alpha)
        K2=s.diag(4*C,4*A+4*alpha+2*d,4*D)
        K1=s.Matrix([[0,0,-4*D-2*d],[0,0,-4*alpha-2*d],[-4*D-2*d,-4*alpha-2*d,0]])
        S=s.Matrix([[0,z[0],z[1]],[-z[0],0,z[2]],[-z[1],-z[2],0]])
        B=s.zeros(6);B[:3,:3]=K0;B[3:,3:]=K2
        B[:3,3:]=K1/2+S;B[3:,:3]=K1/2-S
        blocks=[B];sourcepoint={'d':1,'n':1,'C':2,'A':2,'D':1,'alpha':1,'beta':1}
        auxpoint=[0,0,0]
    else:
        m=c['m'];z=s.symbols('zeta',seq=True)
        pp,qq,rr=4*C+4*D+2*d,4*m+4*beta+2*d,4*D+2*d
        blocks=[s.Matrix([[4*m,-4*m,z[0]],[-4*m,qq+4*n,qq],[z[0],qq,qq]]),
                s.Matrix([[pp+4*A,4*D,-pp],[4*D,4*D,-4*m-rr-z[0]],[-pp,-4*m-rr-z[0],pp]])]
        sourcepoint={'d':1,'n':2,'m':1,'C':2,'A':2,'D':1,'beta':2}
        auxpoint=[-5]
    blocks += [s.Matrix([[v]]) for v in cv]
    sizes=[B.rows for B in blocks];labels=upper_labels(sizes);variables=(*cv,*z)
    expressions=s.Matrix([blocks[b][i,j] for b,i,j in labels])
    L=expressions.jacobian(variables)
    equal('closed_faces',family+' complete homogeneous affine coefficient map',L*s.Matrix(variables)-expressions)
    witness=s.Matrix([sourcepoint[name] for name in order]+auxpoint)
    evaluated=upper_to_blocks(L*witness,labels,sizes)
    factors=[certify_pd(family,block,i) for i,block in enumerate(evaluated)]
    return {'sizes':sizes,'labels':labels,'L':L,'witness':witness,'factors':factors,
            'coefficient_order':order,'auxiliary_names':list(map(str,z))}


def dualize(family,primal):
    L,labels=primal['L'],primal['labels']
    weights=s.diag(*[1 if i==j else 2 for b,i,j in labels])
    A=L.T*weights
    target=s.zeros(A.rows,7);target[:7,:]=s.eye(7)
    reduced,pivots=A.row_join(target).rref()
    ck('dualization',family+' full row rank and consistent arbitrary visible target',
       len(pivots)==A.rows and max(pivots)<A.cols)
    free=[i for i in range(A.cols) if i not in pivots]
    P=s.zeros(A.cols,7);N=s.zeros(A.cols,len(free))
    for row,pivot in enumerate(pivots):
        P[pivot,:]=reduced[row,A.cols:]
        for j,col in enumerate(free):N[pivot,j]=-reduced[row,col]
    for j,col in enumerate(free):N[col,j]=1
    equal('dualization',family+' all visible adjoint equations',A*P-target)
    equal('dualization',family+' all auxiliary adjoint equations',A*N)
    equal('dualization',family+' complete free-coordinate parameterization',N[free,:]-s.eye(len(free)))
    out={
        'family':family,'role':'EXACT_DUAL_OF_DECLARED_COEFFICIENT_CERTIFICATE_CONE',
        'canonical_quantum_converse_required':family in ('C1','C2'),
        'source_coefficient_order':primal['coefficient_order'],
        'source_auxiliary_names':primal['auxiliary_names'],
        'source_block_sizes':primal['sizes'],
        'upper_triangle_order':[list(label) for label in labels],
        'source_coefficient_matrix':coefficient_matrix_json(L),
        'source_strict_witness':list(map(str,primal['witness'])),
        'source_strict_LDL':primal['factors'],
        'trace_pairing_weights':[1 if i==j else 2 for b,i,j in labels],
        'dual_visible_part':coefficient_matrix_json(P),
        'dual_free_part':coefficient_matrix_json(N),
        'dual_free_rows':free,'eliminated_equations':A.rows,
        'dual_auxiliary_count':len(free),
        'interpretation':'Y=P*z+N*t; each block Y is PSD. Exactly L^*(Y)=(z,0).',
    }
    dump(OUT/(family+'_QUALIFIED_DUAL.json'),out)
    return {**primal,'P':P,'N':N,'free_rows':free,'A':A}


def validate_geometry(group):
    deterministic=[]
    for bits in range(16):
        aa=[1 if bits&(1<<i) else -1 for i in range(4)]
        deterministic.append(s.Matrix([1,*aa,aa[0]*aa[2],aa[0]*aa[3],aa[1]*aa[2],aa[1]*aa[3]]))
    prs=[]
    for bits in range(16):
        ee=[1 if bits&(1<<i) else -1 for i in range(4)]
        if s.prod(ee)==-1:prs.append(s.Matrix([1,0,0,0,0,*ee]))
    allvertices={tuple(v) for v in deterministic+prs}
    for g in group:
        M=signed_permutation_matrix(g)
        ck('bell_geometry','physical Bell action preserves all 24 nonsignaling vertices',
           {tuple(M*v) for v in deterministic+prs}==allvertices)
    PR=s.Matrix([1,0,0,0,0,1,-1,1,1])
    neighbors=[]
    for name in FULL_ORDER[1:]:
        matches=[v for v in deterministic if (H.T*v)[0]==0 and (EVENT_VECTORS[name].T*v)[0]==4]
        ck('bell_geometry','unique deterministic losing-event neighbor '+name,len(matches)==1)
        neighbors.append(matches[0])
    E=s.Matrix.vstack(PR.T,*[v.T for v in neighbors])
    equal('bell_geometry','exact nine-channel interpolation normalization',E*JFULL-s.diag(-1,*([4]*8)))
    ck('bell_geometry','original nine source coordinates are an affine basis',JFULL.det()!=0)


def orbit_records(group, all_canonical_frames=False):
    records=[]
    expected={'C1':128 if all_canonical_frames else 64,
              'C2':128 if all_canonical_frames else 64,'CF_ADJ':64,'CF_OPP':32}
    for family,definition in FAMILIES.items():
        seen=set();rows=[]
        for index,g in enumerate(group):
            M=signed_permutation_matrix(g)
            hs=tuple(M.T*H)
            omitted=tuple(sorted(tuple(M.T*EVENT_VECTORS[name]) for name in definition['omissions']))
            key=(hs,omitted)
            if key in seen and not (all_canonical_frames and family in ('C1','C2')):continue
            seen.add(key)
            J=M.T*source_map(family)
            rows.append({'family':family,'bell_group_index':index,'point_action':list(g),
                         'source_to_original_affine':matrix_rows_json(J),
                         'transformed_core':list(map(str,hs)),
                         'omitted_event_vectors':[list(map(str,v)) for v in omitted]})
        ck('bell_geometry',family+' exact orientation/omission orbit count',len(rows)==expected[family])
        records.extend(rows)
    cores=defaultdict(set)
    for rec in records:
        cores[tuple(rec['transformed_core'])].add(tuple(tuple(v) for v in rec['omitted_event_vectors']))
    ck('bell_geometry','all eight CHSH orientations represented',len(cores)==8)
    ck('bell_geometry','all 28 losing-event omission pairs in each orientation',
       all(len(v)==28 for v in cores.values()))
    return records


