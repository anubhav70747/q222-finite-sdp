#!/usr/bin/env python3
"""Compile a NEW enlarged outer pencil in the original eight coordinates.

The unchanged enlarged C1/C2 inputs certify (1+u)(1+v) times the
whole parent. Append all coefficient signs, retain128C1/64C2 maps,
add96 independently exact closed faces and16 original event rays.
Universality of the enlarged canonical certificate cones is OPEN.
"""
from pathlib import Path
from collections import defaultdict
import json,time
import sympy as s
import enlarged_compiler_core as c

HERE=Path(__file__).resolve().parent
OUT=HERE/'compiled_enlarged';OUT.mkdir(exist_ok=True)

def main():
    started=time.time();c.OUT=OUT;c.checks.clear()
    group=c.bell_group();c.validate_geometry(group)
    locals={}
    for family in c.FAMILIES:
        print('Compile enlarged canonical component',family,flush=True)
        primal=c.enlarged_primal(family) if family in ('C1','C2') else c.closed_primal(family)
        locals[family]=c.dualize(family,primal)
    records=[];seen=set()
    for rec in c.orbit_records(group,True):
        if rec['family']=='C2':
            key=(tuple(rec['transformed_core']),tuple(map(tuple,rec['omitted_event_vectors'])))
            if key in seen:continue
            seen.add(key)
        records.append(rec)
    counts={f:sum(rec['family']==f for rec in records) for f in c.FAMILIES}
    c.ck('enlarged_global_compilation','exact frame counts',counts=={'C1':128,'C2':64,'CF_ADJ':64,'CF_OPP':32})
    entries=[];blocks=[];components=[];matrix_offset=aux_offset=0
    for number,rec in enumerate(records):
        family=rec['family'];local=locals[family];J=c.matrix_from_rows(rec['source_to_original_affine'])
        original=local['P']*J.T;N=local['N']
        components.append({**rec,'component':number,'matrix_offset':matrix_offset,
                           'auxiliary_offset':aux_offset,'auxiliary_count':N.cols,'block_sizes':local['sizes']})
        offsets=[];offset=matrix_offset
        for size in local['sizes']:
            offsets.append(offset);blocks.append({'offset':offset,'order':size,'component':number});offset+=size
        for row,(b,i,j) in enumerate(local['labels']):
            gi,gj=offsets[b]+i,offsets[b]+j
            for k in range(9):
                if original[row,k]:entries.append([k,gi,gj,str(original[row,k])])
            for k in range(N.cols):
                if N[row,k]:entries.append([9+aux_offset+k,gi,gj,str(N[row,k])])
        matrix_offset=offset;aux_offset+=N.cols
    event_blocks=[]
    for x in range(2):
        for y in range(2):
            for a in (-1,1):
                for b in (-1,1):
                    vector=c.event_vector(a,b,x,y)
                    for k,v in enumerate(vector):
                        if v:entries.append([k,matrix_offset,matrix_offset,str(v)])
                    blocks.append({'offset':matrix_offset,'order':1,'component':'nonsignaling_event'})
                    event_blocks.append({'offset':matrix_offset,'event':[a,b,x,y],'affine_coefficients':list(map(str,vector))})
                    matrix_offset+=1
    c.ck('enlarged_global_compilation','evaluated dimensions13744,29920,2928',(matrix_offset,aux_offset,len(blocks))==(13744,29920,2928))
    pencil={
       'status':'EVALUATED_GLOBAL_OUTER_PENCIL_REVERSE_INCLUSION_OPEN',
       'quantum_forward_inclusion':True,'quantum_reverse_inclusion_proved':False,
       'quantum_reverse_inclusion_refuted':False,
       'conditional_exactness':'Sufficient: C1_physical = K1_enlarged + sigma1(K1_enlarged), and C2_physical = K2_enlarged. Neither equality is proved by this compiler.',
       'frame_selection':'Both C1 stabilizer frames are retained; one C2 frame per orientation/omission pair suffices under the stated whole-C2 coverage gate. No equality with an all128-C2 enlarged outer is assumed.',
       'visible_coordinates':c.Q_ORDER[1:],'visible_count':8,'auxiliary_count':aux_offset,'matrix_order':matrix_offset,
       'maximum_block_order':max(B['order'] for B in blocks),
       'coefficient_convention':'[k,i,j,value], upper triangle mirrored; k=0 constant, k=1..8 original visible coordinates, k=9+j auxiliary j.',
       'blocks':blocks,'entries':entries,
       'source_geometry':'128 C1 frames,64 C2 frames,64 adjacent and32 opposite exact closed faces,16 original nonsignaling event inequalities.',
    }
    c.dump(OUT/'GLOBAL_CANONICAL_OUTER_PENCIL.coo.json',pencil)
    c.dump(OUT/'GLOBAL_SOURCE_MAPS.json',{
       'original_affine_order':c.Q_ORDER,'full_canonical_order':c.FULL_ORDER,'full_source_map':c.matrix_rows_json(c.JFULL),
       'event_convention':'Each event column is4p(a,b|x,y).',
       'canonical_maps':{f:{'order':d['order'],'matrix':c.matrix_rows_json(c.source_map(f)),'omissions':d['omissions']} for f,d in c.FAMILIES.items()},
       'bell_group_actions':[list(g) for g in group],'components':components,'nonsignaling_event_blocks':event_blocks})
    inputs=[c.INPUTS/(f+'_ENLARGED_PRIMAL.coo.json') for f in ('C1','C2')]
    inputs += [c.INPUTS/(f+'_ENLARGED_SLATER.json') for f in ('C1','C2')]
    inputs += [c.INPUTS/name for name in ('physical_core.tex','closed_faces_short.tex','finite_contact_source_reduction_REDERIVED.tex')]
    outputs=[OUT/(f+'_QUALIFIED_DUAL.json') for f in c.FAMILIES]+[OUT/'GLOBAL_SOURCE_MAPS.json',OUT/'GLOBAL_CANONICAL_OUTER_PENCIL.coo.json']
    receipt={'status':'PASS_EXACT_ENLARGED_GLOBAL_OUTER_COMPILATION',
       'global_reverse_inclusion_proved':False,
       'groups':[{'name':k,'assertion_count':len(v),'assertions':v} for k,v in c.checks.items()],
       'no_completeness_total':'These exact algebra assertions do not prove a missing canonical or global converse.',
       'matrix_order':matrix_offset,'auxiliary_count':aux_offset,'block_count':len(blocks),'coo_entry_count':len(entries),'orbit_counts':counts,
       'inputs':[{'path':str(p.relative_to(HERE)),'sha256':c.digest(p)} for p in inputs],
       'outputs':[{'path':str(p.relative_to(HERE)),'sha256':c.digest(p),'bytes':p.stat().st_size} for p in outputs],
       'code':[{'path':p.name,'sha256':c.digest(p)} for p in (Path(__file__),HERE/'enlarged_compiler_core.py')],
       'seconds':time.time()-started}
    c.dump(OUT/'GLOBAL_COMPILATION_RECEIPT.json',receipt)
    print(json.dumps({k:receipt[k] for k in ('status','matrix_order','auxiliary_count','block_count','coo_entry_count','orbit_counts','seconds')}))

if __name__=='__main__':main()
