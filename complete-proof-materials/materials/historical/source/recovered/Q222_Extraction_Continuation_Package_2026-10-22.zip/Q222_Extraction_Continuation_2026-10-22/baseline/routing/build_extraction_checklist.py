#!/usr/bin/env python3
"""Emit a scoped remaining checklist; never infer theorem closure from a PASS.

The root proof package contains the sibling cap-reduction and normalized
dual-gate components.  Paths in this checklist are relative to that package
root.  This script hashes evidence but performs no new mathematical replay.
"""
from pathlib import Path
import hashlib,json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def evidence(paths):
    out=[]
    for path in paths:
        p=ROOT/path
        out.append({'path':path,'availability':'AVAILABLE' if p.exists() else 'NOT_YET_FROZEN',
                    **({'sha256':sha(p),'bytes':p.stat().st_size} if p.exists() else {})})
    return out
items=[]
def item(ID,title,status,criterion,what_remains,paths,depends=(),category='REQUIRED'):
    items.append({'id':ID,'title':title,'status':status,'acceptance_criterion':criterion,
                  'current_scope_or_remaining_work':what_remains,'depends_on':list(depends),
                  'category':category,'evidence':evidence(paths)})

item('T1','Exact physical target and visible coordinates','FIXED',
     'The full finite-dimensional tensor-product Q222 with shared randomness, arbitrary states and all binary measurement endpoints, in the eight coordinates (a0,a1,b0,b1,E00,E01,E10,E11).',
     'No zero-marginal, symmetric, fixed-angle or single-contact restriction may replace this target.',
     ['routing/inputs/physical_core.tex','routing/inputs/finite_contact_source_reduction_REDERIVED.tex'])
item('S1','Exact original nine-source dictionary','PROVED_RETAINED_AND_REPLAYED',
     'Verify the full Pauli parent, all eight event columns4p, signed CHSH core, source signs and original9-to-canonical7 maps.',
     'Complete. New enlarged readback reconstructs the physical operators independently.',
     ['routing/inputs/physical_core.tex','routing/CHECK_ENLARGED_GLOBAL_COMPILER.json'],['T1'])
item('S2','Exhaustive support-cone generation','PROVED_RETAINED',
     'Every physical affine support is a finite conic sum of events, exact noncoercive closed-face sources, and C1/C2 sources, with all literal zeros preserved.',
     'SE11–SE15 proves the finite extreme-source reduction and genuine finite-contact entry. The compiler retains96 exact closed faces explicitly; no generic-density assumption is used here.',
     ['routing/inputs/finite_contact_source_reduction_REDERIVED.tex','routing/inputs/physical_core.tex','routing/inputs/closed_faces_short.tex'],['S1'])
item('S3','Event and closed-face source lifts','PROVED_AND_COMPILED',
     'Retain all16 original event inequalities and the exact64 adjacent/32 opposite closed faces, including every coefficient-zero boundary.',
     'Complete for the new candidate; the exact source matrices, strict points and qualified dualizations are verified.',
     ['routing/inputs/closed_faces_short.tex','routing/compiled_enlarged/CF_ADJ_QUALIFIED_DUAL.json','routing/compiled_enlarged/CF_OPP_QUALIFIED_DUAL.json','routing/CHECK_ENLARGED_GLOBAL_COMPILER.json'],['S1'])
item('R1','Old two-frame C1 and old global candidates','REFUTED_RETIRED',
     'Do not attempt to close the false old gates C1=R1+sigma(R1), Q222=O8368 or Q222=O10736.',
     'The exact common separator has value−1 at a physical rank-eight extreme ray. All288/352 current maps leave only its two excluded C1 frames. Closedness and normalization prove both global pencils strictly outer. Frozen earlier files are preserved as historical records.',
     ['routing/current_global_candidate_correction.tex','routing/REMEMBERED_RAY_GLOBAL_TRANSFER.json','c1/two_frame_correction.tex','c1/CHECK_TWO_FRAME_CORRECTION.json'],category='RETIRED_ROUTE')
item('F1','Evaluated enlarged fixed testing features','CANDIDATE_DATA_COMPLETE',
     'Specify every source-independent testing function and legal testing-only denominator, with all real signs and projective endpoints.',
     'Complete feature lists are supplied by the enlarged arrays. Their normalized features divide by sqrt((1+u)(1+v)(1+u²)(1+v²)) times the state norm. Their universal adequacy is a separate open gate.',
     ['routing/inputs/C1_ENLARGED_PRIMAL.coo.json','routing/inputs/C2_ENLARGED_PRIMAL.coo.json','routing/enlarged_global_candidate.tex'])
item('F2','Whole-parent identity and complete affine matching','PROVED_AND_REPLAYED',
     'Verify (1+u)(1+v) times the full parent in all7 source and302 auxiliary directions, all source signs, and the entire affine matching space.',
     'Complete. Each family has450 Gram coordinates,148 independent monomial bins and matching dimension309=7+302. This is full coefficient matching, not universal PSD feasibility.',
     ['routing/enlarged_global_candidate.tex','routing/check_enlarged_global_compiler.py','routing/CHECK_ENLARGED_GLOBAL_COMPILER.json'],['F1','S1'])
item('F3','Closedness and exact dual qualification','PROVED_AND_REPLAYED',
     'Prove actual candidate closedness and exact attained trace-adjoint duality, rather than assume every SDP projection is closed.',
     'Positive finite evaluation moments bound all Gram witnesses. Exact strict source points qualify the dual. Both canonical duals have148 auxiliaries after all seven sign blocks are retained.',
     ['routing/enlarged_global_candidate.tex','routing/CHECK_ENLARGED_GLOBAL_COMPILER.json','routing/compiled_enlarged/C1_QUALIFIED_DUAL.json','routing/compiled_enlarged/C2_QUALIFIED_DUAL.json'],['F2'])
item('B1','C1 regular-cap and all-boundary reduction','PROVED_SCOPED_REDUCTION',
     'Prove the precise regular positive-event contact domain is dense in the sharp cap and that closedness plus event addition covers all zero/event/angle/state boundaries; justify the two-orientation disjunction by extremality.',
     'CG1–CG18 proves the finite analytic cap, genuine dense regular entry, regular-ray extremality, actual closedness and every boundary limit. The two-orientation universal PSD choice CG18 remains open.',
     ['c1/c1_regular_contact_reduction.tex','c1/C1_REGULAR_CONTACT_DOMAIN.json','c1/CHECK_C1_REGULAR_CONTACT_REDUCTION.json','routing/C1_REGULAR_GATE_ANALYTICAL_REVIEW.json'],['F3','S1'])
item('B2','C2 regular-cap and all-boundary reduction','PROVED_SCOPED_REDUCTION',
     'For a closed sound cone containing event rays, prove whole C2 coverage is equivalent to coverage of every theta in the exact regular domain GR9.',
     'GR1–GR17 proves sharp-cap existence, analytic/dense regular entry, and all boundary limits. The universal PSD choice GR17 remains open.',
     ['c2/c2_regular_contact_reduction.tex','c2/check_c2_regular_contact_reduction.json','routing/C2_REGULAR_GATE_ANALYTICAL_REVIEW.json'],['F3','S1'])
item('D1','Finite exact dual failure systems','PROVED_DECISION_REFORMULATION_ONLY',
     'Print actual rational dual trace rows, all42 contact polynomials per family, nonzero-minor guards and exact failure predicates.',
     'Complete finite input. Each trace-one dual base has457 coordinates,302 independent auxiliary equations and affine dimension154. The base is compact and strict. Neither failure system has been proved empty.',
     ['normalized_dual_gate.tex','dual_gate/C1_NORMALIZED_DUAL_FAILURE_SYSTEM.json','dual_gate/C2_NORMALIZED_DUAL_FAILURE_SYSTEM.json','dual_gate/CHECK_NORMALIZED_DUAL_GATE.json','routing/NORMALIZED_DUAL_GATE_INDEPENDENT_REVIEW.json'],['F3','B1','B2'])
item('G1','Universal enlarged C1 compatibility','OPEN',
     'For every regular C1 source, at least one complete enlarged orientation has a PSD Gram. Equivalently prove the two-negative-dual-objective failure system F1 empty. Via B1 this gives C1=K1+sigma(K1).',
     'Required exact result: universal primal selectors on an exhaustive finite algebraic cover, or a verified real-algebraic emptiness certificate. A finite sample, one repaired point, fixed-sector result or exact zero contact objective does not pass this gate.',
     ['normalized_dual_gate.tex','dual_gate/C1_NORMALIZED_DUAL_FAILURE_SYSTEM.json'],['B1','D1'])
item('G2','Universal enlarged C2 compatibility','OPEN',
     'For every regular C2 source, its complete enlarged Gram fiber contains a PSD point. Equivalently prove failure system F2 empty. Via B2 this gives C2=K2.',
     'Required exact result: a universal selector/exhaustive cover or exact failure-system emptiness proof. The full regular contact fiber has250 free variables; testing a fixed free-coordinate menu is not a substitute.',
     ['c2/c2_regular_contact_reduction.tex','normalized_dual_gate.tex','dual_gate/C2_NORMALIZED_DUAL_FAILURE_SYSTEM.json'],['B2','D1'])
item('A1','New global original-coordinate compilation','CANDIDATE_DATA_COMPLETE',
     'Emit every affine matrix coefficient with explicit original8 visible coordinates, all auxiliaries, all required Bell frames, events and closed faces.',
     'Complete evaluated candidate: N13744, m29920,2928 PSD blocks, max block15,153248 rational upper-COO entries. Counts describe an outer candidate until G1/G2 or another full reverse proof succeeds.',
     ['routing/enlarged_global_candidate.tex','routing/compiled_enlarged/GLOBAL_CANONICAL_OUTER_PENCIL.coo.json','routing/compiled_enlarged/GLOBAL_SOURCE_MAPS.json','routing/compiled_enlarged/GLOBAL_COMPILATION_RECEIPT.json'],['S2','S3','F3'])
item('A2','Independent exact matrix readback','PROVED_AND_REPLAYED',
     'Read actual emitted arrays without importing the compiler; verify all original/source maps, literal sign blocks, strict witnesses, trace transposes/factor2, eliminated equations, offsets and coefficients.',
     'Complete for the new candidate. Independent2192-check receipt is scoped to these algebraic identities and does not certify G1 or G2.',
     ['routing/check_enlarged_global_compiler.py','routing/CHECK_ENLARGED_GLOBAL_COMPILER.json'],['A1'])
item('A3','Quantum forward inclusion','PROVED',
     'For every physical behavior, construct or qualify feasible dual blocks in the exact new original-coordinate pencil, including endpoints and convex mixtures.',
     'Whole-parent soundness, attained dualization and finite physical Bell relabelings prove Q222 is contained in O13744.',
     ['routing/enlarged_global_candidate.tex','routing/inputs/physical_core.tex','routing/CHECK_ENLARGED_GLOBAL_COMPILER.json'],['A1','F2','F3'])
item('A4','Global reverse inclusion','OPEN_CONDITIONAL',
     'Prove every projected feasible point of the new pencil is a physical quantum behavior.',
     'S2 and both universal gates G1/G2 would identify the compiled source sum with the full physical support cone, giving the reverse inclusion. This conditional assembly is proved; its universal premises are not.',
     ['routing/enlarged_global_candidate.tex','routing/inputs/finite_contact_source_reduction_REDERIVED.tex'],['S2','S3','G1','G2','A1'])
item('ALT','Different adequate common feature space or exact pencil','AVAILABLE_ALTERNATIVE_NOT_COMPLETED',
     'Alternatively supply a different finite common source-independent feature list with full universal certificates, or another evaluated pencil with both inclusions, then compile and verify all coefficients.',
     'This is an alternative to G1/G2, not an extra mandatory gate. Qualitative tensor-SOS existence and an effective enumeration/QE scheme do not by themselves evaluate a size or matrix list. Failure of the old candidate is not nonexistence of finite lifts.',
     ['routing/current_global_candidate_correction.tex'],category='ALTERNATIVE_ROUTE')

aggregates=[
 {'id':'E1','original_acceptance_criterion':'An evaluated global feature list with proved universal adequacy.',
  'status':'INCOMPLETE','closed_part':'The enlarged finite testing lists and complete coefficient maps are evaluated.',
  'missing_part':'Universal adequate PSD coverage G1 and G2, or a complete alternative feature construction.'},
 {'id':'E2','original_acceptance_criterion':'Actual affine coefficient matrices and projection in the original eight coordinates.',
  'status':'CANDIDATE_DATA_DELIVERED_FULL_SET_ACCEPTANCE_INCOMPLETE',
  'closed_part':'Every entry of the new N13744/m29920 candidate and its original-coordinate projection is delivered and independently read back.',
  'missing_part':'The delivered matrices are not yet proved exact for Q222; they cannot be called an extracted exact lift before A4.'},
 {'id':'E3','original_acceptance_criterion':'Both inclusions and executable coefficient data.',
  'status':'INCOMPLETE','closed_part':'Executable coefficient data, forward inclusion and exact qualified dualization are complete.',
  'missing_part':'Global reverse inclusion A4, dependent on the two universal gates or an alternative full proof.'}
]

out={'title':'Precise remaining finite-lift extraction checklist','date':'2026-10-22',
     'overall_status':'INCOMPLETE_UNIVERSAL_ENLARGED_SOURCE_COVERAGE_OPEN',
     'path_base':'finite_lift_checklist_2026-10-22 package root',
     'parent_release_checklist':'CHECKLIST.json is the primary release checklist; this file gives its detailed technical source/extraction dependency breakdown.',
     'central_open_gates':['G1','G2'],
     'status_rule':'No completion percentage is formed. Exact identity checks, scope reductions, and universal theorems are distinct gates.',
     'correction':'N8368 andN10736 are now rigorously refuted as exact Q222 lifts. Their earlier files remain immutable; old open-status prose is historical.',
     'live_candidate':{'N':13744,'m':29920,'blocks':2928,'maximum_block_order':15,'rational_COO_records':153248,
                       'role':'EVALUATED_OUTER_CANDIDATE_ONLY','reverse_inclusion_proved':False},
     'route_logic':'(G1 AND G2 AND the proved assembly infrastructure) OR a fully proved alternative finite feature/pencil route. Printing either route or a decision formula is not completion.',
     'items':items,'original_extraction_criteria':aggregates,
     'additional_scoped_completed_results':[
       {'id':'C2-FIXED-SECTOR','status':'COMPLETE_AT_STATED_SECTOR',
        'scope':'The entire physical canonical C2 sector D=m, alpha=C, including literal zero faces, has the evaluated SF1–SF12 lift with PSD blocks4 and5 and nine auxiliaries. Total order18 in the original seven source coordinates, or14 in five independent sector coordinates.',
        'acceptance_attribution':'The C2 workstream supplies the exact642-check receipt; the root independently reviewed the proof and its primary theorem input. This routing entry records that scoped result and does not claim an additional independent sector replay.',
        'does_not_close':['G2','A4','E1','E3'],
        'evidence':evidence(['c2/c2_reciprocal_fixed_sector.tex','c2/C2_RECIPROCAL_FIXED_SECTOR.coo.json','c2/check_c2_reciprocal_fixed_sector.py','c2/check_c2_reciprocal_fixed_sector.json'])}],
     'priority_execution':['Attack the actual full enlarged regular Gram fibers or exact normalized-dual failure systems. Prove a universal selector/emptiness certificate or obtain a rigorously separated negative witness.','If both enlarged gates succeed, apply the already proved source/closed-face assembly and then freeze a new exact-pencil label with its complete coefficients.','If an enlarged gate fails, retain that exact obstruction and switch to a different common finite feature construction or an independently exact global pencil.'],
     'prohibited_shortcuts':['Do not reuse the false old two-frame adequacy statement.','Do not convert determinant-SOS or a mixed-multiplier certificate into full-parent adequacy without a valid descent proof.','Do not use generic-contact density without its proved cap/closedness argument.','Do not identify full linear coefficient compatibility with PSD feasibility.','Do not count finite sampling, a near-zero numerical margin or a contact dual value zero as a universal certificate.','Do not treat all local tensor-SOS witnesses as a fixed globally adequate feature list without an actual uniform extraction.']}
(HERE/'REMAINING_EXTRACTION_CHECKLIST.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'status':out['overall_status'],'items':len(items),'aggregate_criteria':[a['id'] for a in aggregates],
                  'missing_evidence':[e['path'] for x in items for e in x['evidence'] if e['availability']!='AVAILABLE']},indent=2))
