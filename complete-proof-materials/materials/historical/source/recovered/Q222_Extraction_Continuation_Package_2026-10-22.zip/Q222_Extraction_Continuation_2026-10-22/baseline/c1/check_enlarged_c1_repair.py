#!/usr/bin/env python3
"""Fresh exact C1-only replay of the recovered order-59 repair.

Uses only SymPy and the standard library.  Checks actual affine directions,
the saved rational PSD witness, constructive old-frame inclusion, and the
302-by-7 explicit repaired-chamber selector.  No global converse is asserted.
"""
from pathlib import Path
from itertools import product
import hashlib
import json
import sympy as s

R = Path(__file__).resolve().parent
tests=[]
def ck(x,label):
    if not bool(x): raise AssertionError(label)
    tests.append(label)
def read(name): return json.loads((R/'inputs'/name).read_text())
def mat(rows): return s.Matrix([[s.Rational(x) for x in row] for row in rows])
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def blocks(d,values):
    out=[s.zeros(b['order']) for b in d['blocks']]
    where={i:(g,i-b['offset']) for g,b in enumerate(d['blocks'])
           for i in range(b['offset'],b['offset']+b['order'])}
    for k,i,j,a in d['entries']:
        g,ii=where[i];gg,jj=where[j]
        ck(g==gg,'every COO record stays in its block')
        term=s.Rational(a)*(1 if k==0 else values[k-1])
        out[g][ii,jj]+=term
        if i!=j: out[g][jj,ii]+=term
    return out

d=read('C1_ENLARGED_PRIMAL.coo.json')
old=read('C1_RAMIFIED_PRIMAL.coo.json')
cert=read('C1_REPAIRED_TWO_FRAME_COUNTEREXAMPLE.json')
sep=read('C1_SATURATED_CONE_SEPARATOR.json')
maps=read('C1_OLD_FRAME_INCLUSION.json')['maps']
ch=read('C1_REPAIRED_CHAMBER_AUXILIARY_MAP.json')
ck(d['matrix_order']==59 and d['visible_count']==7 and d['auxiliary_count']==302,
   'order59 and 302 genuine affine auxiliaries')
ck([b['order'] for b in d['blocks']]==[14,15,14,15,1], 'exact retained block orders')
ck(d['weights']==[[0,0],[0,1],[1,0],[1,1]], 'quadrant parity weights')
ck(cert['coefficients']==sep['coefficients'], 'exact same previously excluded source')
cc=list(map(s.Rational,cert['coefficients']))

# Independently reconstructed Pauli parent.
u,v=s.symbols('u v',real=True);I=s.eye(2);Z=s.diag(1,-1);X=s.Matrix([[0,1],[1,0]])
A=[Z,((1-u*u)*Z+2*u*X)/(1+u*u)]
B=[Z,((1-v*v)*Z+2*v*X)/(1+v*v)]
k=s.kronecker_product
H=s.eye(4)-(k(A[0],B[0])-k(A[0],B[1])+k(A[1],B[0])+k(A[1],B[1]))/2
ev=[(1,1,1,-1),(1,0,-1,1),(0,0,-1,1),(1,1,-1,1),(0,1,-1,-1),(1,0,1,-1)]
Pb=[((1+u*u)*(1+v*v)*M).applyfunc(lambda z:s.cancel(z).expand())
    for M in [H]+[k(I+a*A[x],I+b*B[y]) for x,y,a,b in ev]]
target=[((1+u)*(1+v)*P).applyfunc(s.expand) for P in Pb]
got=[{} for _ in range(310)]
where={i:(g,i-b['offset']) for g,b in enumerate(d['blocks'])
       for i in range(b['offset'],b['offset']+b['order'])}
for var,i,j,value in d['entries']:
    g,ii=where[i];gg,jj=where[j]
    ck(g==gg,'generic record block consistency')
    if g==4:
        ck(var==1 and ii==jj==0 and s.Rational(value)==1,'exact d scalar')
        continue
    si,a,b=d['features'][g][ii];sj,c,e=d['features'][g][jj]
    al,be=d['weights'][g]
    key=(si,sj,a+c+al,b+e+be)
    got[var][key]=got[var].get(key,0)+s.Rational(value)
    if i!=j:
        key=(sj,si,a+c+al,b+e+be)
        got[var][key]=got[var].get(key,0)+s.Rational(value)
for var,raw in enumerate(got):
    raw={key:value for key,value in raw.items() if value}
    want={}
    if 1<=var<=7:
        for i,j in product(range(4),repeat=2):
            for (a,b),value in s.Poly(target[var-1][i,j],u,v).terms():
                if value: want[i,j,a,b]=value
    ck(raw==want,f'entire multiplier parent in affine direction {var}')

# The 302 exported auxiliaries are the complete matching kernel.
full=[(i,a,b) for i in range(4) for a,b in product(range(2),repeat=2)]
pairs=[(g,i,j) for g in range(4) for i in range(16) for j in range(i,16)]
groups={}
for col,(g,i,j) in enumerate(pairs):
    si,a,b=full[i];sj,c,e=full[j];al,be=d['weights'][g]
    key=(min(si,sj),max(si,sj),a+c+al,b+e+be)
    groups.setdefault(key,[]).append(col)
zero=set()
while True:
    active={n for n,(g,i,j) in enumerate(pairs) if (g,i) not in zero and (g,j) not in zero}
    new=set()
    for key,cols in groups.items():
        cols=[n for n in cols if n in active]
        i,j,a,b=key
        absent=all(s.Poly(T[i,j],u,v).coeff_monomial(u**a*v**b)==0 for T in target)
        if absent and cols and all(pairs[n][1]==pairs[n][2] for n in cols):
            new.update((pairs[n][0],pairs[n][1]) for n in cols)
    if new<=zero: break
    zero|=new
rank=sum(any(n in active for n in cols) for cols in groups.values())
ck(rank==148 and len(active)==450 and len(active)-rank==302,
   'disjoint coefficient supports give full rank148 and nullity302')
ck(sorted(zero)==list(map(tuple,d['removed_full_features'])), 'exact forced zero-row closure')
ck([[list(full[i]) for i in range(16) if (g,i) not in zero] for g in range(4)]==d['features'],
   'entire degree-bounded retained feature frame')
for j,(g,i,k) in enumerate(d['free_positions']):
    off=d['blocks'][g]['offset']
    terms=[(var,s.Rational(value)) for var,ii,kk,value in d['entries']
           if ii==off+i and kk==off+k]
    ck(terms==[(8+j,s.Integer(1))],f'auxiliary{j} is its actual free Gram entry')

# Exact source certificate in the literal exported affine coordinates.
yy=list(map(s.Rational,cert['auxiliary_values']))
ck(len(yy)==302,'all302 saved auxiliary entries present')
gg=blocks(d,cc+yy)
ranks=[]
for g,(Q,raw,f) in enumerate(zip(gg[:4],cert['grams'],cert['rational_PSD_factorizations'])):
    F=mat(f['factor']);DD=list(map(s.Rational,f['positive_diagonal']))
    ck(all(z>0 for z in DD),f'block{g} has strictly positive rational diagonal factor')
    ck(F*s.diag(*DD)*F.T==Q==mat(raw),f'block{g} actual COO and full rational PSD factor agree')
    ck(F.rank()==Q.rows-1,f'block{g} exact contact rank')
    ranks.append(Q.rows-1)
ck(gg[4]==s.ones(1),'source deficit scalar equals1')
P=sum((z*T for z,T in zip(cc,Pb)),s.zeros(4))
p,q=map(s.Rational,cert['contact_parameters'][:2]);psi=s.Matrix(list(map(s.Rational,cert['contact_state'])))
ck(P.subs({u:p,v:q})*psi==s.zeros(4,1),'same original full kernel')
for t in (u,v): ck((psi.T*P.diff(t).subs({u:p,v:q})*psi)[0]==0,'same original angular stationarity')
ell=list(map(s.Rational,sep['common_separator']))
ck(sum(a*b for a,b in zip(ell,cc))==-1,'repaired source still strictly excluded from old two-frame cone')

# Constructive R1 subset K1: multiplying by 1,u,v,uv relocates each old square.
covered=[set() for _ in range(4)]
ck(sorted((x['old_sector'],*x['factor']) for x in maps)
   ==sorted((g,a,b) for g in range(4) for a,b in product(range(2),repeat=2)),
   'all16 old-square multiplier maps, each exactly once')
for item in maps:
    g,ng=item['old_sector'],item['new_sector'];E=mat(item['embedding'])
    a,b=item['factor'];al,be=old['weights'][g];nal,nbe=d['weights'][ng]
    ck(E.cols==len(old['features'][g]) and E.rows==len(d['features'][ng]),'inclusion map dimensions')
    for j,(state,x,y) in enumerate(old['features'][g]):
        nz=[i for i in range(E.rows) if E[i,j]]
        ck(len(nz)==1 and E[nz[0],j]==1,'inclusion column is a coordinate vector')
        i=nz[0];si,xx,yy=d['features'][ng][i]
        ck(si==state and 2*xx+nal==2*x+al+a and 2*yy+nbe==2*y+be+b,
           'inclusion respects exact squared monomial and weight')
        covered[ng].add(i)
ck(all(len(a)==len(b) for a,b in zip(covered,d['features'])), 'old inclusions cover every new row')

# Explicit all-source linear selector on W={d>=0, c_i>=d*c*_i}.
AA=mat(ch['auxiliary_matrix'])
evy=[s.Matrix(list(map(s.Rational,row))) for row in ch['event_auxiliary_vectors']]
ys=s.Matrix(list(map(s.Rational,cert['auxiliary_values'])))
ck(AA.shape==(302,7),'chamber selector is a302-by7 rational matrix')
ck(AA[:,0]==ys-sum((cc[i+1]*evy[i] for i in range(6)),s.zeros(302,1)),
   'exact deficit column of affine chamber selector')
events=[x for x in read('EVENT_RAY_CERTIFICATES.json') if x['family']=='C1']
for i,(e,yvec) in enumerate(zip(events,evy)):
    ck(e['event']==d['variables'][i+1],'event-ray visible order')
    ck(AA[:,i+1]==yvec,'exact event column of affine chamber selector')
    oldG=blocks(old,list(map(s.Rational,e['coefficient_values']+e['auxiliary_values'])))[:4]
    roots=[s.Matrix(list(map(s.Rational,z))) for z in e['rank_one_vectors_00']]
    ck(oldG[0]==sum((z*z.T for z in roots),s.zeros(14))
       and all(G==s.zeros(G.rows) for G in oldG[1:]),'actual old event Gram has explicit positive rank-one factors')
    newG=[s.zeros(len(f)) for f in d['features']]
    for item in maps:
        E=mat(item['embedding']);newG[item['new_sector']]+=E*oldG[item['old_sector']]*E.T
    cv=[s.Integer(j==i+1) for j in range(7)]
    ck(blocks(d,cv+list(yvec))[:4]==newG,'literal new event auxiliary vector equals positive embedded old Gram')

inputs=['C1_RAMIFIED_PRIMAL.coo.json','C1_SATURATED_CONE_SEPARATOR.json',
        'C1_ENLARGED_PRIMAL.coo.json','C1_REPAIRED_TWO_FRAME_COUNTEREXAMPLE.json',
        'C1_REPAIRED_CHAMBER_AUXILIARY_MAP.json','C1_OLD_FRAME_INCLUSION.json',
        'EVENT_RAY_CERTIFICATES.json']
report={'status':'PASS','exact_checks':len(tests),'checks':tests,
        'claim':'The same exactly separated C1 source belongs to the recovered order59 multiplier cone K1; all old R1 is contained in K1; the printed affine selector certifies the full-dimensional monotone chamber.',
        'global_reverse_inclusion':'UNPROVED: no assertion C1=K1 or C1=K1+sigma(K1).',
        'matrix_order':59,'auxiliary_count':302,'nontrivial_block_orders':[14,15,14,15],
        'source_gram_ranks':ranks,'coefficient_matching_rank':148,
        'source':cert['coefficients'],'contact_parameters':cert['contact_parameters'],
        'contact_state':cert['contact_state'],'old_two_frame_pairing':'-1',
        'chamber_conditions':'d>=0 and c_i>=d*c*_i for i=1,...,6',
        'inputs':{p:sha(R/'inputs'/p) for p in inputs},'checker_sha256':sha(Path(__file__).resolve())}
(R/'CHECK_ENLARGED_C1_REPAIR.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS',len(tests),'exact checks; order59 repair and explicit monotone chamber; global converse UNPROVED')
