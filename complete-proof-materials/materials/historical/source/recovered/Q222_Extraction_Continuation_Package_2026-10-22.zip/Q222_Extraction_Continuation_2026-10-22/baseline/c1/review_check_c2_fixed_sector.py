#!/usr/bin/env python3
"""Independent whole-parent/pencil check of the sibling C2 fixed-sector lift.

This consumer reconstructs the univariate target from the complete parent,
reads the actual COO, and checks the projection and full affine matching.
The analytical converse uses the separately reviewed matrix factor theorem.
"""
from pathlib import Path
from itertools import product,permutations
import hashlib,json
import sympy as s
R=Path(__file__).resolve().parent;peer=R.parent/'c2';checks=[]
def ck(x,name):
    if not bool(x):raise AssertionError(name)
    checks.append(name)
def z(x):return s.cancel(x)==0
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

u,v,W,X,Y,Z,S,T=s.symbols('u v W X Y Z S T',real=True)
d,n,m,C,A,D,alpha=s.symbols('d n m C A D alpha',real=True)
cs=[d,n,m,C,A,D,alpha];Du,Dv=1+u*u,1+v*v
full=n*Du*Dv*X*X+m*(v*W-X+u*v*Y-u*Z)**2+C*Dv*(u*W-Y)**2+A*Du*Dv*Y*Y\
 +(D+d/2)*(u*W+u*v*X-Y-v*Z)**2+(alpha+d/2)*Du*(v*Y-Z)**2\
 +d*Dv*(X+u*Z)**2/2-d*Du*Dv*Z*Z/2
sector=s.expand(full.subs({D:m,alpha:C}))
curve=s.cancel(u*u*sector.subs({v:1/u,W:S+T,Z:S-T})).expand()
qT=(1+u*u)*((2*C+d+2*m)*u*u+2*m)
reduced=s.expand(curve-qT*T*T)
ck(not reduced.has(T),'entire curve parent splits off the exact nonnegative T square')
M=s.hessian(sector,[W,X,Y,Z])/2
P3=s.hessian(reduced,[S,X,Y])/2
J3=s.diag(1,-1,-1)
ck((P3.subs(u,-u)-J3*P3*J3).applyfunc(s.expand)==s.zeros(3),'entire reduced state matrix has declared parity')
ck(all(s.Poly(a,u).degree()<=4 for a in P3 if a),
   'complete reduced matrix degree at most4')

# Independent full determinant projection.  No saved Laurent coefficient data.
dd=s.Poly(0,u,v,d,n,m,C,A,domain=s.QQ)
mp=[[s.Poly(M[i,j],u,v,d,n,m,C,A,domain=s.QQ) for j in range(4)] for i in range(4)]
for perm in permutations(range(4)):
    term=s.Poly((-1)**sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4)),u,v,d,n,m,C,A,domain=s.QQ)
    for i,j in enumerate(perm):term*=mp[i][j]
    dd+=term
Q=s.cancel(dd.as_expr()/(Du**2*Dv**2))
r,t=s.symbols('r t',positive=True)
laurent=0
for (i,j),value in s.Poly(Q,u,v).terms():
    ck(i%2==0 and j%2==0,'generic sector determinant only uses squared angles')
    laurent+=value*(r*t)**(i//2-1)*(r/t)**(j//2-1)
a0=A*C*(2*m+d+2*n)*(2*C+d+2*m)/4
b0=C*m*(d+2*n)*(2*A+2*C+d+2*m)/4
ck(z(laurent-laurent.subs(r,1)-(r+1/r-2)*(a0*t+b0/t)),
   'SF5 exact all-source determinant projection to reciprocal curve')
ck(all(x>0 for x in s.Poly(a0,d,n,m,C,A).coeffs()) and all(x>0 for x in s.Poly(b0,d,n,m,C,A).coeffs()),
   'projection coefficients nonnegative on every coefficient-zero face')

# Literal delivered original-coordinate18-order affine pencil.
path=peer/'C2_RECIPROCAL_FIXED_SECTOR.coo.json';data=json.loads(path.read_text())
xx=list(s.symbols('x1:10',real=True));values=cs+xx;big=s.zeros(18)
for variable,i,j,coef in data['entries']:
    value=s.Rational(coef)*(1 if variable==0 else values[variable-1])
    big[i,j]+=value
    if i!=j:big[j,i]+=value
ck(data['matrix_order']==18 and data['visible_count']==7 and data['auxiliary_count']==9,
   'literal18-order seven-visible nine-auxiliary dimensions')
Qp=big[:4,:4];Qm=big[4:9,4:9]
fp=s.Matrix([S,u*X,u*Y,u*u*S]);fm=s.Matrix([X,Y,u*S,u*u*X,u*u*Y])
ck(z((fp.T*Qp*fp)[0]+(fm.T*Qm*fm)[0]-reduced),
   'every literal affine direction reconstructs the whole original univariate parent')
ck(big[9:,9:]==s.diag(d,n,m,C,A,D-m,m-D,alpha-C,C-alpha),
   'all orthant and original-coordinate equality scalars exactly correct')

# Completeness is independently determined from the two actual parity lists.
coords=[];variables=[];Qgen=[]
for g,ff in enumerate((fp,fm)):
    gg=s.zeros(len(ff))
    for i in range(len(ff)):
        for j in range(i,len(ff)):
            zz=s.Symbol(f'h{g}_{i}_{j}');coords.append((g,i,j));variables.append(zz);gg[i,j]=gg[j,i]=zz
    Qgen.append(gg)
generic=s.expand((fp.T*Qgen[0]*fp)[0]+(fm.T*Qgen[1]*fm)[0])
poly=s.Poly(generic,u,S,X,Y);coef=list(poly.coeffs())
L=s.Matrix([[s.diff(v,x) for x in variables] for v in coef])
ck(L.shape==(16,25) and L.rank()==16,'all25 Gram entries have exact rank16 matching map')
raw=s.Matrix([Qp[i,j] if g==0 else Qm[i,j] for g,i,j in coords])
N=raw.jacobian(xx)
ck(N.rank()==9 and L*N==s.zeros(16,9),'all9 independent auxiliary directions exhaust matching nullspace')
report={'status':'PASS','exact_checks':len(checks),'checks':checks,
 'scope':'Independent exact reconstruction of SF projection, state reduction, complete literal affine Gram family and source/equality constraints. The analytic degree-bounded matrix Fejer-Riesz input was checked separately in the primary source.',
 'proof_sha256':sha(peer/'c2_reciprocal_fixed_sector.tex'),'pencil_sha256':sha(path),
 'checker_sha256':sha(Path(__file__).resolve()),
 'primary_theorem':'Zalar arXiv1503.06034v1, Theorem1.2 p1; also v2 Theorem1.1 p1: PSD univariate degree<=2N has complex polynomial G*G with degreeG<=N, including singular cases.',
 'primary_url':'https://zalara.github.io/Papers/MatrixFejerRieszArxivOriginal.pdf'}
(R/'INDEPENDENT_C2_FIXED_SECTOR_CHECK.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS',len(checks),'independent C2 fixed-sector full-parent/COO checks')
