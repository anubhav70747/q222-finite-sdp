#!/usr/bin/env python3
"""Verify the release bytes and scope; optionally replay exact finite algebra.

The universal G1/G2 coverage statements are OPEN. Neither this program nor
its success output certifies an exact lift of the full quantum body.
"""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor, as_completed
import argparse
import hashlib
import json
import os
import shutil
import subprocess
import sys
import tempfile
import time

ROOT = Path(__file__).resolve().parent
SUITES = [
    ("old_c1_separator", "c1/check_two_frame_correction.py", "c1/CHECK_TWO_FRAME_CORRECTION.json", []),
    ("enlarged_c1_repair", "c1/check_enlarged_c1_repair.py", "c1/CHECK_ENLARGED_C1_REPAIR.json", []),
    ("c1_regular_reduction", "c1/check_c1_regular_contact_reduction.py", "c1/CHECK_C1_REGULAR_CONTACT_REDUCTION.json", ["c1/C1_REGULAR_CONTACT_DOMAIN.json"]),
    ("c1_full_contact_fiber", "c1/build_c1_enlarged_contact_system.py", "c1/CHECK_C1_ENLARGED_CONTACT_SYSTEM.json", ["c1/C1_ENLARGED_REGULAR_CONTACT_SYSTEM.json"]),
    ("c2_regular_reduction", "c2/check_c2_regular_contact_reduction.py", "c2/check_c2_regular_contact_reduction.json", ["c2/c2_regular_contact_seed.json", "c2/c2_enlarged_regular_contact_system.json", "c2/c2_old_regular_contact_system.json"]),
    ("c2_exact_fixed_sector", "c2/check_c2_reciprocal_fixed_sector.py", "c2/check_c2_reciprocal_fixed_sector.json", ["c2/C2_RECIPROCAL_FIXED_SECTOR.coo.json"]),
    ("c2_sector_independent_readback", "c1/review_check_c2_fixed_sector.py", "c1/INDEPENDENT_C2_FIXED_SECTOR_CHECK.json", []),
    ("normalized_dual_contract", "build_normalized_dual_gate.py", "dual_gate/CHECK_NORMALIZED_DUAL_GATE.json", ["dual_gate/C1_NORMALIZED_DUAL_FAILURE_SYSTEM.json", "dual_gate/C2_NORMALIZED_DUAL_FAILURE_SYSTEM.json"]),
    ("dual_contract_independent_readback", "routing/check_normalized_dual_gate_independent.py", "routing/NORMALIZED_DUAL_GATE_INDEPENDENT_REVIEW.json", []),
    ("old_global_strictness", "routing/check_remembered_ray_global_transfer.py", "routing/REMEMBERED_RAY_GLOBAL_TRANSFER.json", []),
    ("enlarged_global_independent_readback", "routing/check_enlarged_global_compiler.py", "routing/CHECK_ENLARGED_GLOBAL_COMPILER.json", []),
]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

def count(receipt):
    for key in ("assertion_count", "checks_passed", "check_count", "assertions"):
        if isinstance(receipt.get(key), int):
            return receipt[key]
    for key in ("checks", "exact_checks"):
        if isinstance(receipt.get(key), list):
            return len(receipt[key])
    raise ValueError("Receipt has no scoped assertion count")

def verify_integrity():
    manifest = read(ROOT / "MANIFEST_SHA256.json")
    failures = []
    for name, expected in manifest["files"].items():
        path = ROOT / name
        if not path.is_file() or sha(path) != expected["sha256"] or path.stat().st_size != expected["bytes"]:
            failures.append(name)
    if failures:
        raise RuntimeError("Manifest mismatch: " + ", ".join(failures))
    ledger = read(ROOT / "CHECKLIST.json")
    assert ledger["overall_status"] == "FULL_FINITE_LIFT_EXTRACTION_NOT_COMPLETE"
    assert ledger["central_open_gates"] == ["G1", "G2"]
    entries = {x["id"]: x for x in ledger["items"]}
    assert entries["G1"]["status"] == entries["G2"]["status"] == "OPEN"
    assert entries["A04"]["status"] == entries["V02"]["status"] == "BLOCKED_BY_OPEN_GATES"
    for row in entries.values():
        for evidence in row["evidence"]:
            if not (ROOT / evidence).is_file():
                raise RuntimeError("Missing checklist evidence: " + evidence)
    pencil = read(ROOT / "routing/compiled_enlarged/GLOBAL_CANONICAL_OUTER_PENCIL.coo.json")
    assert pencil["quantum_forward_inclusion"] is True
    assert pencil["quantum_reverse_inclusion_proved"] is False
    assert pencil["quantum_reverse_inclusion_refuted"] is False
    assert (pencil["matrix_order"], pencil["auxiliary_count"], len(pencil["blocks"]), len(pencil["entries"])) == (13744, 29920, 2928, 153248)
    assert pencil["visible_coordinates"] == ["a0", "a1", "b0", "b1", "E00", "E01", "E10", "E11"]
    assert max(b["order"] for b in pencil["blocks"]) == 15
    old = read(ROOT / "routing/REMEMBERED_RAY_GLOBAL_TRANSFER.json")
    assert old["global_strictness"] == "BOTH_CURRENT_PENCILS_ARE_STRICTLY_OUTER"
    for fam in ("C1", "C2"):
        d = read(ROOT / "dual_gate" / (fam + "_NORMALIZED_DUAL_FAILURE_SYSTEM.json"))
        assert d["status"] == "EXACT_FINITE_GATE_INPUT; UNIVERSAL_EMPTINESS_NOT_DECIDED"
        assert d["normalized_affine_hull_dimension"] == 154
    for item in read(ROOT / "PUBLICATION_TRANSFORMS.json")["files"]:
        assert sha(ROOT / item["original"]) == item["original_sha256"]
        assert sha(ROOT / item["publication_copy"]) == item["publication_sha256"]
        assert item["mathematical_content_changed"] is False
    pdf = ROOT / "Q222_Extraction_Checklist_and_Progress_2026-10-22.pdf"
    visual = read(ROOT / "qa/COMBINED_VISUAL_REVIEW.json")
    compilation = read(ROOT / "qa/PDF_COMPILE_CHECK.json")
    assert visual["status"] == "PASS_ALL_PAGES_VISUALLY_REVIEWED"
    assert visual["all_pages_covered"] is True
    assert visual["pdf_sha256"] == compilation["pdf_sha256"] == sha(pdf)
    assert visual["page_count"] == compilation["page_count"] == 34
    assert all(value == 0 for value in compilation["checks"].values())
    replay = read(ROOT / "REPLAY_RESULTS.json")
    assert replay["status"] == "PASS_ALL_11_SCOPED_ISOLATED_EXACT_REPLAYS"
    assert len(replay["suites"]) == 11 and replay["failures"] == []
    for suite in replay["suites"]:
        assert sha(ROOT / suite["script"]) == suite["script_sha256"]
        assert sha(ROOT / suite["bound_receipt"]) == suite["bound_receipt_sha256"]
        assert count(read(ROOT / suite["bound_receipt"])) == suite["assertion_count"]
        for artifact in suite["regenerated_artifacts"]:
            assert artifact["exact_bytes_reproduced"] is True
            assert sha(ROOT / artifact["path"]) == artifact["sha256"]
    return {"status": "PASS_HASHES_AND_SCOPE_INVARIANTS", "manifest_bound_files": len(manifest["files"]),
            "global_exact_extraction": "OPEN", "central_open_gates": ["G1", "G2"]}

def replay_one(suite, temp_root):
    name, script, receipt_path, artifacts = suite
    work = Path(temp_root) / name
    shutil.copytree(ROOT, work, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "*.zip"))
    expected = read(ROOT / receipt_path)
    start = time.monotonic()
    env = os.environ.copy()
    env["PYTHONDONTWRITEBYTECODE"] = "1"
    run = subprocess.run([sys.executable, str(work / script)], cwd=work, env=env,
                         text=True, capture_output=True, timeout=1200)
    if run.returncode:
        raise RuntimeError(name + " failed:\n" + run.stdout[-6000:] + run.stderr[-6000:])
    result = read(work / receipt_path)
    if not str(result.get("status", "")).startswith("PASS"):
        raise RuntimeError(name + " did not report PASS")
    if count(result) != count(expected):
        raise RuntimeError(name + " assertion count differs: bound=" + str(count(expected))
                           + ", freshly executed=" + str(count(result)))
    readbacks = []
    for relative in artifacts:
        equal = sha(work / relative) == sha(ROOT / relative)
        if not equal:
            raise RuntimeError(name + " regenerated different exact data: " + relative)
        readbacks.append({"path": relative, "sha256": sha(ROOT / relative), "exact_bytes_reproduced": True})
    return {"name": name, "script": script, "script_sha256": sha(ROOT / script),
            "status": result["status"], "assertion_count": count(result),
            "bound_receipt": receipt_path, "bound_receipt_sha256": sha(ROOT / receipt_path),
            "isolated_replay": True, "seconds": round(time.monotonic() - start, 3),
            "regenerated_artifacts": readbacks}

def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--replay", choices=["exact"])
    parser.add_argument("--jobs", type=int, default=3, help="independent isolated replay workers (default: 3)")
    parser.add_argument("--report", type=Path, help="write the replay record to this new file")
    args = parser.parse_args()
    if not 1 <= args.jobs <= 8:
        parser.error("--jobs must be between 1 and 8")
    integrity = verify_integrity()
    print(json.dumps(integrity), flush=True)
    if not args.replay:
        return
    try:
        import sympy
    except ImportError:
        parser.error("Exact replay requires SymPy; install requirements.txt in your Python environment.")
    results = []
    failures = []
    with tempfile.TemporaryDirectory(prefix="q222_exact_replay_") as temporary:
        with ThreadPoolExecutor(max_workers=args.jobs) as pool:
            futures = {pool.submit(replay_one, row, temporary): row[0] for row in SUITES}
            for future in as_completed(futures):
                try:
                    result = future.result()
                except Exception as exc:
                    failure = {"suite": futures[future], "error": str(exc)}
                    failures.append(failure)
                    print(json.dumps(failure), flush=True)
                else:
                    results.append(result)
                    print(json.dumps({"suite": result["name"], "status": result["status"],
                                      "assertion_count": result["assertion_count"]}), flush=True)
    order = {row[0]: i for i, row in enumerate(SUITES)}
    results.sort(key=lambda row: order[row["name"]])
    record = {"status": "REPLAY_FAILED" if failures else "PASS_ALL_11_SCOPED_ISOLATED_EXACT_REPLAYS", "python": sys.version.split()[0],
              "sympy": sympy.__version__, "suites": results,
              "failures": failures,
              "counts_are_not_added": True, "universal_G1_G2": "OPEN",
              "limitation": "These finite exact checks corroborate the stated identities and arrays. Analytical arguments require proof review. Universal PSD coverage and full reverse inclusion are not established."}
    if args.report:
        args.report.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"status": record["status"], "suite_count": len(results),
                      "universal_G1_G2": "OPEN"}), flush=True)
    if failures:
        raise SystemExit(1)

if __name__ == "__main__":
    main()
