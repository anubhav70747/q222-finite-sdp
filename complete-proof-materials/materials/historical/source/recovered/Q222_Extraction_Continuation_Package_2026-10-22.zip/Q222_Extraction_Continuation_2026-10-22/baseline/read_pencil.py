#!/usr/bin/env python3
"""Read exact sparse affine data without building a large dense matrix.

The global file is an OUTER candidate with reverse inclusion OPEN.
The C2 file is exact only on its stated reciprocity-fixed source sector.
"""
from pathlib import Path
from fractions import Fraction
import argparse
import json

ROOT = Path(__file__).resolve().parent
FILES = {
    "global": ROOT / "routing/compiled_enlarged/GLOBAL_CANONICAL_OUTER_PENCIL.coo.json",
    "c2-sector": ROOT / "c2/C2_RECIPROCAL_FIXED_SECTOR.coo.json",
}

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--pencil", choices=list(FILES), default="global")
    p.add_argument("--entry", nargs=2, type=int, metavar=("ROW", "COL"), help="zero-based matrix entry; show its affine terms")
    p.add_argument("--coefficient", type=int, help="restrict to direction k: 0=constant, then visible, then auxiliary")
    p.add_argument("--block", type=int, help="zero-based block to evaluate exactly")
    p.add_argument("--values", type=Path, help="JSON object mapping direction k to rational value; unspecified directions are zero")
    args = p.parse_args()
    d = json.loads(FILES[args.pencil].read_text())
    if args.entry is not None:
        i, j = sorted(args.entry)
        if not 0 <= i <= j < d["matrix_order"]:
            p.error("matrix index is out of range")
        terms = [[k, v] for k, a, b, v in d["entries"] if (a, b) == (i, j) and (args.coefficient is None or k == args.coefficient)]
        print(json.dumps({"entry": [i, j], "terms": terms, "convention": d.get("coefficient_convention", "upper triangle mirrored")}, indent=2))
    elif args.block is not None:
        if not 0 <= args.block < len(d["blocks"]):
            p.error("block index is out of range")
        values = {0: Fraction(1)}
        if args.values:
            values.update({int(k): Fraction(v) for k, v in json.loads(args.values.read_text()).items()})
        if values[0] != 1:
            p.error("the affine constant direction k=0 must have value 1")
        block = d["blocks"][args.block]
        offset, n = block["offset"], block["order"]
        matrix = [[Fraction(0) for _ in range(n)] for _ in range(n)]
        for k, i, j, value in d["entries"]:
            if offset <= i <= j < offset+n:
                x = Fraction(value) * values.get(k, Fraction(0))
                matrix[i-offset][j-offset] += x
                if i != j:
                    matrix[j-offset][i-offset] += x
        print(json.dumps({"block": args.block, "order": n, "matrix": [[str(x) for x in row] for row in matrix],
                          "meaning": "Exact evaluation only; this reader does not decide feasibility."}, indent=2))
    else:
        print(json.dumps({k: v for k, v in d.items() if k not in ("entries", "blocks")}, indent=2))
        print(json.dumps({"block_count": len(d["blocks"]), "upper_triangle_records": len(d["entries"])}))

if __name__ == "__main__":
    main()
