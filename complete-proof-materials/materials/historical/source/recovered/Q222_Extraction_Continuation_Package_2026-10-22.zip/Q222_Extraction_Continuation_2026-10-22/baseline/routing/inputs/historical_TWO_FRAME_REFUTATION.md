# Exact refutation of the saturated C1 frame

27 September 2026.

## Verdict

Let R1 be the coefficient-affine square-cover Gram cone printed in
`sources/C1_RAMIFIED_PRIMAL.coo.json`, let sigma=[0,2,1,5,6,3,4], and let
S1=R1+sigma(R1). Then

**S1 is a proper subcone of the physical C1 cone.**

This statement refutes the particular saturated frame, not finite SDP
representability by some other lift. The inherited qualitative existence
argument is not re-audited here. No whole-C2 equality is decided.

## 1. A rational physical cap

The C1 coefficient order is (d,e2,e3,e4,e5,alpha,beta). Take

c*=(1,
  1166523000/31661820415017653,
  322803000/186199784281,
  218288946200/1359122513,
  90943434293/222507771414,
  248802430236/3300726103,
  205476973/51646655494).

Every coordinate is strictly positive. Use the physical strategy

A0=B0=Z,
A1=(84 Z+13 X)/85,
B1=(-255 Z+32 X)/257,
psi=(112000,-25,16,800)^T/sqrt(12544640881).

The tangent parameters are u=1/13 and v=16. The optimizing Alice pair is
acute, since its relative cosine is 84/85>0. For rational calculations use
the unnormalized state psi0=(140,-1/32,1/50,1)^T.

The consumer reconstructs all physical operators directly from Pauli
matrices and checks the full four kernel and two stationarity equations.
The six-by-six event contact determinant is

-112540891293960573591613289705098896/1346274334462890625,

so this is a regular contact, not an excluded singular chart.

### Global physicality, rather than a single-test check

For P_c(u,v)=(1+u^2)(1+v^2)M_c(u,v), the signed core obeys the exact
congruence

P_H=2 B diag(1,1+v^2,1+u^2,-(1+u^2)(1+v^2)) B^T,
B=[(u,uv,-1,-v)^T,(0,1,0,u)^T,(0,0,v,-1)^T,(0,0,0,1)^T],
det B=uv.

Thus, when uv is nonzero and d>0, adding the nonnegative event operators
leaves at least three positive eigenvalues. The sign of the fourth is the
sign of the determinant.

The verifier computes det(P_c*) independently using all 24 permutation
products. Division gives the exact identity

det P_c*=16(1+u^2)^2(1+v^2)^2 Q(u^2,v^2).

Every coefficient of Q except q11 is nonnegative; their exact values are
in data/VERIFY_REPORT.json. The contact is a zero of Q and of both first
angle derivatives. The function

F(x,y)=exp(-x-y) Q(exp x,exp y)

is a constant plus nonnegative exponentials. It is convex, and its
stationary zero is a global minimum. Consequently det P_c* is nonnegative
at every noncommuting real measurement pair, and the inertia identity gives
P_c*>=0 there. Pauli sign conjugacies and continuity of the original
normalized operator include the other signs and every commuting/projective
endpoint. This proves c* in C1 without using the qualitative existence
argument.

For completeness, the physical interpretation extends beyond the chosen
qubit realization. The two-observable block reduction on each party gives
blocks of dimension at most two. Each pair of qubit observables can be
placed in a real plane by a local basis change; for real observable
matrices a complex state contributes the sum of its real and imaginary
state quadratic forms. Convexity therefore extends the proved all-angle,
all-real-state inequality to the full Q222 target used in this project.
This uses the standard physical reduction, not the historical all-pairs
certificate atlas.

At the displayed state, H has strictly negative expectation. Therefore
increasing d at fixed six event weights is invalid. The point is a sharp
physical deficit cap.

## 2. Both contact fibres are strictly separated

The reflected contact, in last-amplitude-one gauge, is

(u',v',a',b',c')=(13,16,1792025/12816,-775/89,34/801).

Its physical coefficients are sigma(c*). The original contact has
u=1/13, so the sufficient acute-contact universality premise from the
previous release is false as well.

For each orientation, data/C1_TWO_FRAME_CONTACT_REFUTATION.json contains
71 rational separator coordinates and four positive-definite matrices of
orders 13,5,5,3. The exact contact-fibre pairings are, respectively,

-3173178640431959223164745403431139485869 /
 79514550060139391171283033127812500000000000,

-10832735533777046960471655785273013895433953 /
 640433932611077449252867868631250000000000.

All positive-definiteness tests are rational LDL tests. In particular,
neither sign is a floating-point feasibility classification.

Substitution into the predecessor's actual 147-variable simultaneous
failure system satisfies **all 79 strict polynomial inequalities**. The
complete point and every polynomial value are in
`data/C1_TWO_FRAME_FAILURE_EVALUATION.json`.

## 3. A single separator for the entire coefficient cone

The stronger certificate does not require imposing contact equations on
an arbitrary candidate coefficient vector.

Define the rational linear evaluation functional

h(c)=psi0^T P_c(1/13,16) psi0.

In C1 order its row is

(-24827425191/54080000,
 542693412399961/27040000,
 12546269433/105625,
 8738/21125,
 11819844/105625,
 39304/21125,
 92777/43264).

Set L=46712 and ell=2 L h-(1,0,0,0,0,0,0). Then ell(c*)=-1.

For each of the two frame orientations there are four rational
positive-definite matrices Z_g of orders 14,6,6,4 such that, for the actual
79 auxiliary coefficient matrices B_ga,

sum_g tr(Z_g B_ga)=0 for every a,

and, for all seven actual visible coefficient matrices C_gi,

ell_i-sum_g tr(Z_g C_gi)=delta_i0.

In the reflected orientation replace ell by sigma(ell). These equations
are checked entrywise against the published original-coordinate arrays.
They prove ell>=0 on both R1 and sigma(R1), and hence on S1, whereas
ell(c*)=-1.

The file `data/C1_SATURATED_DUAL_LITERAL_WITNESS.json` gives **all 144
auxiliary values in the published saturated dual pencil**. Direct
substitution makes its eight nontrivial PSD blocks positive definite and
both scalar blocks equal to one. Thus the full-cone separation can be
replayed without the contact reduction or the polynomial bad-set system.

### How the full separator was constructed

A positive-definite contact separator has positive compression transverse
to each contact feature vector. Its missing auxiliary trace conditions can
be repaired by matrices f z^T+z f^T. The corresponding exact linear map has
rank 30. Such corrections do not change positivity on f-perp.

After making the target visible functional equal to -d, adding a sufficiently
large positive multiple of f f^T makes each full block positive definite.
The added rank-one term is the actual physical evaluation h. The two
orientations differ by the explicit positive physical scaling factor
(1+v^2)/(u^2(v+c)^2), so a common coefficient penalty can be chosen. The
rational Schur thresholds give L=46712. The full construction data and the
resulting matrices are printed in `data/C1_SATURATED_CONE_SEPARATOR.json`.

## 4. The artificial physical gap

The trace identities actually imply, for every c in S1,

h(c)>=d/46712.

Indeed, ell(c) is a sum of positive trace pairings plus d, and ell=93424h-d.
But h(c*)=0 and d=1. The candidate therefore imposes a strictly positive
energy floor at an actual zero-energy physical support.

In normalized physical-state units the forced floor is

1352000/320021202757070671 > 0

at d=1. It is approximately 4.22e-12. The small magnitude explains why
numerical search alone is not an adequate acceptance test. The rational
trace identities, rather than this approximation, prove the obstruction.

## 5. Failure persists away from the sharp boundary

Let

delta=1690000/144967342450249,
c^- = c* - delta (1,0,0,0,0,0,0).

Decreasing the deficit preserves physicality because

(d',w)=(d'/d)(d,w)+(1-d'/d)(0,w)

and the event-only operator is positive. All coordinates of c^- are
strictly positive. Its exact separating value is

ell(c^-)=-144967345830249/289934684900498 < 0.

This is an interior point of C1 relative to the seven physical coordinates.
For nearby w', event monotonicity and homogeneity give
D(w')>=(1-epsilon)D(w) whenever w'>=(1-epsilon)w. Choosing epsilon=delta/4
and a sufficiently small deficit perturbation keeps d'<D(w'). Continuity
of the linear separator then keeps ell<0.

The verifier exports an explicit rational l-infinity radius for a whole
seven-dimensional open box of missed physical supports. The failure is
therefore neither an isolated contact nor a literal-zero endpoint effect.
