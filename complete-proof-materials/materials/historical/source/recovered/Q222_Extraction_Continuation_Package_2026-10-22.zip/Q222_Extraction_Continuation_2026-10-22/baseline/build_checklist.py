#!/usr/bin/env python3
"""Write one precise status ledger in JSON, plain text, and LaTeX.

Statuses describe delivered proofs or data at their stated scope.  The two
universal coverage gates remain OPEN.  No completion percentage is used.
"""
from pathlib import Path
import json
import sys

R=Path(__file__).resolve().parent
release_verified='--release-verified' in sys.argv[1:]
if release_verified:
    replay=json.loads((R/'REPLAY_RESULTS.json').read_text())
    qa=json.loads((R/'qa/COMBINED_VISUAL_REVIEW.json').read_text())
    assert replay['status']=='PASS_ALL_11_SCOPED_ISOLATED_EXACT_REPLAYS'
    assert qa['status']=='PASS_ALL_PAGES_VISUALLY_REVIEWED'
items=[]
def add(ident,status,title,obligation,acceptance,evidence,depends=()):
    items.append(dict(id=ident,status=status,title=title,obligation=obligation,
                      acceptance_test=acceptance,evidence=evidence,depends_on=list(depends)))

add('S01','COMPLETE','Fix the target and normalization',
 'The full finite-dimensional tensor-product Q222 in the eight original marginal/correlator coordinates is the target.',
 'Every global source map and visible matrix column uses (a0,a1,b0,b1,E00,E01,E10,E11); both parties and all finite mixtures are included.',
 ['routing/enlarged_global_candidate.tex','routing/inputs/finite_contact_source_reduction_REDERIVED.tex'])
add('S02','COMPLETE','Recover and identify actual mathematical inputs',
 'Compare current arrays with the recovered historical obstruction and enlarged construction, including complete coefficients and conventions.',
 'Exact mathematical-key agreement for the old C1 arrays, archive custody, and fresh witness substitution; archive titles alone are not evidence.',
 ['HISTORICAL_RECOVERY.json','c1/TWO_FRAME_CORRECTION_DEPENDENCIES.json','routing/INPUT_CUSTODY.json'])
add('S03','COMPLETE','Correct the old C1 and global candidate statuses',
 'Retire the old two-orientation C1 equality and the order-8368/order-10736 global exactness claims.',
 'A globally physical rational source is excluded by one exact separator on both C1 orientations; its extreme-ray and full component-map transfer proves both global outer containments strict.',
 ['c1/two_frame_correction.tex','routing/current_global_candidate_correction.tex','routing/REMEMBERED_RAY_GLOBAL_TRANSFER.json'],['S02'])
add('F01','COMPLETE','Specify the enlarged testing features',
 'Fix the four feature lists and the testing-only multiplier (1+u)(1+v) for both canonical source families.',
 'Every retained function is explicitly listed; C1 block orders 14,15,14,15 and C2 orders 15,14,14,15, with all source signs retained.',
 ['c1/inputs/C1_ENLARGED_PRIMAL.coo.json','c2/inputs/C2_ENLARGED_PRIMAL.coo.json','routing/enlarged_global_candidate.tex'],['S01'])
add('F02','COMPLETE','Match the full original state polynomial',
 'The candidate Gram identity must equal the complete Pauli parent in all four state coordinates, all angle powers, every source direction and every auxiliary direction.',
 'Exact coefficient readback for all 7 source and 302 auxiliary columns per family; matching rank 148 and full affine matching dimension 309.',
 ['routing/CHECK_ENLARGED_GLOBAL_COMPILER.json','c1/CHECK_ENLARGED_C1_REPAIR.json','c2/check_c2_regular_contact_reduction.json'],['F01'])
add('F03','COMPLETE','Prove event inclusion and closedness',
 'The actual enlarged cones must be sound closed convex cones containing all 6 event rays; the C1 two-orientation sum must also be closed.',
 'Exact event certificates and finite-evaluation Gram bound sum tr(G)<=70756 sum(c); source nonnegativity bounds each summand in the C1 sum.',
 ['c1/c1_regular_contact_reduction.tex','c2/c2_regular_contact_reduction.tex','c1/enlarged_c1_exact_repair.tex'],['F02'])
add('F04','COMPLETE','Qualify the duals and retain all affine equations',
 'Turn each actual source pencil into an attained exact trace-adjoint dual without losing signs or using a different parameterization.',
 'Fresh strict rational source witnesses, exact positive LDL pivots, off-diagonal factors of 2, and full elimination with 148 dual auxiliaries for each enlarged canonical cone.',
 ['routing/compiled_enlarged/C1_QUALIFIED_DUAL.json','routing/compiled_enlarged/C2_QUALIFIED_DUAL.json','routing/CHECK_ENLARGED_GLOBAL_COMPILER.json'],['F02'])
add('R01','COMPLETE','Prove the C1 regular-source reduction',
 'Reduce all C1 sources to one explicit 5-variable regular sharp-contact domain, retaining the two orientation choices.',
 'Positive finite sharp cap, strict logarithmic convexity, negative cap derivative, analytic unique contact, genuine density, and rank-6 regular-ray extremality are proved.',
 ['c1/c1_regular_contact_reduction.tex','c1/C1_REGULAR_CONTACT_DOMAIN.json','c1/CHECK_C1_REGULAR_CONTACT_REDUCTION.json'],['F03'])
add('R02','COMPLETE','Prove the C2 regular-source reduction',
 'Reduce all C2 sources to its explicit 5-variable regular sharp-contact domain.',
 'Finite sharp cap, exact determinant/inertia implication, analytic-contact density and source interpolation are proved with no angle or state-ratio upper bound.',
 ['c2/c2_regular_contact_reduction.tex','c2/c2_regular_contact_seed.json','c2/check_c2_regular_contact_reduction.json'],['F03'])
add('R03','COMPLETE','Discharge boundary reduction rather than assume it',
 'Once all regular sharp sources are admitted, every zero coefficient, zero state coordinate and projective contact limit must follow in the actual candidate.',
 'Approximate by positive event vectors, use proven regular density and actual bounded-Gram closedness; no division by a vanishing boundary coordinate.',
 ['c1/c1_regular_contact_reduction.tex','c2/c2_regular_contact_reduction.tex'],['R01','R02','F03'])
add('R04','COMPLETE','Export complete finite contact and failure systems',
 'Specify the exact equations that a universal proof must solve, without freezing arbitrary free coordinates.',
 'Each primal regular fiber has 392 symmetric coordinates, rank 142, and 250 free coordinates; original-source trace-one dual bases have 154 affine coordinates. All complete maps are printed.',
 ['c1/C1_ENLARGED_REGULAR_CONTACT_SYSTEM.json','c2/c2_enlarged_regular_contact_system.json','dual_gate/C1_NORMALIZED_DUAL_FAILURE_SYSTEM.json','dual_gate/C2_NORMALIZED_DUAL_FAILURE_SYSTEM.json'],['R01','R02','F04'])
add('G1','OPEN','Universal enlarged C1 coverage',
 'For EVERY regular C1 source, at least one of its two orientations admits all 4 enlarged PSD Gram blocks.',
 'Prove for every theta in the explicit dense domain CS7 (both orientations regular), there exist an orientation o in {0,1} and z in R^250 with all four compressed matrices PSD; equivalently prove the two-negative-dual failure system F1 empty on the original regular domain.',
 ['c1/c1_enlarged_contact_selector_contract.tex','normalized_dual_gate.tex','dual_gate/C1_NORMALIZED_DUAL_FAILURE_SYSTEM.json'],['R03','R04'])
add('G2','OPEN','Universal enlarged C2 coverage',
 'For EVERY regular C2 source, the enlarged four-block matching fiber contains PSD matrices.',
 'Prove forall theta in the explicit regular domain, exists z in R^250, all 4 compressed matrices PSD; equivalently prove the negative-dual failure system F2 empty.',
 ['c2/c2_regular_contact_reduction.tex','normalized_dual_gate.tex','dual_gate/C2_NORMALIZED_DUAL_FAILURE_SYSTEM.json'],['R03','R04'])
add('A01','COMPLETE','Keep the full global source assembly',
 'The construction must contain all needed Bell frames, the exact noncoercive closed faces and the original event rays.',
 '128 C1, 64 C2, 64 adjacent and 32 opposite closed-face components, plus 16 original event inequalities, using one shared visible behavior. Conditional converse uses the retained full support-generation proof.',
 ['routing/compiled_enlarged/GLOBAL_SOURCE_MAPS.json','routing/inputs/closed_faces_short.tex','routing/inputs/finite_contact_source_reduction_REDERIVED.tex'],['F04'])
add('A02','COMPLETE','Evaluate every matrix coefficient',
 'Produce the complete rational affine pencil and an exact interpretation of every index.',
 'N=13744, m=29920, 2928 blocks, maximal block order 15, 153248 nonzero upper-triangle COO records; constants, 8 visible directions and all auxiliaries read back exactly.',
 ['routing/compiled_enlarged/GLOBAL_CANONICAL_OUTER_PENCIL.coo.json','routing/CHECK_ENLARGED_GLOBAL_COMPILER.json'],['A01'])
add('A03','COMPLETE','Prove quantum forward inclusion',
 'Every quantum behavior must have a feasible lift in the new candidate.',
 'Sound canonical source identities, exact closed-face cones, attained dualization, finite physical mixtures and the original coordinate projection prove Q222 contained in O13744.',
 ['routing/enlarged_global_candidate.tex','routing/CHECK_ENLARGED_GLOBAL_COMPILER.json'],['F03','F04','A01','A02'])
add('A04','BLOCKED_BY_OPEN_GATES','Prove the global reverse inclusion',
 'Every feasible original-coordinate behavior of the new pencil must be quantum.',
 'Use proved G1,G2 to identify the assembled source cone with the full quantum-valid affine cone; separation then gives O13744 contained in Q222.',
 ['routing/enlarged_global_candidate.tex','normalized_dual_gate.tex'],['G1','G2','A01','A02','A03'])
add('V01','COMPLETE_AT_STATED_SCOPE' if release_verified else 'RELEASE_PENDING','Verify and package the current progress',
 'Bind the current proofs, exact arrays, scripts and scoped verification receipts into a reproducible package.',
 'Fresh isolated replays, independent coefficient readback, source hashes, PDF inspection and ZIP integrity. None of these substitute for G1 or G2.',
 ['VERIFICATION.txt','MANIFEST_SHA256.json','verify.py'],['S03','F02','R04','A02','A03'])
add('V02','BLOCKED_BY_OPEN_GATES','Release an exact full extraction',
 'The final deliverable must be an exact full-Q222 lift, with both inclusions and no unproved coverage premise.',
 'G1,G2 and A04 are proved, or a different universally adequate fixed finite factorization replaces them; only then may E1-E3 be marked complete.',
 ['CHECKLIST.json','CHECKLIST.txt'],['G1','G2','A04','V01'])

data={
 'title':'Q222 precise extraction checklist and verified progress',
 'date':'2026-10-22','overall_status':'FULL_FINITE_LIFT_EXTRACTION_NOT_COMPLETE',
 'completion_definition':'Evaluated finite affine matrices in all 8 original coordinates, with unconditional proofs of both quantum/PSD projection inclusions.',
 'primary_route':'Enlarged C1 two-orientation cone and enlarged C2 cone, plus exact closed faces and event rays.',
 'central_open_gates':['G1','G2'],
 'old_E1_E2_E3':{
  'E1':'Finite feature lists are evaluated. Their universal adequacy is OPEN (G1,G2).',
  'E2':'The new candidate pencil is evaluated. Its equality with Q222 is not proved.',
  'E3':'Forward inclusion and coefficient readback are complete; reverse inclusion is OPEN.'},
 'retired_claims':[
  {'claim':'Old C1 R1+sigma(R1)=C1','status':'REFUTED_BY_EXACT_SOURCE'},
  {'claim':'Order8368 candidate equals Q222','status':'REFUTED_STRICT_OUTER'},
  {'claim':'Order10736 candidate equals Q222','status':'REFUTED_STRICT_OUTER'}],
 'new_candidate':{'total_psd_order':13744,'auxiliaries':29920,'block_count':2928,
                  'maximum_block_order':15,'upper_COO_nonzeros':153248,
                  'forward_inclusion':'PROVED','reverse_inclusion':'OPEN',
                  'is_proved_exact_lift_size_bound':False},
 'rules_for_acceptance':[
  'An exact isolated source certificate does not prove a universal source statement.',
  'A finite list of numerical feasibility tests does not prove coverage.',
  'Closedness extends admission of ALL dense regular sources; it does not supply that admission.',
  'A complete affine matching map does not imply its PSD fibers are universally nonempty.',
  'A compiled real-algebraic failure formula has not been decided merely by writing it.',
  'No local tensor-rank, matrix-size, or symmetric-sector bound is a global lift-size theorem.',
  'No full extraction completion percentage is inferred from counts of algebra assertions or file checks.'
 ],
 'alternative_if_primary_route_fails':{
  'status':'NOT_COMPLETED; ALTERNATIVE_ROUTE, NOT_AN_ADDITIONAL_MANDATORY_BRANCH',
  'required':[ 'Extract one fixed finite source-independent test-function algebra from the inherited tensor-SOS construction.',
               'Prove a finite testing cover and finite support-admission cover; distinguish these two quantifiers.',
               'Print the common finite product table and every original-slack SOS identity.',
               'Compile and verify a replacement affine pencil and both inclusions.'],
  'warning':'The qualitative existence criterion does not certify this selected enlarged dictionary, C160, a fixed NPA level, or a chosen matrix size.'},
 'items':items
}
(R/'CHECKLIST.json').write_text(json.dumps(data,indent=2)+'\n')

lines=[data['title'].upper(),data['date'],'',
       'STATUS: FULL FINITE LIFT EXTRACTION IS NOT COMPLETE.',
       'The two remaining central mathematical gates are G1 and G2.',
       'The order-8368 and order-10736 candidates are now proved strictly outer.',
       'The new order-13744 candidate has a proved forward inclusion only.','']
for x in items:
    mark='[x]' if x['status'].startswith('COMPLETE') else '[ ]'
    lines += [f"{mark} {x['id']}  {x['title']} -- {x['status']}",
              '  Obligation: '+x['obligation'],
              '  Acceptance test: '+x['acceptance_test'],
              '  Dependencies: '+(', '.join(x['depends_on']) or 'none'),
              '  Evidence: '+', '.join(x['evidence']),'']
lines += ['E1-E3:']+['  '+k+': '+v for k,v in data['old_E1_E2_E3'].items()]
lines += ['', 'ACCEPTANCE RULES:']+['  - '+x for x in data['rules_for_acceptance']]
lines += ['', 'ALTERNATIVE IF THE ENLARGED DICTIONARIES FAIL:']
lines += ['  '+x for x in data['alternative_if_primary_route_fails']['required']]
(R/'CHECKLIST.txt').write_text('\n'.join(lines)+'\n')

def esc(t):
    table={'\\':r'\textbackslash{}','&':r'\&','%':r'\%','_':r'\_',
           '#':r'\#','<':r'\textless{}','>':r'\textgreater{}',
           '^':r'\textasciicircum{}','{':r'\{','}':r'\}','~':r'\textasciitilde{}'}
    return ''.join(table.get(c,c) for c in t)

tex=['\\section{The precise completion checklist}',
     'A completed checkbox below means that the stated obligation has been discharged at its declared scope. '
     'It is not a claim of full extraction. The two central mathematical gates are G1 and G2. '
     'Their dependent reverse-inclusion and final-release items remain open. No percentage is assigned.',
     '\\small',
     '\\begin{longtable}{@{}p{0.075\\textwidth}>{\\raggedright\\arraybackslash}p{0.16\\textwidth}>{\\raggedright\\arraybackslash}p{0.71\\textwidth}@{}}',
     '\\toprule ID & Status & Obligation and exact acceptance test\\\\ \\midrule\\endfirsthead',
     '\\toprule ID & Status & Obligation and exact acceptance test\\\\ \\midrule\\endhead',
     '\\midrule\\multicolumn{3}{r}{Continued on next page}\\\\\\endfoot',
     '\\bottomrule\\endlastfoot']
for x in items:
    short=('Done, scoped' if x['status']=='COMPLETE_AT_STATED_SCOPE' else
           'Release pending' if x['status']=='RELEASE_PENDING' else
           'Done' if x['status']=='COMPLETE' else 'Open' if x['status']=='OPEN' else 'Depends on G1/G2')
    body='\\textbf{'+esc(x['title'])+'}. '+esc(x['obligation'])+'\\par\\smallskip '+esc(x['acceptance_test'])
    if x['depends_on']:body+='\\par\\smallskip Dependencies: '+esc(', '.join(x['depends_on']))+'.'
    body+='\\par\\smallskip Evidence: '+', '.join('\\nolinkurl{'+x+'}' for x in x['evidence'])+'.'
    tex += [esc(x['id'])+' & '+short+' & '+body+'\\\\[1.2ex]']
tex += ['\\end{longtable}','\\normalsize',
        '\\paragraph{The original E1--E3 labels.} E1 has evaluated feature data but lacks universal adequacy. '
        'E2 has an evaluated candidate pencil; its equality with the quantum body is not established. '
        'E3 has a forward proof and exact coefficient readback; its reverse proof depends on G1 and G2.',
        '\\paragraph{A replacement route is allowed.} If an enlarged dictionary fails, a different fixed finite '
        'test-function algebra may replace it. Such a route must prove both the finite testing cover and the '
        'finite support-admission cover, print one common product table and original-slack certificates, '
        'then compile and prove both inclusions. The inherited qualitative existence theorem does not '
        'by itself certify a proposed dictionary or a chosen matrix order.']
(R/'checklist_section.tex').write_text('\n'.join(tex)+'\n')
print(json.dumps({'written':['CHECKLIST.json','CHECKLIST.txt','checklist_section.tex'],
                  'overall_status':data['overall_status'],'central_open_gates':['G1','G2'],
                  'required_items':len(items)},indent=2))
