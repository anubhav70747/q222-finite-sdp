These two archives are unchanged historical inputs, not current status ledgers.
The package-root CHECKLIST.json and current proof document supersede their
status claims. In particular both old global candidates are strictly outer.
All mathematical files required by the current eleven replay suites are
also available directly in the current package; no nested extraction is needed.
HISTORICAL_RECOVERY.json records the additional archives inspected during
reconciliation. Those raw archives are not all duplicated here; the exact
inputs used from them are included, with custody hashes.
