#!/usr/bin/env python3
"""Exact identities supporting the candidate-independent C1 boundary theorem.

This verifies the full determinant, contact seed, exact chart matrix, cap
derivative and actual order59 trace bound.  It does NOT prove or sample the
universal PSD-selector assertion CG18.
"""
from itertools import permutations, product
from pathlib import Path
import hashlib
import json
import sympy as s

R=Path(__file__).resolve().parent
tests=[]
def ck(x,name):
    if not bool(x): raise AssertionError(name)
    tests.append(name)
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def zero(expr): return s.cancel(expr)==0
def mz(M): return all(zero(z) for z in M)

u,v,W,X,Y,Z=s.symbols('u v W X Y Z',real=True)
d,m,C,A,D,alpha,beta=s.symbols('d m C A D alpha beta',real=True)
cs=(d,m,C,A,D,alpha,beta);state=s.Matrix([W,X,Y,Z])
Du,Dv=1+u*u,1+v*v
r2=v*W-X+u*v*Y-u*Z;r3=u*W-Y
r5=u*W+u*v*X-Y-v*Z;rA=Y;rAlpha=v*Y-Z;rBeta=X+u*Z
F=s.expand(m*r2*r2+C*Dv*r3*r3+A*Du*Dv*rA*rA
 +(D+d/2)*r5*r5+(alpha+d/2)*Du*rAlpha*rAlpha
 +(beta+d/2)*Dv*rBeta*rBeta-d*Du*Dv*Z*Z/2)
P=s.hessian(F,state)/2
ck(zero((state.T*P*state)[0]-F),'full quarter-parent quadratic form')
K=P.diff(d);Pb=[P.diff(z) for z in cs]
ck(zero((state.T*K*state)[0].subs(Z,0)
        -(r5.subs(Z,0)**2+Dv*X**2+Du*v*v*Y*Y)/2),'CG1 complete strict WXY core')
ck(s.Matrix([[u,u*v,-1],[0,1,0],[0,0,v]]).det()==u*v,
   'three hard core rows independent for uv>0')
ck(s.Matrix([[0,0,1,0],[u,0,-1,0],[0,0,v,-1],[0,1,0,u]]).det() in [u,-u],
   'four positive event roots have trivial common kernel for u>0')
ck(zero(F.subs({u:-u,Y:-Y,Z:-Z},simultaneous=True)-F),'complete Alice sign gauge')
ck(zero(F.subs({v:-v,X:-X,Z:-Z},simultaneous=True)-F),'complete Bob sign gauge')

p22=C*beta*(2*D+d)*(2*A+2*alpha+d+2*m)/4
p21=A*C*(2*D+d)*(2*alpha+2*beta+d+2*m)/4
p10=A*alpha*(2*C+2*D+d)*(2*beta+d+2*m)/4
p02=D*m*(2*beta+d)*(2*A+2*C+2*alpha+d)/4
p01=alpha*m*(2*beta+d)*(2*A+2*C+2*D+d)/4
p12=(C*D*(2*A+2*alpha+d)*(2*beta+d)
     +beta*m*(2*D+d)*(2*A+2*alpha+d)
     +2*C*m*(4*D*beta+d*(D+beta)))/4
outer=[p22,p21,p12,p10,p02,p01]
for label,z in zip(['22','21','12','10','02','01'],outer):
    ck(all(t>0 for t in s.Poly(z,*cs).coeffs()),f'CG2 outer polynomial{label} has positive coefficients')
    ck(z.subs(d,0)!=0,f'CG2 outer coefficient{label} remains positive at d0 when events>0')
p11=s.expand(P.subs({u:1,v:1}).det(method='domain-ge')/16-sum(outer))
poly=s.Poly(0,u,v,*cs,domain=s.QQ)
entries=[[s.Poly(P[i,j],u,v,*cs,domain=s.QQ) for j in range(4)] for i in range(4)]
for perm in permutations(range(4)):
    term=s.Poly((-1)**sum(perm[i]>perm[j] for i in range(4) for j in range(i+1,4)),
                u,v,*cs,domain=s.QQ)
    for i,j in enumerate(perm): term*=entries[i][j]
    poly+=term
Q=p22*u**4*v**4+p21*u**4*v*v+p12*u*u*v**4+p11*u*u*v*v+p10*u*u+p02*v**4+p01*v*v
ck(poly==s.Poly(Du**2*Dv**2*Q,u,v,*cs,domain=s.QQ),
   'CG2 exact generic whole determinant from all24 permutation products')
exps=[(1,1),(1,0),(0,1),(0,-1),(-1,1),(-1,0)]
ck({(1,0),(-1,0),(0,1),(0,-1)}<=set(exps),
   'logarithmic support contains both signed coordinate directions')

# The five-shape contact matrix is completely exported as polynomial data.
a,b,t=s.symbols('a b t',real=True);psi=s.Matrix([a,b,t,1])
J=s.Matrix([[(M*psi)[i] for M in Pb] for i in range(4)]
           + [[(psi.T*M.diff(angle)*psi)[0] for M in Pb] for angle in (u,v)])
J=J.applyfunc(s.expand)
ck(J.shape==(6,7) and all(s.denom(z)==1 or s.denom(z)==2 for z in J),
   'CG9 has42 explicit polynomial entries with rational coefficients')
seed=json.loads((R/'inputs/C1_SATURATED_CONE_SEPARATOR.json').read_text())
coeff=list(map(s.Rational,seed['coefficients']))
pu,pv,pa,pb,pt=map(s.Rational,seed['parameters'])
angle={u:pu,v:pv};shape={u:pu,v:pv,a:pa,b:pb,t:pt};source=dict(zip(cs,coeff))
J0=J.subs(shape);ps=s.Matrix([pa,pb,pt,1]);P0=P.subs(source).subs(angle)
ck(J0*s.Matrix(coeff)==s.zeros(6,1),'seed satisfies all six complete contact equations')
minor=s.factor(J0[:,1:].det())
ck(minor!=0 and all(z!=0 for z in ps),'seed has nonzero state coordinates and event minor')
ck(-J0[:,1:].inv()*J0[:,0]==s.Matrix(coeff[1:]),'seed equals CG11 rational reconstruction')
H=P0[:3,:3]
ck(all(H[:i,:i].det()>0 for i in (1,2,3)),'seed strict hard state block')
ck(mz(P0.adjugate()-H.det()*ps*ps.T),'seed exact normalized kernel adjugate identity')
coreval=s.factor((ps.T*K.subs(angle)*ps)[0])
ck(coreval<0,'strict deficit derivative sign at exact seed')
L=Q/(u*u*v*v)
Ld=s.factor(L.diff(d).subs(source).subs(angle))
ck(Ld==s.factor(H.det()*coreval/(Du**2*Dv**2*u*u*v*v).subs(angle))<0,
   'CG8 cap derivative equals negative core times positive hard determinant')
weights=[s.factor(z.subs(source)*pu**(2*e[0])*pv**(2*e[1])) for z,e in zip(outer,exps)]
ck(all(z>0 for z in weights),'all six seed Laurent weights strictly positive')
ck(p11.subs(source)+sum(weights)==0,'seed zero log determinant')
ck(all(sum(w*e[i] for w,e in zip(weights,exps))==0 for i in (0,1)),
   'seed zero log gradient')
Hlog=sum((w*s.Matrix(e)*s.Matrix(e).T for w,e in zip(weights,exps)),s.zeros(2))
ck(Hlog[0,0]>0 and Hlog.det()>0,'seed strict log Hessian')

# Actual source involution and its nonzero regular reflected seed.
sigma=[0,2,1,5,6,3,4]
G=s.Matrix([[v,-1,0,0],[-1,-v,0,0],[0,0,-v,1],[0,0,1,v]])
ck(G*G.T==Dv*s.eye(4),'reflection state transform has positive norm factor')
P_sig=P.subs(dict(zip(cs,[cs[i] for i in sigma])),simultaneous=True)
ck(mz(u*u*Dv*P_sig.subs(u,1/u)-G*P*G.T),'exact full C1 coefficient involution')
ps_ref=G.subs(v,pv)*ps;ps_ref=ps_ref/ps_ref[3]
J_ref=J.subs({u:1/pu,v:pv,a:ps_ref[0],b:ps_ref[1],t:ps_ref[2]})
ck(J_ref*s.Matrix([coeff[i] for i in sigma])==s.zeros(6,1),'reflected six contact equations')
ck(all(z!=0 for z in ps_ref) and J_ref[:,1:].det()!=0,'reflected seed is also wholly regular')

# Deterministic support rows force every retained event coefficient >=0.
spec=[(1,1,1,-1),(1,0,-1,1),(0,0,-1,1),(1,1,-1,1),(0,1,-1,-1),(1,0,1,-1)]
detrows=[]
for av in product([-1,1],repeat=2):
    for bv in product([-1,1],repeat=2):
        hh=1-s.Rational(av[0]*bv[0]-av[0]*bv[1]+av[1]*bv[0]+av[1]*bv[1],2)
        row=[hh]+[(1+sg*av[x])*(1+tg*bv[y]) for x,y,sg,tg in spec]
        detrows.append((av+bv,row))
neighbors=[]
for i in range(1,7):
    matches=[pt for pt,row in detrows if row==[4*int(j==i) for j in range(7)]]
    ck(len(matches)>0,f'event{i} is one quarter of an actual deterministic support value')
    neighbors.append(matches[0])

# Actual order59 PSD blocks have a uniform finite evaluation trace bound.
new=json.loads((R/'inputs/C1_ENLARGED_PRIMAL.coo.json').read_text())
ck(s.expand(s.trace(4*P)-4*Du*Dv*sum(cs))==0,'original full trace is4DuDv times coefficient sum')
grid=s.expand(sum(((1+uu)*(1+vv)*s.trace(4*P).subs({u:uu,v:vv})
                  for uu,vv in product([1,2],repeat=2)),s.Integer(0)))
ck(grid==1444*sum(cs),'CG16 actual order59 four-point trace identity')
T=s.Matrix([[2,3],[3,5]])-s.eye(2)/7
ck(T[0,0]>0 and T.det()>0,'two-point monomial covariance strictly exceeds I/7')
moment_data=[]
for g,((al,be),fs) in enumerate(zip(new['weights'],new['features'])):
    B=s.Matrix([[sum(uu**(a+aa+al)*vv**(b+bb+be) for uu,vv in product([1,2],repeat=2))
                 if i==j else 0 for j,aa,bb in fs] for i,a,b in fs])
    _,DD=(B-s.eye(B.rows)/49).LDLdecomposition(hermitian=False)
    ck(all(z>0 for z in DD.diagonal()),f'actual block{g} feature covariance strictly exceeds I/49')
    moment_data.append([[str(z) for z in B.row(i)] for i in range(B.rows)])
ck(49*1444==70756,'CG17 exact uniform Gram trace constant')
for j,(g,i,k) in enumerate(new['free_positions']):
    off=new['blocks'][g]['offset']
    terms=[(var,s.Rational(val)) for var,ii,kk,val in new['entries'] if ii==off+i and kk==off+k]
    ck(terms==[(8+j,s.Integer(1))],f'actual auxiliary{j} is bounded by its free Gram entry')

data={'scope':'Exact polynomial chart and determinant/closure data; universal enlarged-frame selector NOT proved.',
      'normalization':'quarter-parent Pcal=Pfull/4',
      'source_order':list(map(str,cs)), 'shape_order':['p','q','a','b','t'],
      'polynomial_variable_translation':{'u':'p','v':'q'},
      'contact_matrix':[[str(z) for z in J.row(i)] for i in range(6)],
      'source_formula':'(1,-J_e^{-1}J_d)',
      'domain':'p,q>0; a*b*t!=0; det(J_e)!=0; all six components -J_e^{-1}J_d>0',
      'outer_exponents':exps,'outer_coefficients':list(map(str,outer)),
      'central_coefficient':str(p11),
      'seed_source':seed['coefficients'],'seed_shape':seed['parameters'],
      'seed_event_minor':str(minor),'seed_core_value':str(coreval),'seed_L_d':str(Ld),
      'seed_log_Hessian':[[str(z) for z in Hlog.row(i)] for i in range(2)],
      'reflected_seed_state':list(map(str,ps_ref)),
      'reflected_seed_event_minor':str(s.factor(J_ref[:,1:].det())),
      'deterministic_event_neighbors':neighbors,'order59_feature_covariances':moment_data,
      'Gram_trace_bound':70756}
(R/'C1_REGULAR_CONTACT_DOMAIN.json').write_text(json.dumps(data,indent=2)+'\n')
report={'status':'PASS','exact_checks':len(tests),'checks':tests,
        'analytic_scope':'CG1-CG18: candidate-independent reduction to regular positive sharp contacts, plus actual enlarged C1 closedness. No universal selector or global converse claimed.',
        'proof_sha256':sha(R/'c1_regular_contact_reduction.tex'),
        'checker_sha256':sha(Path(__file__).resolve()),
        'domain_data_sha256':sha(R/'C1_REGULAR_CONTACT_DOMAIN.json'),
        'inputs':{p:sha(R/'inputs'/p) for p in ['C1_ENLARGED_PRIMAL.coo.json','C1_SATURATED_CONE_SEPARATOR.json']}}
(R/'CHECK_C1_REGULAR_CONTACT_REDUCTION.json').write_text(json.dumps(report,indent=2)+'\n')
print('PASS',len(tests),'exact checks; full C1 regular-contact reduction; CG18 remains unproved')
