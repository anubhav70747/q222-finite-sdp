#!/usr/bin/env python3
"""Export the entire constant contact Gram fiber of the actual larger C1 frame.

All matrices are rational.  This is a complete affine parametrization, not
a claim that its four PSD inequalities are always feasible.
"""
from pathlib import Path
from collections import defaultdict
import hashlib
import json
import sympy as s

R=Path(__file__).resolve().parent
path=R/'inputs/C1_ENLARGED_PRIMAL.coo.json'
d=json.loads(path.read_text());checks=[]
def ck(x,name):
    if not bool(x):raise AssertionError(name)
    checks.append(name)
def sparse(M):return [[i,j,str(M[i,j])] for i in range(M.rows) for j in range(M.cols) if M[i,j]]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def add(out,f,g,weight,value):
    i,a,b=f;j,c,e=g
    out[a+c+weight[0],b+e+weight[1],min(i,j),max(i,j)]+=value

fs=d['features'];wt=d['weights'];orders=list(map(len,fs))
ck(orders==[14,15,14,15],'literal larger C1 frame orders')
coords=[];full=[];hcoords=[];compressed=[]
for g,(rows,weight) in enumerate(zip(fs,wt)):
    for i in range(len(rows)):
        for j in range(i,len(rows)):
            col=defaultdict(int);add(col,rows[i],rows[j],weight,1 if i==j else 2)
            coords.append((g,i,j));full.append(dict(col))
    last=rows[-1]
    for i in range(len(rows)-1):
        for j in range(i,len(rows)-1):
            col=defaultdict(int);factor=1 if i==j else 2
            add(col,rows[i],rows[j],weight,factor)
            add(col,rows[i],last,weight,-factor)
            add(col,last,rows[j],weight,-factor)
            add(col,last,last,weight,factor)
            hcoords.append((g,i,j));compressed.append({key:x for key,x in col.items() if x})
monomials=sorted({key for col in full for key in col});lookup={key:i for i,key in enumerate(monomials)}
L=s.zeros(len(monomials),len(full));M=s.zeros(len(monomials),len(compressed))
for j,col in enumerate(full):
    for key,value in col.items():L[lookup[key],j]=value
for j,col in enumerate(compressed):
    for key,value in col.items():M[lookup[key],j]=value
ck(L.shape==(148,450) and len(L.rref()[1])==148,'complete148-row full coefficient map')
ck(M.shape==(148,392),'all392 compressed symmetric entries retained')

# Read the full affine source+auxiliary map from the actual COO.
index={x:i for i,x in enumerate(coords)}
raw=s.zeros(450,309)
for variable,i,j,value in d['entries']:
    if i==58:
        ck(variable==1 and j==58 and s.Rational(value)==1,'literal scalar d')
        continue
    g=next(g for g,b in enumerate(d['blocks'][:4]) if b['offset']<=i<b['offset']+b['order'])
    off=d['blocks'][g]['offset']
    raw[index[g,i-off,j-off],variable-1]+=s.Rational(value)
E=L*raw[:,:7]
ck(L*raw[:,7:]==s.zeros(148,302),'every literal auxiliary cancels from physical target')
free_rows=[index[tuple(x)] for x in d['free_positions']]
ck(raw[free_rows,7:]==s.eye(302),'literal free-coordinate identity gives entire matching nullspace')

# Exact normalized complete contact constraints, in scalar coefficient form.
C=s.zeros(6,148)
for j,(a,b,i,k) in enumerate(monomials):
    C[i,j]+=s.Rational(1,2);C[k,j]+=s.Rational(1,2)
    C[4,j]=a;C[5,j]=b
ck(len(C.rref()[1])==6,'four state and two angular contact rows independent')
ck(C*M==s.zeros(6,392),'all compressed Gram directions obey entire contact')
ind=list(M.T.rref()[1]);ck(len(ind)==142,'full compressed coefficient rank142')
MR=M[ind,:];piv=list(MR.rref()[1]);free=[i for i in range(392) if i not in piv]
ck(len(piv)==142 and len(free)==250,'exact250 free contact coordinates')
inv=MR[:,piv].inv();free_map=-inv*MR[:,free];compat=M[:,piv]*inv
ck(MR[:,piv]*inv==s.eye(142),'exact constant pivot inverse')
ck(M[:,free]+M[:,piv]*free_map==s.zeros(148,250),'every affine free direction has zero full target')
ck(compat*MR==M,'all148 target rows restored from142 independent rows')
ck(148-142==C.rows,'the only target compatibility equations are the six physical contacts')

# The reflection and all six contact residuals are checked for the entire
# symbolic source, rather than inferred from a single regular seed.
domain_path=R/'C1_REGULAR_CONTACT_DOMAIN.json'
domain=json.loads(domain_path.read_text())
u,v,a,b,t=s.symbols('u v a b t',real=True)
local={str(x):x for x in (u,v,a,b,t)}
Jcontact=s.Matrix([[s.sympify(x,locals=local) for x in row] for row in domain['contact_matrix']])
cc=s.symbols('d m C A D alpha beta',real=True)
P=s.zeros(4)
for j,coef in enumerate(cc):
    basis=s.zeros(4)
    for i in range(4):
        for k,x in enumerate((a,b,t)):basis[i,k]=s.diff(Jcontact[i,j],x)
        basis[i,3]=Jcontact[i,j].subs({a:0,b:0,t:0})
    P+=coef*basis
phi=s.Matrix([a,b,t,1]);sigma=[0,2,1,5,6,3,4]
Ps=P.subs(dict(zip(cc,[cc[j] for j in sigma])),simultaneous=True)
G=s.Matrix([[v,-1,0,0],[-1,-v,0,0],[0,0,-v,1],[0,0,1,v]])
def mz(A):return all(s.cancel(x)==0 for x in A)
ck(G*G.T==(1+v*v)*s.eye(4),'full reflection norm identity')
ck(mz(u*u*(1+v*v)*Ps.subs(u,1/u)-G*P*G.T),'full generic original-parent reflection identity')
raw=G*phi;k=P*phi;au=(phi.T*P.diff(u)*phi)[0];av=(phi.T*P.diff(v)*phi)[0]
ck(mz(Ps.subs(u,1/u)*raw-G*k/u**2),'all four generic kernel residuals transform exactly')
au_ref=(raw.T*Ps.diff(u).subs(u,1/u)*raw)[0]
av_ref=(raw.T*Ps.diff(v).subs(u,1/u)*raw)[0]
ck(s.cancel(au_ref-(2*(1+v*v)*(phi.T*k)[0]/u-(1+v*v)*au))==0,
   'generic Alice angular residual has exact kernel-plus-derivative transform')
ck(s.cancel(av_ref-(2*v*(phi.T*k)[0]-2*((G.diff(v)*phi).T*G*k)[0]
                   +(1+v*v)*av)/u**2)==0,
   'generic Bob angular residual has exact kernel-plus-derivative transform')
normalized=raw/raw[3];twice=G*normalized;twice=twice/twice[3]
ck(mz(twice-phi),'the full normalized state reflection is an exact involution')

data={'status':'COMPLETE_CONSTANT_CONTACT_FIBER_UNIVERSAL_PSD_GATE_OPEN',
      'scope':'The actual order59 C1 coefficient cone after an arbitrary positive-angle/nonzero-state source contact normalization. No universal feasibility is claimed.',
      'features':fs,'weights':wt,'compressed_orders':[n-1 for n in orders],
      'monomials':monomials,'source_order':['d','m','C','A','D','alpha','beta'],
      'unscaled_physical_target_map_shape':list(E.shape),
      'unscaled_physical_target_map':sparse(E),
      'target_normalization':'For monomial row (r,s,i,j), multiply (E*c)[row] by p^r*q^s*psi_i*psi_j. Here psi=(a,b,t,1). This is the entire scalar target (1+pU)(1+qV)*chi^T P_c(pU,qV;diag(psi)) chi.',
      'gram_variables':hcoords,'coefficient_matrix_shape':list(M.shape),'coefficient_matrix':sparse(M),
      'contact_constraints':sparse(C),'contact_rank':6,
      'independent_rows':ind,'pivot_columns':piv,'free_columns':free,
      'pivot_rhs_map':sparse(inv),'pivot_free_map':sparse(free_map),
      'full_target_compatibility_map':sparse(compat),
      'rank':142,'free_dimension':250,
      'solution':'h_free=z; h_pivot=pivot_rhs_map*b[independent_rows]+pivot_free_map*z. Require b=full_target_compatibility_map*b[independent_rows] and all four symmetric H blocks PSD.',
      'restore':'G_g=p^(-alpha_g)*q^(-beta_g)*D_g^(-1)*S_g^T*H_g*S_g*D_g^(-1), with D_g=diag(p^r*q^s*psi_i) on the original features and S_g=[I|-1].',
      'reflection_contact_map':['1/p','q','(q*a-b)/(t+q)','(-a-q*b)/(t+q)','(1-q*t)/(t+q)'],
      'reflection_verified':'Full generic parent congruence, four kernel residuals, both angular residuals, and normalized state involution; no seed-only inference.',
      'contact_domain_input':{'path':domain_path.name,'sha256':sha(domain_path)},
      'input':{'path':'inputs/'+path.name,'sha256':sha(path)}}
dest=R/'C1_ENLARGED_REGULAR_CONTACT_SYSTEM.json';dest.write_text(json.dumps(data,indent=2)+'\n')
receipt={'status':'PASS','exact_checks':len(checks),'checks':checks,
         'scope':'Complete literal C1 larger contact-fiber parametrization; positive semidefinite selection over the regular source domain remains unproved.',
         'input':data['input'],'output':{'path':dest.name,'sha256':sha(dest)},
         'checker_sha256':sha(Path(__file__).resolve())}
(R/'CHECK_C1_ENLARGED_CONTACT_SYSTEM.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PASS',len(checks),'exact checks; complete148x392/rank142 contact map,250 free; universal PSD open')
