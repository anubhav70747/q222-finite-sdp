#!/usr/bin/env python3
"""Independent finite-data check of the OPEN normalized dual failure gates.

This does not solve either failure system. It compares the exported dual
rows to the independently read-back enlarged source arrays and reconstructs
every contact equation directly from the original Pauli operators.
"""
from pathlib import Path
from fractions import Fraction
import hashlib,json,time
import sympy as s

HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
started=time.time();checks=[];used=set()
def read(path):
    used.add(path);return json.loads(path.read_text())
def ck(name,p):
    if not p:raise AssertionError(name)
    checks.append(name)
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def matrix(d):
    M=s.zeros(d['rows'],d.get('cols',d.get('columns')))
    for i,j,v in d['entries']:M[i,j]+=s.Rational(v)
    return M
def zero(name,M):ck(name,all(s.cancel(x)==0 for x in M))
def positive(name,M):
    zero(name+' symmetry',M-M.T)
    a=[[Fraction(str(x)) for x in M.row(i)] for i in range(M.rows)]
    piv=[]
    for k in range(M.rows):
        z=a[k][k];ck(name+' positive LDL pivot '+str(k),z>0);piv.append(str(z))
        for i in range(k+1,M.rows):
            for j in range(i,M.rows):
                a[i][j]-=a[i][k]*a[k][j]/z;a[j][i]=a[i][j]
    return piv

u,v,a,b,t=s.symbols('u v a b t')
psi=s.Matrix([a,b,t,1]);I=s.eye(2);zz=s.diag(1,-1);xx=s.Matrix([[0,1],[1,0]])
du,dv=1+u*u,1+v*v
aa=[zz,((1-u*u)*zz+2*u*xx)/du]
bb=[zz,((1-v*v)*zz+2*v*xx)/dv]
kron=s.kronecker_product
core=s.eye(4)-(kron(aa[0],bb[0])-kron(aa[0],bb[1])+kron(aa[1],bb[0])+kron(aa[1],bb[1]))/2
events={'n':(1,-1,0,0),'m':(1,-1,1,1),'C':(-1,1,1,0),'A':(-1,1,0,0),
        'D':(-1,1,1,1),'alpha':(-1,-1,0,1),'beta':(1,-1,1,0)}
orders={'C1':['d','m','C','A','D','alpha','beta'],
        'C2':['d','n','m','C','A','D','alpha']}
records=[]
for fam in orders:
    ex=read(ROOT/'dual_gate'/(fam+'_NORMALIZED_DUAL_FAILURE_SYSTEM.json'))
    local=read(HERE/'compiled_enlarged'/(fam+'_QUALIFIED_DUAL.json'))
    raw_path=HERE/'inputs'/(fam+'_ENLARGED_PRIMAL.coo.json')
    raw=read(raw_path)
    ck(fam+' export binds exact current enlarged source bytes',ex['source_array_sha256']==sha(raw_path))
    ck(fam+' exact source coefficient order',ex['source_order']==orders[fam])
    labs=[tuple(z) for z in local['upper_triangle_order']]
    ck(fam+' every upper-triangle coordinate is in the same declared order',labs==list(map(tuple,ex['upper_dual_coordinates'])))
    L=matrix(local['source_coefficient_matrix'])
    adj=L.T*s.diag(*[1 if i==j else 2 for g,i,j in labs])
    zero(fam+' complete visible adjoint readback',matrix(ex['visible_adjoint'])-adj[:7,:])
    zero(fam+' complete auxiliary adjoint readback',matrix(ex['auxiliary_adjoint'])-adj[7:,:])
    trace=s.Matrix([[1 if i==j else 0 for g,i,j in labs]])
    zero(fam+' exact trace row',matrix(ex['trace_row'])-trace)
    lookup={z:i for i,z in enumerate(labs)}
    freecols=[lookup[tuple(z)] for z in raw['free_positions']]
    minor=adj[7:,freecols]
    ck(fam+' exact302 auxiliary rank from diagonal minor',minor.is_diagonal() and all(x!=0 for x in minor.diagonal()))
    ck(fam+' trace row independent of auxiliary rows on a scalar sign coordinate',
       all(adj[j,lookup[(4,0,0)]]==0 for j in range(7,309)) and trace[lookup[(4,0,0)]]==1)
    ck(fam+' exact normalized dual affine dimension154',ex['coordinate_count']==457 and ex['auxiliary_rank']==302 and ex['normalized_affine_hull_dimension']==154)
    y=s.Matrix(list(map(s.Rational,ex['strict_rational_dual_point'])))
    zero(fam+' every strict-dual auxiliary equation',adj[7:,:]*y)
    zero(fam+' strict dual has trace one',trace*y-s.ones(1,1))
    blocks=[s.zeros(n) for n in local['source_block_sizes']]
    for z,(g,i,j) in zip(y,labs):blocks[g][i,j]=blocks[g][j,i]=z
    piv=[positive(fam+' strict dual block'+str(g),M) for g,M in enumerate(blocks)]
    operators=[core]
    for name in orders[fam][1:]:
        xval,yval,x,yin=events[name]
        operators.append(kron(I+xval*aa[x],I+yval*bb[yin]))
    parents=[(du*dv*M).applyfunc(s.cancel) for M in operators]
    J=s.Matrix.hstack(*[(M*psi).col_join(s.Matrix([(psi.T*M.diff(u)*psi)[0],
                    (psi.T*M.diff(v)*psi)[0]])) for M in parents])
    exported=s.Matrix([[s.sympify(z,locals={'u':u,'v':v,'a':a,'b':b,'t':t})
                        for z in row] for row in ex['contact_matrix_polynomials']])
    for i in range(6):
        for j in range(7):zero(fam+' original Pauli contact polynomial (%d,%d)'%(i,j),s.Matrix([J[i,j]-exported[i,j]]))
    predicate=ex['uneliminated_regular_source_predicate']
    ck(fam+' all exact regular-domain guards retained',predicate==[
        'u>0','v>0','a*b*t!=0','det(J[:,1:])!=0','c0=1',
        'c1>0','c2>0','c3>0','c4>0','c5>0','c6>0','J*c=0'])
    if fam=='C1':ck(fam+' correct visible source reflection',ex['sigma_zero_based_source_permutation']==[0,2,1,5,6,3,4])
    ck(fam+' export states universal emptiness has not been decided',ex['status']=='EXACT_FINITE_GATE_INPUT; UNIVERSAL_EMPTINESS_NOT_DECIDED')
    records.append({'family':fam,'normalized_dual_dimension':154,'contact_polynomial_count':42,
                    'strict_normalized_dual_LDL_pivots':piv,'universal_failure_system':'UNDECIDED'})

proof=ROOT/'normalized_dual_gate.tex'
out={'status':'PASS_INDEPENDENT_FINITE_GATE_DATA_AND_SCOPED_ANALYTICAL_REVIEW',
     'scope':'DG1–DG9 finite normalization and equivalence only; neither universal gate nor emptiness assertion is proved.',
     'checks_passed':len(checks),'checks':checks,'families':records,
     'analytical_review':['Trace-one PSD blocks give a compact dual base with an explicit interior point.','302 independent auxiliary equations plus the independent trace give affine dimension154.','Actual source Slater gives exact trace-adjoint duality; bounded-Gram closedness supplies strict separation outside the candidate, so DG4 is an equivalence.','Regular contact event-minor rank makes the C1 ray extreme; only on that domain is the two-orientation disjunction equivalent to the saturated cone.','Clearing the event minor by its square preserves every strict inequality; the resulting failure systems are exact semialgebraic predicates.','A zero objective from the physical contact is an upper bound only, as DG9 states.'],
     'proof':{'path':str(proof.relative_to(ROOT)),'sha256':sha(proof)},
     'inputs':[{'path':str(p.relative_to(ROOT)),'sha256':sha(p)} for p in sorted(used)],
     'checker':{'path':'routing/'+Path(__file__).name,'sha256':sha(Path(__file__))},
     'seconds':time.time()-started}
(HERE/'NORMALIZED_DUAL_GATE_INDEPENDENT_REVIEW.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'checks':len(checks),'seconds':out['seconds']}))
