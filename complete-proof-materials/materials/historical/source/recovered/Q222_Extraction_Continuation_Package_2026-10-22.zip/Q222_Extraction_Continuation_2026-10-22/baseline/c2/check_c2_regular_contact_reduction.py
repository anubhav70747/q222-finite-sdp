#!/usr/bin/env python3
"""Exact algebra supporting the candidate-independent C2 cap reduction.

This verifies the actual two affine dictionaries, the full determinant,
the regular positive-event contact, the closure bounds, and both complete
contact coefficient systems.  It does not decide universal PSD feasibility.
No numerical optimizer or historical status receipt is imported.
"""
from pathlib import Path
from collections import defaultdict
from fractions import Fraction
import hashlib
import json
import sympy as s

HERE = Path(__file__).resolve().parent
CHECKS = []


def require(name, condition):
    if not condition:
        raise AssertionError(name)
    CHECKS.append(name)


def zero(name, value):
    require(name, s.cancel(value) == 0)


def sparse(M):
    return [[i, j, str(M[i, j])] for i in range(M.rows)
            for j in range(M.cols) if M[i, j]]


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


u, v = s.symbols('u v')
W, X, Y, Z = state = s.symbols('W X Y Z')
d, n, m, C, A, D, alpha = coeff = s.symbols('d n m C A D alpha')
du, dv = 1+u*u, 1+v*v
P = (n*du*dv*X*X + m*(v*W-X+u*v*Y-u*Z)**2
     + C*dv*(u*W-Y)**2 + A*du*dv*Y*Y
     + (D+d/2)*(u*W+u*v*X-Y-v*Z)**2
     + (alpha+d/2)*du*(v*Y-Z)**2
     + d/2*dv*(X+u*Z)**2-d/2*du*dv*Z*Z)
P = s.expand(P)
F = 4*P
M = s.hessian(P, state)/2
K = s.diff(P, d)
zero('GR3 complete signed core at Z=0',
     K.subs(Z, 0)-((u*W+u*v*X-Y)**2+du*v*v*Y*Y+dv*X*X)/2)
zero('positive core rows independent at uv nonzero',
     s.Matrix([[u, u*v, -1], [0, 0, v], [0, 1, 0]]).det()+u*v)

for name, subst in [('Alice', {u:-u, Y:-Y, Z:-Z}),
                    ('Bob', {v:-v, X:-X, Z:-Z})]:
    zero('full parent '+name+' sign gauge', P.subs(subst, simultaneous=True)-P)

det = s.cancel(M.det(method='domain-ge')/(du*du*dv*dv))
det_terms = s.Poly(det, u, v).as_dict()
outer = {
    (4, 2): A*C*(2*D+d+2*n)*(2*alpha+d+2*m)/4,
    (4, 0): A*n*(2*C+2*D+d)*(2*alpha+d+2*m)/4,
    (2, 4): C*D*(d+2*n)*(2*A+2*alpha+d+2*m)/4,
    (2, 0): A*alpha*(2*C+2*D+d)*(d+2*m+2*n)/4,
    (0, 4): D*m*(d+2*n)*(2*A+2*C+2*alpha+d)/4,
    (0, 2): alpha*m*(d+2*n)*(2*A+2*C+2*D+d)/4,
}
require('GR2 exact determinant support', set(det_terms) == set(outer)|{(2, 2)})
for key, value in outer.items():
    zero('GR2 factored outer coefficient '+str(key), det_terms[key]-value)
zero('GR2 central coefficient from M(1,1)',
     det_terms[(2, 2)]-M.subs({u:1, v:1}).det()/16+sum(outer.values()))
require('six outer exponents span and surround origin',
        {(a//2-1, b//2-1) for a,b in outer}
        == {(1,0),(0,1),(1,-1),(-1,1),(0,-1),(-1,0)})

base = [s.Integer(1), s.Rational(7,8), s.Rational(9,8), s.Rational(1,18),
        s.Rational(11,8), s.Rational(9,8), s.Rational(1,18)]
ps = s.Matrix([1, -s.Rational(1,10), s.Rational(1,10), 1])
test = {u:1, v:1, **dict(zip(state, ps))}
source = dict(zip(coeff, base))
Jcols = []
for c in coeff:
    Mc = M.diff(c)
    Jcols.append((Mc.subs({u:1,v:1})*ps).col_join(s.Matrix([
        (ps.T*Mc.diff(u).subs({u:1,v:1})*ps)[0],
        (ps.T*Mc.diff(v).subs({u:1,v:1})*ps)[0]])))
J = s.Matrix.hstack(*Jcols)
require('GR5 all seven coefficients strictly positive', all(x>0 for x in base))
require('GR5 all four state coordinates nonzero', all(x != 0 for x in ps))
require('GR5 entire six-equation contact', J*s.Matrix(base) == s.zeros(6,1))
event_minor = J[:,1:].det()
require('GR11 actual event contact minor nonzero', event_minor != 0)
core_value = K.subs(test)
require('GR5 fixed contact is a strict negative-core test', core_value < 0)
require('GR5 exact upper state block positive', all(
    M.subs(source).subs({u:1,v:1})[:i,:i].det()>0 for i in (1,2,3)))
for key, value in outer.items():
    require('GR5 strict Laurent mass '+str(key), value.subs(source)>0)

seed_record = {
    'visible_order': [str(c) for c in coeff],
    'coefficients': list(map(str,base)),
    'contact_angles': ['1','1'], 'state': list(map(str,ps)),
    'contact_matrix': [[str(x) for x in row] for row in J.tolist()],
    'event_minor': str(event_minor), 'quarter_core_value': str(core_value),
    'physicality_proof': 'Positive upper state block and stationary zero of the convex logarithmic Laurent determinant; GR2-GR5.',
}
(HERE/'c2_regular_contact_seed.json').write_text(json.dumps(seed_record,indent=2)+'\n')


def add_product(out, f, g, weight, fac):
    i,a,b=f; j,c,e=g
    out[(a+c+weight[0], b+e+weight[1], min(i,j), max(i,j))] += fac


def polynomial_dict(poly):
    out = {}
    for powers, value in s.Poly(s.expand(poly),u,v,*state).terms():
        a,b,*ss = powers
        indices = [i for i,k in enumerate(ss) for _ in range(k)]
        assert len(indices)==2
        out[(a,b,*indices)] = value
    return out


def audit_dictionary(filename, multiplier, expected_orders, expected_rank,
                     expected_aux, expected_comp_rank, expected_free):
    path = HERE/'inputs'/filename
    data = json.loads(path.read_text())
    features, weights = data['features'], data['weights']
    orders = list(map(len,features))
    name = 'old' if multiplier==1 else 'enlarged'
    require(name+' actual feature block orders', orders == expected_orders)
    require(name+' features have separate degree at most one',
            all(0<=a<=1 and 0<=b<=1 and 0<=i<4
                for block in features for i,a,b in block))
    coords=[]; cols=[]; ccols=[]; ccoords=[]
    for k,(block,wt) in enumerate(zip(features,weights)):
        for i in range(len(block)):
            for j in range(i,len(block)):
                dd=defaultdict(int)
                add_product(dd,block[i],block[j],wt,1 if i==j else 2)
                cols.append(dict(dd)); coords.append((k,i,j))
        last=block[-1]
        for i in range(len(block)-1):
            for j in range(i,len(block)-1):
                dd=defaultdict(int); fac=1 if i==j else 2
                add_product(dd,block[i],block[j],wt,fac)
                add_product(dd,block[i],last,wt,-fac)
                add_product(dd,last,block[j],wt,-fac)
                add_product(dd,last,last,wt,fac)
                ccols.append({key:val for key,val in dd.items() if val})
                ccoords.append((k,i,j))
    monomials=sorted({key for col in cols for key in col})
    index={key:i for i,key in enumerate(monomials)}
    L=s.zeros(len(monomials),len(cols))
    for j,col in enumerate(cols):
        for key,val in col.items(): L[index[key],j]=val
    R=s.zeros(len(monomials),len(ccols))
    for j,col in enumerate(ccols):
        for key,val in col.items(): R[index[key],j]=val
    require(name+' full coefficient map rank', len(L.rref()[1])==expected_rank)
    lookup={p:i for i,p in enumerate(coords)}
    offsets=[b['offset'] for b in data['blocks'][:4]]
    Bmat=s.zeros(len(coords),len(data['variables']))
    scalar_index=sum(orders)
    for variable,i,j,value in data['entries']:
        if i==scalar_index:
            require(name+' literal d scalar',
                    j==scalar_index and variable==1 and s.Rational(value)==1)
            continue
        assert variable>0
        k=next(k for k,(off,order) in enumerate(zip(offsets,orders))
               if off<=i<off+order and off<=j<off+order)
        Bmat[lookup[(k,i-offsets[k],j-offsets[k])],variable-1]+=s.Rational(value)
    target=s.zeros(len(monomials),len(data['variables']))
    for j,c in enumerate(coeff):
        for key,value in polynomial_dict(multiplier*F.diff(c)).items():
            target[index[key],j]=value
    require(name+' complete actual COO affine identity', L*Bmat==target)
    aux=Bmat[:,7:]
    require(name+' exact full affine nullspace dimension',
            aux.cols==expected_aux==L.cols-expected_rank)
    if 'free_positions' in data:
        fp=[lookup[tuple(pos)] for pos in data['free_positions']]
        require(name+' auxiliary free-coordinate identity', aux[fp,:]==s.eye(expected_aux))
    else:
        require(name+' auxiliary directions independent',len(aux.rref()[1])==expected_aux)

    # The complete six contact constraints at normalized contact 1.
    contact=s.zeros(6,len(monomials))
    for j,(a,b,i,k) in enumerate(monomials):
        contact[i,j]+=s.Rational(1,2)
        contact[k,j]+=s.Rational(1,2)
        contact[4,j]=a; contact[5,j]=b
    require(name+' normalized contact constraints rank six',len(contact.rref()[1])==6)
    require(name+' all compressed columns satisfy all contact equations',contact*R==s.zeros(6,R.cols))
    independent_rows=list(R.T.rref()[1])
    require(name+' complete compressed rank',len(independent_rows)==expected_comp_rank)
    require(name+' no missing contact compatibility equations',expected_rank-expected_comp_rank==6)
    RR=R[independent_rows,:]
    pivots=list(RR.rref()[1]); free=[i for i in range(R.cols) if i not in pivots]
    require(name+' exact contact free dimension',len(free)==expected_free)
    Binv=RR[:,pivots].inv()
    compatibility=R[:,pivots]*Binv
    require(name+' every free column reconstructed',
            R[:,free]==compatibility*RR[:,free])
    require(name+' pivot inverse exact',RR[:,pivots]*Binv==s.eye(expected_comp_rank))

    # Explicit trace/closure control for the actual retained rows.
    for k,(block,wt) in enumerate(zip(features,weights)):
        covariance=s.zeros(len(block))
        for a in (1,2):
            for b in (1,2):
                for st in range(4):
                    ff=s.Matrix([a**aa*b**bb if ii==st else 0 for ii,aa,bb in block])
                    covariance+=a**wt[0]*b**wt[1]*ff*ff.T
        _, diag=(covariance-s.eye(len(block))/49).LDLdecomposition(hermitian=False)
        require(name+' exact covariance > I/49 block '+str(k),all(x>0 for x in diag.diagonal()))
    trace_sum=sum((4*multiplier*M.trace()).subs({u:a,v:b})
                  for a in (1,2) for b in (1,2))
    trace_factor=196 if multiplier==1 else 1444
    zero(name+' exact entire trace sum',trace_sum-trace_factor*sum(coeff))

    record={
        'status':'EXACT_COMPLETE_CONTACT_SYSTEM_UNIVERSAL_PSD_GATE_OPEN',
        'source_domain':'GR9: p,q>0, a*b*t!=0, det J_e!=0, -J_e^-1 J_d>0; source c=(1,-J_e^-1 J_d).',
        'target':'F' if multiplier==1 else '(1+u)(1+v)F',
        'features':features,'weights':weights,
        'compressed_orders':[k-1 for k in orders],
        'monomials':monomials,'gram_variables':ccoords,
        'coefficient_matrix_shape':list(R.shape),'coefficient_matrix':sparse(R),
        'contact_constraint_matrix':sparse(contact),
        'independent_rows':independent_rows,'pivot_columns':pivots,'free_columns':free,
        'pivot_rhs_map':sparse(Binv),'pivot_free_map':sparse(-Binv*RR[:,free]),
        'full_target_compatibility_map':sparse(compatibility),
        'rank':expected_comp_rank,'free_dimension':expected_free,
        'solution':'h_free=z; h_pivot=Binv*b[independent_rows]+pivot_free_map*z; impose b=compatibility*b[independent_rows] and every compressed block PSD.',
        'source_normalization':'u=pU, v=qV, state=diag(a,b,t,1)*chi; target coefficient [r,s,i,j] multiplied by p^r q^s psi_i psi_j.',
        'closure_trace_bound':49*trace_factor,
        'input':{'path':'inputs/'+filename,'sha256':sha(path)}}
    destination=HERE/('c2_'+name+'_regular_contact_system.json')
    destination.write_text(json.dumps(record,indent=2)+'\n')
    return {'name':name,'input':record['input'],'output':{'path':destination.name,'sha256':sha(destination)},
            'orders':orders,'full_coefficient_rank':expected_rank,
            'auxiliary_count':expected_aux,'compressed_rank':expected_comp_rank,
            'compressed_free_dimension':expected_free,'trace_bound':49*trace_factor}


old=audit_dictionary('C2_RAMIFIED_PRIMAL.coo.json',s.Integer(1),[14,6,6,4],78,79,72,55)
large=audit_dictionary('C2_ENLARGED_PRIMAL.coo.json',(1+u)*(1+v),[15,14,14,15],148,302,142,250)

# Six event packets in the old unweighted feature space.  Their simple
# source-independent roots establish membership before an affine coordinate
# assignment: the full-nullspace audit above supplies those coordinates.
roots={
    n:[X,u*X,v*X,u*v*X],
    m:[v*W-X+u*v*Y-u*Z],
    C:[u*W-Y,u*v*W-v*Y],
    A:[Y,u*Y,v*Y,u*v*Y],
    D:[u*W+u*v*X-Y-v*Z],
    alpha:[v*Y-Z,u*v*Y-u*Z]}
old_data=json.loads((HERE/'inputs/C2_RAMIFIED_PRIMAL.coo.json').read_text())
old_features={tuple(f) for f in old_data['features'][0]}
for c, rr in roots.items():
    zero('literal event SOS '+str(c),P.diff(c)-sum(z*z for z in rr))
    all_supported=True
    for root in rr:
        for powers,value in s.Poly(root,u,v,*state).terms():
            aa,bb,*ss=powers
            assert sum(ss)==1
            st=ss.index(1)
            all_supported &= (st,aa,bb) in old_features
    require('literal event roots in actual old dictionary '+str(c),all_supported)

proof=HERE/'c2_regular_contact_reduction.tex'
receipt={
    'status':'PASS_EXACT_REDUCTION_INPUTS_AND_ACTUAL_DICTIONARIES',
    'assertion_count':len(CHECKS),'checks':CHECKS,
    'proof':{'path':proof.name,'sha256':sha(proof)},
    'checker':{'path':Path(__file__).name,'sha256':sha(Path(__file__))},
    'seed':{'path':'c2_regular_contact_seed.json','sha256':sha(HERE/'c2_regular_contact_seed.json')},
    'dictionaries':[old,large],
    'analytic_gate':'GR4-GR13 prove the cap, analytic density and boundary reduction; these conclusions are mathematical arguments, not inferred from assertion count.',
    'open_gate':'GR17 universal PSD choice: 55 free coordinates for old R2, or 250 for enlarged K2.',
    'numeric_solver_used':False}
(HERE/'check_c2_regular_contact_reduction.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'assertions':len(CHECKS),
                  'event_minor':str(event_minor),'quarter_core_value':str(core_value),
                  'dictionaries':[{k:v for k,v in x.items() if k not in ('input','output')} for x in (old,large)]},indent=2))
