#!/usr/bin/env python3
"""Exact current-array replay of the recovered two-frame C1 obstruction.

Only the standard library and SymPy are required.  No optimization or saved
acceptance status is used.  The script writes only its own adjacent receipt.
The physical operator is rebuilt from the original Pauli/event definition.
"""
from pathlib import Path
from fractions import Fraction as Q
from itertools import permutations
import hashlib
import json
import sympy as s

ROOT = Path(__file__).resolve().parent
checks = []


def ck(condition, name):
    if not bool(condition):
        raise AssertionError(name)
    checks.append(name)


def load(name):
    return json.loads((ROOT / "inputs" / name).read_text())


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def strict_ldl(rows):
    a = [[Q(x) for x in row] for row in rows]
    n = len(a)
    ck(all(len(row) == n for row in a), "dual block square")
    ck(all(a[i][j] == a[j][i] for i in range(n) for j in range(n)),
       "dual block symmetric")
    pivots = []
    for k in range(n):
        z = a[k][k]
        ck(z > 0, f"strict rational LDL pivot {n}:{k}")
        pivots.append(str(z))
        for i in range(k + 1, n):
            for j in range(i, n):
                a[j][i] = a[i][j] = a[i][j] - a[i][k] * a[k][j] / z
    return pivots


pr = load("C1_RAMIFIED_PRIMAL.coo.json")
old = load("HISTORICAL_C1_RAMIFIED_PRIMAL.coo.json")
cert = load("C1_SATURATED_CONE_SEPARATOR.json")
changed = [key for key in old if old[key] != pr.get(key)]
ck(set(old) == set(pr), "historical/current metadata keys identical")
ck(set(changed) == {"scope", "whole_master_equality"},
   "only scope metadata differ; every mathematical array identical")
ck(pr["matrix_order"] == 31 and pr["visible_count"] == 7
   and pr["auxiliary_count"] == 79, "actual order-31 candidate dimensions")
ck([b["order"] for b in pr["blocks"]] == [14, 6, 6, 4, 1],
   "four ramified PSD blocks and scalar d")

# Rebuild the normalized physical matrix directly from the Pauli operators.
u, v = s.symbols("u v", real=True)
eye, zz = s.eye(2), s.diag(1, -1)
xx = s.Matrix([[0, 1], [1, 0]])
aa = [zz, ((1-u*u)*zz + 2*u*xx)/(1+u*u)]
bb = [zz, ((1-v*v)*zz + 2*v*xx)/(1+v*v)]
kron = s.kronecker_product
core = s.eye(4) - (kron(aa[0],bb[0])-kron(aa[0],bb[1])
                    +kron(aa[1],bb[0])+kron(aa[1],bb[1]))/2
events = [(1,1,1,-1), (1,0,-1,1), (0,0,-1,1),
          (1,1,-1,1), (0,1,-1,-1), (1,0,1,-1)]
normalized = [core] + [kron(eye+a*aa[x], eye+b*bb[y])
                       for x,y,a,b in events]
basis = [((1+u*u)*(1+v*v)*a).applyfunc(lambda z:s.cancel(z).expand())
         for a in normalized]

# Universal whole-parent identity for the actual candidate, separately for
# each visible and auxiliary direction; off-diagonal Gram entries mirrored.
got = [s.zeros(4) for _ in range(87)]
for variable, gi, gj, value in pr["entries"]:
    block = next(g for g,b in enumerate(pr["blocks"])
                 if b["offset"] <= gi < b["offset"]+b["order"])
    info = pr["blocks"][block]
    ck(info["offset"] <= gj < info["offset"]+info["order"],
       "COO entry remains in its declared block")
    if block == 4:
        ck(variable == 1 and gi == gj and s.Rational(value) == 1,
           "fifth block is exactly d")
        continue
    i, a, b = pr["features"][block][gi-info["offset"]]
    j, c, d = pr["features"][block][gj-info["offset"]]
    wu, wv = pr["weights"][block]
    monomial = s.Rational(value)*u**(a+c+wu)*v**(b+d+wv)
    got[variable][i,j] += monomial
    if gi != gj:
        got[variable][j,i] += monomial
for k, matrix in enumerate(got):
    target = basis[k-1] if 1 <= k <= 7 else s.zeros(4)
    ck((matrix-target).applyfunc(s.expand) == s.zeros(4),
       f"full original physical-parent coefficient identity {k}")

co = list(map(s.Rational, cert["coefficients"]))
p, q, w, x, y = map(s.Rational, cert["parameters"])
psi = s.Matrix([w,x,y,1])
at = {u:p,v:q}
ck((p,q,w,x,y) == (s.Rational(1,13),16,140,-s.Rational(1,32),
                   s.Rational(1,50)), "exact remembered contact")
ck(co[0] == 1 and all(c > 0 for c in co), "all seven source coordinates positive")
P = sum((c*a for c,a in zip(co,basis)), s.zeros(4))
contact = s.Matrix([[(a.subs(at)*psi)[j] for a in basis] for j in range(4)]
                   + [[(psi.T*a.diff(t).subs(at)*psi)[0] for a in basis]
                      for t in (u,v)])
ck(contact*s.Matrix(co) == s.zeros(6,1), "four full kernel and two angular equations")
minor = s.factor(contact[:,1:].det())
ck(minor != 0, "six event coordinates uniquely fixed by d=1 contact")
solved = [-s.factor(z) for z in contact[:,1:].inv()*contact[:,0]]
ck(solved == co[1:], "source independently reconstructed from contact")

# Physicality: the signed core has precisely three positive and one negative
# eigenvalues on uv != 0.  The six event matrices are nonnegative additions.
B = s.Matrix.hstack(s.Matrix([u,u*v,-1,-v]), s.Matrix([0,1,0,u]),
                    s.Matrix([0,0,v,-1]), s.Matrix([0,0,0,1]))
ck(s.expand(B.det()) == u*v, "core congruence invertible for uv nonzero")
ck((basis[0]-2*B*s.diag(1,1+v*v,1+u*u,
                       -(1+u*u)*(1+v*v))*B.T).applyfunc(s.expand)==s.zeros(4),
   "full original signed-core inertia identity")
polys = [[s.Poly(P[i,j],u,v,domain=s.QQ) for j in range(4)] for i in range(4)]
det = s.Poly(0,u,v,domain=s.QQ)
for perm in permutations(range(4)):
    term = s.Poly((-1)**sum(perm[i] > perm[j] for i in range(4)
                           for j in range(i+1,4)),u,v,domain=s.QQ)
    for i,j in enumerate(perm):
        term *= polys[i][j]
    det += term
quotient, remainder = s.div(det,s.Poly(16*(1+u*u)**2*(1+v*v)**2,
                                     u,v,domain=s.QQ))
ck(remainder.is_zero, "whole determinant has declared exact factor")
qc = {}
for (i,j),a in quotient.terms():
    ck(i%2==0 and j%2==0, "reduced determinant has even exponents")
    qc[(i//2,j//2)] = a
ck(set(qc) == {(2,2),(2,1),(1,2),(1,1),(1,0),(0,2),(0,1)},
   "actual determinant seven-term support")
ck(all(a > 0 for ij,a in qc.items() if ij != (1,1)),
   "six outer Laurent coefficients strictly positive")
weighted = [(ij[0]-1,ij[1]-1,a*p**(2*ij[0]-2)*q**(2*ij[1]-2))
            for ij,a in qc.items() if ij != (1,1)]
ck(qc[(1,1)]+sum(t[2] for t in weighted) == 0,
   "Laurent sum is zero at contact")
for k in (0,1):
    ck(sum(t[k]*t[2] for t in weighted) == 0,
       f"positive Laurent exponents balanced in coordinate {k}")
ck(s.Matrix([[t[0],t[1]] for t in weighted]).rank()==2,
   "strict convex log determinant has two-dimensional exponent span")

# Literal separator: compare every trace with current COO, not historical
# acceptance output or a contact-compressed surrogate.
h = [s.factor((psi.T*a.subs(at)*psi)[0]) for a in basis]
ell = list(map(s.Rational,cert["common_separator"]))
ck(h == list(map(s.Rational,cert["physical_evaluation_coefficients"])),
   "historical evaluation equals FULL original parent, not quarter parent")
ck(ell == [93424*h[i]-(1 if i==0 else 0) for i in range(7)],
   "exact common separator normalization")
ck(sum(a*b for a,b in zip(ell,co)) == -1, "common separator pairing equals -1")
sigma = [0,2,1,5,6,3,4]
orientation_results = []
for ori in cert["orientation_certificates"]:
    orientation = ori["orientation"]
    blocks = [[[Q(z) for z in row] for row in G] for G in ori["dual_blocks"]]
    pivots = [strict_ldl(G) for G in blocks]
    traces = [Q(0) for _ in range(87)]
    for variable, gi, gj, value in pr["entries"]:
        block = next(g for g,b in enumerate(pr["blocks"])
                     if b["offset"] <= gi < b["offset"]+b["order"])
        if block==4:
            continue
        off = pr["blocks"][block]["offset"]
        traces[variable] += Q(value)*(1 if gi==gj else 2)*blocks[block][gi-off][gj-off]
    ck(traces[0] == 0, f"orientation {orientation} has zero constant")
    for k in range(8,87):
        ck(traces[k] == 0, f"orientation {orientation} annihilates current auxiliary {k-8}")
    target = ell if orientation==0 else [ell[i] for i in sigma]
    for i in range(7):
        ck(Q(target[i])-traces[i+1] == (1 if i==0 else 0),
           f"orientation {orientation} visible trace {i} plus scalar d")
    orientation_results.append({"orientation":orientation,
                                "positive_ldl_pivots":pivots,
                                "visible_trace_values":list(map(str,traces[1:8])),
                                "scalar_residual":"1",
                                "all_79_auxiliary_traces_zero":True})

nonsharp = cert["nonsharp_counterexample"]
cm = list(map(s.Rational,nonsharp["coefficients"]))
delta = s.Rational(nonsharp["deficit_decrease"])
ck(0 < delta < 1 and cm == [1-delta,*co[1:]],
   "nonsharp source is a physical convex deficit reduction")
ck(sum(a*b for a,b in zip(ell,cm)) == s.Rational(nonsharp["negative_pairing"]) < 0,
   "strict exclusion persists at positive nonsharp source")

report = {
    "status":"PASS", "exact_checks":len(checks), "checks":checks,
    "claim":"The CURRENT recovered C1 cone R1 plus sigma(R1) is strictly smaller than the physical C1 cone.",
    "not_claimed":"No impossibility of other finite SDP lifts; C2 and enlarged-degree frames are not decided here.",
    "normalization":"P=(1+u^2)(1+v^2)M=4 times the quarter-parent; current COO represents P.",
    "source_order":["d","m","C","A","D","alpha","beta"],
    "source":list(map(str,co)), "parameters":cert["parameters"],
    "event_contact_determinant":str(minor),
    "reduced_determinant_coefficients":{str(k):str(a) for k,a in qc.items()},
    "positive_balanced_Laurent_weights":[list(map(str,t)) for t in weighted],
    "separator":list(map(str,ell)), "negative_pairing":"-1",
    "orientation_results":orientation_results,
    "historical_current_differences":changed,
    "inputs":{name:sha(ROOT/"inputs"/name) for name in (
        "C1_RAMIFIED_PRIMAL.coo.json", "HISTORICAL_C1_RAMIFIED_PRIMAL.coo.json",
        "C1_SATURATED_CONE_SEPARATOR.json")},
    "checker_sha256":sha(Path(__file__).resolve()),
}
(ROOT/"CHECK_TWO_FRAME_CORRECTION.json").write_text(json.dumps(report,indent=2)+"\n")
print("PASS",len(checks),"exact checks; current two-frame candidate refuted at pairing -1")
