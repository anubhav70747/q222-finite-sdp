# Why the printed global candidate is a strict outer relaxation

## 1. An extreme physical support

Let f* be the affine Bell functional corresponding to c* in
TWO_FRAME_REFUTATION.md. It vanishes at exactly two deterministic behaviors.
The verifier computes those two behaviors and the full 8-by-9 matrix
consisting of their evaluation rows, four contact-kernel rows, and two
contact-stationarity rows. This matrix has rank eight, with a printed exact
nonzero minor.

Suppose f*=f1+f2, where both summands are nonnegative on the quantum set.
Their values at each of the two deterministic zeros are nonnegative and
sum to zero, so both inherit the zeros. At the quantum contact, each
physical matrix is PSD and their zero total expectation forces each to
annihilate the state. Their fixed-state expectations have minima at the
same interior measurement pair, so both angle derivatives vanish.

The rank-eight linear system forces each fi to be a scalar multiple of f*.
The scalar is nonnegative because f* is positive at some quantum behavior.
Thus f* is an extreme ray of the full cone of quantum-valid affine supports.
This argument does not suppose nonnegative canonical coefficients for the
summands in advance.

## 2. All 192 frame embeddings are checked

The consumer solves the exact affine coefficient embedding equations for
f* in every member of the published frame list. Only two embeddings have
a nonnegative local coefficient vector:

C1_g030 with local coefficients c*,
C1_g048 with local coefficients sigma(c*).

Every other frame either cannot represent this affine functional in its
seven-column span or requires a negative canonical coefficient. The two
remaining possibilities are both excluded by the common separator.

If f* belonged to the conic sum of all frame images, extremality would
force each nonzero summand to be a nonnegative multiple of f*. No summand
can be such a multiple. Therefore f* is not in that conic sum K.

## 3. Closedness and normalization make the global gap genuine

Each certificate cone is closed, by the previously verified bounded-Gram
property. Every embedding has first row (1,...,1), and every coefficient
vector of a certificate cone is nonnegative. A convergent sequence of
conic sums therefore bounds each coefficient mass, so K is closed.

K is contained in the full physical-support cone P_Q and f* is in P_Q but
not K. Conic separation gives a functional in K* that is negative on f*.
The event rays occur in K; their transported images cover all sixteen
probability events, as the consumer checks. Consequently the homogeneous
coordinate of a nonzero point of K* is positive: it is nonnegative by
summing event inequalities, and a zero homogeneous coordinate forces all
event values and all eight behavior coordinates to vanish. Normalize that
coordinate to one.

It follows that the already published 192-frame set O strictly contains
Q222. This is a mathematical strictness proof, not an explicitly printed
nonquantum behavior with 13,824 auxiliary values. No such behavioral
witness is claimed in this release.

The same conclusion survives adding the 64 reciprocal-symmetric C2 slice
images. Each is a subcone of a transported physical C2 master. An extreme
positive C1 cap cannot belong to any such image: the exact deterministic
zero pair and negative PR signature are incompatible, as in the retained
signature census. More directly, the full six-event C1 coefficient vector
cannot be a nonnegative vector in a C2 embedding, and the consumer checks
all those embeddings too.

## 4. Scope of the conclusion

The theorem is

R1+sigma1(R1) is properly contained in C1,
and the current global 192-frame candidate is a strict outer relaxation.

It is not a nonrepresentability theorem for Q222. It also does not decide
C2=R2, which remains open. Even proving C2=R2 could not make this global
candidate exact, because its necessary C1 equality is false.

All Bell relabelings of the current frame have already been included.
Another relabeling or an additional copy of a current block cannot repair
this failure. A replacement C1 construction must enlarge the actual
certificate space, not merely the list of its symmetry images.
