#!/usr/bin/env python3
"""Verify the scoped continuation release; optionally replay exact algebra.

Passing this program does not prove the open universal G1/G2 statements.
It checks release custody and the exact finite identities actually delivered.
"""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time

HERE=Path(__file__).resolve().parent


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def load(path):
    return json.loads(path.read_text())


def check_hashes(directory,manifest):
    for name,record in manifest['files'].items():
        path=directory/name
        if not path.is_file():
            raise AssertionError('Missing manifest file: '+name)
        if path.stat().st_size != record['bytes'] or digest(path) != record['sha256']:
            raise AssertionError('Manifest mismatch: '+name)
    return len(manifest['files'])


def check_scope():
    current=load(HERE/'CHECKLIST.json')
    previous=load(HERE/'baseline/CHECKLIST.json')
    if current['overall_status'] != 'FULL_FINITE_LIFT_EXTRACTION_NOT_COMPLETE':
        raise AssertionError('This release does not establish an exact global lift.')
    old={row['id']:row['status'] for row in previous['items']}
    new={row['id']:row['status'] for row in current['items']}
    if new != old:
        raise AssertionError('The original extraction gates were not closed by this continuation.')
    if current['central_open_gates'] != ['G1','G2']:
        raise AssertionError('The universal source gates must remain explicit.')
    candidate=current['new_candidate']
    if candidate['reverse_inclusion'] != 'OPEN' or candidate['is_proved_exact_lift_size_bound']:
        raise AssertionError('An evaluated outer candidate is not a proved exact lift.')
    return {'original_checklist_items':len(new),'central_open_gates':['G1','G2'],
            'global_reverse_inclusion':'OPEN'}


def check_recorded_replays():
    plan=load(HERE/'REPLAY_PLAN.json')['suites']
    record=load(HERE/'REPLAY_RESULTS.json')
    if record['status'] != 'PASS_ALL_NEW_SCOPED_REPLAYS' or len(record['suites']) != len(plan):
        raise AssertionError('Incomplete scoped replay record.')
    for item,replayed in zip(plan,record['suites']):
        receipt=load(HERE/item['receipt'])
        if not receipt['status'].startswith('PASS'):
            raise AssertionError('Failed receipt: '+item['receipt'])
        if receipt[item['count_key']] != len(receipt['checks']):
            raise AssertionError('Receipt assertion count mismatch.')
        if replayed['name'] != item['name'] or replayed['status'] != 'PASS':
            raise AssertionError('Scoped replay name/status mismatch.')
        if replayed['executed_count'] != receipt[item['count_key']]:
            raise AssertionError('Scoped replay count mismatch.')
        for key in ['script','receipt']:
            if replayed[key] != item[key] or replayed[key+'_sha256'] != digest(HERE/item[key]):
                raise AssertionError('Scoped replay binding mismatch: '+key)
        for output in replayed['exact_regenerated_files']:
            if output['sha256'] != digest(HERE/output['path']):
                raise AssertionError('Regenerated exact-output binding mismatch.')
    return len(plan)


def check_publication_transforms():
    transforms=load(HERE/'PUBLICATION_TRANSFORMS.json')['transforms']
    for item in transforms:
        source=HERE/item['source']
        publication=HERE/item['publication']
        if digest(source)!=item['source_sha256'] or digest(publication)!=item['publication_sha256']:
            raise AssertionError('Publication copy hash mismatch.')
        expected=source.read_text()
        for change in item['changes']:
            if expected.count(change['from'])!=change['occurrences']:
                raise AssertionError('Publication transform occurrence mismatch.')
            expected=expected.replace(change['from'],change['to'])
        if publication.read_text()!=expected:
            raise AssertionError('Unrecorded publication transformation.')
    return len(transforms)


def run_replay():
    """Run only the six new exact suites, in a disposable isolated copy."""
    plan=load(HERE/'REPLAY_PLAN.json')
    reports=[]
    with tempfile.TemporaryDirectory(prefix='q222_continuation_replay_') as td:
        tmp=Path(td)
        shutil.copytree(HERE/'continuation',tmp/'continuation')
        env=dict(os.environ)
        env['PYTHONDONTWRITEBYTECODE']='1'
        for item in plan['suites']:
            script=tmp/item['script']
            expected=load(HERE/item['receipt'])
            start=time.monotonic()
            proc=subprocess.run([sys.executable,script.name],cwd=script.parent,
                env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,
                timeout=600)
            if proc.returncode:
                raise AssertionError(item['name']+' failed:\n'+proc.stdout)
            actual=load(tmp/item['receipt'])
            for key in item['compare_receipt_keys']:
                if actual[key] != expected[key]:
                    raise AssertionError(item['name']+' receipt differs at '+key)
            regenerated=[]
            for rel in item.get('exact_output_files',[]):
                if digest(tmp/rel) != digest(HERE/rel):
                    raise AssertionError(item['name']+' regenerated data differ: '+rel)
                regenerated.append({'path':rel,'sha256':digest(HERE/rel)})
            reports.append({'name':item['name'],'status':'PASS',
                'script':item['script'],'script_sha256':digest(HERE/item['script']),
                'receipt':item['receipt'],'receipt_sha256':digest(HERE/item['receipt']),
                'executed_count':actual[item['count_key']],
                'isolated_replay':True,'seconds':round(time.monotonic()-start,3),
                'exact_regenerated_files':regenerated})
    import sympy
    return {'status':'PASS_ALL_NEW_SCOPED_REPLAYS','python':sys.version.split()[0],
            'sympy':sympy.__version__,'suites':reports,
            'scope':'Exact algebra and data corroboration. Universal G1 and G2 remain OPEN.'}


def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--replay',action='store_true',help='Replay new exact suites in a temporary copy.')
    args=parser.parse_args()
    total=check_hashes(HERE,load(HERE/'MANIFEST_SHA256.json'))
    inherited=check_hashes(HERE/'baseline',load(HERE/'baseline/MANIFEST_SHA256.json'))
    scope=check_scope()
    recorded=check_recorded_replays()
    publication=check_publication_transforms()
    report={'status':'PASS_SCOPED_RELEASE_INTEGRITY','manifest_bound_files':total,
            'unchanged_baseline_payload_files':inherited,
            'recorded_new_scoped_replays':recorded,
            'verified_publication_copies':publication,**scope}
    if args.replay:
        report['replay']=run_replay()
    print(json.dumps(report,indent=2))


if __name__=='__main__':
    main()
