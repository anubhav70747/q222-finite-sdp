#!/usr/bin/env python3
"""Exact univariate decision of canonical C2 physicality for rational sources.

This is a sign decision in quartic coefficient polynomials, not an affine SDP
representation and not a proof of the enlarged C2 Gram coverage statement.
Source order: (d,n,m,C,A,D,alpha).  All arithmetic and root isolation are exact.
"""
import json
import sys
from pathlib import Path
import sympy as s

u, v, x = s.symbols('u v x')
W, X, Y, Z = state = s.symbols('W X Y Z')
d, n, m, C, A, D, alpha = source = s.symbols('d n m C A D alpha')
du, dv = 1+u*u, 1+v*v
parent = s.expand(n*du*dv*X**2 + m*(v*W-X+u*v*Y-u*Z)**2
    + C*dv*(u*W-Y)**2 + A*du*dv*Y**2
    + (D+d/2)*(u*W+u*v*X-Y-v*Z)**2
    + (alpha+d/2)*du*(v*Y-Z)**2
    + d*dv*(X+u*Z)**2/2-d*du*dv*Z**2/2)
matrix = s.hessian(parent, state)/2


def coefficients(values=None):
    """Return (h,a,b,p,q,f,g) in the radial-elimination convention."""
    a = A*C*(2*D+d+2*n)*(2*alpha+d+2*m)/4
    b = C*D*(d+2*n)*(2*A+2*alpha+d+2*m)/4
    p = A*n*(2*C+2*D+d)*(2*alpha+d+2*m)/4
    q = D*m*(d+2*n)*(2*A+2*C+2*alpha+d)/4
    f = A*alpha*(2*C+2*D+d)*(d+2*m+2*n)/4
    g = alpha*m*(d+2*n)*(2*A+2*C+2*D+d)/4
    if values is None:
        h = s.expand(matrix.subs({u:1,v:1}).det(method='domain-ge')/16-a-b-p-q-f-g)
        return h,a,b,p,q,f,g
    sub = dict(zip(source, map(s.Rational, values)))
    outer = [s.cancel(z.subs(sub)) for z in (a,b,p,q,f,g)]
    h = s.cancel(matrix.subs(sub).subs({u:1,v:1}).det()/16-sum(outer))
    return (h,*outer)


def scalar_polynomials(values):
    h,a,b,p,q,f,g = coefficients(values)
    T = s.Poly(p*x*x+h*x+q, x, domain=s.QQ)
    R = s.Poly(x*(a*x+b)*(f*x+g), x, domain=s.QQ)
    Delta = 4*R-T*T
    return T,R,Delta


def positive_cells(poly):
    """One rational point per component of (0,infinity) minus real roots.

    Rational isolating intervals can have a common endpoint.  A shared
    nonroot endpoint itself samples the gap.  A shared root endpoint is
    removed by refining the neighboring nontrivial isolating interval.
    """
    p = poly.sqf_part()
    while p.eval(0) == 0:
        p = p.exquo(s.Poly(x,x))
    if p.degree() <= 0:
        return [s.Rational(1)], []
    intervals = []
    for (lo,hi), multiplicity in p.intervals():
        while lo <= 0 <= hi:
            lo,hi = p.refine_root(lo,hi,steps=1)
        if lo > 0:
            intervals.append([lo,hi])
    for i in range(len(intervals)-1):
        while intervals[i][1] == intervals[i+1][0] and p.eval(intervals[i][1]) == 0:
            j = i if intervals[i][0] != intervals[i][1] else i+1
            lo,hi = intervals[j]
            intervals[j] = list(p.refine_root(lo,hi,steps=1))
    if not intervals:
        return [s.Rational(1)], []
    points = [intervals[0][0]/2]
    points += [(left[1]+right[0])/2 for left,right in zip(intervals,intervals[1:])]
    points += [intervals[-1][1]+1]
    assert all(p.eval(t) != 0 and t > 0 for t in points)
    return points, intervals


def decide(values):
    if len(values) != 7:
        raise ValueError('Expected seven rational source coordinates.')
    values = list(map(s.Rational, values))
    if not all(z >= 0 for z in values):
        raise ValueError('Canonical C2 source coordinates must be nonnegative.')
    T,R,Delta = scalar_polynomials(values)
    product = T*Delta
    if product.is_zero:
        points, intervals = [], []
    else:
        points, intervals = positive_cells(product)
    rows = [[str(t),str(T.eval(t)),str(Delta.eval(t))] for t in points]
    failing = [row for row in rows if s.Rational(row[1]) < 0 and s.Rational(row[2]) < 0]
    return {
        'source_order': list(map(str,source)), 'source': list(map(str,values)),
        'physical_in_C2': not bool(failing),
        'T': str(T.as_expr()), 'R': str(R.as_expr()), 'Delta': str(Delta.as_expr()),
        'positive_root_isolators': [[str(a),str(b)] for a,b in intervals],
        'sign_samples_x_T_Delta': rows,
        'strict_failure_sample': failing[0] if failing else None,
        'scope': 'Exact physical source membership; no assertion of K2 Gram membership or a finite affine lift.'
    }


if __name__ == '__main__':
    if len(sys.argv) != 8:
        raise SystemExit('Usage: python c2_radial.py d n m C A D alpha\nUse rational strings such as 7/8.')
    print(json.dumps(decide(sys.argv[1:]),indent=2))
