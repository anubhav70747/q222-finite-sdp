#!/usr/bin/env python3
"""Exact reduction of the existing enlarged cones to cubic PSD8 selectors.

This compiles an equivalent quantified gate, not a proof that every physical
source satisfies that gate.  All arithmetic and matching-space tests are exact.
Only the two immutable local inputs and SymPy are required.
"""
from pathlib import Path
import hashlib,json,time
import sympy as s

HERE=Path(__file__).resolve().parent
START=time.time();checks=[]
def ck(name,condition):
    if not condition:raise AssertionError(name)
    checks.append(name)
def zero(name,value):
    values=list(value) if isinstance(value,s.MatrixBase) else [value]
    ck(name,all(s.expand(x)==0 for x in values))
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def sparse(M):
    return [[i,j,str(M[i,j])] for i in range(M.rows) for j in range(M.cols) if M[i,j]]

u,v,W,X,Y,Z=s.symbols('u v W X Y Z',real=True)
d,la,n,m,C,A,D,al,be=s.symbols('d la n m C A D al be',real=True)
state=(W,X,Y,Z);Du=1+u*u;Dv=1+v*v;gens=(u,v,*state)
F=(4*la*Du*(W+v*X)**2+4*n*Du*Dv*X**2
   +4*m*(v*W-X+u*v*Y-u*Z)**2+4*C*Dv*(u*W-Y)**2
   +4*A*Du*Dv*Y**2+(4*D+2*d)*(u*W+u*v*X-Y-v*Z)**2
   +(4*al+2*d)*Du*(v*Y-Z)**2+(4*be+2*d)*Dv*(X+u*Z)**2
   -2*d*Du*Dv*Z**2)
P=(s.hessian(F,state)/2).applyfunc(s.expand)

# Literal universal half-line cubic matching.  The three free matrices have
# 16+10+6 entries, and every entry may be a polynomial of degree at most three.
h=s.symbols('h0:40');hs=[];off=0
for a in range(4):
    M=s.zeros(4)
    for i in range(4):
        for j in range(i,4):M[i,j]=M[j,i]=h[off];off+=1
    hs.append(M)
l=s.symbols('l0:16');tt=s.symbols('t0:10');kk=s.symbols('k0:6')
L=s.Matrix(4,4,l);T=s.zeros(4);K=s.zeros(4);off=0
for i in range(4):
    for j in range(i,4):T[i,j]=T[j,i]=tt[off];off+=1
off=0
for i in range(4):
    for j in range(i+1,4):K[i,j]=kk[off];K[j,i]=-kk[off];off+=1
M=(hs[2]-T)/2+K
Q0=hs[0].row_join(L).col_join(L.T.row_join(T))
Q1=(hs[1]-L-L.T).row_join(M).col_join(M.T.row_join(hs[3]))
Ev=s.eye(4).col_join(v*s.eye(4))
zero('universal two-Gram cubic-v identity',Ev.T*(Q0+v*Q1)*Ev-sum((v**i*hs[i] for i in range(4)),s.zeros(4)))
ck('universal free polynomial-entry count32',len(l)+len(tt)+len(kk)==32)
ck('universal cubic coefficient count128',4*(len(l)+len(tt)+len(kk))==128)

# Ordering of the 128 selector coefficients.
sel=[]
for a in range(4):
    for i in range(4):
        for j in range(4):sel.append(('L',a,i,j))
    for i in range(4):
        for j in range(i,4):sel.append(('T',a,i,j))
    for i in range(4):
        for j in range(i+1,4):sel.append(('K',a,i,j))
ck('literal selector list has128 distinct slots',len(sel)==len(set(sel))==128)
all_results=[]
for fam in ('C1','C2'):
    path=HERE/'inputs'/f'{fam}_ENLARGED_PRIMAL.coo.json'
    raw=json.loads(path.read_text())
    if fam=='C1':cv=(d,m,C,A,D,al,be);sub={la:0,n:0}
    else:cv=(d,n,m,C,A,D,al);sub={la:0,be:0}
    target=s.expand((1+u)*(1+v)*F.subs(sub));Ptarget=P.subs(sub)*(1+u)*(1+v)
    coords=[];products=[]
    for b,features in enumerate(raw['features']):
        wu,wv=raw['weights'][b]
        for i in range(len(features)):
            for j in range(i,len(features)):
                ai,ui,vi=features[i];aj,uj,vj=features[j]
                coords.append((b,i,j))
                products.append((2 if i!=j else 1)*u**(wu+ui+uj)*v**(wv+vi+vj)*state[ai]*state[aj])
    targets=[target.diff(c) for c in cv]
    monoms=sorted(set().union(*[set(s.Poly(z,*gens).monoms()) for z in products+targets]))
    def col(poly):
        dic=s.Poly(poly,*gens).as_dict();return [dic.get(a,0) for a in monoms]
    B=s.Matrix.hstack(*[s.Matrix(col(t)) for t in targets])
    AM=s.zeros(len(monoms),len(coords))
    for j,poly in enumerate(products):
        dic=s.Poly(poly,*gens).as_dict()
        ck(f'{fam} Gram product is one monomial {j}',len(dic)==1)
        for exponent,val in dic.items():AM[monoms.index(exponent),j]=val
    ck(f'{fam} coefficient rows have disjoint nonempty Gram support',all(any(AM[i,j] for j in range(AM.cols)) for i in range(AM.rows)))
    # Each nonzero column has exactly one row; thus all nonempty rows are
    # linearly independent, without a numerical or modular rank inference.
    ck(f'{fam} exact matching rank148',AM.rows==148)
    lookup={c:i for i,c in enumerate(coords)};J=s.zeros(len(coords),309)
    dface=[]
    for variable,i,j,value in raw['entries']:
        if i==58:
            dface.append((variable,j,value));continue
        b=next(b for b,bl in enumerate(raw['blocks'][:4]) if bl['offset']<=i<=j<bl['offset']+bl['order'])
        off=raw['blocks'][b]['offset'];J[lookup[(b,i-off,j-off)],variable-1]+=s.Rational(value)
    E=s.eye(7).row_join(s.zeros(7,302))
    zero(f'{fam} complete actual-array matching identity',AM*J-B*E)
    ck(f'{fam} d orthant is literally the final scalar block',dface==[(1,58,'1')])
    free=[lookup[tuple(c)] for c in raw['free_positions']]
    zero(f'{fam} free positions give identity on302 auxiliaries',J[free,7:]-s.eye(302))
    zero(f'{fam} free positions contain no source shift',J[free,:7])
    ck(f'{fam} full affine matching dimension309',len(coords)+7-AM.rows==309)

    # Diagonal Newton support forces precisely the six deleted features.
    # A weighted row u^(wu/2)v^(wv/2)R(u,v) becomes polynomial after
    # u=s^2,v=t^2.  A square monomial outside the diagonal Newton polygon
    # cannot occur in an SOS, by the leading-face sum-of-squares argument.
    full=[(a,pu,pv) for a in range(4) for pu in (0,1) for pv in (0,1)]
    supports=[]
    for a in range(4):
        diagonal=s.expand(Ptarget[a,a])
        supports.append(set(s.Poly(diagonal,u,v).monoms()))
    witnesses=[];removed=[]
    for b,(wu,wv) in enumerate(raw['weights']):
        for index,(a,pu,pv) in enumerate(full):
            point=(wu+2*pu,wv+2*pv)
            found=None
            for p,q in [(-1,-1),(1,-1),(1,1)]:
                maximum=max(p*i+q*j for i,j in supports[a])
                if p*point[0]+q*point[1]>maximum:
                    found={'block':b,'full_feature_index':index,'feature':[a,pu,pv],
                           'square_exponent':list(point),'normal':[p,q],
                           'support_bound':maximum,'excluded_value':p*point[0]+q*point[1]};break
            if found:removed.append([b,index]);witnesses.append(found)
    ck(f'{fam} six deleted features all have exact Newton witnesses',removed==raw['removed_full_features'])
    for b in range(4):
        expected=[f for j,f in enumerate(full) if [b,j] not in removed]
        ck(f'{fam} actual feature list equals the forced-zero restriction block{b}',expected==list(map(tuple,raw['features'][b])))

    # Project each of the four parity Grams to a pair of cubic matrix
    # polynomials Q0(u),Q1(u).  qrows[(block,degree,i,j)] is its row on the
    # seven source coefficients and302 original auxiliaries.
    qrows={(b,a,i,j):s.zeros(1,309) for b in range(2) for a in range(4) for i in range(8) for j in range(i,8)}
    for r,(b,i,j) in enumerate(coords):
        ai,ui,vi=raw['features'][b][i];aj,uj,vj=raw['features'][b][j]
        wu,wv=raw['weights'][b];ii,jj=sorted((4*vi+ai,4*vj+aj))
        factor=2 if i!=j and ii==jj else 1
        qrows[(wv,wu+ui+uj,ii,jj)]+=factor*J[r,:]
    def qr(b,a,i,j):return qrows[(b,a,min(i,j),max(i,j))]
    rows=[]
    for kind,a,i,j in sel:
        if kind=='L':row=qr(0,a,i,j+4)
        elif kind=='T':row=qr(0,a,i+4,j+4)
        else:row=(qr(1,a,i,j+4)-qr(1,a,j,i+4))/2
        rows.append(row)
    N=s.Matrix.vstack(*rows);aux=N[:,7:]
    reduced,pivots=aux.rref();r=len(pivots)
    image=aux[:,list(pivots)];right=reduced[:r,:]
    zero(f'{fam} exact auxiliary-image factorization',aux-image*right)
    zero(f'{fam} chosen image coordinates have identity right inverse',right[:,list(pivots)]-s.eye(r))
    selector=N[:,:7].row_join(image)
    cvnew=s.symbols(f'{fam.lower()}_0:{7+r}')
    actual_selector=selector*s.Matrix(cvnew)
    LL=[s.zeros(4) for _ in range(4)];TT=[s.zeros(4) for _ in range(4)];KK=[s.zeros(4) for _ in range(4)]
    for value,(kind,a,i,j) in zip(actual_selector,sel):
        if kind=='L':LL[a][i,j]=value
        elif kind=='T':TT[a][i,j]=TT[a][j,i]=value
        else:KK[a][i,j]=value;KK[a][j,i]=-value
    source_sub=dict(zip(cv,cvnew[:7]))
    hp=[Ptarget.diff(v,a).subs(v,0)/s.factorial(a) for a in range(4)]
    hp=[z.subs(source_sub).applyfunc(s.expand) for z in hp]
    LL=sum((u**a*LL[a] for a in range(4)),s.zeros(4))
    TT=sum((u**a*TT[a] for a in range(4)),s.zeros(4))
    KK=sum((u**a*KK[a] for a in range(4)),s.zeros(4))
    MM=(hp[2]-TT)/2+KK
    qq0=hp[0].row_join(LL).col_join(LL.T.row_join(TT))
    qq1=(hp[1]-LL-LL.T).row_join(MM).col_join(MM.T.row_join(hp[3]))
    zero(f'{fam} reduced full-parent identity',Ev.T*(qq0+v*qq1)*Ev-Ptarget.subs(source_sub))
    # Check every original projected entry after the exact auxiliary map.
    back=s.eye(7).row_join(s.zeros(7,302)).col_join(s.zeros(r,7).row_join(right))
    qrecords=[]
    for b,QQ in enumerate([qq0,qq1]):
        for i in range(8):
            for j in range(i,8):
                expression=s.expand(QQ[i,j]);rec=0
                for k,c in enumerate(cvnew):
                    for (a,),value in s.Poly(expression.diff(c),u).terms():
                        if value:qrecords.append([b,a,k,i,j,str(value)]);rec+=value*c*u**a
                zero(f'{fam} literal reduced matrix entry{b},{i},{j}',expression-rec)
                for a in range(4):
                    row=s.Matrix([[s.expand(expression).coeff(u,a).diff(c) for c in cvnew]])
                    zero(f'{fam} original-to-reduced entry{b},{a},{i},{j}',row*back-qr(b,a,i,j))
    export={'status':'EXACT_EQUIVALENT_UNIVERSAL_SELECTOR_GATE_NOT_SOLVED',
            'family':fam,'source_order':list(map(str,cv)),'source_sign_constraints':'all seven visible sources are nonnegative',
            'gate':'there exist source-only real eta such that Q0(u) and Q1(u) are PSD8 for every u>=0',
            'matrices':2,'matrix_order':8,'polynomial_degree':3,'selector_variables':r,
            'generic_selector_coefficients':128,'old_Gram_auxiliary_count':302,
            'variables':list(map(str,cv))+[f'eta{i}' for i in range(r)],
            'records_convention':'[matrix_id,u_degree,variable_index,row,column,rational_value], zero-based; mirror upper entries once',
            'records':qrecords,
            'old_auxiliary_to_eta':{'shape':[r,302],'records':sparse(right)},
            'eta_to_old_matching_auxiliary':{'shape':[302,r],'records':[[j,i,'1'] for i,j in enumerate(pivots)]},
            'Newton_forced_zero_witnesses':witnesses,
            'input':{'path':str(path.relative_to(HERE)),'sha256':sha(path)},
            'limitations':['Equivalent membership test for one fixed enlarged canonical cone only.',
                          'No universal physical-source converse has been proved by this reduction.',
                          'The universal u quantifier remains. Fejer-Riesz converts it back to the existing finite Gram dictionary.']}
    outpath=HERE/f'{fam}_ENLARGED_CUBIC_SELECTOR.coo.json'
    outpath.write_text(json.dumps(export,indent=2)+'\n')
    all_results.append({'family':fam,'selector_variables':r,'old_Gram_auxiliaries':302,
                        'matching_rank':148,'matching_dimension':309,'matrix_records':len(qrecords),
                        'export':outpath.name,'export_sha256':sha(outpath),'input_sha256':sha(path),
                        'forced_zero_features':witnesses})
    print(json.dumps(all_results[-1]),flush=True)

receipt={'status':'PASS_EXACT_ENLARGED_SELECTOR_REDUCTION','checks_passed':len(checks),'checks':checks,
         'families':all_results,'checker':{'path':Path(__file__).name,'sha256':sha(Path(__file__))},
         'proof':{'path':'enlarged_cubic_selector_reduction.tex','sha256':sha(HERE/'enlarged_cubic_selector_reduction.tex')},
         'primary_theorem':'A. Zalar, arXiv:1503.06034v2, Theorem1.1; halfline cubic form follows by x=t^2 and even/odd averaging.',
         'mathematical_gate_status':'OPEN_UNCHANGED: reduction is equivalent to the existing enlarged dictionary, not a universal feasibility proof.',
         'seconds':time.time()-START}
(HERE/'CHECK_ENLARGED_SELECTOR_REDUCTION.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'status':receipt['status'],'checks_passed':len(checks),'seconds':receipt['seconds']},indent=2))
