C2 universal-gate continuation — 2026-10-22

Universal G2 remains OPEN. This directory contains two new exact mathematical
results, not a claim of completed finite extraction.

1. c2_constant_congruence_rigidity.tex (CR1–CR12): a full-parent proof that
   arbitrary constant GL4 state congruences combined with positive angular
   dilations only give an overall scalar on strictly positive-event C2
   sources. An exact sharp physical source has a genuinely varying radial
   minimizer. Checker: check_c2_constant_congruence_rigidity.py, PASS60.

2. c2_compatibility_selector_obstruction.tex (CS1–CS17): exact full-state
   four-PSD2 compatibility identity, then two rigorously physical sources
   refuting low-degree selector rules. The primary rational source is
   strictly positive and regular (event minor -45/4); it excludes a cubic
   numerator divided by 1+u. A separate algebraic n=0 source excludes every
   positive polynomial denominator of degree at most two, with polynomial
   numerator of any degree. Checker: check_c2_compatibility_selector_obstruction.py,
   PASS104. These examples do NOT refute the enlarged C2 Gram dictionary.

The new checkers are self-contained and require Python3 plus SymPy, with no
optimizer or historical receipt imported as a premise. Each writes a deterministic
JSON receipt next to itself. The proof is included in the receipt hash.

REVIEW_C2_RADIAL.json records independent acceptance of the parent radial
physicality decision. review_radial contains unchanged copies of its two
checker files and their isolated PASS31 outputs.

The remaining global assertion is unchanged: every regular physical C2 source
must admit the fixed enlarged four-block affine Gram representation, or an
alternative coefficient-affine finite lift with both inclusions must be proved.
The present obstructions eliminate narrower proposed reductions only.

REVIEW_C1_SELECTOR_OBSTRUCTION.json pins independent acceptance of the sibling
C1 exact low-denominator obstruction and endpoint factorization. Its 76 checks
were freshly replayed with output redirected to c2/review_c1/REPLAY.json;
the primary pointwise joint-measurability theorem was independently opened.
