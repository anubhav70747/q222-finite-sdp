#!/usr/bin/env python3
"""Exact full-parent one-variable completion and polynomial-selection obstruction.

This does not solve a global finite-lift problem.  The finite matrix exported
here is quantified for every Alice angle, with a separately chosen skew
completion at that angle.  Its six completion variables are not a global
finite set of auxiliary variables.
"""
from pathlib import Path
from fractions import Fraction
import hashlib,json,time
import sympy as s

HERE=Path(__file__).resolve().parent
START=time.time();checks=[]
def ck(name,p):
    if not p:raise AssertionError(name)
    checks.append(name)
def zero(name,x):
    vals=list(x) if isinstance(x,s.MatrixBase) else [x]
    ck(name,all(s.cancel(z)==0 for z in vals))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def mat(M):return [[str(z) for z in M.row(i)] for i in range(M.rows)]
def ldl(name,M):
    zero(name+' symmetry',M-M.T)
    a=[[Fraction(str(z)) for z in M.row(i)] for i in range(M.rows)]
    piv=[]
    for k in range(M.rows):
        t=a[k][k];ck(name+' pivot '+str(k),t>0);piv.append(str(t))
        for i in range(k+1,M.rows):
            for j in range(i,M.rows):
                a[i][j]-=a[i][k]*a[k][j]/t;a[j][i]=a[i][j]
    return piv

u,v,W,X,Y,Z=s.symbols('u v W X Y Z',real=True)
cv=s.symbols('d la n m C A D alpha beta',real=True)
d,la,n,m,C,A,D,al,be=cv
state=(W,X,Y,Z);psi=s.Matrix(state);Du=1+u*u;Dv=1+v*v
F=4*la*Du*(W+v*X)**2+4*n*Du*Dv*X**2
F+=4*m*(v*W-X+u*v*Y-u*Z)**2+4*C*Dv*(u*W-Y)**2
F+=4*A*Du*Dv*Y**2+(4*D+2*d)*(u*W+u*v*X-Y-v*Z)**2
F+=(4*al+2*d)*Du*(v*Y-Z)**2+(4*be+2*d)*Dv*(X+u*Z)**2
F-=2*d*Du*Dv*Z**2
P=(s.hessian(F,state)/2).applyfunc(s.expand)
zero('full parent state reconstruction',(psi.T*P*psi)[0]-F)
C0=P.subs(v,0)
B0=P.diff(v).subs(v,0)
A0=P.diff(v,2)/2
zero('entire quadratic Bob coefficient decomposition',P-C0-v*B0-v*v*A0)
ck('every Bob coefficient has Alice degree at most two',all(s.Poly(z,u).degree()<=2 for T in (A0,B0,C0) for z in T if z!=0))

# Original nine-coordinate physical operator, independently reconstructed.
I=s.eye(2);zz=s.diag(1,-1);xx=s.Matrix([[0,1],[1,0]])
aa=[zz,((1-u*u)*zz+2*u*xx)/Du]
bb=[zz,((1-v*v)*zz+2*v*xx)/Dv]
kron=s.kronecker_product
H=s.Matrix([1,0,0,0,0,-s.Rational(1,2),s.Rational(1,2),-s.Rational(1,2),-s.Rational(1,2)])
events=[(1,1,0,1),(1,-1,0,0),(1,-1,1,1),(-1,1,1,0),(-1,1,0,0),(-1,1,1,1),(-1,-1,0,1),(1,-1,1,0)]
def event(a,b,x,y):
    r=s.zeros(9,1);r[0]=1;r[1+x]=a;r[3+y]=b;r[5+2*x+y]=a*b
    return r
J=s.Matrix.hstack(H,*[event(*e) for e in events])
ops=[s.eye(4)]+[kron(T,I) for T in aa]+[kron(I,T) for T in bb]+[kron(T,R) for T in aa for R in bb]
for j in range(9):
    bell=sum((J[i,j]*ops[i] for i in range(9)),s.zeros(4))
    zero('original physical source column '+str(j),P.diff(cv[j])-Du*Dv*bell)
ck('original source dictionary is invertible',J.det()!=0)

sk=s.symbols('k01 k02 k03 k12 k13 k23',real=True)
K=s.zeros(4)
pairs=[(i,j) for i in range(4) for j in range(i+1,4)]
for z,(i,j) in zip(sk,pairs):K[i,j]=z;K[j,i]=-z
Q=C0.row_join(B0/2+K).col_join((B0/2-K).row_join(A0))
T=s.eye(4).col_join(v*s.eye(4))
zero('complete eight-by-eight skew-completion identity',T.T*Q*T-P)
zero('completion is symmetric',Q-Q.T)
for z in sk:zero('every skew coordinate cancels identically',(T.T*Q.diff(z)*T))
full_gram_coords=[(i,j) for i in range(8) for j in range(i,8)]
slice_keys=[(a,i,j) for a in range(3) for i in range(4) for j in range(i,4)]
slice_map=s.zeros(len(slice_keys),len(full_gram_coords))
slice_table=[]
for k,(i,j) in enumerate(full_gram_coords):
    e=i//4+j//4;a,b=sorted((i%4,j%4));factor=2 if i!=j else 1
    slice_map[slice_keys.index((e,a,b)),k]=factor
    slice_table.append({'Gram_entry':[i,j],'product_key':[e,a,b],'Gram_coefficient_factor':factor})
ck('complete one-variable product space has dimension30',slice_map.rank()==30)
ck('pointwise full Gram kernel has dimension exactly six',len(full_gram_coords)-slice_map.rank()==6)
records=[]
allvars=(*cv,*sk)
for i in range(8):
    for j in range(i,8):
        value=s.expand(Q[i,j]);rebuild=0
        for k,z in enumerate(allvars):
            coeff=s.diff(value,z)
            for (a,),w in s.Poly(coeff,u).terms():
                if w:
                    records.append([k,a,i,j,str(w)]);rebuild+=w*z*u**a
        zero('exported literal completion entry (%d,%d)'%(i,j),value-rebuild)
export={
 'status':'EXACT_QUANTIFIED_COMPLETION_NOT_A_GLOBAL_AFFINE_LIFT',
 'quantifier':'physical(c) iff forall real u exists six real k: Q(c,u,k) is PSD8',
 'source_order':['d','lambda','n','m','C','A','D','alpha','beta'],
 'completion_order':list(map(str,sk)),
 'matrix_order':8,'pointwise_completion_variables':6,
 'coefficient_convention':'[variable_index,Alice_power,row,column,rational_value]; upper entries mirrored once; variables are the nine sources followed by six pointwise skew coordinates',
 'source_to_original_affine':mat(J),
 'testing_vector':['W','X','Y','Z','v*W','v*X','v*Y','v*Z'],
 'product_key_convention':'[Bob_power,state_i,state_j] denotes v**Bob_power*psi_i*psi_j, with i<=j',
 'product_table':slice_table,
 'records':records,
 'warning':'The six k values may depend on both c and u. They are not six auxiliary variables for an exact finite affine Q222 lift.'}
(HERE/'FULL_PARENT_UNIVARIATE_COMPLETION.coo.json').write_text(json.dumps(export,indent=2)+'\n')

# Verify that the old actual array contains every ordinary bilinear SOS,
# by proving its entire affine matching space is represented.
raw_path=HERE/'inputs/C1_RAMIFIED_PRIMAL.coo.json';raw=json.loads(raw_path.read_text())
coords=[];polys=[]
for b,ff in enumerate(raw['features']):
    wu,wv=raw['weights'][b]
    for i in range(len(ff)):
        for j in range(i,len(ff)):
            a,pu,pv=ff[i];bb_,qu,qv=ff[j]
            coords.append((b,i,j))
            polys.append((2 if i!=j else 1)*u**(wu+pu+qu)*v**(wv+pv+qv)*state[a]*state[bb_])
Gens=(u,v,*state)
F1=s.expand(F.subs({la:0,n:0}));cv1=(d,m,C,A,D,al,be)
targets=[F1.diff(z) for z in cv1]
monoms=sorted(set().union(*[set(s.Poly(z,*Gens).monoms()) for z in polys+targets]))
def col(z):
    dd=s.Poly(z,*Gens).as_dict();return [dd.get(e,0) for e in monoms]
AM=s.Matrix.hstack(*[s.Matrix(col(z)) for z in polys])
BM=s.Matrix.hstack(*[s.Matrix(col(z)) for z in targets])
lookup={x:i for i,x in enumerate(coords)};L=s.zeros(len(coords),86)
for k,i,j,val in raw['entries']:
    if i==30:continue
    b=next(b for b,B in enumerate(raw['blocks'][:4]) if B['offset']<=i<=j<B['offset']+B['order'])
    off=raw['blocks'][b]['offset'];L[lookup[(b,i-off,j-off)],k-1]+=s.Rational(val)
E=s.eye(7).row_join(s.zeros(7,79))
zero('all actual old-COO source and auxiliary polynomial identities',AM*L-BM*E)
rank_match=AM.row_join(-BM).rank();rank_param=L.col_join(E).rank()
ck('whole matching space has dimension exactly86',len(coords)+7-rank_match==86)
ck('actual old-COO parameterization has full dimension86',rank_param==86)
ck('old source has exactly157 Gram coordinates',len(coords)==157)
ordinary=set((a,pu,pv) for a in range(4) for pu in (0,1) for pv in (0,1))
even=set(map(tuple,raw['features'][0]))
ck('even14 block omits precisely W and uX',ordinary-even=={(0,0,0),(1,1,0)} and len(even)==14)
ck('W squared constant coefficient vanishes',s.Poly(F1,*Gens).coeff_monomial(W**2)==0)
ck('uX squared coefficient at v zero vanishes',s.Poly(F1,*Gens).coeff_monomial(u**2*X**2)==0)

source_path=HERE/'inputs/remembered_contact_source.json';source=json.loads(source_path.read_text())
c=s.Matrix(list(map(s.Rational,source['source'])))
at={u:s.Rational(source['contact']['u']),v:s.Rational(source['contact']['v'])}
ps=s.Matrix(list(map(s.Rational,source['contact']['state'])))
M=P.subs({la:0,n:0,**dict(zip(cv1,c))})
zero('actual cstar full state contact',M.subs(at)*ps)
zero('actual cstar both angular jets',s.Matrix([(ps.T*M.diff(z).subs(at)*ps)[0] for z in (u,v)]))
det=s.cancel(M.det(method='domain-ge')/(Du**2*Dv**2))
outer=[];centre=0
for (i,j),z in s.Poly(det,u,v).terms():
    ck('cstar determinant exponents even (%d,%d)'%(i,j),i%2==0 and j%2==0)
    e=(i//2-1,j//2-1)
    if e==(0,0):centre=z
    else:outer.append((*e,z))
ck('six exact positive outer Laurent coefficients',len(outer)==6 and all(z>0 for i,j,z in outer))
weights=[(i,j,s.cancel(z*at[u]**(2*i)*at[v]**(2*j))) for i,j,z in outer]
zero('cstar contact AMGM constant identity',centre+sum(z for i,j,z in weights))
zero('cstar contact AMGM balanced exponents',s.Matrix([sum(i*z for i,j,z in weights),sum(j*z for i,j,z in weights)]))
ck('cstar positive hard m C A packets',all(c[i]>0 for i in (1,2,3)))
zero('three hard packet rows span WXY',s.Matrix([[v,-1,u*v],[u,0,-1],[0,0,1]]).det()-u)
for angle,S in [(u,s.diag(1,1,-1,-1)),(v,s.diag(1,-1,1,-1))]:
    zero('full sign congruence '+str(angle),M.subs(angle,-angle)-S*M*S)

sep_path=HERE/'inputs/historical_C1_SATURATED_CONE_SEPARATOR.json';sep=json.loads(sep_path.read_text())
zero('separator matches exact cstar source',s.Matrix(list(map(s.Rational,sep['coefficients'])))-c)
item=next(x for x in sep['orientation_certificates'] if x['orientation']==0)
zblocks=[s.Matrix(z).applyfunc(s.Rational) for z in item['dual_blocks']]
pivots=[ldl('current old C1 dual block '+str(i),z) for i,z in enumerate(zblocks)]
ell=s.Matrix(list(map(s.Rational,sep['common_separator'])))
ev=s.Matrix([(ps.T*P.diff(z).subs(at)*ps)[0] for z in cv1])
zero('exact separator evaluation functional',ell-93424*ev+s.Matrix([1,0,0,0,0,0,0]))
tr=s.zeros(1,86)
for r,(b,i,j) in enumerate(coords):tr+=(2 if i!=j else 1)*zblocks[b][i,j]*L[r,:]
zero('entire actual affine dual equation',ell.T*E-tr-s.Matrix([[1]+[0]*85]))
zero('strict separating value minus one',(ell.T*c)[0]+1)

# A simple event already prevents swapping forall u exists K with exists K.
event_sub={z:0 for z in cv};event_sub[la]=1
Ce=C0.subs(event_sub);Be=B0.subs(event_sub);Ae=A0.subs(event_sub)
ew=s.eye(4)[:,0];ex=s.eye(4)[:,1]
Ke=2*Du*(ew*ex.T-ex*ew.T)
Qe=4*Du*ew.col_join(ex)*ew.col_join(ex).T
zero('event-only unique completion has nonconstant skew',
     Qe-Ce.row_join(Be/2+Ke).col_join((Be/2-Ke).row_join(Ae)))
ck('event-only required skew is not constant',s.diff(Ke[0,1],u)!=0)

out={'status':'PASS_EXACT_COMPLETION_AND_POLYNOMIAL_SELECTOR_OBSTRUCTION',
 'checks_passed':len(checks),'checks':checks,
 'export':{'path':'FULL_PARENT_UNIVARIATE_COMPLETION.coo.json','sha256':sha(HERE/'FULL_PARENT_UNIVARIATE_COMPLETION.coo.json'),'records':len(records)},
 'matching':{'Gram_coordinates':len(coords),'coefficient_rows':len(monoms),'constraint_rank':rank_match,'full_solution_dimension':rank_param},
 'source':list(map(str,c)),'contact':source['contact'],'separator_value':'-1','dual_positive_pivots':pivots,
 'positive_Laurent_contact_weights':[[i,j,str(z)] for i,j,z in weights],
 'analytical_implications':['Matrix Fejer-Riesz gives the exact forall-u exists-skew-PSD8 equivalence.','The explicit globally physical source cstar has no ordinary polynomial SOS.','Any polynomial skew selector is at most quadratic by PSD entry bounds; Fejer-Riesz then contradicts the preceding non-SOS conclusion.'],
 'limitations':['No rational/algebraic selector impossibility is asserted.','No impossibility for the enlarged C1/C2 dictionaries or C160 is asserted.','The pointwise six-variable completion is not an evaluated finite Q222 lift.'],
 'inputs':[{'path':str(p.relative_to(HERE)),'sha256':sha(p)} for p in [raw_path,source_path,sep_path]],
 'proof':{'path':'univariate_completion_and_selector_obstruction.tex','sha256':sha(HERE/'univariate_completion_and_selector_obstruction.tex')},
 'checker':{'path':Path(__file__).name,'sha256':sha(Path(__file__))},'seconds':time.time()-START}
(HERE/'CHECK_UNIVARIATE_COMPLETION_AND_OBSTRUCTION.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':out['status'],'checks_passed':out['checks_passed'],'export_records':len(records),'matching':out['matching'],'seconds':out['seconds']},indent=2))
