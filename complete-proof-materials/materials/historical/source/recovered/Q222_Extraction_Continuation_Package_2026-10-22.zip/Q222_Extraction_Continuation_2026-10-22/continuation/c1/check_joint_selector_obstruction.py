#!/usr/bin/env python3
"""Exact whole-parent checks for the C1 low-denominator selector obstruction.

Requires only SymPy.  No numerical solver or network access is used.  The
checker verifies identities; the accompanying proof supplies positivity,
endpoint growth, and the quantified impossibility argument.

Usage:
  python3 check_joint_selector_obstruction.py --output /tmp/replay.json
The optional --write-data is for initial construction, not ordinary replay.
"""
from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path
import time

import sympy as s

HERE = Path(__file__).resolve().parent
R = s.Rational
u, v, a, b = s.symbols("u v a b", real=True)
W, X, Y, Z = s.symbols("W X Y Z", real=True)
state = s.Matrix([W, X, Y, Z])
d, m, C, A, D, al, be = s.symbols("d m C A D alpha beta", real=True)
source_symbols = (d, m, C, A, D, al, be)
Du, Dv = 1 + u**2, 1 + v**2
checks: list[str] = []


def zero(name, value):
    entries = list(value) if isinstance(value, s.MatrixBase) else [value]
    for entry in entries:
        if s.cancel(s.expand(entry)) != 0:
            raise AssertionError(f"{name}: nonzero residual {s.factor(entry)}")
    checks.append(name)


def require(name, condition):
    if not condition:
        raise AssertionError(name)
    checks.append(name)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def mat_json(M):
    return [[str(M[i, j]) for j in range(M.cols)] for i in range(M.rows)]


def scalar_form(M, z):
    return (z.T * M * z)[0]


def full_parent():
    return s.expand(
        m * (v * W - X + u * v * Y - u * Z) ** 2
        + C * Dv * (u * W - Y) ** 2
        + A * Du * Dv * Y**2
        + (D + d / 2) * (u * W + u * v * X - Y - v * Z) ** 2
        + (al + d / 2) * Du * (v * Y - Z) ** 2
        + (be + d / 2) * Dv * (X + u * Z) ** 2
        - d / 2 * Du * Dv * Z**2
    )


def blocks():
    r, t, e = s.Matrix([u, -1]), s.Matrix([1, u]), s.diag(0, 1)
    A0 = (C + D + d / 2) * r * r.T + A * Du * e
    A2 = m * t * t.T + C * r * r.T + (A + al + d / 2) * Du * e
    B0 = (m + be + d / 2) * t * t.T + al * Du * e
    B2 = D * r * r.T + be * t * t.T + d / 2 * Du * s.diag(1, 0)
    T = s.Matrix([
        [(D + d / 2) * u**2 - m, -u * (m + D + d / 2)],
        [-u * (m + D + d / 2), D + d / 2 - m * u**2 - (al + d / 2) * Du],
    ])
    return A0, A2, B0, B2, T, A0 + B0


def outer_coefficients():
    phi = 2 * A + 2 * al + d
    return {
        "p22": C * be * (2 * D + d) * (phi + 2 * m) / 4,
        "p21": A * C * (2 * D + d) * (2 * al + 2 * be + d + 2 * m) / 4,
        "p10": A * al * (2 * C + 2 * D + d) * (2 * be + d + 2 * m) / 4,
        "p02": D * m * (2 * be + d) * (phi + 2 * C) / 4,
        "p01": al * m * (2 * be + d) * (2 * A + 2 * C + 2 * D + d) / 4,
        "p12": (
            C * D * phi * (2 * be + d)
            + be * m * (2 * D + d) * phi
            + 2 * C * m * (4 * D * be + d * (D + be))
        ) / 4,
    }


def permutation_sign(p):
    return (-1) ** sum(p[i] > p[j] for i in range(4) for j in range(i + 1, 4))


def exact_det4(M):
    return s.expand(sum(
        permutation_sign(p) * s.prod(M[i, p[i]] for i in range(4))
        for p in itertools.permutations(range(4))
    ))


def polynomial_gram_witness():
    features = [
        [[1, 0, 1], [2, 1, 0], [3, 1, 1]],
        [[0, 0, 1], [1, 0, 0], [2, 1, 1], [3, 1, 0]],
        [[0, 1, 0], [1, 1, 1], [2, 0, 0], [3, 0, 1]],
        [[0, 1, 1], [2, 0, 1], [3, 0, 0]],
    ]
    Q = [
        s.Matrix([[R(2, 3), R(1, 6), R(2, 9)],
                  [R(1, 6), R(1, 4), -R(1, 12)],
                  [R(2, 9), -R(1, 12), R(1, 6)]]),
        s.Matrix([[R(1, 3), -R(1, 3), R(2, 9), -R(1, 2)],
                  [-R(1, 3), 1, -R(2, 3), 1],
                  [R(2, 9), -R(2, 3), R(4, 3), -1],
                  [-R(1, 2), 1, -1, R(5, 4)]]),
        s.Matrix([[1, R(2, 3), -1, -R(1, 3)],
                  [R(2, 3), R(2, 3), -R(1, 2), -R(2, 9)],
                  [-1, -R(1, 2), R(5, 4), R(1, 4)],
                  [-R(1, 3), -R(2, 9), R(1, 4), R(1, 6)]]),
        s.Matrix([[R(1, 3), -R(2, 9), -R(1, 6)],
                  [-R(2, 9), R(4, 3), -R(1, 3)],
                  [-R(1, 6), -R(1, 3), R(1, 4)]]),
    ]
    return features, Q


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", type=Path, default=HERE / "CHECK_JOINT_SELECTOR_OBSTRUCTION.json")
    parser.add_argument("--write-data", action="store_true")
    args = parser.parse_args()
    start = time.perf_counter()
    F = full_parent()
    P = s.hessian(F, (W, X, Y, Z)) / 2
    zero("full state Hessian reproduces every quarter-parent term", scalar_form(P, state) - F)
    A0, A2, B0, B2, T, H = blocks()
    yy, zz = s.Matrix([W, Y]), s.Matrix([X, Z])
    zero("complete two-by-two block parent", F - scalar_form(A0 + v**2 * A2, yy)
         - scalar_form(B0 + v**2 * B2, zz) - 2 * v * (yy.T * T * zz)[0])
    zero("first exact difference identity", T - (A0 - A2))
    zero("second exact difference identity", T - (B2 - B0))
    zero("common marginal H", H - A2 - B2)
    g0, g1, g2 = s.symbols("g0 g1 g2", real=True)
    G = s.Matrix([[g0, g1], [g1, g2]])
    EE = [G, A0 - G, A2 - G, H - A0 - A2 + G]
    decomposition = (Dv * scalar_form(EE[0], yy) + Dv * scalar_form(EE[3], zz)
                     + scalar_form(EE[1], yy + v * zz)
                     + scalar_form(EE[2], v * yy - zz))
    zero("four-positive-effect identity with all state coordinates", F - decomposition)

    aa, ab, ac, ba, bb, bc = s.symbols("aa ab ac ba bb bc", real=True)
    An, Bn = s.Matrix([[aa, ab], [ab, ac]]), s.Matrix([[ba, bb], [bb, bc]])
    Zn, Xn, I2 = s.diag(1, -1), s.Matrix([[0, 1], [1, 0]]), s.eye(2)
    Sn, Tn = 2 * An - I2, 2 * Bn - I2
    Mn = (An + v**2 * Bn).row_join(v * (An - Bn)).col_join(
        (v * (An - Bn)).row_join(Dv * I2 - An - v**2 * Bn))
    nchsh = ((1 - v**2) * Zn + 2 * v * Xn) / Dv
    CH = (s.kronecker_product(Zn, Sn + Tn) + s.kronecker_product(nchsh, Sn - Tn)) / 2
    zero("normalized fixed-u CHSH identity", 2 * Mn / Dv - s.eye(4) - CH)
    J = s.Matrix([[0, -1], [1, 0]])
    zero("Bob real quarter-turn reverses CHSH sign", s.kronecker_product(J, I2).T * CH
         * s.kronecker_product(J, I2) + CH)

    Gu, Gv = s.diag(1, 1, -1, -1), s.diag(1, -1, 1, -1)
    zero("independent Alice sign gauge", Gu * P.subs(u, -u) * Gu - P)
    zero("independent Bob sign gauge", Gv * P.subs(v, -v) * Gv - P)
    coreZ0 = R(1, 2) * ((u * W + u * v * X - Y) ** 2 + Dv * X**2 + Du * v**2 * Y**2)
    zero("positive WXY core for determinant Schur test", s.diff(F, d).subs(Z, 0) - coreZ0)

    outer = outer_coefficients()
    detP = exact_det4(P)
    p11 = s.expand(P.subs({u: 1, v: 1}).det(method="domain-ge") / 16 - sum(outer.values()))
    L = (p11 + outer["p22"] * a * b + outer["p21"] * a + outer["p12"] * b
         + outer["p10"] / b + outer["p02"] * b / a + outer["p01"] / a)
    zero("generic full-parent Laurent determinant, seven source coefficients", detP
         - Du**2 * Dv**2 * u**2 * v**2 * L.subs({a: u**2, b: v**2}))
    phi = 2 * A + 2 * al + d
    ell0 = be * (2 * D + d) * a + D * (2 * be + d)
    ell1 = C * (phi + 2 * m) * a + m * (phi + 2 * C)
    zero("A0 endpoint determinant", A0.det() - A * (2 * C + 2 * D + d) * u**2 * Du / 2)
    zero("B0 endpoint determinant", B0.det() - al * (2 * m + 2 * be + d) * Du / 2)
    zero("A2 endpoint determinant", A2.det() - Du * ell1.subs(a, u**2) / 2)
    zero("B2 endpoint determinant", B2.det() - Du * ell0.subs(a, u**2) / 2)
    zero("factorization of the three Bob-radial outer terms", 4 * (
        outer["p22"] * a**2 + outer["p12"] * a + outer["p02"]) - ell0 * ell1)
    xx1, xx0 = s.diff(ell0, a), ell0.subs(a, 0)
    yy1, yy0 = s.diff(ell1, a), ell1.subs(a, 0)
    slope = s.factor(xx1 * yy0 - xx0 * yy1)
    zero("outer discriminant is an exact square", outer["p12"]**2
         - 4 * outer["p22"] * outer["p02"] - slope**2 / 16)
    z0, z1, z2, pp = s.symbols("z0 z1 z2 pp", positive=True)
    radial_a, radial_b = s.symbols("radial_a radial_b", positive=True)
    radial_coeff = (z1 * radial_a + z0) * z2 / (4 * radial_a)
    radial_minimizer = s.sqrt(pp / radial_coeff)
    zero("exact radial AM-GM minimum", (radial_coeff * radial_b + pp / radial_b).subs(
        radial_b, radial_minimizer) - 2 * s.sqrt(radial_coeff * pp))

    c0 = [R(1), R(1, 3), R(1, 3), R(1, 4), R(1, 6), R(1, 4), R(1, 6)]
    c0sub = dict(zip(source_symbols, c0))
    p0, q0 = R(1), R(3, 4)
    psi0 = s.Matrix([1, -R(1, 2), R(1, 2), 1])
    angle0 = {u: p0, v: q0}
    P0 = P.subs(c0sub)
    require("obstruction source has d and all six event weights positive", all(t > 0 for t in c0))
    require("obstruction source is sigma fixed", c0 == [c0[i] for i in (0, 2, 1, 5, 6, 3, 4)])
    zero("obstruction source full four state contact equations", P0.subs(angle0) * psi0)
    zero("obstruction source both angular equations", s.Matrix([
        scalar_form(P0.diff(t).subs(angle0), psi0) for t in (u, v)]))
    core_value = s.factor(scalar_form(P.diff(d).subs(angle0), psi0))
    require("contact core has strictly negative expectation", core_value < 0)
    L0 = s.factor(L.subs(c0sub))
    L0_expected = (R(4, 81) * a * b + R(5, 72) * a + R(8, 81) * b
                   + R(1, 16) / b + R(4, 81) * b / a + R(5, 72) / a - R(13, 36))
    zero("obstruction source complete Laurent determinant coefficients", L0 - L0_expected)
    require("six positive outer Laurent coefficients", all(s.factor(t.subs(c0sub)) > 0 for t in outer.values()))
    zero("convex logarithmic Laurent stationary zero", s.Matrix([
        L0, a * s.diff(L0, a), b * s.diff(L0, b)]).subs({a: 1, b: R(9, 16)}))
    principal = [s.factor(P0.subs(angle0)[:i, :i].det()) for i in (1, 2, 3)]
    require("full state kernel is simple at the contact", all(t > 0 for t in principal))

    A00 = s.Matrix([[u**2, -u], [-u, (u**2 + 5) / 4]])
    A20 = s.diag(Du / 3, 4 * Du / 3)
    B00 = s.Matrix([[1, u], [u, (5 * u**2 + 1) / 4]])
    H0 = s.diag(Du, R(3, 2) * Du)
    for name, generic, concrete in [("A0", A0, A00), ("A2", A2, A20),
                                     ("B0", B0, B00), ("H", H, H0)]:
        zero("obstruction source explicit " + name, generic.subs(c0sub) - concrete)
    Gc = s.Matrix([[R(1, 3), -R(2, 3)], [-R(2, 3), R(4, 3)]])
    Gprime = s.Matrix([[R(8, 15), -R(2, 3)], [-R(2, 3), R(8, 15)]])
    kernels = [s.Matrix(k) for k in [(2, 1), (1, 2), (2, -1), (-1, 2)]]
    Ec = [Gc, A00.subs(u, 1) - Gc, A20.subs(u, 1) - Gc,
          H0.subs(u, 1) - A00.subs(u, 1) - A20.subs(u, 1) + Gc]
    zero("all four forced effect kernels", s.Matrix.vstack(*[E * k for E, k in zip(Ec, kernels)]))
    require("all four contact effects are nonzero rank-one PSD", all(
        E.det() == 0 and s.trace(E) > 0 for E in Ec))
    unknown_G = s.Matrix([[g0, g1], [g1, g2]])
    value_solution = s.solve(list(unknown_G * kernels[0]) + list(
        (A00.subs(u, 1) - unknown_G) * kernels[1]), (g0, g1, g2), dict=True)
    require("the contact effect value is uniquely forced", value_solution == [dict(zip(
        (g0, g1, g2), (Gc[0, 0], Gc[0, 1], Gc[1, 1])))])
    xj, yj, zj = s.symbols("xj yj zj", real=True)
    Kjet = s.Matrix([[xj, yj], [yj, zj]])
    derivative_blocks = [Kjet, A00.diff(u).subs(u, 1) - Kjet,
                         A20.diff(u).subs(u, 1) - Kjet,
                         (H0 - A00 - A20).diff(u).subs(u, 1) + Kjet]
    jet_eq = [s.expand(scalar_form(M, k)) for M, k in zip(derivative_blocks, kernels)]
    expected_jets = [4 * xj + 4 * yj + zj, -xj - 4 * yj - 4 * zj,
                     -4 * xj + 4 * yj - zj + R(16, 3),
                     xj - 4 * yj + 4 * zj - R(16, 3)]
    zero("the four complete scalar kernel derivative equations", s.Matrix(jet_eq) - s.Matrix(expected_jets))
    jet_solution = s.solve(jet_eq, (xj, yj, zj), dict=True)
    require("the contact derivative is uniquely forced", jet_solution == [dict(zip(
        (xj, yj, zj), (Gprime[0, 0], Gprime[0, 1], Gprime[1, 1])))])
    hatprime = Gc + 2 * Gprime
    zero("cubic-over-(1+u) forced numerator derivative", hatprime - s.Matrix(
        [[R(7, 5), -2], [-2, R(12, 5)]]))
    zero("endpoint upper bounds use exact complementary diagonal entries", (B00 - A20)[0, 0]
         - (1 - (1 + u**2) / 3))
    qA, qB, qC, lA, lB, lC = s.symbols("qA qB qC lA lB lC")
    qpoly = qA + qB * u + qC * u**2
    Lpoly = lA + lB * u + lC * u**2
    endpoint_solution = s.solve([Lpoly.subs(u, 0), Lpoly.diff(u).subs(u, 0), Lpoly.subs(u, 1)],
                               (lA, lB, lC), dict=True)
    require("degree-two endpoint/contact remainder is forced to zero", endpoint_solution == [
        {lA: 0, lB: 0, lC: 0}])
    require("raw contact derivative contradiction is nonzero", R(2, 3) - Gprime[0, 0] == R(2, 15))
    require("cubic numerator derivative contradiction is nonzero", R(5, 3) - hatprime[0, 0] == R(4, 15))

    features, Qsmall = polynomial_gram_witness()
    fsmall = [s.Matrix([state[i] * u**j * v**k for i, j, k in group]) for group in features]
    zero("independent complete polynomial SOS witness at the excluded source", F.subs(c0sub)
         - sum(scalar_form(Q, f) for Q, f in zip(Qsmall, fsmall)))
    small_minors = []
    for index, (Q, f) in enumerate(zip(Qsmall, fsmall)):
        ev = f.subs(angle0).subs(dict(zip((W, X, Y, Z), psi0)))
        zero(f"polynomial witness block {index} exact contact kernel", Q * ev)
        minors = [s.factor(Q[:k, :k].det()) for k in range(1, Q.rows)]
        require(f"polynomial witness block {index} positive compression", all(t > 0 for t in minors) and ev[-1] != 0)
        small_minors.append([str(t) for t in minors])

    coopath = HERE / "inputs" / "C1_ENLARGED_PRIMAL.coo.json"
    coo = json.loads(coopath.read_text())
    enlarged = []
    for group in coo["features"]:
        mapping = {tuple(t): i for i, t in enumerate(group)}
        M = s.zeros(len(group))
        for f, Q in zip(features, Qsmall):
            require("all polynomial witness features occur in a current enlarged block", all(tuple(t) in mapping for t in f))
            for i, ti in enumerate(f):
                for j, tj in enumerate(f):
                    M[mapping[tuple(ti)], mapping[tuple(tj)]] += 4 * Q[i, j]
        enlarged.append(M)
    fullgram = s.diag(*enlarged, s.Matrix([[c0[0]]]))
    auxiliary = [enlarged[g][i, j] for g, i, j in coo["free_positions"]]
    values = [s.Integer(0)] + c0 + auxiliary
    require("actual COO variable indexing has the full visible and auxiliary list", len(values) == 1 + len(coo["variables"]))
    recovered = s.zeros(coo["matrix_order"])
    for var, i, j, coefficient in coo["entries"]:
        value = R(coefficient) * values[var]
        recovered[i, j] += value
        if i != j:
            recovered[j, i] += value
    zero("every entry of the ACTUAL enlarged affine COO at the explicit witness", recovered - fullgram)
    expanded_witness = 0
    for weight, group, M in zip(coo["weights"], coo["features"], enlarged):
        f = s.Matrix([state[i] * u**j * v**k for i, j, k in group])
        expanded_witness += u**weight[0] * v**weight[1] * scalar_form(M, f)
    zero("actual enlarged full-parent normalization and multiplier", expanded_witness
         - 4 * (1 + u) * (1 + v) * F.subs(c0sub))

    c1 = [R(1), R(32, 115), R(4, 23), R(21, 46), R(13, 230), R(7, 23), R(9, 46)]
    sub1 = dict(zip(source_symbols, c1))
    psi1 = s.Matrix([1, -R(1, 2), R(1, 3), 1])
    P1 = P.subs(sub1)
    require("nonsquare example has all seven positive coefficients", all(t > 0 for t in c1))
    zero("nonsquare physical example full state kernel", P1.subs({u: 1, v: 1}) * psi1)
    zero("nonsquare physical example both angular derivatives", s.Matrix([
        scalar_form(P1.diff(t).subs({u: 1, v: 1}), psi1) for t in (u, v)]))
    slope1 = s.factor(slope.subs(sub1))
    require("nonsquare example has two distinct endpoint linear factors", slope1 == R(921984, 6996025))
    require("nonsquare example endpoint slopes and intercepts are positive", all(s.factor(t.subs(sub1)) > 0
            for t in (xx0, xx1, yy0, yy1, outer["p10"])))

    data = {
        "schema": "C1_low_denominator_joint_effect_obstruction_v1",
        "scope": "Exact impossibility of polynomial qG for a common polynomial q of degree <=2, q(u)>0 on u>0, in the four-effect selector. The enlarged G1 converse remains OPEN.",
        "source_order": [str(t) for t in source_symbols],
        "quarter_parent_normalization": "F=psi^T(P_full/4)psi; enlarged COO represents (1+u)(1+v)P_full.",
        "obstruction_source": [str(t) for t in c0],
        "contact_angles": [str(p0), str(q0)],
        "contact_state": [str(t) for t in psi0],
        "core_contact_expectation": str(core_value),
        "laurent_coefficients": {key: str(s.factor(value.subs(c0sub))) for key, value in {**outer, "p11": p11}.items()},
        "contact_G": mat_json(Gc),
        "contact_G_derivative": mat_json(Gprime),
        "contact_effects": [mat_json(M) for M in Ec],
        "effect_kernel_vectors": [[str(t) for t in k] for k in kernels],
        "contact_jet_equations": [str(t) for t in jet_eq],
        "endpoint_forced_G00": "u**2/3",
        "derivative_gap": "2/15",
        "cubic_numerator_derivative_gap": "4/15",
        "polynomial_witness_features": features,
        "polynomial_witness_quarter_grams": [mat_json(M) for M in Qsmall],
        "polynomial_witness_positive_compression_minors": small_minors,
        "current_enlarged_input_sha256": sha(coopath),
        "current_enlarged_full_parent_gram_blocks": [mat_json(M) for M in enlarged],
        "current_enlarged_auxiliary_values": [str(t) for t in auxiliary],
        "current_enlarged_scalar_block": "1",
        "nonsquare_example_source": [str(t) for t in c1],
        "nonsquare_example_contact": ["1", "1", "1", "-1/2", "1/3", "1"],
        "nonsquare_example_endpoint_slope_determinant": str(slope1),
    }
    datapath = HERE / "C1_JOINT_SELECTOR_OBSTRUCTION.json"
    if args.write_data:
        datapath.write_text(json.dumps(data, indent=2) + "\n")
    require("frozen exact data agree with fresh independent reconstruction", datapath.exists()
            and json.loads(datapath.read_text()) == data)
    inputs = [coopath, HERE / "c1_joint_selector_obstruction.tex", HERE / "c1_endpoint_factorization.tex", datapath]
    receipt = {
        "status": "PASS",
        "check_count": len(checks),
        "checks": checks,
        "scope": data["scope"],
        "analytical_arguments_not_replaced_by_checks": [
            "Logarithmic convexity and the positive three-state Schur block establish all-angle, all-state physicality.",
            "For PSD effect functions, a fixed kernel scalar has zero first derivative at the contact.",
            "Near-zero and infinity polynomial growth bounds force the degree-two remainder to vanish.",
            "The exact derivative contradiction excludes the stated selector class, not the full enlarged frame.",
        ],
        "sympy_version": s.__version__,
        "script_sha256": sha(Path(__file__).resolve()),
        "inputs": [{"path": str(p.relative_to(HERE)), "sha256": sha(p)} for p in inputs],
        "elapsed_seconds": round(time.perf_counter() - start, 6),
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({k: receipt[k] for k in ("status", "check_count", "elapsed_seconds")}, sort_keys=True))


if __name__ == "__main__":
    main()
