#!/usr/bin/env python3
"""Solver-free exact checks for complete-parent constant-congruence rigidity.

The checker verifies the displayed polynomial identities and the explicit
physical example.  The theorem's kernel and positivity arguments are in
the accompanying proof, not replaced by numerical samples.
"""
from pathlib import Path
import hashlib
import json
import sympy as s

HERE = Path(__file__).resolve().parent
checks = []


def require(name, cond):
    if not cond:
        raise AssertionError(name)
    checks.append(name)


def zero(name, expr):
    require(name, s.cancel(expr) == 0)


u, v = s.symbols('u v')
W, X, Y, Z = state = s.symbols('W X Y Z')
d, n, m, C, A, D, al = coeff = s.symbols('d n m C A D alpha')
du, dv = 1+u*u, 1+v*v
P = (n*du*dv*X**2 + m*(v*W-X+u*v*Y-u*Z)**2
     + C*dv*(u*W-Y)**2+A*du*dv*Y**2
     + (D+d/2)*(u*W+u*v*X-Y-v*Z)**2
     + (al+d/2)*du*(v*Y-Z)**2+d*dv*(X+u*Z)**2/2
     - d*du*dv*Z**2/2)
M = s.hessian(P, state)/2
entries = {
    (0,0):m*v*v+(C+D+d/2)*u*u+C*u*u*v*v,
    (1,1):n+m+d/2+(n+d/2)*v*v+n*u*u+(n+D+d/2)*u*u*v*v,
    (2,2):A+C+D+d/2+(A+C+al+d/2)*v*v+A*u*u+(A+m+al+d/2)*u*u*v*v,
    (3,3):al+(m+al+d/2)*u*u+D*v*v,
    (0,1):v*((D+d/2)*u*u-m),
    (0,2):u*((m-C)*v*v-C-D-d/2),
    (0,3):-(m+D+d/2)*u*v,
    (1,2):-(m+D+d/2)*u*v,
    (1,3):u*(m+d/2-D*v*v),
    (2,3):v*(D-al-(m+al+d/2)*u*u),
}
for ij, expr in entries.items():
    zero('CR1 full matrix entry '+str(ij), M[ij]-expr)


def mon(expr, i, j):
    return s.Poly(s.expand(expr),u,v).coeff_monomial(u**i*v**j)


M0 = M.subs({u:0,v:0})
Mtop = M.applyfunc(lambda e: mon(e,2,2))
require('CR4 constant coefficient matrix', M0 == s.diag(0,n+m+d/2,A+C+D+d/2,al))
require('CR4 top coefficient matrix', Mtop == s.diag(C,n+D+d/2,A+m+al+d/2,0))

a,b,ss,x,y,z = s.symbols('a b ss x y z', nonzero=True)
h11,h12,h21,h22 = s.symbols('h11 h12 h21 h22')
# Form forced by the two one-dimensional kernels, before zero-entry tests.
k1,k2,k3,k4 = s.symbols('k1 k2 k3 k4')
S0=s.Matrix([[ss,k1,k2,0],[0,h11,h12,0],[0,h21,h22,0],[0,k3,k4,z]])
G0=S0.T*M0*S0
Gt=S0.T*Mtop*S0
zero('constant XZ forces bottom X entry',G0[1,3]-al*z*k3)
zero('constant YZ forces bottom Y entry',G0[2,3]-al*z*k4)
zero('top WX forces top X entry',Gt[0,1]-C*ss*k1)
zero('top WY forces top Y entry',Gt[0,2]-C*ss*k2)
Sb=S0.subs({k1:0,k2:0,k3:0,k4:0})
G=Sb.T*M.subs({u:a*u,v:b*v},simultaneous=True)*Sb
zero('U parity forces offdiagonal YX',mon(G[0,1],1,0)+ss*a*(C+D+d/2)*h21)
zero('V parity forces offdiagonal XY',mon(G[0,2],0,1)+ss*b*m*h12)

Sd=s.diag(ss,x,y,z)
G=Sd.T*M.subs({u:a*u,v:b*v},simultaneous=True)*Sd
zero('CR5 m from WW',mon(G[0,0],0,2)-m*b*b*ss*ss)
zero('CR5 m from WX',mon(G[0,1],0,1)+m*b*ss*x)
zero('CR5 WW/WY diagonal ratio',mon(G[0,0],2,0)+(a*ss/y)*mon(G[0,2],1,0))
zero('CR5 WZ minus XY',mon(G[0,3]-G[1,2],1,1)+(m+D+d/2)*a*b*(ss*z-x*y))
Gc=G.subs({x:b*ss,y:a*ss,z:a*b*ss})
zero('CR6 D+d/2',mon(Gc[0,1],2,1)-(D+d/2)*a*a*b*b*ss*ss)
zero('CR6 m+D+d/2',mon(Gc[0,3],1,1)+(m+D+d/2)*a*a*b*b*ss*ss)
zero('CR6 subtraction isolates angle a',-mon(Gc[0,3],1,1)-mon(Gc[0,1],2,1)-m*a*a*b*b*ss*ss)
Ga=Gc.subs(a,1)
zero('XZ U recovers d',mon(Ga[1,3],1,0)-(m+d/2)*b*b*ss*ss)
zero('ZZ V2 recovers D with b4',mon(Ga[3,3],0,2)-D*b**4*ss*ss)
require('CR3 whole matrix restored by scalar congruence',
        (Gc.subs({a:1,b:1})-ss*ss*M).applyfunc(s.expand)==s.zeros(4))
# Explicit source-readback functionals establish injectivity independently.
readback=[2*(mon(M[1,3],1,0)-mon(M[0,0],0,2)),
          mon(M[1,1],2,0),mon(M[0,0],0,2),mon(M[0,0],2,2),
          mon(M[2,2],2,0),mon(M[3,3],0,2),mon(M[3,3],0,0)]
for got,want in zip(readback,coeff):
    zero('CR3 explicit source readback '+str(want),got-want)

base=list(map(s.Rational,['1','295/466','27/233','967/466','22/699','1872/1631','967/466']))
src=dict(zip(coeff,base))
at={u:1,v:s.Rational(1,2),W:2,X:-s.Rational(1,10),Y:s.Rational(9,5),Z:1}
require('CR7 strictly positive source',all(q>0 for q in base))
for q in (*state,u,v):
    zero('CR8 complete contact derivative '+str(q),s.diff(P,q).subs(src).subs(at))
zero('CR8 complete contact value',P.subs(src).subs(at))
zero('CR8 exact negative signed core',s.diff(P,d).subs(at)+s.Rational(269,400))
zero('CR9 full core on Z=0',s.diff(P,d).subs(Z,0)-((u*W+u*v*X-Y)**2+du*v*v*Y*Y+dv*X*X)/2)
zero('CR9 core rows independent',s.Matrix([[u,u*v,-1],[0,0,v],[0,1,0]]).det()+u*v)
for name,change in [('Alice',{u:-u,Y:-Y,Z:-Z}),('Bob',{v:-v,X:-X,Z:-Z})]:
    zero('CR9 full sign gauge '+name,P.subs(change,simultaneous=True)-P)

Ms=M.subs(src)
det=s.cancel(Ms.det(method='domain-ge')/(du*du*dv*dv))
dp=s.Poly(det,u,v).as_dict()
require('CR9 exact seven-term determinant support',set(dp)=={(4,2),(2,4),(4,0),(0,4),(2,0),(0,2),(2,2)})
require('CR9 all six outer masses positive',all(dp[k]>0 for k in dp if k!=(2,2)))
require('CR9 exponent convexity spans plane',
        {(i//2-1,j//2-1) for i,j in dp if (i,j)!=(2,2)}=={(1,0),(0,1),(1,-1),(-1,1),(0,-1),(-1,0)})
L=det/(u*u*v*v)
for name,e in [('value',L),('u derivative',s.diff(L,u)),('v derivative',s.diff(L,v))]:
    zero('CR9 contact Laurent '+name,e.subs(at))
outer=[dp[(4,2)],dp[(2,4)],dp[(2,0)],dp[(0,2)]]
expected=[s.Rational(i,20631068647) for i in [8270054760,151573675968,6265022808,21103382520]]
require('CR11 exact four radial coefficients',outer==expected)
aa,bb,dd,ee=outer
zero('CR12 infinity radial limit',dd/aa-s.Rational(2231,2945))
zero('CR12 zero radial limit',ee/bb-s.Rational(2505,17992))
require('CR12 strict radial variation',dd*bb-ee*aa>0)
t,r=s.symbols('t r',positive=True)
rr=(dd*t+ee/t)/(aa*t+bb/t)
zero('CR10 exact radial stationary equation',
     (aa*t+bb/t)*rr-(dd*t+ee/t))
zero('CR12 derivative of squared radial minimizer',
     s.diff(rr,t)-2*t*(dd*bb-ee*aa)/(aa*t*t+bb)**2)

proof=HERE/'c2_constant_congruence_rigidity.tex'
result={'status':'PASS','assertions':len(checks),'checks':checks,
        'scope':'Full-parent constant-state congruence rigidity for strictly positive event coefficients; not a G2 converse or counterexample.',
        'proof':{'path':proof.name,'sha256':hashlib.sha256(proof.read_bytes()).hexdigest()},
        'example':{'coefficients':list(map(str,base)),
                   'contact':['1','1/2','2','-1/10','9/5','1'],
                   'radial_limit_infinity':'2231/2945','radial_limit_zero':'2505/17992'}}
(HERE/'check_c2_constant_congruence_rigidity.json').write_text(json.dumps(result,indent=2)+'\n')
print('PASS',len(checks))
