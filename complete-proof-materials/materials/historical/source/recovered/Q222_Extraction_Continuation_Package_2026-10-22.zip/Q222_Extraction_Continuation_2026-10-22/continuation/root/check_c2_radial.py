#!/usr/bin/env python3
"""Fresh exact checks of the full C2 radial reduction and sign decision."""
from pathlib import Path
import json
import sympy as s
from c2_radial import (u,v,x,W,X,Y,Z,state,source,parent,matrix,coefficients,
                       decide,positive_cells)

HERE=Path(__file__).resolve().parent
checks=[]
def require(name,condition):
    if not condition:
        raise AssertionError(name)
    checks.append(name)
def zero(name,value):
    require(name,s.cancel(value)==0)

h,a,b,p,q,f,g=coefficients()
du,dv=1+u*u,1+v*v
det=s.cancel(matrix.det(method='domain-ge')/(du*du*dv*dv))
zero('complete generic determinant and all seven Laurent coefficients',
     det-(h*u*u*v*v+a*u**4*v*v+b*u*u*v**4+p*u**4+q*v**4+f*u*u+g*v*v))
r,t=s.symbols('r t',positive=True)
U,V=s.symbols('U V',positive=True)
HH,aa,bb,pp,qq,ff,gg=s.symbols('h a b p q f g')
L=HH+aa*U+bb*V+pp*U/V+qq*V/U+ff/V+gg/U
radial=HH+pp*t*t+qq/(t*t)+r*(aa*t+bb/t)+(ff*t+gg/t)/r
zero('radial substitution retains every Laurent term',L.subs({U:r*t,V:r/t})-radial)
zero('minimum radicand after x=t squared',
     x*x*(aa*ff*x+bb*gg/x+aa*gg+bb*ff)-x*(aa*x+bb)*(ff*x+gg))
T=pp*x*x+HH*x+qq
R=x*(aa*x+bb)*(ff*x+gg)
Delta=s.expand(4*R-T*T)
require('quartic sign polynomial has degree at most four',s.Poly(Delta,x).degree()==4)
expected={4:-pp*pp,3:4*aa*ff-2*pp*HH,
          2:4*(aa*gg+bb*ff)-HH*HH-2*pp*qq,
          1:4*bb*gg-2*HH*qq,0:-qq*qq}
for exponent,value in expected.items():
    zero('quartic coefficient '+str(exponent),s.Poly(Delta,x).coeff_monomial(x**exponent)-value)

seed=['1','7/8','9/8','1/18','11/8','9/8','1/18']
psi=s.Matrix([1,-s.Rational(1,10),s.Rational(1,10),1])
sub=dict(zip(source,map(s.Rational,seed)))
M=matrix.subs(sub)
require('sharp seed kernel',M.subs({u:1,v:1})*psi==s.zeros(4,1))
for angle in (u,v):
    zero('sharp seed angular jet '+str(angle),(psi.T*M.diff(angle).subs({u:1,v:1})*psi)[0])
require('sharp seed positive upper principal minors',all(M.subs({u:1,v:1})[:i,:i].det()>0 for i in (1,2,3)))
require('sharp seed positive Laurent masses',all(z>0 for z in coefficients(seed)[1:]))

examples=[]
def example(label,values,expected):
    result=decide(values)
    require(label,result['physical_in_C2'] is expected)
    examples.append({'label':label,**result})
example('sharp positive seed is physical',seed,True)
example('larger deficit violates the same physical contact',['2',*seed[1:]],False)
example('positive D event addition is physical',seed[:5]+['17/8']+seed[6:],True)
example('zero source is physical',['0']*7,True)
example('event-only source with multiple zeros is physical',['0','0','2','0','0','3','0'],True)
example('bare positive deficit is nonphysical',['1','0','0','0','0','0','0'],False)

# Algebraic boundary samples and close rational roots exercise the actual
# exact cell-isolation logic rather than floating-point tolerances.
for label,expression,count in [
    ('no real roots',x*x+1,1),
    ('multiple root at zero removed',x**4*(x-1)**2*(x-2),3),
    ('positive and negative rational roots',(x+2)*(x-1)*(x-3),3),
    ('irrational positive roots',x**4-5*x*x+6,3),
    ('very small positive rational root',(x-s.Rational(1,10**20))*(x-2),3)]:
    points,intervals=positive_cells(s.Poly(expression,x))
    require(label+' complete number of open positive cells',len(points)==count)
    require(label+' exact nonroot samples',all(z>0 and expression.subs(x,z)!=0 for z in points))

added=seed[:5]+['17/8']+seed[6:]
hh,aa0,bb0,pp0,qq0,ff0,gg0=coefficients(added)
require('physical positive source has varying minimizing radial parameter',ff0*bb0!=gg0*aa0)
generic={str(name):str(value) for name,value in zip(s.symbols('h a b p q f g'),(h,a,b,p,q,f,g))}
(HERE/'C2_RADIAL_DATA.json').write_text(json.dumps({
    'source_order':list(map(str,source)),
    'generic_coefficients':generic,
    'T':'p*x^2+h*x+q',
    'R':'x*(a*x+b)*(f*x+g)',
    'Delta':'-p^2*x^4+(4*a*f-2*p*h)*x^3+(4*(a*g+b*f)-h^2-2*p*q)*x^2+(4*b*g-2*h*q)*x-q^2',
    'exact_membership':'For nonnegative source coordinates: for every x>0, T(x)>=0 or Delta(x)>=0.',
    'varying_radial_example':{'source':added,'f_over_a':str(ff0/aa0),'g_over_b':str(gg0/bb0)},
    'examples':examples,
    'scope':'Physicality decision only. These quartic source functions are not affine matrix columns, and this does not prove G2.'
},indent=2)+'\n')
(HERE/'CHECK_C2_RADIAL.json').write_text(json.dumps({'status':'PASS','checks':checks,
    'number_of_checks':len(checks),'universal_G2_status':'OPEN'},indent=2)+'\n')
print('PASS:',len(checks),'exact C2 radial checks; G2 remains OPEN.')
