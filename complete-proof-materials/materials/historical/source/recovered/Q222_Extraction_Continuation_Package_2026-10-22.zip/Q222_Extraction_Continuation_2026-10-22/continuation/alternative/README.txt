Q222: exact selector reductions and a scoped obstruction
2026-10-22

RESULTS

1. univariate_completion_and_selector_obstruction.tex, UC1--UC17.
   The complete nine-source physical parent is equivalent to a quantified
   PSD8 completion: for every real Alice half-angle u, six skew variables
   may be chosen. The data include all 94 rational matrix coefficient
   records and the eight-feature/30-product table.

   A concrete globally physical rational C1 source has no polynomial skew
   selector K(u), of ANY degree, whose completion is PSD on the entire real
   u line in this all-real-v representation. This is proved against the
   complete ordinary polynomial SOS space, using the actual old array's
   full matching space and an exact rational positive dual certificate.

   This is not an obstruction to half-line weighted, signed-gauge, rational,
   or algebraic selectors; enlarged G1/G2; C160; or general finite lifts.

2. enlarged_cubic_selector_reduction.tex, HS1--HS10.
   Each ACTUAL enlarged C1/C2 canonical cone is equivalent to the existence
   of 106 source-only coefficients making two cubic PSD8 matrix polynomials
   positive on u>=0. The reduction is exact, including all source zero
   faces. It does not assume a strict Gram or a nonzero contact coordinate.

   The generic cubic parameterization has 128 coefficients. The actual
   affine image, including all six forced-zero features, has dimension106.
   C1_ENLARGED_CUBIC_SELECTOR.coo.json contains436 rational matrix records;
   C2_ENLARGED_CUBIC_SELECTOR.coo.json contains428. Both also contain the
   exact old-302-auxiliary to new-106-coefficient map and a matching-space
   right inverse. The right inverse is not claimed to preserve positivity.

   The universal half-line quantifier remains. Eliminating it by univariate
   matrix Fejer--Riesz returns the existing enlarged Gram dictionary. Thus
   this is a smaller EQUIVALENT universal selection problem, not a proved
   universal source converse or an evaluated global affine lift.

RUN

Python3 and SymPy suffice. No solver, network, or external workspace source
is needed. Run from this directory:

  python check_univariate_completion_and_obstruction.py
  python check_enlarged_selector_reduction.py

The scripts overwrite only their own exports and receipts in this folder.
The recorded exact runs have respectively122 and1654 assertions. These
counts overlap in elementary content; no combined completeness total is
formed. Analytical uses of Fejer--Riesz, Newton support, and the degree
argument are explicit in the proofs, rather than inferred from counts.

SCOPE OF OTHER ROUTES EXAMINED

The inherited C160 full-orbit construction is still an outer candidate.
Its reverse concentration statement is a separate universal obligation.
None of the obstructions here applies to C160 without a new embedding or
architecture proof.

The historical finite-Bob-space NDWU obstruction concerns the much narrower
architecture in which each Bob-only factor is independent of Alice's
measurement angle and is coupled to one Alice-outcome projector, while the
identity must hold for arbitrary Alice projections. It is not a theorem
against finite Bob monomials with Alice-dependent coefficients. Indeed the
pointwise Fejer--Riesz construction in UC6 supplies just such coefficients.
No NDWU obstruction is used as a premise for the enlarged cones or C160.

The finite local square-root expressions from a tensor-SOS existence proof
do not themselves supply a globally fixed feature list. UC17 gives a small
example distinguishing the span of selected roots from the existence of a
different fixed square space. A common finite product table must be proved
to represent every required source; compactness or QE enumeration alone
does not evaluate that table.

The original required global checklist remains unchanged: the central
universal enlarged gates are open, and the downstream assembly/verification
items depending on them are not complete.

CUSTODY

All local input copies are unchanged. INPUTS.json records original paths,
hashes, and byte counts. All new files are confined to this alternative
directory. No historical release or original source was modified.

PRIMARY THEOREM

Aljaz Zalar, Matrix Fejer--Riesz Theorem with gaps, arXiv:1503.06034v2,
Theorem1.1. https://arxiv.org/pdf/1503.06034

The half-line cubic representation is derived in HS4 by substituting x=t^2
and averaging the even/odd parts of the degree-three realified factor.
