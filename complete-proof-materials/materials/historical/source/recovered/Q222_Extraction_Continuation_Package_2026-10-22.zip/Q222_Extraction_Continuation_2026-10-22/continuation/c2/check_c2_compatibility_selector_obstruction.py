#!/usr/bin/env python3
"""Exact full-parent and contact proof of two restricted-selector failures.

No optimizer, prior status receipt, or numerical positivity test is used.
The proof is about the four-PSD2 compatibility ansatz, not the enlarged
two-angle Gram candidate.
"""
from pathlib import Path
import hashlib
import json
import sympy as s

HERE=Path(__file__).resolve().parent
CHECKS=[]


def require(name, value):
    if not value:
        raise AssertionError(name)
    CHECKS.append(name)


def simp(x):
    return s.factor(s.radsimp(s.cancel(x)))


def zero(name, value):
    require(name,s.simplify(simp(value))==0)


u,v=s.symbols('u v')
W,X,Y,Z=state=s.symbols('W X Y Z')
d,n,m,C,A,D,al=coeff=s.symbols('d n m C A D alpha')
du,dv=1+u*u,1+v*v
P=(n*du*dv*X**2+m*(v*W-X+u*v*Y-u*Z)**2
   +C*dv*(u*W-Y)**2+A*du*dv*Y**2
   +(D+d/2)*(u*W+u*v*X-Y-v*Z)**2
   +(al+d/2)*du*(v*Y-Z)**2+d*dv*(X+u*Z)**2/2-d*du*dv*Z**2/2)
M=s.hessian(P,state)/2
r=s.Matrix([u,-1]); ss=s.Matrix([1,u])
A0=(C+D+d/2)*r*r.T+A*du*s.diag(0,1)
A2=C*r*r.T+m*ss*ss.T+(A+al+d/2)*du*s.diag(0,1)
B0=(m+d/2)*ss*ss.T+du*s.diag(n,al)
B2=D*r*r.T+(n+d/2)*du*s.diag(1,0)
require('CS1 full coefficient identity T',
        (A0-A2-B2+B0).applyfunc(s.expand)==s.zeros(2))
yy=s.Matrix([W,Y]);zz=s.Matrix([X,Z]);T=A0-A2
zero('CS2 entire C2 parent',P-(yy.T*(A0+v*v*A2)*yy)[0]
     -(zz.T*(B0+v*v*B2)*zz)[0]-2*v*(yy.T*T*zz)[0])
g00,g01,g11=s.symbols('g00 g01 g11')
G=s.Matrix([[g00,g01],[g01,g11]])
R=B0-A2+G
decomp=((yy+v*zz).T*(A0-G)*(yy+v*zz))[0]+((v*yy-zz).T*(A2-G)*(v*yy-zz))[0]+dv*((yy.T*G*yy)[0]+(zz.T*R*zz)[0])
zero('CS3 whole state compatibility identity',decomp-P)
zero('CS10 upper endpoint scalar',(A0-G)[0,0]-(C+D+d/2)*u*u+g00)
zero('CS11 upper scalar',(A2-G)[0,0]-m-C*u*u+g00)
zero('CS11 lower scalar',R[0,0]-(n+d/2+(n-C)*u*u+g00))
zero('CS6 positive full core at Z=0',s.diff(P,d).subs(Z,0)-((u*W+u*v*X-Y)**2+du*v*v*Y*Y+dv*X*X)/2)
zero('CS6 independent core rows',s.Matrix([[u,u*v,-1],[0,0,v],[0,1,0]]).det()+u*v)
for name,sub in [('Alice',{u:-u,Y:-Y,Z:-Z}),('Bob',{v:-v,X:-X,Z:-Z})]:
    zero('CS6 full sign gauge '+name,P.subs(sub,simultaneous=True)-P)

outer={
    (4,2):A*C*(2*D+d+2*n)*(2*al+d+2*m)/4,
    (4,0):A*n*(2*C+2*D+d)*(2*al+d+2*m)/4,
    (2,4):C*D*(d+2*n)*(2*A+2*al+d+2*m)/4,
    (2,0):A*al*(2*C+2*D+d)*(d+2*m+2*n)/4,
    (0,4):D*m*(d+2*n)*(2*A+2*C+2*al+d)/4,
    (0,2):al*m*(d+2*n)*(2*A+2*C+2*D+d)/4,
}
det=s.cancel(M.det(method='domain-ge')/(du*du*dv*dv))
dp=s.Poly(det,u,v).as_dict()
require('CS6 exact seven-monomial determinant support',set(dp)==set(outer)|{(2,2)})
for key,val in outer.items():
    zero('CS6 factored outer coefficient '+str(key),dp[key]-val)


def one_case(name,source,contact):
    src=dict(zip(coeff,source));at={u:1,v:1,**dict(zip(state,contact))}
    require(name+' d positive',source[0]>0)
    require(name+' event coefficients nonnegative',all(q>=0 for q in source[1:]))
    for q in (*state,u,v):
        zero(name+' complete contact derivative '+str(q),s.diff(P,q).subs(src).subs(at))
    zero(name+' full contact value',P.subs(src).subs(at))
    core=simp(s.diff(P,d).subs(at))
    require(name+' strictly negative quarter-core',core<0)
    masses=[simp(q.subs(src)) for q in outer.values()]
    require(name+' six nonnegative outer masses',all(q>=0 for q in masses))
    L=det/(u*u*v*v)
    for q,label in [(L,'value'),(s.diff(L,u),'u derivative'),(s.diff(L,v),'v derivative')]:
        zero(name+' Laurent contact '+label,q.subs(src).subs(at))
    y=s.Matrix([contact[0],contact[2]]);z=s.Matrix([contact[1],contact[3]])
    hp=y+z;hm=y-z
    a0=A0.subs(src);a2=A2.subs(src);b0=B0.subs(src)
    ker=[G*y,(a0.subs(u,1)-G)*hp,(a2.subs(u,1)-G)*hm,(b0.subs(u,1)-a2.subs(u,1)+G)*z]
    eq=s.Matrix.vstack(*ker)
    coeffmat,rhs=s.linear_eq_to_matrix(list(eq),(g00,g01,g11))
    require(name+' contact G constraint rank three',coeffmat.rank()==3)
    sol=s.solve(list(eq),(g00,g01,g11))
    require(name+' unique full contact G',set(sol)=={g00,g01,g11})
    Gc=G.subs(sol).applyfunc(simp)
    for i,e in enumerate(ker):
        require(name+' contact kernel '+str(i),e.subs(sol).applyfunc(simp)==s.zeros(2,1))
    der=[(y.T*G*y)[0],(hp.T*(G-a0.diff(u).subs(u,1))*hp)[0],
         (hm.T*(G-a2.diff(u).subs(u,1))*hm)[0],
         (z.T*(G+b0.diff(u).subs(u,1)-a2.diff(u).subs(u,1))*z)[0]]
    dmat,drhs=s.linear_eq_to_matrix(der,(g00,g01,g11))
    require(name+' derivative G constraint rank three',dmat.rank()==3)
    ds=s.solve(der,(g00,g01,g11))
    require(name+' unique full contact derivative',set(ds)=={g00,g01,g11})
    Gp=G.subs(ds).applyfunc(simp)
    for i,e in enumerate(der):
        zero(name+' derivative kernel '+str(i),e.subs(ds))
    blocks=[Gc,a0.subs(u,1)-Gc,a2.subs(u,1)-Gc,b0.subs(u,1)-a2.subs(u,1)+Gc]
    for i,B in enumerate(blocks):
        zero(name+' contact PSD2 rank one '+str(i),B.det())
        require(name+' contact PSD2 positive trace '+str(i),simp(s.trace(B))>0)
    J=[]
    psc=s.Matrix(contact)
    for co in coeff:
        Mi=M.diff(co)
        J.append((Mi.subs({u:1,v:1})*psc).col_join(s.Matrix([
            (psc.T*Mi.diff(u).subs({u:1,v:1})*psc)[0],
            (psc.T*Mi.diff(v).subs({u:1,v:1})*psc)[0]])))
    J=s.Matrix.hstack(*J)
    minor=simp(J[:,1:].det())
    require(name+' full six-by-seven contact matrix',
            (J*s.Matrix(source)).applyfunc(simp)==s.zeros(6,1))
    return {'source':list(map(str,source)),'contact':['1','1']+list(map(str,contact)),
            'G_contact':[[str(x) for x in row] for row in Gc.tolist()],
            'G_derivative':[[str(x) for x in row] for row in Gp.tolist()],
            'event_minor':str(minor),'quarter_core':str(core)},Gc,Gp,minor


rat=list(map(s.Rational,['1','3/64','7/32','3/8','35/128','7/32','3/8']))
ratdata,Gc,Gp,minor=one_case('CS5 rational regular source',rat,[s.S.One,-s.Rational(1,4),s.Rational(1,2),s.S.One])
require('CS5 all six event coefficients strictly positive',all(q>0 for q in rat[1:]))
require('CS5 belongs to regular contact domain',minor!=0)
require('CS5 printed quarter-core',ratdata['quarter_core']=='-29/32')
require('CS9 complete printed contact matrix',Gc==s.Rational(35,96)*s.Matrix([[1,-2],[-2,4]]))
require('CS9 complete printed derivative matrix',Gp==s.Rational(175,1152)*s.Matrix([[4,-5],[-5,4]]))
zero('CS9 first contact entry',Gc[0,0]-s.Rational(35,96))
zero('CS9 first derivative entry',Gp[0,0]-s.Rational(175,288))
beta=simp(2*Gp[0,0]-3*Gc[0,0]-rat[3])
zero('CS13 forced cubic coefficient',beta+s.Rational(73,288))
zero('CS14 exact endpoint violation',beta+rat[1]+s.Rational(119,576))
require('CS14 strict contradiction',beta+rat[1]<0)

sqrt3=s.sqrt(3)
alg=[s.S.One,s.S.Zero,(sqrt3-1)/4,s.Rational(1,2),sqrt3-s.Rational(3,2),(sqrt3-1)/4,s.Rational(1,2)]
algdata,Gc,Gp,_=one_case('CS15 algebraic zero face',alg,[s.S.One,sqrt3-2,1/sqrt3,s.S.One])
require('CS15 exactly the n-zero event face',alg[1]==0 and all(q>0 for q in alg[2:]))
zero('CS15 printed quarter-core',s.sympify(algdata['quarter_core'])-(6-4*sqrt3))
zero('CS16 first contact entry',Gc[0,0]-s.Rational(1,2))
zero('CS16 first derivative entry',Gp[0,0]-sqrt3/2)
require('CS17 derivative contradiction',simp(Gp[0,0]-2*alg[3])!=0)
a,b=s.symbols('a b')
L=u*u*(a+b*u)
zero('CS13 cubic contact interpolation',s.diff(L,u).subs(u,1)-2*L.subs(u,1)-b)
# The elementary divisibility argument: a polynomial of degree <=2 with
# a double root at 0 and a root at 1 is identically zero.
c0,c1,c2=s.symbols('c0 c1 c2')
low=c0+c1*u+c2*u*u
require('CS17 low-degree Hermite system full rank',
        s.linear_eq_to_matrix([low.subs(u,0),s.diff(low,u).subs(u,0),low.subs(u,1)],(c0,c1,c2))[0].det()!=0)

proof=HERE/'c2_compatibility_selector_obstruction.tex'
receipt={'status':'PASS','assertions':len(CHECKS),'checks':CHECKS,
         'scope':'Exact failures of the restricted four-PSD2 low-degree selector; not a refutation of either two-angle C2 Gram candidate.',
         'proof':{'path':proof.name,'sha256':hashlib.sha256(proof.read_bytes()).hexdigest()},
         'rational_example':ratdata,'algebraic_example':algdata}
(HERE/'check_c2_compatibility_selector_obstruction.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('PASS',len(CHECKS))
print('rational event minor:',minor)
