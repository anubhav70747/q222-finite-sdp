# C1 finite-lift gate: exact low-denominator obstruction

## Current mathematical result

The proposed four-effect compatibility selector cannot be made uniform
with a common polynomial denominator of degree at most two. This includes
the proposed cubic numerator divided by `1+u`.

The exact counterexample, in the coefficient order
`(d,m,C,A,D,alpha,beta)`, is

```
(1, 1/3, 1/3, 1/4, 1/6, 1/4, 1/6).
```

It has the full sharp contact

```
u=1, v=3/4, state=(1,-1/2,1/2,1).
```

This source is physical for every angle and state. An independent proof
uses the positive three-state principal block and the strictly convex
logarithmic Laurent determinant. A second proof is an explicit ordinary
polynomial SOS with four rational Gram blocks of orders 3,4,4,3.

The obstruction is a contact-jet contradiction. Every differentiable
four-effect selector must satisfy

```
G(1)  = [[1/3,-2/3],[-2/3,4/3]],
G'(1) = [[8/15,-2/3],[-2/3,8/15]].
```

If a common polynomial `q` has degree at most two, is positive on `u>0`,
and makes `qG` polynomial, the endpoint inequalities instead force
`G00(u)=u^2/3`. Its derivative at one differs from the required derivative
by exactly `2/15`. No numerical infeasibility inference is used.

The source is fixed by the C1 reflection, so applying that reflection does
not repair this selector proposal.

## What remains open

**The universal enlarged C1 converse G1 remains open.** The source above
is explicitly feasible in the actual enlarged order-59 C1 pencil. The
data supply all 302 auxiliary values, and the checker verifies every COO
entry against the explicit positive Gram blocks. Thus this result does
not refute that enlarged pencil. It also does not rule out higher-degree
denominators, other function classes, or the general two-stage selector.

The companion factorization gives an exact scalar radial minimum and a
positive sharp source for which its remaining radical is not rational.
The latter is a statement about that particular scalar function, not an
impossibility theorem for rational Gram selectors or affine SDP lifts.

## Frozen mathematical deliverables

- `c1_joint_selector_obstruction.tex`: complete parent, pointwise
  compatibility identity, physicality, exact jet contradiction, and
  explicit ordinary/enlarged Gram witness (CJO1–CJO20).
- `c1_endpoint_factorization.tex`: endpoint determinants, factorization,
  exact radial minimum, and nonsquare example (CEF1–CEF8).
- `C1_JOINT_SELECTOR_OBSTRUCTION.json`: exact rational source, contacts,
  jets, Gram blocks, actual enlarged auxiliary values, and second example.
- `check_joint_selector_obstruction.py`: exact SymPy checker.
- `CHECK_JOINT_SELECTOR_OBSTRUCTION.json`: current PASS76 receipt.
- `inputs/C1_ENLARGED_PRIMAL.coo.json`: unchanged actual candidate arrays.
- `joint_selector_note.tex` and `.pdf`: six-page standalone presentation.

The lead and an independent C2 reviewer accepted the printed mathematical
scope. The independent review is recorded separately in
`../c2/REVIEW_C1_SELECTOR_OBSTRUCTION.json`; it is not required to replay
the exact calculations. All six standalone PDF pages were rendered and
visually inspected. No clipping, overlap, missing symbols, or unintended
equation numbering was found.

## Portable exact replay

Only Python 3 and SymPy are required; the reviewed run used SymPy 1.14.0.
Run from any working directory:

```sh
python3 /path/to/c1/check_joint_selector_obstruction.py --output /tmp/c1-selector-replay.json
```

The script resolves all inputs relative to its own directory. The
`--output` option keeps the delivered receipt unchanged. The optional
`--write-data` flag is for initial construction and should not be used
for a normal verification replay.

The 76 checks corroborate the full algebra. The printed proof, rather
than the number of checks, supplies logarithmic convexity, positivity
over unbounded testing domains, and the quantified polynomial-growth
argument.

## Optional discovery files

`enlarged_probe.py`, `joint_selector_discovery.py`, and their numerical
JSON outputs are exploratory records. They are not proof dependencies.
They require NumPy, SciPy, CVXPY and a compatible solver. Small numerical
residuals or sampled feasibility are not global coverage evidence. No
numerical survey was used to assert G1.

`JOINT_SELECTOR_DEPENDENCIES.json` records the actual frozen proof,
checker, data and evaluated input bindings. `FROZEN_FILES.json` lists the
files selected for this addendum without a self-referential hash entry.
