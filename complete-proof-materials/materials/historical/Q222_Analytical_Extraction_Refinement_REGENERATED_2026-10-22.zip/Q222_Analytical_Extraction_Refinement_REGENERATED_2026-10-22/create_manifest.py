#!/usr/bin/env python3
"""Create the manifest from an explicit release-file selection.

Build logs, scratch page images, temporary download files and Python bytecode
are not release inputs. The retained previous ZIP is included unchanged.
"""
from pathlib import Path
import hashlib
import json

ROOT=Path(__file__).resolve().parent
ROOT_FILES={
 'README.txt','requirements.txt','verify.py','create_manifest.py',
 'build_release_content.py','build_verification.py','CHECKLIST.json','CHECKLIST.txt',
 'GLOBAL_EXTRACTION_OBLIGATIONS.json','REPLAY_PLAN.json',
 'VERIFICATION.json','VERIFICATION.txt',
 'Q222_Analytical_Extraction_Refinement_REGENERATED_2026-10-22.pdf'
}
PUB_FILES={'main.tex','regular_c2.tex','tilted.tex','effective.tex',
           'checklist.tex','references.tex','PUBLICATION_TRANSFORMS.json'}
ALLOWED={'.py','.json','.txt','.tex','.md','.wl','.pdf','.zip'}

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def select():
    chosen=[]
    for p in ROOT.rglob('*'):
        if not p.is_file():continue
        rel=p.relative_to(ROOT)
        if '__pycache__' in rel.parts:continue
        if len(rel.parts)==1:
            keep=p.name in ROOT_FILES
        elif rel.parts[0]=='publication':keep=len(rel.parts)==2 and p.name in PUB_FILES
        elif rel.parts[0]=='verification':keep=len(rel.parts)==2 and (p.suffix=='.json' or p.name=='PDF_COMPILE.log')
        elif rel.parts[0]=='recovered':keep=p.name=='Q222_Extraction_Continuation_Package_2026-10-22.zip'
        elif rel.parts[0] in {'c2','diagonal','compiler','inputs'}:
            keep=p.suffix in ALLOWED and 'qa' not in rel.parts and not p.name.endswith('_pdf_compile.txt')
        else:keep=False
        if keep:chosen.append(p)
    return sorted(chosen,key=lambda p:p.relative_to(ROOT).as_posix())

def main():
    rows=[{'path':p.relative_to(ROOT).as_posix(),'bytes':p.stat().st_size,'sha256':sha(p)} for p in select()]
    assert rows and len({r['path'] for r in rows})==len(rows)
    data={'release':'Q222 Analytical Extraction Refinement - regenerated 2026-10-22',
          'schema':'sha256-path-size-v1','manifest_excludes_itself':True,
          'global_E1_E2_E3':'OPEN','historical_549_page_proof_recreated':False,
          'file_count':len(rows),'files':rows}
    (ROOT/'MANIFEST.json').write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')
    print(json.dumps({'status':'MANIFEST_CREATED','file_count':len(rows),'manifest_sha256':sha(ROOT/'MANIFEST.json')},sort_keys=True))

if __name__=='__main__':main()
