#!/usr/bin/env python3
"""Build the release checklist, reader guide, and publication fragments.

This script does not certify any open mathematical gate. It preserves every
component source and records the deterministic publication transformations.
"""
from pathlib import Path
import hashlib
import json
import re

ROOT=Path(__file__).resolve().parent
PUB=ROOT/'publication'
PUB.mkdir(exist_ok=True)

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def write_json(path,data): path.write_text(json.dumps(data,indent=2,sort_keys=True)+'\n')

items=[
 ('S01','COMPLETE','Recover and bind the retained source inputs',
  'The canonical August 30 source and the August 31 frozen ZIP match their recorded SHA-256 digests. The earlier continuation archive is preserved unchanged. This verifies custody, not all inherited mathematics.',
  ['inputs/SOURCE_CUSTODY.json','recovered/Q222_Extraction_Continuation_Package_2026-10-22.zip']),
 ('L01','COMPLETE','Explicitly separate every positive local coefficient',
  'The finite identity gamma=p(x)+q(y)+sum(A_i(x)+delta)(B_i(y)+delta) has explicit strict sign bounds and a fixed order-two block conversion. The toy 1+xy example is fully evaluated.',
  ['diagonal/diagonal_proofs.tex','diagonal/SEPARATED_COEFFICIENT_EXACT.json']),
 ('L02','COMPLETE','Prove the denominator-free smooth-diagonal construction',
  'Given exact J^2 data and positive tangential residue, add a normal Gram term, use a constant matrix change, and apply the fixed m^2-frame identity. The theorem leaves its global hypotheses to be instantiated.',
  ['diagonal/diagonal_proofs.tex','diagonal/DIAGONAL_FRAME_EXACT.json']),
 ('L03','COMPLETE_LOCAL','Evaluate a full regular-C2 contact box',
  'The complete parent, six contact equations, regular contact graph, exact Taylor matrix, 25 frames and rational radius are evaluated. The source/contact box and testing box vary independently. This is one normalized local domain.',
  ['c2/regular_c2_local_proof.tex','c2/regular_c2_frames.json','c2/regular_c2_independent_verification.json']),
 ('L04','COMPLETE_LOCAL','Evaluate the regular-C2 feature list and product map',
  'Delivered: 785 order-two blocks, 1570 listed feature entries with repetitions, 237 ambient monomials, 27747 product coefficients, and 295 target coefficients in seven source columns. These do not specify a global eight-coordinate quantum lift.',
  ['c2/regular_c2_feature_list.json','c2/regular_c2_product_map.json','c2/regular_c2_build.py','c2/regular_c2_check.py']),
 ('B01','COMPLETE_MODULE','Extract the displayed B0 coefficient module',
  'The four displayed coefficient scalars form exactly the nonnegative orthant, with four rational necessity tests, nine polynomial square features, and an order-four diagonal pencil. August repair R5 factor typing is retained.',
  ['diagonal/B0_EXACT.json','diagonal/diagonal_proofs.tex']),
 ('B02','COMPLETE_CONDITIONAL','Bound the feature envelope under a fixed-testing-variable congruence',
  'Twenty monomials suffice when the 4-by-4 state congruence is independent of polynomial-testing variables U,V. This is a conditional envelope; it does not assert that order-two blocks survive or that the physical restoration map is known.',
  ['diagonal/B0_EXACT.json','diagonal/diagonal_proofs.tex']),
 ('B03','OPEN','Supply the actual B0 radial restoration and clearing maps',
  'Required: the complete state congruence, every pure-factor scaling/clearing function and its domain, the original slack identity, original-coordinate map, and every singular or zero-factor branch. The retained base asserts a congruence but does not print these data.',
  ['inputs/canonical_august30/Q222_SXDEG2_CONSOLIDATED_PARCHMENT_FINAL_2026-08-30.md','inputs/frozen_august31/Q222_SXDEG2_CORRECTION_PATCH_AND_FREEZE_2026-08-31.md','diagonal/diagonal_proofs.tex']),
 ('C01','COMPLETE_RESTRICTED','Reconstruct the restricted event-contact cofactor vector',
  'All six reduced forms, thirty Jacobian entries and six primitive cofactors are evaluated; all five JX=0 identities hold. This is a restricted stationary-contact parametrization, not a proof of global physical validity or boundary completeness.',
  ['diagonal/EVENT_CONTACT_EXACT.json','diagonal/DIAGONAL_VERIFICATION.json','diagonal/diagonal_proofs.tex']),
 ('T01','COMPLETE','Certify the complete tilted-CHSH support family',
  'The reflection SOS, attainment, all real tilt parameters, both signs, endpoint completion, and separately labelled real-closed-field factors are covered for the stated two-coordinate projection.',
  ['compiler/tilted_family_exact_extraction.tex','compiler/TILTED_SOURCE_CERTIFICATES.json']),
 ('T02','COMPLETE','Evaluate the tilted fixed features and affine pencils',
  'The order-five lift has one auxiliary and 14 nonzero upper coefficient records over Q(sqrt(2)); elimination gives order four, zero auxiliaries and 12 records. Original-coordinate substitution gives a projection cylinder.',
  ['compiler/TILTED_FIXED_FEATURES.json','compiler/TILTED_ORIGINAL_COORDINATE_LIFT.coo.json','compiler/TILTED_DIRECT_ELIMINATED.coo.json']),
 ('T03','COMPLETE','Prove both projected inclusions and exhibit the full-set limitation',
  'Both inclusions are proved for |t|<=1 and t^2+s^2/4<=2. The rational point (0,0,0,0,1,1,1/4,-1/4) passes all probability and relabelled tilted-family inequalities but is nonquantum.',
  ['compiler/tilted_family_exact_extraction.tex','compiler/TILTED_SCOPE_COUNTEREXAMPLE.json','compiler/CHECK_TILTED_EXTRACTION.json']),
 ('D01','COMPLETE','Audit the literal Schur-remainder extraction route',
  'A physical one-parameter complete-parent family has pairwise coprime literal remainder denominators and infinitely many linearly independent scalar remainders. This rules out that literal fixed-feature route, while the complete family itself has five fixed testing features.',
  ['c2/schur_remainder_proof.tex','c2/schur_remainder_data.json','c2/schur_remainder_verification.json']),
 ('A01','OPEN','Evaluate a finite global all-source/all-test atlas',
  'Required: a finite cover of the whole product domain, including exceptional, zero, boundary, projective, away-from-contact and normalization branches, with every restored slack identity. One regular rectangle and general local theorems do not establish the cover.',
  ['diagonal/diagonal_proofs.tex','GLOBAL_EXTRACTION_OBLIGATIONS.json']),
 ('G1','OPEN','Settle the retained enlarged-candidate C1 admission gate',
  'For the retained order-13744 candidate route, the stated C1 canonical admission/converse gate remains open. An alternative exact full-set construction could bypass this sufficient route. It is not made true by the local C2 extraction.',
  ['recovered/Q222_Extraction_Continuation_Package_2026-10-22.zip','inputs/prior_summary/GLOBAL_COMPILATION_RECEIPT.json']),
 ('G2','OPEN','Settle the retained enlarged-candidate C2 admission gate',
  'For the same retained enlarged candidate, the universal C2 admission/converse gate remains open. Exactness on the reciprocity-fixed sector or near one contact does not prove this universal gate.',
  ['recovered/Q222_Extraction_Continuation_Package_2026-10-22.zip','inputs/prior_summary/GLOBAL_COMPILATION_RECEIPT.json']),
 ('E1','OPEN','Deliver the evaluated global feature list and actual dimensions',
  'Required: one fixed finite global list with all radicands, domains, auxiliary variables and a proved completeness statement for every valid full-set affine slack. The present local counts are not global bounds.',
  ['GLOBAL_EXTRACTION_OBLIGATIONS.json','CHECKLIST.json']),
 ('E2','OPEN','Deliver the evaluated full eight-coordinate affine pencil',
  'Required: actual finite N,m and every coefficient of A0 + sum(q_nu A_nu) + sum(y_j B_j), exact algebraic encodings where necessary, and the projection to the original eight coordinates. No such exact full-set pencil is delivered.',
  ['GLOBAL_EXTRACTION_OBLIGATIONS.json','CHECKLIST.json']),
 ('E3','OPEN','Prove both full-set inclusions for that fixed pencil',
  'Required: physical-point lifting and exclusion of every nonquantum point using the delivered fixed coefficients, with exact replayable coefficient evidence. A projection-only proof, an outer approximation or unsolved QE formula does not satisfy this gate.',
  ['GLOBAL_EXTRACTION_OBLIGATIONS.json','CHECKLIST.json']),
 ('Q01','COMPLETE_CONDITIONAL','Specify a conditional exact algebraic extraction procedure',
  'The full rational nine-atom physical formula, real-algebraic coefficient descent theorem and fixed-pattern decision input are explicit. The M=3 order-two input is UNSOLVED: feasibility is not established and no quantifier elimination was run. Termination of the pattern search requires the corresponding existence premise.',
  ['compiler/effective_algebraic_extraction.tex','compiler/Q222_SOC_M3_UNSOLVED_INPUT.json','compiler/Q222_SOC_M3_UNSOLVED_INPUT.wl','compiler/CHECK_Q222_QE_ENCODING.json'])
]
obligations=[
 ('G01','Chart inventory','List every physical source and testing chart with its original-coordinate map, normalization and domain. Include all signs, axes and projective endpoints.'),
 ('G02','Full-slack restoration','Print and verify every exact state/observable congruence and scaling from a displayed local normal form back to the complete original slack. Handle every vanishing clearing factor.'),
 ('G03','Regular contacts','Evaluate sufficient regular anchors and their exact local matrices, radii, feature lists and source/test domains. Prove the asserted portion of the regular contact locus is covered.'),
 ('G04','Exceptional and boundary contacts','Supply exact certificates for rank drops, weak and zero openings, event boundaries, state axes and projective limits. Do not divide by a parameter allowed to vanish.'),
 ('G05','Away-from-contact region','Supply fixed separated positivity certificates on the remaining source/test cells with explicit valid domains and normalization control.'),
 ('G06','Finite global coverage','Prove the finite rectangles or finite cell atlas cover the complete product of all normalized valid supports and all physical tests. Deal explicitly with noncompact parameter directions.'),
 ('G07','Global feature system','Apply the finite cell construction, restore affine constants and homogeneities, and publish every fixed function with its radicand/domain and block membership. Determine actual dimensions.'),
 ('G08','Global product coefficients','Evaluate a basis containing 1 and the original eight coordinate functions plus all within-block products. Publish every exact expansion and any algebraic root-selection data.'),
 ('G09','Original-coordinate pencil','Write the actual matrices A0,A1,...,A8,B1,...,Bm and all equality constraints or their scalar-block encodings. Record index, symmetry, trace and projection conventions.'),
 ('G10','Both global inclusions and release','Prove physical points lift and every feasible projection is physical for the same fixed coefficients. Replay exact checks, bind source/dependency evidence, inspect the PDF and verify the complete archive.')
]
checklist={
 'release':'Q222 Analytical Extraction Refinement - regenerated 2026-10-22',
 'scope':'Supplementary extraction checklist, not a replacement certification of the historical 46-item R21 existence checklist.',
 'global_exact_lift_extraction_complete':False,
 'historical_549_page_proof_recreated':False,
 'status_convention':{'COMPLETE':'Complete only for the precisely stated item.','COMPLETE_LOCAL':'Complete on the displayed normalized local domain.','COMPLETE_MODULE':'Complete for the displayed abstract coefficient module.','COMPLETE_RESTRICTED':'Complete for the stated restricted contact equations.','COMPLETE_CONDITIONAL':'A theorem or construction with its stated hypotheses; missing global hypotheses are not certified.','OPEN':'The required full deliverable or proof is absent.'},
 'items':[{'id':i,'status':st,'title':title,'acceptance_and_result':desc,'evidence':ev} for i,st,title,desc,ev in items]
}
checklist['counts']={'total':len(items),'scoped_completed':sum(st!='OPEN' for _,st,_,_,_ in items),'open':sum(st=='OPEN' for _,st,_,_,_ in items)}
write_json(ROOT/'CHECKLIST.json',checklist)
write_json(ROOT/'GLOBAL_EXTRACTION_OBLIGATIONS.json',{'global_status':'OPEN','route':'Concrete global extraction from analytical local certificates','not_identical_to_retained_candidate_G1_G2':True,'obligations':[{'id':i,'name':n,'acceptance_criterion':d,'status':'OPEN'} for i,n,d in obligations]})

txt=['Q222 ANALYTICAL EXTRACTION REFINEMENT - REGENERATED 2026-10-22','PRECISE SUPPLEMENTARY CHECKLIST','',
 'GLOBAL EXACT FINITE-LIFT EXTRACTION: OPEN',
 'This release reconstructs the analytical refinement from retained sources and freshly regenerated data. It is not a byte-for-byte restoration or a fresh certification of the historical 549-page R21 proof.',
 'The 20 items below concern this refinement. Thirteen are complete within their stated local, restricted, module or conditional scopes; seven are open. The original global extraction items E1-E3 remain open.','']
for i,st,title,desc,ev in items:
 txt.extend([f'{i} [{st}] {title}',desc,'Evidence: '+', '.join(ev),''])
txt.extend(['CONCRETE GLOBAL DATA OBLIGATIONS','These G01-G10 labels are a new data list, distinct from the retained candidate gates G1 and G2.',''])
for i,n,d in obligations:txt.extend([f'{i} [OPEN] {n}',d,''])
txt.extend(['RETAINED CANDIDATE STATUS',
 'The unchanged earlier continuation archive retains an evaluated outer candidate of matrix order 13744 with 29920 auxiliary variables, 2928 blocks and 153248 nonzero upper coefficient records. Its recorded global reverse-inclusion field is false. These inherited arrays are preserved, not newly replayed in this regeneration; their status is not upgraded here.',
 'The older orders 8368 and 10736 are retained as rejected exact candidates in the earlier correction. Do not confuse them with the still-unsettled enlarged order-13744 candidate.','',
 'VERIFICATION CONVENTION',
 'File hashes establish custody and integrity. Symbolic receipts corroborate the named exact identities. Analytical review establishes only the conclusions justified by the supplied arguments. Neither hash counts nor overlapping algebraic assertion totals are a count of proved global requirements. The review is not external peer review or proof-assistant formal verification.',''])
(ROOT/'CHECKLIST.txt').write_text('\n'.join(txt))

guide='''Q222 ANALYTICAL EXTRACTION REFINEMENT - REGENERATED 2026-10-22

Start with the report PDF, then CHECKLIST.txt. The full original sources,
coefficient data and runnable exact checkers are included in this archive.

WHAT WAS REGENERATED
* Complete-parent regular-C2 local fixed features and rational product maps.
* Exact tilted-CHSH projection, all tilt parameters, original-coordinate
  projection-cylinder coefficients, and a nonquantum scope witness.
* Separated-coefficient and denominator-free smooth-diagonal local theorems.
* The displayed B0 coefficient module, with the frozen factor-typing repair.
* Restricted event-contact cofactor data.
* The literal Schur-remainder obstruction and its limited scope.
* A rational full-quantum membership formula and a conditional exact
  coefficient-search specification. Its QE candidate is UNSOLVED.

WHAT IS STILL OPEN
E1: a complete evaluated global feature list and actual global dimensions.
E2: an evaluated affine pencil exactly projecting to the full quantum set.
E3: both full-set inclusions for that same fixed pencil.
The required restoration, atlas and coverage data are itemized in
GLOBAL_EXTRACTION_OBLIGATIONS.json. No new historical-existence certification,
global matrix-size bound, or full-set order-two representation is asserted.

DIRECTORIES
inputs/       Hash-verified retained source inputs and selected prior context.
recovered/    The unchanged earlier continuation ZIP (including its sources).
c2/           Local regular-C2 extraction and literal Schur-remainder audit.
diagonal/     Local theorems, B0 and restricted contact data.
compiler/     Exact tilted coefficients and UNSOLVED global QE input.
publication/  Combined report source and documented source transformations.
verification/ Fresh isolated replay, cross-review and document QA records.

VERIFY
  python3 verify.py
checks every manifest-bound file and the retained-source hashes.
  python3 -m pip install -r requirements.txt
  python3 verify.py --replay quick
also runs six exact construction/verification suites and three separate review
suites in an isolated temporary copy, and requires
every manifest-bound regenerated output to remain byte-identical. The local
C2 and tilted/QE suites use the standard library; diagonal and Schur suites
require SymPy 1.14.0. No network access is used by the checkers themselves.

REBUILD THE REPORT
  python3 build_release_content.py
  cd publication
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
  pdflatex -interaction=nonstopmode -halt-on-error main.tex
The source uses standard LaTeX mathematical and typography packages. The
delivered PDF was rendered and inspected. A rebuilt PDF may differ in binary
metadata even when its mathematical content is identical.

This is a newly regenerated refinement, not an exact byte restoration of the
unavailable prior refinement or a reproduction of the historical 549 pages.
All previous releases are preserved as source artifacts; none is overwritten.
'''
(ROOT/'README.txt').write_text(guide)
(ROOT/'requirements.txt').write_text('sympy==1.14.0\n')

transforms=[]
bibliography=[]
def fragment(rel,outname,title):
 p=ROOT/rel;src=p.read_text();body=src.split('\\begin{document}',1)[1].rsplit('\\end{document}',1)[0]
 body=body.replace('\\maketitle','')
 body=re.sub(r'\\begin\{abstract\}.*?\\end\{abstract\}','',body,flags=re.S)
 bib=re.search(r'\\begin\{thebibliography\}\{[^}]*\}(.*?)\\end\{thebibliography\}',body,re.S)
 if bib:
  bibliography.append(bib.group(1).strip());body=body[:bib.start()]+body[bib.end():]
 # Replace deeper headings first so each heading is demoted exactly once.
 for a,b in [('subsubsection','paragraph'),('subsection','subsubsection'),('section','subsection')]:
  body=body.replace('\\'+a+'{','\\'+b+'{')
 body='\\section{'+title+'}\n'+body.strip()+'\n'
 op=PUB/outname;op.write_text(body)
 transforms.append({'source':rel,'source_sha256':sha(p),'publication_copy':str(op.relative_to(ROOT)),'publication_sha256':sha(op),'operations':['Remove standalone preamble, title, abstract and document wrappers; full source retained unchanged.','Demote section headings by one level and prepend the combined component heading.','Move bibliography entries to the combined bibliography.']})

fragment('c2/regular_c2_local_proof.tex','regular_c2.tex','Complete-parent regular-C2 local extraction')
fragment('compiler/tilted_family_exact_extraction.tex','tilted.tex','Exact tilted--CHSH projection and support family')
fragment('compiler/effective_algebraic_extraction.tex','effective.tex','Conditional effective algebraic extraction')
(PUB/'references.tex').write_text('\\begin{thebibliography}{9}\n'+'\n'.join(bibliography)+'\n\\end{thebibliography}\n')
write_json(PUB/'PUBLICATION_TRANSFORMS.json',{'purpose':'Faithful combination of independently readable source components','transforms':transforms})

def esc(s):
 for a,b in [('\\','\\textbackslash{}'),('&','\\&'),('%','\\%'),('_','\\_'),('#','\\#'),('^','\\textasciicircum{}')]:s=s.replace(a,b)
 return s
tab=['\\section{Extraction checklist and remaining data}','\\label{sec:checklist}',
 'The following is the supplementary checklist for this regenerated refinement. It does not recertify the original R21 existence checklist. The status of each item is limited to its stated domain. Thirteen items are complete within those scopes and seven remain open. Global items E1--E3 are open.',
 '\\small','\\begin{longtable}{@{}>{\\raggedright\\arraybackslash}p{0.075\\linewidth}>{\\raggedright\\arraybackslash}p{0.235\\linewidth}>{\\raggedright\\arraybackslash}p{0.63\\linewidth}@{}}',
 '\\toprule ID & Status & Acceptance and result\\\\\\midrule\\endhead']
for i,st,title,desc,ev in items:
 tab.append(esc(i)+' & '+esc(st.replace('_',' '))+' & \\textbf{'+esc(title)+'}. '+esc(desc)+'\\\\[5pt]')
tab.extend(['\\bottomrule','\\end{longtable}','\\normalsize',
 '\\subsection{Data that would complete the global extraction}',
 'The labels G01--G10 below distinguish these concrete data obligations from the retained enlarged-candidate gates G1 and G2. All ten obligations remain open as global requirements. Local pieces delivered here may satisfy parts of them.'])
for i,n,d in obligations:tab.append('\\paragraph{'+i+': '+esc(n)+'.} '+esc(d))
tab.extend(['\\subsection{Where the retained outer candidate stands}',
 'The unchanged earlier continuation archive records an evaluated outer candidate with matrix order $13744$, $29920$ auxiliary variables, $2928$ blocks and $153248$ upper coefficient records. Its recorded global reverse inclusion remains unproved. These figures and the earlier rejected orders $8368$ and $10736$ are inherited context; the old arrays are preserved without a new full replay in this regeneration. Neither local extraction nor the general assembly theorem upgrades that candidate to an exact full-set lift.',
 '\\subsection{Reading the verification records}',
 'The root verification report identifies each fresh replay and its scope. Hash checks establish file integrity and custody; exact algebra checkers corroborate the specific identities they evaluate. Their overlapping assertion counts are not added into a mathematical completeness total. The analytical and separate-agent reviews are within the same model system. They are neither external peer review nor proof-assistant formal verification.'
])
(PUB/'checklist.tex').write_text('\n'.join(tab)+'\n')
print(json.dumps({'status':'BUILT_SCOPED_RELEASE_CONTENT','checklist_counts':checklist['counts'],'publication_sources':len(transforms)},sort_keys=True))
