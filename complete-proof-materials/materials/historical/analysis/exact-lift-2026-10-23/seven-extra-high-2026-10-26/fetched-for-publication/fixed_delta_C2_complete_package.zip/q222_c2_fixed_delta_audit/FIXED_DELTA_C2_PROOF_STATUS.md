# The fixed-Delta native-C2 certificate: exact results and the unclosed PSD implication

**Scope and verdict (26 October 2026).** Work with the complete four-state SG2 quarter-parent, not a selected state or angular region. This note proves (i) global soundness and source-cone closedness of the proposed 196-function library, (ii) an exact 134-feature forced Newton support and four contact kernels, and (iii) a sharp anisotropic Motzkin-multiplier obstruction. It **does not** prove that every strict native C2 source is admitted, nor produce a native source with a universal SOS separator. No full Q222 lift is claimed.

The native source and SG2 formula are reproduced below so that all finite checks can be performed without another proof archive. The separate C1 and TL3 arguments are not used.

## 1. Literal certificate and both directions of the fixed SOS equivalence

Write the original canonical Bell coefficient vector as `c`. With `d=1`, `lambda=beta=0`, its full quarter-parent is

\[
\begin{aligned}
 P_c=F_c/4={}&nD_uD_vX^2+m(vW-X+uvY-uZ)^2
 +CD_v(uW-Y)^2+AD_uD_vY^2\\
 &+(D+\tfrac12)(uW+uvX-Y-vZ)^2
 +(\alpha+\tfrac12)D_u(vY-Z)^2\\
 &+\tfrac12D_v(X+uZ)^2-\tfrac12D_uD_vZ^2,
 \quad D_u=1+u^2,\ D_v=1+v^2.
\end{aligned}\tag{1}
\]

For arbitrary positive `d`, use `(D+d/2),(alpha+d/2), d/2,-d/2` in the corresponding packets. Thus (1) is affine in the **original** Bell source coefficients.

Set
\[
\Delta(u,v)=(u^2+v^2)(1+u^2v^2)
=u^2+v^2+u^4v^2+u^2v^4.\tag{2}
\]
Let `u=r^2,v=s^2` and let
\[
Z_{ij\ell}=r^is^j\psi_\ell,\quad
0\le i,j\le6,\quad \ell\in\{W,X,Y,Z\}.\tag{3}
\]
An exact certificate is a family `Q_{00},Q_{01},Q_{10},Q_{11}` of symmetric PSD matrices, on the parity sectors of `(i,j)`, with orders `(64,48,48,36)`, such that
\[
 \Delta(r^2,s^2)P_c(r^2,s^2,\psi)
 =\sum_{\epsilon,\eta\in\{0,1\}}Z_{\epsilon\eta}^{T}Q_{\epsilon\eta}Z_{\epsilon\eta}
 \quad\text{as a polynomial in }r,s,W,X,Y,Z.\tag{4}
\]
These equality constraints are **affine in the original source**. To check all coefficients, write
\[
P_c=\sum_{p,q=0}^2\sum_{\ell\le k}f_{pq;\ell k}\,u^pv^q\psi_\ell\psi_k,
\quad f_{pq;\ell k}=0\text{ for absent monomials}.
\]
Then the coefficient of `r^(2i)s^(2j) psi_l psi_k` on the left is exactly
\[
 b_{2i,2j;\ell k}=\sum_{(a,b)\in\{(2,0),(0,2),(4,2),(2,4)\}}
 f_{i-a,j-b;\ell k},\tag{5}
\]
with negative-index coefficients interpreted as zero. All coefficients with an odd `r` or `s` exponent vanish. The coefficient contributed by a symmetric Gram entry `Q_{ef}`, `e<=f`, is `Q_ee` if `e=f`, otherwise `2Q_ef`, at the angular/state monomial `r^(i_e+i_f)s^(j_e+j_f)psi_(l_e)psi_(l_f)`. These rules are a complete finite affine coefficient system; no test angle or state is frozen.

**Soundness.** For every `u,v>0`, `Delta>0`. Equation (4) therefore proves `P_c(u,v,psi)>=0` for all states. The SG2 sign congruences extend this to negative finite angles; polynomial/projective continuity includes compatible axes and all projective endpoints, including the four zeros of Delta. No division at a corner is asserted. Conversely, if `Delta P_c` is a polynomial SOS whose roots are state-linear and of bidegree at most `(6,6)` in `r,s`, average its Gram under `r->-r,s->-s` to obtain (4). This equivalence concerns membership in **this library**, not equivalence between matrix positivity and SOS.

The projective multiplier has the exact reciprocities
\[
 \Delta(1/u,v)=\Delta(u,v)/u^4,\quad
 \Delta(u,1/v)=\Delta(u,v)/v^4,\quad
 \Delta(v,u)=\Delta(u,v).\tag{6}
\]
These identities are algebraic; they are not a proof that an arbitrary CHSH relabeling carries *all* Grams into the same library (the relabeling may also contain `D_u`/`D_v` state factors).

## 2. Newton forced rows: 196 -> 134, including the full four-state coupling

For strict C2, `d,n,m,C,A,D,alpha>0`, the diagonal coefficients of **(1)**, before multiplying by Delta, are
\[
\begin{array}{ll}
P_{WW}=m v^2+(C+D+\tfrac12)u^2+Cu^2v^2,\\
P_{XX}=(n+m+\tfrac12)+(n+\tfrac12)v^2+nu^2+(n+D+\tfrac12)u^2v^2,\\
P_{YY}=(C+A+D+\tfrac12)+Au^2+(C+A+\alpha+\tfrac12)v^2
 +(m+A+\alpha+\tfrac12)u^2v^2,\\
P_{ZZ}=\alpha+(m+\alpha+\tfrac12)u^2+Dv^2.
\end{array}\tag{7}
\]
All displayed monomial coefficients are strictly positive. After multiplying by (2), the half-Newton polygons of their supports (in `r,s` degree coordinates) are exactly
\[
\begin{array}{c|c|c}
\text{state} & \text{allowed root indices }(i,j) &\text{count}\\\hline
W & 0\le i,j\le6,\ |i-j|\le4,\ 4\le i+j\le10 &30\\
X,Y&0\le i,j\le6,\ |i-j|\le4,\ 2\le i+j\le10&37\text{ each}\\
Z&0\le i,j\le6,\ |i-j|\le4,\ 2\le i+j\le8&30.
\end{array}\tag{8}
\]
**Proof of compulsory deletion.** In any PSD Gram, the diagonal-state polynomial is a sum of real squares of scalar coefficient polynomials in `r,s`. The highest initial form in every weight direction is a sum of squares and cannot cancel. Thus the Newton polytope of every root lies in half the Newton polytope of the corresponding diagonal-state polynomial. Applying this to the four polynomials (7) gives (8). There is no assumption about correlations between different state coordinates. At `n=0`, further deletions may occur; the 134 listed features remain a valid uniform upper span.

Ordering sectors `(even,even),(even,odd),(odd,even),(odd,odd)`, the **fixed** PSD orders are therefore
\[
\boxed{(44,28,28,34),\quad 134\text{ retained features}.}\tag{9}
\]
At each finite strict native C2 contact `(u_c,v_c,psi_c)`, the parent has a zero. Delta is positive at that contact, so **every** square in (4) vanishes there. In each of the four parity sectors the feature evaluation vector is nonzero, since all four native contact-state components are nonzero. Every PSD block consequently kills its own evaluation vector. A source-dependent congruence compresses (9) to `(43,27,27,33)` for proving admission. It is **not itself** a fixed source-affine pencil.

When normalizing the contact to `U=V=1` by `u=u_c U,v=v_c V`, the multiplier must also be transformed:
\[
\Delta(u_cU,v_cV)
=(u_c^2U^2+v_c^2V^2)(1+u_c^2v_c^2U^2V^2).\tag{10}
\]
In particular, one must **not** replace it by `Delta(U,V)` or assume equal angular weights for unequal-angle contacts.

## 3. Exact closedness theorem (not conditional on source positivity)

Let `K_Delta` be the image of the fixed PSD coefficient system (4) in the finite-dimensional vector space of real source coefficients. **The cone `K_Delta` is closed.**

*Proof.* Choose a strictly positive smooth finite measure `mu` on `[1,2]^2` in the independent variables `(r,s)` and a rotationally invariant probability measure on the state unit sphere. For every parity block form the fixed Gram moment matrix
\[
\mathcal M_\sigma=\int Z_\sigma Z_\sigma^T\,d\mu.
\]
It is strictly positive definite: if a linear combination of the monomial-state features vanishes on a positive-measure open product, all of its polynomial coefficients vanish, so the combination is identically zero. Suppose source coefficient vectors `c_j` converge, and choose PSD preimages `Q_\sigma^{(j)}` in (4). The integrals `\int \Delta P_{c_j}\,d\mu` remain bounded because the original polynomial coefficient map is linear and finite dimensional. But
\[
0\le\sum_\sigma\operatorname{tr}(Q_\sigma^{(j)}\mathcal M_\sigma)
 \le C.
\]
Since each fixed `M_sigma` is PD, the traces of all positive `Q_sigma^(j)` are bounded. A subsequence of the tuple of Gram matrices therefore converges to a tuple of PSD matrices. Passing to the limit in the finite affine coefficient equations (5) gives a PSD preimage for the limiting source. This proves closedness even at singular Grams. The argument also works for the full 196 basis, avoiding parameter-dependent compression. QED.

**Finite omitted-event consequences.** If a finite source is a coefficientwise limit of strict native C2 sources **already proved admitted by (4)**, it too is admitted, including the `n=0` opening limits. The approximation of an omitted-event contact by strict ones is a separate geometric input; closedness does not supply the missing admission of strict contacts. The known native opening theorem supplies this approximation on its stated domain.

## 4. A sharp scalar obstruction to anisotropic Motzkin cancellation

Define the homogeneous Motzkin form
\[
M(x,y,z)=x^4y^2+x^2y^4+z^6-3x^2y^2z^2.
\]
**Lemma (sharp).** For `A,B>0`, `(A x^2+B y^2)M` is a polynomial sum of real squares **if and only if `A=B`**.

*Proof.* For `A=B`, scale this exact identity:
\[
\boxed{(x^2+y^2)M=
 [xy(2z^2-x^2-y^2)]^2
 +[xz(z^2-y^2)]^2
 +[yz(z^2-x^2)]^2.}\tag{11}
\]
For necessity, assume an SOS. Since the left is homogeneous of degree eight, all roots can be taken homogeneous of degree four. Its Newton polygon permits precisely these monomials, grouped by sign parity in `(x,y)`:
\[
\begin{array}{c|l}
\text{even/even}&x^2y^2\\
\text{odd/odd}&xyz^2,\ x^3y,\ xy^3\\
\text{odd/even}&xz^3,\ xy^2z\\
\text{even/odd}&yz^3,\ x^2yz.
\end{array}\tag{12}
\]
Average the Gram under both sign changes. The polynomial vanishes at `(1,1,1)`, so every averaged parity root vanishes there. The even/even sector has only `x^2y^2` and therefore vanishes identically. Write the odd/odd roots as
`xy(a_i z^2+b_i x^2+c_i y^2)`.
Comparing the coefficients of `x^6y^2`, `x^2y^6` and `x^4y^4` gives, respectively,
\[
 \sum_i b_i^2=A,\qquad \sum_i c_i^2=B,
 \qquad 2\sum_i b_ic_i=A+B.\tag{13}
\]
There is no contribution to these three `z`-free monomials from any other parity block (the only even/even monomial was eliminated). By Cauchy--Schwarz and AM--GM,
\[
 A+B=2\sum_i b_ic_i\le2\sqrt{AB}\le A+B.
\]
Equality implies `A=B`. QED.

The same coefficient comparison can be read as a forced Gram principal minor
\[
\det\begin{pmatrix}A&(A+B)/2\\(A+B)/2&B\end{pmatrix}
=-\tfrac14(A-B)^2.\tag{14}
\]
**Relation to the proposed C2 library.** Identity (11) shows why a first factor of the form `x^2+y^2` can repair the standard homogeneous Motzkin limit; it is not an obstruction by itself. Equation (14) proves that the repair fails for *an arbitrary independently weighted* first factor. Because native contact normalization changes Delta as in (10), any proof that replaces (10) by an isotropic factor is incorrect.

This scalar lemma is **not** a native C2 separator. To turn it into one, it would be necessary to construct a specific family of actual native C2 coefficient tuples and state-linear test substitutions whose exact leading polynomial is the *anisotropically weighted* form in the lemma, while preserving SOS degree bounds and limits. No such native full-state degeneration is proved here. The result cannot be used to exclude the 196-feature library without that step.

## 5. Strict native benchmark, checker and precise outstanding implication

The fixed rational diagnostic source is
\[
(a,b,c,t,r)=(13/600,101/1000,47/15,27/35,13/154).
\]
Put `z=c^2`, `k=1+zr`, `h=b-a^2t`, `g=(1+z)b-(1-r+a^2zt)`, `j=1+zr-t`,
\[
\begin{aligned}
\Delta_s={}&(1+z)zb^2+2z(1+z)br+(1+z)(1+a^2z)b\\
&+z^2(1-a^2)r^2+2z(1+a^2z)r+1+a^2z,\\
N_s={}&(1+z)(b+r)(b+a^2(1-t))-a^2(1+a^2z)(1-r)t,\\
\Xi={}&(b+r)k(k+a^2zt).
\end{aligned}
\]
The original native source is
\[
\begin{array}{lll}
n=(\Xi-r\Delta_s)/(2r\Delta_s),&
 m=(1+a^2z)(1-r)k(k+a^2zt)/(2g\Delta_s),&
 C=kN_s/(2a^2t\Delta_s),\\
 A=a^2\Xi/(2h\Delta_s),&
 D=(1+z)(b+r)(b-a^2zr)(k+a^2zt)/(2a^2j\Delta_s),&
 \alpha=z^2(b+r)N_s/[2(1-zh)\Delta_s].
\end{array}\tag{15}
\]
Its source contact is `(u_c,v_c)=(c,ac)` and
`psi_c=(b/a,-cr,ch/a,1)`. The included exact checker verifies positivity of the native gaps, all four state kernel equations, both angle derivatives, the 196-to-134 Newton computation and the Motzkin and reciprocal identities. It does not claim the Gram is PSD for the benchmark.

**First missing implication:** For every strict native C2 source, find source-only matrices
\[
 Q_{00}\in S_+^{44},\quad Q_{01}\in S_+^{28},\quad
 Q_{10}\in S_+^{28},\quad Q_{11}\in S_+^{34}
\]
obeying *every* original coefficient equality (5), with all native contact kernels; **or** exhibit one rational native source and an exact functional `Y` such that `A^*Y` is PSD on the **full contact-compressed** feature space while `<Y,b(c)><0`. The affine source matrix may depend nonlinearly on native source parameters as a membership proof, but the feature span must remain fixed. Neither certificate has been obtained.

A single-source exploratory affine/PSD projection showed no affine contradiction but did not reach exact simultaneous PSD and coefficient equality. Approximate residuals are not used as evidence of admission or exclusion; no optimization output appears in this checker.

**Status:** the fixed library is globally sound, closed, and has exact reduced coefficient equations. Uniform strict native C2 admission is **unproved**. The native-family-to-global-Q222 implication additionally needs C1 and the nonnative face/orbit joins.
