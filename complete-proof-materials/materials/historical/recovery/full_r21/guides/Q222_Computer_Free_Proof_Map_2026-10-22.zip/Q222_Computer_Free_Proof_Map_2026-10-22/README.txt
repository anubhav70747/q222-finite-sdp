Q222 COMPUTER-FREE PROOF MAP AND STRUCTURAL SIMPLIFICATIONS
22 October 2026

START WITH
Q222_Computer_Free_Proof_Map_and_Simplifications_2026-10-22.pdf

This supplement maps the recovered analytical proof and supplies exact
structural simplifications. No solver or symbolic checker is a premise.

MAIN RESULTS IN THE SUPPLEMENT
1. A common strict-residue Gram mechanism, with an exact global-generator
   divided-difference proof explaining rank-two roots.
2. A 12-circuit decomposition and at most 48 rank-two tensor squares for
   the scalar Laurent contact determinant.
3. A source-reserve inequality and uniform allocation for the R1 branch,
   using explicitly identified retained exact local identities.
4. A one-equation monotone parametrization of all positive shapes in the
   reflection-fixed sector, with its sharp strength formula.
5. Explicit source/test quantifiers, coverage tables, and finite assembly.

ROUTES PRESERVED
The August frozen source asserts sxdeg(Q222)=2; the October R21 source
asserts qualitative finite SDP-lift existence. The fixed-sector extraction
is a separate evaluated exact order-18 source-cone lift. The report does
not conflate these scopes or independently reprove all 215 local bodies.

CONTENTS
  PDF: readable proof map and fully stated simplifications.
  latex/: editable complete LaTeX source; compile the main file with
          pdflatex twice from that directory.
  analysis/: detailed analytical notes with retained versus newly derived
             steps and exact source locators.
  sources/: unchanged selected original bodies, keyed to the report.
  Dependency_Map JSON: theorem-level graph and all 215 indexed components.
  Input_Inventory JSON: source locations and SHA-256 digests.
  MANIFEST.json: hashes identifying the packaged files.

The source files are preserved unchanged. The full recovered proof archives
remain in the previously saved frontier-recovery package.
