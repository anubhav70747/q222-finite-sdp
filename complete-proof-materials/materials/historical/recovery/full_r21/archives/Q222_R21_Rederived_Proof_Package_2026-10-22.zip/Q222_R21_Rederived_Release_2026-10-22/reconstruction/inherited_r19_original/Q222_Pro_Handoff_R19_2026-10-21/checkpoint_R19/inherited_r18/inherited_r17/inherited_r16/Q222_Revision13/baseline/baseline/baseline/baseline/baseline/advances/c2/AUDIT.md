# Scoped review of the three-opening C2 extension

**Verdict: PASS for the stated source domain, conditional on the same source-physicality and inherited noncommuting-residue theorem as the baseline.** No global C2 source classification or atlas-free global join is established by this module.

This is a separate-agent review within the same assistant system. I read the full new theorem, the full baseline `general_single_angle.tex`, the baseline audit, and the new 33-check algebra receipt and its code. I independently derived and executed five additional exact polynomial checks of the *entire* two first normals and three hard Hessian entries. All five passed. No source search, numerical sampling, atlas replay, or new external expert review was performed.

The baseline's exact source and contact identities are unchanged. The review below checks the changed hypotheses rather than treating “the same proof” as sufficient justification.

## 1. Entry and source denominators

The source parameters satisfy x infinitesimal positive, k and b positive units, 0<r<1, 0<h<b, and g=b−1+r+xh a positive unit. Thus j and A_c,S_c are units, and Delta has positive residue `(1+k_0^2)(b_0+1)`.

From n>=0, taking residues in `(b+r) A_c S_c >= r Delta` gives

`r_0 <= b_0/[b_0+k_0^2(b_0+1)] < 1`.

Consequently 1−r is a unit, and substituting that upper bound gives

`b_0−k_0^2 r_0 >= b_0^2(1+k_0^2)/[b_0+k_0^2(b_0+1)] > 0`.

This proves the two removed lower bounds; it does not assume them implicitly. In particular m, D/x and alpha/x remain positive units in both r regimes.

The canceled numerators T_C=xC(b−h) and T_A=xAh are bounded positive units with equal residue T_0. The displayed four cancellation identities are exact. They eliminate every h or b−h pole from the graph scalar and the unnormalized first Y normal. The effective scalar coefficient is `Q=4T_0/b_0`, independent of the limiting opening.

H=x(C+A) is bounded below, even when unbounded. Therefore 1/sqrt(H) is bounded; the replacement Y normal is legitimate as a pure coefficient scaling. Its hard coefficient from the two large packets is exactly `4 D_v[1+A u^2/(C+A)]`, with `0<A/(C+A)<1`. No reciprocal of a mixed element is introduced.

Literal h=0, b−h=0, and r=0 are not in the theorem. Arbitrarily small positive values are included. Literal n=0 is included separately below.

## 2. Bounded n and the matched contact

When r is a unit, n is bounded. The original graph X_g and its infinitesimal correction remain valid: neither their denominator nor the correction uses a lower bound on either complementary opening. The coefficient of the large scalar term is

`4 D_v[T_C(b−h)/b^2 + T_A h D_u/b^2]`.

It is coefficientwise bounded, and its residue is the baseline Q D_v. The remaining scalar coefficients use only bounded n,m,D,alpha and bounded eta=h/b. Thus the five scalar monic divisions, the remote cross-term capacity, and the matched contact conductor argument preserve their hypotheses.

For the Y normal, both potentially large linear products reduce to T_C/b and T_A/b. Their residues agree. All remaining terms involve bounded packet weights. The original normal, on the old `(Y−Y_g)/rho` root, therefore has bounded coefficients with zero residue; dividing those coefficients by sqrt(H) preserves both properties.

At matched contact the scalar functions Q_b and B_b remain coefficientwise bounded, rather than merely bounded at the contact point. Their finite monic differences therefore remain bounded. The four conductor identities use only u,W,rho and the unit kappa. The strict three-variable Hessian, obtained from the Laurent identity and its positive pair terms, supplies exactly the same angular reserve for the two-block Gram correction. Both restored hard pivots are positive after normalization.

## 3. The n=0 corner

The corner graph uses eta_c=C/(C+A). In terms of the bounded numerators,

`eta_c = T_C h/[T_C h+T_A(b−h)]`,

whose denominator has positive residue T_0 b_0, even at either limiting opening. Also

`xCA/(C+A)=T_C T_A/[T_C h+T_A(b−h)]`

is a bounded positive unit with residue T_0/b_0. These identities justify both the scalar harmonic coefficient and the canceled first-normal coefficient uniformly. The old epsilon reserve uses only n,m,alpha and is unaffected. Its ratios n/epsilon and x/epsilon remain bounded, including n=0 exactly. The normalization changes the hard Y pivot to 4 and leaves all zero-residue first-normal lifts valid. No state coordinate or necessary scalar root is deleted.

## 4. Unbounded n: entire normals and hard block

When r is infinitesimal, `(4n+2)r=2(b+r)A_c S_c/Delta` is a positive bounded unit. Hence n r is bounded, n r^2 is bounded, N=4n+2 is unbounded, and 1/sqrt(N) is infinitesimal. The simple graph X_g=−r uZ is exactly centered at the source contact and has bounded coefficients.

The following formulas were derived directly from the complete original parent and checked independently by exact polynomial expansion. Put eta=h/b, V=vW and B=uZ. Then

`F_X|g = V A_X + B B_X`,

where

`A_X = −8m(1+eta u^2)+(8D+4)(1−eta)u^2`,

`B_X = −8nr D_u D_v+8m(1−r)−(8D+4)v^2(1+r u^2)+4D_v(1−r)`.

Every coefficient is bounded. After scaling the X normal by sqrt(N), all these coefficients have zero residue. No uncanceled n occurs.

After removing the C,A contribution to F_Y, the remaining coefficients are exactly

`e_w = 8m v^2(1+eta u^2)−(8D+4)(1−eta)+(8alpha+4)D_u v^2 eta`,

`e_z = v[−8m(1−r)+(8D+4)r−(8alpha+4)]`,

with constant Z term `8v(D−alpha)`. This confirms boundedness for the entire Y first normal, independently of the relative sizes of r, h, b−h and x.

The exact quadratic coefficients, with the convention `H_XX N_X^2+2H_XY N_X N_Y+H_YY N_Y^2`, are

`H_XX=(4n+2)D_uD_v+4m−2u^2D_v+(4D+2)u^2v^2`,

`H_XY=−uv(4m+4D+2)`,

`H_YY=4CD_v+4AD_uD_v+4m u^2v^2+(4D+2)+(4alpha+2)D_u v^2`.

They give exactly the claimed normalized hard residue `diag(D_v,4D_v)` on the u=0 residue axis, with zero mixed residue. This verifies the entire hard block rather than a determinant or a restriction to contact.

## 5. Unbounded n: scalar and contact conductors

The graph's n packet contributes only `4n r^2 D_uD_v u^2Z^2`. Its coefficient is bounded and has zero residue. The remaining scalar coefficients are bounded by the opening cancellations from Section 1. Thus the five monic scalar coquotients remain valid, with the new residue parameters printed in CO10.

The corrected constant in CO11 is **−4 mu**, not −4 mu squared. With this correction the determinant expansion is exact. Its source values give a stationary zero at `(s,z)=(1,k_0^2)`. All six nonconstant coefficients are positive. The reciprocal-pair and directed-three-cycle decomposition has strictly positive s and t pair coefficients; hence it gives both the unique positive-quadrant zero and a positive definite Hessian there. The theorem is using this global identity, not inferring global strictness from local Hessian information.

At v_0=0 the coefficient of V^2 is `2(mu−1)>0`; the printed c_s includes the additional v^2 because it is the coefficient of W^2. With that notation understood, all four scalar-root pivots are positive.

For the matched X normal, all coefficients have a common pure coefficient factor 1/sqrt(N). Monic contact quotients preserve that factor. In

`u A_1+W B_1=−kappa B_1 S+u(A_1+kappa B_1)`,

the second coefficient vanishes exactly at contact. Invariant differences produce coefficients containing u^2, uW or u rho; the v−k difference gives T times a quotient retaining 1/sqrt(N). Every resulting coefficient therefore has zero residue.

For Y, write `L_Y=R B_2+rho E_2'`. Explicitly,

`E_2'=kappa B_2+uW e_w+u^2 e_z+8v(D−alpha)`.

Both B_2 and E_2' have identically zero leading functions on the finite u=0 residue axis, and E_2' vanishes exactly at contact. The invariant differences produce x, rho u or rho W; the v−k quotient retains zero residue. Dividing by sqrt(H) preserves the complete bounded zero-residue lift. Thus the matched strict Gram restores both full normals.

## 6. Outer charts and scope

Taking sigma=min(1,xC,xA) is legitimate in the pure coefficient field; sigma is a bounded positive unit. The two excess C,A event packets are nonnegative. On the residual parent the old four outer identities now have C=A=sigma/x, so their displayed pivots are positive with C_* and A_* replaced by sigma_0.

Every occurrence of n in these outer arguments is in a retained nonnegative packet. No outer Gram entry needs n bounded. The reciprocal-Bob chart keeps its D/x pivot, already proved a positive unit. Consequently all finite and reciprocal commuting endpoints, including their literal projective ends, remain covered. The existing noncommuting-residue theorem supplies exactly the same complementary tests under the explicitly retained physicality hypothesis. State homogeneity and real/imaginary splitting are unchanged.

One scope wording correction was requested and has been incorporated: because h+(b−h)=b is a unit, h and b−h cannot both be infinitesimal. The theorem allows **either** A or C to be arbitrarily larger than x^−1, independently of an arbitrarily large n; it does not include both A and C simultaneously much larger than x^−1 with b a unit. The explicit full-normal coefficients derived above have also been incorporated. These changes do not alter the theorem's displayed domain.

The result is a valid extension of the stated one-weak source family. It removes the lower bounds on r,h,b−h and derives the lower bounds on 1−r and b−k^2r. The unit hypotheses on k,b,g, strict positivity of the openings, and source physicality remain substantive. The residual global source domains and exhaustive analytical join remain outside this review.
