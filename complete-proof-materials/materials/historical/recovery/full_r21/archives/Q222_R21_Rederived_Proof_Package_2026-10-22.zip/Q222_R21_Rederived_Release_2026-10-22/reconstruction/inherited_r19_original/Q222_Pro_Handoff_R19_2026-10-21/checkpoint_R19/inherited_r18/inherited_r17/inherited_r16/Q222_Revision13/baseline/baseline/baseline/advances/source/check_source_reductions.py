"""Exact corroboration of the short C1 source identities; no sampling."""
import json
import sympy as s
x, eta, zeta, r, h = s.symbols('x eta zeta r h')
theta=1-h; K=1+x; R=1+x*r; T=1+x*h; G=h+zeta
M=R-theta/zeta; J=T-(1-r)/eta
y=x*eta*zeta; E=1-x*eta*h; Q=1-x*zeta*r
a=(1-r)/eta; t=theta/zeta
P4=1+x+eta*x*(a-x-1)-zeta*x*t+y*(-zeta*x*t*t+2*x*t+a*(1-t)+t)
Pa=1+x-a*eta*x+zeta*((1+x)-(2+x)*t)+y*(-zeta*t*t+a*(t-1)+t)
Pd=(1+x)**2-a*eta*x*x+zeta*x*((x+1)-(x+2)*t)+y*(-zeta*x*t*t+x*a*(t-1)+x*t+x+1)
P4,Pa,Pd=[s.cancel(z) for z in (P4,Pa,Pd)]
B5=s.expand(K*(1+y)*(r+eta)-(eta*T-(1-r))*Pd)
Bb=s.expand(K*x*(r+eta)*G-theta*Pd)
checks=[]
def check(name, expr):
    assert s.cancel(expr)==0, name
    checks.append(name)
check('P4 positive decomposition',P4-(T*E+x*(1-r)*G))
check('Pa positive decomposition',Pa-(R*h*(1+y)+zeta*M*E))
p0=1+2*x*h+r*x*x*G+x*zeta
p1=x*(K*zeta+x*h*theta)
check('Pd positive decomposition',Pd-(p0+eta*p1))
A=theta*T+K*zeta
B=h*h*r*x*x+h*r*x*(2-h)+h*h*x+h*r*x*x*zeta+h*x*zeta+h*x+h+r*x*zeta+x*zeta+2*zeta+1
C=R*G*(1+r*x*h)
check('uniform E cap identity',h*B5-(-A*E*E+B*E-C))
aa=K*x*zeta-T*p1
bb=K*(1+x*zeta*r)-T*p0+(1-r)*p1
cc=K*r+(1-r)*p0
pp=K*x*G-theta*p1
qq=K*x*r*G-theta*p0
check('B5 quadratic coefficients', B5-(aa*eta*eta+bb*eta+cc))
check('Bb linear coefficients',Bb-(pp*eta+qq))
check('positive linear coefficient',pp-x*h*(K*(1+zeta)-x*theta*theta))
positive=x*x*h*h*K*K*R*G*G*(1+2*x*h+r*x*x*h*h+(1-r)*x*zeta)
check('division free elimination',pp*pp*B5-aa*Bb*Bb-(pp*bb-2*aa*qq)*Bb-positive)
check('theta one beta exclusion',Bb.subs(h,0)+1+x*zeta*(1-r))
# The next exact expression is used only in the stated eta-unbounded branches.
check('alternative beta numerator',Bb-((x*eta*h)*(K*(1+zeta)-x*theta*theta)+x*r*G*T-theta*(1+2*x*h+x*zeta)))
# Reconstruct all original relative events from the seven native coquotients.
c2=2*K*h*r*(1+y)*(r+eta)*Q
cb=2*K*r*G*(r+eta)*Q
c3=2*K*r*(r+eta)*Q*E
c5=2*K*r*(r+eta)*Q*(1+y)
c4=2*Q*P4; ca=2*r*(r+eta)*Pa; cd=4*r*Q*Pd
signed=2*a*eta*cd/c3
native_events={
 'C':s.Integer(2),
 'A':2*a*eta**2*c4/c3,
 'm':2*a*(x*eta/zeta)*c2/(M*c3),
 'alpha':2*a*x*x*zeta*eta*ca/c3,
 'D':2*a*c5/(J*c3)-signed/2,
 'beta':2*a*(x*eta/zeta)*cb/(t*c3)-signed/2,
}
relative={
 'C':K*(r+eta)*E/(2*(1-r)*Pd),
 'A':eta*P4/(2*r*Pd),
 'm':K*x*(r+eta)*h*(1+y)/(2*M*zeta*Pd),
 'alpha':x*x*zeta*(r+eta)*Pa/(2*Q*Pd),
 'D':B5/(2*J*eta*Pd),
 'beta':Bb/(2*theta*Pd),
}
for name in native_events:
    check('native relative event '+name,native_events[name]/signed-relative[name])
print(json.dumps({'status':'PASS','exact_checks':len(checks),'checks':checks,'scope':'Polynomial identities only; boundedness, physical entry, and all-tests routing are proved in source_reductions.tex.'},indent=2))
