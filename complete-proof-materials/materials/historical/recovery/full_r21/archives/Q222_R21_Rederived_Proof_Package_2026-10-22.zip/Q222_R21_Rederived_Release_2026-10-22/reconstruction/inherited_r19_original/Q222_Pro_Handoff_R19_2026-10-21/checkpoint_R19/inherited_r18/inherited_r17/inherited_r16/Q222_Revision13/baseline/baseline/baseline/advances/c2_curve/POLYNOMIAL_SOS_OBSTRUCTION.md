# The exact double-infinitesimal witness is not a polynomial SOS

This is an exact obstruction over the real closed **source coefficient
field**, not an obstruction to pointwise tensor SOS. The witness and its
unchanged parent are specified in `HALFCORNER_CERTIFICATE.md`. Let
`x=k²>0` be infinitesimal.

## The degree restriction is exhaustive

The parent `F` is homogeneous of degree two in the four state variables
`W,X,Y,Z`, and has degree at most two separately in each angle `u,v`.
If `F=sum_j f_j²` in `K_c[u,v,W,X,Y,Z]`, the highest-degree coefficients
of a sum of squares cannot cancel over an ordered field. Applying this
first to state degree and then separately to `u` and `v` forces every
`f_j` to have state degree at most one and angle degrees at most one.
Since `F(u,v,0,0,0,0)=0`, all constant state terms of the `f_j` vanish.
Consequently every summand is linear in state and lies in exactly

```
span_Kc {W,X,Y,Z} × {1,u,v,uv}.
```

Thus a positive semidefinite Gram matrix on these sixteen monomials is
necessary for **every polynomial SOS**, not merely a chosen degree
relaxation.

## One parity block and two zero diagonals

The parent is invariant under the commuting sign operations

```
(u,Y,Z) -> (-u,-Y,-Z),
(v,X,Z) -> (-v,-X,-Z).
```

Averaging any positive semidefinite Gram matrix over this four-element
group preserves positivity and coefficient matching. Its invariant
character block uses exactly

```
b0=(W,uY,vX,uvZ).
```

Both the constant-angle coefficient of `W²` and the coefficient of
`u²v²Z²` in the full parent vanish. These are the first and last diagonal
entries of this block. Positive semidefiniteness therefore forces both
corresponding rows and columns to vanish. The remaining two-by-two block
on `(uY,vX)` has diagonals exactly

```
d1=4A, d2=2+4n.
```

At the exact contact `(u,v)=(k,k)`, the state is

```
(W,X,Y,Z)=(1,-k³/4,k(1-x/2),x).
```

The parent is zero there, so the positive semidefinite block must kill
its contact vector. In particular its remaining two-by-two block kills

```
(a0,b0)=(x(1-x/2),-x²/4).
```

If the off-diagonal entry is `t`, the two kernel equations are
`d1 a0+t b0=0` and `t a0+d2 b0=0`. Multiplying them by `a0` and `b0`
respectively and subtracting forces

```
d1 a0²=d2 b0².
```

But the exact source formulas give

```
d1 a0²-d2 b0²
 = (x+4)(3x+4) x³(4-3x) / [64(1+x)²] > 0
```

for every positive infinitesimal `x`. This is the contradiction.
Therefore the original witness parent has **no polynomial sum-of-squares
representation over `K_c`**.

`check_polynomial_obstruction.py` verifies the two zero diagonal
coefficients, the two remaining diagonal coefficients, and the positive
contact-imbalance identity: five small exact checks, recorded in
`check_polynomial_obstruction.json`.

The earlier `global_four_blocks.py` calculation remains corroboration
only: its complete exact linear elimination forces a negative two-by-two
principal minor. No table, search, or elimination result is needed in the
proof above.

## Scope

The tensor-SOS problem evaluates testing coordinates in an independent
real closed field and allows arbitrary pure-testing inverses and radicals.
Those possibilities are not polynomial SOS in free angle and state
variables. The separate `rational_curve_tensor_sos.tex` now admits this
very source family at every independent test by univariate factorization
in the source parameter. Its factors have coefficients in the testing
field, so their dependence on testing coordinates need not be polynomial.
The polynomial obstruction and the all-tests tensor-SOS theorem are
therefore compatible. Neither result claims uniform coverage of the
multiparameter actual-II source leaf.
