"""Independent whole-normal checks for the weak-m, n=0 corner."""
from pathlib import Path
import json
import sympy as s

u,v,W,X,Y,Z,n,m,D,alpha,H,t=s.symbols('u v W X Y Z n m D alpha H t')
Du,Dv=1+u*u,1+v*v
C,A=t*H,(1-t)*H
M=v*W-X+u*v*Y-u*Z
J=u*W+u*v*X-Y-v*Z
F=(4*n*Du*Dv*X**2+4*m*M**2+4*C*Dv*(u*W-Y)**2
   +4*A*Du*Dv*Y**2+(4*D+2)*J**2+(4*alpha+2)*Du*(v*Y-Z)**2
   +2*Dv*(X+u*Z)**2-2*Du*Dv*Z**2)
Hc=4*n+4*m+2
zeta=(4*m+2)/Hc
chi=4*m/Hc
graph={X:chi*v*W-zeta*u*Z,Y:t*u*W}
f=s.expand(F.subs(graph,simultaneous=True))
fy=s.expand(s.diff(F,Y).subs(graph,simultaneous=True))
checks=[]
def eq(label,lhs,rhs=0):
    assert s.factor(lhs-rhs)==0,label
    checks.append(label)
def bound(label,expr):
    den=s.denom(s.cancel(expr))
    assert den.subs({n:0,m:0,u:0,v:0,H:0,t:0})!=0,(label,den)
    assert den.subs({n:0,m:0,u:0,v:0,H:0,t:1})!=0,(label,den)
    checks.append(label)

large_y=8*Dv*H*t*(1-t)*u**3*W
yr=s.expand(fy-large_y)
ew=s.cancel(yr.coeff(W)/u)
ez=s.cancel((yr.coeff(Z)-8*v*(D-alpha))/u**2)
eq('complete corner Y normal',fy,large_y+u*W*ew+u*u*Z*ez+8*v*(D-alpha)*Z)
eq('corner Y W remainder independent of strong size',s.diff(ew,H))
eq('corner Y Z remainder independent of strong size',s.diff(ez,H))
bound('corner Y W remainder bounded',ew)
bound('corner Y Z remainder bounded',ez)

cross=s.cancel(f.coeff(W).coeff(Z)/(u*v))
eq('corner scalar cross independent of strong size',s.diff(cross,H))
bound('corner scalar cross bounded',cross)
strong_w=4*H*t*(1-t)*Dv*u*u*(1+t*u*u)
wr=s.cancel(f.coeff(W,2)-strong_w)
eq('complete corner W strong packet extraction',s.diff(wr,H))
bound('corner W nonstrong scalar bounded',wr)

out={'result':'PASS','number_of_checks':len(checks),'checks':checks,
     'scope':'Independent full Y-normal and scalar cross/harmonic extraction at the weak-m double-zero corner. Boundedness uses n,m,D,alpha,t bounded and Hc a positive unit; no upper bound on H=C+A is needed.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
