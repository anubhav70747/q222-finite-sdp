Q222 REVISION 15: COMPLETING THE COUPLED SQUARE
20 October 2026

READ FIRST: Q222_R15_Analytical_Proof.pdf
CURRENT CHECKLIST: Q222_End_to_End_Checklist_R15.txt
MACHINE-READABLE FRONTIER: FRONTIER_R15.json

NEW: Whole weak-C2 source shape R9 is all-tests admitted. One local proof handles every testing ratio. The same mechanism closes all tests on the eta,j0-unit, large-zeta C1 subdomain, including r/1-r openings and beta=0. C14.3a as a whole is still open. The global theorem is still open: six C1 branches and nine weak-C2 shapes remain, followed by universal routing and the finite-lift bridge.

The proof uses exact identities and positive residue Grams. Numerical tables are not mathematical premises. The 101 new symbolic assertions corroborate the printed identities; the full-parent analytical allocation is in the proof text. All earlier admissions are preserved.

This is a compact supplement to the reconciled R13 baseline and R14 advances. It includes the complete current checklist and all direct supporting modules for the new certificates with provenance. It does not duplicate the full R13 archive or claim to be a completed global proof.

Reproduce:
  python verify.py             # integrity hashes
  python verify.py --algebra   # only new checks, including their stated source dependencies
  pdflatex Q222_R15_Analytical_Proof.tex
Run from this folder. Python 3 and SymPy are required for algebra; standard LaTeX packages and TikZ for the PDF. No network is required.

The algebra runner executes the scalar checker through its R9 dependency once, then the coupled lemma, original-parent audit and C1 extension. It does not replay the old suite. REVIEW.txt states the exact review scope.
