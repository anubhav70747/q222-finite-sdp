# Joint C2 opening closed within the rational source domain

`joint_centered_packets.tex` proves the full-parent tensor-SOS conclusion for the remaining rational C2 corner with positive infinitesimal `x,r,g`, bounded positive unit `k,b`, `g=b−1+r+xh`, arbitrary `0<h<b`, and the inherited physical-source hypothesis. It treats every independent projective measurement pair and all real or complex projective states. It does not classify sources outside this rational domain.

The new exact step is to retain centered excess packets:

`F = G + 4n Du Dv (X+r uZ)^2 + 4(m−1)(M−g uZ)^2`.

The remainder `G` retains exact zero and full stationarity at the original contact because both subtracted squares vanish there. Its non-`C,A` coefficients are bounded products `nr`, `nr²`, `(m−1)g`, `(m−1)g²`. On `X=−r uZ, Y=(h/b)uW`, use normalized `X,Y` normals and leave the centered `m` square unexpanded as an additional, possibly redundant root. This prevents the former `C u²/n` and `C u²/m` coefficients from appearing.

The leading whole-remainder graph scalar is

`q P² − 2v P E + e E² + 4(V−B)²`,

where `q e−v²=(v²−K²)²/(1+K²)²`. The exact determinant identity in (JC9) proves global equality uniqueness and a positive contact Hessian. The inherited bounded monic conductor construction then gives a strict full seven-root Gram at matched angles; complete first-normal lifts are checked in the proof. Remote finite-axis tests, including the double-zero test, have strict four-root scalar Grams and zero-residue full-normal couplings. All other commuting charts use the already established outer identities with original excess packets retained; physical noncommuting-residue tests use the inherited theorem.

The opening cancellations `xC(b−h)` and `xAh` make the argument uniform when either complementary opening tends to zero. There is no comparison between coefficient and testing infinitesimals and no inverse or radical of a mixed tensor element.

`check_packet_repair.py` and `packet_repair_checks.json` provide compact exact symbolic checks of the new algebra. The checker is not substituted for the analytical global strictness, full-normal lifting, and all-tests dispatch in the proof. `AUDIT_PACKET_REPAIR.md` records an independent review.

Review provenance: separate agents in the same system; not external peer review or formal verification.
