# Revision 13: small-L C1 boundary progress

This directory contains **two new full-parent, all-tests source admissions**
inside C14.3, one explicitly narrower local algebraic extension, and valid
source bounds for C14.4. It does not close either original C1.4 row or the
global finite-lift theorem.

## Results and exact scope

**r_opening_closure.tex**, RO1–RO14, admits

- positive infinitesimal x;
- positive bounded units eta, zeta, and j0=eta+r-1;
- every original 0<r<1, including either infinitesimal r or
  infinitesimal 1-r;
- all original beta>=0, including literal beta=0.

The full normal is weighted by sqrt(H0), and the X normal uses
sqrt(beta+1/2). The latter combines beta with its original half-core
contribution. All source divisions cancel before either r endpoint is
examined. Literal source r=0 or r=1 is not added.

RO15 states a **local**, two-infinitesimal-tests algebraic extension for
the exact native stationary coefficient formulas when
beta+1/2 >= b_* > 0 for a real b_*. In that local assertion beta may
be negative. Physicality and beta nonnegativity are not used after those
algebraic source assumptions. No remote admission is imported for
negative beta.

**j_opening_closure.tex**, JO1–JO21, admits

- positive infinitesimal x;
- positive bounded units eta, zeta, r, and 1-r;
- positive infinitesimal **actual** j=eta(1+xh)-1+r;
- all original beta openings, including beta=0.

Thus j0=0 and slightly negative j0 are retained. Its decisive exact
normal is Nd=sqrt(D)(J_t+j uW). The resulting complete higher-angle
quadratic, JO19, contains no D and has strict soft pivots eta/2 and 1/2.
The state graph varies with the test angle and matches the original
source graph exactly at contact. Every first normal is printed and
checked. Simultaneously infinitesimal r and j are excluded from this
theorem.

**eta_large_bounds.tex**, ES1–ES10, supplies the source step for C14.4:
with sigma=1/eta and S=sigma+L,

- P/S and B/S are positive bounded units;
- an exact shared D/beta source sphere retains both coefficient
  boundaries;
- C and A are unbounded, while D=O(sigma^2/S) and alpha=O(L);
- e^2=O(x/S), so unbounded zeta forces e infinitesimal;
- the exact m split preserves the same beta sphere coordinate and
  displays the M opening.

ES is **not** a new C14.4 testing-domain admission.

## Remaining small-L source alternatives

After the earlier IC1 admission and RO/JO, the C14.3 complement can be
printed as these disjoint source alternatives, always intersected with
the original physicality, scale and earlier-complement conditions:

1. zeta unbounded, eta bounded.
2. zeta a positive bounded unit, eta infinitesimal.
3. zeta and eta positive bounded units, with r and actual j both
   positive infinitesimals.

In alternative 3, eta+r has residue one and 1-r is a positive bounded
unit. Actual j remains positive; j0 is not assumed positive.

C14.4 still requires a full-parent allocation at every residual
infinitesimal-u test, using the new source bounds. No source domain is
declared empty merely because it appears on this residual list.

## Exact verification receipt

Only these new focused checkers were run to completion:

| Checker | Exact assertions |
|---|---:|
| check_r_openings.py | 24 |
| check_eta_large_bounds.py | 10 |
| check_j_opening.py | 25 |
| check_j_reciprocal.py | 4 |
| **Total** | **63** |

The JSON files beside the checkers contain the successful records.
The RO denominator checker requires every irreducible source
denominator factor at x=0 to be among eta, zeta, eta+r, eta+r-1,
eta+2r-1 and constants. In the actual output only the retained unit
factors eta, zeta, j0, j0+r and constants occur. No r, 1-r or theta/x
opening factor remains.

The JO denominator checker requires every irreducible source factor
at x=j=0 to be among eta, zeta, 1-eta and constants. In particular it
does not infer uniformity merely from a few endpoint substitutions.

Reproduction in the recovered scratch environment:

    PYTHONPATH=/tmp/q222-deps python check_r_openings.py
    PYTHONPATH=/tmp/q222-deps python check_eta_large_bounds.py
    PYTHONPATH=/tmp/q222-deps python check_j_opening.py
    PYTHONPATH=/tmp/q222-deps python check_j_reciprocal.py

These checks corroborate finite identities and denominator factorizations.
The ordered-field bounds, finite contact/Taylor identities and all-tests
joins are supplied by the proofs. Parent and track review are same-system
mathematical reviews, not external verification or a formal proof check.
No inherited suite was rerun, and no baseline file was edited.
