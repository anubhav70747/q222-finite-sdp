#!/usr/bin/env python3
"""Focused exact checks for the z/B-infinitesimal full-parent extension.

The previous six-contact full-parent Gram is used by exact congruence;
this checker addresses only the new cancellation and remote charts.
"""
import json
from pathlib import Path
import sympy as s

checks = {}
def ck(name, expression):
    assert s.cancel(expression) == 0, name
    checks[name] = True

half = s.Rational(1, 2)
B,a,h,t,r = s.symbols('B a h t r')
ac=1+a*B*r
Sc=1+B*(1-h+a*r)
g=1+a*(h*B+r-1)
j=ac-(1-h)/t
dd=a+(1+a*B)+(1+a*B)*B+2*a*B*(1+a*B)*r+a**3*B**2*r**2+2*a*a*B*r+t*B*(1+a+a*B+a*a*B*r*(2-r))
MM=(1+a*B)*(1+a*r)*(h+t)-a*(1+t*B)*(1-r)*(1-h)
n=((1+a*r)*ac*Sc-r*dd)/(2*r*dd)
mu=(1+t*B)*(1-r)*ac*Sc/(2*g*dd)
C=ac*MM/(2*(1-h)*dd)
Ah=t*ac*(1+a*r)*Sc/(2*dd)
D=(1+a*B)*(1+a*r)*(1-a*t*B*r)*Sc/(2*t*j*dd)
alhat=(1+a*r)*MM/(2*(1-h*B)*dd)
b2=2*a*a*mu*h+C*(1-h)**2+Ah*h+(B*B*alhat+half)*h*h
ck('exact_cancellation_at_a_zero', (b2-alhat).subs(a,0))
num,den=s.fraction(s.cancel(b2-alhat))
quot,rem=s.div(s.Poly(num,a),s.Poly(a,a))
assert rem.is_zero
checks['numerator_divisible_by_a']=True
corner={B:0,a:0,h:0}
den_corner=s.factor(den.subs(corner))
assert den_corner != 0
checks['quotient_denominator_regular_at_joint_corner']=True
ck('cancelled_quotient_identity',quot.as_expr()/den-(b2-alhat)/a)
for name,expr,expected in [
 ('n',n,(1-r)/(2*r)),('mu',mu,(1-r)/2),
 ('C',C,t/2),('D',D,1/(2*(t-1))),
 ('Ah',Ah,t/2),('alpha_over_B2',alhat,t/2)]:
    ck('joint_residue_'+name,expr.subs(corner)-expected)

# Exact rescaling formulas in the existing local full-parent Gram.
k,c4,d2,d4,a4,b4,U = s.symbols('k c4 d2 d4 a4 b4 U', nonzero=True)
ell=1/a
beta=(B*d4+k*c4)/(k*ell**2)
j0=(B*d4-a4*k*k*ell+d2*ell)/(2*k*ell**2)
j1=d4/(2*k*ell)
fs=(b2-c4/ell**2-alhat-B*d4/(k*ell**2))/2
ck('rescaled_beta',beta/a**2-(B*d4+k*c4)/k)
ck('rescaled_J',(j0+j1*U)/a-(a*B*d4-a4*k*k+d2+d4*U)/(2*k))
ck('rescaled_f',fs/a-(quot.as_expr()/den-a*c4-a*B*d4/k)/2)

# Full original parent, with the uncentered hard state retained.
u,v,W,X,Y,Z,Yhat,S,R,q=s.symbols('u v W X Y Z Yhat S R q')
nn,mm,CC,AA,DD,al,mu0,e=s.symbols('nn mm CC AA DD al mu0 e')
Du=1+u*u; Dv=1+v*v
RD=u*W+u*v*X-Y-v*Z
F=nn*Du*Dv*X**2+mm*(v*W-X+u*v*Y-u*Z)**2+CC*Dv*(u*W-Y)**2+AA*Du*Dv*Y**2+DD*RD**2+al*Du*(v*Y-Z)**2+half*(RD**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)
finite=(nn*Du*Dv*X**2+mu0*(v*S-a*X+a*u*v*Y-a*u*Z)**2+CC*Dv*(R-Y)**2+Du*Dv*Yhat**2+DD*(R+u*v*X-Y-v*Z)**2+al*Du*(v*Y-Z)**2+half*((R+u*v*X-Y-v*Z)**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2))
ck('finite_patch_entire_parent',finite.subs({S:a*W,R:u*W,Yhat**2:AA*Y**2})-F.subs(mm,a*a*mu0))
reciprocal=(nn*Du*(1+q*q)*X**2+mu0*(S-a*q*X+a*u*Y-a*u*q*Z)**2+CC*(1+q*q)*(R-Y)**2+Du*(1+q*q)*Yhat**2+DD*(q*R+u*X-q*Y-Z)**2+al*Du*(Y-q*Z)**2+half*((q*R+u*X-q*Y-Z)**2+Du*(Y-q*Z)**2+(1+q*q)*(X+u*Z)**2-Du*(1+q*q)*Z**2))
ck('reciprocal_patch_entire_parent',reciprocal.subs({S:a*W,R:u*W,Yhat**2:AA*Y**2})-q*q*F.subs({v:1/q,mm:a*a*mu0}))
norm={Y:e*Yhat}
residue={a:0,e:0,al:0,u:0}
finite_res=s.expand(finite.subs(norm).subs(residue))
finite_expected=mu0*v*v*S*S+(nn+half)*Dv*X*X+Dv*Yhat*Yhat+(CC*Dv+DD+half)*R*R-2*(DD+half)*v*R*Z+DD*v*v*Z*Z
ck('finite_patch_full_residue',finite_res-finite_expected)
ck('reciprocal_patch_full_residue',reciprocal.subs(norm).subs({**residue,q:0})-(mu0*S*S+CC*R*R+(nn+half)*X*X+Yhat*Yhat+DD*Z*Z))
C0=t/2; D0=1/(2*(t-1)); n0=(1-r)/(2*r)
ck('source_residue_balance',C0*D0-D0/2-half/2)
ck('finite_patch_block_determinant',((CC*Dv+DD+half)*DD*v*v-(DD+half)**2*v*v-CC*DD*v**4).subs({CC:C0,DD:D0}))

# Finite u-unit chart: recompute the complete three-state determinant at m=0.
F3=F.subs({Y:0,mm:0,al:0})
variables=s.Matrix([W,X,Z]); P3=s.hessian(F3,variables)/2
det=s.factor(P3.det())
bcoef=nn*(2*CC+2*DD+1)/4
ccoef=CC*(2*DD+2*nn+1)/4
dcoef=CC*DD*(2*nn+1)/2
expected=Du*Dv*u*u*(bcoef*u*u+ccoef*u*u*v*v+dcoef*v**4)
ck('finite_u_unit_determinant',(det-expected).subs({CC:C0,DD:D0,nn:n0}))

payload={'status':'PASS','count':len(checks),'checks':checks,
 'cancelled_quotient_denominator_at_corner':str(den_corner),
 'scope':'New z/B-positive-infinitesimal source extension. Original source physicality, stationary contact and strict gaps retained. Exact local rescaling relies on previously checked full-parent five-root Gram. Existing reciprocal-u and double-infinity formulas remain positive at m0=0; no residual intersection nonemptiness asserted.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps(payload,indent=2))
