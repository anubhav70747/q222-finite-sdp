# Finite-unit contact covariance: an elementary physical exclusion

Date: 2026-10-17. These are new source-specific reductions. They do not cancel a mixed multiplier and do not revisit plain polynomial SOS.

## 1. Exact hypotheses and notation

Let the nonnegative canonical coefficients be bounded elements of a real closed source field. Assume that the source is physical, meaning that its complete parent is PSD at every real testing angle pair over that field. Assume `res(d)>0`. Take C1 (`lambda=n=0`) or C2 (`lambda=beta=0`). Let an actual zero contact have finite positive unit coordinates `(uc,vc)` and put `Uc=uc^2,Vc=vc^2`.

For the determinant Laurent expression `L=h+sum_nu q_nu U^nu1 V^nu2`, centered outer exponents are the eight nonzero vectors of `{-1,0,1}^2`. At the contact set `m_nu=q_nu Uc^nu1 Vc^nu2`. The logarithmic Hessian is

    C = sum_nu m_nu nu nu^T.

Its stationary balance is `sum_nu m_nu nu=0`. Because `Uc,Vc` are units, `res(m_nu)>0` iff `res(q_nu)>0`. Thus the rank of `res(C)` is precisely the dimension of the span of the active outer exponents in residue.

Write bars for residues and suppress bars when discussing their support. Every `t_i=d+2(sum of nonnegative coefficients)` has positive residue. The nonzero outer terms are therefore determined by these pair products:

    q00: lambda*alpha
    q01: lambda*D or alpha*m
    q02: m*D
    q10: alpha*A or lambda*n
    q12: beta*m or c*D
    q20: n*A
    q21: beta*n or c*A
    q22: beta*c.

No cancellation occurs inside any of these sums.

## 2. Rank zero is physically impossible

Suppose all eight outer residues vanish. The positive event support must avoid every pair in the preceding list. The following maximal supports are exhaustive. Any smaller support is contained in a listed one.

At `u=v=1` define

    K(W,X,Y,Z)=(W+X-Y-Z)^2+2(Y-Z)^2+2(X+Z)^2-4Z^2.

The d-core of the original polynomial parent is exactly `2d K`. The relevant original event rows there are

    n=X, m=W-X+Y-Z, c=W-Y, A=Y,
    D=W+X-Y-Z, alpha=Y-Z, beta=X+Z.

Each table vector annihilates every event in its listed support, and has strictly negative core energy.

| Family | Maximal possible strong support | `(W,X,Y,Z)` | `K` |
|---|---|---|---:|
| C1 | c,m | (1,0,1,2) | -2 |
| C1 | A,m | (2,-1,0,3) | -6 |
| C1 | alpha,c | (1,0,1,1) | -1 |
| C1 | A,D,beta | (2,-1,0,1) | -2 |
| C1 | D,alpha,beta | (3,-1,1,1) | -4 |
| C2 | A,m | (2,-1,0,3) | -6 |
| C2 | A,D | (2,-1,0,1) | -2 |
| C2 | c,m,n | (1,0,1,2) | -2 |
| C2 | alpha,c,n | (1,0,1,1) | -1 |
| C2 | D,alpha,n | (2,0,1,1) | -2 |

At this fixed real angle pair, taking residues preserves PSD: the coefficients are bounded, and the PSD inequality holds on every real state vector. Strong events vanish on the table witness, and all weak coefficients have zero residue. The residue of the full energy is consequently `2 res(d) K<0`, a contradiction. Hence at least one outer residue is positive.

This argument does not assume that literal coercivity passes to residue. It uses a physical test state and retains the full original parent.

## 3. The complete covariance rank classification

A nonzero positive combination `sum m_nu nu nu^T` has rank one only if its active exponents lie on a line through zero. Stationary balance forces both opposite rays to be present. In this eight-point grid there are only horizontal, vertical, and two diagonal possibilities.

### C1

Here `q00=q20=0`, so neither diagonal line can balance. A horizontal rank-one support would require `q01,q21>0`, hence `alpha,m,c,A>0`, which forces `q10>0` off the line. A vertical support would require `q10>0` and `q12>0`. The former forces `alpha,A>0`. If the latter comes from `beta*m>0`, it forces `q01>0`; if it comes from `c*D>0`, it forces `q21>0`. Both contradict vertical rank one.

Together with rank-zero exclusion, this proves

    res(C) is positive definite for every finite-positive-unit C1 contact
    with res(d)>0.

### C2

Here `q00=q22=0`, so the positive-slope diagonal cannot balance. The same product arguments rule out horizontal and vertical rank one. The sole possible rank-one case is

    q02>0, q20>0, all other outer residues zero.

Equivalently,

    n,m,A,D have positive residues; alpha,c have zero residues.

Indeed `q02,q20>0` require `m,D,n,A>0`; then the off-line vanishing equations force `alpha=c=0`. Conversely this residue support has precisely those two outer exponents. The stationary balance imposes

    q02 Vc/Uc = q20 Uc/Vc.

The residue determinant is flat in the common scaling of `(U,V)` and varies only with `V/U`. This is the exact one-dimensional contact-curve exception; its soft curve mode still requires separate treatment.

## 4. Independent hard-state bound and Newton multiplier degeneration

Let `B=dH+sum c_i E_i`, with `E_i` rank-one PSD testing matrices. For `s=|sin(a)sin(b)|` in `(0,1]`, the ordered CHSH-core eigenvalues are

    -a=1-sqrt(1+s), b=1-sqrt(1-s),
    c=1+sqrt(1-s), e=1+sqrt(1+s).

The positive eigenspace of `H` is testing-owned and three-dimensional. In that basis the hard block is exactly

    A=d diag(b,c,e)+sum_i c_i z_i z_i^T.

Thus it has an explicit tensor Gram, and its pure core determinant is

    d^3 b c e = d^3 s(1+sqrt(1+s)).

For a physical PSD `B`, min-max gives `lambda_j(B)>=d lambda_j(H)` for `j=2,3,4`, and therefore

    e3(B)>=lambda2(B)lambda3(B)lambda4(B)
          >=d^3 s(1+sqrt(1+s))>=2d^3 s.

This is an ordered-field lower bound in any common realization in which the physical matrix is PSD. It is not a claimed tensor-SOS identity for the difference.

After a positive source-only trace normalization, `res(d)>0` and a nonzero real residue of `s` imply strictly positive residue of `e3(B)`. Exact `e3(B)=0` with `d>0` is impossible at noncommuting angles. Vanishing-residue multiplier regimes can only occur when the normalized `d` vanishes in residue or the testing observables approach commuting ones.

## 5. What these lemmas accomplish

The finite-unit C1 contact has both a strictly positive hard-state residue block and a strictly positive two-dimensional logarithmic determinant covariance. These are the exact nondegeneracy hypotheses for a local state/angle quadratic normal form, provided that the legal bounded contact-root construction is separately established. C2 has precisely one possible flat covariance direction, with the strong support identified above. No mixed Schur inverse, mixed square root, or unjustified cancellation has entered these statements.

The accompanying standard-library checker exhausts the tiny support families and verifies each integer event-kernel and energy calculation. The Hessian rank arguments are the elementary analytical case proof in Section 3.
