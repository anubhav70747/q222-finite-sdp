#!/usr/bin/env python3
"""Exact all-testing boundary checks for finite-unit-source C2. SymPy only."""
from pathlib import Path
import json
import sympy as s
u,v,a,b,W,X,Y,Z,n,m,c,A,D,alpha,d=s.symbols('u v a b W X Y Z n m c A D alpha d')
Du,Dv=1+u*u,1+v*v
psi=s.Matrix([W,X,Y,Z])
eX=s.Matrix([0,1,0,0]);eY=s.Matrix([0,0,1,0]);eZ=s.Matrix([0,0,0,1])
eM=s.Matrix([v,-1,u*v,-u]);eD=s.Matrix([u,u*v,-1,-v])
ec=s.Matrix([u,0,-1,0]);ea=s.Matrix([0,0,v,-1]);eb=s.Matrix([0,1,0,u])
P=4*n*Du*Dv*eX*eX.T+4*m*eM*eM.T+4*c*Dv*ec*ec.T
P+=4*A*Du*Dv*eY*eY.T+(4*D+2*d)*eD*eD.T
P+=(4*alpha+2*d)*Du*ea*ea.T+2*d*Dv*eb*eb.T-2*d*Du*Dv*eZ*eZ.T
P=s.expand(P)
def zero(f):
    vals=list(f) if isinstance(f,s.MatrixBase) else [f]
    assert all(s.expand(x)==0 for x in vals)
def chart(M,iu,iv):
    out=M
    if iu: out=out.subs(u,1/a)*a*a
    if iv: out=out.subs(v,1/b)*b*b
    return s.expand(out)
charts={(i,j):chart(P,i,j) for i in [0,1] for j in [0,1]}
coords={(0,0):(u,v),(0,1):(u,b),(1,0):(a,v),(1,1):(a,b)}
corners={
 (0,0):s.diag(0,4*(n+m)+2*d,4*(c+A+D)+2*d,4*alpha),
 (0,1):s.diag(4*m,4*n+2*d,4*(c+A+alpha)+2*d,4*D),
 (1,0):s.diag(4*(c+D)+2*d,4*n,4*A,4*(m+alpha)+2*d),
 (1,1):s.diag(4*c,4*(n+D)+2*d,4*(m+A+alpha)+2*d,0)}
for key,M in charts.items():
    first,second=coords[key]
    zero(M.subs({first:0,second:0})-corners[key])
for su in [-1,1]:
    for sv in [-1,1]:
        sign=s.diag(1,sv,su,su*sv)
        zero(P.subs({u:su*u,v:sv*v})-sign.T*P*sign)
F=(psi.T*P*psi)[0]
F01=(psi.T*charts[0,1]*psi)[0]
F10=(psi.T*charts[1,0]*psi)[0]
edge_u0=4*m*(v*W-X)**2+(4*n+2*d)*Dv*X*X
edge_u0+=(4*(c+A)+2*d)*Dv*Y*Y+4*D*(Y+v*Z)**2+4*alpha*(v*Y-Z)**2
edge_v0=(4*(c+D)+2*d)*(u*W-Y)**2+4*A*Du*Y*Y
edge_v0+=4*n*Du*X*X+(4*m+2*d)*(X+u*Z)**2+4*alpha*Du*Z*Z
edge_ui=4*c*Dv*W*W+(4*D+2*d)*(W+v*X)**2+4*n*Dv*X*X
edge_ui+=4*A*Dv*Y*Y+(4*(m+alpha)+2*d)*(v*Y-Z)**2
edge_vi=4*m*(W+u*Y)**2+4*c*(u*W-Y)**2+(4*(A+alpha)+2*d)*Du*Y*Y
edge_vi+=(4*n+2*d)*Du*X*X+4*D*(u*X-Z)**2
zero(F.subs(u,0)-edge_u0);zero(F.subs(v,0)-edge_v0)
zero(F10.subs(a,0)-edge_ui);zero(F01.subs(b,0)-edge_vi)
def jet2(f,zz):
    pol=s.Poly(s.expand(f),*zz)
    assert pol.coeff_monomial(1)==0
    assert all(sum(mon)!=1 or coef==0 for mon,coef in pol.terms())
    return s.Add(*(coef*s.prod(z**e for z,e in zip(zz,mon))
                   for mon,coef in pol.terms() if sum(mon)==2))
p=4*m;q=4*(c+D)+2*d;rx=p+4*n+2*d;ry=q+4*A
Q00=rx*X*X+ry*Y*Y+4*alpha*Z*Z+q*u*u+p*v*v-2*p*v*X-2*q*u*Y
zero(jet2(F.subs(W,1),(X,Y,Z,u,v))-Q00)
completion00=rx*(X-p*v/rx)**2+ry*(Y-q*u/ry)**2+4*alpha*Z*Z
completion00+=p*(4*n+2*d)*v*v/rx+4*A*q*u*u/ry
assert s.factor(Q00-completion00)==0
F11=(psi.T*charts[1,1]*psi)[0]
p=4*D;q=4*(m+alpha)+2*d;rx=p+4*n+2*d;ry=q+4*A
Q11=4*c*W*W+rx*X*X+ry*Y*Y+p*a*a+q*b*b-2*p*a*X-2*q*b*Y
zero(jet2(F11.subs(Z,1),(W,X,Y,a,b))-Q11)
completion11=4*c*W*W+rx*(X-p*a/rx)**2+ry*(Y-q*b/ry)**2
completion11+=p*(4*n+2*d)*a*a/rx+4*A*q*b*b/ry
assert s.factor(Q11-completion11)==0
npacket=4*n*(1+a*a)*(1+v*v)*X*X
Q10=(4*m+2*d)*(a+Z)**2+4*alpha*Z*Z+4*c*W*W+4*A*Y*Y+(4*D+2*d)*(W+v)**2
zero(jet2((F10-npacket).subs(X,1),(W,Y,Z,a,v))-Q10)
receipt={'status':'PASS','arithmetic':'exact symbolic polynomial identities',
 'checks':{'projective_corner_matrices':4,'literal_edge_square_forms':4,'signed_angle_conjugations':4,
           'five_normal_full_quadratic_jets':3,'source_only_square_completions':3},
 'coverage':'all independent testing residues for the finite-unit-source C2 stratum, conditional on the companion stationary-support and interior-testing proof',
 'global_all_source_theorem_claimed':False}
Path(__file__).with_name('ALL_TEST_C2_CHECK_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
