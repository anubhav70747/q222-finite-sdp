"""Focused exact checks for the C14.1b unit-u all-state advance."""
from pathlib import Path
import json
import sympy as s

checks={}
def ck(name, expression):
    if isinstance(expression,s.MatrixBase):
        assert all(s.cancel(e)==0 for e in expression), name
    else:
        assert s.cancel(expression)==0, (name,s.factor(expression))
    checks[name]=True
    print('PASS '+name,flush=True)

u,w,q,W,Z,x,sg,sh,lam,kappa=s.symbols('u w q W Z x sigma sqrt_h lambda kappa')
h=sh**2; U=u*u; z=q*q; ss=x/sg
N,Ny,D,m,nu,chi,Hy,Kr,Rg,b,p,Rx,Ry,cN,Bx,Ay=s.symbols(
    'N Ny D m nu chi Hy Kr Rgamma b p Rx Ry cN Bx Ay')
Gam=sg*Z-u*w*W; R=w*Z/q-u*q*W; A0=q*W; A=(U-x)*A0
Pb=u*Z-ss*w*W; Xe=N-h*Pb
H=sh*u*Z; S=u*w*W-h*U*Z; Zg=S+u*sh*H
Ph=(1-ss*h)*H-ss*sh*S/u
Ga=-S+(sg/(u*sh)-u*sh)*H
Lh=lam*sg/h; rho=lam*x/sg; dd=4*D/sg**2
KA=4*kappa*h/sg-lam
ck('SU4 exact angular-to-normal conductor',A*(A+u*R)-u*(U-x)*w*W*Z+x*(U-x)*A0**2)
ck('SU6 exact Gamma allocation',Gam-Ga)
ck('SU6 exact Pbeta allocation',sh*Pb-Ph)
ck('SU6 exact Xe allocation',Xe-N+sh*Ph)
packet=lam*sg*Pb**2+rho*(U-x)*(w*w-sg*z)*W**2
packet2=Lh*Ph**2+rho*(1-x/U)*Zg**2-rho*sg*(U-x)*A0**2
ck('SU7 complete signed contact packet',packet-packet2)

Hx=2*(1+w*w)+4*m*w*w
normal=Hx*N*N+2*(2*D+1)*U*(N-sh*Ph)**2+dd*Ga**2-4*u*nu*N*Ga
normal+=Lh*Ph**2+rho*(1-x/U)*Zg**2-4*sh*(U-x)*Zg*H/u
angular=2*((U-x)*A0+u*R)**2+2*R*R
angular+=(4*h*x-rho*sg)*(U-x)*A0**2+(KA-(2-4*h))*(U-x)**2*A0**2
angular+=(chi-(4-4*h))*u*(U-x)*A0*R+(Kr-2*(1+U))*R*R
cross=-4*u*q*w*(2*m+2*D+1)*N*Ny+q*w*Rg*Ny*Gam+q*w*b*Rg*R*Gam
cross+=u*q*w*Rx*N*R+(cN+z*Ry)*Ny*R+q*w*Bx*N*A+u*Ay*Ny*A
old=2*(2*D+1)*(u*Xe)**2+Hx*N*N+Hy*Ny*Ny
old+=(dd+4*b*p*z*U)*Gam**2+Kr*R**2-4*u*nu*N*Gam+cross
old+=4*kappa*h/sg*A*A+lam*u*(Gam*Pb+A*R)+chi*u*A*R
new=normal+angular+Hy*Ny*Ny+4*b*p*z*U*Gam**2+cross
ck('SU8-SU10 ENTIRE original SP6 core all hard and first normals',old-new)

Nf,Sf,Hf,df=s.symbols('Nfree Sfree Hfree d_res')
Gr=-Sf-u*sh*Hf; Zgr=Sf+u*sh*Hf
normal_res=2*Nf*Nf+2*U*(Nf-sh*Hf)**2+df*Gr*Gr-4*u*Nf*Gr
normal_res+=2*Hf*Hf+(2-df)*Zgr*Zgr-4*sh*u*Zgr*Hf
target=2*(1+U)*Nf*Nf+4*u*Nf*Sf+2*Sf*Sf+2*Hf*Hf
ck('SU9 exact complete normal residue with both sphere endpoints',normal_res-target)
ck('SU9 normal principal block determinant',s.det(s.Matrix([[2*(1+U),2*u],[2*u,2]]))-4)
angmat=s.Matrix([[2*U**2,2*U*u],[2*U*u,2*(1+U)]])
ck('SU10 angular-radial determinant',s.det(angmat)-4*u**4)

result={'status':'PASS','count':len(checks),'checks':checks,
 'scope':'C14.1b all real/complex states for bounded nonzero unit u and infinitesimal/zero w; all source sphere openings retained',
 'remaining':'C14.1b infinitesimal-u complement, excluding earlier state and sign admissions',
 'dependencies':['R17 exact SP6 full parent','R17 opening-uniform source estimates and source sphere','separated bounded strict-residue Gram lemma'],
 'review_boundary':'Focused exact algebra corroboration; mathematical source estimates and all-state join require review; not formal or external verification'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
