#!/usr/bin/env python3
"""Check exact four-feature weak-source baseline and its edge determinant."""
import json
from pathlib import Path
import sympy as s
HERE=Path(__file__).resolve().parent
u,v=s.symbols('u v')
d,c,A,D,al,be=s.symbols('d c A D alpha beta')
W,X,Y,Z=s.symbols('W X Y Z')
du=1+u*u;dv=1+v*v
F=(4*c*dv*(u*W-Y)**2+4*A*du*dv*Y**2+(4*D+2*d)*(u*W+u*v*X-Y-v*Z)**2
 +(4*al+2*d)*du*(v*Y-Z)**2+(4*be+2*d)*dv*(X+u*Z)**2-2*d*du*dv*Z**2)
P=s.hessian(F,(W,X,Y,Z))/2
order=[1,2,3,0]
H=P.extract(order,order)
for i in range(4):
    for j in range(4):H[i,j]=s.cancel(H[i,j]/u**((i==3)+(j==3)))
assert all(s.denom(z)==1 for z in H)
eta=s.Matrix([X,Y,Z,u*W]);psi=s.Matrix([W,X,Y,Z])
assert s.expand((eta.T*H*eta)[0]-F)==0
assert s.cancel(P.det()-u*u*H.det())==0
H0=H.subs(u,0)
edge=s.cancel(H0.det()/(16*dv*dv))
ep=s.Poly(edge,v)
t1=d+2*D;t2=d+2*(al+A);t3=d+2*(c+D);t4=d+2*(al+be)
t5=d+2*be;t7=d+2*be;t8=d+2*(c+A+D)
q10=4*al*A*t7*t3
q12=4*c*D*t5*t2
q21=4*c*A*t1*t4
q22=4*be*c*t1*t2
assert ep.degree()==4 and all(exp[0]%2==0 for exp in ep.monoms())
assert s.expand(ep.coeff_monomial(1)-q10)==0
assert s.expand(ep.coeff_monomial(v**4)-q12)==0
V,w,U=s.symbols('V w U')
Q10,Q11,Q12,Q21,Q22=s.symbols('Q10 Q11 Q12 Q21 Q22')
Dpoly=U*Q10+U*V*Q11+U*V**2*Q12+U**2*V*Q21+U**2*V**2*Q22
res=s.expand(Dpoly.subs({Q10:Q12*w*w,Q11:-2*Q12*w}))
assert s.expand(res-(U*Q12*(V-w)**2+U**2*V*(Q21+Q22*V)))==0
out={'status':'PASS','scope':'Generic exact m=0 four-feature polynomial Gram, determinant division by U, two endpoint coefficients, and residue stationary determinant factorization','mixed_inversions':0,'H_degree_u':int(max(s.degree(z,u)for z in H)),'H_degree_v':int(max(s.degree(z,v)for z in H)),'edge_middle_coefficient':str(ep.coeff_monomial(v**2)),'endpoint_q10':str(s.factor(q10)),'endpoint_q12':str(s.factor(q12))}
(HERE/'WEAK_C1_ALL_TEST_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
