"""Narrow exact corroboration of common_remote.tex; no source sampling."""
import json
from pathlib import Path
import sympy as s

u,v,p,w,W,X,Y,Z,B,V,R,H,mu = s.symbols('u v p w W X Y Z B V R H mu')
Du,Dv,Dp,Dw = 1+u*u,1+v*v,1+p*p,1+w*w
K=(u*W+u*v*X-Y-v*Z)**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2
M=v*W-X+u*v*Y-u*Z
Cpacket=Dv*(u*W-Y)**2
Apacket=Du*Dv*Y**2
alpacket=Du*(v*Y-Z)**2
checks=[]
def eq(name, a, b=0):
    q=s.cancel(s.expand(a-b))
    assert q==0,(name,s.factor(q))
    checks.append(name)
def res(f, small):
    return s.expand(f).subs(dict.fromkeys(small,0), simultaneous=True)
def polynomial(name, f, variables):
    q=s.Poly(s.expand(f), *variables)
    assert all(e>=0 for m,c in q.terms() for e in m)
    checks.append(name)
def deg2(f,variables):
    return sum(c*s.prod(x**e for x,e in zip(variables,m))
               for m,c in s.Poly(s.expand(f),*variables).terms() if sum(m)<=2)

K2=(u*W-Y+u*v*B)**2+Dv*B**2+Du*v*v*Y*Y+Du*u*u*V*V-2*Du*u*V*(W+v*B)
eq('CE2 full core; every state normal',K2.subs({B:X+u*Z,V:v*Z},simultaneous=True),K)
eq('CE3 restricted kernel determinant',(1+v*v*Du)*Du*u*u-(Du*u*v)**2,Du*u*u)
Kp=s.cancel(p*p*K.subs(u,1/p))
K4=B*B-2*p*v*B*W-2*v*B*Y+Dp*R*R+2*Dp*R*W+(W-p*Y)**2+Dp*v*v*Y*Y
eq('CE4 full core; every state normal',K4.subs({B:p*X+Z,R:v*X},simultaneous=True),Kp)
eq('CE5 full selected residue',res(2*K4+4*mu*Dv*(W-p*Y)**2+4*mu*Dp*Dv*Y*Y,[p]),
   4*mu*Dv*(W*W+Y*Y)+2*(W+R)**2+2*(B-v*Y)**2)
Kw=s.cancel(w*w*K.subs(v,1/w))
K6=u*u*H*H-2*u*u*H*Y-2*u*H*W+2*u*w*H*X+u*u*w*w*W*W+2*u*u*w*W*X-2*u*w*w*W*Y+(Du+w*w)*(X*X+Y*Y)-2*u*w*X*Y
eq('CE6 full core; every state normal',K6.subs(H,w*Z),Kw)
eq('CE6 kernel restriction at w=0',res(K6,[w,W,Y]),Du*X*X+u*u*H*H)
K7=H*H-2*p*H*W+2*p*w*H*X-2*H*Y+w*w*W*W+2*w*W*X-2*p*w*w*W*Y+(Dp+p*p*w*w)*(X*X+Y*Y)-2*p*w*X*Y
eq('CE7 full core; every state normal',K7,s.cancel(p*p*K6.subs(u,1/p)))
eq('CE8 selected double-infinity residue',res(2*K7+4*mu*Dw*(W-p*Y)**2+4*mu*Dp*Dw*Y*Y,[p,w]),
   4*mu*(W*W+Y*Y)+2*X*X+2*(H-Y)**2)
for n,f,variables in [('CE2',K2,[u,v,W,Y,B,V]),('CE4',K4,[p,v,W,Y,B,R]),
                       ('CE6',K6,[u,w,W,X,Y,H]),('CE7',K7,[p,w,W,X,Y,H])]:
    polynomial(n+' bounded polynomial coefficients',f,variables)

# Check the whole core plus both transported selected packets, not just
# the permutation of their labels. The remaining transport is inherited.
rot={u:1/v,v:u,W:Y+v*Z,X:-W-v*X,Y:Z-v*Y,Z:v*W-X}
eq('CE10 whole signed-core transport',v*v*K.subs(rot,simultaneous=True),Dv*K)
eq('CE10 original A to rotated C',v*v*Cpacket.subs(rot,simultaneous=True),Dv*Apacket)
eq('CE10 original alpha to rotated A',v*v*Apacket.subs(rot,simultaneous=True),Dv*alpacket)
transform=s.Matrix([[0,0,1,v],[-1,-v,0,0],[0,0,-v,1],[v,-1,0,0]])
eq('CE9 state-map squared determinant',transform.det()**2,Dv**4)

F=2*K+4*mu*(M*M+Cpacket+Apacket+alpacket)
eq('four-packet zero-zero residue',res(F,[u,v]),(2+4*mu)*X*X+(2+8*mu)*Y*Y+4*mu*Z*Z)
F0=F.subs(W,1)
eq('CE11 entire corner degree at most two',deg2(F0,[u,v,X,Y,Z]),
   2*(u-Y)**2+2*X*X+4*mu*((v-X)**2+(u-Y)**2+Y*Y+Z*Z))
Fp=s.cancel(p*p*F.subs(u,1/p))
F1=Fp.subs(X,1)
eq('CE12 entire corner degree at most two',deg2(F1,[p,v,W,Y,Z]),
   2*(W+v)**2+2*(p+Z)**2+4*mu*((p+Z)**2+W*W+Y*Y+Z*Z))
P13=4*mu*((W-w*X+u*Y-u*H)**2+Dw*(u*W-Y)**2+Du*Dw*Y*Y+Du*(Y-H)**2)
eq('CE13 every capped packet after homogenization',P13.subs(H,w*Z),s.cancel(w*w*(F-2*K).subs(v,1/w)))
eq('CE14 strict full residue',res(2*K6+P13,[u,w]),4*mu*W*W+2*X*X+(8*mu+2)*Y*Y+4*mu*(Y-H)**2)
P15=4*mu*((p*W-p*w*X+Y-H)**2+Dw*(W-p*Y)**2+Dp*Dw*Y*Y+Dp*(Y-H)**2)
eq('CE15 every capped packet after double homogenization',P15,s.cancel(p*p*P13.subs(u,1/p)))
eq('CE16 strict full residue',res(2*K7+P15,[p,w]),4*mu*W*W+2*X*X+4*mu*Y*Y+(8*mu+2)*(Y-H)**2)
for name,poly,vars in [('CE11',F0,[u,v,X,Y,Z]),('CE12',F1,[p,v,W,Y,Z])]:
    assert min(sum(m) for m,c in s.Poly(poly,*vars).terms())==2
    checks.append(name+' exact square-ideal membership')

q,E,Fq,Gq,Vq,Rq,Sq,c,mstar,astar,bstar=s.symbols('q E Fq Gq Vq Rq Sq c mstar astar bstar')
K18=Vq**2+(Du+w*w)*X*X+q*q*(u*u*(Gq-Fq)**2+Dw*Fq*Fq)-2*u*Gq*E+2*q*u*w*X*(Gq-Fq)+2*u*Vq*X-2*u*w*w*E*Fq
eq('CE18 complete weak-weight core',K18.subs({E:q*W,Fq:Y/q,Gq:H/q,Vq:u*w*W},simultaneous=True),K6)
F19=2*K18+4*mstar*(E-q*w*X+u*q*q*(Fq-Gq))**2+4*astar*Du*Dw*Fq*Fq+4*bstar*Du*(Fq-Gq)**2
eq('CE19 complete weak-weight residue',res(F19,[u,w,q]),2*Vq*Vq+2*X*X+4*mstar*E*E+4*astar*Fq*Fq+4*bstar*(Fq-Gq)**2)
K20=Rq*Rq+Dw*Sq*Sq+q*q*(Gq-Fq)**2+p*p*Dw*q*q*Fq*Fq-2*p*E*(Gq+w*w*Fq)+2*q*w*Sq*(Gq-Fq)
eq('CE20 complete weak-weight core',K20.subs({E:q*W,Fq:Y/q,Gq:H/q,Rq:X+w*W,Sq:p*X},simultaneous=True),K7)
F21=2*K20+4*c*Dw*(E-p*q*q*Fq)**2+4*astar*Dp*Dw*Fq*Fq+4*bstar*Dp*(Fq-Gq)**2
eq('CE21 complete weak-weight residue',res(F21,[p,w,q]),2*Rq*Rq+2*Sq*Sq+4*c*E*E+4*astar*Fq*Fq+4*bstar*(Fq-Gq)**2)
report={'status':'PASS','count':len(checks),'checks':checks,
        'scope':'Exact identities and polynomial support only. common_remote.tex supplies source entry, strictness, exhaustion, and tensor-SOS inference.',
        'whole_rows_closed':[]}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
