#!/usr/bin/env python3
"""Small exact circuit classification and SOS identities; standard library only."""
from itertools import combinations
from fractions import Fraction
from pathlib import Path
import json
if not __debug__:
    raise SystemExit('Run without -O: assertions are exact checks.')

points=[(x,y) for x in (-1,0,1) for y in (-1,0,1) if x or y]
cross=lambda p,q:p[0]*q[1]-p[1]*q[0]
pairs=[c for c in combinations(points,2) if tuple(-v for v in c[0])==c[1]]
triangles=[]
for p,q,r in combinations(points,3):
    w=(cross(q,r),cross(r,p),cross(p,q))
    if all(t>0 for t in w) or all(t<0 for t in w):
        w=tuple(abs(t) for t in w)
        assert all(sum(w[i]*z[j] for i,z in enumerate((p,q,r)))==0 for j in (0,1))
        triangles.append(((p,q,r),w))
assert len(pairs)==4 and len(triangles)==8
assert sorted(sorted(w) for _,w in triangles)==[[1,1,1]]*4+[[1,1,2]]*4

zero=(0,0,0)
def C(q): return {zero:Fraction(q)} if q else {}
def add(*ps):
    out={}
    for p in ps:
        for e,c in p.items(): out[e]=out.get(e,0)+c
    return {e:c for e,c in out.items() if c}
def scale(p,c): return {e:v*c for e,v in p.items() if v*c}
def mul(p,q):
    out={}
    for e,c in p.items():
        for f,d in q.items():
            g=tuple(x+y for x,y in zip(e,f))
            out[g]=out.get(g,0)+c*d
    return {e:c for e,c in out.items() if c}
def pow_(p,n):
    out=C(1)
    for _ in range(n): out=mul(out,p)
    return out
def sub(p,q): return add(p,scale(q,-1))
a,b,c=({tuple(int(i==j) for i in range(3)):Fraction(1)} for j in range(3))
sq=lambda p:pow_(p,2)
# x=a², y=b². Difference is exactly twice the product constraint ab-1.
assert sub(sub(add(sq(a),sq(b),C(-2)),sq(sub(a,b))),scale(add(mul(a,b),C(-1)),2))=={}
# x=a³, y=b³, z=c³; abc=1.
left=add(pow_(a,3),pow_(b,3),pow_(c,3),scale(mul(mul(a,b),c),-3))
right=scale(mul(add(a,b,c),add(sq(sub(a,b)),sq(sub(b,c)),sq(sub(c,a)))),Fraction(1,2))
assert sub(left,right)=={}
# x=a⁴,y=b⁴,z=c²; abc=1.
left=add(pow_(a,4),pow_(b,4),scale(sq(c),2),C(-4))
right=add(sq(sub(sq(a),sq(b))),scale(sq(sub(mul(a,b),c)),2))
assert sub(sub(left,right),scale(add(mul(mul(a,b),c),C(-1)),4))=={}
report={'status':'PASS','opposite_pair_circuits':len(pairs),'triangle_circuits':len(triangles),
        'checked_identities':3,'scope':'Integer minimal positive dependencies and exact polynomial circuit identities. Cone decomposition, endpoint homogenization and conductor deductions are proved in the text.'}
Path(__file__).with_name('circuit_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
