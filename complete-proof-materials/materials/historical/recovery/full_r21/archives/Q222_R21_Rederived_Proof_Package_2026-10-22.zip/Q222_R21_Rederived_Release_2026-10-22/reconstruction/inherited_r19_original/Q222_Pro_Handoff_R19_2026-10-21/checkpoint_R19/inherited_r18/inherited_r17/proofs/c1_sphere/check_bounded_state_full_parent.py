"""Focused exact checks for the new C14.1b bounded-state full parent.

Imports the already-verified complete SP6 parent as an exact dependency.
All hard, scalar, and Gamma first-normal terms are retained explicitly.
"""
import json
import time
from pathlib import Path
import sympy as s

started=time.monotonic()
checks={}
def ck(name,expr):
    if isinstance(expr,s.MatrixBase):
        assert all(s.cancel(x)==0 for x in expr),name
    else:
        assert s.cancel(expr)==0,(name,s.factor(expr))
    checks[name]=True
    print('PASS '+name,flush=True)

u,w,q,f,Z,x,sg,sh,lam,kappa=s.symbols(
    'u w q f Z x sigma sqrt_h lambda kappa')
h=sh**2; H=h/sg; z=q*q; ss=x/sg
W=f*Z
R=w*Z/q-u*q*W
At=q*(u*u-x)*W
Gam=sg*Z-u*w*W
Pb=u*Z-x*w*W/sg
Uh=sh*u*Z
Lh=lam/H
rho=lam*x/sg
KA=4*kappa*H-lam
Bf=(sg-x*z*f*f)/sh
Ug=Bf*Uh-u*q*f*At-u*u*q*f*R
Wg=q*z*f*Bf*Uh-u*z*z*f*f*At+z*(sg-u*f*w-u*u*z*f*f)*R

ck('BS3 exact Pbeta state conductor',sh*Pb-(1-ss*z*f*f)*Uh+sh*ss*q*f*R)
ck('BS5 full first Gamma normal',u*Gam-Ug)
ck('BS6 full radial and second Gamma normals',q*w*Gam-Wg)
positiveQ=rho*u*u*w*w*W*W
positiveM=lam*x*x*z*W*W
packet_old=lam*sg*Pb*Pb+rho*(u*u-x)*(w*w-sg*z)*W*W
packet_new=Lh*((1-ss*z*f*f)*Uh-sh*ss*q*f*R)**2+positiveQ+positiveM
packet_new-=Lh*ss*z*f*f*Uh*Uh
packet_new-=Lh*ss*ss*(sh*q*f*R+z*f*f*Uh)**2
ck('BS4 complete signed contact product including both negative terms',packet_old-packet_new)
ck('BS2 extraction using whole lambda',4*kappa*H*At**2+lam*u*(Gam*Pb+At*R)
   -KA*At**2-packet_old)

# Reassemble the entire SP6 core, with each unchanged generic coefficient
# free. This prevents a scalar-only test from hiding a dropped normal.
Nx,Ny,D,m,b,p,nu,chi,Hxx,Hy,Kr,Rx,Ry,Rg,cN,Bx,Ay=s.symbols(
    'Nx Ny D m b p nu chi Hxx Hy Kr Rx Ry Rgamma cN Bx Ay')
Xe=Nx-h*Pb
retained=2*(2*D+1)*(u*Xe)**2
retained+=(4*D/sg**2+4*b*p*z*u*u)*Gam**2
basic=-4*u*q*w*(2*m+2*D+1)*Nx*Ny+u*q*w*Rx*Nx*R
basic+=(cN+z*Ry)*Ny*R+q*w*Bx*Nx*At+u*Ay*Ny*At
sp6=retained+Hxx*Nx**2+Hy*Ny**2+Kr*R**2+basic
sp6+=-4*nu*Nx*(u*Gam)+Rg*(Ny+b*R)*(q*w*Gam)
sp6+=4*kappa*H*At**2+lam*u*(Gam*Pb+At*R)+chi*u*At*R
new=retained+Hxx*Nx**2+Hy*Ny**2+Kr*R**2+basic
new+=-4*nu*Nx*Ug+Rg*(Ny+b*R)*Wg+KA*At**2+chi*u*At*R+packet_new
ck('BS2-BS8 ENTIRE original SP6 core all hard and first normals',sp6-new)
ck('additional_D_zero_null_state_retained_exactly',
   new.subs({u:0,w:0,f:0,Nx:0,Ny:0})-4*D*Z**2)

ll=s.symbols('sqrt_lambda',positive=True)
Ml=ll*x*q*W
ck('BS11 exact unit_h angular conductor',At-q*f*u*Uh/sh+Ml/ll)

# Positive-residue proof uses these exact two finite matrices.
u0=s.symbols('u0',real=True)
angular=s.Matrix([[2,2*u0],[2*u0,2*(1+u0*u0)]])
ck('BS10 complete angular_radial residue determinant',s.det(angular)-4)
small_h=s.diag(2,2*(1+u0*u0),2,1,1)
small_h[3:5,3:5]=angular
ck('BS10 full strict residue determinant',s.det(small_h)-32*(1+u0*u0))
unit_h=s.diag(2,2*(1+u0*u0),2,2*(1+u0*u0),1)
ck('BS12 full strict residue determinant',s.det(unit_h)-16*(1+u0*u0)**2)

# Exact bounded Gram for BS4, with positive Q and M squares kept.
Rfree,Ufree=s.symbols('Rfree Ufree')
base=Lh*((1-ss*z*f*f)*Ufree-sh*ss*q*f*Rfree)**2
base-=Lh*ss*z*f*f*Ufree**2+Lh*ss**2*(sh*q*f*Rfree+z*f*f*Ufree)**2
packetgram=s.hessian(base,(Ufree,Rfree))/2
Lf,st=s.symbols('Lh s_source')
packetgram=packetgram.subs(lam,Lf*h/sg).subs(x,st*sg).applyfunc(s.cancel)
ck('BS4 full contact-packet residue without mixed inversion',
   packetgram.subs({st:0,q:0,Lf:2})-s.diag(2,0))

XX,YY,WW,ZZ=s.symbols('X Y W Z')
Du=1+u*u; Dw=1+w*w
Jw=u*w*WW+u*XX-w*YY-ZZ
Kw=Jw**2+Du*(YY-w*ZZ)**2+Dw*(XX+u*ZZ)**2-Du*Dw*ZZ**2
ck('original_reciprocal_core_at_literal_w_zero',
   Kw.subs(w,0)-Du*(XX*XX+YY*YY))
ck('original_reciprocal_core_at_literal_Z_zero',
   Kw.subs(ZZ,0)-(u*w*WW+u*XX-w*YY)**2-Du*YY**2-Dw*XX**2)

payload={
 'status':'PASS','count':len(checks),'checks':checks,
 'scope':'C14.1b entire original parent, bounded u and infinitesimal/zero w, Z nonzero and W/Z bounded in pure testing; Z=0 by original-core sign lemma',
 'remaining':'Positive WZ with W/Z unbounded; no entire source branch admission',
 'imported_dependencies':['complete exact SP6 generic full-parent identity','BE opening-uniform source estimates and SP9-SP11 source cancellations','finite bounded positive-Gram criterion','original-core sign exit for Z=0'],
 'seconds':round(time.monotonic()-started,3)}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
print(f'{len(checks)} focused exact assertions passed in {payload["seconds"]} seconds',flush=True)
