"""Only the new state determinant, scalar circuit and toric conductors."""
import json
from pathlib import Path
import sympy as s

checks = {}
def ck(name, expr):
    value = s.cancel(expr)
    assert value == 0, (name, value)
    checks[name] = True
    print('PASS ' + name)

# New matched-ratio exit determinant; do not rerun historical LA identities.
c0,s0,rho,L,r=s.symbols('c0 s0 rho L r')
b=L*r; Le=L*(1-r)
M=s.Matrix([[c0+s0,-c0*(rho-Le)-s0*b],
            [-c0*(rho-Le)-s0*b,c0*(rho-Le)**2+s0*b*b]])
ck('offmatched_state_determinant',M.det()-c0*s0*(rho-L)**2)

# Entire new opening-safe radial extraction, including all first normals.
a,ell,C,z,b,D,m,t,xi,h,sigma,abeta,Ny,R=s.symbols('a ell C z b D m t xi h sigma abeta Ny R')
Q=1-b; p=a*b; ll=ell*Q; g=h-Q; r=b*z
Du=1+t; Dw=1+xi
Hy=4*Du*(a*Dw+ell)+4*m*t*z+4*C*z*Dw+(4*D+2)*xi*z+2*Du*z
k0=2*b*((2*C+1)*b+4*D+4*p*sigma+2*(2*C+2*D+1)*sigma*(r-1))
k1=2*(1+2*m)*g*g+8*D*h*b+8*p*b*sigma+4*abeta
k2=2*b*b*(2*C+2*D+1)
Kr=k0+k1*t+k2*xi
Ry=4*(t*(2*D*h+2*p*sigma+(1+2*m)*g)+b*(2*C+2*D+1)*(xi+sigma*z)+(2*C+1)*(b-sigma)+2*D*(1-sigma)+2*p*sigma)
cG=4*Du*(p*b*Dw+ll*Q)
cN=8*Du*(p*Dw-ll)
actual_radial=Hy*Ny*Ny+(cG+z*Kr)*R*R+(cN+z*Ry)*Ny*R
positive_radial=4*Du*(a*Dw*(Ny+b*R)**2+ell*(Ny-Q*R)**2)+2*z*(2*C+1)*(Ny+b*R)**2+4*C*z*xi*(Ny+b*R)**2
Eyy=2*z*((1+2*m)*t+(1+2*D)*xi)
ERR=z*(8*b*D+8*b*p*sigma+4*b*sigma*(2*C+2*D+1)*(r-1)+k1*t+2*b*b*(2*D+1)*xi)
EyR=4*z*(t*(2*D*h+2*p*sigma+(1+2*m)*g)+b*(2*D+1)*xi+sigma*(2*C+1)*(r-1)+2*D*(1+sigma*(r-1))+2*p*sigma)
ck('full_opening_safe_radial_extraction',actual_radial-positive_radial-Eyy*Ny*Ny-ERR*R*R-EyR*Ny*R)

# Substitute z=z6^6,c=j^3,lambda=l^2,sigma=S^2,x=k^2.
# All displayed radicals now separate into rational monomials.
z6,j,l,S,k,V,F,W,beta0=s.symbols('z6 j l S k V F W beta0',nonzero=True)
q=z6**3; z=z6**6; lam=l*l; sig=S*S; x=k*k
c=j**3; u=j*V*F; w=V/j; Z=F*W/j
kc=z6*z6*j
V0=S*z6; F0=k*z6/S; g0=l*k*z6
A1=l*S*V*F*F*W
A2=l*k/S*V*V*F*W
A3=l*k*k*q*W
G=g0*V*F*W
d1=A1-G; d2=A2-G; d3=A3-G
Jc=(kc-1)*V*F*W
R=w*Z/q-u*q*W
Gamma=sig*Z-u*w*W
At=q*(u*u-x)*W
Pbeta=u*Z-x/sig*w*W
rho_s=lam*x/sig
scalar=lam*sig*Pbeta**2+rho_s*(u*u-x)*(w*w-sig*z)*W*W
rc=1/kc
extra=lam*x*z*(u*W*(rc-1)*rc*(rc+1))**2+2*lam*x*z*(u*W*(rc-1)*rc)**2
ck('ternary_product',A1*A2*A3-G**3)
ck('entire_signed_scalar_plus_radial_cost',scalar+lam*x*R*R-(A1*A1+A2*A2+A3*A3-3*G*G)-extra)
ck('radial_root_without_mixed_inverse',R+(kc*kc+kc+1)/(q*j*j)*Jc)
ck('first_toric_conductor',(F-F0)*G-F0*d1)
ck('second_toric_conductor',(V-V0)*G-V0*d2)
BG=beta0*V0/g0
ck('w_weighted_Gamma',w*beta0*Gamma+BG*(V0+V)/(kc*j)*d2+beta0*V*V/(kc*j)*Jc)
ck('u_weighted_Gamma',u*beta0*Gamma+BG*j*F*(V0+V)/kc*d2+beta0*j*V*V*F/kc*Jc)
gamma_a=q*c*w/(l*S)
ck('full_angular_conductor',At-gamma_a*d1-kc*kc/l*d2+d3/l-(kc+1)*k*z6*Jc)

# Constant-diagonal AMGM decomposition in the pure separated cube roots.
p1,p2,p3=s.symbols('p1 p2 p3')
gg=p1*p2*p3
aa=[p1**3,p2**3,p3**3]
rhs=sum((a-gg)**2 for a in aa)+gg*(p1+p2+p3)*((p1-p2)**2+(p1-p3)**2+(p2-p3)**2)
ck('strict_ternary_circuit',sum(a*a for a in aa)-3*gg*gg-rhs)

payload={'status':'PASS','count':len(checks),'checks':checks,
         'scope':'New exact state-exit determinant and scalar/normal/angular toric identities only; no historical suite replay.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
print(str(len(checks))+' focused checks passed')
