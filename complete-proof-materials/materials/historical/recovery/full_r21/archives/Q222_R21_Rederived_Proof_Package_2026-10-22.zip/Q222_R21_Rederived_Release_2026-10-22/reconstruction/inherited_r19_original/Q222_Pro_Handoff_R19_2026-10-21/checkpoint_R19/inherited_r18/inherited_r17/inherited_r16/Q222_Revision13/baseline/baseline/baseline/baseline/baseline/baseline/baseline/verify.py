#!/usr/bin/env python3
"""Integrity and small exact replays for the cumulative Q222 package.

Run from any directory. Replays run in temporary directories and do not
change historical check receipts. The global atlas is not replayed.
"""
from pathlib import Path
import argparse, hashlib, json, shutil, subprocess, sys, tempfile

ROOT=Path(__file__).resolve().parent

def sha256(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for part in iter(lambda:f.read(1024*1024),b''):h.update(part)
    return h.hexdigest()

def main():
    if not __debug__:
        raise SystemExit('Run without -O: assertions in proof checkers must be enabled.')
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--with-sympy',action='store_true',help='Also replay the new C2 symbolic identities.')
    p.add_argument('--integrity-only',action='store_true',help='Only verify distributed file hashes.')
    args=p.parse_args()
    manifest=json.loads((ROOT/'MANIFEST.json').read_text())
    failures=[]
    for entry in manifest['files']:
        f=ROOT/entry['path']
        if not f.is_file():failures.append({'path':entry['path'],'reason':'missing'})
        elif f.stat().st_size!=entry['bytes'] or sha256(f)!=entry['sha256']:
            failures.append({'path':entry['path'],'reason':'size or SHA-256 mismatch'})
    report={'integrity':{'files_checked':len(manifest['files']),'failures':failures},'exact_replays':[],'atlas_replayed':False}
    if failures:
        print(json.dumps(report,indent=2));return 1
    scripts=[] if args.integrity_only else ['advances/c1/check_shape_openings.py']
    if args.with_sympy and not args.integrity_only:scripts.append('advances/c2/check_all_tests.py')
    for name in scripts:
        with tempfile.TemporaryDirectory(prefix='q222-replay-') as d:
            script=Path(d)/Path(name).name;shutil.copy2(ROOT/name,script)
            run=subprocess.run([sys.executable,str(script)],cwd=d,text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            item={'script':name,'exit_code':run.returncode,'status':'PASS' if run.returncode==0 else 'FAIL'}
            if run.returncode:
                item['stdout']=run.stdout[-6000:];item['stderr']=run.stderr[-6000:]
            report['exact_replays'].append(item)
    report['status']='PASS' if all(i['exit_code']==0 for i in report['exact_replays']) else 'FAIL'
    print(json.dumps(report,indent=2))
    return 0 if report['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
