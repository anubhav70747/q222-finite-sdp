# Separate-agent review: C2 actual-angle reductions

**Verdict: PASS; no blocking gap found in the stated positive-chart
source reductions.** This is a same-system separate-agent review, not
external or proof-assistant verification. Reviewed
`analysis_atlas/oct18b_cover/angle_reductions.tex` against the original
rational formulas and the cited inherited exits.

## Ordinary–ordinary actual contacts

When both actual angles are bounded units, the positive gaps bound
`h,t,b`; `g>0` gives a positive lower bound for `b+r`; and the positive
expansion makes `Delta` a bounded unit. Therefore the numerator in the
original `A` formula is a unit and its denominator is bounded, proving
`A` strong without an upper bound.

The specialization of the exact `n` numerator at `r=1` is strictly
negative, uniformly for the bounded variables in this case. Thus
`n>=0` excludes infinitesimal `1-r`. The `m` numerator is consequently
a unit, while `g Delta` is bounded, proving `m` strong. Applying this
same argument to the exact reflected source proves `D` strong.

If either complementary coefficient is infinitesimal, its exact formula
forces `N` infinitesimal; all factors needed for this implication are
bounded or have bounded reciprocals in the stated case. The positive
identity for `N` then forces `h,j` infinitesimal. This makes
`t=Ac-j` and `1-zh` units, so both `C,alpha` are infinitesimal.
The inherited chart-free theorem in
`baseline/baseline/current/contact/chart_free_c2.tex` requires no
additional matching-weight or source-angle assumptions. Otherwise all
five consecutive events `D,C,A,alpha,m` are strong, exactly the all-tests
exit in `prior/prior_core/cover/six_template_reduction.tex`. Literal
`n=0` is harmless in both alternatives.

## Directed exactly-one-weak exclusions

Orient the source with weak `C` and strong `alpha`.

- **Actual (unit,Inf).** Weak `C` gives `N/a^2` infinitesimal. The
  positive identity gives `j,rt` infinitesimal. Then `t` is a unit and
  `r` infinitesimal; `g>0` forces `h` to be a unit. The first positive
  summand of `N` is a unit, a contradiction. All coefficients used in
  the division are controlled in this angle type.
- **Actual (Inf,unit).** For bounded `b`, the inherited exact entry
  inequality makes `b` a unit. The canceled identity

  ```
  x C(b-h) = Ac (xN)/(2 Delta),
  xN=(1+x)(b+r)(xh+k^2)-x(1+k^2)(1-r)(b-h)
  ```

  has positive-unit right side. This identity needs no lower bound on
  `g`; its residue numerator is `k0^2(b0+r0)>0`. Thus `C` is strong.
  For unbounded `b`, the exact reduction gives `C L` a unit with
  bounded `L`, again proving `C` strong. These two possibilities exhaust
  positive `b`.
- **Actual (Inf,Inf).** `L=yt` is infinitesimal and `B=H+L` bounded.
  If `H` were a unit, the first positive summand of `N` and the
  unit quotient `Delta/b` would give `C >= c0 H/L`, contradicting
  weak `C`. Hence `H,B` are infinitesimal. The exact ratio
  `alpha/C=(B+zr)L/[Ac(1-H)]` is then infinitesimal, forcing weak
  `alpha`, contrary to the orientation.

Together with the ordinary–ordinary result, these are exactly the four
excluded ordered angle types. The five remaining listed types are the
correct complement in the 3-by-3 classification. The reflection of
`(unit,unbounded)` is the established `(Inf,unit)` domain with the weak
complement exchanged, so the stated reflected unbounded-b leaf is
correct. The list makes no unwarranted nonemptiness claim.

The bounded-b identity above was sent to the author as an optional
exposition strengthening: it prevents a reader from accidentally
importing the stronger `g`-unit hypothesis of the opening *theorem*
when only its canceled coefficient identity is needed.

## Exact double-infinitesimal witness

The final source has all original chart gaps and all six retained
coefficients positive for infinitesimal `x>0`. The inherited original
stationary identities plus the strict `Z=0` state restriction and
Laurent convexity prove its physicality. Its actual pair is `(Inf,Inf)`
and its weak `m,A` defeat the five-consecutive-strong exit. Therefore
that strong-complementary angle orbit cannot be removed by a source
nonexistence assertion. This is correctly distinguished from a
counterexample to tensor SOS.

No tensor-SOS conclusion is supplied here for the remaining ordered
angle types or the double-infinitesimal witness.
