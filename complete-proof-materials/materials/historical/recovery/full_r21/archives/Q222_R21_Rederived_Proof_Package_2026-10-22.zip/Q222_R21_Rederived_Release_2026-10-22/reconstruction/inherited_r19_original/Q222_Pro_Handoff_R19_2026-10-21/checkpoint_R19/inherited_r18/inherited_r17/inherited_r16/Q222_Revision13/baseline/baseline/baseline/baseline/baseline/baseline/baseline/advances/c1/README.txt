C1 ORDINARY ANGLES: ALL POSITIVE SHAPE OPENINGS

Read arbitrary_shape_openings.tex, an extension of the authoritative
../../current/c1/ordinary_angle.tex in this cumulative package.

The theorem removes ALL four unit hypotheses on a,t,M,J. It assumes
only k and s=g/f positive bounded units, eta=f^2 positive infinitesimal,
zeta=s^2 eta, and positive native shapes/gaps a,t,M=R-t,J=T-a.
These inequalities already imply a,t<K and R,T positive units.
The original event coefficients need not be bounded or comparable.

Mechanism
---------
Retain the four exact positive packets with coefficients t/M, M/t,
J/a and a/J. After the positive pure coefficient scaling Delta^2 Lambda,
their remainder G has only bounded coefficients. Its two hard-normal
reserves and soft scalar are independent of all four opening rates.
A pure-testing coordinate w avoids a mixed inverse. The old angular
capacity identity and five-root contact Hessian now finish the entire
finite-unit Alice chart. In outer charts, explicit source lower bounds
on m/a,c/a,D/a,beta/a allow four constant positive weights; all excess
weights are retained as positive packets. No capped-source physicality
claim is made or required.

Run the new checker with:

    python check_shape_openings.py

It is self-contained, uses only the Python standard library, and refuses
optimized Python (-O). The actual first run passed 34 exact polynomial
and monomial-allocation checks in 0.706 seconds. The JSON report records
the executed status and timing. Its checks include all four packet
subtractions, the full inverse-coordinate identities, bounded Gram
allocation of the entire remainder, vanishing coefficient errors,
shape-free leading model, state relation, angular factorization, contact
Hessian/minors, weighted normal divisibility, and both Alice endpoints.

The native source formulas and exact contact identities are explicitly
inherited from the existing source-definition appendix, whose earlier
checker already verifies all six contact balances. The new proof uses
those algebraic identities for bounded shapes, regardless of their
residue. Positivity and the finite Taylor argument are stated in the
proof, not inferred from a computational PASS label.

Remaining scope
---------------
Nonunit k or s, non-small eta, and literal zero openings outside the
native formulas remain outside this theorem. Entry of an actual physical
contact into the native formula still uses the inherited sign/minor
domain; this note does not enlarge that domain or claim global coverage.
