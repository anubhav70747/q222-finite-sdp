#!/usr/bin/env python3
"""Exact corroboration of the C1 small-L/bounded-eta remote reduction."""
import json
from pathlib import Path
import sympy as s

checks = {}
def ck(name, expr):
    ans = s.factor(s.cancel(s.together(expr)))
    if ans != 0:
        raise AssertionError((name, ans))
    checks[name] = True

# Clear every source opening before taking the small-L residue.
L,q,r,e,b=s.symbols('L q r e b')
x=q*L; zeta=1/q; theta=b*L; h=1-theta
K=1+x; Rn=1+x*r; T=1+x*h; M=Rn-theta/zeta
y=L*e; En=1-x*e*h; Q=1-L*r; J=T-(1-r)/e
rho=r+e; j=e*J; G=h+zeta
P4=T*En+x*(1-r)*G
Pal=Rn*h*(1+y)+zeta*M*En
Pd=1+2*x*h+r*x*x*G+x*zeta+e*x*(K*zeta+x*h*theta)
B5=K*(1+y)*rho-j*Pd
C=K*rho*En/(2*(1-r)*Pd)
A=e*P4/(2*r*Pd)
D=B5/(2*j*Pd)
m=K*x*rho*h*(1+y)/(2*M*zeta*Pd)
al=x*x*zeta*rho*Pal/(2*Q*Pd)
beta=(K*x*rho*G-theta*Pd)/(2*theta*Pd)
ck('exact_beta_opening_identity',2*beta*theta*Pd-K*rho*(x*h+L)+theta*Pd)
def res(f):
    return s.cancel(f).subs(L,0)
ck('B5_residue_is_one',res(B5)-1)
for name,expr,target in [
 ('C_opening_cleared',C*(1-r),rho/2),
 ('A_opening_cleared',A*r/e,s.Rational(1,2)),
 ('D_opening_cleared',D*j,s.Rational(1,2)),
 ('m_scale',m*L/(x*x),rho/2),
 ('alpha_scale',al/(L*(L+x)),rho/2),
 ('beta_scale',(2*beta+1)*theta/(x+L),rho)]:
    ck(name,res(expr)-target)

# Full original core and D event in both raw remote frames.
u,v,W,X,Y,Z,p,R,B=s.symbols('u v W X Y Z p R B')
du=1+u*u;dv=1+v*v
Jraw=u*W+u*v*X-Y-v*Z
core=Jraw**2+du*(v*Y-Z)**2+dv*(X+u*Z)**2-du*dv*Z**2
core1=(p-Y+u*v*B)**2+dv*B**2+du*v*v*Y**2+du*u*u*R**2-2*du*u*R*(W+v*B)
ck('whole_small_v_core_frame',core1.subs({p:u*W,R:v*Z,B:X+u*Z})-core)
ck('whole_small_v_D_event',(p-Y+u*v*B-du*R).subs({p:u*W,R:v*Z,B:X+u*Z})-Jraw)
core2=(p+u*v*X-Y-R)**2+du*v*v*Y**2-2*du*Y*R+dv*X*X+2*dv*u*X*R/v+(u*u/v**2-1)*R**2
ck('whole_small_u_core_frame',core2.subs({p:u*W,R:v*Z})-core)

# Strict residue blocks and all divergent-opening kernels.
U,V=s.symbols('U V',positive=True)
j0=e+r-1
c0=(r+e)/(2*(1-r));a0=e/(2*r);d0=1/(2*j0)
def fu(c,a,d):
    return c*(p-Y)**2+a*(1+U)*Y**2+d*(p-Y-(1+U)*R)**2+s.Rational(1,2)*((p-Y)**2+(1+U)*U*R**2-2*(1+U)*p*R)
def fv(c,a,d):
    return c*(1+V)*(p-Y)**2+a*(1+V)*Y**2+d*(p-Y-R)**2+s.Rational(1,2)*((p-Y)**2+V*Y**2-2*p*R)
def gram(f,vs):return s.hessian(f,vs)/2
Mu=gram(fu(c0,a0,d0),(p,Y,R));Mv=gram(fv(c0,a0,d0),(p,Y,R))
ck('small_v_first_pivot',Mu[0,0]-e*(e+r)/(2*(1-r)*j0))
ck('small_v_second_minor',Mu[:2,:2].det()-e*e*(1+U)*(e+r)/(4*r*(1-r)*j0))
ck('small_v_full_determinant',Mu.det()-U*e*(1+U)**2*(e+r)**2/(8*r*(1-r)*j0))
ck('small_u_second_minor',Mv[:2,:2].det()-(e+r)*(V*e+V*r+e)*(V*e+V*r-V+e)/(4*r*(1-r)*j0))
ck('small_u_full_determinant',Mv.det()-V*(1+V)*(e+r)**2/(8*r*(1-r)*j0))
targets_u=[U*e*e*(1+U)/(4*(e-1)),U*(1+U)**2*(e+1)/4,U*(1+U)**2/(4*r),U*(1+U)/2]
targets_v=[V*e/(4*(e-1)),V*(e+1)/(4*e),V*(1+V)/(4*r*(1-r)),V/2]
for tag,f,targets,scale in [('small_v',fu,targets_u,1+U),('small_u',fv,targets_v,1)]:
    forms=[
        ('r_zero',f(e/2,0,1/(2*(e-1))).subs(Y,0),(p,R)),
        ('r_one',f(0,e/2,1/(2*e)).subs(Y,p),(p,R)),
        ('j_zero',f(1/(2*(1-r)),(1-r)/(2*r),0).subs(p,Y+scale*R),(Y,R)),
        ('double_opening',f(s.Rational(1,2),0,0).subs({Y:0,p:scale*R}),(R,))]
    for (name,f0,vs),target in zip(forms,targets):
        ck(tag+'_'+name,gram(f0,vs).det()-target)

# The weak-alpha repair is an exact root identity, independent of source rates.
aa,bb,ell,Vh,ys=s.symbols('aa bb ell Vh ys')
R0=bb*X+aa*(Z-ell)
repair=v*(Z-ell)-aa*v*R0+bb*bb*v*ell+bb*v*(aa*X-bb*Z)
ck('weak_alpha_negative_term_repair',s.expand(repair).subs(aa*aa,1-bb*bb))
ck('literal_affine_double_axis',core.subs({u:0,v:0})-X*X-Y*Y)

result={'status':'all_exact_checks_passed','count':len(checks),'checks':checks,
 'scope':'C1 x infinitesimal, zeta noninfinitesimal, L=x*zeta infinitesimal, eta bounded: exact source alternatives and full-parent remote complement. The both-infinitesimal testing chart is not admitted.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'count':len(checks)}))
