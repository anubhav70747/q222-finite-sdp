"""Exact symbolic receipts for the R17 spectral-frame reduction."""
import json
from pathlib import Path
import sympy as sp

checks = []
q = sp.symbols('p0:10')
P = sp.Matrix([[q[0],q[1],q[2],q[3]],
               [q[1],q[4],q[5],q[6]],
               [q[2],q[5],q[7],q[8]],
               [q[3],q[6],q[8],q[9]]])
coeff = P.charpoly().all_coeffs()
e1,e2,e3,e4 = -coeff[1],coeff[2],-coeff[3],coeff[4]
S = P*P-e1*P+e2*sp.eye(4)
assert all(sp.expand(k)==0 for k in e3*P-P*S*P-e4*sp.eye(4))
checks.append('Generic symmetric 4x4 Cayley-Hamilton quadratic identity')

l1,l2,l3 = sp.symbols('l1 l2 l3', positive=True)
D=sp.diag(l1,l2,l3,0)
S0=D*D-(l1+l2+l3)*D+(l1*l2+l1*l3+l2*l3)*sp.eye(4)
assert all(sp.expand(k)==0 for k in
           S0-sp.diag(l2*l3,l1*l3,l1*l2,l1*l2+l1*l3+l2*l3))
checks.append('Rank-three residue spectral matrix eigenvalues')

s,t,v,eps=sp.symbols('s t v eps')
A=1+s*s*t*t
c=eps*eps*((t-s)**2+(v-s)**2)
P0=sp.diag(A,1,1,c)
r=[eps*(t-s),eps*s*t*(t-s),eps*(v-s),eps*s*t*(v-s)]
assert sp.expand(P0.det()-sum(k*k for k in r))==0
checks.append('Explicit four determinant roots for weak-scale example')
f4=c
assert f4.subs({t:s,v:s})==0
assert sp.diff(f4,t).subs({t:s,v:s})==0
assert sp.diff(f4,v).subs({t:s,v:s})==0
assert sp.hessian(f4,(t,v))==2*eps**2*sp.eye(2)
checks.append('Isolated contact, two exact zero jets, positive angular Hessian')
assert sp.expand(-P0.charpoly().all_coeffs()[3]-A-c*(1+2*A))==0
checks.append('Spectral scalar e3 for the weak-scale example')

out={'status':'PASS','checks':checks,
     'scope':'Algebraic identities only; nonunit and valuation arguments are proved in matrix_mechanism.tex.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
