#!/usr/bin/env python3
"""Exact local identities for chart-free C2 entry; no numerical samples."""
if not __debug__:
    raise SystemExit("Run without -O: assertions are exact checks.")
from pathlib import Path
import json
import sympy as s

checks = []
def zero(name, expr):
    if isinstance(expr, s.MatrixBase):
        assert all(s.cancel(x) == 0 for x in expr), name
    else:
        assert s.cancel(expr) == 0, name
    checks.append(name)

u,v,W,X,Y,Z = s.symbols("u v W X Y Z")
du,dv = 1+u*u,1+v*v
rm = v*W-X+u*v*Y-u*Z
rd = u*W+u*v*X-Y-v*Z
H = 2*(rd**2+du*(v*Y-Z)**2+dv*(X+u*Z)**2-du*dv*Z**2)
M = s.hessian(H,(W,X,Y,Z))/2
L = du*dv
J = s.Matrix([[0,0,0,1],[0,0,-1,0],[0,-1,0,0],[1,0,0,0]])
zero("core matrix square", (M-L*s.eye(4))**2-L**2*s.eye(4)-4*u*v*L*J)
zero("core involution", J**2-s.eye(4))
zero("square-root bound comparison", (L+2*u*v)**2-(L**2+4*u*v*L)-4*u*u*v*v)

x,y,q = s.symbols("x y q")
sub = {W:1,X:u*x,Y:u*y,v:u*q}
scaled = s.cancel(H.subs(sub, simultaneous=True)/u**2)
formula = 2*((1-y-q*Z+u*u*q*x)**2+(1+u*u*q*q)*(x+Z)**2
             +(1+u*u)*(u*u*q*q*y*y-2*q*y*Z-q*q*Z*Z))
zero("complete scaled core",scaled-formula)
pt = {u:0,x:0,y:0,Z:1,q:1}
zero("scaled core at limiting contact", scaled.subs(pt))
ell = s.Matrix([x,y,q-x+u*u*q*y-Z,1+u*u*q*x-y-q*Z])
vars = [x,y,Z,q]
Jac = ell.jacobian(vars).subs(pt)
zero("small-angle normal determinant",Jac.det()-2)
grad = s.Matrix([s.diff(scaled,z).subs(pt) for z in vars])
zero("small-angle normal core gradient",Jac.T*s.Matrix([2,-2,-2,2])-grad)
# At the limiting contact, the square-root normalization equals one and
# its derivatives multiply x or y, hence do not change this Jacobian.
norm = (1+u*u)*(1+u*u*q*q)
zero("normalization at small-angle contact", norm.subs(pt)-1)

ordinary = {W:1,X:0,Y:0,Z:1,v:u}
raw = s.Matrix([X,Y,rm,rd])
Jord = raw.jacobian([X,Y,Z,v]).subs(ordinary)
Jord[0,:] = (1+u*u)*Jord[0,:]
Jord[1,:] = (1+u*u)*Jord[1,:]
zero("ordinary-angle normal determinant",Jord.det()-2*u*(1+u*u)**2)
gord = s.Matrix([s.diff(H,z).subs(ordinary) for z in [X,Y,Z,v]])
zero("ordinary-angle normal core gradient",Jord.T*(2*u*s.Matrix([1,-1,-1,1]))-gord)

a=v/u
b=a*W/Z
r=-X/(u*Z)
t=(u*W-Y)/(v*Z)
h=b-a*a*t
g=(1+u*u)*b-(1-r+a*a*u*u*t)
j=1+u*u*r-t
zero("fourth source gap",h-a*Y/(u*Z))
zero("second source gap",g-rm/(u*Z))
zero("fifth source gap",j+rd/(v*Z))
zero("alpha chart boundary",1-u*u*h-(Z-v*Y)/Z)
zero("D chart boundary",b-a*a*u*u*r-a*(W+v*X)/Z)

aa,zz,bb,rr,tt=s.symbols("aa zz bb rr tt")
hh=bb-aa*aa*tt
gg=(1+zz)*bb-(1-rr+aa*aa*zz*tt)
jj=1+zz*rr-tt
delta=((1+zz)*zz*bb**2+2*zz*(1+zz)*bb*rr+(1+zz)*(1+aa*aa*zz)*bb
       +zz**2*(1-aa*aa)*rr**2+2*zz*(1+aa*aa*zz)*rr+1+aa*aa*zz)
positive=(1+(1+zz)*bb+zz*(1+zz)*bb**2+2*zz*(1+zz)*bb*rr+zz**2*rr**2+2*zz*rr
          +aa*aa*zz*((1+zz)*bb+1+zz*rr*(2-rr)))
zero("positive source denominator",delta-positive)
N=(1+zz)*(bb+rr)*(bb+aa*aa*(1-tt))-aa*aa*(1+aa*aa*zz)*(1-rr)*tt
zero("positive source numerator",N-(1+zz)*(bb+rr)*hh-aa*aa*(gg+jj+rr*tt*(1+aa*aa*zz)))
minor=s.Matrix([[aa,1,aa*aa*zz],[-1-bb-zz*(rr+aa*aa*tt),zz*hh/aa,aa*zz*(rr-1+zz*hh)],
                [bb/aa+aa*zz*(hh-rr),zz*hh,(1+aa*aa*zz)*(1+zz*hh)+zz*(rr+aa*aa*tt)]])
zero("three-by-three source determinant",minor.det()-delta)

report={"status":"PASS","checks":checks,
        "scope":"Core bound identities, both normal-coordinate Jacobians and gradients, and exact source entry. Ordered-field deductions and inherited all-tests certificates are proved in the text, not numerically sampled."}
Path(__file__).with_name("check_contact_entry.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))
