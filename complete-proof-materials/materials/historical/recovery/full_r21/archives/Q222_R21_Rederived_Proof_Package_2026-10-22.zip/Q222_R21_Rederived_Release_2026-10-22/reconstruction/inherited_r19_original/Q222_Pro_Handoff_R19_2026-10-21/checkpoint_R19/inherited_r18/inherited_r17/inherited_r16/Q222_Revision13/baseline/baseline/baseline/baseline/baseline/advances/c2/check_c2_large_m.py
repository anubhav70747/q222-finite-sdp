#!/usr/bin/env python3
"""Exact full-parent identities for the r-unit, g-infinitesimal C2 extension."""
from pathlib import Path
import json, runpy
base=runpy.run_path(str(Path(__file__).with_name('check_c2_openings.py')))
s=base['s']; F=base['F'];u,v,W,X,Y,Z=[base[q] for q in ('u','v','W','X','Y','Z')]
x,k,b,h=[base[q] for q in ('x','k','b','h')]
nn,mm,CC,AA,DD,ee=[base[q] for q in ('nn','mm','CC','AA','DD','ee')]
du=1+u*u;dv=1+v*v;checks=[]
def eq(name,lhs,rhs=0):
 assert s.factor(lhs-rhs)==0,name
 checks.append(name)
def finite(name,E):
 E=s.cancel(E);den=s.denom(E)
 assert den.subs({G:0,x:0,h:0,u:0,v:0})!=0,(name,den)
 assert den.subs({G:0,x:0,h:b,u:0,v:0})!=0,(name,den)
 checks.append(name)
 return E
G,mg,n,tc,ta,cD,ca=s.symbols('G mg n tc ta cD ca')
eta=h/b;weights={nn:n,mm:mg/G,CC:tc/(x*(b-h)),AA:ta/(x*h),DD:x*cD,ee:x*ca}
Xg=v*(1+eta*u*u)*W-(1+G)*u*Z
graph={X:Xg,Y:eta*u*W}
M=base['M'];eq('entire m amplitude on contact graph',M.subs(graph,simultaneous=True),G*u*Z)
eq('exact triangular Y normal cancels m',s.diff(4*mm*M*M,Y)+u*v*s.diff(4*mm*M*M,X))
Fg=s.expand(F.subs(weights).subs(graph,simultaneous=True))
FX=s.expand(s.diff(F,X).subs(weights).subs(graph,simultaneous=True))
GY=s.expand((s.diff(F,Y)+u*v*s.diff(F,X)).subs(weights).subs(graph,simultaneous=True))
fww=Fg.coeff(W,2);fzz=Fg.coeff(Z,2);fwz=Fg.coeff(W).coeff(Z)
co=[x*(fww-fww.subs(u,0))/u**2,(fzz-fzz.subs(u,0))/u**2,
 fww.subs(u,0)/v**2,fzz.subs(u,0)/x,fwz/(u*v)]
lead={G:0,x:0,u:0,ta:tc}
want=[4*dv*tc/b,(4*n+2)*dv-2,(4*n+2)*dv,4*cD*v*v+4*ca,-2*(4*n+2)*dv]
for label,E,target in zip(('q','b','cbar','e','g'),co,want):
 E=finite('bounded entire large-m scalar '+label,E)
 eq('large-m scalar residue '+label,E.subs(lead,simultaneous=True),target)
finite('bounded full m-normal V coefficient',FX.coeff(W)/v)
finite('bounded full m-normal B coefficient',FX.coeff(Z)/u)
B2=8*dv*(ta*du-tc)/b
rem=s.expand(GY-u*W*B2/x)
ew=finite('bounded triangular Y residual ew',rem.coeff(W)/u)
ez=finite('bounded triangular Y residual ez',(rem.coeff(Z)-8*v*x*(cD-ca))/u**2)
eq('triangular Y constant',rem.coeff(Z).subs(u,0),8*v*x*(cD-ca))
eq('triangular Y leading',(B2+x*ew).subs(lead,simultaneous=True))
Hxx=s.diff(F,X,2)/2;Hxy=s.diff(F,X,Y)/2;Hyy=s.diff(F,Y,2)/2
eq('mixed triangular hard block cancels m',s.diff(Hxy+u*v*Hxx,mm))
eq('Y triangular hard block cancels m',s.diff(Hyy+2*u*v*Hxy+u*u*v*v*Hxx,mm))

# Exact five-term Laurent expression, and the stationary source substitution.
nu,Q,E0,E2,z,S=s.symbols('nu Q E0 E2 z S')
q=Q*(1+z);bs=2*nu*(1+z)-2;cs=2*z*nu*(1+z);d2=16*z*nu*nu*(1+z)**2;e=E2*z+E0
det=(q*S+cs)*(bs*S+e)-d2*S/4
L=2*Q*(nu-1)*S/z+2*Q*nu*S+2*nu*E2*z/S+2*nu*E0/S+Q*E0/z+Q*E2-4*nu
eq('five-term Laurent determinant',det/((1+z)*S*z),L)
delta0=(1+k*k)*(b+1)
src={nu:1/((1-b*b)*(1+k*k)),Q:2*k*k/(b*delta0),
 E0:2*k*k/delta0,E2:2*(b-k*k*(1-b))/(k*k*delta0)}
for label,E in [('value',L),('s derivative',s.diff(L,S)),('z derivative',s.diff(L,z))]:
 eq('large-m stationary Laurent '+label,E.subs({S:1,z:k*k}).subs(src,simultaneous=True))
a,d,e,t=s.symbols('a d e t')
exp=a*S/t+(d+e)*S+(a+e)*t/S+d/S+e/t-(2*a+2*d+3*e)
eq('five-term balanced decomposition',exp,a*(S/t+t/S-2)+d*(S+1/S-2)+e*(t/S+S+1/t-3))

# The corner graph uses bounded n, even when n=0 exactly.
Hc=4*mg/G+4*n+2;xi=(4*mg/G)/Hc;ze=(4*mg/G+2)/Hc
et=tc*h/(tc*h+ta*(b-h))
xiS,zeS,etS=s.symbols('xiS zeS etS')
corner_sub={xiS:s.cancel(xi),zeS:s.cancel(ze),etS:s.cancel(et)}
def corner_eval(E):
 return s.cancel(E).subs(corner_sub,simultaneous=True)
cornergraph={X:xiS*v*(1+etS*u*u)*W-zeS*u*Z,Y:etS*u*W}
corner=s.expand(F.subs(weights).subs(cornergraph,simultaneous=True))
eps=4*x*ca+4*n*ze
zz=corner_eval(corner.coeff(Z,2))
zzbase=4*x*ca+eps*u*u+4*n*ze*ze*u**4+4*x*cD*v*v
eq('corner entire Z coefficient at v zero',zz.subs(v,0),zzbase.subs(v,0))
Bb=finite('corner exact uv coquotient',(zz-zzbase)/(u*u*v*v))
eq('corner uv coefficient residue',Bb.subs({G:0,x:0,u:0,v:0,n:0},simultaneous=True),2)
wx=corner.coeff(W,2)
L=(1-etS)+xiS*v*v*(1+etS*u*u)
wx_formula=(4*n*du*dv*xiS**2+4*(mg/G)*(1-xiS)**2+2*dv*xiS**2)*v*v*(1+etS*u*u)**2
wx_formula+=4*tc*dv*u*u*(1-etS)**2/(x*(b-h))+4*ta*du*dv*etS**2*u*u/(x*h)
wx_formula+=(4*x*cD+2)*u*u*L**2+(4*x*ca+2)*du*etS**2*u*u*v*v
eq('corner entire W coefficient packet identity',wx,wx_formula)
finite('corner bounded m graph square',(mg/G)*(1-s.cancel(xi))**2)
qcorner=s.cancel(tc*(1-et)**2/(b-h)+ta*et**2/h)
eq('corner harmonic scalar identity',qcorner,tc*ta/(tc*h+ta*(b-h)))
eq('corner P residue',4*qcorner.subs(ta,tc),4*tc/b)
vcorner=(4*n+2)*xi**2+4*(mg/G)*(1-xi)**2
eq('corner V residue',s.cancel(vcorner).subs({G:0,n:0},simultaneous=True),2)
finite('corner WZ cross coefficient',corner_eval(corner.coeff(W).coeff(Z)/(u*v)))
CX=s.expand(s.diff(F,X).subs(weights).subs(cornergraph,simultaneous=True))
eq('corner exact X first normal at v zero',corner_eval(CX.coeff(Z).subs(v,0)),-8*n*ze*u**3)
finite('corner entire X first normal V',corner_eval(CX.coeff(W)/v))
finite('corner entire X first normal T',corner_eval((CX.coeff(Z)+8*n*zeS*u**3)/(u*v*v)))
CY=s.expand((s.diff(F,Y)+u*v*s.diff(F,X)).subs(weights).subs(cornergraph,simultaneous=True))
Bc=8*dv*(ta/(h)*et*du-tc/(b-h)*(1-et))
eq('corner large Y exact cancellation',Bc,8*dv*ta*et*u*u/h)
BcS=8*dv*(ta/(h)*etS*du-tc/(b-h)*(1-etS))
CYrem=s.expand(CY-u*W*BcS/x)
finite('corner whole triangular Y ew',corner_eval(CYrem.coeff(W)/u))
finite('corner whole triangular Y ez',corner_eval((CYrem.coeff(Z)-8*v*x*(cD-ca))/(u*u*v)))

data={'result':'PASS','number_of_checks':len(checks),'checks':checks,
 'scope':'g infinitesimal, r unit, k,b units, arbitrary positive h,b-h; full original normal coquotients and exact scalar identities. Does not cover r,g both infinitesimal.'}
target=Path(__file__).with_name('c2_large_m_checks.json');target.write_text(json.dumps(data,indent=2)+'\n')
print(json.dumps({'result':'PASS','number_of_checks':len(checks),'output':str(target)}))
