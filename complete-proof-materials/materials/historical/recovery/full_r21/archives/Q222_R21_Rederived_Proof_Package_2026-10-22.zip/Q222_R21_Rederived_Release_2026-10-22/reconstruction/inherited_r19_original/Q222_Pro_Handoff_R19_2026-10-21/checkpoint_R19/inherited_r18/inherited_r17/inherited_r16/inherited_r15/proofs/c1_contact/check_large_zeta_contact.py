"""New C1 all-local coupled certificate checks; reuse unchanged R14 source arrays."""
import sympy as s,json
from pathlib import Path
p=Path(__file__).resolve();base=p.parents[2]/'inherited_reference/check_large_zeta_R14.py'
ns={};exec(base.read_text().partition('\nlam=rho/(2*eta)')[0],ns)
checks=ns['checks'];reports=ns['reports'];ck=ns['zero'];audit=ns['audit']
for name in ['x','eta','zeta','r','pi','U','V','c','a','D','m','al','be','h','rho','j0','b','H0','gamma','B0','PY','PE','qU','cF','aUUV','aUVV','fB','fA','fC','fG','L','z']:
 globals()[name]=ns[name]
lam=fB-qU/(eta*zeta*x)
AE=s.expand(PE).coeff(U,1).coeff(V,0);BE=s.expand(PE).coeff(U,0).coeff(V,1);CE=s.expand(PE).coeff(U,1).coeff(V,1)
AY=s.expand(PY).coeff(U,1).coeff(V,0);BY=s.expand(PY).coeff(U,0).coeff(V,1);CY=s.expand(PY).coeff(U,1).coeff(V,1)
audit('new_lambda',lam,rho/(2*eta))
audit('new_d4',aUUV,rho/(2*j0))
audit('new_PE_U',AE,-rho*(1-r)/(eta*(j0+r)))
audit('new_PY_U',AY,rho/j0)
# Source-free reconstruction of the complete native parent, before weighting nu,xi.
u,w,E,nu,xi=s.symbols('u w E nu xi');aa=s.symbols('aa');v=u*w;UU=u*u;VV=v*v
W=(v+E)/(eta*u);Y=r*(v+E)/eta+b*E+nu;X=xi-h*u;Du=1+UU;Dv=1+VV
Rm=v*W-X+u*v*Y-u;Dr=u*W+u*v*X-Y-v
F=m*Rm**2+c/(1-r)*Dv*(u*W-Y)**2+a/r*Du*Dv*Y**2+(D+s.Rational(1,2))*Dr**2+(al+s.Rational(1,2))*Du*(v*Y-1)**2+B0*Dv*(X+u)**2-Du*Dv/2
mu=m-aa*aa*qU;Hu=aa*VV/(eta*u)-u
Q=qU*(Hu+aa*w*E/eta-aa*xi)**2;sing=mu*(w*E/eta-xi)**2
R=s.Poly(s.cancel(F-Q-sing),E,nu,xi)
polPE=PE.subs({U:UU,V:VV});polPY=PY.subs({U:UU,V:VV})
ck('complete_E_normal',R.coeff_monomial(E)-(2*mu*v*w*w/eta**2+v*(polPE+2*aa*qU/eta)))
ck('complete_Y_normal',R.coeff_monomial(nu)-v*polPY)
KX=(1-h)*(m+B0)-aa*qU
x3=2*(B0*(1-h)-(D+s.Rational(1,2))+(D+s.Rational(1,2))*(1-r)/eta-m*r/eta)
x5=-2*h*(D+s.Rational(1,2))
ck('complete_X_normal',R.coeff_monomial(xi)-(2*KX*u-2*mu*u*w*w/eta+x3*u*VV+x5*u*UU*VV))
for i,z1 in enumerate((E,nu,xi)):
 for j,z2 in enumerate((E,nu,xi)):
  if j<i:continue
  pol=s.Poly(s.expand(R.coeff_monomial(z1*z2)),u,w)
  bad=[(mon,co) for mon,co in pol.terms() if mon[0]<mon[1] or min(mon)<0]
  assert not bad,(i,j,bad)
  checks['hard_no_testing_ratio_'+str(i)+str(j)]=True
  # Unweighted source-reference residue; weighting gives diag(gamma,1,1).
  corner={aa:0,h:1,m:0,al:0,c:rho/2,a:eta/2,D:1/(2*j0),u:0}
  val=s.factor(R.coeff_monomial(z1*z2).subs(corner))
  expected=0 if i!=j else [gamma,H0,B0][i]
  ck('hard_residue_'+str(i)+str(j),val-expected)
ck('joint_3by3_Schur',rho/(2*j0)-gamma*(1-r)**2-rho**2/(4*j0*j0*H0)-rho/(2*eta))
# Complete scalar contact identity, using exact value/jet balances.
k,cc,t,cf,dd,ee,ll=s.symbols('k cc t cf dd ee ll');vv=s.symbols('v');xx=k*k;yy=xx/(cc*cc)
At=u*vv;Bt=cc*k*vv*vv/u;Ct=xx/cc;G=k*vv;Fv=vv*vv-yy;RD=vv*(u*u-xx)
S=(cf*Fv**2+(ll-2*dd*xx-ee*yy+dd*u*u+ee*vv*vv)*At**2+ll*Bt**2+(ll+ee*yy)*Ct**2-(3*ll-dd*xx+ee*yy)*G**2)
ck('scalar_contact_completion',S-((cf+ee*xx)*Fv**2+ll*(At**2+Bt**2+Ct**2-3*G**2)+dd*RD**2+ee*vv*RD*Fv))
out={'status':'PASS','checks':checks,'count':len(checks),'source_reports':reports,'scope':'New full-parent all-local identities for C14.3a eta,j0 units, zeta unbounded. Uniform source-opening hard bounds use unchanged RO opening cancellations.'}
p.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print('FINAL',len(checks),flush=True)
