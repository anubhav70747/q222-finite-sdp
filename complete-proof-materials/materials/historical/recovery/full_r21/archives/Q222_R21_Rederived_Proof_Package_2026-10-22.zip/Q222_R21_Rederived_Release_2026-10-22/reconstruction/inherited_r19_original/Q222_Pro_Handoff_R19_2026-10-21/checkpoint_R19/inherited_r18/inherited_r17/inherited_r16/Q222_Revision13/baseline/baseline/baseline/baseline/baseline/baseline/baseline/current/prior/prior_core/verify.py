#!/usr/bin/env python3
"""Replay the small supplement's exact identities; no downloaded certificates."""
from pathlib import Path
import argparse,json,os,subprocess,sys,time
if not __debug__:
    raise SystemExit('Run without -O: exact checks use assertions.')
p=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument('--with-sympy',action='store_true',help='also check exact matching-budget and sharp-path formulas')
args=ap.parse_args()
jobs=['c1/check_native_contact.py','c1/check_analytical_lift.py','circuit/check_circuit_frame.py','cover/check_cycle_reduction.py']
if args.with_sympy:jobs.append('geometry/check_matching_budget.py')
reports=[]
for job in jobs:
    start=time.monotonic()
    env=os.environ.copy()
    env.pop('PYTHONOPTIMIZE',None)
    proc=subprocess.run([sys.executable,str(p/job)],cwd=p,env=env,text=True,capture_output=True)
    report={'script':job,'exit_code':proc.returncode,'seconds':round(time.monotonic()-start,3)}
    reports.append(report)
    print(('PASS ' if proc.returncode==0 else 'FAIL ')+job,flush=True)
    if proc.returncode:
        print(proc.stdout);print(proc.stderr,file=sys.stderr)
        break
out={'status':'PASS' if len(reports)==len(jobs) and all(r['exit_code']==0 for r in reports) else 'FAIL',
     'with_sympy':args.with_sympy,'suites':reports,
     'scope':'New analytical identities and exact source checks only; no replay or closure of the global atlas.'}
(p/'verification/FRESH_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
raise SystemExit(0 if out['status']=='PASS' else 1)
