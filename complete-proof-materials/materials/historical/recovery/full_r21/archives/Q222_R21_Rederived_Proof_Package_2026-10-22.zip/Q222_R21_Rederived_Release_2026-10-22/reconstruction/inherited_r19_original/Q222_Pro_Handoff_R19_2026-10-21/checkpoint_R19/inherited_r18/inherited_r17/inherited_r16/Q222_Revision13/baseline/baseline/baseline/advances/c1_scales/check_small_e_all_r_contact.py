"""Exact finite full-normal and conductor residue check for SE1--SE11.

The full rational tail is justified in small_e_all_r_contact.tex, SE5--SE8;
this checker verifies the displayed finite collection, not that tail alone.
"""
from pathlib import Path
import json,sys
import sympy as s
from sympy.polys.domains import QQ
EE,LL,TT=s.symbols('E ell tau');dom=QQ.frac_field(EE,LL,TT)
CAP=14 if '--tail-check' in sys.argv else 10;WT=(1,1,2,1,3,5,3);DIM=len(WT)
def wt(m):return sum(a*b for a,b in zip(m,WT))
class P:
 def __init__(self,d):self.d={m:dom.convert(c) for m,c in d.items() if c and wt(m)<=CAP}
 def lift(self,q):return q if isinstance(q,P) else P({(0,)*DIM:q})
 def __add__(self,q):
  q=self.lift(q);o=dict(self.d)
  for m,c in q.d.items():o[m]=o.get(m,dom.zero)+c
  return P(o)
 __radd__=__add__
 def __neg__(self):return P({m:-c for m,c in self.d.items()})
 def __sub__(self,q):return self+-self.lift(q)
 def __rsub__(self,q):return self.lift(q)+-self
 def __mul__(self,q):
  q=self.lift(q);o={}
  for m,c in self.d.items():
   for n,b in q.d.items():
    v=tuple(x+y for x,y in zip(m,n))
    if wt(v)<=CAP:o[v]=o.get(v,dom.zero)+c*b
  return P(o)
 __rmul__=__mul__
 def __pow__(self,n):
  if n<0:return self.inv()**(-n)
  o=self.lift(1)
  for _ in range(n):o=o*self
  return o
 def inv(self):
  leading={m:c for m,c in self.d.items() if wt(m)==0}
  assert len(leading)==1,leading
  (m,c),=leading.items();base=P({tuple(-x for x in m):1/c})
  assert not any(m)
  h=self*base-1;o=self.lift(1);power=self.lift(1)
  for j in range(1,CAP+1):power=power*(-h);o=o+power
  result=base*o
  assert not (self*result-1).d
  return result
 def __truediv__(self,q):return self*self.lift(q).inv()
 def __rtruediv__(self,q):return self.lift(q)*self.inv()
def var(i):return P({tuple(int(i==j) for j in range(DIM)):1})
eps,hc,u,w,v,N,M=map(var,range(DIM));E=P({(0,)*DIM:EE});ell=P({(0,)*DIM:LL});tau=P({(0,)*DIM:TT})
k=eps*hc;t=eps*eps*tau
K=1+k*k;Q=K*K-ell*k*k;a=(K-ell)/E
eta=K*E/Q;r=ell/Q;e2=eps*eps*K*K/(Q*Q)
zeta=hc*hc*Q*E/K
R=K*K/Q;T=K-k*k*t*zeta
H=r+eta;Vc=k*k*eta*zeta;Qc=1-k*k*zeta+a*Vc
P4=1+k*k+eta*k*k*(a-k*k-1)-zeta*k*k*t
P4+=Vc*(-zeta*k*k*t*t+2*k*k*t+a*(1-t)+t)
Pa=1+k*k-a*eta*k*k+zeta*((1+k*k)-(2+k*k)*t)
Pa+=Vc*(-zeta*t*t+a*(t-1)+t)
Pd=K*K-a*eta*k**4+zeta*k*k*(K-(2+k*k)*t)
Pd+=Vc*(-zeta*k*k*t*t+k*k*a*(t-1)+k*k*t+K)
c2=2*K*(1-t*zeta)*(1+Vc)*H*Qc/Q
cb=2*K*(1+(1-t)*zeta)*H*Qc/Q
c3=2*K*H*Qc*(1-k*k*eta+t*Vc)/Q
c5=2*K*H*Qc*(1+Vc)/Q
c4=2*Qc*P4;ca=2*H*Pa/Q;cd=4*Qc*Pd/Q
# G divided by pure coefficient a: no inverse a survives.
B2=8*c2*e2/(R*c3);Bb=8*cb*e2/(R*c3)
B3=8/T;B5=8*c5/(T*c3)
Ar=2*eta*eta*c4/(Q*c3)
bell_d=2*eta*cd/c3
alpha=2*eps**4*hc**6*Q*Q*eta*eta*ca/(K*K*c3)
Astar=Ar*H/(1+r*H)
Du=1+u*u;Dv=1+v*v;p=t/R;hh=a/T
qA=v*Du*w;qB=v*(Du-u*N-p*u*Du*v*w)
W=w+u*(M+hh*qB)/Du;Y=u*w-(M+hh*qB)/Du
center=Y-r*u*W
G=B2*(N*N-2*qA*N+(1-p)*qA*qA)
G+=Bb*Dv*(N*N+2*qA*N+p*qA*qA)
G+=B3*Dv*(M*M+2*qB*M+hh*qB*qB)
G+=B5*(M*M-2*qB*M+(1-hh)*qB*qB)
G+=4*Astar*Du*Dv*center*center
G+=4*Ar*Du*Dv*(2*u*W*Y-r*u*u*W*W)
G+=4*alpha*Du*(v*Y-1)**2
G+=2*bell_d*Du*((v*Y-1)**2-Dv)
normal_mass=bell_d*(R-t)/R
G+=normal_mass*Dv*N*N
source_term_count=len(G.d)
checks=[]
def pick(n,m,maxwt=None):
 return P({ex[:5]+(0,0):c for ex,c in G.d.items() if ex[5:]==(n,m) and (maxwt is None or wt(ex)-5*n-3*m<=maxwt)})
parts={'scalar':pick(0,0),'N':pick(1,0,5),'M':pick(0,1,5),'NN':pick(2,0,0),'NM':pick(1,1,0),'MM':pick(0,2,0)}
zero=0*eps;one=zero+1
def eq(name,p,q):
 assert not (p-q).d,name
 checks.append(name)
def contact(p):
 o={}
 for m,c in p.d.items():
  ee,he,ue,we,ve,ne,me=m;n=(ee+ue+ve,he+ue+we+2*ve,0,0,0,ne,me)
  o[n]=o.get(n,dom.zero)+c*dom.convert(EE)**ve
 return P(o)
def deriv(p,i):return P({m[:i]+(m[i]-1,)+m[i+1:]:c*m[i] for m,c in p.d.items() if m[i]})
roots=(u-k,w-hc,v-eps*hc*hc*E)
cms=((1,1,0,0,0,0,0),(0,1,0,0,0,0,0),(1,2,0,0,0,0,0))
def monic(p):
 remainder=dict(p.d);qs=[]
 for i,cm in zip((2,3,4),cms):
  q={};nxt={}
  for m,c in remainder.items():
   n=m[i];base=list(m);base[i]=0
   final=tuple(x+n*y for x,y in zip(base,cm));coef=c*(dom.convert(EE)**n if i==4 else 1)
   nxt[final]=nxt.get(final,dom.zero)+coef
   for j in range(n):
    mm=list(base);mm[i]=n-1-j;mm=tuple(x+j*y for x,y in zip(mm,cm));coef=c*(dom.convert(EE)**j if i==4 else 1)
    q[mm]=q.get(mm,dom.zero)+coef
  qs.append(P(q));remainder={m:c for m,c in nxt.items() if c}
 rem=P(remainder);eq('monic',p,rem+sum((a*b for a,b in zip(roots,qs)),zero));return rem,qs
A=eps*w*v;B=v;C=E*u*w;D0=eps*eps*hc**3*E
x=B-C;y=A-k*C;z=u*B-k*C;hr=k*C-D0;rr=[x,y,z,hr]
q1square=A*(u*v)+(k*C)*D0-2*(k*C)*(k*B)
def conductor(p):
 rem,(Tu,Tw,Tv)=monic(p);assert not rem.d,('contact needed',rem.d)
 epart={};vpart={}
 for mon,c in Tw.d.items():
  if mon[0]:epart[(mon[0]-1,)+mon[1:]]=c
  else:
   assert mon[4],('uncovered conductor',mon,c)
   mm=list(mon);mm[4]-=1;vpart[tuple(mm)]=c
 Te=P(epart);Tvw=P(vpart)
 ans=[-u*Tu-eps*w*Te-E*k*w*w*Tvw-E*k*w*Tv,
      Te+E*hc*w*Tvw+hc*E*Tv,
      Tu+E*w*(w-hc)*Tvw+E*w*Tv]
 eq('conductor',C*p,sum((a*b for a,b in zip(rr,ans)),zero));return ans
def decompose(p,gs):
 mons=[next(iter(g.d.items())) for g in gs];out=[{} for g in gs]
 for m,c in p.d.items():
  for j,(n,cc) in enumerate(mons):
   if all(a>=b for a,b in zip(m,n)):
    mm=tuple(a-b for a,b in zip(m,n));out[j][mm]=c/cc;break
  else:raise AssertionError(('raw',m))
 qs=[P(q) for q in out];eq('raw',p,sum((q*g for q,g in zip(qs,gs)),zero));return qs
def linear(p):
 RA,RB,RC=decompose(p,[A,B,C]);S=k*RA+RB+RC
 eq('normal contact',contact(p),zero);ans=conductor(S);ans[0]+=RB;ans[1]+=RA
 eq('normal lift',p,sum((a*b for a,b in zip(rr,ans)),zero));return ans
def square(p):
 pairs=[(0,0),(1,1),(1,2),(2,2)];mons=[A,B,C]
 coeffs=decompose(p,[mons[i]*mons[j] for i,j in pairs]+[D0*D0]);rho=coeffs[-1];cs=[k,one,one]
 S=k*k*rho;HH=[zero,zero,zero,-2*k*rho];terms=[(3,3,rho)];idx=[1,0,None]
 for (i,j),f in zip(pairs,coeffs):
  S+=f*cs[i]*cs[j]
  if idx[i] is not None:HH[idx[i]]+=f*cs[j]
  if idx[j] is not None:HH[idx[j]]+=f*cs[i]
  if idx[i] is not None and idx[j] is not None:terms.append((idx[i],idx[j],f))
 eq('scalar contact',contact(p),zero)
 for i in (2,3,4):eq('scalar derivative',contact(deriv(p,i)),zero)
 lifted=conductor(S)
 for i in range(3):HH[i]+=lifted[i]
 rhoc=contact(rho);lam=2*k*rhoc;syz=[-2*k,one,one,-one];rem=[a-lam*b for a,b in zip(HH,syz)]
 assert all(not contact(a).d for a in rem)
 terms.append((1,2,-2*rhoc))
 for i,a in enumerate(rem):
  for j,b in enumerate(conductor(a)):terms.append((i,j,b))
 eq('scalar lift',p,sum((f*rr[i]*rr[j] for i,j,f in terms),zero)+2*rhoc*q1square)
 return terms,2*rhoc
terms,qcoef=square(parts['scalar']);linN=linear(parts['N']);linM=linear(parts['M'])
def residue(p):return s.factor(dom.to_sympy(p.d.get((0,)*DIM,dom.zero)))
Gram=s.zeros(4)
for i,j,f in terms:
 if i==j:Gram[i,j]+=residue(f)
 else:Gram[i,j]+=residue(f)/2;Gram[j,i]+=residue(f)/2
Gram=Gram.applyfunc(s.factor)
H0=EE+LL;VV=1+LL*H0
expected=s.Matrix([[8*(EE+2)/(H0*VV),0,0,0],[0,8,-8,0],[0,-8,8,0],[0,0,0,8]])
assert all(s.factor(z)==0 for z in Gram-expected)
assert residue(qcoef)==16
assert [residue(p) for p in linN]==[0,0,0]
assert s.factor(residue(linM[0])-16*EE*(H0+1)/(H0*VV))==0
assert [residue(p) for p in linM[1:]]==[0,0]
assert s.factor(residue(parts['NN'])-4*EE/H0)==0
assert residue(parts['NM'])==0
assert s.factor(residue(parts['MM'])-8*(EE**2+2*EE*LL+2*LL**2+2)/VV)==0
coupled=s.Matrix([[residue(parts['MM']),residue(linM[0])/2],[residue(linM[0])/2,Gram[0,0]]])
assert s.factor(coupled.det()-64*(EE**2+2*EE*LL+4*EE+4*LL)/(H0**2*VV))==0
checks.extend(['SE9 scalar residue','SE9 full N normal','SE9 full M normal','SE10 hard block','SE11 coupled determinant'])
for poly in [qcoef]+[f for i,j,f in terms]+linN+linM:
 assert all(all(e>=0 for e in mon) for mon in poly.d)
checks.append('no negative source/testing monomial exponents in lifted collection')
# Exact new conductor identity, independent of a truncation.
eu,jj,uu,ww,vv,EE2=s.symbols('eps j u w v E')
kk=eu*jj;CC=EE2*uu*ww;xx=vv-CC;yy=eu*ww*vv-kk*CC;zz=uu*vv-kk*CC
assert s.expand(CC*vv*(ww-jj)-(EE2*ww*(ww-jj)*zz+EE2*jj*ww*yy-EE2*kk*ww**2*xx))==0
checks.append('SE6 exact division-free v conductor')
result={'status':'PASS','scope':'Finite complete scalar and first-normal collection from SE4; full-tail proof is SE5--SE8 in manuscript; no outer join checked here.',
 'weighted_cutoff':CAP,'source_terms':source_term_count,'checks':checks,
 'scalar_residue':str(Gram),'full_M_normal':str(residue(linM[0])),
 'hard_diagonal':[str(residue(parts['NN'])),str(residue(parts['MM']))],
 'coupled_determinant':str(s.factor(coupled.det()))}
if __name__=='__main__':
 dest=Path(__file__).with_name('small_e_all_r_conductor_tail_check.json' if CAP==14 else 'small_e_all_r_contact_checks.json')
 dest.write_text(json.dumps(result,indent=2)+'\n')
 print('PASS',len(checks),'checks; source terms',source_term_count)
