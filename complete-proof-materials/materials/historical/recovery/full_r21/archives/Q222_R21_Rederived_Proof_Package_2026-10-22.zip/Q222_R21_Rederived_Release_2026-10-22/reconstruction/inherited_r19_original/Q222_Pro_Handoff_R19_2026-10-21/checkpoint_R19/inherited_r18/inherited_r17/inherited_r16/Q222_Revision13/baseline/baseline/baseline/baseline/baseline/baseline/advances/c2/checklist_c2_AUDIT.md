# Scoped audit of the general single-angle C2 theorem

**Verdict: PASS for the displayed source domain, with its explicit physicality and inherited noncommuting-residue hypotheses. No mathematical correction is requested.**

This is a separate same-system reading audit of the revised `general_single_angle.tex`, including its balanced-cycle replacement of the logarithmic argument. I inspected the accompanying exact checker and its 44-check PASS report; I did not rerun that suite or perform a new source search. The following analytical checks are separate from the author's algebra receipt.

## Source and global scalar

The seven source residue formulas have the required scales: bounded nonnegative n, unit m, positive-unit xC and xA, and positive-unit D/x and alpha/x. All displayed source denominators are positive units after the explicit scale factors are removed. Positivity of n and physicality remain assumptions, rather than conclusions inferred merely from stationarity.

The scalar determinant has six positive Laurent coefficients, except that the s/t coefficient may vanish when n has zero residue. At the stationary zero, the balances are exactly

`a-c = d-b = f-e = tau`.

Both printed cycle decompositions have the correct signs. The s+1/s and t+1/t pairs retain strictly positive coefficients even when n has zero residue. Consequently their equality conditions force s=t=1; the cycle and remaining pair cannot introduce another zero. These same two pairs give a strict two-variable Hessian, while all other brackets have positive semidefinite Hessians at their zero. This proves global positivity, unique contact, and local nondegeneracy without extrapolating a local Hessian to remote tests.

The resulting strict cross-term capacity is used only away from the matched finite-angle residue. Its splitting function is pure testing: the parameters appearing in it are real residue constants. Its denominator has positive residue, including the separate zero-angle case when n has positive residue.

## Matched contact and both full normals

The three conductor identities and the displayed decomposition of f follow directly from p=uW, the monic invariant differences, and W=kappa(u-S). The Jacobian of (R,S) at contact has determinant -2. It is used to prove vanishing of coefficient evaluations; no inverse of rho or a mixed element is introduced into a Gram coefficient.

Monic division of the two scalar coefficient functions gives bounded products of R,S,U,T: invariant differences contribute bounded factors u,W,rho, and the v-k differences give RU or ST. The scalar restriction G0 supplies U squared by its exact double contact factor. The positive three-variable Hessian gives precisely the stated Schur inequality. I checked the zero identity

`T^2-U^2-S*T*(v-k)-kappa^(-1)*R*U*(v-k)=0`.

Its added coefficient splits the positive angular reserve between the (R,U) and (S,T) blocks; its remaining coefficients contain v-k and have zero residue.

The full X-normal uses the exact decomposition `-kappa*B1*S + u*(A1+kappa*B1)`. The contact-zero second coefficient and monic invariant differences produce only bounded coefficients with factors u*rho, u squared, or uW; the v-k quotient has zero leading function. The Y-normal decomposition `R*B2 + rho*E2` has the same property. Thus the proof restores both full first normals, not only their restrictions or Hessians. The two hard pivots are strictly positive.

## Zero-zero corner, including literal n=0

The reserve epsilon is positive because alpha/x is a positive unit. Both n/epsilon and x/epsilon are bounded by its positive summands. I checked directly the coefficient of Z squared at v=0:

`4 alpha + epsilon*u^2 + 4 n*zeta^2*u^4`.

The remaining u squared v squared coefficient has residue 2. Thus the five scalar roots have all five printed positive pivots even if n=0 exactly.

I also checked the full X-normal at v=0: its Z coefficient is exactly `-8 n*zeta*u^3`. The coefficient on the scaled root is bounded and infinitesimal because `n/sqrt(epsilon)=(n/epsilon)*sqrt(epsilon)`. The remaining Z term has the stated u*v squared factor. For the Y-normal, cancellation of the large packets leaves the printed u squared v remainder and `8v(D-alpha)` constant part. There is no division by n, u, or v, and literal n=0 loses no required root.

## Outer charts and restoration

The four displayed core identities use the original signed core and retain all unused nonnegative packets. Their selected C and A coefficients are xC and xA; the reciprocal-Bob pivot uses D/x. The finite-unit Alice formula uses only a pure testing unit inverse. The other endpoint formulas admit their homogeneous literal endpoints without any testing infinitesimal inverse.

Their pivots remain positive for every stated endpoint overlap. A root may vanish identically at a literal endpoint; strictness of the coefficient Gram does not require the root map to be injective. No omitted state-ray case is needed for these outer identities. Together with the full finite u=0 axis analysis, these cases exhaust commuting testing residues. The noncommuting join uses exactly the physical-source theorem retained in the hypotheses, and all positive pure factors and retained event packets are restored.

The result is therefore a genuine all-tests theorem for this bounded-shape single-angle source family, including n=0 and its reflected orientation. It is not an exhaustive classification of one-weak C2 sources, and it does not remove the stated shape-unit or source-physicality hypotheses.
