"""Exact source identities and full-parent stationary witness; no sampling."""
from pathlib import Path
import json
import sympy as s
z,a2,b,r,h=s.symbols('z a2 b r h')
t=(b-h)/a2
g=b-1+r+z*h
j=1+z*r-t
ac=1+z*r;sc=ac+a2*z*t
de=(1+z)*z*b*b+2*z*(1+z)*b*r+(1+z)*(1+a2*z)*b+z*z*(1-a2)*r*r+2*z*(1+a2*z)*r+1+a2*z
ns=(1+z)*(b+r)*(b+a2*(1-t))-a2*(1+a2*z)*(1-r)*t
checks=[]
def eq(name,lhs,rhs=0):
 assert s.cancel(lhs-rhs)==0,name
 checks.append(name)
eq('positive N identity',ns,(1+z)*(b+r)*h+a2*(g+j+r*t*(1+a2*z)))
eq('n numerator r-one obstruction',((b+r)*ac*sc-r*de).subs(r,1),-z*(a2+h)*(b+1)*(z+1))
u,v,W,X,Y,Z,k=s.symbols('u v W X Y Z k')
x=k*k
weights={
 'n':(8-5*x*x)/(16*(1+x)**2),
 'm':3*x*x*(3*x+4)/(16*(1+x)*(4+x-2*x*x)),
 'C':(4-x)/(8*x),'alpha':(4-x)/(8*x),
 'A':x*(x+4)*(3*x+4)/(32*(2-x)*(1+x)**2),
 'D':(2-x)*(3*x+4)/(16*x*(1+x))}
n,m,C,alpha,A,D=[weights[f] for f in ['n','m','C','alpha','A','D']]
Du=1+u*u;Dv=1+v*v
M=v*W-X+u*v*Y-u*Z;J=u*W+u*v*X-Y-v*Z
core=2*(J*J+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z*Z)
F=core+4*n*Du*Dv*X*X+4*m*M*M+4*C*Dv*(u*W-Y)**2+4*A*Du*Dv*Y*Y+4*D*J*J+4*alpha*Du*(v*Y-Z)**2
contact={u:k,v:k,W:1,X:-k**3/4,Y:k*(1-x/2),Z:x}
eq('physical witness exact full parent contact',F.subs(contact,simultaneous=True))
for q in [u,v,W,X,Y,Z]:
 eq('physical witness full derivative '+str(q),s.diff(F,q).subs(contact,simultaneous=True))
for label,expr,want in [('n',n,s.Rational(1,2)),('m/x^2',m/x**2,s.Rational(3,16)),('A/x',A/x,s.Rational(1,4)),('xC',x*C,s.Rational(1,2)),('xalpha',x*alpha,s.Rational(1,2)),('xD',x*D,s.Rational(1,2))]:
 eq('witness residue '+label,s.cancel(expr).subs(k,0),want)
out={'status':'PASS','count':len(checks),'checks':checks,'scope':'Two exact angle-reduction identities and one full-parent rational stationary family. Ordered-field source exclusions and physicality use the printed proofs, not these finite checks.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
