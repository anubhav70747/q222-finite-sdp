# Adversarial audit: ordinary-angle C1 source

Reviewed `ordinary_angle.tex`, the native contact identities in
`prior_core/c1/source_definitions.tex`, and the accompanying exact checker.
Result: **no substantive gap found**. The result has precisely the regular
ordinary-angle, comparable-state-ratio source scope stated in (OA1); it does
not establish an exhaustive C1 source cover.

## Exact parent and reciprocal endpoint

The reduction (OA5) retains the full original parent. In particular, the
last signed contribution is

\[
2dD_u\bigl(v^2Y^2-2vYZ-v^2Z^2\bigr),
\]

not merely its bilinear term. Its remaining terms fit the proposed bounded
Gram, with zero-residue coefficients after extracting the displayed
leading terms.

For the reciprocal Alice chart, put
\(h=1/u\), \(x'=hX+Z\), and \(y'=W-hY\). The exact identities

\[
W=y'+hY,\qquad Z=x'-hX
\]

turn the two nontrivial strong currents in \(h^2F\) into

\[
v[(1+h^2)Y+h y']-x',\qquad
y'+v[(1+h^2)X-hx'].
\]

Thus the four strong roots at residue are exactly the ones stated in the
text. The weak reserves are \(\eta Y\) and \(\eta hX\). The potentially
dangerous core bilinear term is exactly

\[
-4d(1+h^2)(vY)x'
+4(d/\eta)(1+h^2)h(vX)(\eta Y).
\]

Both coefficients have zero residue. The other core and weak-packet
monomials also admit allocations to the six stated roots with an extra
factor among \(\eta,h,v\). No division by \(h\), a mixed element, or
\(v/\eta\) occurs. At the literal endpoint one uses the homogeneous
parent directly; one does not invert the zero projective multiplier.

## Weighted contact division

Before and after translating the three normal coordinates by their exact
source contacts, the polynomial lies in

\[
(N_1,N_2,N_3)^2+\eta(N_1,N_2,N_3)+(\eta^2).
\]

Consequently its constant-normal coefficient is \(\eta^2 C(U,B)\), and
each linear-normal coefficient is \(\eta L_i(U,B)\), with bounded
polynomial coefficients. Exact value and first-derivative identities imply
\(C(0,0)=C_U(0,0)=C_B(0,0)=0\) and \(L_i(0,0)=0\).
Cancelling the nonzero pure coefficient \(\eta\) proves these vanishing
identities; it is not used to construct a mixed quotient.

Monic Taylor division therefore gives bounded coefficients in

\[
C\in(U,B)^2,\qquad L_i\in(U,B),
\]

and hence an exact Gram on
\((N_1,N_2,N_3,\eta U,\eta B)\). Higher-order terms leave an additional
infinitesimal deviation or a zero-residue source coefficient. This justifies
the stated weighted-Hessian residue even when the actual ratios
\(v/\eta,x/\eta,y/\eta\) are unbounded. The half-Hessian's positive
leading principal minors are as printed in (OA16).

## Exhaustion of independent tests

Normalize both projective angle pairs and the state in the testing field.
When the homogeneous Bob sine has nonzero residue, the four strong
packet amplitudes have no common nonzero state kernel at any projective
Alice angle. The resulting strict residue matrix absorbs the bounded
infinitesimal signed core. This includes the reciprocal Bob endpoint.

The remaining Bob-small chart is exhausted by ordinary Alice residue,
the Alice-zero endpoint, and the reciprocal Alice endpoint. At the
matched ordinary Alice residue, the exact relation (OA13) supplies the
extra strict direction when its coefficient has nonzero residue. If that
coefficient vanishes in residue, the strong kernel makes \(Z\) a unit,
and the two state residues are \(W=\pm s\). The negative branch has
nonnegative pure-testing core by the cited exact Schur calculation; the
positive branch is precisely the five-root contact chart. Literal axes
are direct nonnegative-core exits. Thus no state or angle chart is omitted
within the theorem's source assumptions.

## Verification and scope

Re-ran `check_ordinary_angle.py`: **38 exact checks passed**, including
the original-parent identity, both endpoint allocations, all six native
contact balances, capacity factorization, and Hessian identities. The
finite Taylor argument and the chart exhaustion above were checked
separately rather than inferred from these identities.

The theorem genuinely covers the former example
\(k=s=1,a=t=1/2,\eta>0\) infinitesimal. It requires all of
\(k,s,a,t,M,J\) to remain positive units, as explicitly stated.
