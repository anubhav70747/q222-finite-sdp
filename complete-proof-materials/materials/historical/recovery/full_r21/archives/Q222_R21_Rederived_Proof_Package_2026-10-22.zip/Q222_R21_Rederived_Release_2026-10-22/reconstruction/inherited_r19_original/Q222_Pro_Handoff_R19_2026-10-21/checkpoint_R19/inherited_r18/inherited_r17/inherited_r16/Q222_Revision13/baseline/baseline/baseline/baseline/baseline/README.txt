Q222 analytical checklist continuation — 18 October 2026

Read Q222_Checklist_Proof_2026-10-18.pdf first. The root CHECKLIST.json and
PROOF_STATUS.json are authoritative. The complete preceding package is
preserved unchanged under baseline/.

Four new all-tests admissions are proved on their exact stated domains:
1. C1 unit eta,r with unbounded e and infinitesimal k,zeta.
2. C2 three collapsing openings, including unbounded n.
3. C2 last opening with unbounded m when r is a unit.
4. C2 pitchfork with arbitrary n,m,A,D and unit d,C,alpha.
There is also a short analytical exclusion of b infinitesimal in the stated
rational C2 entry. The intermediate two-large theorem is included because
its formulas make the strongest pitchfork proof easier to follow.

The global atlas-free proof is UNFINISHED. Read the precise remaining
source complements and full-parent obligations in the checklist. The
frontier notes contain useful local reductions and unproved continuation
routes; they are not additional all-tests admissions. The historical
computer-assisted global package is retained, not newly rerun or globally
reaudited. No evaluated affine SDP pencil is supplied.

Reproduction:
  python3 verify.py
  python3 verify.py --with-sympy   (requires SymPy)
  python3 verify.py --integrity-only
The new checkers confirm 145 distinct exact identities; the g-opening
checker imports 33 opening checks, counted only once. These checkers are
optional corroboration, not numerical positivity premises. Separate-agent
reviews are same-system reviews, not external peer review or formal proofs.

To rebuild the manuscript, run pdflatex twice on the root .tex file with
a standard TeX Live installation (amsmath, lmodern, microtype, TikZ,
hyperref, xurl). Typesetting-only line breaks and tag placement may differ
from the authors' frozen analysis copies; mathematical expressions agree.

The archive manifest covers every distributed file except MANIFEST.json.
Verification runs checkers in a temporary copy, leaving archived receipts
and their hashes untouched. Baseline integrity is separately recorded.
