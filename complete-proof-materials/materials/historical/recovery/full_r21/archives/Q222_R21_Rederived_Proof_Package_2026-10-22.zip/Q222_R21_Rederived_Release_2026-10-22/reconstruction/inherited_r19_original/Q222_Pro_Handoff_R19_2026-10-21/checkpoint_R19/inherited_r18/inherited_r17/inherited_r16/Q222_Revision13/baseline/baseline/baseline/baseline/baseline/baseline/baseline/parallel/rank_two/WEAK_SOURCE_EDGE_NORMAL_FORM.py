#!/usr/bin/env python3
"""Exact symbolic weak-source edge normal form; SymPy only."""
from pathlib import Path
import json
import sympy as s
u,v,W,X,Y,Z,n,m,c,A,D,alpha,d=s.symbols('u v W X Y Z n m c A D alpha d')
Du,Dv=1+u*u,1+v*v
F=4*n*Du*Dv*X*X+4*m*(v*W-X+u*v*Y-u*Z)**2
F+=4*c*Dv*(u*W-Y)**2+4*A*Du*Dv*Y*Y
F+=(4*D+2*d)*(u*W+u*v*X-Y-v*Z)**2
F+=(4*alpha+2*d)*Du*(v*Y-Z)**2+2*d*Dv*(X+u*Z)**2-2*d*Du*Dv*Z*Z
energy=4*(D+alpha)+(4*alpha-8*D-2*d)*u*u+(4*D+8*c+2*d)*u**4
assert s.expand(F.subs({v:1,W:u,X:0,Y:0,Z:1})-energy)==0
edge=4*m*(v*W-X)**2+(4*n+2*d)*Dv*X*X
edge+=(4*(c+A)+2*d)*Dv*Y*Y+4*D*(Y+v*Z)**2+4*alpha*(v*Y-Z)**2
assert s.expand(F.subs(u,0)-edge)==0
poly=s.Poly(s.expand(F.subs({m:0,W:1})),X,Y,Z,u)
jet=s.Add(*(coef*s.prod(z**e for z,e in zip([X,Y,Z,u],mon))
            for mon,coef in poly.terms() if sum(mon)==2))
k=4*D+2*d;g=4*c*Dv+k
expected=(4*n+2*d)*Dv*X*X+(4*(c+A)+2*d)*Dv*Y*Y
expected+=4*D*(Y+v*Z)**2+4*alpha*(v*Y-Z)**2+g*u*u-2*g*u*Y-2*k*v*u*Z
assert s.expand(jet-expected)==0
receipt={'status':'PASS','arithmetic':'exact symbolic polynomial identities',
 'checks':['exact source opening-floor test energy','exact commuting edge energy',
           'full four-normal univariate matrix jet'],
 'proved_floor':'D+alpha>=d**2/(36*rho)',
 'remaining':'bounded weighted contact division for weak m and source u_c; source corners and d-weak regimes not treated'}
Path(__file__).with_name('WEAK_SOURCE_EDGE_CHECK_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
