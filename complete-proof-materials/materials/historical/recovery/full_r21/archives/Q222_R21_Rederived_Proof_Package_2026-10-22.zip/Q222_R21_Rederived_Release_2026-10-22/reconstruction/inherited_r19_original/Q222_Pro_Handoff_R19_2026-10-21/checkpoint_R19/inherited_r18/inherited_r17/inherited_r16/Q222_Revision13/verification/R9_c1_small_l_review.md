# Same-system independent review: small-L C1 extension

## Final status

- Generic three-circuit lemma: **PASS**.
- Source-specific bounded-ratio scalar and complete normal arrays: **PASS**.
- Source-specific unbounded-ratio full-parent certificate: **PASS**.
- New source-domain closure: **PASS within (IC1), with the explicitly identified inherited remote theorem**.

This review does not rerun or recertify the inherited global suite. It concerns the proposed revision-9 extension only.

## Generic three-circuit lemma

Reviewed `work_r9/three_circuit/three_circuit_lift.tex` and its short exact checker. The mathematical identities, rather than the checker receipt, support the following conclusions.

1. For the displayed positive separated monomials, `A1 A2 A3=G^3`. The two conductors `G(u-k)=k d1` and `G(t-s)=s d2` hold exactly.

2. The cube roots of each positive separated monomial remain separated products of pure source and pure testing roots. Their product equals `G`. The elementary three-cube identity therefore gives the displayed nine-square formula for `Q=G sum(d_i)`. The identity `L=sum(d_i^2)+2Q` supplies a strict constant diagonal Gram on the combined root list.

3. Expanding `A_i=G+d_i` and the supplied finite coefficient decompositions gives the printed scalar error identity. The two source jet identities cancel precisely the remaining first-order terms proportional to `G d1,G d2`. No inverse of `G` is used in the proof. Its appearance in the optional symbolic check is only a rational identity check.

4. Every correction coefficient is infinitesimal under the stated array assumptions. The distinction between the two coordinates is necessary and correct: bounded `K_iu,H_uu,H_ut,H_tu` acquire small factors `k` or `k^2`, whereas the t-coordinate conductor has unit factor `s`, so `K_it,H_tt` must already be infinitesimal. The statement does not infer this from scalar contact alone.

5. The normal extension is exact: subtracting `G` from each `A_i` leaves `G sum(c_i)`, and the finite contact decomposition converts this to `k J_u d1+s J_t d2`. The coefficient assumptions again make every resulting normal coupling infinitesimal. This can be appended to a genuinely strict full hard-normal block.

The generic lemma proves a finite tensor-SOS mechanism. It does not by itself establish the source-specific scalar coefficient decomposition, finite Taylor array bounds, hard-normal bounds, or all-testing coverage.

## Source-specific review

Reviewed `work_r9/c1_small/interior_closure.tex`, its exact checker source and the source denominator receipt, the earlier complete native normal identity in `work_r8/c1_small_l/native_reduction.tex`, and the inherited remote module at `recovered/Q222_Analytical_Revision_2026-10-18/advances/c1_lsmall_eta_bounded/remote_reduction.tex`. The checker receipt corroborates the identities; the following finite algebra and bounds are the proof basis. No old suite was rerun.

6. **Source entry and divisions.** On (IC1), beta nonnegativity first gives `theta=O(x)`, so `h` has residue one. The displayed native source gives `m/x`, `alpha/x^2` positive units, while `C,A,D` differ from the printed finite reference weights by `O(x)`. Every other original weight is bounded. Consequently infinitesimal total-normalized signed weight forces beta unbounded; the exact beta numerator then gives `theta=x*pi` with positive infinitesimal `pi`. The products `beta theta/x` and `beta theta^2/x^2` have the stated bounds. After these products cancel beta's opening denominator, the remaining source denominators are units. The numerators of the C,A,D differences, the two constant first-normal coefficients, and q_V vanish at x=0; their divisions by x are finite polynomial numerator divisions. The denominator receipt contains only the declared unit factors, including `eta+2r-1=j0+r`.

7. **The scalar is exact.** The decomposition (IC7)--(IC8) includes the original beta contribution and the source-negative quadratic base. I checked its structural allocation directly from the original graph: the m packet supplies the `V^2/U` term, its remaining terms enter c_F and the UVV coefficient, and all other terms enter the displayed affine coefficients. The nontrivial residue is consistent with the native first-order expansion `q_V/x -> -rho(2 zeta+3)/(2 eta)`, giving `f_G -> 3 rho/(2 eta)`. Thus the additional binomial has a positive unit coefficient and the remaining leading scalar is the asserted three-monomial circuit.

8. **Finite scalar arrays, including infinitesimal t.** f_A and f_C are affine in `U=u^2,V=u^2 t^2`; f_B and f_G are source-only. Their source slopes are bounded. Therefore (IC12)--(IC13) are exact finite identities with no negative t powers. The u-coordinate arrays are bounded, and every t-coordinate first array carries k^2; the second t array is k^2 times a bounded source slope. These satisfy the asymmetric hypotheses of the generic lemma even when t is infinitesimal. Native contact and stationarity give exactly the two required first-jet balances. The proof does not substitute a source/testing scale comparison for these identities.

9. **Every first normal is allocated.** The original full-parent differentiation gives the three forms (IC18), not only restrictions of their coefficients at contact. In (IC19), `P00/k=O(k)`; the other Y/E coefficients contain u or k, and the normalized X coefficients contain `u/sqrt(beta)`, `m/(k sqrt(beta))`, or `v/sqrt(beta)`. They are all infinitesimal. Their t-dependence is polynomial, and monic t-division after setting u=k retains an infinitesimal factor. Their u divided differences are bounded. The exact complete-normal contact identities make the total coefficient of G vanish at contact. Formula (IC21) then handles the additional G term as well as the three A_i terms, so all hard-soft couplings have infinitesimal coefficients on the strict circuit frame.

10. **The hard block is complete and strict.** The bounded-ratio inverse state map has only the pure-testing inverse u and positive source-unit inverses. The possible m t^2 hard coefficient is infinitesimal. Scaling xi by sqrt(beta) gives X-normal pivot one and makes its other hard couplings infinitesimal. The remaining complete hard residue is the diagonal comparison form printed in (IC5), with all factors positive units. Together with the full scalar and complete first normals, this proves a strict full-parent Gram, rather than a scalar-only certificate.

11. **Unbounded t: source errors have no unresolved pole.** The finite reference quadratic base is exactly `H0 N^2+gamma E^2`. Its difference from the original C,A,D base has O(x) source coefficients in `(p,Y,q)`. Substituting `Y=rp+bE+N`, `q=eta p-E`, and `sqrt(x)p=sqrt(x/m)(u/v)P` allocates all errors. For instance the P^2 coefficient is bounded times `(u/v)^2`, and a mixed P-E or P-N coefficient has an additional sqrt(x). All vanish in residue. No comparison of u/v with k is needed.

12. **Unbounded t: the entire higher-angle and B parts are controlled.** The exact identity (IC24) has positive residual R_t and S_t pivots `rho eta/2` and `rho/2`. Its other allocations use `U p E=u R_t E`, `V p E=v S_t E`, and the analogous identities printed in the proof, so all other coefficients are infinitesimal. The B-dependent D/core terms are explicitly restored. Their potentially problematic product with p is allocated directly using `uv p=u S_t`; one must not assume that p itself has a bounded coefficient in the raw root frame. With `B=N_x/sqrt(beta)+(theta u/sqrt(alpha))Q`, the remaining coefficients are small by `theta/sqrt(alpha)=O(pi)` and `1/sqrt(beta)` infinitesimal. The complete m, alpha, beta packet roots in (IC26) have leading roots P, -Q, N_x respectively, and only infinitesimal corrections. This proves the complete seven-root positive residue asserted in (IC27).

13. **State and sign coverage.** No bound on W is assumed in the Z=1 calculation. Homogenizing the exact quadratic state identity multiplies each scalar circuit root by Z and restores the three homogeneous linear normals; no Z inverse remains. Hence Z=0 is included by the polynomial identity, without taking a radical of Z. The two printed exact sign gauges cover negative testing angles. Literal axes have the nonnegative pure-testing core identities printed in the proof. Real and imaginary parts cover complex states.

14. **All-tests join has the required domain.** The inherited module with label `sec:r8-c1-small-L-bounded-eta` explicitly covers every independent projective test except simultaneous infinitesimal u,v for original C1 sources with x,L infinitesimal, zeta noninfinitesimal, and eta bounded. Its domain contains (IC1). Its unit-eta full-state blocks and homogeneous endpoint discussion provide the required remote join. The new bounded/unbounded pure-testing-ratio split exhausts the previously missing simultaneous-infinitesimal chart. The bounded-total-scale alternative is separately supplied by the inherited positive-total-scale theorem.

## Exact admitted domain and limits

The new admission is the original physical native C1 subdomain with x positive infinitesimal and `eta,zeta,r,1-r,eta+r-1` positive bounded units, intersected with the inherited canonical-source conditions. The new work supplies its residual total-normalized-d-infinitesimal case; the preexisting theorem supplies the bounded-total-scale alternative. Together with the inherited remote join, every independent projective test and every real or complex state is covered on this subdomain.

This does not admit infinitesimal eta, unbounded zeta, infinitesimal r or 1-r, an infinitesimal j0 opening, all of C14.3, C14.4, or the global source cover. The review found no substantive unresolved gap in the stated extension.
