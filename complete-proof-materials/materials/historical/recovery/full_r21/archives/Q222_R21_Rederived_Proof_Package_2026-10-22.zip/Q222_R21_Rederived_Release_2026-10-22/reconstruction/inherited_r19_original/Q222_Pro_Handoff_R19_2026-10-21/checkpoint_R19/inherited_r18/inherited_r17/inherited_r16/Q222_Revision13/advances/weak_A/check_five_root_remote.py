#!/usr/bin/env python3
"""Narrow direct remote join for the WA1 source subchart; no imported join."""
import sympy as s
import json
from pathlib import Path
checks={}
def ck(name,expr):
    assert s.cancel(expr)==0,(name,s.factor(expr))
    checks[name]=True
e,h,rho,tau,r=s.symbols('e h rho tau r')
B=e;H=e*h;L=e*(1-h);z=e*rho;y=e*tau
ac=1+z*r;Sc=ac+L;Tc=B+z*r;G=B+z*(H+r-1);j=ac-L/y
delta=z+(1+z)*B+(1+z)*B**2+2*z*(1+z)*B*r+z**3*r*r+2*z*z*r+y*((1+z)*B+z+z*z*r*(2-r))
Ms=(1+z)*Tc*(H+y)-z*(1+y)*(1-r)*L
source={
 'n':(Tc*ac*Sc-r*delta)/(2*r*delta),
 'm':z*z*(1+y)*(1-r)*ac*Sc/(2*G*delta),
 'C':ac*Ms/(2*L*delta),
 'D':(1+z)*Tc*(B-z*y*r)*Sc/(2*y*j*delta),
 'hA':y*ac*Tc*Sc/(2*B*delta)}
g=1-rho*(1-r)
limits={
 'n':(1-r)/(2*r*(1+rho)),
 'm':rho*rho*(1-r)/(2*g*(1+rho)),
 'C':(tau*(1+rho*r)-rho*(1-r))/(2*(1+rho)),
 'D':(1+rho*r)/(2*(1+rho)*(tau-1)),
 'hA':tau*(1+rho*r)/(2*(1+rho))}
for name,expr in source.items():
    num,den=s.fraction(s.cancel(expr))
    assert den.subs({e:0,h:0})!=0
    ck('joint_source_residue_'+name,(num/den).subs({e:0,h:0})-limits[name])

u,v,W,X,Y,Z=s.symbols('u v W X Y Z');U=u*u;V=v*v;Du=1+U;Dv=1+V
n,m,C,D,A,al=s.symbols('n m C D A al')
half=s.Rational(1,2)
RM=v*W-X+u*v*Y-u*Z;RD=u*W+u*v*X-Y-v*Z
F4=n*Du*Dv*X**2+m*RM**2+C*Dv*(u*W-Y)**2+A*Du*Dv*Y**2+D*RD**2+al*Du*(v*Y-Z)**2+half*(RD**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)
F3=s.expand(F4.subs({Y:0,al:0}))
P3=s.hessian(F3,[W,X,Z])/2
det3=s.factor(P3.det())
a0=D*m*(2*n+1)/2
c0=C*(2*m+1)*(2*D+2*n+1)/4
d0=C*D*(2*n+1)/2
co={n:limits['n'],m:limits['m'],C:limits['C'],D:limits['D']}
detpoly=s.Poly(s.cancel(det3/(Du*Dv)),u,v)
b0=detpoly.coeff_monomial(u**4)
middle=detpoly.coeff_monomial(u**2*v**2)
ck('finite_remote_generic_determinant',det3-Du*Dv*(a0*V**2+b0*U**2+middle*U*V+c0*U*U*V+d0*U*V*V))
ck('finite_remote_pair_balance',s.factor((b0-a0*tau**2/rho**2).subs(co)))
ck('finite_remote_central_contact',s.factor((middle+2*a0*tau/rho).subs(co)))
p,q=s.symbols('p q')
F_uinf=s.cancel(p*p*F3.subs(u,1/p)).subs(p,0)
uinf=C*Dv*W**2+n*Dv*X**2+(D+half)*(W+v*X)**2+(m+half)*Z**2
ck('single_u_infinity_residue',F_uinf-uinf)
F_vinf=s.cancel(q*q*F3.subs(v,1/q)).subs(q,0)
vinf=(m+C*U)*W**2+(n+half)*Du*X**2+D*(u*X-Z)**2
ck('single_v_infinity_residue',F_vinf-vinf)

# Complete four-state double-reciprocal parent, including the signed core.
Fhat=s.cancel(p*p*q*q*F4.subs({u:1/p,v:1/q}))
Pz,Qz,Qy,a=s.symbols('Pz Qz Qy a')
YY=a*Qy
RMhat=p*W-p*q*X+YY-Qz
RDhat=q*W+X-p*q*YY-Pz
core=RDhat**2+(1+p*p)*(YY-Qz)**2+p*p*(1+q*q)*X**2+2*(1+q*q)*X*Pz-(1+q*q)*Pz**2
rootform=n*(1+p*p)*(1+q*q)*X**2+m*RMhat**2+C*(1+q*q)*(W-p*YY)**2+(1+p*p)*(1+q*q)*Qy**2+D*RDhat**2+al*(1+p*p)*(YY-Qz)**2+half*core
ck('double_infinity_complete_parent',Fhat.subs({A:1/a**2,Y:a*Qy})-rootform.subs({Pz:p*Z,Qz:q*Z}))
Ginf=s.hessian(rootform,[W,X,Qy,Pz,Qz])/2
res=Ginf.subs({p:0,q:0,a:0,al:0})
expected=s.Matrix([[C,0,0,0,0],[0,n+D+half,0,-D,0],[0,0,1,0,0],[0,-D,0,D,0],[0,0,0,0,m+half]])
for i in range(5):
    for j2 in range(5):ck('double_infinity_residue_'+str(i)+str(j2),res[i,j2]-expected[i,j2])
ck('double_infinity_two_block_determinant',(n+D+half)*D-D*D-D*(n+half))
ck('source_C_positive_numerator',tau*(1+rho*r)-rho*(1-r)-(tau*g+rho*(tau-1)+rho*r))
payload={'status':'PASS','count':len(checks),'checks':checks,
 'scope':'Direct complete remote join on WA1, using unchanged C2 source residues and the complete four-state parent. Finite, one reciprocal, and two reciprocal charts plus local WA1 exhaust all testing angle pairs, including literal endpoints. No final residual-complement nonemptiness claim.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps(payload,indent=2))
