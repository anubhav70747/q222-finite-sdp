"""Focused new checks for the actual-j C1 boundary; no inherited replay."""
import json
from pathlib import Path
import sympy as s
checks={};reports={}
def zero(name,expr):
    val=s.factor(s.together(expr))
    if val!=0:raise AssertionError((name,val))
    checks[name]=True
    print("PASS",name,flush=True)
U,V,u,v,t,W,X,Y,Z,ee,nn,xx=s.symbols("U V u v t W X Y Z E n xi")
C,A,D,m,al,be,h,j,eta=s.symbols("C A D m alpha beta h j eta")
x,zeta,pi=s.symbols("x zeta pi")
th=1-h;Bx=be+s.Rational(1,2);Du=1+U;Dv=1+V
R0=1+j-eta;g=R0-eta*h*U;y=x*eta*zeta
scalar=m*(V*V*(1+g*U)**2/(eta**2*U)-2*th*V*(1+g*U)/eta+th*th*U)
scalar+=C*Dv*(1-g)**2*V/eta**2+A*Du*Dv*g*g*V/eta**2+(D+s.Rational(1,2))*j*j*V/eta**2
scalar+=(al+s.Rational(1,2))*Du*g*g*V*V/eta**2-(2*al+1)*Du*g*V/eta+al*Du+Bx*th*th*U*Dv-Du*V/2
cF=(2*m*R0+C*(1-R0)**2+(A+al+s.Rational(1,2))*R0*R0)/eta**2
qV=(C*(1-R0)**2+A*R0*R0+(D+s.Rational(1,2))*j*j)/eta**2-2*m*th/eta-(2*al+1)*R0/eta-s.Rational(1,2)
qU=al+(m+Bx)*th*th
fA=s.cancel((scalar-m*V*V/(eta**2*U)-cF*V*V-qV*V-al-qU*U)/(U*V))
if s.denom(fA).has(U,V) or fA.has(D):raise AssertionError(("nonpolynomial_fA",fA))
fB=m*zeta/(eta*x);fC=(al-cF*y*y+qU*U)/(eta*zeta*x*x);fG=-(qV+2*cF*y)/x
zero("actual_j_exact_scalar_three_circuit",scalar-cF*(V-y)**2-fA*U*V-fB*x*V*V/(eta*zeta*U)-fC*eta*zeta*x*x+fG*x*V)

Aw=m*V*(1+g*U)**2+C*Dv*(1-g)**2*U+A*Du*Dv*g*g*U+(D+s.Rational(1,2))*(1-g)**2*U+(al+s.Rational(1,2))*Du*g*g*U*V
b0=m*th+D*(1-g)+al*g+s.Rational(1,2)
b1=m*g*th+h*(D+s.Rational(1,2))*(1-g)+(al+s.Rational(1,2))*g
PY=2*((m*V*(1+g*U)-C*Dv*(1-g)+A*Du*Dv*g+(al+s.Rational(1,2))*Du*g*V)/eta-m*th*U-(al+s.Rational(1,2))*Du+(D+s.Rational(1,2))*j/eta)
PE=s.cancel(2*(Aw/U-m*V/U)/eta**2-2*(b0+b1*U)/eta+(1+h*U)*PY)
ZX=s.expand(Bx*th-(D+s.Rational(1,2))*j/eta+PY/2)
zero("actual_j_normal_D_product_PY",s.diff(PY,D)-2*j/eta)
zero("actual_j_normal_D_product_PE",s.diff(PE,D)-2*j*j/eta**2)
zero("actual_j_X_normal_D_cancellation",s.diff(ZX,D))
LX=2*u*th*(m+Bx)-2*m*u*t*t*(1+g*U)/eta+2*u*V*ZX

# Differentiate the entire original parent after the new exact state map.
du=1+u*u;dv=1+v*v
jt=u*W+u*v*X-Y-v*Z;mt=v*W-X+u*v*Y-u*Z
F4=m*mt*mt+C*dv*(u*W-Y)**2+A*du*dv*Y*Y+(D+s.Rational(1,2))*jt*jt+(al+s.Rational(1,2))*du*(v*Y-Z)**2+Bx*dv*(X+u*Z)**2-du*dv*Z*Z/2
change={Z:1,W:(v+ee)/(eta*u),X:-h*u+xx,Y:(1+j)*(v+ee)/eta-(1+h*u*u)*v+u*v*xx-nn}
zero("actual_j_complete_D_event_map",jt.subs(change)-nn+j*(v+ee)/eta)
full=s.expand(F4.subs(change).subs(v,u*t));zero_state={ee:0,nn:0,xx:0};uv={U:u*u,V:u*u*t*t}
zero("actual_j_full_scalar_graph",full.subs(zero_state)-scalar.subs(uv))
zero("actual_j_complete_E_normal",s.diff(full,ee).subs(zero_state)-u*t*(2*m*t*t/eta**2+PE.subs(uv)))
zero("actual_j_complete_D_normal",s.diff(full,nn).subs(zero_state)+u*t*PY.subs(uv))
zero("actual_j_complete_X_normal",s.diff(full,xx).subs(zero_state)-LX.subs(uv))

# Leading bounded scalar coefficients; j and x tend to zero independently.
lead={j:0,h:1,m:0,al:0,C:1/(2*eta),A:eta/(2*(1-eta))}
zero("actual_j_cF_strict_residue",cF.subs(lead)-1/(2*eta**2))
zero("actual_j_fA_strict_residue",fA.subs({U:0,V:0}).subs(lead)-1/(2*eta))

# Source in actual-j coordinates. Dj is substituted directly; no inverse j.
hs=1-x*pi;ths=x*pi;rs=1+j-eta*(1+x*hs);rho=eta+rs
K=1+x;R=1+x*rs;T=1+x*hs;M=R-ths/zeta;Es=1-x*eta*hs;Q=1-x*zeta*rs
P4=T*Es+x*(1-rs)*(hs+zeta)
Pa=R*hs*(1+y)+zeta*M*Es
Pd=1+2*x*hs+rs*x*x*(hs+zeta)+x*zeta+eta*x*(K*zeta+x*hs*ths)
B5=K*(1+y)*rho-j*Pd;Bbeta=K*x*rho*(hs+zeta)-ths*Pd
src={h:hs,C:K*rho*Es/(2*(1-rs)*Pd),A:eta*P4/(2*rs*Pd),m:K*x*rho*hs*(1+y)/(2*M*zeta*Pd),al:x*x*zeta*rho*Pa/(2*Q*Pd),be:Bbeta/(2*ths*Pd)}
Ct=(1+j)/(2*(eta-j));At=eta/(2*R0)
Dj=B5/(2*Pd)
arrays={
 "C_reference_error_over_x":(src[C]-Ct)/x,
 "A_reference_error_over_x":(src[A]-At)/x,
 "Dj_relative_error_over_x":(Dj-s.Rational(1,2))/x,
 "m_over_x":src[m]/x,"alpha_over_x2":src[al]/x**2,
 "Bx_theta_over_x":(src[be]+s.Rational(1,2))*ths/x,
 "qU_over_x2":qU.subs(src)/x**2,
}
allowed={s.Poly(q,eta,zeta).monic().as_expr() for q in (eta,zeta,1-eta)}
for name,expr in arrays.items():
    val=s.factor(s.together(expr));den0=s.factor(s.denom(val).subs({x:0,j:0}))
    if den0==0 or den0.has(pi):raise AssertionError(("uncleared_small_source",name,den0))
    for fac,_ in s.factor_list(den0)[1]:
        if s.Poly(fac,eta,zeta).monic().as_expr() not in allowed:raise AssertionError(("unapproved_factor",name,fac))
    reports[name]=str(den0);checks["unit_source_denominator_"+name]=True
    print("PASS unit_source_denominator_"+name,flush=True)
zero("actual_j_graph_matches_source",g.subs({U:x,h:hs})-rs)
zero("actual_j_fB_source_residue",s.factor(s.together(fB.subs(src))).subs({x:0,j:0})-1/(2*eta))
zero("actual_j_fC_source_residue",s.factor(s.together(fC.subs(U,0).subs(src))).subs({x:0,j:0})-1/(2*eta))

# The comparison base in the new hard frame contains no soft p coordinate.
p,q,YY,dd=s.symbols("p q YY d")
Ht=eta*(j+R0)/(2*R0*(1-R0)*j);bt=R0*(1-R0)/(eta*(j+R0));gt=(1+j)/(2*eta*(j+R0))
base=Ct*(p-YY)**2+At*YY*YY+(p-YY-q)**2/(2*j)+(p-YY)**2/2-p*q
zero("actual_j_reference_hard_base",base-Ht*(YY-R0*p-bt*(eta*p-q))**2-gt*(eta*p-q)**2)
zero("actual_j_reference_normal_gap",1-bt-j*(1+j)/(eta*(j+R0)))
base_new=s.factor(base.subs({q:eta*p-ee,YY:R0*p+ee-nn}))
zero("actual_j_reference_has_no_soft_p",s.diff(base_new,p))
zero("actual_j_reference_normal_ratio_limit",(2*j*Ht).subs(j,0)-1)

out={"status":"PASS","checks":checks,"count":len(checks),"source_denominators_at_x_j_zero":reports,"scope":"Actual j infinitesimal; eta,zeta,r,1-r units. New scalar graph, all first normals, opening cancellation, and strict reference hard block. Source contact jets inherited by the exact graph equality. Full local/all-tests proof is separate."}
Path(__file__).with_suffix(".json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"status":"PASS","checks":len(checks)}))
