General bounded-shape one-weak C2 all-tests theorem
================================================

The proof is general_single_angle.tex.  The exact checker is
check_general_single_angle.py; its successful run writes
check_general_single_angle.json.  It uses the existing SymPy dependency:

  PYTHONPATH=/workspace/scratch/f695f02f9e9c/.proof_dependencies \
    "$CODEX_PRIMARY_RUNTIME_PYTHON" \
    analysis_atlas/checklist_c2/check_general_single_angle.py

Exact source domain (reflected orientation): x>0 coefficient
infinitesimal; k,b,r,h and 1-r,b-h,g=b-1+r+xh,b-k^2 r are positive
bounded units.  Set c=sqrt(x), a=k/sqrt(x), t=x(b-h)/k^2, and use all
six exact original rational weights displayed in the proof.  Require
n>=0 and the inherited physical canonical-source hypothesis.

Result: all independent real/complex projective state and angle tests.
The theorem allows n to be a positive unit, a nonnegative infinitesimal,
or zero exactly.  No coefficient/testing rate comparison is made.
The original orientation is obtained by exact C2 reflection, swapping
C with alpha and m with D and fixing n,A.

Advance beyond the fixed rational family: the bounded contact shapes
k,b,r,h vary freely within the stated inequalities, and no fixed xA/xC
ratio is assumed.  The six-term Laurent scalar has a global exact
balanced-cycle AM-GM decomposition.  This proves uniqueness and strict
local Hessian at the matched remote angle.  Full normals, n0=0 at the
double-zero testing corner, and all four remaining outer chart types
are included explicitly.

Inherited conceptual inputs: the strict bounded-tensor residue Gram
lemma; the physical arbitrary-scale noncommuting-residue exit.  The
checker verifies source contact algebra directly, but does not itself
prove either inherited theorem or enumerate all canonical sources.

Scope boundary: this is a sufficient bounded-shape source theorem,
not a global C2 classification.  Degeneration of any printed positive
unit, unbounded k or shape parameters, or failure of source positivity
falls outside this theorem; some such cases are covered by other
retained theorems.  No assertion of global openness is made for those
complements.
