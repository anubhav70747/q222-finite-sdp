#!/usr/bin/env python3
"""Focused source bounds and complete hard/normal extraction checks.

The unchanged six-contact Gram identity is inherited from WA8;
no remote-testing assertion is made by this checker.
"""
import json
from pathlib import Path
import sympy as s
checks={}
def ck(name,expr):
    assert s.cancel(expr)==0,name
    checks[name]=True
B,h,a,t,r=s.symbols('B h a t r')
ca=1+a*B*r; S=1+B*(1-h+a*r)
g=1+a*(h*B+r-1); j=ca-(1-h)/t
dd=a+(1+a*B)+(1+a*B)*B+2*a*B*(1+a*B)*r+a**3*B**2*r*r+2*a*a*B*r+t*B*(1+a+a*B+a*a*B*r*(2-r))
M=(1+a*B)*(1+a*r)*(h+t)-a*(1+t*B)*(1-r)*(1-h)
N=((1+a*r)*ca*S-r*dd)/(2*dd)
m=a*a*(1+t*B)*(1-r)*ca*S/(2*g*dd)
mu=(1+t*B)*(1-r)*ca*S/(2*g*dd)
C=ca*M/(2*(1-h)*dd); Ah=t*ca*(1+a*r)*S/(2*dd)
D=(1+a*B)*(1+a*r)*(1-a*t*B*r)*S/(2*t*j*dd)
alhat=(1+a*r)*M/(2*(1-h*B)*dd)
corner={B:0,h:0,r:0}
for name,expr,target in [
 ('nr',N,1/(2*(1+a))),('mu',mu,1/(2*(1-a*a))),
 ('C',C,(t-a)/(2*(1+a))),('D',D,1/(2*(1+a)*(t-1))),
 ('Ah',Ah,t/(2*(1+a))),('alpha_over_B2',alhat,(t-a)/(2*(1+a)))]:
    ck('joint_source_residue_'+name,expr.subs(corner)-target)

# The previous a-normalization cancellation remains regular at r=0.
b2=2*m*h+C*(1-h)**2+Ah*h+(B*B*alhat+s.Rational(1,2))*h*h
ck('exact_a_zero_cancellation_all_r',(b2-alhat).subs(a,0))
numer,denom=s.fraction(s.cancel(b2-alhat))
quot,rem=s.div(s.Poly(numer,a),s.Poly(a,a))
assert rem.is_zero
checks['numerator_divisible_by_a']=True
denres=s.factor(denom.subs(corner))
# Explicit factor form shows this is a unit throughout 0 <= a0 < 1.
assert s.expand(denres-2*(a-1)*(a+1)) == 0
checks['cancelled_denominator_nonzero_polynomial']=True
ck('cancelled_quotient',quot.as_expr()/denom-(b2-alhat)/a)
ck('cancelled_quotient_has_zero_residue',quot.as_expr().subs(corner))

# Check the complete normal and hard entries directly against the original
# signed parent, before imposing the source-contact representations.
u,v,W,X,Y,Z,xx,yy,nn,AA,mm,CC,DD,al=s.symbols('u v W X Y Z xx yy nn AA mm CC DD al')
pn,pa=s.symbols('pn pa',nonzero=True)
U=u*u; V=v*v; Du=1+U; Dv=1+V; half=s.Rational(1,2)
RD=u*W+u*v*X-Y-v*Z
F=nn*Du*Dv*X**2+mm*(v*W-X+u*v*Y-u*Z)**2+CC*Dv*(u*W-Y)**2+AA*Du*Dv*Y**2+DD*RD**2+al*Du*(v*Y-Z)**2+half*(RD**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)
norm=F.subs({X:xx/pn-r*u*Z,Y:yy/pa+h*u*W,nn:pn*pn,AA:pa*pa})
hxx=pn*pn*Du*Dv+mm+(DD+half)*U*V+half*Dv
hxy=-u*v*(mm+DD+half)
hyy=pa*pa*Du*Dv+CC*Dv+DD+half+mm*U*V+(al+half)*Du*V
ck('entire_normalized_x_hard_pivot',s.diff(norm,xx,2)/2-hxx/(pn*pn))
ck('entire_normalized_y_hard_pivot',s.diff(norm,yy,2)/2-hyy/(pa*pa))
ck('entire_normalized_cross_hard_entry',s.diff(norm,xx,yy)/2-hxy/(pn*pa))
lx=v*W*(-mm+(-mm*h+(DD+half)*(1-h))*U)+u*Z*(-pn*pn*r+mm*(1-r)+half*(1-r)-pn*pn*r*U+(-DD-r*(pn*pn+half))*V-r*(pn*pn+DD+half)*U*V)
ly=u*W*(-(CC+DD+half)*(1-h)+pa*pa*h+pa*pa*h*U+(-CC*(1-h)+pa*pa*h+mm+(al+half)*h)*V+h*(pa*pa+mm+al+half)*U*V)+v*Z*(DD-al+(-mm*(1-r)+r*(DD+half)-al-half)*U)
ck('complete_normalized_x_first_normal',s.diff(norm,xx).subs({xx:0,yy:0})/2-lx/pn)
ck('complete_normalized_y_first_normal',s.diff(norm,yy).subs({xx:0,yy:0})/2-ly/pa)
out={'status':'PASS','count':len(checks),'checks':checks,
 'cancelled_denominator_at_B_h_r_zero':str(denres),
 'scope':'Original physical C2 source with r positive infinitesimal, a positive bounded (unit or infinitesimal), G/B unit: complete bounded-test full-parent congruence, with exact zero quotient residue; no endpoint conclusion from this checker alone.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
