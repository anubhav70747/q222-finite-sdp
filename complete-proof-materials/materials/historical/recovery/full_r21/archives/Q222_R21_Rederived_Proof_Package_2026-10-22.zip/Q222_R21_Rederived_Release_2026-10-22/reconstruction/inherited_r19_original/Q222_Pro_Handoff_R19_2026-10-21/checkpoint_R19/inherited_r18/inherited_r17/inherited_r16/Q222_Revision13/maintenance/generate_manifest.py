#!/usr/bin/env python3
"""Generate a deterministic manifest for the derivative package, excluding build auxiliaries."""
from pathlib import Path
import hashlib
ROOT=Path(__file__).resolve().parents[1]
ignored={".aux",".log",".out",".toc",".synctex",".gz",".pyc"}
rows=[]
for p in sorted(ROOT.rglob("*")):
 if not p.is_file() or p.name=="MANIFEST.sha256" or p.suffix in ignored or "__pycache__" in p.parts:continue
 if p.is_symlink():raise RuntimeError("Symlink in release package: "+str(p))
 rows.append(hashlib.sha256(p.read_bytes()).hexdigest()+"  "+str(p.relative_to(ROOT)))
(ROOT/"MANIFEST.sha256").write_text("\n".join(rows)+"\n")
print(str(len(rows))+" release members hashed.")
