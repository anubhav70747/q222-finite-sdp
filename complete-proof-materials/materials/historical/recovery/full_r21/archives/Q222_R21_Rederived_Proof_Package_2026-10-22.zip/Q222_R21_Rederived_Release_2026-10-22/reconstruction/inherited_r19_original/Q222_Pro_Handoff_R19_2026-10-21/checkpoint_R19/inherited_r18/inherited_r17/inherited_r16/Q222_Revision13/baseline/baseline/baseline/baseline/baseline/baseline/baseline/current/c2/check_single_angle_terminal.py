#!/usr/bin/env python3
"""Exact checks for one C2 family's LOCAL single-angle terminal.

This checks the displayed identities, source contact, leading scalar,
both normal gates and strict residue.  The monic-division proof in the
companion TeX supplies the exact bounded Gram, without expanding it.
"""
from pathlib import Path
import json
import sympy as s

if not __debug__:
    raise SystemExit('Run without -O: assertions are proof checks.')
x,u,v,W,X,Y,Z,rho=s.symbols('x u v W X Y Z rho')
K=39*x*x+95*x+64
n=(11*x*x+45*x+16)/(2*K)
m=2*(x+2)*(x+3)*(5*x+4)/K
C=4*(x+2)*(x*x+3*x+5)/(3*x*K)
A=5*(x+2)*(5*x+4)/(x*K)
D=15*x*(x+1)*(5*x+4)/(2*(4-x)*K)
alpha=5*x*(x*x+3*x+5)/(2*K)
Du,Dv=1+u*u,1+v*v
Rm=v*W-X+u*v*Y-u*Z
RD=u*W+u*v*X-Y-v*Z
Ra=v*Y-Z; Rb=X+u*Z
F=4*n*Du*Dv*X*X+4*m*Rm*Rm+4*C*Dv*(u*W-Y)**2
F+=4*A*Du*Dv*Y*Y+4*D*RD*RD+4*alpha*Du*Ra*Ra
F+=2*(RD*RD+Du*Ra*Ra+Dv*Rb*Rb-Du*Dv*Z*Z)
kappa=4/(4+x); sigma=1/kappa
hx=(11+5*v*v)/2
gamma=5*x/(8*(4+x))
Xg=(3*v*W-5*u)/hx+gamma*u
Yg=u*W/4
graph={X:Xg,Y:Yg,Z:1}
contact={u:rho,v:1,W:4*rho/(4+rho*rho),
         X:-rho/(4+rho*rho),Y:rho*rho/(4+rho*rho),Z:1,x:rho*rho}
assert s.cancel(Xg.subs(contact,simultaneous=True)+rho/(4+rho*rho))==0
assert s.cancel(Yg.subs(contact,simultaneous=True)-rho*rho/(4+rho*rho))==0
contact_count=0
for E in [F]+[s.diff(F,q) for q in (u,v,W,X,Y,Z)]:
    assert s.cancel(E.subs(contact,simultaneous=True))==0
    contact_count+=1

# Exact source binding: original c=1, a^2=1/x, r=h=j=1/4,t=1;
# then swap (m,D),(C,alpha), as required by C2 reflection.
aa=1/x; b=aa+s.Rational(1,4); r=s.Rational(1,4)
delta=2*b*b+4*b*r+2*(1+aa)*b+(1-aa)*r*r+2*(1+aa)*r+1+aa
Ns=2*(b+r)*b-aa*(1+aa)*s.Rational(3,4)
ac=s.Rational(5,4); ss=ac+aa; g=aa-s.Rational(1,4)
original=[((b+r)*ac*ss-r*delta)/(2*r*delta),
          (1+aa)*s.Rational(3,4)*ac*ss/(2*g*delta),
          ac*Ns/(2*aa*delta),aa*ac*(b+r)*ss/(s.Rational(1,2)*delta),
          2*(b+r)*(b-aa*r)*ss/(aa*s.Rational(1,2)*delta),
          (b+r)*Ns/(s.Rational(3,2)*delta)]
for actual,expected in zip((n,m,C,A,D,alpha),
                            (original[0],original[4],original[5],original[3],original[1],original[2])):
    assert s.cancel(actual-expected)==0

R=(u*W-kappa*x)/rho; S=u-sigma*W
U=rho*(v-1); T=u*(v-1)
def rho_square(E):
    return s.cancel(E).subs(rho*rho,x)
for E in (u*u-x-u*S-sigma*rho*R,
          W*W-kappa*kappa*x+kappa*W*S-kappa*rho*R,
          u*W-kappa*x-rho*R):
    assert s.cancel(E)==0
zero=T*T-U*U-S*T*(v-1)-sigma*R*U*(v-1)
assert s.cancel(zero).subs(rho*rho,x)==0

f=s.Poly(s.expand(F.subs(graph,simultaneous=True)),u,W)
q=5*(1+v*v)/8
bb=5*(1+5*v*v)/(11+5*v*v)
cc=15*v*v*(1+v*v)/(11+5*v*v)
dd=50*v*(1+v*v)/(11+5*v*v)
ee=(15*v*v+25)/32
p,w=s.symbols('p w')
leading=0
for (i,j),coef in f.terms():
    assert (i+j)%2==0
    leading+=s.limit(s.cancel(coef*x**((i+j)//2-1)),x,0)*p**i*w**j
assert s.factor(leading-(q*p*p*w*w+bb*p*p+cc*w*w-dd*p*w+ee))==0

# The displayed singular scalar packet is the entire coefficient pole.
Q=Dv*(9*x*C+x*A*Du)/4
regular=s.Poly(s.expand(f.as_expr()-(u*W)**2*Q/x),u,W)
for coef in regular.coeffs():
    assert s.limit(x*s.cancel(coef),x,0)==0

# X normal: bounded, odd, and its entire degree-one leading term is zero
# for every v.  This is stronger than checking it only at v=1.
LX=s.Poly(s.expand(s.diff(F,X).subs(graph,simultaneous=True)),u,W)
for (i,j),coef in LX.terms():
    assert (i+j)%2==1
    assert s.limit(x*s.cancel(coef),x,0)==0
    if i+j==1:
        assert s.factor(s.limit(s.cancel(coef),x,0))==0

# rho*F_Y = R*Bbig + rho*E.  E and Bbig are bounded even;
# both vanish at x=u=W=0 for every v.  No mixed division occurs.
Bbig=2*Dv*(x*A*Du-3*x*C)
FY=s.diff(F,Y).subs(graph,simultaneous=True)
E0=s.Poly(s.expand(FY-(u*W/x)*Bbig),u,W)
for (i,j),coef in E0.terms():
    assert (i+j)%2==0
    assert s.limit(x*s.cancel(coef),x,0)==0
assert s.factor(s.limit(s.cancel(E0.as_expr().subs({u:0,W:0})),x,0))==0
assert s.factor(s.limit(s.cancel(Bbig.subs(u,0)),x,0))==0

# Hard Gram after using NY=(Y-Yg)/rho.
hxx=s.diff(F,X,2)/2
hyy=x*s.diff(F,Y,2)/2
hxy=s.diff(F,X,Y)/2
assert s.limit(s.cancel(hxx.subs({u:0,v:1})),x,0)==8
assert s.limit(s.cancel(hyy.subs({u:0,v:1})),x,0)==s.Rational(20,3)
assert s.limit(s.cancel(hxy.subs({u:0,v:1})),x,0)==0
assert s.simplify(s.diff(2*q+bb+cc-dd,v).subs(v,1))==s.Rational(5,16)
assert s.simplify(s.diff(bb-cc,v).subs(v,1))==-s.Rational(5,2)
assert s.simplify(s.diff(q+bb+cc-dd+ee,v,2).subs(v,1)/2)==s.Rational(255,128)
G_RU=s.Matrix([[s.Rational(5,4),s.Rational(5,32)],
               [s.Rational(5,32),s.Rational(127,128)]])
G_ST=s.Matrix([[s.Rational(15,8),-s.Rational(5,4)],[-s.Rational(5,4),1]])
assert G_RU.det()==s.Rational(1245,1024)
assert G_ST.det()==s.Rational(5,16)
report={'status':'PASS','exact_source_contact_checks':contact_count,
        'source_binding':'six rational reflected C2 weights checked',
        'normal_gate':'both full normal coefficients have bounded zero-residue lifts',
        'hard_diagonal':['8','20/3'],
        'soft_block_determinants':[str(G_RU.det()),str(G_ST.det())],
        'scope':'LOCAL ONLY: reflected chart u,W infinitesimal, v-1 infinitesimal, Z=1; no all-tests conclusion',
        'proof_boundary':'monic division and strict-residue Gram theorem are explained analytically in the companion TeX'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
