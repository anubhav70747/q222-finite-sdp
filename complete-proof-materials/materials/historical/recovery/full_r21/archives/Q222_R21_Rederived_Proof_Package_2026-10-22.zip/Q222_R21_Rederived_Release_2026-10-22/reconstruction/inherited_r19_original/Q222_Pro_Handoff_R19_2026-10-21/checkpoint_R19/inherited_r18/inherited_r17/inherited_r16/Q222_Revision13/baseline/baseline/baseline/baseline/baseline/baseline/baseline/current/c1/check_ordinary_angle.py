"""Small exact identities for ordinary_angle.tex; Python standard library only.

No Groebner basis, numerical positivity test, expanded archive, or external
source file is used. The analytical proof supplies the bounded-Gram lemma.
"""
if not __debug__:
    raise SystemExit('Run without -O: assertions are proof checks.')
from fractions import Fraction as Q
from pathlib import Path
from itertools import permutations
import json
import time

started = time.perf_counter()
checks = []

class P:
    def __init__(self, terms, n):
        self.p = {m:c for m,c in terms.items() if c}
        self.n = n
    def lift(self, q):
        if isinstance(q, P):
            assert q.n == self.n
            return q
        return P({(0,)*self.n:q},self.n)
    def __add__(self, q):
        q=self.lift(q); out=dict(self.p)
        for m,c in q.p.items():out[m]=out.get(m,0)+c
        return P(out,self.n)
    __radd__=__add__
    def __neg__(self):return P({m:-c for m,c in self.p.items()},self.n)
    def __sub__(self,q):return self+-self.lift(q)
    def __rsub__(self,q):return self.lift(q)+-self
    def __mul__(self,q):
        q=self.lift(q);out={}
        for m,c in self.p.items():
            for r,d in q.p.items():
                t=tuple(x+y for x,y in zip(m,r));out[t]=out.get(t,0)+c*d
        return P(out,self.n)
    __rmul__=__mul__
    def __pow__(self,e):
        assert isinstance(e,int) and e>=0
        out=self.lift(1);p=self
        while e:
            if e&1:out=out*p
            p=p*p;e//=2
        return out
    def diff(self,i):
        out={}
        for m,c in self.p.items():
            if m[i]:
                r=list(m);r[i]-=1;out[tuple(r)]=c*m[i]
        return P(out,self.n)
    def sub(self, replacements):
        vs=variables(self.n);vs=[self.lift(replacements.get(i,p)) for i,p in enumerate(vs)]
        powers=[{0:self.lift(1)} for _ in vs]
        out=self.lift(0)
        for m,c in self.p.items():
            term=self.lift(c)
            for i,e in enumerate(m):
                if e not in powers[i]:powers[i][e]=vs[i]**e
                term=term*powers[i][e]
            out=out+term
        return out

def variables(n):
    return [P({tuple(int(i==j) for i in range(n)):1},n) for j in range(n)]
def zero(name,p):
    assert not p.p,(name,len(p.p))
    checks.append(name)
def determinant(A):
    n=len(A);out=A[0][0].lift(0)
    for perm in permutations(range(n)):
        sign=(-1)**sum(perm[i]>perm[j] for i in range(n) for j in range(i+1,n))
        term=A[0][0].lift(sign)
        for i,j in enumerate(perm):term=term*A[i][j]
        out=out+term
    return out

# Native source: eta and zeta are independent polynomial variables here.
k,eta,zeta,a,t=variables(5);kap=k*k;K=1+kap;Vc=kap*eta*zeta
Lc=1-a*eta;Hc=1+(1-a)*eta;Qc=1-kap*zeta+a*Vc
P4=K+eta*kap*(a-K)-zeta*kap*t+Vc*(-zeta*kap*t*t+2*kap*t+a*(1-t)+t)
Pa=K-a*eta*kap+zeta*(K-(2+kap)*t)+Vc*(-zeta*t*t+a*(t-1)+t)
Pd=K*K-a*eta*kap*kap+zeta*kap*(K-(kap+2)*t)+Vc*(-zeta*kap*t*t+kap*a*(t-1)+kap*t+K)
c2=2*K*(1-t*zeta)*Lc*(1+Vc)*Hc*Qc
cb=2*K*Lc*(1+(1-t)*zeta)*Hc*Qc
c3=2*K*Lc*Hc*Qc*(1-kap*eta+t*Vc)
c5=2*K*Lc*Hc*Qc*(1+Vc)
c4=2*Qc*P4;ca=2*Lc*Hc*Pa;cd=4*Lc*Qc*Pd
V=1+Vc;R=K-a*kap*eta;T=K-kap*zeta*t
zero('native current 1',cb-c2-zeta*c3)
zero('native current 2',c3-c5+kap*eta*cb)
zero('native Alice balance',c2-(1-t*zeta)*c5)
zero('native state Y balance',2*kap*c2+2*V*Lc*c4-2*kap**2*zeta*Qc*ca-Qc*cd)
zero('native scalar balance',2*kap*Lc*c2+2*c5+2*V*Lc**2*c4+2*kap*Qc**2*ca+(kap*zeta*Lc**2-2*Lc-eta)*cd)
zero('native Bob balance',2*kap*R*c2+2*t*kap*Vc*cb+2*a*Vc*c3+2*T*c5+2*K*Vc*Lc**2*c4-2*kap**2*zeta*K*Qc*Lc*ca-K*(Qc*Lc+eta)*cd)
for name,p in [('c2',c2),('cb',cb),('c3',c3),('c5',c5),('c4',c4),('ca',ca)]:
    zero('ordinary-angle residue '+name,p.sub({1:0,2:0})-2*K)
zero('ordinary-angle residue cd',cd.sub({1:0,2:0})-4*K*K)

# Four-square completion, angular capacity, contact factorization, Hessian.
k,s,a,t,u,W,Z,nu,xi,chi=variables(10);K=1+k*k;Du=1+u*u
den=K*s*s*t*(K-t)*(K-a)
model=8*a*k*k*K*t*(K-a)*(nu*Du*W-xi)**2
model+=8*a*k*k*K*(K-t)*(K-a)*xi**2+8*den*chi**2
model+=8*a*K*s*s*t*(K-t)*(chi-nu*Du*Z)**2
model+=8*a*den*Du*u*u*W*W+8*a*s*s*k**4*den*Du*Z*Z-16*a*K*den*Du*u*nu*W*Z
Sn=K*s*s*u*u*W*W+K*s**4*k**4*Z*Z+Du*nu*nu*(k*k*W*W+s*s*Z*Z)-2*K*K*s*s*u*nu*W*Z
completed=8*a*k*k*(K-a)*(K*xi-t*nu*Du*W)**2
completed+=8*s*s*t*(K-t)*(K*chi-a*nu*Du*Z)**2+8*a*Du*t*(K-t)*(K-a)*Sn
zero('four-square completion after pure unit clearing',model-completed)
zero('angular capacity factorization',Du*(u+k**3)**2-K**3*u*u-(u-k)**2*(k**4+2*k**3*u+2*k*u+u*u))
zero('matched-angle two-square factorization',Sn.sub({4:k})-K*s*s*(nu*Z-k*W)**2-K*(k*nu*W-s*s*k*k*Z)**2)
zero('state conductor relation',W*(nu*Z-k*W)-Z*(nu*W-s*s*k*Z)-k*(s*s*Z*Z-W*W))
contact={4:k,5:s,6:1,7:k*s}
zero('scalar contact',Sn.sub(contact))
for i,name in [(7,'nu'),(5,'W'),(4,'u')]:zero('scalar contact derivative '+name,Sn.diff(i).sub(contact))
H=[[K*K,K*k*(k*k-1),K*s*(k*k-1)],
   [K*k*(k*k-1),k*k*K*K,s*k*(k**4+1)],
   [K*s*(k*k-1),s*k*(k**4+1),s*s*K*K]]
indices=[7,5,4]
for i in range(3):
    for j in range(i,3):
        zero('half-Hessian entry %d%d'%(i+1,j+1),Q(1,2)*Sn.diff(indices[i]).diff(indices[j]).sub(contact)-s*s*H[i][j])
zero('Hessian principal minor 1',H[0][0]-K*K)
zero('Hessian principal minor 2',determinant([row[:2] for row in H[:2]])-4*k**4*K*K)
zero('Hessian principal minor 3',determinant(H)-12*s*s*k**6*K*K)

# Exact full parent and finite monomial Gram allocation. Source parameters
# m,c,D,b,A2,al2,d0 are formal bounded coefficients: A=eta²A2 etc.
m,c,D,b,A2,al2,d0,eta,u,v,W,Z,x,y=variables(14)
Du=1+u*u;Dv=1+v*v;Y=u*W-y;X=x-u*Z
rm=v*(W+u*Y)-X-u*Z;rd=u*W+u*v*X-Y-v*Z
core=2*(rd*rd+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z*Z)
original=4*m*rm*rm+4*c*Dv*(u*W-Y)**2+4*eta*eta*A2*Du*Dv*Y*Y
original+=4*D*rd*rd+4*eta*eta*al2*Du*(v*Y-Z)**2+4*b*Dv*(X+u*Z)**2+eta*d0*core
F=4*m*(v*(Du*W-u*y)-x)**2+4*c*Dv*y*y+4*eta*eta*A2*Du*Dv*(u*W-y)**2
F+=(4*D+2*eta*d0)*(y+v*(u*x-Du*Z))**2
F+=4*eta*eta*al2*Du*(v*(u*W-y)-Z)**2+(4*b+2*eta*d0)*Dv*x*x
F+=2*eta*d0*Du*((v*(u*W-y)-Z)**2-Dv*Z*Z)
zero('entire original parent in x,y coordinates',original-F)
lead=4*m*(v*Du*W-x)**2+4*b*x*x+4*c*y*y+4*D*(y-v*Du*Z)**2
lead+=4*A2*Du*(eta*u*W)**2+4*al2*Du*(eta*Z)**2-4*d0*Du*u*v*W*eta*Z

def allocate(name,poly,roots,small):
    monomials=[]
    for r in roots:
        assert len(r.p)==1
        (mon,coef),=r.p.items();assert coef==1
        monomials.append(mon)
    pairs=[tuple(a+b for a,b in zip(r,s)) for i,r in enumerate(monomials) for s in monomials[i:]]
    for mon,coef in poly.p.items():
        legal=[]
        for pair in pairs:
            rem=tuple(a-b for a,b in zip(mon,pair))
            if min(rem)>=0 and (not small or any(rem[i] for i in small)):legal.append(rem)
        assert legal,(name,mon,coef)
    checks.append(name)

allocate('bounded finite-chart full Gram',F,[x,y,v*W,v*Z,eta*W,eta*Z],[])
allocate('finite-chart omitted terms have zero residue',F-lead,[x,y,v*W,v*Z,eta*W,eta*Z],[7,9])
lead_zero=lead+4*d0*Du*u*v*W*eta*Z
allocate('Alice zero chart has strict-leading remainder',F-lead_zero,[x,y,v*W,v*Z,eta*u*W,eta*Z],[7,8,9])

# Reciprocal testing chart; here u denotes h, W denotes free X, Z free Y.
h=u;XX=W;YY=Z
FR=4*m*(v*((1+h*h)*YY+h*y)-x)**2+4*c*Dv*y*y
FR+=4*eta*eta*A2*(1+h*h)*Dv*YY*YY
FR+=(4*D+2*eta*d0)*(y+v*((1+h*h)*XX-h*x))**2
FR+=4*eta*eta*al2*(1+h*h)*(v*YY-x+h*XX)**2+(4*b+2*eta*d0)*Dv*x*x
FR+=2*eta*d0*(1+h*h)*((v*YY-x+h*XX)**2-Dv*(x-h*XX)**2)
LR=4*m*(v*YY-x)**2+4*b*x*x+4*c*y*y+4*D*(y+v*XX)**2
LR+=4*A2*(eta*YY)**2+4*al2*(eta*h*XX)**2
allocate('Alice reciprocal chart full Gram',FR,[x,y,v*YY,v*XX,eta*YY,eta*h*XX],[])
allocate('Alice reciprocal omitted terms have zero residue',FR-LR,[x,y,v*YY,v*XX,eta*YY,eta*h*XX],[7,8,9])

# Exact structural divisibility before and after a generic eta-sized shift.
for mon,coef in F.p.items():
    normal_degree=mon[9]+mon[12]+mon[13]
    assert normal_degree>=2 or mon[7]+normal_degree>=2
checks.append('full normal polynomial in N² + eta N + eta²')
# Shift by three algebraically independent bounded coefficient constants;
# no exact stationary identities are needed for this elementary gate.
F17=P({mon+(0,0,0):coef for mon,coef in F.p.items()},17)
vs=variables(17)
shifted=F17.sub({9:vs[9]+vs[7]*vs[14],12:vs[12]+vs[7]*vs[15],13:vs[13]+vs[7]*vs[16]})
for mon,coef in shifted.p.items():
    normal_degree=mon[9]+mon[12]+mon[13]
    assert normal_degree>=2 or mon[7]+normal_degree>=2
checks.append('eta-sized contact translation preserves divisibility')

out={'status':'PASS','checks':len(checks),'identities':checks,
     'seconds':time.perf_counter()-started,
     'method':'standard-library exact sparse rational polynomial arithmetic; no numerical or Groebner step',
     'scope':'regular ordinary-angle source only; analytical proof supplies finite Taylor allocation and strict-residue Gram conclusion'}
Path(__file__).with_name('ordinary_angle_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
