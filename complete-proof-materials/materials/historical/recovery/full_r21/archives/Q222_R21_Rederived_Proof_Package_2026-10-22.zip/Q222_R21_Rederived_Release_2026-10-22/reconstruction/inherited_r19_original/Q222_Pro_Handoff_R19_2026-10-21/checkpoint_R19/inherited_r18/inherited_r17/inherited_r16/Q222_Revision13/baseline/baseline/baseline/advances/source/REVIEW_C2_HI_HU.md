# Review of the directed weak-C HI/HU exclusion

Result: PASS for the precise original-source impossibility statement in
`bounded_second_angle_exclusion.tex`.

The review used the unchanged six-coefficient C2 source, rather than a
selected square family. The independent exact replay passes all nine
identity/sign checks in `check_bounded_second_angle.py`.

The key uniform step is sound. If R=r/q were unbounded, then q/r is
infinitesimal. The ratio T/(H+yr) is bounded in both exhaustive possibilities
for 0<r<1: for a positive bounded unit r use T<H+y<=(H+yr)/r;
for infinitesimal r the positive g gap forces H to have residue one.
The negative terms in P/[r^2(H+yr)] therefore have zero residue, whereas
1+y is at least one. The exact negative prefactor in n then contradicts
n>=0, including n=0.

Once R is bounded, the positive g gap gives H residue one. The displayed
Delta is a bounded positive unit, and the exact N_src/q formula has
residue (1+y_0)(1+R_0)>0. The original coefficient C has bounded positive
inverse because L is bounded; no lower bound on L is required. These
arguments include infinitesimal y and arbitrary infinitesimal gap rates.

This is source exclusion and hence needs no restriction of independent
testing fields, testing angles, or state charts. It removes the two
directed residual leaves HI and HU only in the orientation C weak.
The reflection consequence for HI and UI stated by the author is correct.
It does not identify IH with HI, does not close a strong C2 leaf, and does
not prove global coverage.

This is a review by the supervising agent, with exact replay, not external
or independently certified mathematical verification.
