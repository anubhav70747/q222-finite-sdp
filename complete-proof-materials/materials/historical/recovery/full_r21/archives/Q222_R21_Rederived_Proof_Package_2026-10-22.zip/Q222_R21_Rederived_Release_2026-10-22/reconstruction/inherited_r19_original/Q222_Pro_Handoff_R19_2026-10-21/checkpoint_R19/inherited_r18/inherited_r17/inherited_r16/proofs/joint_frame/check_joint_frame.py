"""Exact full-parent assembly through six original contact balances.
No SOS admission is asserted.  All inverses are pure source or testing.
"""
import json
from pathlib import Path
import sympy as s
u,v,E,Q,xi=s.symbols('u v E Qt xi'); U=u*u; V=v*v
x,a,t,h,r,m,A,C,D,B,al=s.symbols('x a eta h r m A C Dp Bx alpha', nonzero=True)
th=1-h; y=x*t/a; j=t*(1+x*h)+r-1
T0=A+al+s.Rational(1,2); Tm=T0+m; e4=r*r*Tm/t**2
q=al+(m+B)*th**2; mu=m-a*a*q; lam=mu/(t*a*x)
b=A*r/t-m*th-al-s.Rational(1,2); bp=b+e4*y*t/(2*r)
g=2*(B*th-D*j/t-m*r/t)
W=(v+E)/(t*u); Y=r*v/t+Q; X=xi-h*u
M=v*W-X+u*v*Y-u; De=u*W-Y+u*v*X-v
parent=m*M**2+C*(1+V)*(u*W-Y)**2+A*(1+U)*(1+V)*Y**2+D*De**2+(al+s.Rational(1,2))*(1+U)*(v*Y-1)**2+B*(1+V)*(X+u)**2-(1+U)*(1+V)/2
F=V-y; Fb=F+v*E; Ft=F+t/r*v*Q; RD=v*(U-x); P=E/t-Q
H=a*v*W-u-a*xi; Hfull=H+a*xi
L=U*V+a*x/t*V**2/U+t*x*x/a-3*x*V
# This is exactly the generic coupled circuit before its literal-square completion.
circuit=lam*L+mu*V/(t*t*U)*E**2+2*(mu*v**3/(t*t*U)-lam*x*v)*E
rad=C/t**2*(Fb-r*Ft)**2+T0*r*r/t**2*Ft**2+(2*m*r/t**2+e4*x)*Fb*Ft
candidate=q*H**2+circuit+C*P**2+A*Q**2+D*(P-h*RD+u*v*xi)**2+2*bp*Q*RD+B*(1+V)*xi**2+rad+e4*U*Ft**2-e4*y*u*Hfull*Ft+A*U*Q**2-2*mu/a*H*xi-mu*xi**2+g*u*F*xi-2*m*u*v*Q*xi
checks={}
def ck(name, expr):
    assert s.cancel(expr)==0, (name, s.factor(expr))
    checks[name]=True

def at_contact(expr):
    return s.cancel(s.expand(expr).subs(u**2,x).subs(v**2,y))

zero={E:0,Q:0,xi:0}
dE=at_contact(s.diff(parent,E).subs(zero)/v)
dQ=at_contact(s.diff(parent,Q).subs(zero)/v)
dXi=at_contact(s.diff(parent,xi).subs(zero)/u)
Us,Vs=s.symbols('Us Vs')
scalar=s.expand(parent.subs(zero)).subs(u**2,Us).subs(v**2,Vs)
cs=s.expand(candidate.subs(zero)).subs(u**2,Us).subs(v**2,Vs)
d0=s.cancel(scalar.subs({Us:x,Vs:y}))
dU=s.cancel(s.diff(scalar,Us).subs({Us:x,Vs:y}))
dV=s.cancel(s.diff(scalar,Vs).subs({Us:x,Vs:y}))
ck('candidate_contact_value',cs.subs({Us:x,Vs:y}))
ck('candidate_contact_U_normal',s.diff(cs,Us).subs({Us:x,Vs:y}))
ck('candidate_contact_V_normal',s.diff(cs,Vs).subs({Us:x,Vs:y}))
for name,normal,divisor in [('E',E,v),('Qt',Q,v),('xi',xi,u)]:
    ck('candidate_contact_'+name+'_normal',at_contact(s.diff(candidate,normal).subs(zero)/divisor))
defect=dE*v*E+dQ*v*Q+dXi*u*xi+(dU/y)*U*V+(dV-x*dU/y)*V+d0-y*dV
ck('full_original_parent_six_contact_balance_identity',parent-candidate-defect)
rho=m+r*Tm*x/2
rad_completed=C/t**2*(Fb-r*(1-rho/C)*Ft)**2+r*r/t**2*(T0+2*rho-rho*rho/C)*Ft**2
ck('joint_radial_pure_source_completion',rad-rad_completed)
TD=RD-u*v*xi/h
gamma=2*bp/h+2*D*j/r-2*t*B*th/r
ck('entire_remaining_xi_coupling',2*bp*Q*RD+g*u*F*xi-2*m*u*v*Q*xi-(2*bp*Q*TD+g*u*Ft*xi+gamma*u*v*Q*xi))
# Use k,c for an exact conductor with source x=k^2, a=eta c^2.
k,c,Rc,Rroot,J=s.symbols('k c Rc Rroot J',nonzero=True)
rc=c*k*v/u*E+c*k*v*v/u-k*v
jc=u*v-k*k/c
hh=c*c*v*(v+E)/u-u
rd=v*(u*u-k*k)
ck('full_D_circuit_conductor',rd-(u*jc+k*rc-k*k/c*hh))
# Bare-F/Fbar conflict remains a genuine distinction.
ck('radial_difference_contains_nu',Fb-r*Ft-((1-r)*F+t*v*P))

# Extra coupled row cancels the formerly O(1) E--angular cross.
Ws,Zs,kap,ll=s.symbols('W Z kappa lambda')
es=t*u*Ws-v*Zs
hs=t*c*c*v*Ws-u*Zs
ts=t*c*Ws-Zs
rcs=k*v*ts
js=u*v-k*k/c
ps=c*k*v/u
ck('extra_row_angular_polarization',es*hs-(u*v*ts**2-t*(u-c*v)**2*Ws*Zs))
extra=2*ll*k*k/c*u*v*ts**2
ck('extra_row_principal_cancellation',extra+kap*h*k*k/c*es*hs-(k*k/c*(2*ll+kap*h)*u*v*ts**2-kap*h*t*k*k/c*(u-c*v)**2*Ws*Zs))
ck('negative_small_extra_fraction_conductor',k*k*(k/ps)*rcs**2-(U*rcs**2-k*u*js*rcs*ts))
fbstate=t*u*v*Ws-k*k/(t*c*c)*t*Zs
ck('Z_unit_radial_constant_conductor',fbstate/t-((Ws/Zs)*js*Zs+k*k/(t*c*c)*ts))
# This conductor uses only the pure-testing Z inverse on a Z-unit chart.
Qts=s.symbols('Qts')
Pstate=es/t-Qts
ck('Z_unit_remaining_gamma_allocation',u*v*Qts*xi-(U*(Ws/Zs)*es*xi-u*xi/(t*Zs)*es**2-u*v*Pstate*xi))
out={'status':'PASS','count':len(checks),'checks':checks,'scope':'Whole original C1 parent reassembly under six stationary-contact balances, exact joint radial completion and extra-row conductors. These identities alone do not admit C14.3b.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
