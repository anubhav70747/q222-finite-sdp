"""Small exact sparse-polynomial arithmetic. Python standard library only."""
from fractions import Fraction
import gzip
import json

VARIABLES = ('L', 'V', 'U', 'P', 'b', 'K', 'a', 't')
WEIGHTS = (2, 9, 1, 1, 6, 1, 0, 0)

def rational(x):
    if isinstance(x, (int, Fraction)):
        return x
    return Fraction(x) if '/' in x else int(x)

def divide(a, b):
    if isinstance(a, int) and isinstance(b, int):
        q, r = divmod(a, b)
        return q if not r else Fraction(a, b)
    q = Fraction(a, b)
    return q.numerator if q.denominator == 1 else q

def add_into(out, source, shift=None, factor=1):
    for m, c in source.items():
        n = tuple(x+y for x, y in zip(m, shift)) if shift is not None else m
        value = out.get(n, 0) + factor*c
        if value:
            out[n] = value
        else:
            out.pop(n, None)
    return out

def add(a, b):
    return add_into(dict(a), b)

def subtract(a, b):
    return add_into(dict(a), b, factor=-1)

def scale(a, c):
    return {m:v*c for m,v in a.items() if v*c}

def multiply(a, b):
    out = {}
    for m, c in a.items():
        add_into(out, b, m, c)
    return out

def power(a, n):
    assert n >= 0
    dimension = len(next(iter(a))) if a else 8
    out = {(0,)*dimension: 1}
    while n:
        if n & 1:
            out = multiply(out, a)
        n >>= 1
        if n:
            a = multiply(a, a)
    return out

def grevlex(m):
    return sum(m), tuple(-x for x in reversed(m))

def leading(p, main_count=6):
    m = max(p, key=lambda x: grevlex(x[:main_count]))
    return m, p[m]

def weight(m):
    return sum(x*y for x,y in zip(m, WEIGHTS))

def homogeneous_weight(p):
    values = {weight(m) for m in p}
    assert len(values) == 1, values
    return values.pop()

def rows(p):
    return [[list(m), str(c)] for m,c in sorted(p.items(), reverse=True)]

def from_rows(items, dimension=8):
    out = {}
    for m, c in items:
        assert len(m) == dimension and all(isinstance(x,int) and x >= 0 for x in m)
        m = tuple(m)
        assert m not in out, ('duplicate exponent', m)
        c = rational(c)
        assert c
        out[m] = c
    return out

def save_gzip(path, obj):
    data = json.dumps(obj, separators=(',', ':'), sort_keys=True).encode()
    with open(path, 'wb') as raw:
        with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as stream:
            stream.write(data)

def load_gzip(path):
    with gzip.open(path, 'rt') as stream:
        return json.load(stream)

def roots():
    def monomial(**kw):
        return {tuple(kw.get(x,0) for x in VARIABLES):1}
    four = [monomial(L=1,V=1), monomial(P=1,U=1,V=1),
            monomial(P=1,K=1,b=1,U=1,L=1), monomial(P=2,K=3,b=1)]
    squares = [multiply(x,x) for x in four]
    out = [subtract(monomial(P=2,V=2),monomial(P=2,b=2,U=2,L=2))]
    out += [subtract(squares[i],squares[j]) for i in range(4) for j in range(i+1,4)]
    out += [subtract(multiply(four[0],four[1]),multiply(four[2],four[3])),
            subtract(multiply(four[0],four[2]),multiply(four[1],four[3])),
            subtract(multiply(four[0],four[3]),multiply(four[1],four[2]))]
    out += [subtract(monomial(U=2,L=2,V=2),monomial(P=4,K=8,b=2))]
    return out

def component_polynomial(items):
    """Native order (delta,k,b,a,t,u,w,v) -> separate square-root ring."""
    out = {}
    for m,c in items:
        d,k,b,a,t,u,w,v = m
        mm = (2*w,2*v,2*u,2*d,b,2*k,a,t)
        assert mm not in out
        out[mm] = rational(c)
    return out

def component_targets(component):
    F = component_polynomial(component['scalar_terms'])
    leading_part = component_polynomial(component['leading_terms'])
    return {'E0':subtract(F,leading_part),
            'L1':component_polynomial(component['linears_terms'][0]),
            'L2':component_polynomial(component['linears_terms'][1])}
