"""Four new whole-polynomial checks for the j-opening reciprocal chart."""
import json
from pathlib import Path
import sympy as s
checks={}
def zero(name,expr):
    val=s.factor(s.together(expr))
    if val!=0:raise AssertionError((name,val))
    checks[name]=True
    print("PASS",name,flush=True)
u,v,p,q,n,xi,C,A,h,j,eta,m,al,be,U,V=s.symbols("u v p q n xi C A h j eta m alpha beta U V")
R0=1+j-eta;g=R0-eta*h*U;th=1-h;Bx=be+s.Rational(1,2)
Du=1+U;Dv=1+V
scalar=m*(V*V*(1+g*U)**2/(eta**2*U)-2*th*V*(1+g*U)/eta+th*th*U)
scalar+=C*Dv*(1-g)**2*V/eta**2+A*Du*Dv*g*g*V/eta**2
scalar+=(al+s.Rational(1,2))*Du*g*g*V*V/eta**2-(2*al+1)*Du*g*V/eta+al*Du+Bx*th*th*U*Dv-Du*V/2
cF=(2*m*R0+C*(1-R0)**2+(A+al+s.Rational(1,2))*R0*R0)/eta**2
qV=(C*(1-R0)**2+A*R0*R0)/eta**2-2*m*th/eta-(2*al+1)*R0/eta-s.Rational(1,2)
qU=al+(m+Bx)*th*th
fA=m*V*(g*g-2*eta*h)/eta**2-2*m*th*g/eta
fA+=C*Dv*(2*h*(1-R0)/eta+h*h*U)
fA+=(A*Dv+(al+s.Rational(1,2))*V)*(g*g/eta**2-2*R0*h/eta+h*h*U)
fA-=(2*al+1)*(g/eta-h)
fA+=Bx*th*th-s.Rational(1,2)
zero("actual_j_printed_fA_polynomial",scalar-m*V*V/(eta**2*U)-cF*V*V-qV*V-al-qU*U-fA*U*V)
Y0=(1+j)*p-q-n;shift=-h*u*u*q+u*v*xi;Y=Y0+shift;du=1+u*u;dv=1+v*v
actual=C*dv*(p-Y)**2+A*du*dv*Y*Y
actual+=((p-Y0-q)**2+du*(v*v*Y*Y-2*q*Y-q*q))/2
base=C*(p-Y0)**2+A*Y0*Y0+(p-Y0)**2/2-p*q
high=C*(v*v*(p-Y0)**2-2*dv*(p-Y0)*shift+dv*shift*shift)
high+=A*((du*dv-1)*Y0*Y0+2*du*dv*Y0*shift+du*dv*shift*shift)
high+=du*v*v*Y*Y/2-u*u*q*Y+(h-s.Rational(1,2))*u*u*q*q-u*v*q*xi
zero("actual_j_complete_higher_angle_identity",actual-base-high)
lead={q:eta*p,n:0,xi:0,j:0,h:1,C:1/(2*eta),A:eta/(2*(1-eta))}
lim=s.expand(high.subs(lead))
zero("actual_j_reciprocal_R_pivot",lim.coeff(u,2).coeff(v,0)/p**2-eta/2)
zero("actual_j_reciprocal_S_pivot",lim.coeff(u,0).coeff(v,2)/p**2-s.Rational(1,2))
out={"status":"PASS","checks":checks,"count":len(checks),"scope":"Printed scalar polynomial and complete reciprocal higher-angle quadratic, including both strict soft pivots; companion actual-j checker covers all three first normals."}
Path(__file__).with_suffix(".json").write_text(json.dumps(out,indent=2)+"\n")
