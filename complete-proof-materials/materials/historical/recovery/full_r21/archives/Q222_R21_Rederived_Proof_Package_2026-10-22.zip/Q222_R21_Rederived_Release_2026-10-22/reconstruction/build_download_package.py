#!/usr/bin/env python3
"""Build a valid, honestly labelled archive from all recovered proof material.

The damaged saved ZIP is not carried into the new archive.  Its complete
members and the two independently restored source inputs are preserved at
the exact file-content level.  The missing late completed release is not
represented as recovered.
"""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import zipfile

WORK=Path(__file__).resolve().parent.parent
REC=WORK/'reconstruction'
OUT=WORK/'output'
ROOT=OUT/'Q222_R21_Reconstruction'
NAME='Q222_R21_Reconstruction.zip'
BASE=REC/'salvaged_checkpoint/Q222_Recovery_Continuation_R21_2026-10-21'

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def copy(source,relative):
    destination=ROOT/relative
    destination.parent.mkdir(parents=True,exist_ok=True)
    shutil.copyfile(source,destination)

def write(relative,text):
    destination=ROOT/relative
    destination.parent.mkdir(parents=True,exist_ok=True)
    destination.write_text(text)

def dump(relative,value):
    write(relative,json.dumps(value,indent=2,ensure_ascii=False)+'\n')

def stage():
    OUT.mkdir(exist_ok=True)
    if ROOT.exists():
        assert ROOT.parent==OUT and ROOT.name=='Q222_R21_Reconstruction'
        shutil.rmtree(ROOT)
    ROOT.mkdir()
    old=json.loads((BASE/'MANIFEST_SHA256.json').read_text())
    for rel,expected in old['files'].items():
        source=BASE/rel
        assert source.is_file() and sha(source)==expected,rel
        copy(source,'reconstruction/salvaged_checkpoint/'+BASE.name+'/'+rel)
    copy(BASE/'MANIFEST_SHA256.json','reconstruction/salvaged_checkpoint/'+BASE.name+'/MANIFEST_SHA256.json')

    context=REC/'restored_context'
    for source in sorted(context.rglob('*')):
        if not source.is_file():
            continue
        rel=source.relative_to(context)
        if '__pycache__' in rel.parts or 'validation' in rel.parts or source.suffix=='.pyc':
            continue
        copy(source,'reconstruction/restored_context/'+rel.as_posix())

    # The intact saved checkpoint is immutable.  Separately saved variants
    # are retained in provenance rather than overwriting its manifest bytes.
    for name in ['Q222_Recovery_Proofs_R21.pdf','FRONTIER_R21.json','Q222_End_to_End_Checklist_R21.txt']:
        copy(REC/'source_archives'/name,'provenance/separately_saved/'+name)
    copy(REC/'salvaged_checkpoint/SALVAGE_REPORT.json','provenance/SALVAGE_REPORT.json')
    copy(REC/'saved_checkpoint_manifest_recovery.json','provenance/saved_checkpoint_manifest_recovery.json')
    copy(REC/'salvage_zip.py','provenance/salvage_zip.py')
    copy(WORK/'project_sources/01-Q222_SXDEG2_ZERO_COMPUTER_FROZEN_2026-08-31-1-.zip',
         'provenance/user_input/Q222_SXDEG2_ZERO_COMPUTER_FROZEN_2026-08-31.zip')
    for source in sorted((WORK/'recovery/weak_c2').rglob('*')):
        if source.is_file():
            copy(source,'provenance/surviving_temporary_records/'+source.relative_to(WORK/'recovery/weak_c2').as_posix())
    # Preserve the surviving script at the path cited by the recovered checklist.
    copy(WORK/'recovery/weak_c2/preserved_tmp/build_r21_checklist.py',
         'recovery/weak_c2/preserved_tmp/build_r21_checklist.py')
    for source in sorted((REC/'verification').glob('*')):
        if source.is_file() and source.suffix in ('.txt','.json'):
            copy(source,'reconstruction/verification/'+source.name)

    pdfdir=REC/'pdf_supplement'
    copy(pdfdir/'Q222_R21_Reconstructed_Arguments.pdf','Q222_R21_Reconstructed_Arguments.pdf')
    for source in sorted(pdfdir.rglob('*')):
        if source.is_file() and (source.suffix in ('.tex','.json') or source.name=='Q222_R21_Reconstructed_Arguments.log'):
            copy(source,'reconstruction/pdf_supplement/'+source.relative_to(pdfdir).as_posix())
    copy(REC/'package_verify.py','verify.py')
    write('requirements-replay.txt','sympy==1.14.0\nmpmath==1.3.0\n')
    # Reader-facing aliases are copies of frozen reviewed inventories.
    for name in ['CURRENT_RECOVERY_CHECKLIST_46.txt','CURRENT_RECOVERY_CHECKLIST_46.json',
                 'DEPENDENCY_RECONSTRUCTION_MAP.txt','DEPENDENCY_RECONSTRUCTION_MAP.json']:
        copy(context/'routing'/name,name)

    earlier_files=len(old['files'])
    status={
      'title':'Q222 R21 reconstruction download',
      'created_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
      'late_release_status':'PARTIAL_RECONSTRUCTION',
      'original_completed_zip_recreated':False,
      'original_549_page_pdf_recreated':False,
      'earlier_saved_checkpoint':{
        'status':'EXACT_FILE_CONTENT_RECOVERY',
        'original_manifest_bound_files':earlier_files,
        'fresh_verifier_status':'PASS',
        'mathematical_status':'Global theorem remains OPEN in this earlier checkpoint.',
        'pdf_pages':71,
        'pdf_sha256':sha(BASE/'Q222_Recovery_Proofs_R21.pdf'),
        'recovery_method':'1200 manifest-bound files recovered from complete CRC-valid local ZIP members, plus two source inputs independently restored with matching manifest hashes.'},
      'new_supplement':{
        'filename':'Q222_R21_Reconstructed_Arguments.pdf','pages':30,
        'sha256':sha(pdfdir/'Q222_R21_Reconstructed_Arguments.pdf'),
        'scope':'Fresh physical/normalization arguments; conditional assembly; actual-source R1 scalar and full local conductor; structural R2 entry; full-state/sign/projective reduction; intact bounded-Gram lemma.'},
      'fresh_checker_groups':[
        {'name':'actual source and scalar','assertions':44},
        {'name':'small normal helpers','assertions':6},
        {'name':'full local R1 conductor','assertions':43},
        {'name':'structural R2 source entry','assertions':17},
        {'name':'full-state/sign/projective join','assertions':24},
        {'name':'physical complete-parent normalization','assertions':12}],
      'checker_count_note':'These six fresh groups are not the historical final-release replay suites. Their assertions overlap and are not summed as a completeness total.',
      'current_checklist_ids':46,
      'logical_dependency_nodes':62,
      'missing_global_inputs':[
        'Late C14.1b residual and C14.4 completion bodies and their complete CJ join.',
        'The bounded-q and outer-angular R1 bodies and whole-source join.',
        'Missing R2/R3/R4 late terminal certificates and source/testing joins.',
        'Positive-scale terminals and uniform-C1 replacements not recovered as complete bodies.',
        'Complete late UL/UC/HJ/global assembly proof and original final dependency/release manifests.'],
      'current_global_conclusion':'Local-certificate hypothesis LC remains unestablished by the recovered materials; universal tensor-SOS and finite-lift existence are conditional in this reconstruction.',
      'explicit_representation_items':'E1-E3 remain additional undelivered constructive extraction tasks; they are distinct from the current missing existence-proof inputs.',
      'review_scope':'Analytical and separate-agent review within the same model system, plus targeted exact algebra. Not external peer review or proof-assistant formal verification.'}
    dump('RECOVERY_STATUS.json',status)
    dump('provenance/HISTORICAL_LATE_RELEASE_IDENTIFIERS.json',{
      'status':'HISTORICAL_REPORTED_IDENTIFIERS_ONLY',
      'current_bytes_available':False,
      'archive':{'name':'Q222_Completed_Proof_R21_2026-10-21.zip','bytes':13345116,
                 'sha256':'ab973b767026fe6dbf8ad6c2f3137ae83a694ec87555672ef6ea40c8864194ea'},
      'pdf':{'name':'Q222_Completed_Proof_R21.pdf','pages':549,'bytes':3948973,
             'sha256':'27deab0fa3c225ec41e121c07b339fc04842edaa79fc70fea2285e8adbd18c1d'},
      'reported_original_inventory':{'proof_components':226,'manifest_bound_files':1667,
           'checklist_complete':43,'additional_explicit_representation_items_undelivered':3,
           'R20_inherited_hashes':1142,'analytical_dependencies':266,
           'dependencies_including_printed_inputs':299,'recorded_symbolic_groups':54},
      'warning':'These identifiers and prior claims identify the target release. They have not been reverified against the missing original bytes and do not certify this reconstruction.'})
    dump('provenance/SOURCE_ARCHIVE_RECOVERY.json',{
      'damaged_saved_archive':{'name':'Q222_Recovery_Continuation_R21_2026-10-21.zip',
         'bytes':10683255,'sha256':'c6667dc25f11f7acb87a03c885a56ef5bc1e6c800c506de7244038e0c86689b4',
         'problem':'Truncated in final nested R19 ZIP entry; no central directory/end-of-central-directory record.',
         'complete_crc_verified_members':1201,'complete_manifest_bound_members':1200,
         'damaged_container_included':False},
      'restored_source_inputs':[
         {'name':'Q222_Pro_Handoff_R19_2026-10-21.zip','bytes':5769365,
          'sha256':'b163bffc06e59daefc9a4af3a0b888a440957b06e06ac0c91e225439b33fc96d'},
         {'name':'Q222_SXDEG2_CONSOLIDATED_PARCHMENT_FINAL_2026-08-30.md','bytes':76839,
          'sha256':'e268a6ae1c11dd02b5819064fa7e8187173074050d92f3204e703dd46f574731'}],
      'restored_earlier_checkpoint_manifest_match':True,
      'separate_saved_pdf_variant':'The separately saved PDF has a different byte hash, but all 71 pages have identical extracted text to the manifest-bound PDF. Both are preserved without overwriting the checkpoint.'})
    write('READ_FIRST_R21_RECONSTRUCTION.txt',f'''Q222 R21 RECONSTRUCTION DOWNLOAD

STATUS: A VALID RECOVERY ARCHIVE; THE LATE COMPLETED RELEASE IS NOT FULLY RESTORED.

This ZIP contains all recovered proof material and the freshly rederived
arguments produced in this recovery. It is not the original 549-page completed
R21 release and does not carry forward that release's reported 43 COMPLETE
checklist statuses. The original completed ZIP, full manuscript, full source
tree, unchanged R20 checkpoint and final 1,667-file manifest were not recovered.

START HERE

1. Q222_R21_Reconstructed_Arguments.pdf is the new 30-page recovery supplement.
   It establishes the physical/normalization and scoped local results named
   below and states the final assembly condition LC explicitly.
2. CURRENT_RECOVERY_CHECKLIST_46.txt preserves all 46 original criterion IDs,
   separates historical claims from current evidence, and records what remains.
3. DEPENDENCY_RECONSTRUCTION_MAP.txt gives the 62-node reconstruction map.
4. RECOVERY_STATUS.json gives machine-readable scope and provenance.
5. Run python verify.py to check the delivered hashes and the intact earlier
   checkpoint. Optional: install requirements-replay.txt, then run
   python verify.py --replay quick for six fresh exact suites in a temporary copy.

WHAT WAS RECOVERED EXACTLY

The earlier saved Q222_Recovery_Continuation_R21_2026-10-21 archive was damaged.
Its 1,201 complete local members passed length and CRC checks; these comprise
the original root manifest and 1,200 manifest-bound files. The remaining two
source inputs were recovered independently and matched their expected hashes.
All {earlier_files:,} manifest-bound files now match, and the earlier checkpoint's own
verifier passes. Its 71-page PDF and full inherited R19 material are present at:

reconstruction/salvaged_checkpoint/Q222_Recovery_Continuation_R21_2026-10-21/

The earlier verifier explicitly prints: Global theorem remains OPEN.
Its original bytes and scope have been preserved. The damaged ZIP container
itself is not included in this new archive.

WHAT WAS RECONSTRUCTED FRESHLY

- Physical model: common-embedding effect dilation, real qubit blocks, exact
  nine-atom convexification, semialgebraicity, transfer and normalization.
- R1 actual source/scalar: six native stationary weights, physicality bounds,
  circuit allocations and the effective current reserve, including n=0.
- R1 full local conductor: the whole parent and both unrestricted state normals
  for the specified unbounded-source-ratio/local-angle sector, with arbitrary
  positive state ratio and all printed source openings.
- Full-state/sign/projective reduction: exact gauges, state axes, arbitrary
  positive ratio normalization and literal projective endpoints.
- R2 structural entry: physicality and scale bounds, source normalizations and
  exact two-packet extraction. Positivity of its remaining parent is not proved.
- Conditional global assembly: separated source conic and testing convex
  closure, preserving the affine constant and independently labelled fields.

These new files are under reconstruction/restored_context/. The original
stationary formulas and bounded-Gram lemma used by them are actual recovered
source bodies. Exact checks corroborate the displayed identities; they do not
substitute for the analytical bounds. There are six CURRENT checker groups,
distinct from the historical final-release suites, and their counts overlap.

WHAT STILL PREVENTS COMPLETE RESTORATION

Missing later bodies include the residual C14.1b and C14.4 completions, bounded-q
and outer-angular R1 charts, R2/R34 terminal closures, positive-scale and uniform
C1 replacements, and complete UL/UC/CJ/HJ/global assembly sources. The full
original final dependency inventory is absent. The map lists the known missing
premises without inventing filenames or proofs for the unrecorded inventory.

Consequently, LC and the current universal tensor-SOS/finite-lift conclusion
remain open or conditional in this reconstruction. E1-E3 (explicit features,
an evaluated pencil and its validation) also remain undelivered; those separate
constructive tasks are not the cause of the current missing existence proof.

HISTORICAL RECORDS

Retained completion reviews, assembly fragments, old generation scripts and
older parchment claims are preserved for provenance. Their COMPLETE/PASS text
refers to earlier work and does not certify absent current proof bodies. The
original completed-release filenames, sizes and reported hashes are recorded
in provenance/HISTORICAL_LATE_RELEASE_IDENTIFIERS.json for identification only.

PATHS AND REBUILDING

Relative paths beginning with reconstruction/ refer to this archive's root.
Absolute /workspace/... paths in retained records describe the former working
location and are historical provenance. The fresh verifier and six fresh
checkers use portable relative paths. Rebuild the supplement by running
pdflatex twice on reconstruction/pdf_supplement/Q222_R21_Reconstructed_Arguments.tex
from that directory. Formatting-only exposition changes are recorded in its
COMPONENT_PROVENANCE.json; original proof sources remain separate.

Review consists of same-system analytical and separate-agent review with exact
symbolic corroboration. It is not external peer review or formal verification.
''')
    write('BUILD_SCOPE.txt','This archive was assembled only after the listed files existed and were verified. The ZIP is closed before its CRC and archived SHA-256 audit. PASS means package integrity and the specified local checks, not restoration of the missing global proof.\n')
    return status

def manifest():
    records={}
    for p in sorted(ROOT.rglob('*')):
        if p.is_file() and p!=ROOT/'MANIFEST_SHA256.json':
            records[p.relative_to(ROOT).as_posix()]={'bytes':p.stat().st_size,'sha256':sha(p)}
    dump('MANIFEST_SHA256.json',{'algorithm':'SHA-256',
         'scope':'Every delivered file except this manifest; package integrity does not certify missing mathematical premises.',
         'file_count':len(records),'files':records})
    return records

def make_zip(records):
    target=OUT/NAME
    pending=OUT/(NAME+'.building')
    with zipfile.ZipFile(pending,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=6,allowZip64=True) as archive:
        for p in sorted(ROOT.rglob('*')):
            if p.is_file():
                archive.write(p,ROOT.name+'/'+p.relative_to(ROOT).as_posix())
    with pending.open('rb') as stream:
        os.fsync(stream.fileno())
    with zipfile.ZipFile(pending) as archive:
        assert archive.testzip() is None,'ZIP CRC failure'
        assert len(archive.infolist())==len(records)+1
        for rel,entry in records.items():
            value=archive.read(ROOT.name+'/'+rel)
            assert len(value)==entry['bytes'] and hashlib.sha256(value).hexdigest()==entry['sha256'],rel
    pending.replace(target)
    result={'filename':target.name,'path':str(target),'bytes':target.stat().st_size,
            'sha256':sha(target),'manifest_bound_files':len(records),
            'zip_entries':len(records)+1,'zip_crc':'PASS','archived_hashes':'PASS',
            'scope':'Valid partial-reconstruction archive; not the missing completed late R21 release.'}
    (OUT/'Q222_R21_Reconstruction_DOWNLOAD_INFO.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1]=='--finish':
        records=manifest()
        make_zip(records)
    else:
        stage()
        records=manifest()
        print(json.dumps({'staged':str(ROOT),'manifest_bound_files':len(records)}))
