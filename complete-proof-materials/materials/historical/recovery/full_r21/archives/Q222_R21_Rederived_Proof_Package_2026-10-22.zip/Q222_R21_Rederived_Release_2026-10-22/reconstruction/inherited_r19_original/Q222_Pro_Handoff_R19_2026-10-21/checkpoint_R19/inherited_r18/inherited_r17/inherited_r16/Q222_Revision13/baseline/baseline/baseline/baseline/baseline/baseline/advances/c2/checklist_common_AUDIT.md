# Independent audit of the C2 unbounded-n pitchfork

## Current verdict

**Local certificate: PASS. All-tests corollary: PASS.**

The result covers an original physical C2 source with `lambda=beta=0`, bounded-unit `d,c,alpha`, bounded nonnegative `m,A,D`, arbitrary nonnegative `n`, and a finite stationary zero contact with `u_c=k>0` infinitesimal and `v_c=a>0` a bounded unit. The local theorem certifies every real or complex projective state at independent tests with `u` infinitesimal or zero and residue `v=a`; the appended corollary extends this to every independent projective measurement pair. Neither result assumes a comparison between independent `u` and source `k`, or between `n` and `k`.

## Sources inspected

- `c2_unbounded_n_pitchfork.tex` in this directory.
- `output/structural_proof/c2_pitchfork.tex` for the inherited bounded-source pitchfork and boundary Schur calculation.
- `output/structural_proof/physical_core.tex` for the original parent, determinant coefficients, and `t_i` definitions.
- `output/structural_proof/positive_d_geometry.tex` and the inherited source-partition dispatch for commuting and projective endpoint identities.

## Detailed checks

1. **The divided determinant coefficients are exact and bounded.** Setting `N=d+2n` gives `t5=N`, `t7=N+2m`, and `t1=N+2D`. The six expressions (CN1) follow directly from the original determinant coefficients. `1/N` and `n/N` are bounded even when `n` has no residue. The remaining displayed `t_i` are positive bounded units. Dividing the stationary equations by this pure source factor is legitimate.

2. **The entry does force A,D to be units.** The first stationary equation gives `m=O(A k^4)`, and the second compares `A` and `D` by positive unit factors plus smaller terms. If both had zero residue, restricting the original parent to `X=0` removes the entire possibly unbounded `n` packet. The remaining bounded physical restriction has the explicitly negative boundary minimum when `A=D=m=0`, a contradiction. No residue is taken of `n` itself. Consequently `A,D` are units and `m/k^4` is a positive unit.

3. **The full hard normalization is valid.** In coordinates `(sqrt(N) X,Y,Z)` the `X` diagonal has residue `2(1+a^2)`, not an unbounded coefficient. Its couplings to `Y,Z` are `O(k/sqrt(N))`, and its coupling to `W` is `O(k^2/sqrt(N))`. The `Y,Z` block is the positive form (CN3). The source-field block solve therefore gives `Y_c,Z_c=O(k)` and `N X_c=O(k^2)`. Thus for `X_c=x k^2`, the quantities `N x`, `n x`, and `n x^2` are bounded. This stronger estimate, rather than bounded `x` alone, is essential.

4. **The entire graph scalar has bounded coefficients.** The sole potentially unbounded contribution is `4n x^2 U^2(1+U)(1+v^2)`, which is bounded by the preceding estimate. The original scalar is exactly `4m v^2+U H(U,v)`. Exact contact and angular stationarity give all three displayed values of `H,H_U,H_v`. Substitution into its finite Taylor decomposition gives (CN5) exactly. After `U-K=R+(K/a)(v-a)`, the terms allocate to the quadratic ideal of `(R,T)`. The `R` residue pivot is the positive unit `gamma`.

5. **All first normals are included.** The only additional large-event contribution is `8n x(1+U)(1+v^2)` in `L_X`, which is bounded. Dividing the entire `X` derivative by `sqrt(N)` gives the coefficient of the scaled state normal. Formula (CN7) follows by direct substitution of the monic contact division; the cancellation of `-8m v` is exact. Its `X`-normal coefficients on `R,T` are infinitesimal. For the `Y,Z` normals the `R` coefficients are infinitesimal, and only the stated `T` coefficients can survive in residue. This is a full-normal calculation, not merely a contact evaluation.

6. **The quadratic normal remainder is bounded.** Its `n` contribution is exactly `4(n/N)(1+U)(1+v^2) E_X^2`. Every other source coefficient is bounded, and all factors of `1/sqrt(N)` are bounded. Since the parent is quadratic in state coordinates, this accounts for all remaining normal terms; no higher-normal remainder is omitted.

7. **The remaining Schur complement is strictly positive.** The boundary coefficient of `u^2` contains neither the `n` packet nor the `X` graph, which begin at order `u^4`. The coefficients `Q10,Q12` in (CN8) follow by dividing the inherited determinant coefficients by `N` before taking residues. Both are positive. Contact and first-normal equations make the residue graph state minimize this boundary coefficient at `v=a`; scalar angular stationarity gives its first derivative zero. Hence the quartic bracket is exactly `Q12(v^2-a^2)^2`. Its half second derivative is the positive displayed expression. Together with the separate `X` and `R` pivots, this makes the complete five-root residue Gram positive definite.

8. **All projective states are covered locally.** The `W=1` calculation is polynomial and quadratic in state coordinates. Homogenizing every graph normal and replacing the last two roots by `R W,T W` gives the same identity for arbitrary `W,X,Y,Z`, including `W=0`. The roots may be unbounded; only the Gram coefficients must be bounded. Each source radical remains in the coefficient field. Pure testing normalization and real/imaginary splitting are therefore legitimate.

## Completed all-tests join

9. **Unmatched finite remote residues.** Retaining the entire original `m,n` packets leaves a bounded exact Gram on `(X,Y,Z,uW)`: every remaining occurrence of `W` carries a factor `u`. Its `X` pivot is `2d(1+v^2)`; the YZ block is precisely the same positive boundary block, and its soft Schur complement is `f(v)`. Removing `m` does not alter this residue because `m=O(k^4)`. Removing `n` changes only the independent positive X mass. The quartic factor is positive away from both matched remote residues, including `v=0`. The exact Bob sign identity handles the negative matched residue.

10. **The Bob-infinite endpoint.** After multiplying by the pure testing homogeneous factor, the same four-root Gram has hard block `diag(4(c+A+alpha)+2d,4D)` and X pivot `2d`. The soft Schur complement is `8 Q12/det(B_infty)>0`. All are residues of a bounded polynomial in the reciprocal testing coordinate; no limit or inverse in the tensor ring is used. This includes literal Bob infinity.

11. **The other open commuting axes.** After dividing by the pure source `d`, capping `c,A,D,alpha` at their positive-unit minimum and retaining all excesses plus all `m,n` packets is exact. The selected bounded polynomial need not remain globally physical. At each remaining open commuting axis, the printed core squares and selected positive event packets have trivial common state kernel. Thus their state-matrix Gram is strictly positive for arbitrary projective state coordinates. This never takes a residue of the original unbounded `n`.

12. **The two Alice-infinite corners.** I independently expanded the selected homogeneous parent to degree two at each remaining zero ray. At `(1/u,v)=(0,0)`, its selected state form has sole zero ray X; with `X=1`, its quadratic part is exactly (CN10). At `(1/u,1/v)=(0,0)`, its sole zero ray is Z; with `Z=1`, its quadratic part is exactly (CN11). Both displayed sums of positive squares have full rank in their five local coordinates. There are no constant or linear terms. Every higher monomial can therefore be allocated to a pair of coordinate roots with an infinitesimal coefficient. States off the sole zero ray have a positive residue evaluation and hence a scalar strict-residue certificate. All capped excesses and the unbounded original n packet remain separate positive squares.

13. **Exhaustion.** The local theorem, its sign copy, the unmatched finite and Bob-infinite certificates cover the complete u-zero residue axis. The three other open axes and two Alice-infinite corners cover all remaining commuting residues. The inherited theorem for arbitrary physical sources covers all noncommuting residues. Homogeneous angle factors, pure source factors, projective state factors, and complex splitting are restored separately. No missing projective state or literal endpoint remains under the stated source hypotheses.

## Scope limitation

This audit does not certify every source with `c/d` and `alpha/d` strong: the other retained coefficients except `n` must still be bounded after the chosen positive-unit `d` normalization, and the actual finite contact has the stated single-small-angle geometry. It does not complete the entire C2 or global source cover.
