# Exact double-infinitesimal C2 family: first remaining Gram gate

Status: **research checkpoint, no new tensor-SOS admission**. This is a
failure of the direct bounded-Gram extension, not a counterexample to the
desired tensor-SOS conclusion. The proved strong finite pitchfork remains
unchanged.

## Exact physical source

Let `x>0` be infinitesimal, `k=sqrt(x)`, and choose the original positive
C2 rational data

```
c=k, a=1, b=1/x, r=1/4, t=1/2, d=1.
```

The unchanged source formulas give

```
n     = (8-5x^2)/(16(1+x)^2),
m     = 3x^2(3x+4)/(16(1+x)(4+x-2x^2)),
C=alpha = (4-x)/(8x),
A     = x(x+4)(3x+4)/(32(2-x)(1+x)^2),
D     = (2-x)(3x+4)/(16x(1+x)).
```

Every retained coefficient is positive. The original chart gaps are

```
h=1/x-1/2, g=1/x+1/4-x/2, j=1/2+x/4,
1-xh=x/2, b-xr=1/x-x/4,
```

and are all positive. The inherited exact source identities and
stationary-contact/inertia theorem therefore give a physical source at
the actual contact `u=v=k`. After normalizing `W=1`, its state is exactly

```
(W,X,Y,Z)=(1,-k^3/4,k(1-x/2),x).
```

Thus `C,alpha,D` diverge like `1/(2x)`, whereas `A~x/4`,
`m~3x^2/16`, and `n~1/2`. This lies outside the proved strong
finite-pitchfork theorem because its second actual angle is infinitesimal.

## Exact contact graph and first failed boundedness gate

A polynomial graph matching every angle-sign copy is

```
Xg=-u^2 v W/4, Yg=(1-x/2)uW, Zg=uvW.
```

Writing `U=u^2,V=v^2`, its retained amplitudes are exactly

```
rg=(x/2)uW,
pg=-(x/2)uvW,
Jg=u[x/2-V-UV/4]W,
Rmg=v[1+U/4-xU/2]W.
```

Use `N=1+2n`, which is a bounded unit, and centered normals

```
EX=sqrt(N)(X-Xg),
Er=sqrt(C)(r-rg),
Ep=sqrt(alpha)(p-pg).
```

The exact original amplitude relation is

```
J=(1+v^2)r+uvX-uv^2W+vp.
```

Consequently the original `D` packet contributes the quadratic normal
term

```
4D[(1+v^2)Er/sqrt(C)+uvEX/sqrt(N)+vEp/sqrt(alpha)]^2.
```

Its `EX^2` coefficient is `4(D/N)u^2v^2`. Since `D~1/(2x)`, this
coefficient is not in the bounded separated tensor ring for arbitrary
independent infinitesimal tests. The fact that `u,v,k` all have zero
residue does not permit a comparison of `u^2v^2` with `x`.

Centering the entire `D` packet at the exactly matched `Jg` does remove
this raw coefficient from a three-normal Gram if one introduces the
additional original-amplitude root

```
ED=sqrt(D)(J-Jg).
```

But its exact dependence on the three state normals contains

```
ED=(1+v^2)sqrt(D/C) Er
     +uv sqrt(D/N) EX+v sqrt(D/alpha) Ep.
```

The middle coefficient is proportional to `uv/k`, again unbounded in
the separated bounded tensor ring. Treating `ED` as unconstrained loses
the relation that supplies the soft positive Schur contribution. Thus
centering alone does not prove a bounded strict-residue Gram. It remains
a legitimate candidate ingredient; no impossibility of a larger
certificate is asserted.

## Exact scalar conductor information

Let `Phi(U,V)` be the entire graph scalar with `W=1`. Direct expansion
of the unchanged parent gives the two exact slices

```
Phi(x,V) = (4-x)(4+x)(3x+4)/(32(1+x)) (V-x)^2,

Phi(U,x) = x(U-x)^2
           [96+72x+(32+28x-11x^2-10x^3)U]
           /[32(1+x)(4+x-2x^2)].
```

They suggest the two differently scaled soft roots

```
P=u(v^2-x)/sqrt(x),    Q=v(u^2-x).
```

Their natural slice pivots tend to `2` and `3/4`, respectively.
The scalar is even in both angles. It vanishes to second order at the
origin and at all four points `(u,v)=(±k,±k)`; the entire first state
normals vanish at those five points as well.

Over the pure coefficient field, the ideal

```
I=(u(v^2-x), v(u^2-x))
```

is the radical ideal of exactly those five points. Indeed its equations
imply `u^2=v^2`, and its Jacobian is invertible at every zero because
`x>0`. Therefore the scalar lies in `I^2` and each entire first normal
lies in `I`, after pure coefficient localization. This is an ungraded
conductor statement; it does **not** bound its coquotients after the
required source scalings.

The missing step is an exact full-parent allocation on these soft roots
and centered original packet roots that simultaneously (i) keeps all
Gram coefficients bounded without comparing source and test scales,
(ii) preserves the displayed dependence of the `D` normal, and
(iii) has positive residue on the complete hard/soft state system.
Neither scalar membership nor the two positive scalar slices supplies
that step. No all-tests certificate is claimed for this family.
