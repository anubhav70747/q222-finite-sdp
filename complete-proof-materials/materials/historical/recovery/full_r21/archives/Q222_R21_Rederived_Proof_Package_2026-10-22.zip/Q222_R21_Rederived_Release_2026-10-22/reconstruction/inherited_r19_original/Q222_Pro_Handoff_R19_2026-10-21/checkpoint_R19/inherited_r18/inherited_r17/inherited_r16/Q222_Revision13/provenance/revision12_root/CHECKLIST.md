# Q222 revision 12: exact remaining proof obligations

**The global proof remains unfinished. Four original rows are closed; C1.4 and C2.W.HH remain open. No new all-tests source domain is admitted in this revision.**

Every row is intersected with original physicality, positive infinitesimal total scale, and the complement of all admitted domains and exact symmetry images. Listing a residual domain does not prove nonemptiness.

## Completed in this revision

- [x] Exact source identity: 2r Delta n = (1-r)Q - BK.
- [x] Physical bound: B/(1-r) and n/(1-r) bounded; literal r=1 at B>0 gives n<0.
- [x] Full-parent six-root certificate for the formerly degenerate reciprocal-u axis, including n=0.
- [x] Every other nonlocal testing chart and literal projective endpoint on that printed source domain.
- [x] Reduction there to the complete both-infinitesimal local parent.
- [x] Preserve all earlier proofs and failed routes without replaying their check suites.

## Exact remaining checklist

### C1.4

Original native k infinitesimal, zeta noninfinitesimal, L=k^2 zeta. The L-unit subdomains with eta infinitesimal or a positive unit, and the L-unbounded subdomain with eta a positive unit, are now removed. Revision 9 additionally removes IC1: eta,zeta,r,1-r,eta+r-1 positive bounded units.

**Testing scope:** L and eta unbounded: u bounded,v unbounded. L unit with eta unbounded: inherited residual tests, with E~1 and the exact BE source sphere for both noninfinitesimal-L charts. L infinitesimal with eta bounded: only u,v both infinitesimal. L infinitesimal with eta unbounded: only u infinitesimal.

- [ ] **C14.1** — Complete the joint scalar, radial and first-normal allocation. On beta=0 retain the exact contact cancellation and first radial square BR1; allocate the surviving kappa22 t^2 xi^2 packet from BR3, its centered lower terms, every radial first normal, and Zuw, including the 8(ab)b/sigma term through Q=1-b infinitesimal. Then cover beta>0, complementary d0,b0,h/sigma branches and every bounded u.

  **Progress:** BR1-BR3 identify the next exact coefficient; neither a C1 domain nor the beta-zero full parent is yet admitted.

  **Completion criterion:** A finite full-parent Gram controls all w-dependent terms through d0=0 and b0=0, every bounded u, independent testing rate and projective join.

- [ ] **C14.2** — For L a positive unit and eta unbounded, build a full-parent allocation from the source sphere BE6 and shared packet BE8. Cover both d0=0 and b0=0 and all inherited residual tests. The new EN theorem assumes L unbounded and cannot be imported here.

  **Progress:** Exact source sphere retained; scalar/full-normal allocation remains open.

  **Completion criterion:** Exact full-parent finite SOS on the L-unit eta-unbounded residual domain; no assumed bound on x eta^2 h and no lost coefficient opening.

- [ ] **C14.3** — After removing IC1, close L infinitesimal and eta bounded with eta infinitesimal, zeta unbounded, or at least one of r,1-r,j0=eta+r-1 not a positive bounded unit. Retain the positive actual j=eta(1+xh)-1+r opening; j0 may vanish or be slightly negative. Allocate SN1-SN2 and its negative defect with all original normals and independent rates.

  **Progress:** IC1 all-tests interior admitted; only its exact source complement remains.

  **Completion criterion:** One legal weighted positive Gram for the entire printed remainder, uniform in all SB source openings and independent rates; retain the proved remote complement.

- [ ] **C14.4** — For L infinitesimal and eta unbounded, first prove source-weight bounds valid in this regime, then allocate SN1-SN5 and SN8-SN11 on every residual infinitesimal-u test chart. Do not use bounded-eta estimates SN7 or SN12 or an unproved map to C1.1.

  **Progress:** No new admission on unbounded eta.

  **Completion criterion:** Exact full-parent certificates for every residual Bob angle type, with all source openings and projective joins. No unproved mapping to C1.1.

- [ ] **C14.5** — Join the four residual source alternatives with the four now-admitted C1.4 source subdomains, all inherited admissions, exact sign gauges, literal coefficient boundaries and projective endpoints.

  **Progress:** Four C1.4 all-tests subdomains available; original row remains open.

  **Completion criterion:** A quantified union of the four new source charts, four admitted C1.4 subdomains, inherited admissions, source openings and retained coefficient boundaries covers the entire original C1.4 row.

### C2.W.HH

Original directed weak-C HH, reflected exactly to strong-C/weak-alpha actual II with B=H+L infinitesimal, outside all inherited admissions. Revision 9 removes the all-tests WA1 A-only interior and its exact symmetry images, including the SO1 family. Revision 10 also removes z/B infinitesimal with all other WA1 unit and gap hypotheses retained. Revision 11 also removes r infinitesimal, including jointly infinitesimal r and z/B, with the other stated source gaps retained.

**Testing scope:** Every independent test on the complement of the expanded admission; neither r nor z/B is required to be a unit there. Remaining source assumptions are not silently weakened. On the BS1/GR1 small-(1-r), z/B-unit chart, only u,v both infinitesimal or zero remain after revision 12; retain all its source gaps and n=0.

- [ ] **W.1** — Exhaust the complement of the expanded weak-C2 admission. On 1-r infinitesimal with z/B a unit and the other GR1 hypotheses, retain the exact physical constraint (1-r)Q>=BK, including equality n=0. The source-only ratios B/(1-r),n/(1-r) are bounded. The literal r=1,B>0 anchor is invalid. Other source-gap openings and z/B types remain separate.

  **Progress:** Exact source-scale constraint BS1-BS6 proved; no new source-domain admission.

  **Completion criterion:** Every residual physical source configuration from the proved source alternatives is assigned to a valid full-parent certificate; no source gap or total-scale intersection is dropped.

- [ ] **W.2** — Construct scalar or direct full-parent certificates on the complement of the expanded admission. Preserve the polynomial-SOS obstruction and its already proved SO1 tensor admission.

  **Progress:** One normalized five-root Gram now covers every bounded test on the small-r source chart; exact projective joins complete it.

  **Completion criterion:** An exact scalar certificate on every original residual source/test pair. Any restriction excluding SO1 must be justified by proved prior admissions; scalar success alone does not close the parent.

- [ ] **W.3** — On the small-(1-r), z/B-unit chart of BS1/GR1, construct a complete local full-parent certificate for u,v both infinitesimal or zero, retaining (1-r)Q>=BK and n=0. The simple sqrt(1-r)R2 Gram still has the known Js and fs poles, despite bounded diagonal coefficients. Then treat every remaining source-gap chart.

  **Progress:** All remote tests on this source chart are now removed; only the complete local parent remains there.

  **Completion criterion:** A finite legal weighted Gram contains both soft states, every first state normal and every hard quadratic coupling in the independent source/testing fields.

- [ ] **W.4** — For branches still using centered m,D packets, control every excess jet and higher term with an exact joint Gram, without a positive real lower bound on a possibly vanishing Hessian determinant. The direct WA proof avoids that subtraction only on its own source domain.

  **Progress:** Centered-jet obstruction remains on other branches.

  **Completion criterion:** An exact joint allocation controls centered-packet jets and all higher terms, including zero or arbitrarily small source-Hessian determinant; justify any subtraction by its own inequality.

- [ ] **W.5** — Join a valid local certificate on BS1/GR1 to its now-proved remote complement. Complete remote, literal-projective, sign and exact weak-event reflection joins for the other unproved source charts.

  **Progress:** GR2-GR7 and the exact endpoint packets cover every nonlocal test on the small-(1-r), z/B-unit source chart, including n=0. Other source domains are not imported.

  **Completion criterion:** All residual testing charts, literal projective endpoints, signs and exact reflected weak-event orientation are covered, completing the original C2.W.HH row.

## Global gates

- [ ] **U1:** Exact universal exhaustion after C14.5 and W.5.
- [ ] **U2:** Apply the finite-lift bridge after U1. An evaluated global affine pencil is not supplied.
- [x] **U3:** Reconcile the manuscript, checklist and verification records.

## Acceptance gates

- G1 Original source entry, signs, and every bounded ratio.
- G2 Exact full-parent decomposition preserving actual contact and jets.
- G3 Admissible roots; only pure-source/pure-test inverses or radicals.
- G4 Every first state normal and every hard quadratic coupling.
- G5 Strict residue or exact SOS; resolve every equality case.
- G6 All independent projective tests, signs, real/complex states.
- G7 Literal retained coefficient boundaries and all positive opening rates.
- G8 Analytical review plus narrowly scoped exact algebra corroboration.
- G9 Admit only the proved quantified domain and exact symmetry images.

## Efficient reproduction

`python3 verify.py --revision12-only` runs the 20 new exact assertions. `python3 verify.py --integrity-only` checks all delivered files. Previous 612 recorded assertions were not replayed. Same-system review is not external review or formal verification. No numerical atlas is a premise.
