"""Check CA6--CA8 and the full monic lift from the exact centered-A source."""
from pathlib import Path
from fractions import Fraction
import json,sys
HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
native=HERE if (HERE/'source_from_formulas.py').is_file() else (
 ROOT/'output/Q222_Checklist_Advance_2026-10-18/advances/c1')
sys.path.insert(0,str(native))
from source_from_formulas import Poly,variables
delta,k,E,ell,t,u,w,v=variables(8)
zero=0*delta;one=zero+1
sys.path.insert(0,str(HERE))
import centered_a_source as source
parts={name:Poly(poly,8) for name,poly in source.parts.items()}
checks=[]
def eq(name,p,q):
 assert not (p-q).terms,name
 checks.append(name)
def contact(p):
 o={}
 for m,c in p.terms.items():
  de,ke,ee,le,te,ue,we,ve=m
  n=(de+we+ve,ke+ue+we+2*ve,ee+ve,le,te,0,0,0)
  o[n]=o.get(n,0)+c
 return Poly({m:c for m,c in o.items() if c},8)
def deriv(p,i):return Poly({m[:i]+(m[i]-1,)+m[i+1:]:c*m[i] for m,c in p.terms.items() if m[i]},8)
roots=(u-k,w-delta*k,v-delta*k*k*E)
cms=((0,1,0,0,0,0,0,0),(1,1,0,0,0,0,0,0),(1,2,1,0,0,0,0,0))
def monic(p):
 remainder=dict(p.terms);qs=[]
 for i,cm in zip((5,6,7),cms):
  q={};nxt={}
  for m,c in remainder.items():
   n=m[i];base=list(m);base[i]=0
   final=tuple(x+n*y for x,y in zip(base,cm));nxt[final]=nxt.get(final,0)+c
   for j in range(n):
    mm=list(base);mm[i]=n-1-j;mm=tuple(x+j*y for x,y in zip(mm,cm))
    q[mm]=q.get(mm,0)+c
  qs.append(Poly({m:c for m,c in q.items() if c},8));remainder={m:c for m,c in nxt.items() if c}
 rem=Poly(remainder,8)
 eq('monic identity',p,rem+sum((a*b for a,b in zip(roots,qs)),zero))
 return rem,qs
A=w*v;B=delta*v;C=delta*E*u*w;D0=delta*delta*k**3*E
x=B-C;y=A-k*C;z=u*B-k*C;h=k*C-D0;rr=[x,y,z,h]
q1square=A*(delta*u*v)+(k*C)*D0-2*(k*C)*(k*B)
T4=y*y+z*z+h*h-2*y*z+2*q1square
invE=Poly({(0,0,-1,0,0,0,0,0):1},8)
invdelta=Poly({(-1,0,0,0,0,0,0,0):1},8)
P00=E*E*(E+4)-E*(E*E+6*E+4)*ell+2*(E+1)*(E+2)*ell*ell
P00+=E*E*(8-3*E)*k*k+4*E*E*k*u+E*E*(E+4)*u*u
eq('CA6 exact scalar coefficient collection',parts['scalar'],
   4*P00*invE**4*invdelta**2*x*x-16*(k+u)*invE**2*invdelta**2*x*z
   +8*invE*invdelta**2*T4)
eq('CA6 complete first N normal',parts['N'],zero)
eq('CA6 complete first M normal',parts['M'],
   8*(E*E+2*E-2*ell*(E+1))*invE**2*invdelta*x)
eq('CA7 first hard diagonal',parts['NN'],16*invE*invdelta**2)
eq('CA7 hard cross coefficient',parts['NM'],zero)
eq('CA7 second hard diagonal',parts['MM'],4*(E*E+4)*invE)
star=y+z-h-2*k*x
eq('conductor u',C*(u-k),z-u*x)
eq('conductor w',C*(w-delta*k),delta*y-w*x)
eq('conductor v',C*(v-delta*k*k*E),E*(w*z+delta*k*y-k*w*x))
eq('circuit repair',k*C*star,q1square-y*z)
def conductor(p):
 rem,(Tu,Tw,Tv)=monic(p);assert not rem.terms,'contact needed'
 ans=[-u*Tu-w*Tw-E*k*w*Tv,delta*Tw+delta*k*E*Tv,Tu+E*w*Tv]
 eq('conductor multiplication',C*p,sum((a*b for a,b in zip(rr,ans)),zero))
 return ans
def decompose(p,gs):
 mons=[next(iter(g.terms)) for g in gs];out=[{} for g in gs]
 for m,c in p.terms.items():
  for j,n in enumerate(mons):
   # delta and E are positive units; their Laurent exponents are allowed.
   if all(m[i]>=n[i] for i in range(8) if i not in (0,2)):
    mm=tuple(a-b for a,b in zip(m,n));out[j][mm]=c;break
  else:raise AssertionError(('monomial outside raw ideal',m))
 qs=[Poly(q,8) for q in out]
 eq('raw monomial membership',p,sum((q*g for q,g in zip(qs,gs)),zero))
 return qs
def linear(p):
 RA,RB,RC=decompose(p,[A,B,C]);S=k*RA+RB+RC
 eq('normal contact',contact(p),zero);assert not contact(S).terms
 ans=conductor(S);ans[0]+=RB;ans[1]+=RA
 eq('complete normal lift',p,sum((a*b for a,b in zip(rr,ans)),zero))
 return ans
def square(p):
 pairs=[(i,j) for i in range(3) for j in range(i,3)];mons=[A,B,C]
 coeffs=decompose(p,[mons[i]*mons[j] for i,j in pairs]+[D0*D0])
 rho=coeffs[-1];cs=[k,one,one]
 S=k*k*rho;HH=[zero,zero,zero,-2*k*rho];terms=[(3,3,rho)]
 idx=[1,0,None]
 for (i,j),f in zip(pairs,coeffs):
  S+=f*cs[i]*cs[j]
  if idx[i] is not None:HH[idx[i]]+=f*cs[j]
  if idx[j] is not None:HH[idx[j]]+=f*cs[i]
  if idx[i] is not None and idx[j] is not None:terms.append((idx[i],idx[j],f))
 Q=sum((f*rr[i]*rr[j] for i,j,f in terms),zero)
 eq('initial square decomposition',p,Q+C*sum((a*b for a,b in zip(rr,HH)),zero)+C*C*S)
 eq('scalar contact',contact(p),zero)
 for i in (5,6,7):eq('scalar contact derivative',contact(deriv(p,i)),zero)
 assert not contact(S).terms
 lifted=conductor(S)
 for i in range(3):HH[i]+=lifted[i]
 rhoc=contact(rho);lam=2*k*rhoc;syz=[-2*k,one,one,-one]
 rem=[a-lam*b for a,b in zip(HH,syz)]
 assert all(not contact(a).terms for a in rem)
 terms.append((1,2,-2*rhoc))
 for i,a in enumerate(rem):
  for j,b in enumerate(conductor(a)):terms.append((i,j,b))
 eq('complete scalar lift',p,sum((f*rr[i]*rr[j] for i,j,f in terms),zero)+2*rhoc*q1square)
 return terms,2*rhoc
terms,qcoef=square(parts['scalar'])
linN=linear(parts['N']);linM=linear(parts['M'])
for poly in [qcoef]+[f for i,j,f in terms]+linN+linM:
 assert all(all(ex>=0 for i,ex in enumerate(mon) if i not in (0,2))
            for mon in poly.terms),'only delta and E unit inverses are allowed'
checks.append('only positive units delta E inverted in the monic lift coefficients')
import sympy as s
dd,EE,tt=s.symbols('delta E t')
def residue(p):return s.factor(sum(s.Rational(c.numerator,c.denominator)*dd**m[0]*EE**m[2]*tt**m[4]
 for m,c in p.terms.items() if all(m[j]==0 for j in (1,3,5,6,7))))
G=s.zeros(4)
for i,j,f in terms:
 if i==j:G[i,j]+=residue(f)
 else:G[i,j]+=residue(f)/2;G[j,i]+=residue(f)/2
G=G.applyfunc(s.factor)
print('scalar Gram',G)
print('qcoef',residue(qcoef))
print('N normal',[residue(x) for x in linN])
print('M normal',[residue(x) for x in linM])
print('hard',[residue(parts[name]) for name in ('NN','NM','MM')])
expected=s.Matrix([[4*(EE+4)/(EE**2*dd**2),0,0,0],
 [0,8/(EE*dd**2),-8/(EE*dd**2),0],
 [0,-8/(EE*dd**2),8/(EE*dd**2),0],[0,0,0,8/(EE*dd**2)]])
assert all(s.factor(z)==0 for z in G-expected)
assert s.factor(residue(qcoef)-16/(EE*dd**2))==0
assert [residue(x) for x in linN]==[0,0,0]
assert all(s.factor(residue(x)-y)==0 for x,y in zip(linM,[8*(EE+2)/(EE*dd),0,0]))
checks.append('exact residue scalar and complete-normal Grams')
coupled=s.Matrix([[4*(EE**2+4)/EE,4*(EE+2)/(EE*dd)],
                  [4*(EE+2)/(EE*dd),4*(EE+4)/(EE**2*dd**2)]])
assert s.factor(s.det(coupled)-256/(EE**3*dd**2))==0
checks.append('CA8 exact positive coupled determinant')
out={'status':'PASS','checks':checks,'scalar_gram':str(G),'q1_coefficient':str(residue(qcoef)),
 'N_normal':[str(residue(x)) for x in linN],'M_normal':[str(residue(x)) for x in linM],
 'hard':[str(residue(parts[name])) for name in ('NN','NM','MM')]}
(HERE/'centered_a_lift_checks.json').write_text(json.dumps(out,indent=2)+'\n')
