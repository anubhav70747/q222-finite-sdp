"""Focused new R6 tests: full stress, raw full-normal support, endpoint,
and the exact leading-row obstruction of the older five-root frame.
Imported identities (not rerun): full WA parent, original TL2--TL3,
C1 SD4/CC conductor, and the physical source stationary identities.
"""
import json,time
from pathlib import Path
from frame import *
started=time.monotonic();checks={}
def ck(name,e):
    vals=list(e) if isinstance(e,z.MatrixBase) else [e]
    assert all(z.cancel(a)==0 for a in vals),name
    checks[name]=True
# New exact syzygies and the entire leading row.
W,X,Y,Z=z.symbols('W X Y Z')
physical=z.Matrix([X+r*u*Z,Y-h*u*W,u*W-v*Z/t,v*W-s*u*Z,(U-s*b)*Z])
S=z.Matrix([0,0,(U-s*b)*v,-(U-s*b)*u,V/t-s*U])
ck('physical_RA3_contact_syzygy',(S.T*physical)[0])
Devent=u*W+u*v*X-Y-v*Z;jactual=1+s*b*r-(1-h)/t
LD=u*v*physical[0]-physical[1]+(1-h)*physical[2]-r*v*physical[4]
ck('full_D_conductor_on_RA3_frame',LD-Devent-jactual*v*Z)
M=v*W-X+u*v*Y-u*Z;Rmc=M-g*v*W;T=u*v*W-s*s*b*Z
ck('retained_m_exact_contact_conductor',((1-g+h*U)*T-u*physical[0]+U*v*physical[1]-u*Rmc-s*(1-g)*physical[4]).subs(g,1-w+h*s*b))
d0=1/(2*(t-(1-h)));dd=d0+z.Rational(1,2);c0=(h+t)/2
J0=(t-h)/4+t*d0;J1=t*dd/2
ck('complete_five_entry_soft_row_residue',lead[:,4]-z.Matrix([0,v*dd,-v*(J0+J1*U),u*(c0+t*dd*U)/2,0]))
L=z.Matrix([0,0,0,0,t*dd]);S0=S.subs(s,0)
gauged=lead+(S0*L.T+L*S0.T)/2
ck('leading_soft_row_after_polynomial_gauge',gauged[:,4]-z.Matrix([0,v*dd,-v*J0,u*c0/2,dd*V]))
# A polynomial syzygy gauge could cancel eta,Ku only if v*dd belonged
# to the principal ideal (v^2); its nonzero remainder proves failure.
_,rem=z.div(z.Poly(v*dd,v),z.Poly(v*v,v))
assert rem.as_expr()!=0
checks['bounded_polynomial_five_root_eta_row_obstruction']=True
# Full event difference, with the one newly changed bounded A term.
nn,ga,pc,dc,da,dD,dal,ddel=z.symbols('n gamma p deltaC deltaA deltaD deltaAlpha deltad')
rho=z.symbols('rho',positive=True);Du=1+U;Dv=1+V
At,NN=z.symbols('At N');Btest=X+u*Z
base=dc*Dv*(u*W-Y)**2+da*Du*Dv*Y**2+dD*Devent**2+dal*Du*(v*Y-Z)**2+ddel*z.Rational(1,2)*(Devent**2+Du*(v*Y-Z)**2+Dv*Btest**2-Du*Dv*Z**2)
# delta beta = -n - delta d/2, delta m = 0.
full_difference=base+nn*Du*Dv*X**2+(-nn-ddel/2)*Dv*Btest**2
Nrow=nn*Du*Dv*(X+ga*At)**2
stress=(nn*Du*Dv*X**2-Nrow)-nn*Dv*Btest**2+dc*Dv*(u*W-Y)**2+(dD+ddel/2)*Devent**2+dal*Du*(v*Y-Z)**2+ddel/2*Du*((v*Y-Z)**2-Dv*Z**2)+da*Du*Dv*Y**2
ck('new_R6_full_parent_stress_identity',full_difference-Nrow-stress)
rowexp=2*nn*ga*Du*Dv*u*At*Z-(2*nn*ga*pc*Du+nn*ga*ga)*Du*Dv*At**2-2*nn*ga*Du*Dv*At*NN
ck('full_n_row_with_normal',(nn*Du*Dv*X**2-Nrow).subs(X,NN+pc*Du*At-u*Z)-rowexp)
# Raw support in full SD5 coordinates. All source symbols below are bounded.
wtest,MB,H=z.symbols('wtest MB H');n0,ng,ng2,Cd,Ad,Dd,ald,db=z.symbols('n0 ng ng2 Cd Ad Dd ald db')
at=v*wtest;qb=v*(Du-u*NN-pc*u*Du*at)
xs=NN+pc*Du*at-u
ws=wtest+u*(MB+H*qb)/Du
ys=u*wtest-(MB+H*qb)/Du
js=u*ws+u*v*xs-ys-v
st=(2*ng*Du*Dv*u*at-(2*ng*pc*Du+ng2)*Du*Dv*at**2-2*ng*Du*Dv*at*NN
    -n0*Dv*(xs+u)**2+Cd*Dv*(u*ws-ys)**2+(Dd+db/2)*js**2
    +ald*Du*(v*ys-1)**2+db/2*Du*((v*ys-1)**2-Dv)+Ad*Du*Dv*ys**2)
cleared=z.Poly(z.cancel(Du*Du*st),NN,MB)
assert max(sum(mm) for mm in cleared.monoms())<=2
checks['full_stress_has_normal_degree_at_most_two']=True
scalar=z.cancel(Du*Du*(st.subs({NN:0,MB:0})-ald*Du))
def raw_member(expr,second):
    pol=z.Poly(z.expand(expr),u,v,wtest)
    for (iu,iv,iw),co in pol.terms():
        good=(iv>=2 or (iv>=1 and iu>=1 and iw>=1) or (iu>=2 and iw>=2)) if second else (iv>=1 or(iu>=1 and iw>=1))
        assert good,((iu,iv,iw),co)
raw_member(scalar,True);checks['complete_scalar_raw_square_support_except_explicit_alpha_constant']=True
for normal,name in [(NN,'N'),(MB,'MB')]:
    lin=z.cancel(Du*Du*z.diff(st,normal).subs({NN:0,MB:0}))
    raw_member(lin,False);checks['complete_'+name+'_normal_raw_support']=True
# The relevant source coquotients have unit denominators when b is a unit.
rr,QQ,KK,delta,EE=z.symbols('rr QQ KK delta EE',nonzero=True)
Kc=s*KK/QQ;e=s*w;x=s*b;D02=delta**4*x**3*EE**2
ck('n_gamma_squared_over_rho_regular',e*e*rr*rr/(Kc*Kc)-w*w*rr*rr*QQ*QQ/(KK*KK))
ck('n_x_over_rho_D0_squared_regular',e*e*x/D02-w*w/(delta**4*b*b*EE*EE))
# Complete homogeneous core in the delicate (infinity,0) endpoint.
p,Ss,Tt,Ccap,Acap=z.symbols('p S T Ccap Acap')
core=(Devent**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)/2
hom=z.cancel(p*p*core.subs(u,1/p))
coreframe=((W+(1+p*p)*Tt-p*Y-p*v*Ss)**2+(1+p*p)*(v*v*Y*Y-2*Y*(v*Ss-p*Tt)-(v*Ss-p*Tt)**2)+Dv*Ss*Ss)/2
ck('entire_infinity_zero_core_identity',hom-coreframe.subs({Ss:p*X+Z,Tt:v*X}))
selected=coreframe+Ccap*Dv*(W-p*Y)**2+Acap*(1+p*p)*Dv*Y**2
ck('entire_infinity_zero_selected_residue',selected.subs({p:0,v:0})-((W+Tt)**2/2+Ss**2/2+Ccap*W*W+Acap*Y*Y))
# Exact physical native source mapping, independent of the opening.
ck('native_M_gap_is_actual_g',1+x*h-w-(1-w+h*s*b))
ck('native_J_gap_is_actual_j',1+x*(1-s*w)-(1-h)/t-jactual)
ck('native_state_scale_is_t_b',x*t/s-t*b)
ck('n_gamma_over_rho_regular',e*e*rr/Kc-s*w*w*rr*QQ/KK)
ck('alpha_constant_coquotient_native_units',(w*w/(delta**4*b*b*EE*EE)).subs(delta**4,KK*KK/(b*b*QQ*QQ*EE*EE))-w*w*QQ*QQ/(KK*KK))
payload={'status':'PASS','count':len(checks),'checks':checks,'scope':'R6 unbounded-a thin-layer exact stress/raw-normal support and delicate projective endpoint; old-frame obstruction. Analytical positivity and unchanged historical certificates are not replaced by these checks.','seconds':round(time.monotonic()-started,3)}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps(payload,indent=2))
