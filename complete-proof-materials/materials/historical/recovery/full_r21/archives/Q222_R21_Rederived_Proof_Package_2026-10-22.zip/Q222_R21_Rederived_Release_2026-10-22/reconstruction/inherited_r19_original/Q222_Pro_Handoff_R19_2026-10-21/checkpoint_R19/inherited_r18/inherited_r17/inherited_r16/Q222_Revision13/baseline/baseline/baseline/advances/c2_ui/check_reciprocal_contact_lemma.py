"""Exact algebra for the reciprocal contact completion; not a full UI certificate."""
from pathlib import Path
import json
import sympy as s

checks=[]
def zero(name, value):
    values=list(value) if isinstance(value,s.MatrixBase) else [value]
    assert all(s.factor(q)==0 for q in values), name
    checks.append(name)

V,W=s.symbols('V W')
x,y,x0,y0=s.symbols('x y x0 y0')
a00,a01,a11,b00,b01,b11=s.symbols('a00 a01 a11 b00 b01 b11')
A0=s.Matrix([[a00,a01],[a01,a11]])
A2=s.Matrix([[b00,b01],[b01,b11]])
q=s.Matrix([x,y]);q0=s.Matrix([x0,y0])
b=-(A0+A2)*q0
c0=(q0.T*A2*q0)[0];c2=(q0.T*A0*q0)[0]
F=(q.T*(A0+V**2*A2)*q)[0]+2*V*W*(b.T*q)[0]+(c0+c2*V**2)*W**2
first=q-V*q0*W;second=V*q-q0*W
zero('general reciprocal contact factorization',F-(first.T*A0*first)[0]-(second.T*A2*second)[0])
contact={x:x0,y:y0,V:1,W:1}
zero('contact value',F.subs(contact))
for var in (x,y,V,W):
    zero('full contact first derivative '+str(var),s.diff(F,var).subs(contact))

a,B,r=s.symbols('a B r',nonzero=True)
z=a*a;Du=1+z;Ac=1+z*r
Delta=1+(1+z)*B+z*(1+z)*B**2+2*z*(1+z)*B*r+z*z*r*r+2*z*r
g=(1+z)*B-1+r
N0=(1+z)*(B+r)*B
n=((B+r)*Ac**2-r*Delta)/(2*r*Delta)
m=(1-r)*Ac**2/(2*g*Delta)
alpha=z*z*(B+r)*N0/(2*(1-z*B)*Delta)
H0=z*(1+z)*(B+r)*B/(2*Delta)
Aweak=Ac**2*(B+r)/(2*z*B*Delta)
q0=s.Matrix([-r/B,1/(a*B)])
A0=s.Matrix([[4*n*Du+4*m+2,(4*m+2)*a],[(4*m+2)*a,(4*m+2)*z+4*alpha*Du]])
ell=s.Matrix([a,-1]);A2=4*H0*ell*ell.T
b=s.Matrix([-4*m*Du,-Du*a*(4*m+4*alpha+2)])
c0=4*Aweak*Du*z
c2=4*m*Du**2+(4*alpha+2)*Du*z
zero('UI leading state equations',b+(A0+A2)*q0)
zero('UI leading constant identity',c0-(q0.T*A2*q0)[0])
zero('UI leading V squared identity',c2-(q0.T*A0*q0)[0])
q=s.Matrix([x,y])
F=(q.T*(A0+V**2*A2)*q)[0]+2*V*W*(b.T*q)[0]+(c0+c2*V**2)*W**2
sig=(ell.T*q0)[0]
rhs=((q-V*q0*W).T*A0*(q-V*q0*W))[0]+4*H0*(V*(a*x-y)-sig*W)**2
zero('UI leading exact sum of squares',F-rhs)

C,D,u,v,R,Q=s.symbols('C D u v R Q')
L=C+D;theta=D/L;H=C*D/L
zero('full original C D parallel packet identity',
     C*(1+v*v)*R*R+D*(R+v*Q)**2-
     (L*(R+theta*v*Q)**2+H*v*v*Q*Q+C*v*v*R*R))

out={'status':'PASS','check_count':len(checks),'checks':checks,
     'scope':'Exact leading reciprocal contact identity and full parallel packet identity only. Not a complete full-parent or all-tests UI certificate.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
