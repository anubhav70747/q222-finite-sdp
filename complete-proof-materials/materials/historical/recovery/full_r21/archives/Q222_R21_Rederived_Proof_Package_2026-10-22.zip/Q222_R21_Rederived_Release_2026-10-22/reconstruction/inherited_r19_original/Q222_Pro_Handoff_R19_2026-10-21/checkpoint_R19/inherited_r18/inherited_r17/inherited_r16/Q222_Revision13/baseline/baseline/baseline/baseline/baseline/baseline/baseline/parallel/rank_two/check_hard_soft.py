#!/usr/bin/env python3
"""Exact symbolic checks of the hard/soft reduction; requires SymPy only."""
from pathlib import Path
import json
import sympy as s

def zero(M):
    values=list(M) if isinstance(M,s.MatrixBase) else [M]
    assert all(s.expand(v)==0 for v in values)

# Generic block identities, independent of physical specialization.
p,q,r,a,b,c,e,f,g,h,k,l=s.symbols('p q r a b c e f g h k l')
A=s.Matrix([[p,q],[q,r]])
X=s.Matrix([[a,b],[c,e]])
C=s.Matrix([[f,g],[g,h]])
B=A.row_join(X).col_join(X.T.row_join(C))
D=A.det(); J=A.adjugate(); K=D*C-X.T*J*X
x=s.Matrix([k,l]); z=s.Matrix(s.symbols('z0:2'))
state=x.col_join(z)
zero(D*(state.T*B*state)[0]-((A*x+X*z).T*J*(A*x+X*z))[0]-(z.T*K*z)[0])
zero(K.det()-D*B.det())
zero(s.trace(K)*K-K*K-K.det()*s.eye(2))

# Generic event coefficient expansion, including every three-event type.
d,h1,h2=s.symbols('d h1 h2')
t=s.symbols('t0:3')
xs=[s.Matrix(s.symbols('x%d_0 x%d_1'%(i,i))) for i in range(3)]
ys=[s.Matrix(s.symbols('y%d_0 y%d_1'%(i,i))) for i in range(3)]
Ah=s.diag(h1,h2)
AA=d*Ah+sum((t[i]*xs[i]*xs[i].T for i in range(3)),s.zeros(2))
XX=sum((t[i]*xs[i]*ys[i].T for i in range(3)),s.zeros(2))
YY=sum((t[i]*ys[i]*ys[i].T for i in range(3)),s.zeros(2))
detA=AA.det()
area=lambda i,j:s.det(s.Matrix.hstack(xs[i],xs[j]))
det_expected=d*d*h1*h2+d*sum(t[i]*(h2*xs[i][0]**2+h1*xs[i][1]**2) for i in range(3))
det_expected+=sum(t[i]*t[j]*area(i,j)**2 for i in range(3) for j in range(i+1,3))
zero(detA-det_expected)
R=detA*YY-XX.T*AA.adjugate()*XX
expected=d*d*h1*h2*YY
for i in range(3):
    for j in range(i+1,3):
        z1=xs[i][1]*ys[j]-xs[j][1]*ys[i]
        z0=xs[i][0]*ys[j]-xs[j][0]*ys[i]
        expected+=d*t[i]*t[j]*(h1*z1*z1.T+h2*z0*z0.T)
v=area(0,1)*ys[2]-area(0,2)*ys[1]+area(1,2)*ys[0]
expected+=t[0]*t[1]*t[2]*v*v.T
zero(R-expected)
receipt={'status':'PASS','arithmetic':'exact symbolic polynomial expansion',
         'checks':['generic full-parent block identity','generic determinant identity',
                   'generic binary characteristic identity','hard determinant expansion',
                   'generic three-event Cauchy-Binet matrix expansion'],
         'global_tensor_descent_proved':False}
Path(__file__).with_name('CHECK_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
