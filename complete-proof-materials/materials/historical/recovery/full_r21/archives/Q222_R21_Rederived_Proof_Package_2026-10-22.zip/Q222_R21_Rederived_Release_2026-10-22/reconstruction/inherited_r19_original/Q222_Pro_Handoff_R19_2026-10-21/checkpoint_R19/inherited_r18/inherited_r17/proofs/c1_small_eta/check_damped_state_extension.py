"""Two exact identities for the local damped state-chart extension."""
import sympy as s
import json
from pathlib import Path
u,v,W,X,Y,Z,t,h,eps,Q=s.symbols('u v W X Y Z eta h epsilon Q', nonzero=True)
E=t*u*W-v*Z;P=E/t-Q;xi=X+h*u*Z
lhs=eps*u*v*Q*xi
rhs=eps*u*u*W/Z*E*xi-eps*u*xi/Z*E*E/t-eps*u*v*P*xi
assert s.cancel(lhs-rhs)==0
m,C,A,D,al,be=s.symbols('m C A D alpha beta')
Du,Dv=1+u*u,1+v*v
Rm=v*W-X+u*v*Y-u*Z
Rd=u*W-Y+u*v*X-v*Z
parent=m*Rm**2+C*Dv*(u*W-Y)**2+A*Du*Dv*Y**2+(D+s.Rational(1,2))*Rd**2+(al+s.Rational(1,2))*Du*(v*Y-Z)**2+(be+s.Rational(1,2))*Dv*(X+u*Z)**2-Du*Dv*Z*Z/2
exit_packet=Dv*((X+u*Z)**2-Du*Z*Z)/2
rest=m*Rm**2+C*Dv*(u*W-Y)**2+A*Du*Dv*Y**2+(D+s.Rational(1,2))*Rd**2+(al+s.Rational(1,2))*Du*(v*Y-Z)**2+be*Dv*(X+u*Z)**2
assert s.expand(parent-exit_packet-rest)==0
out={'status':'PASS','count':2,'checks':{'DS2_complete_normal_Z_conductor':True,'DS3_original_parent_state_exit_packet_accounting':True},'scope':'All unchanged C14.3b sources; local testing state chart X/Z bounded and u^2 W/Z bounded, plus the direct X/Z-unbounded exit. Remaining unbounded-x/eta source is not admitted for all states.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
