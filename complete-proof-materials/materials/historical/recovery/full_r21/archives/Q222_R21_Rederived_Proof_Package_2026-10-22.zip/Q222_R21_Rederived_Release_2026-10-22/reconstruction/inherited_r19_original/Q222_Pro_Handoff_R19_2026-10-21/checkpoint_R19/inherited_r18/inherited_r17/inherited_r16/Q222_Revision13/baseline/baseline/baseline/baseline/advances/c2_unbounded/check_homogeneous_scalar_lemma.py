"""Exact source-free homogeneous scalar identities; no positivity claim."""
from pathlib import Path
import json
import sympy as s

B,sig,k,u,W,Z,v=s.symbols('B sig k u W Z v', nonzero=True)
xi,x=s.symbols('xi x')
rootB=s.symbols('rootB',nonzero=True)
q0,rad,h2,d=s.symbols('q0 rad h2 d')
Q1,a01,d1,e1,b1,Jxi,Jv=s.symbols('Q1 a01 d1 e1 b1 Jxi Jv')
tau=v-k
R=(u*W-B*Z/k)/rootB
S=u*Z-sig*k*W
U=rootB*tau*Z
T=u*tau*Z
checks=[]
def eq(label,lhs,rhs=0):
    diff=s.factor(lhs-rhs)
    diff=s.factor(diff.subs(rootB**2,B).subs(x,sig*B).subs(xi,u*u))
    assert diff==0,(label,diff)
    checks.append(label)

eq('first homogeneous conductor',(u*u-sig*B)*W,u*rootB*R+B*S/k)
eq('second homogeneous conductor',(u*u-sig*B)*Z,u*S+sig*k*rootB*R)
eq('scaled angular conductor zero',T*T-sig*U*U-S*T*tau-sig*k*R*U*tau)

# The quotient definitions are imposed algebraically, then multiplied back.
delta=xi-sig*B
c=rad*delta-B*d/k
a=(h2*delta**2-k*xi*d-sig*k*k*c-sig*B*k*d)/B
q=-k*d-sig*k*k*rad
eq('exact matched scalar Gram',a*W*W+2*u*d*W*Z+c*Z*Z,
   q*R*R+rad*S*S+h2*(u*R+rootB*S/k)**2)

# Double-zero conditions of the final monic numerator, checked on jets.
ac,dc,cc,ax,dx,cx=s.symbols('ac dc cc ax dx cx')
N0=B*ac+k*sig*B*dc+sig*k*k*cc+sig*B*k*dc
N1=B*ax+k*dc+2*k*sig*B*dx+sig*k*k*cx
eq('double quotient value from state stationarity',N0.subs({ac:-sig*k*dc,cc:-B*dc/k}))
eq('double quotient derivative from u stationarity',N1.subs(ax,(-k*dc-2*k*sig*B*dx-sig*k*k*cx)/B))

# General angular correction: angular stationarity permits J=delta Jxi+tau Jv.
L1=a01/k**2+b1
e1_constrained=delta*Jxi+tau*Jv-sig*L1-Q1/k**2-2*d1/k
f1=(xi*Q1/B+sig**2*a01)*W**2+2*u*d1*W*Z+(B*e1_constrained+xi*b1)*Z**2
D1=L1+B*Jxi
angular=(tau*Q1*R**2+tau*a01*S**2/k**2
         +(2*(Q1/k+d1)+sig*k*D1)*R*U
         +(D1-2*a01/k**2)*S*T+Jv*U**2)
eq('entire angular correction',tau*f1,angular)
eq('angular leftover identity',tau*(xi-sig*B)*Z**2,S*T+sig*k*R*U)
eq('small-B scalar RU Schur margin',2/k**2-(4*(k*k-1)/(1+k*k))**2/(8*k*k),8/(1+k*k)**2)

payload={'result':'PASS','number_of_checks':len(checks),'checks':checks,
         'scope':'Exact homogeneous scalar Gram identities under state/u/v stationary contact, plus the small-B source scalar RU Schur margin. Full-normal restoration and all-tests closure remain separate obligations.'}
Path(__file__).with_name('homogeneous_scalar_checks.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps(payload,indent=2))
