# C2 closure with an unbounded opposite event

`c2_unbounded_n_pitchfork.tex` proves a new complete source-domain theorem.

**Source assumptions.** Original physical C2 parent, lambda=beta=0; d,c,alpha positive bounded units; m,A,D bounded nonnegative; n arbitrary nonnegative, including unbounded; finite stationary zero with actual u=k positive infinitesimal and v=a a positive bounded unit. No n/k comparison.

**Conclusions.** Physicality and exact stationarity force A,D units, m/k^4 a unit, and the contact form (1,xk^2,yk,zk) with (d+2n)x,y,z bounded. Theorem thm:cnp-local gives an exact five-root whole-parent certificate at the matched independent angle. Corollary cor:cnp-all-tests proves all independent projective tests and states, retaining the whole m,n packets on outer charts. The noncommuting-residue theorem is the only imported all-tests dispatch input.

**New scope.** The older bounded-source pitchfork excluded n unbounded. This result permits arbitrary n largeness and consequently includes normalized-d-zero sources. It does not cover additional unbounded c,alpha,A,D or arbitrary actual contact regimes, and does not assert that all remaining C2 sources enter this source domain.

**Verification.** `check_c2_unbounded_n_pitchfork.py` is self-contained standard-library exact polynomial arithmetic. All 18 checks passed, covering the entire scalar and all first-normal forms, the complete n contributions, both outer-chart quadratic root allocations, the boundary Schur numerator, both cap corner quadratics, and the exact Bob sign symmetry. Receipt: `check_c2_unbounded_n_pitchfork.json`. No atlas calculation was replayed.

**Independent review.** The agent audit_c1_extension reviewed the full local proof and all-tests join and reported PASS on 2026-10-17, independently expanding CN10 and CN11. The strict-residue Gram theorem, physical canonical parent, contact stationarity and universal noncommuting-residue coverage remain retained imports. No claim of global analytical coverage follows from this source-domain theorem.
