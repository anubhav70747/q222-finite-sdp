import sympy as s, json, time
from pathlib import Path
start=time.monotonic(); checks=[]
def ck(name,expr):
    n=s.fraction(s.cancel(expr))[0]
    ok=s.expand(n)==0
    checks.append({'name':name,'pass':ok})
    print(('PASS ' if ok else 'FAIL ')+name,flush=True)
    if not ok: print(s.factor(n),flush=True); raise AssertionError(name)
k,u,q,w,W,Z,Nx,Ny=s.symbols('k u q w W Z Nx Ny')
sig,H,b=s.symbols('sigma H b'); x=k*k; z=q*q; K=1+x; Du=1+u*u; Dw=1+w*w; h=sig*H
m,c,a,l,D,be=s.symbols('m c a l D beta')
j=u-k*b*z;p=1+u*k*b*z;t=h*k-u
X=Nx-k*h*Z;Y=q*Ny+k*b*z*W
Mw=W-w*X+u*Y-u*w*Z;Rw=u*W-Y;Jw=u*w*W+u*X-w*Y-Z;Bw=X+u*Z
core=Jw**2+Du*(Y-w*Z)**2+Dw*Bw**2-Du*Dw*Z**2
F=4*m*z*Mw**2+4*c*z*Dw*Rw**2+4*a/z*Du*Dw*Y**2+4*D*Jw**2+4*l/z*Du*(Y-w*Z)**2+4*be*Dw*Bw**2+2*core
A=4*m*z*z*t*t+4*l*Du+(4*be+2)*z*t*t
B=(4*c*z+4*D+2)*j*j+4*a*Du*x*b*b*z
C=(4*D*(1+u*k*h)**2+4*be*(u-k*h)**2+2*Du*x*h*h)/sig**2
D1=8*m*z*p*t-8*D*j*(1+u*k*h)-8*l*Du*k*b-4*u*u*k*(h+b*z)-4*u+4*u*x*h*b*z
EE=4*m*p*p+4*c*j*j+4*(a+l)*Du*x*b*b+2*Du*x*b*b*z
Ax=-8*m*z*p+(8*D+4)*u*j
Bx=-8*D*u*(1+u*k*h)+8*be*(u-k*h)-4*Du*k*h
Cx=-8*m*z*t+(8*be+4)*(u-k*h)
Ay=8*m*z*u*p-8*c*z*j+8*(a+l)*Du*k*b+4*Du*k*b*z
By=-8*c*z*j+8*a*Du*k*b-(8*D+4)*j
Cy=8*m*z*z*u*t-8*l*Du+8*D*z*(1+u*k*h)+4*u*z*t
Qx=4*m*z*w*w+4*D*u*u+4*be*Dw+2*(Du+w*w)
Qy=4*m*z*z*u*u+4*c*z*z*Dw+4*a*Du*Dw+4*l*Du+4*D*z*w*w+2*z*(Du+w*w)
Qxy=-8*m*z*u*q*w-8*D*u*q*w-4*u*q*w
sc=A/z*w*w*Z*Z+B*w*w*W*W+C*sig*sig*Z*Z+D1*w*W*Z+EE*z*W*W
LX=Ax*w*W+Bx*Z+Cx*w*w*Z; LY=q*(Ay+By*w*w)*W+Cy*w*Z/q
ck('complete scalar and all first/quadratic normal coefficients',F-(sc+Nx*LX+Ny*LY+Qx*Nx*Nx+Qy*Ny*Ny+Qxy*Nx*Ny))
U=w*W-sig*Z/k;N=(w*Z-z*W/k)/q;delta=u-k;S=q*delta*W;TT=sig*delta*Z
L=2*A/k+2*B*sig/k+D1; JJ=C-B/k**2; KK=A/k**2+2*B*sig/k**2+D1/k+EE
ck('homogeneous scalar conductor',sc-(A*N*N+B*U*U+q*L*W*N+sig**2*JJ*Z**2+z*KK*W**2))
ck('homogeneous angular root relation',TT*TT-sig*S*S-k*sig*delta*S*N+k*delta*TT*U)
Jx=Bx+sig/k*(Ax+z/k*Cx); Jy=Ay+Cy/k+sig*z/k**2*By
ck('full X normal conductor',LX-((Ax+z/k*Cx)*U+Cx*q*w*N+Jx*Z))
ck('full Y normal conductor',LY-((Cy+sig*z/k*By)*N+q*By*w*U+q*Jy*W))
# Use z as an independent symbol for source algebra, avoiding repeated q powers.
zz=s.symbols('z');R=1+x*zz*b;Q=1-x*b;Es=1-x*H
Js=1+sig*(x*H-1+zz*b);theta=1-sig*H;M=R-zz+sig*zz*H
P=x*K+sig*x+sig*zz+sig*zz*b*x*x+x*x*sig*zz*H*(1-sig*H)+2*x*sig*sig*zz*H+sig*sig*zz*zz*b*x*x*H
V=zz*(1+x*sig*H)*Es+x*(1-zz*b)*(1+sig*zz*H)
Pa=R*sig*zz*H+R*x*H+M*Es
ND=s.cancel((K*(sig*zz+x)*(1+sig*zz*b)-Js*P)/sig)
NB=s.cancel((K*x*(1+sig*zz*b)*(1+sig*zz*H)-theta*P)/sig)
source={m:K*x*(1+sig*zz*b)*H*(sig*zz+x)/(2*M*P),c:K*(1+sig*zz*b)*Es/(2*(1-zz*b)*P),a:V/(2*b*P),l:x*x*(1+sig*zz*b)*Pa/(2*Q*P),D:sig*ND/(2*Js*P),be:sig*NB/(2*theta*P)}
def src(expr):
    # Factor each weight multiplier before source substitution. Contact jets
    # cancel every opening independently; a giant common denominator hides it.
    expr=s.expand(expr.subs(q*q,zz))
    weights=(m,c,a,l,D,be)
    out=expr.subs({v:0 for v in weights})
    for v in weights:
        out += s.cancel(s.factor(expr.coeff(v))*source[v])
    return out
for name, expr in [('L contact',L.subs(u,k)),('J contact',JJ.subs(u,k)),('K contact',KK.subs(u,k)),('angular source jet',(s.diff(KK,u)+sig*s.diff(JJ,u)).subs(u,k)),('X first normal source jet',Jx.subs(u,k)),('Y first normal source jet',Jy.subs(u,k))]: ck(name,src(expr))
PM=s.cancel((ND+x*NB)/sig);H0=(x+zz*Q)/(x*(K+zz));E0=R/(K+zz)
ck('opposite first weak numerators',ND.subs(sig,0)+x*NB.subs(sig,0))
ck('weak numerator source H collapse',NB.subs(sig,0)-x*(K+zz)*(H-H0))
ck('weak mass residue',PM.subs(sig,0).subs(H,H0)/(2*x*K)-K*H0*E0/2)
# Generic centered excesses have exactly the same supports and vanish in value and all first jets.
# Check scalar source identities by setting each weight-excess to one independently.
Mtest=W-w*X+u*Y-u*w*Z; Rtest=u*W-Y
rows=[q*Mtest-k*M.subs(zz,z)*(w*Z/q), q*Rtest-x*(1-b*z)*(w*Z/q),(Y-x*b*w*Z)/q,Jw+Js.subs(zz,z)*Z,X+u*h*Z]
contact={u:k,w:q*s.symbols('f')/k,W:s.symbols('f')/q,X:-k*h*Z}
# Direct amplitude check using unreplaced X,Y and f^2=sigma.
f=s.symbols('f')
for i,row in enumerate(rows):
    val=s.expand(row.subs({Nx:0,Ny:0,u:k,w:q*f/k,W:f/q,Z:1}).subs(sig,f*f))
    ck('centered excess row '+str(i+1),val)
# etaH leading hard Schur and quartic block. Use sigma=0,H=H0 in coefficient polynomials.
limsrc={m:x*H0/(2*(1-zz*Q)),c:R/(2*x*(1-zz*b)*(K+zz)),a:H0/(2*b),l:x*R/(2*Q*(K+zz)),D:0,be:0}
def lim(expr): return s.factor(expr.subs(q*q,zz).subs(sig,0).subs(H,H0).subs(limsrc))
# Hard Ny,N block coefficients in conductor: Qy, A, LY N. Angular coefficients via monic divisions.
a11=lim(Qy.subs({w:0,u:k}));a22=lim(A.subs(u,k));a12=lim((Cy+sig*q*q/k*By).subs(u,k))/2
sx=lim(s.diff(Jy,u).subs(u,k))/2
sn=lim(s.diff(L,u).subs(u,k))/2
ss=lim(s.diff(KK,u,2).subs(u,k))/2
harddet=s.factor(a11*a22-a12*a12)
gamma=s.factor(ss-(a22*sx*sx-2*a12*sx*sn+a11*sn*sn)/harddet)
ck('etaH angular Schur',gamma-8*R*H0/K)
ck('etaH U block coefficient',lim(B.subs(u,k))-2*K*x*H0)
ck('etaH X U block coefficient',lim((Ax+q*q/k*Cx).subs(u,k))-4*K*x*H0)
ck('etaH quartic Schur',lim(B.subs(u,k))-(lim((Ax+q*q/k*Cx).subs(u,k)))**2/(8*K)-2*K*x*H0*E0)
# eta-unit angular Schur: z=0 coefficients, no source small-rate assumption.
Ju=1+sig*(x*H-1);th=1-sig*H
unit={m:K*x*H/(2*(K+sig)),c:K*(1-x*H)/(2*x*(K+sig)),a:1/(2*b*(K+sig)),l:x/(2*Q*(K+sig)),D:K/(2*Ju*(K+sig))-s.Rational(1,2),be:K/(2*th*(K+sig))-s.Rational(1,2)}
def ulim(expr):return s.factor(expr.subs(q,0).subs(unit))
# Qxy has q factor and off-block couplings q w vanish.
uyy=ulim(Qy.subs({w:0,u:k}));unn=ulim(A.subs(u,k));uyn=ulim((Cy+sig*q*q/k*By).subs(u,k))/2
uys=ulim(s.diff(Jy,u).subs(u,k))/2
uns=ulim((s.diff(L,u)+k*sig*s.diff(JJ,u)).subs(u,k))/2
uss=ulim(s.diff(KK,u,2).subs(u,k))/2
udety=s.factor(uyy*unn-uyn*uyn)
gs=s.factor(uss-(unn*uys*uys-2*uyn*uys*uns+uyy*uns*uns)/udety)
uxx=ulim(Qx.subs({w:0,u:k}));uuu=ulim(B.subs(u,k));uxu=ulim((Ax+q*q/k*Cx).subs(u,k))/2
uxt=ulim(s.diff(Jx,u).subs(u,k)/sig)/2
uut=ulim(-k*s.diff(JJ,u).subs(u,k))/2
utt=ulim(s.diff(JJ,u,2).subs(u,k))/2
udetx=s.factor(uxx*uuu-uxu*uxu)
gt=s.factor(utt-(uuu*uxt*uxt-2*uxu*uxt*uut+uxx*uut*uut)/udetx)
ph=K*x*(K+4*sig)*H**2-2*K*(x+2*sig)*H+x
ck('eta-unit angular combined Schur',gs+sig*gt+2*ph/(sig*(K+sig)))
ck('angular polynomial lower endpoint',ph.subs(H,1/(K+sig))+sig*(3*sig*x+4*sig+4*x+4)/(K+sig)**2)
ck('angular polynomial upper endpoint',ph.subs(H,(x+sig)/(x*(K+sig)))+sig*(4*sig*x+3*sig+4*x*x+4*x)/(x*(K+sig)**2))
min_y=b*(2*b*x*zz-x+1)/K
min_n=(4*b*x*zz-x-2*zz+1)/(x*K)
ck('etaH bounded hard minimizer Y',min_y+(a22*sx-a12*sn)/harddet)
ck('etaH bounded hard minimizer N',min_n+(-a12*sx+a11*sn)/harddet)
uxmin=(sig*H*H*x*K-H*x*K-sig*H*(2*x+1)+x)/(sig*K)
uumin=(H*x*K*(K+sig)-x*K-sig)/(x*sig*K)
ck('eta-unit bounded X minimizer',uxmin+(uuu*uxt-uxu*uut)/udetx)
ck('eta-unit bounded U minimizer',uumin+(-uxu*uxt+uxx*uut)/udetx)
ck('eta-unit D face defect',k*(uxmin+uumin)+(1-x*H)/k-k*(H*K-1)*Ju/(sig*K))
ck('eta-unit beta face defect',uxmin+H+x*th*(H*K-1)/(sig*K))
caprows=[u*z*Ny-(k*(1+x*z*b)+z*delta)*N-q*w*Nx-z*(1-x*b)/k*S,
         S-z*Ny-x*(1-b*z)*N,Ny-x*b*N,
         j*U+u*Nx-q*w*Ny+(1-x*H)/k*TT,Nx+H*TT]
for i,(row,normalrow) in enumerate(zip(rows,caprows)):
    ck('full centered cap normal row '+str(i+1),row-normalrow)
vv=s.symbols('V')
EH=1-x*H; AH=x*x*H+EH*vv; den=Ju+th*vv
NP=vv*(K+sig)-AH*den
BP=K*(1+vv)-(K+sig)*den
QP=EH**2*th**2*vv**2+2*EH*(x*th**2+EH*th*Ju+(K+sig)*th-2*K)*vv+x*x*H*H*Ju*Ju
ck('away discriminant factorization',NP**2-4*AH*vv*BP-(vv-x)**2*QP)
ck('away quadratic matched value',QP.subs(vv,x)-x*ph)
ck('away concave polynomial matched value',NP.subs(vv,x)-2*x*sig)
ck('double opening away gap',((K*x*H+K*EH*vv/x)*x*(1+vv)-K*K*vv).subs({sig:K,H:1/K})-(vv-x)**2)
# The last Schur check is a polynomial identity after multiplying the
# displayed positive denominator, avoiding a combinatorial rational gcd.
xx=s.symbols('X0');kx=1+xx;rx=b*zz;qx=1-xx*b;rr=1+xx*rx
mm=1-zz*qx;hh=xx+zz*qx;bn=vv*(1-rx)+rr;ln=vv*hh+xx*mm
adj=xx*hh*(1-rx)*bn*ln+rr*vv*mm*bn*ln-vv*hh*b*kx*kx*mm*ln-xx*vv*rr*kx*kx*qx*(1-rx)*bn-(vv-xx)**2*(1+vv)*rr*hh*mm*(1-rx)
ck('etaH all-opening away Schur',adj)
cc=rr/(2*xx*(1-rx)*(kx+zz));mc=hh/(2*(kx+zz)*mm)
BH=2*hh*bn/(b*xx*(1-rx)*(kx+zz));LH=2*rr*ln/(qx*(kx+zz)*mm)
ck('etaH all-opening F minimizer',2*(2*cc*zz+1)*b*xx*(1-rx)*(kx+zz)-2*hh*b*kx)
ck('etaH all-opening F-G minimizer',2*(2*mc*zz+1)*qx*(kx+zz)*mm-2*rr*kx*qx)
report={'checks':checks,'count':len(checks),'all_pass':all(i['pass'] for i in checks),'seconds':time.monotonic()-start,'scope':'Exact complete normal coefficients, source contact jets, homogeneous conductor, centered excess zeros, weak source mass, and both angular/normal Schur identities; no numerical sampling.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2))
print(json.dumps({'count':len(checks),'seconds':report['seconds'],'all_pass':report['all_pass']}),flush=True)
