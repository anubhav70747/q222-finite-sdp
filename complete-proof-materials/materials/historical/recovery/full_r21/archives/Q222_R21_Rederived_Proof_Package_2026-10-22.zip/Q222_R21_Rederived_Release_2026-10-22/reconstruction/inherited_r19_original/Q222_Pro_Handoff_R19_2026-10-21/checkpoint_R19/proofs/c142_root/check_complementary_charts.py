"""Focused exact identities for CF; no numerical positivity certificate."""
import json
from pathlib import Path
import sympy as s

checks = {}
def ck(name, expr):
    assert s.cancel(expr) == 0, (name, s.factor(expr))
    checks[name] = True
    print('PASS ' + name, flush=True)

x,sg,h,q,u,w,f,Z,lam=s.symbols('x sigma h q u w f Z lambda')
z=q*q; W=f*Z; H=h/sg; ss=x/sg; rho=lam*x/sg
R=w*Z/q-u*q*W; Gm=sg*Z-u*w*W
A=q*(u*u-x)*W; Pb=u*Z-x*w*W/sg
Uh,lh=s.symbols('U_h L_h')
# Use a formal sqrt(h)=v to keep every test polynomial rational.
v=s.symbols('sqrt_h', nonzero=True)
Us=v*u*Z
Ps=lam*sg*Pb**2+rho*(u*u-x)*(w*w-sg*z)*W**2
rhs=(lam*sg/h)*((1-ss*z*f*f)*Us-v*ss*q*f*R)**2
rhs+=rho*(u*w*W)**2+lam*(x*q*W)**2
rhs-=(lam*sg/h)*ss*z*f*f*Us**2
rhs-=(lam*sg/h)*ss**2*(v*q*f*R+z*f*f*Us)**2
ck('CF3 whole scalar including both negative packets',(Ps-rhs).subs(h,v*v))
Bf=(sg-x*z*f*f)/v
ck('CF4 full u Gamma conductor',u*Gm-Bf*Us+u*q*f*A+u*u*q*f*R)
ck('CF4 full qw Gamma conductor',q*w*Gm-q*z*f*Bf*Us+u*z*z*f*f*A-z*(sg-u*f*w-u*u*z*f*f)*R)
ck('CF5 exact h-unit angular allocation',A-q*f*u*Us/v+x*q*W)

# Source residue follows exact polynomial divisibility SP10, not
# multiplication of an unspecified infinitesimal by H.
b,r=s.symbols('b r')
th=1-h; K=1+x
P=sg+K+sg*z*(1+b*x+2*x*h)+sg*b*x*x*h*z*z+x*x*h*th*z
M=1+x*b*z-x*z*th
Nk=K*(1+sg*b*z)*(1+sg*z)-M*P
Fs=s.cancel((Nk-Nk.subs(sg,0))/sg)
ck('CF2 exact alpha-kappa residue polynomial',Fs.subs({x:0,sg:0})-(b*z-1))
H0=1+z-b*z; pp=H0/2; ll=s.Rational(1,2)
alpha_res=-2*h*(1-b*z); lam0_res=-2*(1-h)*H0
ka_res=alpha_res-lam0_res
ck('CF2 bounded K_A residue',ka_res-2*(H0-h*(H0+1-b*z)))
chi_res=8*(pp*b+ll*(1-b))-4*h+4*z*((h-1+b)**2+h*(1-h))
ck('CF2 complete chi residue',chi_res-4*(H0-h*(1+z-2*b*z)))

V=u*w*(u*u-x)*W
ck('CF8 exact syzygy full state',V*V-sg*u*u*A*A-u*sg*(u*u-x)*A*R+(u*u-x)*V*Gm)
H00,S0=s.symbols('H0_residue S0_residue')
det=s.det(s.Matrix([[2*H00,S0/2],[S0/2,1+S0*S0]]))
ck('CF9 strict final two by two determinant',det-2*H00-(2*H00-s.Rational(1,4))*S0*S0)

result={'status':'PASS','count':len(checks),'checks':checks,
 'scope':['C14.2 H unbounded and W/Z bounded: complete parent via exact SP6 and radial decomposition',
          'C14.2 beta*theta/sigma^2 bounded: complete parent at remaining small tests',
          'lambda nonpositive and H bounded enters the second source case'],
 'imported':['SP6 and JR5/JB1 complete parent','BE source identities','CT7-CT7a exact radial decomposition','bounded separated-Gram lemma'],
 'limitations':'Algebra checks do not substitute for the accompanying ordered-field and boundedness proof.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(str(len(checks))+' focused exact checks passed',flush=True)
