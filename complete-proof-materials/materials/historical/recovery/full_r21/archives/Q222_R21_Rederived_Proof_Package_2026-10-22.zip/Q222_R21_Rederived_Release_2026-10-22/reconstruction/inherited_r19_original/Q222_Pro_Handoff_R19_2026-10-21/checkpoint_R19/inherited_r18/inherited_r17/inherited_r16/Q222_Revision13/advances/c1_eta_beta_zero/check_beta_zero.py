import sympy as s,time,json
from pathlib import Path
x,z,b,h,sg,t,xi=s.symbols('x z b h sigma t xi');Q=1-b;th=1-h
m,C,D,bt,ab,lq=s.symbols('m C D bt ab lq')
cg=4*(1+t)*(ab*b*(1+xi)+lq*Q)
T=1+t*h+b*xi;Jf=1-T/sg;M0=1+t*(h-Q)*xi/sg;Rf=1-b*xi/sg
phi=4*m*M0*M0+4*C*(1+xi)*t*Rf*Rf+cg*t*(2*xi/sg-z)+4*D*t*xi*Jf*Jf+4*bt*th*(1+xi)*t*t*xi/sg**2
phi+=2*(t*xi*Jf*Jf+(1+t)*t*Q*Q*xi*xi/sg**2+(1+xi)*t*t*th*th*xi/sg**2-(1+t)*(1+xi)*t*xi/sg**2)
Lz=8*m*(h-Q)*M0-8*C*(1+xi)*b*Rf+2*cg-(8*D+4)*T*Jf+8*bt*th*(1+xi)*t/sg+4*(1+t)*Q*Q*xi/sg+4*(1+xi)*t*th*th/sg-4*(1+t)*(1+xi)/sg
expr=s.factor((s.diff(Lz,t)/sg-s.diff(phi,t,xi)/x).subs({t:x,xi:sg*z,bt:0}))

K=1+x;r=b*z;R=1+x*r;M=R-x*z*th;J=1+x*h-sg*(1-r);E=1-x*h/sg
P=sg+K+sg*z*(1+b*x+2*x*h)+sg*b*x*x*h*z*z+x*x*h*th*z
src={m:K*(1+sg*r)*h*(1+sg*z)*x*x*z/(2*sg*M*P),C:K*(1+sg*r)*E*z/(2*(1-r)*P),D:K*(1+sg*z)*(1+sg*r)/(2*J*P)-s.Rational(1,2),ab:(z*(1+x*h)*E+(1-r)*(1+x*h*z))/(2*P),lq:(1+sg*r)*((x/sg)*R*h*(1+sg*z)+M*E)/(2*P)}
# Verify the displayed T identity on the literal original beta face.
start=time.monotonic(); checks={}
def ck(name,ok):
    checks[name]=bool(ok)
    print(('PASS ' if ok else 'FAIL ')+name,flush=True)
    if not ok: raise AssertionError(name)
H=h/sg
TT=1+z*(1-2*b)-b*Q*z*z+H*z*Q
TT+=H*x*z*(b*(z-1)+sg*(1-r)*(2-r))
TT+=H*H*x*((1+x)*(1-z)+sg*z*(1-r))
target=2*(1+sg*r)*TT/(J*P)
NB=s.expand(K*(1+sg*r)*(1+x*h*z)-th*P)
# Clear a known common pure-source denominator before substitution; avoid
# a large unrestricted rational cancellation of the entire parent coefficient.
common=2*sg*M*P*J*(1-r)
generic=s.Poly(s.expand(s.cancel(expr*sg*sg*x/2)),tuple(src))
constant=generic.coeff_monomial((0,)*len(src))*common
combined=constant
for weight in src:
    combined+=generic.coeff_monomial(weight)*s.cancel(common*src[weight])
Tclear=s.expand(s.cancel(sg*sg*TT))
diffnum=s.expand(2*combined-4*sg*x*M*(1-r)*(1+sg*r)*Tclear)
vars=(h,x,z,b,sg)
remainder=s.Poly(diffnum,*vars).rem(s.Poly(NB,*vars))
ck('displayed contact identity modulo original beta numerator',remainder.is_zero)
# Independent exact boundary checks use the same scalar parent, not a copied value.
phi_boundary=s.cancel(phi.subs({m:0,C:0,D:sg*sg/(2*(1-sg*sg)),bt:0,ab:1/(2*(1+sg)),lq:1/(2*(1+sg)),z:0,h:sg/(1+sg)}))
radial=s.Poly(s.expand(phi_boundary),t,xi).coeff_monomial(t*xi*xi)
ck('boundary radial coefficient on beta zero',s.cancel(radial-2*b*b/(sg*sg))==0)
pole=2*(h*sg+h+sg*sg-sg)/(sg*sg*(1-sg*sg))
ck('boundary combined pole cancellation',s.cancel(pole.subs(h,sg/(1+sg))-2/(1-sg*sg))==0)
out={'scope':'C14.1 literal beta=0: exact combined contact coefficient and boundary radial diagnostic only; no full-parent admission','checks':checks,'passed':len(checks),'seconds':round(time.monotonic()-start,3)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(str(len(checks))+' exact assertions passed',flush=True)
