# Q222 analytical proof package — revision 4

The global atlas-free proof is **unfinished**. This revision closes four of the preceding thirteen whole conditional leaves. Nine remain. The number is a partition count, not a percentage of difficulty or a claim that each residual set is nonempty.

The main manuscript is `Q222_Analytical_Revision_2026-10-18.pdf`; its editable source has the same name with `.tex`. Read the opening explanation and precise checklist first. Every new proof is analytical; exact Python checks corroborate identities and are not numerical positivity tables.

## New completed mathematics

- C1.2 and C1.3: the entire bounded-unit-eta branch with k,zeta infinitesimal, every positive e and native r, all independent tests and all states. The proofs keep the original parent, complete normals and arbitrary opening rates.
- Actual unit/unit C1 subdomain: a division-free source identity forces entry into the inherited five-event theorem. This removes only that subdomain of C1.5.
- C2.W.HI and C2.W.HU: original-source n>=0 excludes the directed weak-C domains, including n=0.
- **A two-square theorem for real-rational physical source curves.** Factor the cleared parent over the testing field on a real interval; each factor evaluates into at most two separated squares, and the two-square product identity preserves that bound. The exact strong-II family and the displayed weak-IH/HH/radial example curves are all-tests admissions. General sources with several independent non-real parameters remain outside this argument.
- The same exact strong-II parent has no polynomial SOS in free angle/state variables. Two zero Gram diagonals and one positive contact imbalance prove this. Pointwise tensor SOS permits pure testing-field factors, so the two results are compatible.

## Further results with a local testing scope

- Weak-C IH: an exact seven-root full-parent Gram for u and 1/v infinitesimal or zero, assuming rho and 1-rho are positive units. The positive parameters r,H,1-H are arbitrary; n may be unbounded or exactly zero. Source boundaries and remote testing joins remain open.
- Strong C2 UI: the contact neighborhood v infinitesimal and u-a infinitesimal, all original opening rates, all states and n=0. The other commuting axes and outer projective join remain open.

The half-corner and mixed-multiplier calculations for the exact curve are preserved as auxiliary constructions. The mixed multiplier is not cancelled. That family now has a different complete proof through interval factorization.

## Current authority and reproduction

`CHECKLIST.json`, `CHECKLIST.md`, `PROOF_STATUS.json` and `PROOF_GRAPH.json` are the current ledgers. They supersede every historical ledger under `baseline/`. The complete preceding delivered archive is preserved there byte for byte, with 365 file hashes in `verification/EXACT_BASELINE.json`.

```bash
python3 verify.py --integrity-only
python3 verify.py --with-sympy
```

The second command needs SymPy. It runs the current small exact checkers in a temporary copy and preserves distributed receipts. Add `--with-baseline` only if a replay of the preceding package is wanted. No new global atlas replay or certification is claimed.

To rebuild the PDF, run `pdflatex -interaction=nonstopmode -halt-on-error Q222_Analytical_Revision_2026-10-18.tex` twice from this directory. A standard TeX Live installation with the packages named in the preamble is sufficient. Review notes are separate-agent or supervising-agent checks within the same system, not external peer review or formal verification.

Universal coverage and application of the finite-lift bridge remain blocked by the residual domains. An evaluated global affine SDP pencil is a separate deliverable and is not supplied.
