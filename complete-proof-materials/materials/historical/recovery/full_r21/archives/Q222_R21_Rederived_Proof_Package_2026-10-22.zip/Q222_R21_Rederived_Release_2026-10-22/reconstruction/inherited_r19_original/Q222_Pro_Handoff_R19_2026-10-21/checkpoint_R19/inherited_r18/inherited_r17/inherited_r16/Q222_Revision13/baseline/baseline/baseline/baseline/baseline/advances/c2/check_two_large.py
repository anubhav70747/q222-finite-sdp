"""Small exact checks for the C2 n,D-unbounded pitchfork.
SymPy expands only the original quadratic parent and its three graph normals.
No atlas, numerical samples, or source-to-test identification is used.
"""
import sympy as s
from pathlib import Path
import json,time
start=time.perf_counter(); checks=[]
def zero(name,p):
    p=s.cancel(p)
    assert p==0,(name,p)
    checks.append(name)
def shape(name,p,u,minpow,parity):
    p=s.Poly(s.expand(p),u)
    assert all(e[0]>=minpow and e[0]%2==parity for e,c in p.terms()),name
    checks.append(name)
d,n,m,C,A,D,al,u,v,W,X,Y,Z,x,z,j,q,ell=s.symbols('d n m C A D al u v W X Y Z x z j q ell')
Du=1+u*u;Dv=1+v*v
R2=v*W-X+u*v*Y-u*Z;r=u*W-Y;J=u*W+u*v*X-Y-v*Z;p=v*Y-Z;B=X+u*Z
H=2*(J**2+Du*p**2+Dv*B**2-Du*Dv*Z**2)
F=d*H+4*n*Du*Dv*X**2+4*m*R2**2+4*C*Dv*r**2+4*A*Du*Dv*Y**2+4*D*J**2+4*al*Du*p**2
graph={W:1,X:x*u*u,Y:u*(1-j-v*z+x*u*u*v),Z:z*u}
G=s.expand(F.subs(graph,simultaneous=True))
FX=s.expand((s.diff(F,X)+u*v*s.diff(F,Y)).subs(graph,simultaneous=True))
FJ=s.expand((-s.diff(F,Y)).subs(graph,simultaneous=True))
FZ=s.expand((s.diff(F,Z)-v*s.diff(F,Y)).subs(graph,simultaneous=True))
zero('graph has exact J=j*u',J.subs(graph,simultaneous=True)-j*u)
shape('full scalar 4mv²+u² H(u²,v)',G-4*m*v*v,u,2,0)
shape('full X-normal -8mv+u² Lx',FX+8*m*v,u,2,0)
shape('full J-normal u LJ',FJ,u,1,1)
shape('full Z-normal u LZ',FZ,u,1,1)
zero('full n graph term',s.diff(G,n)-4*x*x*u**4*Du*Dv)
zero('full D graph term',s.diff(G,D)-4*j*j*u*u)
zero('full n X-normal term',s.diff(FX,n)-8*x*u*u*Du*Dv)
zero('D absent from adapted X normal',s.diff(FX,D))
zero('full D J-normal term',s.diff(FJ,D)-8*j*u)
zero('n absent from adapted J normal',s.diff(FJ,n))
zero('n absent from adapted Z normal',s.diff(FZ,n))
zero('D absent from adapted Z normal',s.diff(FZ,D))
# Independent hard coordinates before their pure coefficient scaling.
eX,eJ,eZ=s.symbols('eX eJ eZ')
adapt={X:x*u*u+eX,Z:z*u+eZ,Y:u*(1-j)+u*v*(x*u*u+eX)-v*(z*u+eZ)-eJ,W:1}
Fa=s.expand(F.subs(adapt,simultaneous=True))
zero('D hard block is exactly its one root square',s.diff(Fa,D)-4*(j*u+eJ)**2)
zero('n hard block is exactly its one root square',s.diff(Fa,n)-4*Du*Dv*(x*u*u+eX)**2)
# Exact original boundary form with m=0, X=0, Y=u*y,Z=u*z.
y=s.symbols('y')
lead=s.Poly(s.expand(F.subs({m:0,W:1,X:0,Y:y*u,Z:z*u},simultaneous=True)),u).coeff_monomial(u*u)
b11=(4*(C+A)+2*d)*Dv+4*D+4*al*v*v
b22=4*D*v*v+4*al;b12=4*v*(D-al)
l1=-4*C*Dv-(4*D+2*d);l2=-(4*D+2*d)*v;cc=4*C*Dv+4*D+2*d
zero('complete real boundary hard form',lead-(b11*y*y+2*b12*y*z+b22*z*z+2*l1*y+2*l2*z+cc))
detB=s.expand(b11*b22-b12*b12)
num=s.expand(detB*cc-(b22*l1*l1-2*b12*l1*l2+b11*l2*l2))
Q10=4*al*A*(d+2*(C+D));Q12=4*C*D*(d+2*(al+A))
quot=s.cancel(num/(8*Dv));assert s.denom(quot)==1
Q0=s.Poly(quot,v).coeff_monomial(v*v)
zero('exact real boundary quartic',quot-Q10-Q0*v*v-Q12*v**4)
assert s.degree(Q0,D)<=1;checks.append('middle quartic coefficient affine in D')
assert s.degree(detB,D)<=1;checks.append('hard determinant affine in D')
zero('hard determinant leading D coefficient',s.diff(detB,D)-4*((4*(C+A)+2*d)*Dv*v*v+4*al*Dv*Dv))
zero('uniform n,D reciprocal identity',n/(d+2*n)+(1+2*D/(d+2*n))/(d+2*D)-(n+1)/(d+2*n)-2*n/((d+2*n)*(d+2*D)))
# Entire outer remainder after retaining m,n, with scaled root represented
# temporarily by ell=J (then ell=KJ/sqrt(D), a pure source substitution).
outer=s.expand(F.subs({m:0,n:0,Y:u*W+u*v*X-v*Z-ell},simultaneous=True))
poly=s.Poly(outer,W,X,Z,ell,u,v)
assert all(e[4]>=e[0] for e,c0 in poly.terms());checks.append('entire finite outer form in X,Z,J,uW')
zero('outer D term exactly 4D J²',s.diff(outer,D)-4*ell**2)
Fh=s.cancel(q*q*F.subs(v,1/q))
outerh=s.expand(Fh.subs({m:0,n:0,Z:q*u*W+u*X-q*Y-ell},simultaneous=True))
poly=s.Poly(outerh,W,X,Y,ell,u,q)
assert all(e[4]>=e[0] for e,c0 in poly.terms());checks.append('entire reciprocal outer form in X,Y,Jh,uW')
zero('reciprocal outer D term exactly 4D Jh²',s.diff(outerh,D)-4*ell**2)
# The D-infinite hard-state residue after the root scaling.
eps=s.symbols('eps',positive=True)
scaled=s.expand((b11*y*y+2*b12*y*z+b22*z*z).subs({y:-v*eZ-eJ*eps,z:eZ,D:1/eps**2},simultaneous=True))
zero('exact D-infinite hard block residue',s.limit(scaled,eps,0)-(4*eJ**2+((4*(C+A)+2*d)*Dv*v*v+4*al*Dv*Dv)*eZ**2))
report={'status':'PASS','count':len(checks),'checks':checks,'seconds':round(time.perf_counter()-start,3),'arithmetic':'exact symbolic polynomial identities','scope':'graph and all first normals; complete large-packet hard terms; real Schur quartic; two full outer root forms. Ordered-field estimates and full-parent positivity are proved in accompanying TeX.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
