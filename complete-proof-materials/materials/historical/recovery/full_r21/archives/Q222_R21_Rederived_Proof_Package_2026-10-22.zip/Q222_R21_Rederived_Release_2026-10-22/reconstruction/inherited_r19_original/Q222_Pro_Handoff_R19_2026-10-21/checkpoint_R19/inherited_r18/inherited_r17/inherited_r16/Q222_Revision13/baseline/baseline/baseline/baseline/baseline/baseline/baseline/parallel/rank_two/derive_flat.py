import sympy as s
u,v,n,m,A,D,d=s.symbols('u v n m A D d')
Du,Dv=1+u*u,1+v*v
r=lambda x:s.Matrix([x])
eX=s.Matrix([0,1,0,0]);eY=s.Matrix([0,0,1,0]);eZ=s.Matrix([0,0,0,1])
eM=s.Matrix([v,-1,u*v,-u]);eD=s.Matrix([u,u*v,-1,-v]);ea=s.Matrix([0,0,v,-1]);eb=s.Matrix([0,1,0,u])
P=4*n*Du*Dv*eX*eX.T+4*m*eM*eM.T+4*A*Du*Dv*eY*eY.T+(4*D+2*d)*eD*eD.T+2*d*Du*ea*ea.T+2*d*Dv*eb*eb.T-2*d*Du*Dv*eZ*eZ.T
print('det computing',flush=True)
f=s.factor(P.det(method='domain-ge'))
print(f)
open('/workspace/scratch/964ce4ea4964/work/advance_2026_10_17/rank_two/flat_det.txt','w').write(str(f))
