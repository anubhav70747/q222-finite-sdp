#!/usr/bin/env python3
"""Replay only this continuation's small exact suites, without numerical sampling."""
from pathlib import Path
import argparse, json, os, subprocess, sys, time
if not __debug__:
    raise SystemExit('Run without -O: checks use exact assertions.')
root=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument('--with-sympy',action='store_true')
ap.add_argument('--with-local',action='store_true',help='also replay the more extensive one-weak local source check; implies --with-sympy')
args=ap.parse_args()
jobs=['c1/check_ordinary_angle.py','bridge/check_circuits.py']
if args.with_sympy or args.with_local:
    jobs += ['contact/check_contact_entry.py','c2/check_automatic_matching.py']
if args.with_local:
    jobs += ['c2/check_single_angle_terminal.py']
reports=[]
for job in jobs:
    env=os.environ.copy(); env.pop('PYTHONOPTIMIZE',None)
    start=time.monotonic()
    p=subprocess.run([sys.executable,str(root/job)],cwd=root,env=env,text=True,capture_output=True)
    reports.append({'script':job,'exit_code':p.returncode,'seconds':round(time.monotonic()-start,3)})
    print(('PASS ' if p.returncode==0 else 'FAIL ')+job,flush=True)
    if p.returncode:
        print(p.stdout);print(p.stderr,file=sys.stderr)
report={'status':'PASS' if all(r['exit_code']==0 for r in reports) else 'FAIL',
        'with_sympy':args.with_sympy or args.with_local,'with_local':args.with_local,'suites':reports,
        'scope':'New exact identity suites only. This does not certify global analytical coverage or replay the inherited atlas.'}
(root/'verification').mkdir(exist_ok=True)
(root/'verification/FRESH_CHECKS.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
raise SystemExit(0 if report['status']=='PASS' else 1)
