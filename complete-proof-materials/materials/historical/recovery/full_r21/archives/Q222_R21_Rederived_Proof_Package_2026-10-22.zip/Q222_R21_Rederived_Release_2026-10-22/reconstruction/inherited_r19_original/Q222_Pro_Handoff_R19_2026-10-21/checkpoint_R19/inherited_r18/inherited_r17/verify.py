from pathlib import Path
import argparse,hashlib,json,subprocess,sys
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--identities',action='store_true');args=p.parse_args()
if args.identities:
    scripts=sorted((root/'proofs').glob('*/check_*.py'))+sorted((root/'proofs').glob('*/review_r5_direct.py'))
    for script in scripts:
        print('Running',script.relative_to(root),flush=True)
        subprocess.run([sys.executable,str(script)],cwd=root,check=True)
    print('PASS: new focused identities. Global theorem still OPEN.')
else:
    manifest=json.loads((root/'MANIFEST_R17.json').read_text())
    for item in manifest['files']:
        f=root/item['path']; actual=hashlib.sha256(f.read_bytes()).hexdigest()
        if actual!=item['sha256']:raise SystemExit('Integrity failure: '+item['path'])
    frontier=json.loads((root/'FRONTIER_R17.json').read_text())
    assert frontier['new_whole_shape_admissions']==['R5','R8']
    assert frontier['open_weak_C2']==['R1','R2','R3','R4','R6','R7']
    assert len(frontier['open_C1'])==6 and frontier['global_theorem']=='OPEN'
    print('PASS:',len(manifest['files']),'file hashes and current admission accounting.')
