"""Targeted new receipts for the complete eta-unit C14.3a opening closure."""
import sympy as s,json
from pathlib import Path
a,L,t,r,pi=s.symbols('a L eta r pi')
x=a*L;h=1-L*pi;th=L*pi;K=1+x;R=1+x*r;M=R-a*th;y=t*L
Es=1-x*t*h;Q=1-L*r
Pd=1+2*x*h+r*x*x*h+r*x*L+L+t*(K*L+x*x*h*th)
P4=(1+x*h)*Es+(1-r)*(x*h+L)
Cc=K*(r+t)*Es/(2*Pd)
Aa=t*P4/(2*Pd)
Dpj=K*(1+y)*(r+t)/(2*Pd)
m=K*a*a*L*(r+t)*h*(1+y)/(2*M*Pd)
al=L*L*(r+t)*(a*R*h*(1+y)+M*Es)/(2*Q*Pd)
Bth=K*(r+t)*L*(1+a*h)/(2*Pd)
q=al+m*th*th+Bth*th;mu=m-a*a*q
rTm=Aa+r*(al+s.Rational(1,2)+m)
bp=P4/(2*Pd)-m*th-al-s.Rational(1,2)+rTm*L/2
kappat=2*(t*Bth-Dpj-m*r)
rhor=m+rTm*x/2
def finite_ratio(expr):
 num,den=s.fraction(s.together(expr))
 num=s.expand(num);den=s.expand(den)
 for var in (a,L,t):
  pd=s.Poly(den,var); k=min(mon[0] for mon,co in pd.terms())
  if k:
   pn=s.Poly(num,var)
   quotient,remainder=s.div(pn,s.Poly(var**k,var))
   assert remainder.is_zero,('uncanceled monomial',var,k)
   num=quotient.as_expr(); den=s.Poly(den,var).exquo(s.Poly(var**k,var)).as_expr()
 return num,den

checks={};reports={}
def ck(n,f):
 val=s.cancel(f)
 assert val==0,(n,s.factor(val))
 checks[n]=True
 print('PASS',n,flush=True)
def audit(n,expr,target):
 num,den=finite_ratio(expr);val=num/den
 d0=s.factor(den.subs({a:0,L:0}))
 assert d0!=0,(n,'bad denominator')
 res=s.factor(val.subs({a:0,L:0}))
 ck(n+'_residue',res-target)
 reports[n]={'residue':str(res),'denominator_at_a_L_zero':str(d0)}
 audit_zero=s.factor(d0)
 # The displayed denominators are real constants or retained eta-unit factors.
 assert not audit_zero.has(r,pi),(n,'uncleared source opening',audit_zero)

audit('C_cleared',Cc,(r+t)/2)
audit('A_cleared',Aa,t/2)
audit('Dplus_cleared',Dpj,(r+t)/2)
audit('m_a2L',m/(a*a*L),(r+t)/2)
audit('alpha_L2',al/(L*L),(r+t)/2)
audit('Btheta_L',Bth/L,(r+t)/2)
audit('q_L2',q/(L*L),(r+t)*(1+pi)/2)
audit('mu_a2L',mu/(a*a*L),(r+t)/2)
audit('r_Tm',rTm,(r+t)/2)
audit('bprime_L',bp/L,-(r+t)/4)
audit('eta_kappa',kappat,-(r+t))
audit('radial_rho_x',rhor/x,(r+t)/4)
# The decisive all-normal cancellation is source-free and is not inferred from a jet.
u,v,E,Qt,Fb,Ft,xi,ka,ga,bp0,hh,mm,rr,tt=s.symbols('u v E Qt Fb Ft xi kappa gamma bp h m r eta',nonzero=True)
Btheta,Dpj0=s.symbols('Btheta Dpj')
ks=2*(Btheta-Dpj0/tt-mm*rr/tt)
gs=2*bp0/hh+2*Dpj0/rr-2*tt*Btheta/rr
ck('exact_kappa_gamma_cancellation',tt*ks/rr+gs-(2*bp0/hh-2*mm))
ck('entire_two_normal_Fb_rewrite',(ka*u*Ft*xi+ga*u*v*Qt*xi-(ka*u*Fb*xi+u*v*((2*bp0/hh-2*mm)*Qt-ka*E)*xi)).subs({Ft:Fb-v*E+(tt/rr)*v*Qt,ka:ks,ga:gs}))
# Radial root coefficient boundedness is an exact factorization; its bounds are in the proof.
Tm,Kr,ee,yy,qq,LL=s.symbols('Tm Kr e4 y q L',positive=True)
ck('radial_angular_cross_normalization',(rr*rr*Tm/tt**2)*(tt*LL)*(tt/(rr*s.sqrt(Kr)))-(rr*Tm*LL/s.sqrt(Kr)))
output={'status':'PASS','count':len(checks),'checks':checks,'reports':reports,
'scope':'C14.3a eta positive bounded unit, arbitrary actual j>0 and all r openings: source arrays and complete first-normal cancellation for all-state local closure. Remote join uses the unchanged bounded-eta small-L theorem.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps(output,indent=2))
