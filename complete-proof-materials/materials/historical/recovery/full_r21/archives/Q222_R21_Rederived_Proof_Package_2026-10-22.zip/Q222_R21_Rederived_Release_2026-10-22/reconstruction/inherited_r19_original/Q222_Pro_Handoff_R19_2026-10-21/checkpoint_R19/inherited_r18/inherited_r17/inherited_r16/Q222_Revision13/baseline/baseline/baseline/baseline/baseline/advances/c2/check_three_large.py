"""Exact original-parent checks for C2 arbitrary n,A,D pitchfork."""
import sympy as s
from pathlib import Path
import json,time
start=time.perf_counter();checks=[]
def zero(name,p):
    p=s.cancel(p)
    assert p==0,(name,p)
    checks.append(name)
def shape(name,p,u,minpow,parity):
    p=s.Poly(s.expand(p),u)
    assert all(e[0]>=minpow and e[0]%2==parity for e,c in p.terms()),name
    checks.append(name)
d,n,m,C,A,D,al,u,v,W,X,Y,Z,x,y,j,q,ell,eta=s.symbols('d n m C A D al u v W X Y Z x y j q ell eta')
Du=1+u*u;Dv=1+v*v
R2=v*W-X+u*v*Y-u*Z;r=u*W-Y;J=u*W+u*v*X-Y-v*Z;p=v*Y-Z;B=X+u*Z
H=2*(J**2+Du*p**2+Dv*B**2-Du*Dv*Z**2)
F=d*H+4*n*Du*Dv*X**2+4*m*R2**2+4*C*Dv*r**2+4*A*Du*Dv*Y**2+4*D*J**2+4*al*Du*p**2
b=1-j-y
graph={W:1,X:x*u*u,Y:y*u,Z:u*(b/v+x*u*u)}
G=s.expand(F.subs(graph,simultaneous=True))
FX=s.expand((s.diff(F,X)+u*s.diff(F,Z)).subs(graph,simultaneous=True))
FY=s.expand((s.diff(F,Y)-s.diff(F,Z)/v).subs(graph,simultaneous=True))
FJ=s.expand((-s.diff(F,Z)/v).subs(graph,simultaneous=True))
zero('graph has exact J=j*u',J.subs(graph,simultaneous=True)-j*u)
shape('full scalar 4mv²+u² H(u²,v)',G-4*m*v*v,u,2,0)
shape('full X-normal -8mv+u² Lx',FX+8*m*v,u,2,0)
shape('full Y-normal u LY',FY,u,1,1)
shape('full J-normal u LJ',FJ,u,1,1)
zero('full n graph term',s.diff(G,n)-4*x*x*u**4*Du*Dv)
zero('full A graph term',s.diff(G,A)-4*y*y*u*u*Du*Dv)
zero('full D graph term',s.diff(G,D)-4*j*j*u*u)
zero('full n X-normal term',s.diff(FX,n)-8*x*u*u*Du*Dv)
zero('A absent from adapted X normal',s.diff(FX,A))
zero('D absent from adapted X normal',s.diff(FX,D))
zero('full A Y-normal term',s.diff(FY,A)-8*y*u*Du*Dv)
zero('n absent from adapted Y normal',s.diff(FY,n))
zero('D absent from adapted Y normal',s.diff(FY,D))
zero('full D J-normal term',s.diff(FJ,D)-8*j*u)
zero('n absent from adapted J normal',s.diff(FJ,n))
zero('A absent from adapted J normal',s.diff(FJ,A))
eX,eY,eJ=s.symbols('eX eY eJ')
adapt={X:x*u*u+eX,Y:y*u+eY,Z:(u+u*v*(x*u*u+eX)-(y*u+eY)-(j*u+eJ))/v,W:1}
Fa=s.expand(F.subs(adapt,simultaneous=True))
zero('D hard block exactly one root square',s.diff(Fa,D)-4*(j*u+eJ)**2)
zero('A hard block exactly one root square',s.diff(Fa,A)-4*Du*Dv*(y*u+eY)**2)
zero('n hard block exactly one root square',s.diff(Fa,n)-4*Du*Dv*(x*u*u+eX)**2)
z=s.symbols('z')
lead=s.Poly(s.expand(F.subs({m:0,W:1,X:0,Y:y*u,Z:z*u},simultaneous=True)),u).coeff_monomial(u*u)
b11=(4*(C+A)+2*d)*Dv+4*D+4*al*v*v
b22=4*D*v*v+4*al;b12=4*v*(D-al)
l1=-4*C*Dv-(4*D+2*d);l2=-(4*D+2*d)*v;cc=4*C*Dv+4*D+2*d
zero('complete real boundary hard form',lead-(b11*y*y+2*b12*y*z+b22*z*z+2*l1*y+2*l2*z+cc))
detB=s.expand(b11*b22-b12*b12)
num=s.expand(detB*cc-(b22*l1*l1-2*b12*l1*l2+b11*l2*l2))
Q10=4*al*A*(d+2*(C+D));Q12=4*C*D*(d+2*(al+A))
quot=s.cancel(num/(8*Dv));assert s.denom(quot)==1
Q0=s.Poly(quot,v).coeff_monomial(v*v)
zero('exact real boundary quartic',quot-Q10-Q0*v*v-Q12*v**4)
assert s.degree(Q0,D)<=1 and s.degree(Q0,A)<=1;checks.append('middle quartic coefficient multi-affine in A,D')
assert s.degree(detB,D)<=1 and s.degree(detB,A)<=1;checks.append('hard determinant multi-affine in A,D')
zero('hard determinant positive AD coefficient',s.diff(detB,A,D)-16*Dv*v*v)
assert all(c>0 for mon,c in s.Poly(detB-16*A*D*Dv*v*v,A,D,C,al,d,v).terms());checks.append('remaining determinant has nonnegative coefficients')
# Exact hard block lower bound in arbitrary A,D scaling, represented first
# without square roots: EY/sqrt(A)=eta, EJ/sqrt(D)=ell.
hard=s.expand((b11*y*y+2*b12*y*z+b22*z*z).subs({y:eta,z:-(eta+ell)/v},simultaneous=True))
zero('two explicit hard packet pivots',hard-4*A*Dv*eta**2-4*D*ell**2-((4*C+2*d)*Dv*eta**2+4*al*(v*eta+(eta+ell)/v)**2))
outer=s.expand(F.subs({m:0,n:0,Y:eta,Z:(u*W+u*v*X-eta-ell)/v},simultaneous=True))
poly=s.Poly(s.expand(v*v*outer),W,X,eta,ell,u,v)
assert all(e[4]>=e[0] for e,c0 in poly.terms());checks.append('entire finite-unit outer form in X,Y,J,uW')
zero('outer A term exactly 4A DuDv Y²',s.diff(outer,A)-4*Du*Dv*eta**2)
zero('outer D term exactly 4D J²',s.diff(outer,D)-4*ell**2)
# The two cap corner soft pivots need no physicality of the cap source.
zero('boundary det at v=0',detB.subs(v,0)-4*al*(4*(C+A+D)+2*d))
zero('boundary det leading v4',s.Poly(detB,v).coeff_monomial(v**4)-4*D*(4*(C+A+al)+2*d))
# The physicality contradiction at A=D=m=0 with n packet killed exactly.
contra=s.expand(F.subs({n:0,m:0,A:0,D:0,W:1,X:0,Y:u,Z:u*v*(2*al+d)/(2*al)},simultaneous=True))
zero('exact negative u2 coefficient excludes all weak A,D,m',s.Poly(contra,u).coeff_monomial(u*u)+d*v*v*(2*al+d)/al)
report={'status':'PASS','count':len(checks),'checks':checks,'seconds':round(time.perf_counter()-start,3),'arithmetic':'exact symbolic polynomial identities','scope':'full original parent graph and first normals; all three large-packet hard terms; multi-affine real Schur quartic; entire outer root form and cap endpoints. Ordered-field source estimates and positivity are proved in the TeX.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
