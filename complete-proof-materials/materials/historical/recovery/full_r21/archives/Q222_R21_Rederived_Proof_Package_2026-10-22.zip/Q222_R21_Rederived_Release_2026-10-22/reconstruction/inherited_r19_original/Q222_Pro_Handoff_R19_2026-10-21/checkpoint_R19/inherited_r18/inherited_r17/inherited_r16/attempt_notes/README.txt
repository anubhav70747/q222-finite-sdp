FOCUSED EXTENSION ATTEMPTS, NOT NEW ADMISSIONS

R7/R8: the R10 method fails first at an unbounded hard block (D opening in R8, m opening in R7). The exact first failed hypotheses are recorded in r7_r8_first_failures.tex.

C14.3b unit-W contact chart: unit_W_critical_attempt.tex shows that the opening-safe critical-A-wall correction is not an infinitesimal allocation of the original m event at contact. The limiting ratio is 3+2*zeta. Six targeted exact checks pass in its separate receipt. These six checks audit a failed extension; they are not included in the 84 enumerated main-proof checks and do not close a source branch.

These failures concern particular proof frames, not counterexamples to the global theorem. The current frontier remains exactly FRONTIER_R16.json.
