"""Independent short exact checks for the small-e outer/state join.

No contact scalar or conductor calculation is imported. This checker
does not certify the remaining u,v,w-infinitesimal contact chart.
"""
from pathlib import Path
import json
import sympy as s

HERE = Path(__file__).resolve().parent
checks = []


def eq(name, left, right):
    remainder = s.cancel(left-right)
    # Factoring is occasionally needed to canonicalize the repeated
    # pure-coefficient radical sqrt(4*c_*+C); no numerical test is used.
    if remainder != 0:
        remainder = s.factor(remainder)
    assert remainder == 0, name
    checks.append(name)


# Native short source, with kappa=k^2. All scale claims use cancellation
# before residue, never a quotient by the native r or an opening.
kappa, eta, zeta, a, t = s.symbols('kappa eta zeta a t')
r = 1-a*eta
K = 1+kappa
H = r+eta
Vc = kappa*eta*zeta
S = 1-kappa*eta+t*Vc
R = 1+kappa*r
T = K-kappa*zeta*t
M, J = R-t, T-a
P4 = (K+eta*kappa*(a-kappa-1)-zeta*kappa*t
      +Vc*(-zeta*kappa*t*t+2*kappa*t+a*(1-t)+t))
Pd = (K*K-a*eta*kappa*kappa+zeta*kappa*(K-(kappa+2)*t)
      +Vc*(-zeta*kappa*t*t+kappa*a*(t-1)+kappa*t+K))
L = K*H*S
N = K*H*(1+Vc)-J*eta*Pd
d0, A0, D0 = 4*eta*Pd, 2*eta*eta*P4, 2*N
dn, An, Dn = a*d0/L, a*A0/(r*L), a*D0/(J*L)
Q = 4*A0*D0-r*J*d0*d0
Nc = (a*d0*(d0*r+2*A0)*(d0*J+2*D0)-4*Q*L)
B0 = 8*D0*L-a*(2*d0*D0+d0*d0*J)
NA = r*d0*d0*(4*J*L+a*(d0*J+2*D0))-2*A0*B0
eq('critical c cleared numerator zero at kappa zero', Nc.subs(kappa, 0), 0)
eq('critical A cleared numerator zero at kappa zero', NA.subs(kappa, 0), 0)
qc = s.Poly(s.expand(Nc), kappa)
qa = s.Poly(s.expand(NA), kappa)
assert qc.nth(0) == 0 and qa.nth(0) == 0
checks.append('both deficit numerators have exact polynomial kappa factors')
eq('critical c unit denominator residue when a unit',
   Q.subs({kappa: 0, zeta: 0}), 16*eta*eta*a*H)
eq('critical A unit denominator residue when a infinitesimal',
   B0.subs({kappa: 0, zeta: 0, a: 0}), 16*(1+eta))

# The two rational critical equations are checked independently with
# abstract source coefficients, then with their short common denominators.
dd, AA, DD, cc = s.symbols('d A D c', positive=True)
critical_c = dd*(dd+2*AA)*(dd+2*DD)/(2*(4*AA*DD-dd*dd))
critical_A = dd*dd*(4+dd+2*DD)/(2*(8*DD-2*dd*DD-dd*dd))
wall = 2*cc*(4*AA*DD-dd*dd)-dd*(dd+2*AA)*(dd+2*DD)
eq('critical c solves exact wall', wall.subs(cc, critical_c), 0)
eq('critical A solves exact wall at c=2',
   wall.subs({cc: 2, AA: critical_A}), 0)

# Verify formulas after replacing each native packet by its exact
# denominator-cleared expression, avoiding a large expanded source ratio.
ds, As, Ds, ls, rs, js, aa = s.symbols('d0 A0 D0 L r J a')
abstract_d = aa*ds/ls
abstract_A = aa*As/(rs*ls)
abstract_D = aa*Ds/(js*ls)
abstract_Q = 4*As*Ds-rs*js*ds*ds
abstract_Nc = aa*ds*(ds*rs+2*As)*(ds*js+2*Ds)-4*abstract_Q*ls
abstract_B = 8*Ds*ls-aa*(2*ds*Ds+ds*ds*js)
abstract_NA = (rs*ds*ds*(4*js*ls+aa*(ds*js+2*Ds))
               -2*As*abstract_B)
eq('exact critical c deficit cancellation',
   critical_c.subs({dd: abstract_d, AA: abstract_A, DD: abstract_D})-2,
   abstract_Nc/(2*abstract_Q*ls))
eq('exact critical A deficit divided by a cancellation',
   (critical_A.subs({dd: abstract_d, DD: abstract_D})-abstract_A)/aa,
   abstract_NA/(2*rs*ls*abstract_B))
eq('native N residue with all openings intact', N.subs(kappa, 0), 1)
eq('native weak m coefficient after t infinitesimal',
   (2*(1-t*zeta)*(1+Vc)/(M*S)).subs({kappa: 0, zeta: 0, t: 0}), 2)
eq('native beta bound coquotient residue',
   (K*(1+(1-t)*zeta)*H/(eta*Pd)).subs({kappa: 0, zeta: 0}), H/eta)

# Whole critical parent on a four-root module.
u, v, B, Y, U, V = s.symbols('u v B Y U V')
Du, Dv = 1+u*u, 1+v*v
C = 4*DD+2*dd
Lc = 4*critical_c+C
y = dd/(2*AA)
b = (4*AA*DD-dd*dd)/(AA*C)
ss = 1-b
q = y+b
eq('critical b=C/(4c+C)', b, C/Lc)
eq('critical C*s=4c*b', C*ss, 4*critical_c*b)
eq('bounded critical c*b', critical_c*b, dd*(2*AA+dd)/(4*AA))


def parent_frame(Yv, Uv, Vv=V):
    jt = Uv-Yv
    return (4*critical_c*Dv*jt*jt+4*AA*Du*Dv*Yv*Yv
            +C*(jt+u*v*B-Du*Vv)**2+2*dd*Dv*B*B
            +2*dd*Du*(v*v*Yv*Yv-2*Yv*Vv-Vv*Vv))


ha, hd, hc = s.symbols('HA HD HC')
g = dd*(2*AA+dd)/AA
gamma = DD*dd*(2*AA+dd)**2/(AA*AA*(2*DD+dd))
Yd = y*V+ha/s.sqrt(AA)
Ud = Yd+(b+u*u)*V-u*v*B+hd/s.sqrt(C)
Fd = s.expand(parent_frame(Yd, Ud))
Fc = s.expand(parent_frame(Yd, Yd+b*V+hc/s.sqrt(Lc)))
eq('D-normal full zero-section scalar', Fd.subs({B: 0, ha: 0, hd: 0}),
   V*V*(g*u*u+gamma*v*v+4*critical_c*u**4
        +g*(y+2)*u*u*v*v+4*critical_c*u**4*v*v))
eq('c-normal full zero-section scalar', Fc.subs({B: 0, ha: 0, hc: 0}),
   V*V*(g*u*u+gamma*v*v+C*u**4+g*y*u*u*v*v))
eq('D-normal complete hard block at zero', Fd.subs({u: 0, v: 0}),
   2*dd*B*B+4*ha*ha+(1+4*critical_c/C)*hd*hd)
eq('c-normal complete hard block at zero', Fc.subs({u: 0, v: 0}),
   2*dd*B*B+4*ha*ha+hc*hc)

for title, poly, hard in [('D', Fd, (B, ha, hd)), ('c', Fc, (B, ha, hc))]:
    for root in hard:
        entry = s.diff(poly, root, V).subs({B: 0, ha: 0, hd: 0, hc: 0})/2
        for angular_derivative in [entry, s.diff(entry, u), s.diff(entry, v)]:
            eq(title+'-normal '+str(root)+' hard-V order check '+str(len(checks)),
               angular_derivative.subs({u: 0, v: 0}), 0)
    assert all(sum(mon) == 2 for mon, coefficient in
               s.Poly(poly, *hard, V).terms())
    checks.append(title+'-normal full state polynomial is quadratic in four roots')

# Exact full-parent finite outer identities.
Fp = parent_frame(Y, U)
F00 = Fp.subs({u: 0, v: 0})
eq('finite u-zero v-unit identity', Fp.subs(u, 0),
   F00+v*v*(2*dd*B*B+(4*AA+2*dd)*Y*Y+4*critical_c*(U-Y)**2))
eq('finite v-zero u-unit identity', Fp.subs(v, 0),
   F00.subs(V, Du*V)+u*u*(4*AA*Y*Y+2*dd*Du*V*V))
eq('v-unit extra null mass equals gamma',
   (4*AA+2*dd)*y*y+4*critical_c*b*b, gamma)

# Direct finite-angle determinant removes any reliance on an inherited
# all-noncommuting source theorem, including after normalization by a.
G = s.Matrix([
    [2*dd*Dv+C*u*u*v*v, 0, C*u*v, -C*u*v*Du],
    [0, 4*AA*Du*Dv+2*dd*Du*v*v, 0, -2*dd*Du],
    [C*u*v, 0, 4*cc*Dv+C, -C*Du],
    [-C*u*v*Du, -2*dd*Du, -C*Du, C*Du*Du-2*dd*Du],
])
det_finite = 64*critical_c*dd*Du*Du*Dv*Dv*(
    AA*(2*DD+dd)*u*u+DD*(2*AA+dd)*v*v)
eq('complete critical finite-angle determinant',
   s.det(G).subs(cc, critical_c), det_finite)
eq('D-normal scaled finite-angle determinant', det_finite/(AA*C),
   32*critical_c*dd*Du*Du*Dv*Dv*(
       u*u+DD*(2*AA+dd)/(AA*(2*DD+dd))*v*v))
eq('D-normal complete finite-angle hard restriction', Fd.subs(V, 0),
   (4*Du*Dv+2*dd*Du*v*v/AA)*ha*ha+hd*hd
   +4*critical_c*Dv*(hd/s.sqrt(C)-u*v*B)**2+2*dd*Dv*B*B)
eq('c-normal complete finite-angle hard restriction', Fc.subs(V, 0),
   (4*Du*Dv+2*dd*Du*v*v/AA)*ha*ha
   +4*critical_c*Dv/Lc*hc*hc
   +C*(hc/s.sqrt(Lc)+u*v*B)**2+2*dd*Dv*B*B)

# Exact pure-testing identity used to absorb the small deficit, W=1.
X, Z = s.symbols('X Z')
Bm = X+u*Z
rm = v-X+u*v*Y-u*Z
eq('pure-testing weak-event V identity', v*Z,
   Z*(rm+Bm)/(1+u*Y))

# The repaired (u,1/v)=(0,0) corner uses U=uW, not an m W² lower bound.
W, cq, Aq, Dq, dq, qq = s.symbols('W c_cap A_cap D_cap d q')
core = 2*((u*W+u*v*X-Y-v*Z)**2+Du*(v*Y-Z)**2
          +Dv*(X+u*Z)**2-Du*Dv*Z*Z)
selected = (4*cq*Dv*(u*W-Y)**2+4*Aq*Du*Dv*Y*Y
            +4*Dq*(u*W+u*v*X-Y-v*Z)**2+dq*core)
hom = s.cancel(qq*qq*selected.subs(v, 1/qq))
hom = s.cancel(hom.subs(W, U/u))
assert not s.denom(hom).has(u, qq)
assert all(sum(mon) == 2 for mon, coefficient in
           s.Poly(hom, X, Y, U, Z).terms())
checks.append('zero-infinity complete bounded four-root allocation without m')
eq('zero-infinity complete four-root residue without m',
   hom.subs({u: 0, qq: 0}),
   2*dq*X*X+4*cq*(U-Y)**2+(4*Aq+2*dq)*Y*Y+4*Dq*Z*Z)
p = s.symbols('p')
hinf = s.cancel(p*p*selected.subs(u, 1/p))
eq('infinity-unit signed-core residue retains missing Z pivot',
   s.cancel(p*p*core.subs(u, 1/p)).subs(p, 0),
   2*((W+v*X)**2+(v*Y-Z)**2))

out = {
    'status': 'PASS', 'check_count': len(checks), 'checks': checks,
    'scope': ('Exact native deficit bounds, complete critical hard frames, '
              'finite and projective outer identities, and pure-testing '
              'weak-event repair. No remaining small-u,v,w contact proof '
              'is imported or claimed.'),
    'cleared_deficit_numerator_term_counts': {
        'c': len(s.Poly(s.expand(Nc), kappa, eta, zeta, a, t).terms()),
        'A': len(s.Poly(s.expand(NA), kappa, eta, zeta, a, t).terms()),
    },
}
(HERE/'outer_small_e_checks.json').write_text(json.dumps(out, indent=2)+'\n')
print(json.dumps(out, indent=2))
