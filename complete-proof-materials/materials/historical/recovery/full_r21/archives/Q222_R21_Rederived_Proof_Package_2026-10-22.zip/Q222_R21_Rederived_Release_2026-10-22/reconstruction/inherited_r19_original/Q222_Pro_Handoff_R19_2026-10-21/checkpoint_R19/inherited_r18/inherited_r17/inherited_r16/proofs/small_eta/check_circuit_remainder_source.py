import sympy as s,json
from pathlib import Path
x,t,a,pi,ss=s.symbols('x eta a pi sigma')
r=1-t*ss;h=1-x*pi;th=x*pi;K=1+x;R=1+x*r;T=1+x*h;M=R-a*th;y=x*t/a;Es=1-x*t*h;Qc=1-x*r/a
Pd=1+2*x*h+r*x*x*(h+1/a)+x/a+t*x*(K/a+x*h*th)
m=K*x*a*(r+t)*h*(1+y)/(2*M*Pd)
al=x*x/a**2*(r+t)*(a*R*h*(1+y)+M*Es)/(2*Qc*Pd)
Bxth=K*(r+t)*x*(h+1/a)/(2*Pd)
q=al+m*th*th+Bxth*th
Dpj=K*(1+y)*(r+t)/(2*Pd)
f=s.cancel(2*(m/(a*x)-a*q/x+t*h*Bxth-h*Dpj-h*m*r))
num,den=s.fraction(f);num=s.Poly(num,x);quo,rem=s.div(num,s.Poly(x,x))
assert rem.is_zero
val=s.factor((quo.as_expr()/den).subs({x:0,t:0}))
expected=-(a+2+1/a+pi)
assert s.cancel(val-expected)==0,(val,expected)
assert s.factor(den.subs({x:0,t:0}))!=0
out={'status':'PASS','source_expression':'eta*(2lambda+kappa*h)/x','residue':str(val),'denominator_at_x_eta_zero':str(s.factor(den.subs({x:0,t:0}))),'scope':'Exact source-only negative remainder of the extra-circuit cancellation; retains all original opening rates via r=1-eta*sigma.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
