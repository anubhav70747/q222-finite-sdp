Q222 revision 13, C1 eta-large track
==================================

Actual new all-tests source admission
------------------------------------
Original physical C1.4, with every original complement/total-scale
restriction retained; x=k^2, z=1/L and sigma=1/eta all positive
infinitesimals; beta>=0; M_beta=beta*(1-h)/sigma^2 bounded.

There are no additional h/sigma or D/sigma^2 unit assumptions.
The BE source identities imply h/sigma~1, D/sigma^2~1/2 on this domain.
All independent projective tests, signs and real/complex states are
included after the exact CE9-CE10, CE20-CE21 remote join.

Read beta_positive_extension.tex as the admission theorem, and
joint_radial_beta_zero.tex as the exact common identity and its
beta-zero residue calculation. The beta-zero face is a corollary.

Additional proved testing reduction
------------------------------------
On original C14.1 with h/sigma bounded and M_beta unbounded, every
bounded nonzero-unit u is now covered at infinitesimal/zero reciprocal
Bob test w=1/v. This statement retains D=0. Together with the same
remote complement, only infinitesimal u remains on that source branch.

Decisive new mechanism
---------------------
Lift the entire scalar radial quotient together with every radial first
state normal. Their exact joint cancellations eliminate all radial
sigma poles in the six-root Gram, including the full BR3 coefficient,
Z_uw contribution and 8(ab)b/sigma through the Q opening.

The combined angular coefficient S has a short generic formula from
monic quotients; no reduction modulo the source beta numerator is needed.
The legal pure-testing pivot lambda(t)=2(t^2+t+1)/(1+t)^2 produces the
strict residue Schur complement (4t+3)/(2(1+t)^4) in the beta-zero
calculation, uniformly over every finite real u residue.

The beta-positive square uses a_beta=beta*theta^2. This is distinct from
M_beta=beta*theta/sigma^2, and is never the squared product (beta*theta)^2.
The exact common beta/m source packet pays for its scalar reserve.

New checks
----------
python3 check_joint_radial.py

Requires SymPy. The present environment used
PYTHONPATH=/tmp/q222_sympy python3 check_joint_radial.py
with SymPy 1.14.0. All 36 new exact assertions passed. The output receipt
is check_joint_radial.json. No earlier baseline suite was replayed.

The full-parent assertion explicitly retains and prints the six contact
remainders; their zero values on the original source are imported from
the verified original contact identities. Other imported proof inputs
are the BE source normalization, the exact CE remote joins, and the
project's bounded-positive-Gram and finite-penalty lemmas.

Remaining work, not admitted
---------------------------
1. C14.1 with bounded h/sigma, unbounded beta*theta/sigma^2,
   infinitesimal u and residual infinitesimal w.
2. C14.1 with h/sigma unbounded.
3. C14.2, L a positive bounded unit and eta unbounded.
4. Every other original residual row and the global exhaustion/lift gate.

JB5 has 1/u and 1/u^2 coefficients, so the unit-u beta-square allocation
cannot be imported on the first remaining branch. The square P_beta
itself has no u inverse, but its full joint angular remainder still
requires a new separated allocation. No comparison of source x and
testing u^2 is allowed.

The new algebra was checked by this subagent; the parent separately
reviewed the displayed positive blocks and domain restrictions within
the same assistant system. This is not external or formal verification.
