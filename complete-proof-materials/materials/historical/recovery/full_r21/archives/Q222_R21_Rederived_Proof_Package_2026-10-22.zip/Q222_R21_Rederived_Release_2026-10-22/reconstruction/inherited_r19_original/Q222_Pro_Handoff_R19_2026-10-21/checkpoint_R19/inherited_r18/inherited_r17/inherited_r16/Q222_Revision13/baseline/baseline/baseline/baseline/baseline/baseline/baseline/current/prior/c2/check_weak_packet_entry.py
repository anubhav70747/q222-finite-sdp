#!/usr/bin/env python3
"""Small exact checks for one-weak-packet C2 source entry and obstruction."""
from pathlib import Path
import json
import sympy as s
if not __debug__:
    raise SystemExit('Run without -O: assertions are proof checks.')
checks=[]
def eq(name,expr):
    assert s.cancel(expr)==0,name
    checks.append(name)
z,q,b,r,t=s.symbols('z q b r t') # q=a^2
h=b-q*t;g=(1+z)*b-(1-r+q*z*t);j=1+z*r-t
Delta=((1+z)*z*b*b+2*z*(1+z)*b*r+(1+z)*(1+q*z)*b
       +z*z*(1-q)*r*r+2*z*(1+q*z)*r+1+q*z)
positive=1+(1+z)*b+z*(1+z)*b*b+2*z*(1+z)*b*r+z*z*r*r+2*z*r
positive+=q*z*((1+z)*b+1+z*r*(2-r))
N=(1+z)*(b+r)*(b+q*(1-t))-q*(1+q*z)*(1-r)*t
eq('positive denominator rewrite',Delta-positive)
eq('positive N identity',N-((1+z)*(b+r)*h+q*(g+j+r*t*(1+q*z))))
eq('b minus one identity',b-1+r-g+z*h)
eq('b plus r lower-bound identity',(1+z)*(b+r)-(1+g+z*r+q*z*t))
x=s.symbols('epsilon',positive=True)
zp=x*x;rp=hp=gp=jp=x;tp=1-x+x**3;bp=1-x**3
qp=(1-x-x**3)/tp
sub={z:zp,q:qp,b:bp,r:rp,t:tp}
dp=s.cancel(Delta.subs(sub));np=s.cancel(N.subs(sub));ac=1+zp*rp
eq('path h',bp-qp*tp-hp)
eq('path g',(1+zp)*bp-(1-rp+qp*zp*tp)-gp)
eq('path j',1+zp*rp-tp-jp)
S=ac+qp*zp*tp
n=s.cancel(((bp+rp)*ac*S-rp*dp)/(2*rp*dp))
m=s.cancel((1+qp*zp)*(1-rp)*ac*S/(2*gp*dp))
C=s.cancel(ac*np/(2*qp*tp*dp))
A=s.cancel(qp*ac*(bp+rp)*S/(2*hp*dp))
D=s.cancel((1+zp)*(bp+rp)*(bp-qp*zp*rp)*S/(2*qp*jp*dp))
alpha=s.cancel(zp*zp*(bp+rp)*np/(2*(1-zp*hp)*dp))
expected={'Delta':(dp,2),'N_over_epsilon':(np/x,4),
          'epsilon_n':(x*n,s.Rational(1,4)),'epsilon_m':(x*m,s.Rational(1,4)),
          'epsilon_A':(x*A,s.Rational(1,4)),'epsilon_D':(x*D,s.Rational(1,4)),
          'C_over_epsilon':(C/x,1),'alpha_over_epsilon5':(alpha/x**5,1),
          'alpha_over_C_epsilon4':(alpha/(C*x**4),1)}
limits={}
for name,(expr,value) in expected.items():
    actual=s.limit(s.cancel(expr),x,0,dir='+')
    assert actual==value,(name,actual,value)
    limits[name]=str(actual)
for name,weight in [('n',n),('m',m),('A',A),('D',D)]:
    actual=s.limit(s.cancel(alpha*weight/x**4),x,0,dir='+')
    assert actual==s.Rational(1,4)
    limits['alpha_'+name+'_over_epsilon4']=str(actual)
# Bind the path to the full original parent and its actual stationary contact.
u,v,W,X,Y,Z,aa=s.symbols('u v W X Y Z a')
nn,mm,cc,AA,DD,al=s.symbols('n m C A D alpha')
Du,Dv=1+u*u,1+v*v
R2=v*W-X+u*v*Y-u*Z;R3=u*W-Y
R5=u*W+u*v*X-Y-v*Z;Ra=v*Y-Z;Rb=X+u*Z
F=4*nn*Du*Dv*X*X+4*mm*R2*R2+4*cc*Dv*R3*R3
F+=4*AA*Du*Dv*Y*Y+4*DD*R5*R5+4*al*Du*Ra*Ra
F+=2*(R5*R5+Du*Ra*Ra+Dv*Rb*Rb-Du*Dv*Z*Z)
point={u:x,v:aa*x,W:bp,X:-aa*x*rp,Y:x*hp,Z:aa}
weights={nn:n,mm:m,cc:C,AA:A,DD:D,al:alpha}
def path_reduce(expr):
    p=s.Poly(s.expand(expr.subs(point,simultaneous=True)),aa)
    odd=[s.Integer(0),s.Integer(0)]
    for (degree,),coef in p.terms():
        odd[degree%2]+=coef*qp**(degree//2)
    return [s.cancel(expr.subs(weights,simultaneous=True)) for expr in odd]
for name,expr in [('value',F)]+[(str(var)+' derivative',s.diff(F,var)) for var in (W,X,Y,Z,u,v)]:
    for parity,remainder in enumerate(path_reduce(expr)):
        eq('full-parent contact '+name+' parity '+str(parity),remainder)
report={'status':'PASS','checks':len(checks),'check_names':checks,
        'counterpath_limits':limits,
        'scope':'Exact source identities, original-parent stationary contact and asymptotic obstruction; all-tests entry uses proved radial certificates.',
        'not_claimed':'No exhaustive C2 source entry; no general implication from weak-packet sum to either summand.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
