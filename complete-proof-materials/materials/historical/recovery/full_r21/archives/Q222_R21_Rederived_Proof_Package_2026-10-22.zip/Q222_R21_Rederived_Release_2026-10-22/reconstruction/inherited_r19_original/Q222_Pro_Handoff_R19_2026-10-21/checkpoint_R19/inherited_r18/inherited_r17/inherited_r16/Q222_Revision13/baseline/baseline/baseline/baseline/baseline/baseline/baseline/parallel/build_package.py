#!/usr/bin/env python3
"""Preserve the completed proof frontier without runtime dependencies or logs."""
from pathlib import Path
import hashlib,json,zipfile
ROOT=Path(__file__).resolve().parent
files={}
for name in ['README.txt','REGULAR_SOURCE_PROOF.tex','FRONTIER_STATUS.json','NEW_EXACT_REPLAY.json','replay.py','build_package.py']:
    files[name]=ROOT/name
files['output/pdf/REGULAR_SOURCE_PROOF.pdf']=ROOT/'output/pdf/REGULAR_SOURCE_PROOF.pdf'
for sub in ['graph','newton','rank_two','root']:
    for p in sorted((ROOT/sub).rglob('*')):
        if p.is_file() and p.suffix in {'.md','.py','.json'}:
            files[p.relative_to(ROOT).as_posix()]=p
files['prior/Q222_Physical_Proof_Development_2026-10-15.zip']=ROOT/'recovered/Q222_Physical_Proof_Development_2026-10-15.zip'
locked=ROOT/'base/source/Q222_Locked_Analytical_Proof.pdf'
assert hashlib.sha256(locked.read_bytes()).hexdigest()=='f20ecc9ac7383c02d389e7e804b4baebfae0bc6355a929c8e80d0ec1d545f69e'
receipt=json.loads((ROOT/'NEW_EXACT_REPLAY.json').read_text())
assert receipt['status']=='PASS' and len(receipt['checks'])==11
manifest={'package':'Q222_Physical_Proof_Advance_2026-10-17','files':[{'path':k,'size_bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}for k,p in sorted(files.items())]}
out=ROOT/'Q222_Physical_Proof_Advance_2026-10-17.zip'
with zipfile.ZipFile(out,'w',zipfile.ZIP_DEFLATED,compresslevel=8)as z:
    for name,p in sorted(files.items()):z.write(p,name)
    z.writestr('MANIFEST.json',json.dumps(manifest,indent=2)+'\n')
with zipfile.ZipFile(out)as z:
    assert z.testzip() is None
    for f in manifest['files']:
        assert hashlib.sha256(z.read(f['path'])).hexdigest()==f['sha256']
print(json.dumps({'status':'PASS','file':str(out),'size_bytes':out.stat().st_size,'members':len(manifest['files'])+1,'exact_checks':11,'prior_locked_pdf_unchanged':True},indent=2))
