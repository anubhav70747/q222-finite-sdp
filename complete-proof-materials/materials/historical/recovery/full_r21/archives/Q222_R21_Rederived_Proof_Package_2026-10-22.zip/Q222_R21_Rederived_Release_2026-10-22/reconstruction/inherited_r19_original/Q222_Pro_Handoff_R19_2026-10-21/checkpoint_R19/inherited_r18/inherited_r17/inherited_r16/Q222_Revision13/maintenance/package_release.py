#!/usr/bin/env python3
"""Build and independently verify the complete revision-13 derivative archive."""
from pathlib import Path
from tempfile import TemporaryDirectory
import argparse, hashlib, json, shutil, subprocess, sys, zipfile

ROOT=Path(__file__).resolve().parents[1]
PREFIX="Q222_Revision13/"

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument("output_directory", type=Path)
    args=parser.parse_args()
    output=args.output_directory.resolve()
    if output==ROOT or ROOT in output.parents:
        raise RuntimeError("The release output must be outside the source tree.")
    output.mkdir(parents=True,exist_ok=True)
    manifest=ROOT/"MANIFEST.sha256"
    entries={name:sha for sha,name in
             (line.split("  ",1) for line in manifest.read_text().splitlines())}
    names=sorted([*entries,"MANIFEST.sha256"])
    archive=output/"Q222_Revision13_Source_Package.zip"
    with zipfile.ZipFile(archive,"w",compression=zipfile.ZIP_DEFLATED,
                         compresslevel=9,allowZip64=True) as bundle:
        for name in names:
            data=(ROOT/name).read_bytes()
            if name in entries and hashlib.sha256(data).hexdigest()!=entries[name]:
                raise RuntimeError("Source changed after hashing: "+name)
            info=zipfile.ZipInfo(PREFIX+name,date_time=(2026,10,19,0,0,0))
            info.compress_type=zipfile.ZIP_DEFLATED
            info.create_system=3
            info.external_attr=0o100644<<16
            bundle.writestr(info,data,compress_type=zipfile.ZIP_DEFLATED,
                            compresslevel=9)
    with zipfile.ZipFile(archive) as bundle:
        if bundle.testzip() is not None:
            raise RuntimeError("ZIP CRC verification failed.")
        if set(bundle.namelist())!={PREFIX+name for name in names}:
            raise RuntimeError("ZIP member set differs from the complete manifest.")
        for name,sha in entries.items():
            if hashlib.sha256(bundle.read(PREFIX+name)).hexdigest()!=sha:
                raise RuntimeError("Archived SHA-256 mismatch: "+name)
        with TemporaryDirectory(prefix="q222-release-extract-") as scratch:
            bundle.extractall(scratch)
            extracted=Path(scratch)/PREFIX
            run=subprocess.run([sys.executable,"verify.py","--integrity-only"],
                               cwd=extracted,stdout=subprocess.PIPE,
                               stderr=subprocess.STDOUT,text=True)
            if run.returncode:
                raise RuntimeError("Extracted release verifier failed:\n"+run.stdout)
            integrity=json.loads(run.stdout)
    for source,target in [
        ("Q222_Revision13_Results.pdf","Q222_Revision13_Results.pdf"),
        ("Q222_Analytical_Revision_2026-10-18.pdf","Q222_Revision13_Full_Manuscript.pdf"),
        ("CHECKLIST.md","Q222_Revision13_Checklist.md")]:
        shutil.copy2(ROOT/source,output/target)
    print(json.dumps({"status":"PASS","archive":str(archive),
        "archive_bytes":archive.stat().st_size,
        "archive_sha256":hashlib.sha256(archive.read_bytes()).hexdigest(),
        "zip_members":len(names),"every_member_crc":"PASS",
        "every_manifest_sha256":"PASS","extracted_release_integrity":integrity,
        "deliverables":[str(output/name) for name in [
            "Q222_Revision13_Results.pdf","Q222_Revision13_Full_Manuscript.pdf",
            "Q222_Revision13_Checklist.md","Q222_Revision13_Source_Package.zip"]]},indent=2))

if __name__=="__main__":
    main()
