"""Independent small algebra checks for the scoped C1 audit; no atlas input."""
import json
from pathlib import Path
import sympy as S
eta,a,u,A,B,C,D0=S.symbols('eta a u A B C D0')
r=1-a*eta; H=r+eta; Du=1+u*u
checks=[]
def zero(name,x):
    assert S.cancel(x)==0,name
    checks.append(name)
source=8*r*H*Du*Du*A*A+8*r*H*Du*Du*B*B+8*Du*(C-a*eta*B)**2+8*r*H*Du*D0*D0+8*r*Du*(eta*B*B*(-1+2*a)-2*B*C)
target=8*r*H*Du*Du*A*A+8*Du*((B-C)**2+u*u*r*H*B*B)+8*r*H*Du*D0*D0
zero('ordinary-u scalar residue from five source packets',source-target)
zero('ordinary-u hard-soft determinant',(16*r*H+8*eta*eta/Du)*8*Du-(8*eta)**2-128*Du*r*H)
zero('small-u hard-soft determinant',(16*r*H+8*eta*eta)*8-(8*eta)**2-128*r*H)
zero('harmonic denominator residue',(1-a)*H+a-(1+eta*(1-a)**2))
a1,a2,a3,a4=S.symbols('a1 a2 a3 a4')
y=a1*a1-a3*a3; z=a2*a2-a3*a3; h=a3*a3-a4*a4
q1=a1*a2-a3*a4; q2=a1*a3-a2*a4
zero('two-pairing strict circuit',sum(x**4 for x in (a1,a2,a3,a4))-4*a1*a2*a3*a4-(y*y+z*z+h*h-y*z+z*h+q1*q1+q2*q2))
G=S.Matrix([[1,-S.Rational(1,2),0],[-S.Rational(1,2),1,S.Rational(1,2)],[0,S.Rational(1,2),1]])
assert [G[:i,:i].det() for i in (1,2,3)]==[1,S.Rational(3,4),S.Rational(1,2)]
checks.append('circuit positive principal minors')
report={'status':'passed','checks':checks,'count':len(checks)}
Path(__file__).with_name('audit_small_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
