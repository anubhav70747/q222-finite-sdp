"""Focused exact checks for the simultaneous r,j harmonic event frame."""
import json
from pathlib import Path
import sympy as s

checks, reports = {}, {}
def zero(name, expr):
    val = s.factor(s.together(expr))
    if val != 0:
        raise AssertionError((name, val))
    checks[name] = True
    print("PASS", name, flush=True)

U,V,u,v,t,W,X,Y,Z,ell,n,xi = s.symbols("U V u v t W X Y Z ell n xi")
C,A,D,m,al,be,h,r,j,rho = s.symbols("C A D m alpha beta h r j rho")
x,zeta,pi,eta = s.symbols("x zeta pi eta")
e = 1-r+j
th = 1-h
Bx = be+s.Rational(1,2)
Du,Dv = 1+U,1+V
w = (1+h*U)/e
y = x*eta*zeta
aa = C*(1-r)**2
bb = A*r*r
dd = (D+s.Rational(1,2))*j*j
cc = (al+s.Rational(1,2))*r*r

scalar = m*(w*w*V*V*(1+r*U)**2/U-2*w*th*V*(1+r*U)+th*th*U)
scalar += aa*Dv*w*w*V+bb*Du*Dv*w*w*V+dd*w*w*V
scalar += cc*Du*w*w*V*V-(2*al+1)*Du*r*w*V+al*Du+Bx*th*th*U*Dv-Du*V/2
cF = (2*m*(h+r)+aa+bb+cc)/e**2
qV = (aa+bb+dd)/e**2-2*m*th/e-(2*al+1)*r/e-s.Rational(1,2)
qU = al+(m+Bx)*th*th
LA = (1+2*h)+(2*h+h*h)*U+h*h*U*U
fA = m*V*((h+r)**2+2*h*r+2*h*r*(h+r)*U+h*h*r*r*U*U)/e**2
fA += -2*m*th*((h+r)+h*r*U)/e+aa*(2*h+h*h*U)*Dv/e**2
fA += bb*LA*Dv/e**2+dd*(2*h+h*h*U)/e**2+cc*LA*V/e**2
fA += -(2*al+1)*r*(1+h+h*U)/e+Bx*th*th-s.Rational(1,2)
fB = m*eta*zeta/(e*e*x)
fC = (al-cF*y*y+qU*U)/(eta*zeta*x*x)
fG = -(qV+2*cF*y)/x
zero("simultaneous_printed_scalar_polynomial",scalar-m*V*V/(e*e*U)-cF*V*V-qV*V-al-qU*U-fA*U*V)
zero("simultaneous_exact_scalar_circuit",scalar-cF*(V-y)**2-fA*U*V-fB*x*V*V/(eta*zeta*U)-fC*eta*zeta*x*x+fG*x*V)

# Complete first normals before the pure-source divisions by sqrt(H), sqrt(K), sqrt(Bx).
an = r/e+rho
bn = (1-r)/e-rho
cn = 1-rho-j/e
PN = 2*(m*(w*V*(1+r*U)-th*U)-C*Dv*(1-r)*w+A*Du*Dv*r*w
         +(D+s.Rational(1,2))*j*w+(al+s.Rational(1,2))*Du*(r*w*V-1))
PE = 2*(m*V*((h+r)+h*r*U)/e**2-m*th/e
         +m*an*(w*V*(1+r*U)-th*U)+C*Dv*(1-r)*w*bn
         +A*Du*Dv*r*w*an-(D+s.Rational(1,2))*j*w*cn
         +(al+s.Rational(1,2))*Du*(r*w*V-1)*an)
ZX = m*th*(1+r*U)/e+Bx*th
ZX -= (C*Dv*(1-r)**2*w+A*Du*Dv*r*r*w+(D+s.Rational(1,2))*j*j*w
       +(al+s.Rational(1,2))*Du*r*(r*w*V-1))/e
LX = 2*u*th*(m+Bx)-2*m*w*u*t*t*(1+r*U)*(1+V*(1+r*U)/e)+2*u*V*ZX

du,dv = 1+u*u,1+v*v
jt = u*W+u*v*X-Y-v*Z
mt = v*W-X+u*v*Y-u*Z
F4 = m*mt*mt+C*dv*(u*W-Y)**2+A*du*dv*Y*Y
F4 += (D+s.Rational(1,2))*jt*jt+(al+s.Rational(1,2))*du*(v*Y-Z)**2
F4 += Bx*dv*(X+u*Z)**2-du*dv*Z*Z/2
pp = ((1+h*u*u)*v-u*v*xi+ell)/e
change = {Z:1,W:pp/u,X:-h*u+xi,Y:r*pp+rho*ell+n}
zero("simultaneous_complete_D_event_map",jt.subs(change)+j*pp-(1-rho)*ell+n)
zero("simultaneous_complete_E_event_map",(u*W+u*v*X-v*Z-(r-j)*u*W).subs(change)-ell)
full = s.expand(F4.subs(change).subs(v,u*t))
zero_state = {ell:0,n:0,xi:0}
uv = {U:u*u,V:u*u*t*t}
zero("simultaneous_full_scalar_graph",full.subs(zero_state)-scalar.subs(uv))
zero("simultaneous_complete_N_normal",s.diff(full,n).subs(zero_state)-u*t*PN.subs(uv))
zero("simultaneous_complete_E_normal",s.diff(full,ell).subs(zero_state)-u*t*(2*m*t*t/e**2+PE.subs(uv)))
zero("simultaneous_complete_X_normal",s.diff(full,xi).subs(zero_state)-LX.subs(uv))

# Harmonic weighted identities; no rate between r and j is selected.
p,q,YY = s.symbols("p q YY")
H = A+D
Kh = A*D/H
rh = D/H
YYh = r*p+rh*ell+n
JH = -j*p+(1-rh)*ell-n
zero("simultaneous_whole_AD_completion",
     A*YYh**2+D*JH**2-H*n*n-Kh*ell*ell
     -2*p*((A*r+D*j)*n+Kh*(r-j)*ell)-(A*r*r+D*j*j)*p*p)
zero("simultaneous_A_E_normal_weight",A*rh*rh/Kh-rh)
zero("simultaneous_A_N_normal_weight",A/H-(1-rh))
Ct = (1+j)/(2*(1-r))
At = e/(2*r)
Dt = 1/(2*j)
base = Ct*(p-YY)**2+At*YY*YY+Dt*(p-YY-q)**2+(p-YY)**2/2-p*q
base_new = s.factor(base.subs({q:e*p-ell,YY:r*p+rho*ell+n}))
zero("simultaneous_reference_has_no_soft_p",s.diff(base_new,p))
zero("simultaneous_reference_hard_only",base_new-(At+Ct+s.Rational(1,2))*(rho*ell+n)**2-Dt*((1-rho)*ell-n)**2)

# A whole homogeneous higher-angle identity on the seven reciprocal roots.
qt = p+u*v*X-YY # Jt+q, only a temporary symbolic expression
dtest = -h*u*u*q+u*v*xi
JJ = p-YY-q+dtest
actual = C*dv*(p-YY)**2+A*du*dv*YY*YY+D*JJ*JJ
actual += (JJ*JJ+du*(v*v*YY*YY-2*q*YY-q*q))/2
quadratic = C*(p-YY)**2+A*YY*YY+D*JJ*JJ+(p-YY)**2/2-p*(q-dtest)
high = C*v*v*(p-YY)**2+A*(u*u+v*v+u*u*v*v)*YY*YY
high += du*v*v*YY*YY/2-th*u*u*q*YY+(h-s.Rational(1,2))*u*u*q*q
high += h*h*u**4*q*q/2-u*v*xi*(YY+(1+h*u*u)*q)+u*u*v*v*xi*xi/2
zero("simultaneous_whole_reciprocal_remainder",actual-quadratic-high)
highlead = s.expand(high.subs({YY:0,xi:0,h:1,C:s.Rational(1,2)}))
zero("simultaneous_reciprocal_R_pivot",highlead.coeff(u,2).coeff(v,0)/q**2-s.Rational(1,2))
zero("simultaneous_reciprocal_S_pivot",highlead.coeff(u,0).coeff(v,2)/p**2-s.Rational(1,2))
lead = {r:0,j:0,h:1,m:0,al:0,C:s.Rational(1,2)}
zero("simultaneous_cF_strict_residue",cF.subs(lead)-s.Rational(1,2))
zero("simultaneous_fA_strict_residue",fA.subs({U:0,V:0}).subs(lead)-s.Rational(1,2))

# Exact native source bounds: eta=(1-r+j)/(1+xh), theta=x*pi.
hs = 1-x*pi
ths = x*pi
T = 1+x*hs
etas = e/T
ys = x*etas*zeta
K0 = 1+x
R = 1+x*r
M = R-ths/zeta
Es = 1-x*etas*hs
Q = 1-x*zeta*r
P4 = T*Es+x*(1-r)*(hs+zeta)
Pa = R*hs*(1+ys)+zeta*M*Es
Pd = 1+2*x*hs+r*x*x*(hs+zeta)+x*zeta+etas*x*(K0*zeta+x*hs*ths)
B5 = K0*(1+ys)*(r+etas)-j*Pd
Bbeta = K0*x*(r+etas)*(hs+zeta)-ths*Pd
Cs = K0*(r+etas)*Es/(2*(1-r)*Pd)
Ars = etas*P4/(2*Pd)
Djs = B5/(2*Pd)
ms = K0*x*(r+etas)*hs*(1+ys)/(2*M*zeta*Pd)
als = x*x*zeta*(r+etas)*Pa/(2*Q*Pd)
bes = Bbeta/(2*ths*Pd)
src = {h:hs,eta:etas,C:Cs,A:Ars/r,D:Djs/j,m:ms,al:als,be:bes}
arrays = {
    "C_reference_error_over_x":(Cs-Ct)/x,
    "Ar_reference_error_over_x":(Ars-e/2)/x,
    "Dj_reference_error_over_x":(Djs-s.Rational(1,2))/x,
    "m_over_x":ms/x,
    "alpha_over_x2":als/x**2,
    "Bx_theta_over_x":(bes+s.Rational(1,2))*ths/x,
    "qU_over_x2":(als+(ms+bes+s.Rational(1,2))*ths**2)/x**2,
}
for name,expr in arrays.items():
    val = s.factor(s.together(expr))
    den0 = s.factor(s.denom(val).subs({x:0,r:0,j:0}))
    if den0 == 0 or den0.has(pi):
        raise AssertionError(("uncleared_small_source",name,den0))
    for fac,_ in s.factor_list(den0)[1]:
        if s.Poly(fac,zeta).monic().as_expr() != zeta:
            raise AssertionError(("unapproved_factor",name,fac))
    reports[name] = str(den0)
    checks["unit_source_denominator_"+name] = True
    print("PASS unit_source_denominator_"+name,flush=True)
zero("simultaneous_scalar_graph_source_match",(w.subs({U:x,h:hs}))*etas-1)
zero("simultaneous_fB_source_residue",s.factor(s.together(fB.subs(src))).subs({x:0,r:0,j:0})-s.Rational(1,2))
zero("simultaneous_fC_source_residue",s.factor(s.together(fC.subs(U,0).subs(src))).subs({x:0,r:0,j:0})-s.Rational(1,2))

out = {
    "status":"PASS","count":len(checks),"checks":checks,
    "source_denominators_at_x_r_j_zero":reports,
    "scope":"Simultaneous positive infinitesimal r,j with eta,zeta units: complete event map, scalar circuit, all three full-parent first normals, harmonic hard cancellation, strict reciprocal pivots, and only retained-unit source denominators."
}
Path(__file__).with_suffix(".json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"status":"PASS","checks":len(checks)}),flush=True)
