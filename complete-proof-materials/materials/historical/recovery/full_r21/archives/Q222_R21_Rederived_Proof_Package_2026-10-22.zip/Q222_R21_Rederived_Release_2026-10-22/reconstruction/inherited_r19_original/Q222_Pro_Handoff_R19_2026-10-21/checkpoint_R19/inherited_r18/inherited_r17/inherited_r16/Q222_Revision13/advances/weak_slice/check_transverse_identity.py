#!/usr/bin/env python3
"""Exact transverse correction with all original excess jets retained."""
import json
from pathlib import Path
import sympy as s
t,b,v=s.symbols('t b v')  # v is normalized state ratio s in the note
w01,w10,w11,w20,w21,z00,z01,z20,z21=s.symbols('w01 w10 w11 w20 w21 z00 z01 z20 z21')
# Eliminate only the exact v/state contact derivatives.
z10=w01+w11+w21-z00-z20
z11=w10+w20-z01-z21
a=w10*t**2+w20*t**4
bb=w01+w11*t**2+w21*t**4
c=z00+z10*t**2+z20*t**4
d=z01+z11*t**2+z21*t**4
P0=w01+z00+z01;P2=w10+w11+z10+z11;P4=w20+w21+z20+z21
N1=(P2+3*P4-P0)/2;N0=P0+P2+P4-N1
q=P4-N1/2;Q=P4*t**2+2*q*t+P0
ee=(N0*t+N1*t**3)/2
P=a*v**2+bb*b*b*v*v+c+d*b*b-2*ee*b*v
R=v-b;S=b*v-1;delta=d-a;kappa=c-bb
results={}
def check(name,x):
    ok=s.expand(x)==0;results[name]=ok;assert ok,name
check('exact_transverse_identity',P-(a*R**2+bb*S**2-delta*b*R-kappa*S+(t-1)**2*Q*(1+S)))
dbar=(z21-w20)*t*t-z01
kbar=(z20-w21)*t*t-(z00-w01)
check('delta_division',delta-(t*t-1)*dbar)
check('kappa_division',kappa-(t*t-1)*kbar)
x,rb,sb,l=s.symbols('x rb sb l')
# Tangent change: t=1+x, b=1+(S-R)/2, state=1+(S+R)/2.
local=P.subs({t:1+l*x,b:1+l*(sb-rb)/2,v:1+l*(sb+rb)/2})
quad=s.expand(local).coeff(l,2)
a0=a.subs(t,1);b0=bb.subs(t,1);q0=Q.subs(t,1)
d0=dbar.subs(t,1);k0=kbar.subs(t,1)
check('original_contact_hessian',quad-(q0*x*x+a0*rb*rb+b0*sb*sb-2*d0*x*rb-2*k0*x*sb))
# This is a polynomial identity only. Its source coefficients need not have a
# physical sign in this free symbolic check.
mat=s.Matrix([[q0,-d0,-k0],[-d0,a0,0],[-k0,0,b0]])
check('source_hessian_determinant',mat.det()-(a0*b0*q0-b0*d0*d0-a0*k0*k0))
check('source_hessian_schur',a0*b0*quad-b0*(a0*rb-d0*x)**2-a0*(b0*sb-k0*x)**2-(a0*b0*q0-b0*d0*d0-a0*k0*k0)*x*x)
check('original_radial_hessian_mass',q0+a0+b0+2*d0-2*k0-4*(w21+z21+z00))
# Explicit original-jet check on each centered excess root is recorded in WS15;
# this checker deliberately never removes its quadratic jet.
out={'count':len(results),'checks':results,'scope':'Exact original transverse and contact-Hessian identities. PSD requires original physicality; no capped-Hessian transfer and no independent-angle/full-normal weighted lift is certified.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
