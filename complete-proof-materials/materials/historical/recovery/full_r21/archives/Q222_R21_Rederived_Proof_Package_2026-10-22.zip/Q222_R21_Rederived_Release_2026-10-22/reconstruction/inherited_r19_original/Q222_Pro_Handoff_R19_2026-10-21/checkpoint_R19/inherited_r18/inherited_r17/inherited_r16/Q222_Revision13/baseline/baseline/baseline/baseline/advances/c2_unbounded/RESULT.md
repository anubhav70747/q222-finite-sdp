# Unbounded b with xb infinitesimal: full-parent proof

`unbounded_b_small_B.tex`, together with `homogeneous_scalar_lemma.tex`, proves the all-tests tensor-SOS conclusion for the remaining rational C2 source regime `b→∞`, `B=xb→0`, with bounded positive unit `k`, positive-chart inequalities, `n≥0`, and the inherited physicality hypothesis. Both complementary openings may be arbitrarily small. Literal `n=0`, unbounded `n`, and arbitrary actual contact ratio `W/Z=√(B/σ)/k` are included, where `σ=1/b`.

The central new construction is homogeneous in the entire state. The roots

`R=(uW−BZ/k)/√B`, `S=uZ−σkW`, `U=√B(v−k)Z`, `T=u(v−k)Z`

satisfy bounded conductors for `(u²−x)W` and `(u²−x)Z`. Exact state and angular stationarity give monic divisions that construct a bounded scalar Gram without normalizing `W/Z`. Its main `(R,U)` block has Schur margin `8/(1+K²)²`, while the radial `S²` coefficient is `2(1−r0)>0`.

The smaller radial scale is retained explicitly. The exact zero is

`T²−σU²−ST(v−k)−σkRU(v−k)=0`.

Adding a suitable positive real multiple gives the necessary `T²` reserve at zero residue cost to `U²`. This absorbs the full `X` normal's possible nonzero `X–T` coupling. The full `Y` normal has zero-residue bounded lifts, and the hard normal block is strict. This proves a full six-root certificate at matched angles, for every homogeneous state simultaneously.

Remote finite-axis tests use the exact determinant identity and the full `X` Schur expression `2−4/[N(1+v²)]`, with `N=4n+2≥2`. The remaining double-zero test uses the explicit epsilon reserve and retains literal `n=0`; its weak `m` packet is correctly normalized with `V=σvW`. The original outer identities remain strict because their `4m+2` pivots tend to `2`. All noncommuting-residue tests use the inherited physical-source theorem.

Independent whole-proof audit `AUDIT_FULL_PARENT.md` records **PASS** for this full-parent, all-tests scope. Exact new checks are in `check_full_parent.py` (33 checks), `check_homogeneous_scalar_lemma.py` (9 checks), and `check_audit_corner.py` (9 checks), with their JSON outputs. The source reparameterization was separately checked against the original formulas in `../oct18b_root/check_unbounded_b.py` (17 checks). These compact algebra checks support the analytical proofs; they are not numerical evidence or a substitute for full-normal restoration and chart exhaustion.
