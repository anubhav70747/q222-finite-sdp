"""Small exact checks for arbitrary_state_ratio.tex; standard library only.

The separate check_analytical_lift.py reconstructs the complete native
source and verifies the unchanged conductor construction at the new grading.
This file checks the new reflection/dispatch identities, not a GB certificate.
"""
if not __debug__:
    raise SystemExit('Run without -O: assertions are proof checks.')
from pathlib import Path
from fractions import Fraction
import json
import time
from source_from_formulas import Poly, variables, native_coquotients

start=time.perf_counter()
checks=[]
def eq(name,p,q):
    assert not (p-q).terms,name
    checks.append(name)

def parent(U,V,state,c):
    u0,u1=U;v0,v1=V;W,X,Y,Z=state
    la,n,m,cc,A,De,al,be,d=c
    Du=u0*u0+u1*u1;Dv=v0*v0+v1*v1
    out=4*la*Du*(v0*W+v1*X)**2+4*n*Du*Dv*X*X
    out+=4*m*(v1*u0*W-v0*u0*X+v1*u1*Y-v0*u1*Z)**2
    out+=4*cc*Dv*(u1*W-u0*Y)**2+4*A*Du*Dv*Y*Y
    out+=(4*De+2*d)*(u1*v0*W+u1*v1*X-u0*v0*Y-u0*v1*Z)**2
    out+=(4*al+2*d)*Du*(v1*Y-v0*Z)**2
    out+=(4*be+2*d)*Dv*(u0*X+u1*Z)**2-2*d*Du*Dv*Z*Z
    return out

u0,u1,v0,v1,W,X,Y,Z,la,n,m,cc,A,De,al,be,d=variables(17)
psi=[v1*W-v0*X,-v0*W-v1*X,v0*Z-v1*Y,v0*Y+v1*Z]
original=[la,n,m,cc,A,De,al,be,d]
reflected=[n,la,cc,m,al,be,A,De,d]
eq('full nine-channel homogeneous reflection including signed core',
   parent([u1,u0],[v0,v1],psi,reflected),
   (v0*v0+v1*v1)*parent([u0,u1],[v0,v1],[W,X,Y,Z],original))

k,s,eta,a,t=variables(5)
zeta=s*s*eta;K=1+k*k
R=K-a*k*k*eta;T=K-k*k*t*zeta;M=R-t;J=T-a
Hf=1+(1-a)*eta;Hg=1+(1-t)*zeta;V=1+k*k*eta*zeta
E=1-k*k*eta*(1-t*zeta);Qc=1-k*k*zeta*(1-a*eta)
vc=k*s*eta;Wc=s;Xc=-k*(1-t*zeta);Yc=k*s*(1-a*eta)
eq('reflected contact W',vc*Wc-Xc,k*Hg)
eq('reflected contact X',-Wc-vc*Xc,-s*E)
eq('reflected contact Y',1-vc*Yc,Qc)
eq('reflected contact Z',Yc+vc,k*s*Hf)
eq('reflected state r gap',Hg-Qc,zeta*M)
eq('reflected state theta gap',Hf-E,eta*J)
eq('reflected shape M prime numerator',k*k*Hg+Qc-J,a*V)
eq('reflected shape J prime numerator',k*k*Hf+E-M,t*V)
eq('native f prime contact relation',k*k*zeta*Hf,vc*k*s*Hf)
# This relation is denominator-cleared and avoids a symbolic inverse.
eq('native g prime contact relation cleared',k*k*eta*Hg*s,k*vc*Hg)
eq('reflected zeta equals s prime squared eta prime, cleared',
   k*k*eta*Hg*s*s,k*k*zeta*Hg)

# Current mass identities, keeping all opening ratios exact.
a,J,T,D1=variables(4)
eq('current mass bounded denominator',2*J+a*D1,
   2*(J+a)+a*(D1-2))
# The residue 2J+aD1=2K uses J=K-a and D1=2 even if either a or J is small.
k,a=variables(2);K=1+k*k
eq('current mass residue denominator',2*(K-a)+2*a,2*K)
eq('critical mass positive-unit residue, cleared',
   (2)*(2)*(4*K**3),(4*K)**2*K)

# Six native coquotient residues at f=g=0, with k unrestricted.
native=native_coquotients()
k,f,g,a,t=variables(5);K=1+k*k
for name,p in native.items():
    restricted=Poly({m:c for m,c in p.terms.items() if not m[1] and not m[2]},5)
    eq('native ordinary-k residue '+name,restricted,4*K*K if name=='Cd' else 2*K)

# The exact circuit is valid without small k,u. g4 is retained as a square.
delta,k,b,u,w,v=variables(6)
AA=w*v;BB=delta*v;CC=delta*b*b*u*w;DD=delta*delta*k**3*b*b
x=BB-CC;y=AA-k*CC;z=u*BB-k*CC;h=k*CC-DD
g4=u*w*v-delta*delta*k**4*b*b
eq('g4 bounded-root identity for arbitrary bounded k,u',g4,u*y+k*z-k*u*x+k*h)
P=(1+u*u)*(AA*AA+BB*BB)+(1+k*k)*(CC*CC+DD*DD)-2*(1+k*k)**2*BB*CC
circuit=AA*AA+(u*BB)**2+(k*CC)**2+DD*DD-4*k*k*BB*CC
eq('leading scalar circuit identity for arbitrary k,u',P,x*x+g4*g4+circuit)

a1,a2,a3,a4=variables(4)
y=a1*a1-a3*a3;z=a2*a2-a3*a3;h=a3*a3-a4*a4
q1=a1*a2-a3*a4;q2=a1*a3-a2*a4
eq('strict six-root two-pairing circuit',
   a1**4+a2**4+a3**4+a4**4-4*a1*a2*a3*a4,
   y*y+z*z+h*h-y*z+z*h+q1*q1+q2*q2)
assert [Fraction(1),Fraction(3,4),Fraction(1,2)]==[
    Fraction(1),Fraction(1)-Fraction(1,4),
    Fraction(1)-Fraction(1,4)-Fraction(1,4)]
checks.append('strict contrast Gram rational principal minors')

report={'status':'PASS','checks':len(checks),'check_names':checks,
        'seconds':time.perf_counter()-start,
        'scope':'New native-reflection and outer-dispatch identities; conductor source lift checked separately.'}
(Path(__file__).parent/'dispatch_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
