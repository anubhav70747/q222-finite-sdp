#!/usr/bin/env python3
"""Exact five-root full-parent identity; positivity bounds are in the text.

Checks are conditional only on the six original contact equations, whose
linear scalar and normal consequences are imposed explicitly below.
"""
import sympy as s
import json
from pathlib import Path
out={}
def ck(name,expr):
    assert s.cancel(expr)==0,(name,s.factor(expr))
    out[name]=True

u,v,W,Z=s.symbols('u v W Z'); U=u*u; V=v*v
k,l,B=s.symbols('k l B',nonzero=True)
R1=u*W-k*v*Z; R2=v*W-l*u*Z; T=u*v*W-B*Z
a,a4,m,b2,b4,c,c2,c4,d,d2,d4,e0,e1=s.symbols('a a4 m b2 b4 c c2 c4 d d2 d4 e0 e1')
aw=a*U+a4*U**2+(m+b2*U+b4*U**2)*V
az=c+c2*U+c4*U**2+(d+d2*U+d4*U**2)*V
scalar=aw*W*W+az*Z*Z-2*u*v*(e0+e1*U)*W*Z
wm=[m*B*l,a*B*k,b2*B**2,a4*B**2*k/l,b4*B**3/l]
zm=[c,d*B/k,c2*B/l,d2*B**2/(k*l),c4*B**2/l**2,d4*B**3/(k*l**2)]
N0=2*B*e0; N1=2*B**2*e1/l
contact=[sum(wm)+sum(zm)-N0-N1,
         2*(wm[1]+wm[2])+4*(wm[3]+wm[4])+2*(zm[2]+zm[3])+4*(zm[4]+zm[5])-N0-3*N1,
         2*(wm[0]+wm[2]+wm[4]+zm[1]+zm[3]+zm[5])-N0-N1,
         2*sum(wm)-N0-N1]
contact_sub=s.solve(contact,[c,d,e0,e1],dict=True)[0]
for i,eq in enumerate(contact): ck('scalar_contact_'+str(i+1),eq.subs(contact_sub))
beta=(B*d4+c4*k)/(k*l*l)
gamma=b4+d4/(k*l)
j0=(B*d4-a4*k*k*l+d2*l)/(2*k*l*l)
j1=d4/(2*k*l)
f0=(b2-c4/l**2-c/B**2-B*d4/(k*l*l))/2
Js=j0+j1*U
gs=(a+a4*U)*R1**2+(m+beta*U)*R2**2+(c/B**2+gamma*U)*T**2+2*u*v*Js*R1*R2-2*v*Js*R1*T+2*u*(f0-j1*U)*R2*T
ck('entire_scalar_three_root_Gram',(scalar-gs).subs(contact_sub))

# Every first normal, with its ONE original contact equation imposed.
fw0,fw1,fz0,fz1,fzV,fzUV=s.symbols('fw0 fw1 fz0 fz1 fzV fzUV')
fw=fw0+fw1*U; fz=fz0+fz1*U+fzV*V+fzUV*U*V
px0=-fzV/k; px1=-fzUV/k; qx1=(-fz1+B*px1)/l
fx0=fw1-px0-qx1
lx=v*W*fw+u*Z*fz
lxlift=u*v*(px0+px1*U)*R1+(fw0+qx1*U)*R2+u*(fx0-px1*U)*T
xcontact=s.solve(l*fw.subs(U,B/l)+fz.subs({u:s.sqrt(B/l),v:s.sqrt(B/k)}),fz0)[0]
ck('complete_x_normal',(lx-lxlift).subs(fz0,xcontact))
kw0,kwU,kwV,kwUV,kz0,kzU=s.symbols('kw0 kwU kwV kwUV kz0 kzU')
kw=kw0+kwU*U+kwV*V+kwUV*U*V; kz=kz0+kzU*U
qy0=(-kzU-k*kwU-B*kwUV)/l; fy0=kwV-qy0
ly=u*W*kw+v*Z*kz
lylift=(kw0+kwU*U)*R1+u*v*qy0*R2+v*(fy0+kwUV*U)*T
ycontact=s.solve(k*kw.subs({u:s.sqrt(B/l),v:s.sqrt(B/k)})+kz.subs(U,B/l),kz0)[0]
ck('complete_y_normal',(ly-lylift).subs(kz0,ycontact))

# Unconditional extraction of the original full parent into the printed
# graph and BOTH complete first normals plus the complete hard block.
n,C,A,D,al,r,h=s.symbols('n C A D al r h')
xi,eta,X,Y=s.symbols('xi eta X Y')
Du=1+U; Dv=1+V
RM=v*W-X+u*v*Y-u*Z; RD=u*W+u*v*X-Y-v*Z
F4=n*Du*Dv*X**2+m*RM**2+C*Dv*(u*W-Y)**2+A*Du*Dv*Y**2+D*RD**2+al*Du*(v*Y-Z)**2+s.Rational(1,2)*(RD**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)
half=s.Rational(1,2)
coeff={a:(C+D+half)*(1-h)**2+A*h*h,a4:A*h*h,
 b2:2*m*h+C*(1-h)**2+(A+al+half)*h*h,
 b4:h*h*(m+A+al+half),c:al,c2:n*r*r+(m+half)*(1-r)**2+al,
 c4:n*r*r,d:D,d2:(n+half)*r*r+2*D*r,d4:(n+D+half)*r*r,
 e0:m*(1-r)+D*(1-h)+al*h+half,
 e1:m*h*(1-r)+r*(D+half)*(1-h)+(al+half)*h}
xcoeff={fw0:-m,fw1:-m*h+(D+half)*(1-h),
 fz0:-n*r+m*(1-r)+half*(1-r),fz1:-n*r,
 fzV:-D-r*(n+half),fzUV:-r*(n+D+half)}
ycoeff={kw0:-(C+D+half)*(1-h)+A*h,kwU:A*h,
 kwV:-C*(1-h)+A*h+m+(al+half)*h,kwUV:h*(A+m+al+half),
 kz0:D-al,kzU:-m*(1-r)+r*(D+half)-al-half}
hxx=n*Du*Dv+m+(D+half)*U*V+half*Dv
hyy=A*Du*Dv+C*Dv+D+half+m*U*V+(al+half)*Du*V
hxy=-u*v*(m+D+half)
reconstruction=scalar.subs(coeff)+2*xi*lx.subs(xcoeff)+2*eta*ly.subs(ycoeff)+hxx*xi**2+2*hxy*xi*eta+hyy*eta**2
ck('original_full_four_state_parent',s.expand(F4.subs({X:xi-r*u*Z,Y:eta+h*u*W})-reconstruction))
ck('x_normal_p0_formula',px0.subs(xcoeff)-(D+r*(n+half))/k)
ck('x_normal_p1_formula',px1.subs(xcoeff)-r*(n+D+half)/k)
ck('x_normal_q1_formula',qx1.subs(xcoeff)-(n*r+B*r*(n+D+half)/k)/l)

# Exact residue positivity and the legal separated small-perturbation identity.
nn,mm=s.symbols('nn mm')
ck('x_R2_residue_determinant',(nn+mm+half)*mm-mm*mm-mm*(nn+half))
aa,bb=s.symbols('aa bb')
ck('pure_source_test_positive_product_identity',1+aa*bb-((1+aa)*(1+bb)+(1-aa)*(1-bb))/2)
payload={'status':'PASS','count':len(out),'checks':out,
 'scope':'Exact full-parent five-root Gram conditional on the original six stationary contact equations. Local tensor positivity uses the separate boundedness and positive-residue proof; no claim of final residual-complement nonemptiness.',
 'source_subchart':'A-only unbounded weak-B chart, with z/B and 1-r additionally positive bounded units.',
 'testing_scope':'u,v independent infinitesimals or zero; no source/testing rate comparison.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps(payload,indent=2))
