# Final scope of the weak-B reduction

`weak_two_soft_frame.tex` is an exact full-parent reduction on the actual reflected C2 weak-C HH face: z, y, B are positive infinitesimals, C is strong, alpha is weak, and every original source gap and n >= 0 are retained. It includes arbitrary independent source and testing rates. Its local testing domain is u and v infinitesimal.

The reduction retains all state directions. It proves a bounded polynomial remainder with two strictly positive hard-normal residue entries after retaining the complete centered m and D excess packets. It prints the entire two-soft scalar, all first-normal coefficients, the exact common-radial factorization, and a positive-term source identity. The new source identity gives zy/B infinitesimal, alpha/B infinitesimal, and, using C strong, a positive real lower bound for alpha/B^2.

The precise unproved gate is a joint weighted allocation of the two soft directions, both full first normals, and the centered excess-packet jets. Source physicality gives a positive semidefinite contact Hessian for the original parent. It cannot be applied unchanged to the capped remainder: the removed m and D packets have radial Hessian masses m_e z H^2 and D_e z^2 y r^2. A legal proof must keep their weighted jet roots in the Gram or prove the required subtraction bound. Neither the scalar radial factorization nor a fixed-v pure-source positive Gram solves this full-parent gate.

`check_weak_two_soft_frame.py` / `.json`: 16 exact symbolic checks pass. They verify the printed reduction identities, not weak-B positivity or a weak-B residual-row admission. Final TeX display endings and tags in WS14 and WS17 have been repaired.

The separate strong-II/HH result is complete: `local_strong_ii.tex` has 22 passing exact checks and joins the independently reviewed remote module under `analysis_atlas/oct19_r7_c2_remote/`, which has 17 passing checks. See `ROOT_REVIEW.md` for the supervising admission and coverage statement. No strong-face proof is extended to the weak-B face by continuity.
