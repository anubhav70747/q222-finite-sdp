# An exact physical family approaching a commuting source angle

Let 0<t<=1/2, or let t be positive infinitesimal in the real closed source field. Set uc=t, vc=1 and

    psi_c=(1,-5t^2/8,t/2,3t/4),   d=1,   lambda=n=0.

Writing H=5t^4+32t^2+32, take

    m=60t^4(t^2+1)/[(3t^2+8)H],
    c=-3(t^2+1)(5t^2-8)/(2H),
    A=-3(5t^4-6t^2-16)/(4H),
    D=-(25t^6+170t^4+32t^2-128)/[2(5t^2+2)H],
    alpha=(5t^2-4t+8)(5t^2+4t+8)/(2H),
    beta=(5t^2+4)(11t^2+16)/(2H).

Every coefficient is strictly positive on the stated interval. Direct exact substitution gives P(uc,vc)psi_c=0 and psi_c^T P_u psi_c=psi_c^T P_v psi_c=0. Their limits are

    (m,c,A,D,alpha,beta) -> (0,3/8,3/8,1,1,1),
    m/t^4 -> 15/64.

The exact determinant has nonnegative outer Laurent coefficients. Its stationary zero supplies positive exponent balance, and the finite positive circuit/AM-GM decomposition proves its nonnegativity for all positive angles. The original three-direction core criterion then gives PSD of the entire parent. Literal commuting axes have direct nonnegative core squares, and signed angles follow the exact state-sign conjugation. This proves global physicality, rather than only contact feasibility. After source-trace normalization, d tends to 4/19, so the weak angle is not explained by d losing residue.

This family demonstrates the appropriate normal scale. The bounded parity state is q(u)=(1,-5t^2/8,u/2,3u/4). At t=0 its scalar energy has exact u^2 coefficient

    (9/2)(v-1)^2.

The XYZ hard residue is diag(12,18,8), while the v-current divided by t tends to (0,6,0). After state relaxation the v-stiffness therefore satisfies

    C_vv/t^2 -> 9/2 - 36/18 = 5/2.

Whitening only with the source-scaled normal t(v-1) leaves a coefficient proportional to u_test^2/t^2. Its source coefficient t^-2 is unbounded. The testing-weighted normal u_test(v-1), together with u_test^2-t^2, avoids that particular failure. This is a failure of the naive source-normal allocation, not an impossibility result for bounded tensor SOS; the companion weighted theorem resolves this D-unit branch.

Reproduce with derive_weak_source_family.py. It verifies all six contact equations, all coefficient signs on 0<t<=1/2 using exact rational bounds, the hard block and curvature limits. The receipt is WEAK_SOURCE_FAMILY_CHECKS.json. No numerical optimization was used.
