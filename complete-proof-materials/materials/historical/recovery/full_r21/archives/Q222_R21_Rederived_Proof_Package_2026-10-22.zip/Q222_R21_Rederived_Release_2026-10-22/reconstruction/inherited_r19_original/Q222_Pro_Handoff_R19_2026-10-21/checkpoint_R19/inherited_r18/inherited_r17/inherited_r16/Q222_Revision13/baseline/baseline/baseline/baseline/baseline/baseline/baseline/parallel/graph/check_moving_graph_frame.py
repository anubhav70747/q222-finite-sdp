#!/usr/bin/env python3
"""Exact full-parent moving-frame check. No numerical SDP or sampling."""
import json
from pathlib import Path
import sympy as s

HERE=Path(__file__).resolve().parent
u,v,x,y=s.symbols('u v x y')
d,m,c,A,D,al,be=s.symbols('d m c A D alpha beta')
Du,Dv=1+u*u,1+v*v
a,b,cc,f,p,q,k=4*m,4*c,4*A,4*D,4*al,4*be,2*d
G=s.Matrix([
 [Du*(p+v*v*(f*Du+k*u*u)),-Du*Dv*(f*Du+k*u*u),-Du*(p+k),0],
 [-Du*Dv*(f*Du+k*u*u),Du*Dv/v**2*(b*Du+cc+f*Du*Dv+k*(1+u*u+u*u*v*v)),-cc*Du*Dv/v**2,-b*u*Du*Dv],
 [-Du*(p+k),-cc*Du*Dv/v**2,Du*(a*Du/u**2+cc*Dv/v**2+p+k),-a*Du*Dv/u],
 [0,-b*u*Du*Dv,-a*Du*Dv/u,Dv*(a*Dv+b*u*u*v*v+q+k)]
])
# This is exactly the existing full C1 gain matrix, after a pure test clearing.
M=(u*u*v*v*G).applyfunc(s.expand)
src={d:s.Rational(437,30),m:s.Rational(3,11),c:2,A:s.Rational(244,15),D:s.Rational(79,780),al:s.Rational(351,20),be:s.Rational(823,60)}
ct={u:s.Rational(1,2),v:s.Integer(2)}
h=s.Matrix([s.Rational(12,5),s.Rational(7,5),s.Rational(19,10),s.Rational(1,8)])
H=s.diag(*h); one=s.ones(4,1); E=s.eye(4)[:,:3]
M=M.subs(src)
L=H*M.subs(ct)*H
assert L*one==s.zeros(4,1)
assert all(L[i,j]<0 for i,j in [(0,1),(0,2),(2,3)])
L0=L[:3,:3]
assert all(L0[:i,:i].det()>0 for i in range(1,4))
currents=[]; transports=[]
for z in (u,v):
    b0=H*M.diff(z).subs(ct)*h
    assert sum(b0)==0
    t=s.Matrix([*L0.inv()*(-b0[:3,0]),0])
    assert L*t==-b0
    currents.append(b0); transports.append(t)

V=one+transports[0]*x+transports[1]*y
Mxy=M.subs({u:ct[u]+x,v:ct[v]+y})
K=H*Mxy*H
hard=(E.T*K*E).applyfunc(s.expand)
cross=(E.T*K*V).applyfunc(s.expand)
scalar=s.expand((V.T*K*V)[0])
assert all(s.Poly(z,x,y).coeff_monomial(x**i*y**j)==0 for z in cross for i,j in [(0,0),(1,0),(0,1)])
assert all(s.Poly(scalar,x,y).coeff_monomial(x**i*y**j)==0 for i,j in [(0,0),(1,0),(0,1)])

# Exact contact-ideal division, never an omitted Taylor remainder.
Q=s.zeros(5); Q[:3,:3]=hard
for i in range(3):
    for (a0,b0),coef in s.Poly(cross[i],x,y).terms():
        if a0:
            term=coef*x**(a0-1)*y**b0; Q[i,3]+=term;Q[3,i]+=term
        else:
            term=coef*y**(b0-1);Q[i,4]+=term;Q[4,i]+=term
for (a0,b0),coef in s.Poly(scalar,x,y).terms():
    if a0>=2: Q[3,3]+=coef*x**(a0-2)*y**b0
    elif a0==1:
        term=coef*y**(b0-1)/2;Q[3,4]+=term;Q[4,3]+=term
    else: Q[4,4]+=coef*y**(b0-2)
Q=Q.applyfunc(s.expand)
w1,w2,w3,z=s.symbols('w1 w2 w3 z')
w=s.Matrix([w1,w2,w3]); state=H*(E*w+V*z)
roots=s.Matrix([w1,w2,w3,x*z,y*z])
assert s.expand((state.T*Mxy*state)[0]-(roots.T*Q*roots)[0])==0
Q0=Q.subs({x:0,y:0})
assert Q0[:3,:3]==L0
assert Q0[:3,3:]==s.zeros(3,2)
C=Q0[3:,3:]
assert C[0,0]>0 and C.det()>0

# Check curvature = balanced determinant covariance at the same physical contact.
tt=[d+2*D,d+2*(al+m+A),d+2*(c+D),d+2*(al+be+m),d+2*be,d+2*(al+c+A),d+2*(be+m),d+2*(c+A+D)]
t1,t2,t3,t4,t5,t6,t7,t8=tt
outer={(-1,0):4*al*m*t5*t8,(-1,1):4*m*D*t5*t6,(0,-1):4*al*A*t7*t3,(0,1):4*(be*m*t1*t6+c*D*t5*t2),(1,0):4*c*A*t1*t4,(1,1):4*be*c*t1*t2}
Uc,Vc=ct[u]**2,ct[v]**2
Cov=s.zeros(2);balance=s.zeros(2,1)
for nu,coef in outer.items():
    mass=coef.subs(src)*Uc**nu[0]*Vc**nu[1]
    nv=s.Matrix(nu);Cov+=mass*nv*nv.T;balance+=mass*nv
assert balance==s.zeros(2,1)
J=s.Matrix([[1,0,0,1],[0,1,0,1],[0,0,1,1],[0,0,0,1]])
# det(J)=1; det(HJ)^2 is the constant state-congruence factor.
detT=(1+Uc)/(ct[u]*ct[v]**2)
prefactor=(ct[u]**2*ct[v]**2)**4*detT**2*s.prod(h)**2*16*(1+Uc)**2*(1+Vc)**2*Uc*Vc
DC=s.diag(1/ct[u],1/ct[v])
predicted=2*prefactor/L0.det()*DC*Cov*DC
assert s.simplify(C-predicted)==s.zeros(2), (C,predicted,C[0,0]/predicted[0,0])

def mat(a):return [[str(z) for z in a.row(i)]for i in range(a.rows)]
receipt={'status':'PASS','scope':'Full literal C1 parent, source-only moving graph frame, exact five-feature Gram, strict residue at a physical rational contact; not all degeneration regimes',
 'source':{str(k):str(v)for k,v in src.items()},'contact_angles':[str(ct[u]),str(ct[v])],
 'h':list(map(str,h)),'grounded_laplacian':mat(L0),'currents':[list(map(str,a))for a in currents],
 'transport':[list(map(str,a))for a in transports], 'reduced_curvature':mat(C),
 'grounded_sylvester_minors':[str(L0[:i,:i].det())for i in range(1,4)],
 'curvature_sylvester_minors':[str(C[0,0]),str(C.det())],
 'balanced_covariance':mat(Cov),'exact_full_parent_identity':True,'no_mixed_inverse':True,
 'Q_polynomial_degrees':[max(s.Poly(a,x,y).total_degree() for a in Q)],
 'Q_nonzero_terms':sum(len(s.Poly(a,x,y).terms()) for a in Q if a!=0)}
(HERE/'MOVING_GRAPH_FRAME_CHECKS.json').write_text(json.dumps(receipt,indent=2)+'\n')
(HERE/'MOVING_GRAPH_ANCHOR_GRAM.json').write_text(json.dumps({'variable_order':['x','y'],'Q':[[[[list(exp),str(coef)]for exp,coef in s.Poly(Q[i,j],x,y).terms()] for j in range(5)]for i in range(5)]},indent=2)+'\n')
print(json.dumps(receipt,indent=2))
