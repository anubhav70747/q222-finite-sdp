from pathlib import Path
import sympy as s,json
ns={}
exec(Path(__file__).with_name('check_ih_source.py').read_text().split("e=s.symbols('e',positive=True)")[0],ns)
z,y,H,L,R=[ns[k] for k in ['z','y','H','L','R']]
e=s.symbols('e',positive=True)
sub={z:e**4,y:e**4,H:e,L:e**4/2,R:e**4/4}
w={k:s.factor(v.subs(sub)) for k,v in ns['weights'].items()}
reflection={'n':'n','m':'D','C':'alpha','A':'A','D':'m','alpha':'C'}
hh={k:w[v] for k,v in reflection.items()}
scales={'n':1,'m':e**-3,'C':e**2,'A':e**3,'D':e**6,'alpha':e**-3}
expected={'n':s.Rational(3,2),'m':1,'C':s.Rational(1,2),'A':s.Rational(1,2),'D':s.Rational(3,8),'alpha':1}
checks=[]
for name,val in hh.items():
 lim=s.limit(val/scales[name],e,0,dir='+');assert lim==expected[name],(name,lim)
 checks.append('reflected HH leading '+name)
G=ns['G'];B=ns['B']
gaps={'r':R/z,'1-r':1-R/z,'h':H/z,'t':L/y,'g':G/z,'j':1+R-L/y,'1-zh':1-H,'b-y*r':(B-y*R)/z}
for name,gap in gaps.items():
 lead=s.factor(gap.subs(sub)).as_leading_term(e);assert lead.as_coeff_Mul()[0]>0,(name,lead)
 checks.append('physical pre-reflection gap '+name)
result={'status':'PASS','count':len(checks),'checks':checks,'weights':{k:str(v) for k,v in hh.items()},'normalized_leading':{k:str(v) for k,v in expected.items()},'scope':'Physical HH curve by exact reflection, demonstrating failure of product bounds. This exact rational curve is separately all-tests admitted by cor:rational-physical-source-curve; it is not a residual-leaf nonemptiness witness.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
