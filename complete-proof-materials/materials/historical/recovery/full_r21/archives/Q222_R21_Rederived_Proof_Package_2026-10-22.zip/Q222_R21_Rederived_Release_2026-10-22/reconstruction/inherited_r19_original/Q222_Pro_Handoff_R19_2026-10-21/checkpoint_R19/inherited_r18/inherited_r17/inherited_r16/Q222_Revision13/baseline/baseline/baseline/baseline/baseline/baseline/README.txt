Q222: analytical checklist continuation -- 17 October 2026
=========================================================

Start with Q222_Checklist_Proof_2026-10-17.pdf and CHECKLIST.json.
PROOF_STATUS.json is authoritative for this cumulative package.

Four completed analytical admissions
-----------------------------------
1. C1: k a positive bounded unit, eta=f^2 and zeta=g^2 infinitesimal,
   arbitrary positive s=g/f and every positive native shape opening.
   All independent projective tests. Combined with the inherited small-k
   theorem after orientation 0<k<=1, this closes the entire both-small
   eta,zeta domain.
2. C2: C/d infinitesimal, d/alpha bounded, and all four ratios
   d^2/(Cn),d^2/(Cm),d^2/(CA),d^2/(CD) bounded. The exact reflection
   joins two existing outer-chart lemmas into an all-tests theorem.
3. C2: the variable bounded-shape single-angle domain printed in
   advances/c2/general_single_angle.tex, including literal n=0.
   Its global scalar sign and unique contact reduce to reciprocal-pair
   and three-cycle AM-GM identities. All full normals and tests included.
4. C2: the pitchfork with d,C,alpha units, m,A,D bounded and n>=0
   arbitrary, including unbounded n/d, and an actual small--ordinary
   contact. A sqrt(d+2n) state-normal scaling controls every n term.
   Source entry and all independent tests are proved.

These are scoped source-domain theorems. Every proof retains its exact
physicality, source-entry, actual-contact and original-positivity
hypotheses. No numerical positivity sample or atlas table is a premise.

Remaining global obligation
---------------------------
The global atlas-free proof is NOT complete. The C1 native complement
has at least one of eta,zeta non-infinitesimal. C2 retains uncaptured
one-weak sources and uncaptured sources with C/d,alpha/d strong and a
weak event among m,A,D. Subtract all stated inherited/new admissions and
their symmetry images before treating a point as open. These conditions
are not a count of nonempty families. A universal analytical source-by-
test cover and its final finite-lift join remain to be proved.

The retained historical global computer-assisted atlas package is
included intact under baseline/retained/. It has not been freshly
replayed. No evaluated global affine SDP pencil is supplied.

Reproduction
------------
  python3 verify.py
      All distributed-file hashes and 77 new standard-library checks.

  python3 verify.py --with-sympy
      Also runs the 44 new exact SymPy identities: 121 checks in total.

  python3 verify.py --integrity-only
      File integrity only; no algebra replay.

Do not use Python -O. The checkers intentionally reject disabled
assertions. SymPy is needed only for the optional general C2 checker.
Replays run in temporary directories; supplied historical receipts are
never overwritten. Test PASS labels corroborate finite exact algebra;
proof quantifiers, boundedness and exhaustive dispatch are arguments in
the manuscript. The root verification/ records fresh scoped replays.

To rebuild the manuscript, run pdflatex twice on
Q222_Checklist_Proof_2026-10-17.tex from this directory. A TeX installation
with the packages named in its preamble is required.

Contents and provenance
-----------------------
advances/c1/                 New C1 proof, exact checks and audit.
advances/c2/                 Three new C2 proofs, checks and audits.
reconciliation/checklist.tex Precise residual mathematical obligations.
CHECKLIST.json               Machine-readable completion checklist.
PROOF_GRAPH.json             Dependency/admission graph; not exhaustive.
baseline/                   Exact preceding cumulative package.
verification/               Fresh exact replays and PDF layout record.
MANIFEST.json               SHA-256 integrity of every other file.

The baseline is preserved byte-for-byte. Its nested status files retain
historical scope. New proof copies differ from audited research sources
only by line breaks, path wrapping and other typesetting adjustments.
Independent audits are scoped same-system reviews, not external peer
review or formal verification. The mathematical frontier remains explicit.
