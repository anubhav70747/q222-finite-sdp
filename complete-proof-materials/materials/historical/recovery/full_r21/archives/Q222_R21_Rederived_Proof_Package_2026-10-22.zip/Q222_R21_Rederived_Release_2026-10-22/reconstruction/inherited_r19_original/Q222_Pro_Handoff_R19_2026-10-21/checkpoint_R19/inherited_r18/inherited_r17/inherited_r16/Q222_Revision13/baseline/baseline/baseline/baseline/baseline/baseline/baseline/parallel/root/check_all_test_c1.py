#!/usr/bin/env python3
"""Generic exact original-parent C1 edge and corner checks; no numerical search."""
import json
from pathlib import Path
import sympy as s

HERE=Path(__file__).resolve().parent
u,v,r,t=s.symbols('u v r t')
d,m,c,A,D,al,be=s.symbols('d m c A D alpha beta')
W,X,Y,Z=s.symbols('W X Y Z')
psi=s.Matrix([W,X,Y,Z]); du=1+u*u; dv=1+v*v
F=(4*m*(v*W-X+u*v*Y-u*Z)**2+4*c*dv*(u*W-Y)**2+4*A*du*dv*Y**2
 +(4*D+2*d)*(u*W+u*v*X-Y-v*Z)**2+(4*al+2*d)*du*(v*Y-Z)**2
 +(4*be+2*d)*dv*(X+u*Z)**2-2*d*du*dv*Z**2)
P=s.hessian(F,(W,X,Y,Z))/2
P=P.applyfunc(s.expand)

def chart(i,j):
    Q=P.subs({u:1/r if i else r,v:1/t if j else t})
    return (Q*(r*r if i else 1)*(t*t if j else 1)).applyfunc(s.cancel)

edges={
 'u0':(P.subs(u,0),4*m*(v*W-X)**2+(4*be+2*d)*dv*X**2+(4*(c+A)+2*d)*dv*Y**2+4*D*(Y+v*Z)**2+4*al*(v*Y-Z)**2),
 'uinf':(chart(1,0).subs(r,0).subs(t,v),4*c*dv*W**2+4*A*dv*Y**2+(4*D+2*d)*(W+v*X)**2+(4*m+4*al+2*d)*(v*Y-Z)**2+4*be*dv*Z**2),
 'v0':(P.subs(v,0),(4*m+4*be+2*d)*(X+u*Z)**2+4*al*du*Z**2+(4*(c+D)+2*d)*(u*W-Y)**2+4*A*du*Y**2),
 'vinf':(chart(0,1).subs(t,0).subs(r,u),4*m*(W+u*Y)**2+4*c*(u*W-Y)**2+(4*(A+al)+2*d)*du*Y**2+2*d*du*X**2+4*D*(u*X-Z)**2+4*be*(X+u*Z)**2)
}
for name,(matrix,formula) in edges.items():
    assert s.expand((psi.T*matrix*psi)[0]-formula)==0,name

expected={
 (0,0):[0,4*m+4*be+2*d,4*c+4*A+4*D+2*d,4*al],
 (1,0):[4*c+4*D+2*d,0,4*A,4*m+4*al+4*be+2*d],
 (0,1):[4*m,4*be+2*d,4*c+4*A+4*al+2*d,4*D],
 (1,1):[4*c,4*D+2*d,4*m+4*A+4*al+2*d,4*be]
}
for ij,diag in expected.items():
    assert chart(*ij).subs({r:0,t:0})==s.diag(*diag),ij

specs=[((0,0),0,{},[4*A*(d+2*(c+D))/(d+2*(c+A+D)),4*m*(d+2*be)/(d+2*(m+be))]),
 ((1,0),1,{},[4*al*(d+2*(m+be))/(d+2*(m+al+be)),4*c*(d+2*D)/(d+2*(c+D))]),
 ((0,1),3,{D:0},[4*be*d/(d+2*be),4*al*(d+2*(c+A))/(d+2*(c+A+al))]),
 ((1,1),3,{be:0},[4*D*d/(d+2*D),4*A*(d+2*(m+al))/(d+2*(m+A+al))])]
out=[]
for ij,k,subs,diag in specs:
    Q=chart(*ij).subs(subs)
    Q0=Q.subs({r:0,t:0})
    ids=[i for i in range(4) if i!=k]
    hard=Q0.extract(ids,ids)
    inv=hard.inv(); h=s.eye(4)[:,k]
    assert Q0*h==s.zeros(4,1)
    C=s.zeros(2)
    bs=[]
    for var in (r,t):
        grad=Q.diff(var).subs({r:0,t:0})*h
        assert (h.T*grad)[0]==0
        bs.append(grad.extract(ids,[0]))
    for i,vi in enumerate((r,t)):
        for j,vj in enumerate((r,t)):
            C[i,j]=s.cancel((h.T*Q.diff(vi,vj).subs({r:0,t:0})*h)[0]/2-(bs[i].T*inv*bs[j])[0])
    assert all(s.cancel(C[i,j]-(diag[i] if i==j else 0))==0 for i in range(2) for j in range(2)),(ij,C)
    out.append({'chart':list(ij),'kernel_coordinate':k,'hard_diagonal':[str(hard[i,i])for i in range(3)],'curvature':[[str(C[i,j])for j in range(2)]for i in range(2)]})
receipt={'status':'PASS','scope':'generic exact C1 four open-edge identities, four projective corner matrices, and four source-only reduced corner Hessians','edge_identities':list(edges),'corners':out,'numerical_tests':0,'mixed_inversions':0}
(HERE/'ALL_TEST_C1_CHECKS.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
