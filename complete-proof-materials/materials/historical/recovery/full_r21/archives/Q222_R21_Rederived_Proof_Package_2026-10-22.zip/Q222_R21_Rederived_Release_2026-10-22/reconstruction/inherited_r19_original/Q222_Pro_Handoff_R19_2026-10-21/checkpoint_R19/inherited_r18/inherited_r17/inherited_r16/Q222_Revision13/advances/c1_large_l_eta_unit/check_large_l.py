import sympy as s, json, time
from pathlib import Path
start=time.monotonic(); checks=[]
def ck(name,expr):
    n=s.fraction(s.cancel(expr))[0]; ok=s.expand(n)==0
    checks.append({'name':name,'pass':ok}); print(('PASS ' if ok else 'FAIL ')+name,flush=True)
    if not ok: print(s.factor(n),flush=True); raise AssertionError(name)
u,w,q,W,X,Y,Z,Nx,Ny,Ez=s.symbols('u w q W X Y Z Nx Ny Ez')
x,z,t,xi,b,h,sg=s.symbols('x z t xi b h sigma')
mu,c,a,l,Ds,bs,dj,bt=s.symbols('mu c a l Dstar betastar dJ betatheta')
aa,ll=s.symbols('astar lstar'); Q=1-b; th=1-h
Js=1+x*h-sg*(1-b*z)
Du=1+u*u; Dw=1+w*w; m=mu*x*x*q*q
Mw=W-w*X+u*Y-u*w*Z;Rw=u*W-Y;Jw=u*w*W+u*X-w*Y-Z;Bw=X+u*Z
Kw=Jw**2+Du*(Y-w*Z)**2+Dw*Bw**2-Du*Dw*Z**2
cN=8*Du*(a*b*Dw-l*Q);cG=4*Du*(a*b*b*Dw+l*Q*Q)
G0=4*Du*(aa*Dw+ll)*Ny**2+cN*u*q*W*Ny+cG*(2*u*w*W*Z-u*u*q*q*W*W)
G0+=4*m*Mw**2+4*c*q*q*Dw*Rw**2+4*Ds*Jw**2-8*dj*Z*Jw-4*dj*Js.subs(z,q*q)*Z*Z
G0+=4*bs*Dw*Bw**2+8*(bt-bs*th)*u*Dw*Z*Bw-4*(bt-bs*th)*u*u*th*Dw*Z*Z+2*Kw
G0=s.Poly(s.expand(G0.subs({X:Nx-u*h*Z,Y:q*Ny+b*w*Z}).subs(Z,Ez+u*w*W/sg)),Nx,Ny,Ez,W)
M0=1+t*(h-Q)*xi/sg;Rf=1-b*xi/sg;T0=1+t*h+b*xi;Jf=1-T0/sg
cn=8*(1+t)*(a*b*(1+xi)-l*Q);cg=4*(1+t)*(a*b*b*(1+xi)+l*Q*Q)
phi=4*mu*x*x*z*M0**2+4*c*z*(1+xi)*t*Rf**2+cg*t*(2*xi/sg-z)
phi+=4*Ds*t*xi*Jf**2-8*dj*t*xi*Jf/sg-4*dj*Js*t*xi/sg**2+4*bt*th*(1+xi)*t*t*xi/sg**2
phi+=2*(t*xi*Jf**2+(1+t)*t*Q*Q*xi*xi/sg**2+(1+xi)*t*t*th*th*xi/sg**2-(1+t)*(1+xi)*t*xi/sg**2)
Lx=-8*mu*x*x*z*M0+t*((8*Ds+4)*Jf-8*dj/sg+(8*bt+4*th)*(1+xi)/sg)
Ly=8*mu*x*x*z*M0-8*c*z*(1+xi)*Rf+cn-(8*Ds+4)*xi*Jf+8*dj*xi/sg-4*(1+t)*Q*xi/sg
Lz=8*mu*x*x*z*(h-Q)*M0-8*c*z*(1+xi)*b*Rf+2*cg-(8*Ds+4)*T0*Jf-8*dj*Jf+8*dj*(T0-Js)/sg
Lz+=8*bt*th*(1+xi)*t/sg+4*(1+t)*Q*Q*xi/sg+4*(1+xi)*t*th*th/sg-4*(1+t)*(1+xi)/sg
sub={t:u*u,xi:w*w,z:q*q}
for name,expr,mon in [('scalar',phi,(0,0,0,2)),('X first normal',w*Lx,(1,0,0,1)),('Y first normal',u*q*Ly,(0,1,0,1)),('Z first normal',u*w*Lz,(0,0,1,1))]:
    ck('complete '+name,G0.coeff_monomial(mon)-expr.subs(sub))
# The remaining six coefficients are retained by this coefficient extraction,
# so this is an exact full normal identity rather than a scalar restriction.
quad=sum(G0.coeff_monomial(mon)*Nx**mon[0]*Ny**mon[1]*Ez**mon[2] for mon in [(2,0,0,0),(0,2,0,0),(0,0,2,0),(1,1,0,0),(1,0,1,0),(0,1,1,0)])
ck('complete quadratic normal support',G0.as_expr()-quad-phi.subs(sub)*W*W-w*Lx.subs(sub)*W*Nx-u*q*Ly.subs(sub)*W*Ny-u*w*Lz.subs(sub)*W*Ez)
mn=-w*Nx+u*q*Ny+u*w*(h-Q)*Ez;rn=-q*Ny-b*w*Ez;jn=u*Nx-w*q*Ny-T0.subs(sub)*Ez;bn=Nx+u*th*Ez
hh=4*Du*(aa*Dw+ll)*Ny*Ny+4*m*mn*mn+4*c*q*q*Dw*rn*rn+(4*Ds+2)*jn*jn-8*dj*Ez*jn-4*dj*Js.subs(z,q*q)*Ez*Ez
hh+=(4*bs+2)*Dw*bn*bn+8*(bt-bs*th)*u*Dw*Ez*bn-4*(bt-bs*th)*u*u*th*Dw*Ez*Ez+2*Du*(q*Ny-Q*w*Ez)**2-2*Du*Dw*Ez*Ez
ck('displayed complete quadratic normal block',quad-hh)
K=1+x;R=1+x*b*z;M=R-x*z*th;Es=1-x*h/sg
P=sg+K+sg*z*(1+b*x+2*x*h)+sg*b*x*x*h*z*z+x*x*h*th*z
VV=z*(1+x*h)*Es+(1-b*z)*(1+x*h*z)
src={mu:K*(1+sg*b*z)*h*(sg*z+1)/(2*sg*M*P),c:K*(1+sg*b*z)*Es/(2*(1-b*z)*P),a:VV/(2*b*P),l:(1+sg*b*z)*((x/sg)*R*h*(sg*z+1)+M*Es)/(2*Q*P),dj:K*(sg*z+1)*(1+sg*b*z)/(2*P)-Js/2-Ds*Js,bt:K*(1+sg*b*z)*(1+x*h*z)/(2*P)-th/2}
def source(e):
    e=s.expand(e); weights=tuple(src); out=e.subs({v:0 for v in weights})
    for v in weights:out+=s.cancel(s.factor(e.coeff(v))*src[v])
    return out
contact={t:x,xi:sg*z}
for name,e in [('scalar contact',phi),('scalar t jet',s.diff(phi,t)),('scalar xi jet',s.diff(phi,xi)),('X jet',Lx),('Y jet',Ly),('Z jet',Lz)]:ck(name,source(e.subs(contact)))
ck('scalar t-zero support',phi.subs(t,0)-4*mu*x*x*z)
ck('X t-zero support',Lx.subs(t,0)+8*mu*x*x*z)
ck('source ab-lQ vanishes at z zero',source(a*b-l*Q).subs(z,0))
ck('scalar xi-contact divisible z',phi.subs(xi,sg*z).subs(z,0))
ck('source mu residue',src[mu].subs({x:0,z:0})-h/(2*sg*(1+sg)))
ck('source dJ residue',(src[dj]+Ds*Js).subs({x:0,z:0})-sg*sg/(2*(1+sg)))
ck('source beta theta residue',src[bt].subs({x:0,z:0})-((1+sg)*h-sg)/(2*(1+sg)))
rh=(w*Z-u*q*q*W)/q;az=q*(u*u-x)*W;v=u*w*(u*u-x)*W;ez=Z-u*w*W/sg
ck('scalar mixed conductor',u*u*(u*u-x)*(w*w-sg*q*q)*W*W-u*sg*az*rh+sg*v*ez)
ck('scalar radial conductor',u*u*(w*w-sg*q*q)**2*W*W-sg*sg*(q*rh-w*ez)**2)
ck('free V pivot',v*v-sg*u*u*az*az-u*sg*(u*u-x)*az*rh+sg*(u*u-x)*v*ez)
ck('X angular conductor',w*(u*u-x)*u*u*W-u*v)
ck('X radial conductor',w*u*u*(w*w-sg*q*q)*W-u*sg*q*w*rh+u*sg*w*w*ez)
ck('Y radial conductor',u*q*(w*w-sg*q*q)*W-sg*q*q*rh+sg*q*w*ez)
ck('Z radial conductor',u*w*(w*w-sg*q*q)*W-sg*q*w*rh+sg*w*w*ez)
res={u:0,w:0,q:0,x:0,z:0}
ck('hard Nx pivot',quad.coeff(Nx,2).subs(res)-2-4*bs)
ck('hard Ny pivot',quad.coeff(Ny,2).subs(res)-4*(aa+ll))
ck('hard Ez pivot',quad.coeff(Ez,2).subs(res)-4*(Ds+dj*(1+sg)))
for nm,mm in [('xy',Nx*Ny),('xz',Nx*Ez),('yz',Ny*Ez)]:ck('hard '+nm+' cross residue',s.expand(quad).coeff(mm).subs(res))
ck('radial pivot residue',source(cg).subs({t:0,xi:0,x:0,z:0})-2/(1+sg))
# Exact finite-denominator positive allocation away from the angular contact.
U=s.symbols('U');jj=1-sg;den=jj+th*U
AA=U;BB=1+U;CC=U/den;DD=(1+U)*((1+U)/den-(1+sg));EE2=U*(1+U)**2/den**2
NN=U*(2*sg-th*U)
ck('away allocation numerator',EE2-AA*BB-CC*DD-(1+U)*NN/den)
ck('away discriminant',NN*NN-4*U*U*(1+U-(1+sg)*den)-U**3*(th*th*U-4*h))
ef,gf,rf,ff,xx,zz,rho=s.symbols('Eraw Graw Rraw Fraw Xraw Zraw rho')
dd=jj+th*u*u;pp=1+sg
raw=u*u*ef*ef+(1+u*u)*(ff*ff/b+(ff-gf)**2/Q)+(u*rf+u*xx-zz)**2/jj+(xx+u*zz)**2/th-pp*(1+u*u)*zz*zz
dx=xx+(u*u*th*rf+u*(jj-th)*zz)/dd
rr=(1+u*u)/u-rho*dd/(u*u)
sch=(1+u*u)*(2*rho/u-pp)-rho*rho*dd/(u*u)
comp=u*u*ef*ef+(1+u*u)*gf*gf-2*rho*ef*gf+(1+u*u)/(b*Q)*(ff-b*gf)**2+dd/(jj*th)*dx*dx+u*u/dd*(rf-rr*zz)**2+sch*zz*zz
ck('away full frame square completion',raw-comp-2*rho*(ef*gf-rf*zz))
# Centered-cap pair identities, independent of any source contact argument.
gg=s.symbols('Graw2'); original=4*Du*(a*Dw*(Ny+b*gg)**2+l*(Ny-Q*gg)**2)
ck('exact A alpha centered cap pair',original-4*(a-aa)*Du*Dw*Ny*Ny-4*(l-ll)*Du*Ny*Ny-4*Du*(aa*Dw+ll)*Ny*Ny-cN*Ny*gg-cG*gg*gg)
dd0,bb0,jj0=s.symbols('Dfull betafull Jpure')
ck('exact D centered cap',4*dd0*Jw*Jw-4*(dd0-Ds)*(Jw+jj0*Z)**2-4*Ds*Jw*Jw+8*(dd0-Ds)*jj0*Z*Jw+4*(dd0-Ds)*jj0*jj0*Z*Z)
ck('exact beta centered cap',4*bb0*Dw*Bw*Bw-4*(bb0-bs)*Dw*(X+u*h*Z)**2-4*bs*Dw*Bw*Bw-8*(bb0-bs)*th*u*Dw*Z*Bw+4*(bb0-bs)*th*th*u*u*Dw*Z*Z)
eF,eD,eB=s.symbols('eF eD eB'); dF=eF;dX=eB;dR=(eD-u*eB+q*w*eF)/u
ck('separated cap inverse F',dF-eF)
ck('separated cap inverse D',u*dR+u*dX-q*w*dF-eD)
ck('separated cap inverse beta',dX-eB)
out={'scope':'C1.4 L unbounded, sigma unit; exact full-normal conductor identities only','checks':checks,'passed':len(checks),'seconds':time.monotonic()-start}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(str(len(checks))+' checks in '+str(out['seconds'])+' seconds',flush=True)
