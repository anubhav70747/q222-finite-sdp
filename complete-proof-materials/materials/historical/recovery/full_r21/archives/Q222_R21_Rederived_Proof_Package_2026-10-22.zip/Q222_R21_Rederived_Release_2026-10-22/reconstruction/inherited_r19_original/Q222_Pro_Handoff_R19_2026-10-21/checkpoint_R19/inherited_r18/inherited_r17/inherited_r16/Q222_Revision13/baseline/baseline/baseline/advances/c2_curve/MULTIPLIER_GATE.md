# One exact mixed positive multiplier removes the remaining local Gram pole

Status: a full-parent **multiplier certificate**, not cancellation of the
multiplier. The subsequent `rational_curve_tensor_sos.tex` admits the
exact source family at all tests by a different argument. The source and roots are those
in `HALFCORNER_CERTIFICATE.md`.

Let `z=(eX,eM,ep,eP,Q)`. The old even-conductor allocation gives the exact
five-root Gram `MO` from `derive_witness_gram.py`. Its only unbounded entries
are `(X,P)` and `(P,Q)`. The new half-corner allocation gives `MN` from
`derive_halfcorner_witness.py`; without the restriction that `u/v` be
bounded, its only potentially unbounded entries are `(M,Q)` and `(P,Q)`.
Both represent the same full parent after an exact multiple of `G=0`.

Remove the listed exceptional entries and their symmetric partners from
`MO` and `MN`, giving `AO` and `BN`. Both remaining matrices are bounded
for arbitrary independent infinitesimal `u,v`. For each removed off-diagonal
entry `Eij`, add

```
x MO_ij/(2kv)       from the old matrix,
v² MN_ij/(2kv)      from the new matrix
```

to positions `(i,j)` and `(j,i)` of a five-by-five matrix `CC`. These
apparent testing denominators cancel exactly. In particular,

```
CC_PQ = u AP/(2k),
CC_MQ = u AM/(4k),
CC_XP = k MO_XP/(2v).
```

The first two are bounded because `AP/k` and `AM/k` are bounded pure
source quantities. The last is bounded because `MO_XP` is `uv/k` times
a bounded polynomial. Every entry of `CC` has zero residue.

The ten-by-ten Gram

```
MM = [ AO  CC  ]
     [ CC  BN  ]
```

on the ten original separated-tensor roots `(kz,vz)` satisfies exactly

```
(x+v²) Ftilde + G[x LO+v² LN] = (kz,vz) MM (kz,vz)^T,
```

where `LO,LN` are the old and new exact linear relation multipliers.
Thus on the original state, `G=0`, this is the unchanged parent multiplied
by `x+v²`.

Every Gram entry has a pure source unit denominator after cancellation.
Its residue is `diag(M0,M0)`, where

```
M0 = [4 0 0 0 1]
     [0 4 0 0 0]
     [0 0 2 0 0]
     [0 0 0 1 0]
     [1 0 0 0 1].
```

Each copy has Schur pivot `3/4`; the ten-by-ten determinant is `576`.
Consequently `(x+v²)F` is tensor SOS for **all** infinitesimal testing
`u,v`, with no relative-rate comparison and no mixed inverse or radical.
`derive_multiplier_witness.py` checks the exact full-parent identity,
all 55 bounded denominator gates and the residue matrix.

The unresolved local step is cancellation of

```
x+v² = k²+v².
```

It is a sum of a pure source square and a pure testing square. Its inverse
is not an allowed element of the separated tensor ring, and no principle
cancelling such a multiplier has been established here. Dividing the
identity by it, or taking its mixed square root, would not prove the
original tensor-SOS claim. The half-corner theorem cancels this need by
choosing the second allocation where `u/v` is bounded; the opposite
directed ratio endpoint still needs a denominator-free replacement or a
valid separate cancellation theorem. For this exact source family those testing charts are now covered by
the rational-curve theorem; uniform multiparameter source-II coverage
remains open.
