"""Narrow exact identities used in weak-B II source classification."""
import json
from pathlib import Path
import sympy as s

z,y,H,L,r=s.symbols('z y H L r')
B=H+L; ac=1+z*r; S=ac+L; j=ac-L/y
T=B+z*r; G=B+z*(H+r-1); g=G/B
delta=z+(1+z)*B+(1+z)*B**2+2*z*(1+z)*B*r+z**3*r**2+2*z**2*r+y*((1+z)*B+z+z**2*r*(2-r))
M=(1+z)*T*(H+y)-z*(1+y)*(1-r)*L
n=(T*ac*S-r*delta)/(2*r*delta)
m=z*z*(1+y)*(1-r)*ac*S/(2*G*delta)
C=ac*M/(2*L*delta)
A=y*ac*T*S/(2*H*delta)
alpha=T*M/(2*(1-H)*delta)
checks={}

def check(name,expr):
    assert s.cancel(expr)==0,name
    checks[name]=True

check('positive_M_decomposition',M-((1+z)*T*H+y*G+y*z*j+z*r*L*(1+y)))
check('n_source_scale',r*(2*n+1)-T*ac*S/delta)
check('A_source_scale',A*H/y-ac*T*S/(2*delta))
check('m_relative_gap_identity',m-(1+y)*ac*S*z*(1+z*H/B-g)/(2*delta*g))
check('two_small_gaps_force_B_z_contact',(1-g)*B/z-(1-H-r))
check('complementary_coefficient_ratio',alpha/C-L*T/((1-H)*ac))
payload={'status':'PASS','checks':checks,'scope':'Six exact source identities only. Valuation equivalences and admission scope are proved in weak_ii_source_alternatives.tex.'}
out=Path(__file__).with_suffix('.json')
out.write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps({'status':'PASS','count':len(checks)}))
