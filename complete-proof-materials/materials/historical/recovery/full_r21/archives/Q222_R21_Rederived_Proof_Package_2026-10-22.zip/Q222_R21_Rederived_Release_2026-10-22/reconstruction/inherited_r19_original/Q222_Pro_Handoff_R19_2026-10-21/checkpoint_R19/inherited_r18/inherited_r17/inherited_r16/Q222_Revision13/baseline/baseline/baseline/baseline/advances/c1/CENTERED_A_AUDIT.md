# Scoped same-system review: centered-A C1 extension

Reviewer: coverage_reduction agent. Reviewed `centered_a_unit_e.tex`, `centered_a_outer.tex`, `centered_a_source.py`, `check_centered_a_contact.py`, and `check_centered_a_outer.py`, against the actual inherited SD1–SD8 source/parent/packet formulas and the polynomial contact conductor. This is separate-agent same-system review, not external peer review or formal verification.

## Outcome and exact scope

No mathematical gap found in the stated all-tests theorem: physical unchanged native C1, k,ζ,r=1−aη positive infinitesimals, η and e positive bounded units, arbitrary positive opening rates, original coefficient nonnegativity, literal β=0 included, and no bound on k²/r. The theorem does not include nonunit e or unbounded η.

The new source chart removes the potentially uncontrolled k²/r quotient before the Gram construction. The centered packet is an original pure-coefficient positive square with exact zero value and full first derivative at the contact. Its restoration and the four inherited packet restorations recover the original parent exactly.

## Exact replay and portability

Both new checkers passed in the original location and in a relocated minimal bundle:

- `check_centered_a_contact.py`: 40 recorded exact checks, including the CA6 coefficient collection, full first normals and hard block, complete polynomial monic lifts of the low-weight terms, residue Gram, and CA8 determinant.
- `check_centered_a_outer.py`: 30 exact checks, reconstructing the original short source formulas and full selected parent independently of the contact scalar module.

For the portability replay, only the three new Python scripts plus the inherited `source_from_formulas.py` and `arithmetic.py` were copied to a fresh temporary directory; both checkers ran with working directory `/tmp`. SymPy was supplied as an external dependency. The reviewer identified a workspace-relative import issue; the author corrected the main checker to prefer a colocated source module, and the relocated replay used that route. `CENTERED_A_PORTABLE_REPLAY.json` records PASS. No numerical samples, rate grids, or additional source enumeration were used.

The checkers verify finite algebra and the displayed low-weight lift. They do not independently verify every arbitrarily high rational term or establish universal coverage by PASS labels; those steps are supplied by the polynomial membership, bounded-unit clearing, degree argument, and chart proof reviewed below.

## Cancelled source and CA5 full restoration

The exact identity `ell=K−aE=Qr` with `Q=K²−ell k²` follows from the unchanged SD6 substitution, not a residue approximation. All resulting denominators K,Q,E,δ,R,T,a and the cancelled tilde-c3 have positive unit residues. The six coquotients other than c4 have an explicit original Lc=r factor; dividing by ell=Qr cancels this factor algebraically. No ell inverse remains. In particular tilde-c-alpha is `2 Hc P-alpha/Q`, with no missing Qc factor.

The full source residues imply a is a unit, Ar→2, d→4/η, A unbounded, and A*=1/a bounded. Hence A−A*>0, and the centered square (CA1) is positive. The contact identity Yc=r uc Wc is exact, so retaining that square preserves full contact and all first derivatives.

The CA5 coefficients agree term-by-term with inherited SD4 divided by Δ²Λ:

- B2=H2/(Δ²Λ), Bb=Hb/(Δ²Λ).
- B3=H3/Λ and B5=H5/Λ.
- The remaining native positive channels become exactly 4A DuDv Y² and 4α Du(vY−1)².
- The remaining signed channel is exactly 2d Du[(vY−1)²−Dv].

Subtracting `4(A−A*)DuDv(Y−ruW)²` changes the A channel to precisely
`4A*DuDv(Y−ruW)² + 4(Ar)DuDv(2uWY−r u²W²)`.
This verifies CA2 and every term of CA5. The pure-testing inverse for W,Y uses only Du; qB and its N dependence are retained. No full normal or hard-state term is discarded. Potentially unbounded t,M,a,J opening ratios occur only in the four separately retained positive packets; CA5 has bounded coefficients and a unit denominator at every stated source rate.

## Low-weight collection and conductor

`centered_a_source.py` performs exact arithmetic modulo weights greater than six. A denominator inverse is computed as the finite geometric inverse in that quotient after factoring its weight-zero monomial in E and δ. Every discarded term has strictly higher weight. No inverse of k or ell occurs. The source code reconstructs the cancelled native coefficients and all of CA5 before extracting the scalar, full first normals, and hard block.

The exact collection CA6 agrees with the checker, including the ell and ell² x² corrections and the `(k+u)xz` term. Its residue is the stated x² plus T4 form. The hard block CA7 and full M-normal coupling give CA8 with determinant `256/(E³ δ²)>0`; the x pivot is also positive. The two-pairing identity supplies the remaining five strict soft-root directions. Together with the independent N direction this is a strict eight-root residue Gram.

The higher-term lifting argument is valid for the full rational remainder, not just its truncation:

1. At zero normals, qA lies in (wv), qB in (v), while uW and Y lie in (v,uw) with bounded unit denominators. Thus every scalar term belongs to `(A0,B0,C0)²+(D0²)`. The alpha constant has its exact k⁶ factor, hence is a unit multiple of D0²; its nonconstant contributions belong to the raw squared ideal. No uncontrolled mixed D0 term is introduced.
2. Differentiating the same complete expression shows both first normals belong to `(A0,B0,C0)`: the M derivatives of W,Y have bounded coefficients, the N derivatives contain v, and the core's remaining derivative has a v factor. This includes the signed first normals.
3. Original contact and stationarity, plus exact contact vanishing of every retained square, give second-order scalar contact membership and first-order normal contact membership.
4. Clear finitely many displayed positive unit denominators. The inherited monic conductor then applies in a polynomial ring allowing only the pure-unit E,δ inverses. Its proof uses domain cancellation only to establish vanishing, never to form an inverse of k,ell, an opening, or a contact difference.
5. Contact substitutions preserve weights. The CA6 scalar is itself a combination of contact-root products and belongs to the same restricted raw squared ideal; the apparent mixed D0 terms in T4 cancel by the exact circuit identity. Subtracting CA6 therefore preserves the required ideal and contact memberships. Scalar corrections have weight at least seven and normal corrections at least four. The scalar roots have weights at most three, so all constructed correction coefficients have positive weight. Clearing and restoring a unit denominator preserves this conclusion and all residue signs.

This supplies the bounded full-parent Gram claimed in the manuscript for every positive rate of ell relative to k. It does not rely on the original small-δ application of the conductor; only the unchanged polynomial identities are reused.

## Outer/state join

The cancelled original source identities give positive lower bounds on m/d,c/d,A/d,D/d without lower bounds on openings. The old outer identities BE2–BE4 require only those bounds and therefore apply. Neither BE5 nor the bounded-r raw contact conclusion is imported.

The new centered root H=√A(Y−ruW) is retained in full. CAO6 was independently reconstructed from the original parent; all source/testing factors and the complete signed cancellation are present. For bounded-unit u, its four-root residue has positive U,V determinant using either bounded exact D (η residue>1) or an allowed real cap below unbounded D (η residue=1). For unit w and unit Z, the additional clipped m packet supplies the strictly positive V mass after the residue B Schur calculation; that computation does not insert a mixed inverse into the full Gram.

Maximal-coordinate state normalization, the negative-core branch, and the exact SD5 pure-testing Schur identity leave precisely Z=1 with u,v,w positive infinitesimals. Literal axes, projective infinities, unit-W/zero-Z states, and every bounded-unit u state are already included by the proved outer frames. Real/imaginary splitting supplies complex states. Thus the remaining contact certificate joins to all independent tests with no missing state chart.

## Coverage consequence

Combined with the bounded-unit-r/e theorem, this closes every positive native r when η and e are units and k,ζ are infinitesimal. Combining further with the earlier η,r-unit/e-unbounded theorem leaves, inside the unit-η native row:

- r a unit and e infinitesimal;
- r infinitesimal and e infinitesimal or unbounded.

The η-unbounded branch remains outside these admissions. These are residual sufficient-domain complements, not claims that each is nonempty.
