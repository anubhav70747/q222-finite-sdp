"""Exact full-normal and residue determinant checks for IH remote charts."""
from pathlib import Path
import json
import sympy as s
u,p,w,v,W,X,Y,Z,H,B,C,A,al,d,c,a,b=s.symbols('u p w v W X Y Z H B C A al d c a b', real=True)
Dp=1+p*p; Dw=1+w*w; Du=1+u*u; Dv=1+v*v
J=w*W+X-p*w*Y-p*Z
core=2*(J**2+Dp*(Y-w*Z)**2+Dw*(p*X+Z)**2-Dp*Dw*Z*Z)
F=4*C*Dw*(W-p*Y)**2+4*A*Dp*Dw*Y*Y+4*d*J*J+4*al*Dp*(Y-w*Z)**2+core
P=s.sqrt(d)*p*Z; E=s.sqrt(B)*w*Z; SS=s.sqrt(C)*W; U=p*w*W
checks=[]
def ck(name,x):
    assert s.factor(s.expand(x))==0,(name,s.factor(x)); checks.append(name)
fg=4*Dw*(SS-p*H*s.sqrt(C/B)*E)**2+4*Dp/B*(A*H**2*Dw+al*(1-H)**2)*E**2+4*(1+H*w*w)**2*P**2+2*Dw*U**2-4*p*Dw/s.sqrt(B*C)*SS*E+2/B*((1-H)**2+H**2*p*p*Dw)*E**2
# Avoid independent square-root simplification choices: source B,C,d are positive.
assum={B:s.Symbol('BB',positive=True),C:s.Symbol('CC',positive=True),d:s.Symbol('dd',positive=True)}
ck('both-infinite exact graph',s.simplify((F.subs({X:-w*W,Y:H*w*Z})-fg).subs(assum)))
lx=-p*Dw*U+p*(1-H)*w*E/s.sqrt(B)-2*s.sqrt(d)*(1+H*w*w)*P
ck('both-infinite full X normal',s.diff(F,X).subs({X:-w*W,Y:H*w*Z})/4-lx)
ly=-2*p*s.sqrt(C)*Dw*SS+E/s.sqrt(B)*(2*C*p*p*H*Dw+2*Dp*(A*H*Dw-al*(1-H))+(2*d+1)*p*p*(1+H*w*w)-Dp*(1-H))
ck('both-infinite full Y normal',s.diff(F,Y).subs({X:-w*W,Y:H*w*Z})/4-ly)
ck('both-infinite X quadratic',s.diff(F,X,2)/2-(4*d+2+2*Dw*p*p))
ck('both-infinite Y quadratic',s.diff(F,Y,2)/2-(4*C*p*p*Dw+4*A*Dp*Dw+4*al*Dp+(4*d+2)*p*p*w*w+2*Dp))
ck('both-infinite mixed normal',s.diff(F,X,Y)+(8*d+4)*p*w)
ck('both-infinite PE normal determinant',4*(2+4*d)-16*d-8)
L=s.symbols('L',positive=True)
cs=(1+L)/(H+L)
subs={c:1/(2*L),a:(1+L)/(2*H),b:(H+L)/(2*(1-H))}
M=s.Matrix([[2+4*c*Dv,-2-4*c*Dv,-2*v],[-2-4*c*Dv,2*Dv+4*c*Dv+4*a*Dv+4*b*v*v,-4*b*v],[-2*v,-4*b*v,4*b]])
expect=[2*(L+Dv)/L,4*(L+1)*(Dv-H)*(L+Dv)/(H*L*(1-H)),8*(H+L)*(L+1)**2*Dv/(H*L*(1-H))]
for j in range(1,4): ck('strong finite axis minor '+str(j),M[:j,:j].det().subs(subs)-expect[j-1])
# Restricted forms at each opening, computed before taking the divergent cap.
vec=s.Matrix(s.symbols('UU YY ZZ')); form=(vec.T*M*vec)[0];UU,YY,ZZ=vec
for name,pol,vars,target in [
 ('H0',form.subs({YY:0,H:0,c:1/(2*L),b:L/2}),[UU,ZZ],4*(L+1)),
 ('H1',form.subs({ZZ:v*YY,c:1/(2*L),a:(1+L)/2}),[UU,YY],4*(L+1)**2*Dv/L),
 ('L0',form.subs({UU:YY,a:1/(2*H),b:H/(2*(1-H))}),[YY,ZZ],4/(1-H))]:
 ck('strong finite restricted '+name,s.hessian(pol,vars).det()/4-target)
M2=s.Matrix([[4*c,-4*c,-2],[-4*c,4*c+(4*a+4*b+2)*Du,-4*b*Du-2*u*u],[-2,-4*b*Du-2*u*u,4*b*Du+2*u*u]])
expect=[2/L,4*(1+L)*Du/(H*L*(1-H)),8*u*u*(1+L)**2*Du/(H*L*(1-H))]
for j in range(1,4): ck('strong open axis minor '+str(j),M2[:j,:j].det().subs(subs)-expect[j-1])
form=(vec.T*M2*vec)[0]
for name,pol,vars,target in [
 ('H0',form.subs({YY:0,c:1/(2*L),b:L/2}),[UU,ZZ],4*u*u*(1+1/L)),
 ('H1',form.subs({YY:ZZ,c:1/(2*L),a:(1+L)/2}),[UU,ZZ],4*u*u*(1+L)/L),
 ('L0',form.subs({UU:YY,a:1/(2*H),b:H/(2*(1-H))}),[YY,ZZ],4*u*u*Du/(H*(1-H)))]:
 ck('strong open restricted '+name,s.hessian(pol,vars).det()/4-target)
# Exact reciprocal-v core rewriting used by the strong open-axis proof.
UU,EE,PZ=s.symbols('UU EE PZ')
Jo=w*UU+u*X-w*Y-Z
Co=2*(Jo**2+Du*(Y-w*Z)**2+Dw*(X+u*Z)**2-Du*Dw*Z*Z)
Cnew=2*((w*UU+u*X-w*Y)**2+Du*(Y-EE)**2+Dw*X*X-EE*EE-2*UU*EE+2*Y*EE+2*u*w*X*EE)
ck('strong open exact core',Co-Cnew.subs(EE,w*Z))
result={'status':'PASS','count':len(checks),'checks':checks,'scope':'Exact remote-chart identities and residue positivity determinants; scope joins and source scale estimates are proved in accompanying text.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
