# Strong C2 double-infinitesimal progress, 18 October 2026

The exact double-infinitesimal source family is now admitted at **all
independent tests** by `rational_curve_tensor_sos.tex`. The proof applies a
new elementary rational-curve transfer lemma: clear the full parent's pure
source denominators, factor the resulting degree-six univariate polynomial
over the testing field, and evaluate its interval factors as separated
at most two tensor squares, using the two-square product identity.
This bound is independent of degree. Literal projective endpoints and complex states are
included. `check_curve_certificate.py/json` records 21 exact checks.

This is not a theorem for every strong actual-II source. Independent
non-real source shape parameters have not been placed on a real rational
curve, and the proof does not identify those fields or parameters.

Three accompanying exact results clarify the mechanism:

- `POLYNOMIAL_SOS_OBSTRUCTION.md` proves that this same original parent has
  no polynomial SOS over the source field. The complete degree restriction
  and one parity block with two zero diagonals give a five-check proof.
  Thus unrestricted pure-testing field elements are material.
- `HALFCORNER_CERTIFICATE.md` retains all four full-parent state normals in
  a five-root bounded Gram whenever the infinitesimal testing ratio `u/v`
  is bounded. Its strict final Schur pivot is `3/4`.
- `MULTIPLIER_GATE.md` gives an exact ten-root certificate for
  `(x+v²)F` at all infinitesimal test ratios, with residue determinant576.
  It does not cancel that mixed multiplier. The rational-curve theorem
  bypasses that cancellation for the exact source family.

The local Gram scripts retain their historically scoped status strings;
the all-tests theorem is the subsequent rational-curve proof. No delivered
package has been edited.
