#!/usr/bin/env python3
import json
from pathlib import Path
import sympy as s
B,h,a,t,r=s.symbols('B h a t r')
ca=1+a*B*r; S=1+B*(1-h+a*r)
g=1+a*(h*B+r-1); j=ca-(1-h)/t
dd=a+(1+a*B)+(1+a*B)*B+2*a*B*(1+a*B)*r+a**3*B**2*r*r+2*a*a*B*r+t*B*(1+a+a*B+a*a*B*r*(2-r))
M=(1+a*B)*(1+a*r)*(h+t)-a*(1+t*B)*(1-r)*(1-h)
n=((1+a*r)*ca*S-r*dd)/(2*r*dd)
m=a*a*(1+t*B)*(1-r)*ca*S/(2*g*dd)
C=ca*M/(2*(1-h)*dd); Ah=t*ca*(1+a*r)*S/(2*dd)
D=(1+a*B)*(1+a*r)*(1-a*t*B*r)*S/(2*t*j*dd)
alhat=(1+a*r)*M/(2*(1-h*B)*dd)
half=s.Rational(1,2); k=1/t; ell=1/a
a4=Ah*h; c4=n*r*r; d2=(n+half)*r*r+2*D*r; d4=(n+D+half)*r*r
b2=2*m*h+C*(1-h)**2+Ah*h+(B*B*alhat+half)*h*h
j0=(B*d4-a4*k*k*ell+d2*ell)/(2*k*ell*ell)
j1=d4/(2*k*ell)
fs=(b2-c4/ell**2-alhat-B*d4/(k*ell**2))/2
corner={B:0,h:0,r:1}
expected={'n':(n,0),'m':(m,0),'C':(C,t/2),'D':(D,1/(2*(t-1))),
 'alpha_over_B2':(alhat,t*(1+a)/2),'j0':(j0,a*t*(t+1)/(4*(t-1))),
 'j1':(j1,a*t*t/(4*(t-1))),'fs':(fs,-a*t/4)}
for name,(expr,target) in expected.items():
    assert s.cancel(expr.subs(corner)-target)==0,name
out={'status':'PASS','count':len(expected),'checks':{k:True for k in expected},'scope':'Exact poles in the proposed sqrt(1-r) rescaling of the fixed WA8 Gram; no obstruction to other full-parent frames is claimed.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
