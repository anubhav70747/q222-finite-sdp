"""Exact reparameterization; no positivity sampling or atlas use."""
from pathlib import Path
import json
import sympy as s

x,k,b,r,h=s.symbols('x k b r h', positive=True)
sig,B,eta=s.symbols('sigma B eta', positive=True)
a2=k*k/x
t=x*(b-h)/(k*k)
j=1+x*r-t
g=b-1+r+x*h
ac=1+x*r
sc=ac+a2*x*t
de=(1+x)*x*b*b+2*x*(1+x)*b*r+(1+x)*(1+a2*x)*b+x*x*(1-a2)*r*r+2*x*(1+a2*x)*r+1+a2*x
ns=(1+x)*(b+r)*(b+a2*(1-t))-a2*(1+a2*x)*(1-r)*t
old={
 'n':((b+r)*ac*sc-r*de)/(2*r*de),
 'm':(1+a2*x)*(1-r)*ac*sc/(2*g*de),
 'C':ac*ns/(2*a2*t*de),
 'A':a2*ac*(b+r)*sc/(2*h*de),
 'D':(1+x)*(b+r)*(b-a2*x*r)*sc/(2*a2*j*de),
 'alpha':x*x*(b+r)*ns/(2*(1-x*h)*de)}
sub={x:sig*B,b:1/sig,h:eta/sig}
hatde=s.cancel(sig*de.subs(sub, simultaneous=True))
hatns=s.cancel(sig*sig*B*ns.subs(sub, simultaneous=True))
hatg=1+sig*(r-1+B*eta)
ac1=1+sig*B*r
sc1=ac1+B*(1-eta)
j1=ac1-B*(1-eta)/(k*k)
new={
 'n':((1+sig*r)*ac1*sc1-r*hatde)/(2*r*hatde),
 'm':sig*sig*(1+k*k)*(1-r)*ac1*sc1/(2*hatg*hatde),
 'C':ac1*hatns/(2*B*(1-eta)*hatde),
 'A':k*k*ac1*(1+sig*r)*sc1/(2*B*eta*hatde),
 'D':B*(1+sig*B)*(1+sig*r)*(1-sig*k*k*r)*sc1/(2*k*k*j1*hatde),
 'alpha':B*(1+sig*r)*hatns/(2*(1-B*eta)*hatde)}
checks=[]
def eq(name,lhs,rhs):
    assert s.cancel(lhs-rhs)==0,name
    checks.append(name)
for name in old:
    eq('exact canceled '+name,old[name].subs(sub, simultaneous=True),new[name])
eq('Delta hat leading polynomial',hatde.subs(sig,0),B+1+k*k)
eq('N hat leading polynomial',hatns.subs(sig,0),k*k+B*eta)
eq('g hat exact',sig*g.subs(sub, simultaneous=True),hatg)
eq('j exact',j.subs(sub, simultaneous=True),j1)
for name,lhs,rhs in [
 ('C z',new['C']*B*(1-eta),k*k/(2*(1+k*k))),
 ('A y',new['A']*B*eta,k*k/(2*(1+k*k))),
 ('D/B',new['D']/B,1/(2*k*k*(1+k*k))),
 ('alpha/B',new['alpha']/B,k*k/(2*(1+k*k))),
 ('m/sigma^2',new['m']/(sig*sig),(1-r)/2),
 ('nr',new['n']*r,(1/(1+k*k)-r)/2)]:
    eq('small B residue '+name,s.cancel(lhs).subs({sig:0,B:0},simultaneous=True),rhs)
v=s.symbols('v')
q=2*k*k*(1+v*v)/(1+k*k)
e=2*(v*v/(k*k)+k*k)/(1+k*k)
eq('candidate scalar determinant',q*e-4*v*v,4*(v*v-k*k)**2/(1+k*k)**2)
result={'status':'PASS','count':len(checks),'checks':checks,
 'Delta_hat':str(s.expand(hatde)), 'N_hat':str(s.expand(hatns)),
 'scope':'Exact source reparameterization and candidate scalar determinant only; does not close the B-infinitesimal all-tests frontier.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
