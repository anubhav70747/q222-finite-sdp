from pathlib import Path
import sympy as s
import json,time
start=time.perf_counter()
base=Path(__file__).parent
old={};new={}
exec((base/'derive_witness_gram.py').read_text().split('regular=[]')[0],old)
exec((base/'derive_halfcorner_witness.py').read_text().split('ratio=s.symbols')[0],new)
k,u,v,W=old['k'],old['u'],old['v'],old['W'];x=k*k
GO,GN=old['Gram'],new['Gram']
AO,BN=GO.copy(),GN.copy();CC=s.zeros(5)
for GG,target,weight,indices in [(GO,AO,x,[(0,3),(3,4)]),(GN,BN,v*v,[(1,4),(3,4)])]:
 for i,j in indices:
  CC[i,j]+=s.cancel(weight*GG[i,j]/(2*k*v))
  CC[j,i]=CC[i,j]
  target[i,j]=target[j,i]=0
MM=AO.row_join(CC).col_join(CC.T.row_join(BN)).applyfunc(s.cancel)
for i in range(10):
 for j in range(i,10):
  den=s.denom(MM[i,j]);assert not den.has(u,v),(i,j,'testing denominator',s.factor(MM[i,j]))
  assert den.subs(k,0)!=0,(i,j,'source pole',s.factor(MM[i,j]))
R=MM.subs({k:0,u:0,v:0}).applyfunc(s.factor)
expected=s.diag(s.Matrix([[4,0,0,0,1],[0,4,0,0,0],[0,0,2,0,0],[0,0,0,1,0],[1,0,0,0,1]]),s.Matrix([[4,0,0,0,1],[0,4,0,0,0],[0,0,2,0,0],[0,0,0,1,0],[1,0,0,0,1]]))
assert R==expected
hard=old['hard'];Q=v*(u*u-x)*W;z=s.Matrix([*hard,Q]);zz=(k*z).col_join(v*z)
LO=old['LW']*W+sum(a*b for a,b in zip(old['Li'],hard))
LN=new['LW']*W+sum(a*b for a,b in zip(new['Li'],hard))
identity=s.cancel((x+v*v)*old['F']+old['G']*(x*LO+v*v*LN)-(zz.T*MM*zz)[0])
assert identity==0
out={'status':'PASS: MULTIPLIED LOCAL PARENT ONLY','multiplier':'x+v^2','exact_full_parent_identity':True,'all_55_gram_entries_have_pure_source_unit_denominators':True,'strict_residue':'diag(M0,M0), M0 Schur pivot 3/4','residue_determinant':str(R.det()),'all_infinitesimal_testing_angle_ratios':True,'does_not_cancel_mixed_multiplier':True,'seconds':round(time.perf_counter()-start,2)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
(base/'multiplier_witness_cross_block.txt').write_text(str(CC.applyfunc(s.factor))+'\n')
print(json.dumps(out,indent=2))
