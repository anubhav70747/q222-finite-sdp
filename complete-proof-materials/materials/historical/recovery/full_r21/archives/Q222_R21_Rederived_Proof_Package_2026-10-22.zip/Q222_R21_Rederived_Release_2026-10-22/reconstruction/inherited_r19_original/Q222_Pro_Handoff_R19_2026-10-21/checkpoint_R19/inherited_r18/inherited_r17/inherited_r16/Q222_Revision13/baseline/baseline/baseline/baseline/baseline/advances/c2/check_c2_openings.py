#!/usr/bin/env python3
"""Exact identities for the three-opening C2 extension, without samples.

The all-tests argument and boundedness hypotheses are in the companion TeX.
These checks validate its new algebra, not global source coverage.
"""
from pathlib import Path
import json
import sympy as s
checks=[]
def eq(name,lhs,rhs=0):
    assert s.factor(lhs-rhs)==0,name
    checks.append(name)
def no_pole(name,expr,variables):
    den=s.denom(s.cancel(expr))
    for var in variables:
        assert s.rem(den,var,var)!=0,(name,var,den)
    checks.append(name)

x,k,b,r,h=s.symbols('x k b r h')
a2=k*k/x;t=x*(b-h)/(k*k)
g=b-1+r+x*h;j=1+x*r-t;Ac=1+x*r;Sc=Ac+a2*x*t
Delta=(1+x)*x*b*b+2*x*(1+x)*b*r+(1+x)*(1+a2*x)*b
Delta+=x*x*(1-a2)*r*r+2*x*(1+a2*x)*r+1+a2*x
Num=(1+x)*(b+r)*(b+a2*(1-t))-a2*(1+a2*x)*(1-r)*t
n=((b+r)*Ac*Sc-r*Delta)/(2*r*Delta)
m=(1+a2*x)*(1-r)*Ac*Sc/(2*g*Delta)
C=Ac*Num/(2*a2*t*Delta)
A=a2*Ac*(b+r)*Sc/(2*h*Delta)
D=(1+x)*(b+r)*(b-a2*x*r)*Sc/(2*a2*j*Delta)
alpha=x*x*(b+r)*Num/(2*(1-x*h)*Delta)
delta0=(1+k*k)*(b+1);T0=k*k*(b+r)/(2*delta0)
TC=s.cancel(x*C*(b-h));TA=s.cancel(x*A*h)
eq('opposite-event exact bounded product',(4*n+2)*r,2*(b+r)*Ac*Sc/Delta)
eq('C opening residue',TC.subs(x,0),T0)
eq('A opening residue',TA.subs(x,0),T0)
for label,z in [('TC',TC),('TA',TA)]:
    den=s.factor(s.denom(z))
    assert den.subs({x:0,h:0})!=0
    assert den.subs({x:0,h:b})!=0
    assert den.subs({x:0,r:0})!=0
    checks.append(label+' denominator at all three openings')
bound=b/(b+k*k*(b+1))
eq('physicality forces D opening',b-k*k*bound,b*b*(1+k*k)/(b+k*k*(b+1)))
eta=h/b
eq('C linear bounded product',x*C*(1-eta),TC/b)
eq('A linear bounded product',x*A*eta,TA/b)
eq('C quadratic bounded product',x*C*(1-eta)**2,TC*(b-h)/b**2)
eq('A quadratic bounded product',x*A*eta**2,TA*h/b**2)
eq('harmonic residue',4*T0*(b-h)/b**2+4*T0*h/b**2,4*T0/b)

# Exact original parent with symbolic bounded numerators.
u,v,W,X,Y,Z=s.symbols('u v W X Y Z')
nn,mm,CC,AA,DD,ee=s.symbols('nn mm CC AA DD ee')
du=1+u*u;dv=1+v*v
M=v*W-X+u*v*Y-u*Z;J=u*W+u*v*X-Y-v*Z
core=J*J+du*(v*Y-Z)**2+dv*(X+u*Z)**2-du*dv*Z*Z
F=4*nn*du*dv*X*X+4*mm*M*M+4*CC*dv*(u*W-Y)**2
F+=4*AA*du*dv*Y*Y+4*DD*J*J+4*ee*du*(v*Y-Z)**2+2*core
tc,ta,nr,cm,cD,ca=s.symbols('tc ta nr cm cD ca')
weights={nn:nr/r,mm:cm,CC:tc/(x*(b-h)),AA:ta/(x*h),DD:x*cD,ee:x*ca}
graph={X:-r*u*Z,Y:h*u*W/b}
Fg=s.expand(F.subs(weights).subs(graph,simultaneous=True))
Fx=s.expand(s.diff(F,X).subs(weights).subs(graph,simultaneous=True))
Fy=s.expand(s.diff(F,Y).subs(weights).subs(graph,simultaneous=True))
fww=Fg.coeff(W,2);fzz=Fg.coeff(Z,2);fwz=Fg.coeff(W).coeff(Z)
coeffs=[x*(fww-fww.subs(u,0))/u**2,
        (fzz-fzz.subs(u,0))/u**2,fww.subs(u,0)/v**2,
        fzz.subs(u,0)/x,fwz/(u*v)]
expected=[4*dv*tc/b,4*cm+2,4*cm,4*cD*v*v+4*ca,-8*cm-4]
lead={r:0,x:0,u:0,ta:tc}
for label,E,target in zip(('q','b','cbar','e','g'),coeffs,expected):
    E=s.cancel(E)
    # This is the complete graph scalar; no r or h denominator remains.
    assert s.denom(E).subs({r:0,h:0})!=0
    assert s.denom(E).subs({r:0,h:b})!=0
    checks.append('bounded scalar coquotient '+label)
    eq('unbounded n leading scalar '+label,E.subs(lead,simultaneous=True),target)
for label,E in [('FX/V',Fx.coeff(W)/v),('FX/B',Fx.coeff(Z)/u)]:
    E=s.cancel(E)
    assert s.denom(E).subs({r:0,h:0,x:0})!=0
    assert s.denom(E).subs({r:0,h:b,x:0})!=0
    checks.append('bounded entire first normal '+label)
B2=8*dv*(ta*du-tc)/b
Fyr=s.expand(Fy-u*W*B2/x)
ew=s.cancel(Fyr.coeff(W)/u)
ez=s.cancel((Fyr.coeff(Z)-8*v*x*(cD-ca))/(u*u))
eq('entire Y constant normal',Fyr.coeff(Z).subs(u,0),8*v*x*(cD-ca))
for label,E in [('ew',ew),('ez',ez)]:
    assert s.denom(E).subs({r:0,h:0,x:0,u:0})!=0
    assert s.denom(E).subs({r:0,h:b,x:0,u:0})!=0
    checks.append('bounded entire Y normal '+label)
eq('Y scaled leading correction',(B2+x*ew).subs(lead,simultaneous=True))
Hxx=s.diff(F,X,2)/2
eq('X exact hard pivot',Hxx,(4*nn+2)*du*dv+4*mm-2*u*u*dv+(4*DD+2)*u*u*v*v)
eq('Y exact hard packets',(CC+AA*du)/(CC+AA),1+AA*u*u/(CC+AA))

# New determinant and contact when r has zero residue.
mu,Q,E0,E2,z,S=s.symbols('mu Q E0 E2 z S')
q=Q*(1+z);bs=2*mu;cs=2*(mu-1)*z;d2=16*mu*mu*z;e=E2*z+E0
det=(q*S+cs)*(bs*S+e)-d2*S/4
L=2*Q*mu*S/z+2*Q*mu*S+2*(mu-1)*E2*z/S+2*(mu-1)*E0/S
L+=Q*E0/z+Q*E2*z+Q*(E0+E2)-4*mu
eq('new six-term Laurent identity',det/(S*z),L)
sources={mu:1+1/((b-1)*(b+1)),Q:2*k*k/delta0,
         E0:2*k*k*b*b/delta0,E2:2*b*b/(k*k*delta0)}
for label,E in [('value',L),('s derivative',s.diff(L,S)),('z derivative',s.diff(L,z))]:
    eq('new Laurent stationary contact '+label,E.subs({S:1,z:k*k}).subs(sources,simultaneous=True))

payload={'result':'PASS','number_of_checks':len(checks),'checks':checks,
 'scope':'Exact new identities and whole-normal bounded coquotients for c2_openings_and_unbounded_n.tex; no global source cover or numerical sampling.',
 'analytical_inputs':['prior full-normal conductor lemma','balanced Laurent AM-GM identity','strict bounded tensor Gram lemma','inherited noncommuting-residue theorem']}
target=Path(__file__).with_name('c2_openings_checks.json')
target.write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps({'result':'PASS','number_of_checks':len(checks),'output':str(target)}))
