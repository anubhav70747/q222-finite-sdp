"""Focused check of the actual paired-event reduction and n conductor."""
import sympy as s,json
from pathlib import Path
u,v,W,X,Y,Z,p,H,m,C,A,D,al,n,ga=s.symbols('u v W X Y Z p H m C A D al n ga')
Du=1+u*u;Dv=1+v*v;half=s.Rational(1,2)
ww=(W+u*Y)/Du;At=v*ww;qa=Du*At;qb=v*(Z-u*X)
N=X+u*Z-p*qa;MB=u*W-Y-H*qb;J=u*W+u*v*X-Y-v*Z;M=v*W-X+u*v*Y-u*Z
parent=n*Du*Dv*X*X+m*M*M+C*Dv*(u*W-Y)**2+A*Du*Dv*Y*Y+(D+half)*J*J+(al+half)*Du*(v*Y-Z)**2+half*Dv*(X+u*Z)**2-half*Du*Dv*Z*Z
pack=m*p*N*N+half*(1-p)*Dv*N*N+C*(1-H)*Dv*MB*MB+(D+half)*H*MB*MB+n*Du*Dv*(X+ga*At)**2
rem=(m*(1-p)*(N*N-2*qa*N+(1-p)*qa*qa)+half*p*Dv*(N*N+2*qa*N+p*qa*qa)
     +C*H*Dv*(MB*MB+2*qb*MB+H*qb*qb)+(D+half)*(1-H)*(MB*MB-2*qb*MB+(1-H)*qb*qb)
     +A*Du*Dv*Y*Y+al*Du*(v*Y-Z)**2+half*Du*((v*Y-Z)**2-Dv*Z*Z)
     +2*n*ga*Du*Dv*u*At*Z-(2*n*ga*p*Du+n*ga*ga)*Du*Dv*At*At-2*n*ga*Du*Dv*At*N)
out={}
def ck(name,z):
 assert s.cancel(z)==0,name
 out[name]=True
ck('entire_actual_paired_parent_with_full_n_row',parent-pack-rem)
Kc,x,e,r,nh=s.symbols('Kc x e r nh')
conduct=(At-Kc*u*Z)-((Kc/nh)*(nh*(X+r*At/Kc))-Kc*N-p*Kc*(u*u-x)*At)
ck('new_retained_n_row_contact_conductor',conduct.subs(r,1-p*(1+x)*Kc))
ss,w,R,K,rho=s.symbols('ss w R K rho',positive=True)
ck('n_gamma_squared_is_opening_free',((ss*w)**2*rho)*(r*K/(ss*R))**2-rho*w*w*r*r*K*K/(R*R))
ck('n_conductor_unit_coefficient',(ss*R/K)/(ss*w*s.sqrt(rho))-R/(K*w*s.sqrt(rho)))
# Leading At² coefficient from the paired m/B remainder and retained n row.
B2,pp=s.symbols('B2 pp')
ck('leading_At_mass_after_n_extraction',(B2*(1-pp)+pp*pp/2-rho).subs({B2:half,pp:1})-(half-rho))
h,t,b=s.symbols('h t b')
ck('physical_residue_mass_identity',(half-rho).subs(rho,(1-b*(h+t))/2)-b*(h+t)/2)
payload={'status':'PASS','count':len(out),'checks':out,'scope':'Exact full-parent reduction and retained-n conductor only; no nonthin R6 positivity/admission claimed.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps(payload,indent=2))
