"""Focused source receipts for extending R16's Z-state closure to large zeta.
No historical suite is executed. Source gaps are never evaluated at zero before
clearing their prescribed factors. Bounds remain ordered-field arguments.
"""
import sympy as s, json
from pathlib import Path
a,L,t,pi,ss=s.symbols('a L eta pi sigma')
x=a*L; r=1-t*ss; h=1-L*pi; th=L*pi
K=1+x;R=1+x*r;T=1+x*h;M=R-a*th;j=t*T-1+r
y=t*L;E=1-x*t*h;Q=1-L*r
Pd=1+2*x*h+r*x*x*h+r*x*L+L+t*(K*L+x*x*h*th)
P4=T*E+(1-r)*(x*h+L)
Pa=R*h*(1+y)+(M/a)*E
# Opening-cleared exact coefficients, using Bx=beta+1/2.
Cc=K*(r+t)*E/(2*Pd) # C*(1-r)
Aa=t*P4/(2*Pd) # A*r
Dpj=K*(1+y)*(r+t)/(2*Pd) # (D+1/2)*j
m=K*a*a*L*(r+t)*h*(1+y)/(2*M*Pd)
al=L*L*(r+t)*(a*R*h*(1+y)+M*E)/(2*Q*Pd)
Bth=K*(r+t)*L*(1+a*h)/(2*Pd)
A=Aa/r; B=Bth/th; q=al+m*th*th+Bth*th;mu=m-a*a*q
T0=A+al+s.Rational(1,2);Tm=T0+m;e4=r*r*Tm/(t*t)
b=A*r/t-m*th-al-s.Rational(1,2)
bp=b+e4*y*t/(2*r)
kappat=2*(t*Bth-Dpj-m*r)
gamma=2*bp/h+2*Dpj/r-2*t*Bth/r
def finite_ratio(expr):
 num,den=s.fraction(s.together(expr))
 num=s.expand(num);den=s.expand(den)
 for var in (a,L,t):
  pd=s.Poly(den,var); k=min(mon[0] for mon,co in pd.terms())
  if k:
   pn=s.Poly(num,var)
   quotient,remainder=s.div(pn,s.Poly(var**k,var))
   assert remainder.is_zero,('uncanceled monomial',var,k)
   num=quotient.as_expr(); den=s.Poly(den,var).exquo(s.Poly(var**k,var)).as_expr()
 return num,den

checks={};reports={}
def ck(name,expr):
 value=s.cancel(expr)
 assert value==0,(name,s.factor(value))
 checks[name]=True

def audit(name,expr,target,vanish_L=False):
 num,den=finite_ratio(expr)
 val=num/den
 # Every denominator here must be a unit even at all retained pi,sigma openings.
 d0=s.factor(den.subs({L:0,t:0,a:0}))
 assert d0!=0,(name,'nonunit denominator',d0)
 res=s.factor(val.subs({L:0,t:0,a:0}))
 ck(name+'_residue',res-target)
 if vanish_L:
  rem=s.Poly(num,L).rem(s.Poly(L,L)).as_expr()
  assert rem==0,(name,'not divisible by L',s.factor(rem))
  checks[name+'_L_divisibility']=True
 print('PASS',name,flush=True)
 reports[name]={'residue':str(res),'denominator_at_a_L_eta_zero':str(d0)}

audit('C_cleared',Cc,s.Rational(1,2))
audit('A_cleared',Aa/t,s.Rational(1,2))
audit('Dplus_cleared',Dpj,s.Rational(1,2))
audit('m_a2L',m/(a*a*L),s.Rational(1,2))
audit('alpha_L2',al/(L*L),s.Rational(1,2))
audit('Btheta_L',Bth/L,s.Rational(1,2))
audit('q_L2',q/(L*L),(1+pi)/2)
audit('mu_a2L',mu/(a*a*L),s.Rational(1,2))
audit('bprime',bp,0,vanish_L=True)
audit('bprime_L',bp/L,-s.Rational(1,4))
audit('eta_kappa',kappat,-1)
audit('gamma',gamma,1)
audit('eta2_e4',t*t*e4,s.Rational(1,2))
# Exact source-only bound for the angular cross, normalized by a.
# Its square divided by a^2 equals (mu/(a^2 L))^2 / ((q/L^2)*B).
ck('angular_cross_bound_identity',mu*mu/(a*a*q*B)/(a*a)-(mu/(a*a*L))**2/((q/(L*L))*B))
# Exact source-only bound for the radial-angular normal after factoring u.
ck('radial_angular_coefficient_bound', (e4*y*t)**2/q-((t*t*e4)**2)/ (q/(L*L)))
# New homogeneous W-chart simplifications, used only to state the remaining lemma.
u,v,W,X,Y,Z,eta0,r0,h0,x0,L0=s.symbols('u v W X Y Z eta0 r0 h0 x0 L0',nonzero=True)
Et=eta0*u*W-v*Z;Qt=Y-r0*v*Z/eta0;xi=X+h0*u*Z
TD=v*(u*u-x0)*Z-u*v*xi/h0
Fb=(v*v-eta0*L0)*Z+v*Et
Ft=(v*v-eta0*L0)*Z+(eta0/r0)*v*Qt
ck('full_D_shift_W_chart',TD+v*(x0*Z+u*X/h0))
ck('full_B_radial_W_chart',Fb/eta0-(u*v*W-L0*Z))
ck('full_Y_radial_W_chart',Ft/eta0-(v*Y/r0-L0*Z))
output={'status':'PASS','count':len(checks),'checks':checks,'reports':reports,
'scope':'New source arrays for the full-parent C14.3a eta-infinitesimal, zeta-unbounded, bounded-W/Z,X/Z local-state closure. No whole-source admission; actual positive j and literal beta=0 retained.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
