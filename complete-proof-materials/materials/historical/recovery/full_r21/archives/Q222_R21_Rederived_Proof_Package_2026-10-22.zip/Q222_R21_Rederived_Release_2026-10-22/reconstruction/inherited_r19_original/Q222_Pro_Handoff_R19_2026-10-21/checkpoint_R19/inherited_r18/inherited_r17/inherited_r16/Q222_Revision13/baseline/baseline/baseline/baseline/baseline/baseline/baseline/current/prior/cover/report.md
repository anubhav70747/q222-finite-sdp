# Physicality forces hard directions on the remaining weak faces

Three exact coefficient-field experiments sharpen the six-template source graph. Their proofs use the full physical parent and work with arbitrary coefficient scales. No actual-contact parametrization or boundedness after d=1 is assumed.

The principal C2 inequality is

\[
6A(d+6m)(d+6D)\ge d^3.
\]
Thus the C2 **A-weak** template can be oriented so that **D/d is unbounded**. It then splits into two precise scale cases:

- If m/d is bounded, physicality supplies the bounded reciprocal d²/(AD).
- If m/d is unbounded, physicality supplies the bounded reciprocal d³/(AmD), with residue at most 216.

The experiment is especially short: in the infinity-zero homogeneous chart, set `(W,X,Y,Z)=(p,0,1,v)`. The n,c,α packets vanish, the signed core is −2dp²v², and only the A,m,D packets remain in C2. Physicality holds for every positive p,v, yielding the displayed inequality at p²=d/(6m), v²=d/(6D).

For C1, write L=d+A+D and L′=d+α+β. Two reflected exact curves give

\[
320mL^2+32cdL\ge d^3,\qquad
320c(L')^2+32mdL'\ge d^3.
\]
If **m and c are both weak relative to d**, there must therefore be a hard event in **each** of `{A,D}` and `{α,β}`. These are two separately forced directions, not just a statement that some coefficient is large. The inequalities also specify what each hard scale must fund: at least one of `mL²/d³, cL/d²` has bounded reciprocal, and similarly for the reflected pair.

A third consequence, valid for every physical source with λ=0, is

\[
256A(d+m+D)^2+32\beta d(d+m+D)\ge d^3.
\]
In C1, weak A and β force m or D to be hard; by the exact stabilizer, weak α and D force c or β to be hard.

These restrictions extend the positive-d forbidden-face observations to genuinely unbounded relative scales. They are homogeneous degree-three inequalities, so they apply unchanged to bounded source normalizations whose d is infinitesimal. The required measurement/state experiments lie entirely in the coefficient field; no independent testing rate enters the proof.

`relative_forbidden_faces.tex` contains the human proof and all exact curve identities. `check_compressions.py` independently checks the homogeneous packet/core identities and rational interval constants with standard-library exact arithmetic; all 17 checks pass. It does not replay the archived atlas.

This is a necessary-source reduction, not an all-tests certificate for the residual families. In particular, the inequalities do not force the five-strong exit: they exhibit the hard coefficients that compensate missing weak directions and provide explicit pair/triple products or finite funding alternatives for the next local argument. The existing physical ordinary-angle radial C2 path with both c and α weak already demonstrates that physical actual contacts need not satisfy the consecutive-five criterion.
