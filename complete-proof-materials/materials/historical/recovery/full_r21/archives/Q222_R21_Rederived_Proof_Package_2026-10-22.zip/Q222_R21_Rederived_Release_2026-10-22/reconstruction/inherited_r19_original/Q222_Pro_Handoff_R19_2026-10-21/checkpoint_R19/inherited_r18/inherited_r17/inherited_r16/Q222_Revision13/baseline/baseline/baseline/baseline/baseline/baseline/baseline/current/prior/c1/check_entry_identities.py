"""Small exact C1 entry identities; no full-source or Groebner expansion."""
if not __debug__:raise SystemExit('Run without -O: assertions are proof checks.')
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path(__file__).resolve().parent.parent/'prior_core'/'c1'))
from source_from_formulas import variables,native_coquotients
start=time.perf_counter();checks=[]
def eq(name,p,q):
 assert not (p-q).terms,name
 checks.append(name)
k,f,g,a,t=variables(5)
kap=k*k;eta=f*f;zet=g*g;K=1+kap;r=1-a*eta;q=kap*eta
R=K-a*kap*eta;T=K-kap*zet*t;J=T-a
V=q*zet;Hc=r+eta;Qc=1-kap*zet*r;E=1-q*(1-t*zet)
Pd=K*K-a*eta*kap*kap+zet*kap*(K-(kap+2)*t)+V*(-zet*kap*t*t+kap*a*(t-1)+kap*t+K)
P4=K+eta*kap*(a-K)-zet*kap*t+V*(-zet*kap*t*t+2*kap*t+a*(1-t)+t)
Pa=K-a*eta*kap+zet*(K-(kap+2)*t)+V*(-zet*t*t+a*(t-1)+t)
H=2+kap*r+zet*(K-(kap+2)*t)+q*zet*(-zet*t*t+t+1)+kap*zet*(1-r)*(t-1)
Pds=1+q*zet+kap*H
B5=K*(1+q*zet)*Hc-J*eta*Pd
B5s=K*r*(1+q*zet)+(1-r)*Pd+q*(zet*t*(1+q*zet)-(K-kap*zet*t)*H)
P4s=K*(1-q)+kap*(1-r)-kap*zet*t+q*zet*(-kap*zet*t*t+2*kap*t+t)+kap*zet*(1-r)*(1-t)
Pas=1+kap*r+zet*(K-(kap+2)*t)+q*zet*(-zet*t*t+t)+kap*zet*(1-r)*(t-1)
eq('bounded P_d polynomial',Pd,Pds)
eq('bounded fifth-event sign polynomial',B5,B5s)
eq('bounded P_4 polynomial',P4,P4s)
eq('bounded P_alpha polynomial',Pa,Pas)
c=native_coquotients()
eq('fourth-event ratio after cancellation',2*r*Pd*c['C4'],P4*c['Cd'])
eq('fifth-event numerator after cancellation',2*c['C5']-J*eta*c['Cd'],4*r*Qc*B5)
eq('signed/coercive ratio after cancellation',a*eta*c['Cd']*K*Hc*E,2*(1-r)*Pd*c['C3'])
eq('alpha ratio after cancellation',2*Qc*Pd*c['Ca'],Hc*Pa*c['Cd'])
# Check the decisive residues as polynomial substitutions with independent q,r.
x,q0,r0,z0,t0=variables(5);K0=1+x
HH=2+x*r0+z0*(K0-(x+2)*t0)+q0*z0*(-z0*t0*t0+t0+1)+x*z0*(1-r0)*(t0-1)
PP=1+q0*z0+x*HH
BB=K0*r0*(1+q0*z0)+(1-r0)*PP+q0*(z0*t0*(1+q0*z0)-(K0-x*z0*t0)*HH)
P4b=K0*(1-q0)+x*(1-r0)-x*z0*t0+q0*z0*(-x*z0*t0*t0+2*x*t0+t0)+x*z0*(1-r0)*(1-t0)
def zero_xz(p):return p.__class__({m:c for m,c in p.terms.items()if m[0]==m[3]==0},5)
eq('fifth-event residue 1-2q',zero_xz(BB),1-2*q0)
eq('P_4 residue 1-q',zero_xz(P4b),1-q0)
eq('P_d residue 1',zero_xz(PP),1+0*x)
out={'status':'PASS','checks':checks,'seconds':time.perf_counter()-start,
 'scope':'exact source-entry polynomial identities; all-tests implication uses completed uniform C1 theorem and canonical source sign/sufficiency prerequisites'}
Path(__file__).with_name('entry_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
