import argparse,hashlib,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--algebra',action='store_true');a=p.parse_args();r=Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST.json').read_text())
for rel,h in m.items():
 assert hashlib.sha256((r/rel).read_bytes()).hexdigest()==h,rel
print('PASS: all',len(m),'manifest hashes')
if a.algebra:
 for f in sorted((r/'proofs').glob('*/check_*.py')):
  subprocess.run([sys.executable,str(f)],cwd=r,check=True)
 print('PASS: four new algebra checkers; inherited suite not run')
