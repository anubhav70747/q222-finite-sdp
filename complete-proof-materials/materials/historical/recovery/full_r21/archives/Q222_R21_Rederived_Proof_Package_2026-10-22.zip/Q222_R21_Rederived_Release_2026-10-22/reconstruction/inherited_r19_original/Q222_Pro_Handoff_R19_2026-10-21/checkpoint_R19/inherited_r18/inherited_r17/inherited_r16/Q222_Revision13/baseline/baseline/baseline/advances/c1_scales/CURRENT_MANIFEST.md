# C1 scale completion — current proof files

The reviewed C1.2 extension is `centered_a_bounded_delta.tex`, with
`scaled_centered_source.py`, `check_scaled_centered_contact.py`,
`scaled_centered_lift_checks.json`, and `REVIEW_BOUNDED_DELTA.md`.
It imports the frozen centered-A source and outer lemmas from oct18b_c1.
The source reconstruction's only potentially inverted Laurent unit is E;
delta is positive bounded and is never inverted.

The C1.3 all-tests theorem is `small_e_all_tests.tex`, supported by:

- `small_e_all_r_contact.tex`;
- `check_small_e_all_r_contact.py`;
- `small_e_all_r_contact_checks.json`;
- `small_e_all_r_conductor_tail_check.json`;
- `outer_small_e/outer_small_e.tex`;
- `outer_small_e/check_outer_small_e.py`;
- `outer_small_e/outer_small_e_checks.json`.

The exact standalone small-e checker uses SymPy. Run its default mode for
the weight-ten complete scalar/first-normal collection, and `--tail-check`
for the weight-fourteen regression that reaches the repaired v-conductor
allocation. The full rational-tail proof is in SE5–SE8, not inferred solely
from either finite run. The outer checker separately tests the independent
state/projective join and source deficit coquotients.

Files with `probe_` names and `small_e_centered_source.py` are exploratory
checkpoints, not proof-package dependencies. They should not be used as a
replacement for the all-r checker or the full rational-tail manuscript.
No authoritative prior package was changed.

Final exact receipts: bounded-delta 40; small-e contact 33; its
weight-fourteen conductor regression 33; small-e independent outer/state
join 50. The outer join now includes SEO20, the exact full critical-matrix
determinant and strict bounded hard restrictions, so its finite-angle
coverage does not depend on a separate noncommuting-residue admission.

Final separate-agent all-tests audit: `../source/SMALL_E_REVIEW.md`.
The reviewer freshly replayed contact PASS33 and outer PASS50 and approved
the full small-e theorem at exactly the printed source/test scope.
