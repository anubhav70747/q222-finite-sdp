"""Exact pure-testing Schur identity and original-parent sign gauges."""
from pathlib import Path
import json
import sympy as s
u,v,W,X,Y,Z=s.symbols('u v W X Y Z',real=True)
Du=1+u*u;Dv=1+v*v
Q=((u*W+u*v*X-Y-v*Z)**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)/2
M=s.hessian(Q,[X,Y,W,Z])/2
b=1+v*v+u*u*v*v;delta=b*b-u*u*v*v
H=s.Matrix([[b,-u*v],[-u*v,b]])/2
S=Du*Dv/(2*delta)*s.Matrix([[u*u*v*v,-u*v*b],[-u*v*b,u*u*v*v]])
checks={}
def check(name,expressions):
    assert all(s.cancel(e)==0 for e in expressions),name
    checks[name]=True
check('hard_matrix',list(M[:2,:2]-H))
check('schur_complement',list(M[2:,2:]-M[:2,2:].T*H.inv()*M[:2,2:]-S))
lam,n,m,C,A,D,alpha,beta,d=s.symbols('lam n m C A D alpha beta d')
F=lam*Du*(W+v*X)**2+n*Du*Dv*X**2+m*(v*W-X+u*v*Y-u*Z)**2+C*Dv*(u*W-Y)**2+A*Du*Dv*Y**2+D*(u*W+u*v*X-Y-v*Z)**2+alpha*Du*(v*Y-Z)**2+beta*Dv*(X+u*Z)**2+d*Q
check('full_parent_u_sign',[F-F.subs({u:-u,Y:-Y,Z:-Z},simultaneous=True)])
check('full_parent_v_sign',[F-F.subs({v:-v,X:-X,Z:-Z},simultaneous=True)])
Path(__file__).with_suffix('.json').write_text(json.dumps({'status':'PASS','count':len(checks),'checks':checks,'scope':'Pure-testing sign exit; no source admission.'},indent=2)+'\n')
print(f'PASS: {len(checks)} exact identities')
