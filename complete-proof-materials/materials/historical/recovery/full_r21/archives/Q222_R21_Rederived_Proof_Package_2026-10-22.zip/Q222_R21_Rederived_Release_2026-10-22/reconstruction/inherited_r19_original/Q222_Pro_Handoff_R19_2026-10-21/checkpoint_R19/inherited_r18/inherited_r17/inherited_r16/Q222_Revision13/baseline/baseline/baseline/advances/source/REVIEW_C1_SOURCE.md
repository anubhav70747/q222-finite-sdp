# Review of native C1 source reductions

Result: PASS for the uniform E gap and the actual-unit/unit all-tests
consequence in `source_reductions.tex`.

The positive identities NC2 match the original P4, P_alpha, P_d polynomials.
The six relative-weight identities NC4 were checked directly by cancelling
the original seven native coquotients and using a eta=1-r, t zeta=theta,
and e^2=x eta/zeta. This retains the original D and beta, including zero.

The global cap is elementary: NC6 and B5>=0 give Ccal<=Bcal E;
the six non-zeta terms and the zeta coefficient in Bcal are each bounded
by six; theta=t zeta<2 zeta gives 1+zeta<3(h+zeta). Since
Ccal>=h+zeta>0, E>=1/18 follows. No opening is inverted.

For actual unit/unit angles, eta zeta is a positive bounded unit.
The two exact sign inequalities E,Q>0 exclude either eta or zeta
unbounded; hence both are units. Nonnegative beta excludes h infinitesimal
by the stated theta=1 specialization. The first four ratios in NC4 then
have bounded positive reciprocals. All coefficients in NC7 are bounded,
whereas its right side is a positive unit. Thus D/d and beta/d cannot
both be infinitesimal. This argument also permits one literal zero.

The inherited `five_retained_events.tex` has exactly the quoted cycle,
allows arbitrary upper weights, and proves the full parent for every
independent projective measurement and real or complex state. The two
five-event lists in the new proof are consecutive in that cycle.

The source theorem closes only the actual-(U,U) portion of C1.5. It
does not close C1.1, C1.4, or all of C1.5. The E cap applies more broadly
but is not itself an all-tests certificate. No global coverage claim follows.

Review provenance: supervising-agent mathematical review and exact
corroboration within the same system; not external peer review or formal
verification. A missing TeX backslash was reported for correction.
