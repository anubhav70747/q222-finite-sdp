#!/usr/bin/env python3
"""Exact adapter: C1 L unit, eta infinitesimal, to the full strong-II Gram."""
import json
from pathlib import Path
import sympy as s
checks={}
def ck(name,expr):
    val=s.factor(s.cancel(s.together(expr)))
    if val != 0: raise AssertionError((name,val))
    checks[name]=True

u,v,W,xi,ze,N,Rh,R,T1=s.symbols('u v W xi ze N Rh R T1')
U,V,z,k,B,t,r=s.symbols('U V z k B t r')
c,d,g,q,mu,ar,sigma,tau,ec,alc=s.symbols('c d g q mu a_ratio sigma tau ell_cap alpha_cap')
y=k*k; H=B-y*t; ac=1+z*r; j=ac-t; sc=ac/B
K=u*k*W; Qn=u*xi-ze
rh_actual=v*Qn/k-sc*u*(v*v-y)*W/k
ell=c/t+d/j; qq=d*t/(c*j+d*t); gg=c*d/(c*j+d*t)
eta=k*(N+q*Rh)
X=-z*r*v/B*W+xi; Y=H*u/B*W+eta; Z=u*v/B*W+ze
du=1+u*u; dv=1+v*v
M=v*W-X+u*v*Y-u*Z; J=u*W+u*v*X-Y-v*Z
p=v*Y-Z; bb=X+u*Z
core=2*(J*J+du*p*p+dv*bb*bb-du*dv*Z*Z)
base=(4*ec*N*N+4*g*Rh*Rh+8*(d-c)/B*K*N-8*g*sc*K*Rh
      +4*(c*t+d*j)/B**2*K*K+4*c*t/B**2*v*v*K*K
      -8*c/B*v*v*K*(N+q*Rh)
      +4*alc*du*(v*eta-ze)**2
      +4*sigma*du*((1-H)*u*u*v*v/B**2*W*W-2*u*v/B*W*(v*eta-ze))
      +4*z*z*mu*M*M+4*y*ar*du*dv*Y*Y+core)
beta_rem=8*tau*z/B*dv*v*W*(xi+u*ze)+4*tau*z/B**2*dv*v*v*(2*u*u-z*(1+r))*W*W
Ebeta=xi+u*ze+v*(u*u-z)*W/B
beta=tau/(1-r)
ck('exact_centered_beta_remainder',4*beta*dv*bb*bb-4*beta*dv*Ebeta*Ebeta-beta_rem)
G=s.expand(base+beta_rem)

# All original state coordinates and every retained normal are reconstructed.
Cw=c/(y*t); Dw=d/(y*j); al=sigma/(1-H)
F=4*z*z*mu*M*M+4*Cw*dv*(u*W-Y)**2+4*y*ar*du*dv*Y*Y+4*Dw*J*J+4*al*du*p*p+4*beta*dv*bb*bb+core
kept=4*(ell-ec)*N*N+4*Cw*v*v*eta*eta+4*(al-alc)*du*(v*eta-ze)**2+4*beta*dv*Ebeta*Ebeta
ck('full_original_parent_all_state_normals',(F-kept-G).subs({q:qq,g:gg,Rh:rh_actual}))

rho=s.cancel(G.coeff(Rh,1).coeff(W,1)/(u*k))
assert rho.is_polynomial(u,v)
checks['dependent_root_gauge_has_bounded_parity']=True
Gg=s.expand(G-u*k*rho*Rh*W+rho*(u*v*W*Qn-sc*u*u*(v*v-y)*W*W))
ck('no_first_Rh_normal_after_gauge',Gg.coeff(Rh,1).coeff(W,1))
ck('gauge_exact_on_roots',(Gg-G).subs(Rh,rh_actual))

def even(expr,pu=0,pv=0,pk=0):
    poly=s.Poly(s.cancel(expr/(u**pu*v**pv*k**pk)),u,v)
    ans=0
    for (i,jj),coef in poly.terms():
        assert i%2==0 and jj%2==0
        ans+=coef*U**(i//2)*V**(jj//2)
    return s.expand(ans)
Pxi=even(Gg.coeff(xi,1).coeff(W,1),pv=1)
Pze=even(Gg.coeff(ze,1).coeff(W,1),pu=1,pv=1)
PN=even(Gg.coeff(N,1).coeff(W,1),pu=1,pk=1)
phi=even(Gg.coeff(W,2))
ck('xi_normal_support_U_z',Pxi.subs({U:0,z:0}))
assert s.degree(phi,U)<=2
checks['scalar_degree_U_at_most_two']=True
ds=4*z*z/B**2*(mu*(B+z*r)**2+r*r/2-tau*(1+r))
es=4*z*z/B**2*(r*r/2-tau*(1+r))
ck('new_scalar_at_U_zero',phi.subs(U,0)-V*(ds+es*V))
normal=Gg.subs(W,0).subs({u:0,v:0,z:0,k:0})
ck('hard_four_normal_residue',normal-4*ec*N*N-2*xi*xi-4*alc*ze*ze-4*g*Rh*Rh)
h,rr=s.symbols('h rr')
res={B:h,r:rr,c:h/(2*(1+h)),d:h/(2*(1+h)),g:h/(2*(1+h)),q:t,
     mu:rr/(2*h*(1+h)),ar:1/(2*h*(1+h)),
     sigma:h*h/(2*(1+h)),tau:h/(2*(1+h))-(1-rr)/2}
cross=s.diff(Pxi,U).subs({U:0,V:0,z:0,k:0}).subs(res)
diag=s.cancel(ds/z**2).subs({z:0,k:0}).subs(res)
ck('unchanged_xi_R_cross',cross-4/(h*(1+h)))
ck('beta_scalar_cancellation',diag-2/(h*h*(1+h)))
ck('strict_xi_R_schur',diag-(cross/2)**2/2-2/(h*(1+h)**2))
toric=T1*T1-u*u*R*R-(u*u-z)/sc*Rh*T1+u*(u*u-z)/sc*R*Qn
ck('unchanged_exact_toric_conductor',toric.subs({Rh:rh_actual,R:v*(u*u-z)*W,T1:u*k*(u*u-z)*W}))

# Native C1 source residues: clear openings before specialization.
xs,etas,L,an,theta=s.symbols('x_s eta_s L a_native theta')
rn=1-an*etas; hn=1-theta; yn=L*etas; zet=L/xs
Kn=1+xs; Rn=1+xs*rn; Tn=1+xs*hn
Gn=hn+zet; Mn=Rn-theta/zet; Jn=Tn-an
En=1-xs*etas*hn; Qc=1-L*rn
P4=Tn*En+xs*(1-rn)*Gn
Pal=Rn*hn*(1+yn)+zet*Mn*En
Pd=1+2*xs*hn+rn*xs*xs*Gn+xs*zet+etas*xs*(Kn*zet+xs*hn*theta)
B5=Kn*(1+yn)*(rn+etas)-etas*Jn*Pd
Bbet=Kn*xs*(rn+etas)*Gn-theta*Pd
src_ct=L*Kn*(rn+etas)*En/(2*Pd)
src_dj=L*B5/(2*Pd)
src_ar=P4/(2*rn*L*Pd)
src_mu=Kn*(rn+etas)*hn*(1+yn)/(2*Mn*L*Pd)
src_sig=xs*L*(rn+etas)*Pal/(2*Pd)
src_tau=Bbet/(2*Pd)
zsource={xs:0,etas:0}
def residue(expr): return s.cancel(expr).subs(zsource)
ck('native_C_times_y_a',residue(src_ct)-L/(2*(1+L)))
ck('native_D_times_y_J',residue(src_dj)-L/(2*(1+L)))
ck('native_A_over_y',residue(src_ar)-1/(2*L*(1+L)))
ck('native_m_over_z_squared',residue(src_mu)-(1-theta)/(2*L*(1+L)))
ck('native_alpha_Q',residue(src_sig)-L*L/(2*(1+L)))
ck('native_beta_theta',residue(src_tau)-(L-theta*(1+L))/(2*(1+L)))

result={'status':'all_exact_checks_passed','count':len(checks),'checks':checks,
 'scope':'C1 native x infinitesimal, L=x*zeta unit, eta infinitesimal: exact full-parent adapter to strong-II local Gram. Remote proof follows RR1--RR13 with beta packet retained. Analytical bound and inherited contact/division arguments are in the source text.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
Path(__file__).with_name('extracted_coefficients.txt').write_text('\n\n'.join(['rho = '+str(s.factor(rho)),'P_xi = '+str(s.factor(Pxi)),'P_zeta = '+str(s.factor(Pze)),'P_N = '+str(s.factor(PN)),'phi = '+str(s.collect(phi,U))])+'\n')
print(json.dumps({'status':result['status'],'count':len(checks)}))
