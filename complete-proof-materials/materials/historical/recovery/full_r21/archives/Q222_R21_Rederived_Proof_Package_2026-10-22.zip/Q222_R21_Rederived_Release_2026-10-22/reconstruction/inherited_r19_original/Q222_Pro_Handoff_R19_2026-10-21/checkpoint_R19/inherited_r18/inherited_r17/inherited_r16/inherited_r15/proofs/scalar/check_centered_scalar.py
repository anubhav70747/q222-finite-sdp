"""Exact new identities: centered scalar and coupled circuit, no numerical tests."""
import sympy as s
from pathlib import Path
import json
checks={}
def check(name,e):
 z=s.cancel(e)
 assert z==0,(name,s.factor(z))
 checks[name]=True;print('PASS',name,flush=True)
# Generic stationary positive-monomial scalar, normalized at contact.
p,q,lam,ep,ed,eb=s.symbols('p q lam ep ed eb', nonzero=True)
fB=lam+ep+2*ed+eb;fC=lam+2*ed+2*eb;fG=3*lam+2*ep+5*ed+4*eb
S=lam*p*p*q*q+fB*q**4/p**2+fC+ep*p*p+ed*p**4*q*q+eb*p*p*q**4-fG*q*q
L3=p*p*q*q+q**4/p**2+1-3*q*q
L5=p**4*q*q+2*q**4/p**2+2-5*q*q
L4=p*p*q**4+q**4/p**2+2-4*q*q
check('exact_centered_AMGM_decomposition',S-lam*L3-ep*(p-q*q/p)**2-ed*L5-eb*L4)
for name,E in [('value',S),('p_jet',s.diff(S,p)),('q_jet',s.diff(S,q))]:check('contact_'+name,E.subs({p:1,q:1}))
# Coupled lift avoids every inverse of a sum of source/testing quantities.
P,k,E,d=s.symbols('P k E d',nonzero=True)
left=(1+P*P)*E*E+2*(P+k)*E*d+(1+2*k/P)*d*d
right=2*k/P*(P*E+d)**2+((P-k)*E+d)**2+(1-k*k)*E*E
check('coupled_circuit_exact_lift',left-right)
A,B,G=s.symbols('A B G',nonzero=True);C=G**3/(A*B)
check('three_circuit_two_difference_form',A*A+B*B+C*C-3*G*G-((A-C)**2+(1+2*G/B)*(B-G)**2))
# Source-only check of the new q*=q_s+alpha contact identities.
B,a,t,r,h,U,V=s.symbols('B a t r h U V'); half=s.Rational(1,2)
n,m,C,Ah,D,al=s.symbols('n m C Ah D alpha');e=1-r
ca=1+a*B*r;Sc=1+B*(1-h+a*r);g=1+a*(h*B+r-1);j=ca-(1-h)/t
delta=a+(1+a*B)+(1+a*B)*B+2*a*B*(1+a*B)*r+a**3*B**2*r*r+2*a*a*B*r+t*B*(1+a+a*B+a*a*B*r*(2-r))
M=(1+a*B)*(1+a*r)*(h+t)-a*(1+t*B)*e*(1-h)
src={n:((1+a*r)*ca*Sc-r*delta)/(2*r*delta),m:a*a*(1+t*B)*e*ca*Sc/(2*g*delta),C:ca*M/(2*(1-h)*delta),Ah:t*ca*(1+a*r)*Sc/(2*delta),D:(1+a*B)*(1+a*r)*(1-a*t*B*r)*Sc/(2*t*j*delta),al:B*B*(1+a*r)*M/(2*(1-h*B)*delta)}
aw=(C+D+half)*(1-h)**2+Ah*h
b2=2*m*h+C*(1-h)**2+Ah*h+(al+half)*h*h
b4=h*h*(m+al+half)+Ah*h
d2=(n+half)*r*r+2*D*r;d4=(n+D+half)*r*r
e0=m*e+D*(1-h)+al*h+half
e1=m*h*e+r*(D+half)*(1-h)+(al+half)*h
qs=n*r*r+(m+half)*e*e;qt=qs+al
cf=(b2-a*a*n*r*r)/t**2
lam=Ah*h/t**2+d2-2*e1/t+2*a*n*r*r/t
fb=(m-a*a*qt)/(t*a*a*B)
fc=(al-cf*(t*B)**2)/(t*a*B**2)
fg=-(aw/t**2+D-2*e0/t+2*a*qt/t+2*cf*t*B)/(a*B)
ed=d4*a*B;eb=b4*B/t
weights=(n,m,C,Ah,D,al)
uden=2*r*g*(1-h)*(1-h*B)*(t-1+h+a*B*t*r)*delta
nums={z:s.cancel(uden*src[z]) for z in weights}
def source_zero(name,expr):
 en,de=s.fraction(s.factor(expr));poly=s.Poly(en,*weights);assert poly.total_degree()<=1
 num=s.expand(poly.coeff_monomial(1)*uden+sum(poly.coeff_monomial(z)*nums[z] for z in weights))
 assert num==0,(name,'nonzero source polynomial')
 checks[name]=True;print('PASS',name,flush=True)
source_zero('source_fB_star_balance',fb-lam-2*ed-eb)
source_zero('source_fC_balance',fc-lam-2*ed-2*eb)
source_zero('source_fG_star_balance',fg-3*lam-5*ed-4*eb)
# Exact full-state angular completion and radial binomial.
u,v,W,Z,E=s.symbols('u v W Z E',nonzero=True)
H=a*v*v*Z/(t*u)-u*Z
check('full_angular_root',H+a*v/(t*u)*(t*u*W-v*Z)-(a*v*W-u*Z))
check('full_radial_root',(v*v-t*B)*Z+t*(B*Z-u*v*W)+v*(t*u*W-v*Z))
out={'status':'PASS','checks':checks,'count':len(checks),'scope':'Exact scalar and coupled-circuit identities. Full-parent closure is a separate obligation.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
