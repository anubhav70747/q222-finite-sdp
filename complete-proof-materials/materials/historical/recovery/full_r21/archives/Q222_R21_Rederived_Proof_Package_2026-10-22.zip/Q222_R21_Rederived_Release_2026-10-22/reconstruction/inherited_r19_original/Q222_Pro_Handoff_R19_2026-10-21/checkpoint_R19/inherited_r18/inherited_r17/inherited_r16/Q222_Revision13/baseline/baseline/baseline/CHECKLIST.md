# Exact remaining checklist — revision 4

Global status: **unfinished**. Every residual row is intersected with original physicality, positive infinitesimal total scale, and the complement of all proved admissions and their exact full-parent symmetries. A local certificate removes a testing subregion, not an entire source row.

## Completed this revision

- [x] **C1.2** — proved_all_tests.  Proof: `advances/c1_scales/centered_a_bounded_delta.tex`.
- [x] **C1.3** — proved_all_tests.  Proof: `advances/c1_scales/small_e_all_tests.tex`.
- [x] **C1.UU** — proved_all_tests_subdomain. Actual unit/unit subcase of C1.5 only Proof: `advances/source/source_reductions.tex`.
- [x] **C2.W.HI** — proved_empty.  Proof: `advances/source/bounded_second_angle_exclusion.tex`.
- [x] **C2.W.HU** — proved_empty.  Proof: `advances/source/bounded_second_angle_exclusion.tex`.
- [x] **C2.EXACT_CURVE** — proved_all_tests_subdomain. The displayed rational one-parameter physical source family only; not all strong II sources Proof: `advances/c2_curve/rational_curve_tensor_sos.tex`.
- [x] **RATIONAL_CURVES** — proved_all_tests_subdomains. Every real-rational physical source curve on a real interval, with pure-source polynomial denominator clearing. Includes the displayed weak-IH,HH and radial witness curves on sufficiently small real intervals. This does not imply exhaustion of any several-parameter source leaf. Proof: `advances/c2_curve/rational_curve_tensor_sos.tex`.

## Nine conditional residual domains

### C1.1

- [ ] k,zeta infinitesimal; eta unbounded.


Original native entry, C=2, 0<k<=1; q=k^2 eta bounded with residue <=1/2. C/d strong, alpha/d and D/d weak. Uniform E>=1/18 and NI1–NI2 source comparisons hold. Actual II; C,A unbounded, D,alpha weak; beta>=0 forces t=O(e^2).

**Remaining work:** Obtain source-scaled full-parent graph/conductor; handle arbitrary e and opening rates.

Apply every acceptance gate below to the exact remaining domain.

### C1.4

- [ ] k infinitesimal; zeta noninfinitesimal; eta arbitrary positive.


Includes zeta bounded unit and zeta unbounded; use original signs and coefficient inequalities. Uniform E>=1/18 and NI1–NI2 source comparisons hold.

**Remaining work:** Close the exhaustive L=k^2 zeta alternatives NI4–NI6: L unbounded, L unit, or L infinitesimal with eta bounded/unbounded. Source comparisons alone are insufficient.

Apply every acceptance gate below to the exact remaining domain.

### C1.5

- [ ] k bounded unit; eta or zeta noninfinitesimal; actual(U,U) and its exact symmetry images removed.


The eta,zeta both infinitesimal domain is already covered. Uniform E>=1/18 and NI1–NI2 source comparisons hold.

**Remaining work:** Close actual UI or UH after the exact NI7–NI10 source reductions, with every original normal and all testing charts.

Apply every acceptance gate below to the exact remaining domain.

### C2.W.IH

- [ ] IH.

d=1, C weak, alpha strong; at least one of 1/(Cn),1/(Cm),1/(CA),1/(CD) unbounded or undefined at n=0
C weak iff B unbounded; rho=B/y bounded with residue in [0,1]; r/rho bounded, 1-r unit; Cm weak throughout. Original positive chart and all boundaries retained.

**Remaining work:** Complete this contact corner when rho or 1-rho is infinitesimal, and all other commuting test charts for every permitted source shape. In particular resolve the infinity-infinity normal pivot uniformly at n=0.

**Already proved locally:** rho and 1-rho positive units, arbitrary positive r,H,1-H and n>=0: complete parent at independent u and w=1/v infinitesimal or zero.

Apply every acceptance gate below to the exact remaining domain.

### C2.W.HH

- [ ] HH.

d=1, C weak, alpha strong; at least one of 1/(Cn),1/(Cm),1/(CA),1/(CD) unbounded or undefined at n=0
The exact rational HH example disproves a universal four-product reduction on the coarse directed type, but is itself admitted by the rational-curve theorem. It does not prove residual nonemptiness. Reflection must preserve the weak-C orientation.

**Remaining work:** Prove source emptiness or a bounded full-parent Gram for every independent testing chart, including all full normals and literal retained coefficient boundaries.

Apply every acceptance gate below to the exact remaining domain.

### C2.S.II_HH

- [ ] II_HH.

d=1, C and alpha strong; a weak member of m,A,D


**Remaining work:** Prove all-tests coverage for arbitrary multiple source parameters after subtracting every proved rational source curve; control all normals and all relative source/test rates. The single-curve theorem and polynomial-SOS obstruction do not decide this leaf.

**Already proved for all tests:** The exact real-rational x family in advances/c2_curve/rational_curve_tensor_sos.tex is admitted at every test for 0<x<1/4, together with exact full-parent symmetry images.

Apply every acceptance gate below to the exact remaining domain.

### C2.S.IH

- [ ] IH.

d=1, C and alpha strong; a weak member of m,A,D


**Remaining work:** Prove source emptiness or a bounded full-parent Gram for every independent testing chart, including all full normals and literal retained coefficient boundaries.

Apply every acceptance gate below to the exact remaining domain.

### C2.S.UI_HU

- [ ] UI_HU.

d=1, C and alpha strong; a weak member of m,A,D


**Remaining work:** Join the local contact certificate to every other commuting chart, including v=0 with Y=uW,X=Z=0, and u=infinity with W=X=0,Z=vY; retain all upper source scales and n=0. Noncommuting residues already covered.

**Already proved locally:** Actual u_c=a unit,v_c=k infinitesimal, C and alpha strong: every state at v infinitesimal and u-a infinitesimal; all positive opening rates and n=0. Include exact sign/reflection images.

Apply every acceptance gate below to the exact remaining domain.

### C2.S.HI

- [ ] HI.

d=1, C and alpha strong; a weak member of m,A,D


**Remaining work:** Prove source emptiness or a bounded full-parent Gram for every independent testing chart, including all full normals and literal retained coefficient boundaries.

Apply every acceptance gate below to the exact remaining domain.

## Acceptance gates for each domain

- [ ] **G1 — Exact source entry:** Use unchanged original parent and coefficients. Prove chart signs, source normalizations and every bounded ratio; no inferred entry from a filename.
- [ ] **G2 — Full-parent decomposition:** Give an exact polynomial identity retaining positive excess event squares. If centered, prove each center vanishes at the actual contact and all contact jets persist.
- [ ] **G3 — Admissible roots and bounded Gram:** Exhibit explicit tensor squares, or admissible roots and a bounded Gram. Every inverse/radical must be pure source or pure test. Print the division/factorization identities.
- [ ] **G4 — All first normals and hard blocks:** Carry every state-normal linear term and every quadratic coupling. A scalar graph restriction or determinant alone does not pass this gate.
- [ ] **G5 — Strictness and equality cases:** For a bounded Gram, prove strict positive real residue or resolve its equalities. A direct exact tensor-SOS identity can instead discharge positivity without a residue Gram.
- [ ] **G6 — Independent tests:** Cover every measurement residue chart (0, finite nonzero, infinity), both signs, all projective state charts and complex states; actual contact and test scales are independent.
- [ ] **G7 — Literal boundaries:** Retain C1 D=0 or beta=0 (at most one) and C2 n=0. Treat literal testing endpoints homogeneously. Do not confuse vanishing coefficient with positive infinitesimal opening.
- [ ] **G8 — Scoped review and corroboration:** Review assumptions and algebra against original formulas; small exact checkers may corroborate identities, with no numerical sampling premise.
- [ ] **G9 — Coverage admission:** Record only the proved quantified domain. Subtract its exact symmetry images and re-form the residual set; no global closure from a local PASS.

## Final global steps

- [ ] **U1:** prove exact exhaustion of all original sources and all independent tests after the nine rows are resolved.
- [ ] **U2:** apply the inherited finite-lift bridge with its original universal quantifiers. This is blocked by U1.
- [x] **U3:** deliver the current cumulative manuscript, proofs, checkers, dependency graph and precise frontier.

An explicit evaluated affine SDP pencil is a separate optional deliverable. It is not asserted here.
