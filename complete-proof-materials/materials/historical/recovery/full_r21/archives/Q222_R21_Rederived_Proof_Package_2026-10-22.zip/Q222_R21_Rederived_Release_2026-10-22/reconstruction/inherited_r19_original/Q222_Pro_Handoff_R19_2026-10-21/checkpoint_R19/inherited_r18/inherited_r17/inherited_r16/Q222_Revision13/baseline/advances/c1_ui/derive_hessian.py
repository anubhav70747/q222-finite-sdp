from pathlib import Path
import sympy as s,json,time
k,f,r,u,V,w,Y=s.symbols('k f r u V w Y',positive=True)
x=k*k;e=f*f;K=1+x;R=1+x*r;E=1-x*e;P4=K*E+x*(1-r);Pd=1+2*x+r*x*x;a=(1-r)/e;J=K-a
h=2*x*e/(R*E);C=2/a;A=2*e*e*P4/(K*r*(r+e)*E);d=4*e*Pd/(K*(r+e)*E);D=2/(J*E)-d/2;al=2*x*x*e*R/(K*E)
# Use generic coefficients while differentiating; source substitutions last.
hh,cc,aa,dd,ds,al0=s.symbols('hh cc aa dd ds al0')
v=k*f*V;W=w/f;yy=k*Y/f;Du=1+u*u
F=4*hh*v*v*(W+u*yy)**2+4*cc*(u*W-yy)**2+4*aa*Du*yy**2+(4*dd+2*ds)*(u*W-yy-v*Du)**2+4*al0*Du-4*ds*Du*v*yy-2*ds*Du*v*v
vars=(w,Y,V,u);P=s.hessian(F,vars)/2;P=P.subs({w:1,Y:r,V:1,u:k});src={hh:h,cc:C,aa:A,dd:D,ds:d,al0:al}
P=P.applyfunc(lambda z:s.factor(z.subs(src)))
print('state Hessian obtained',flush=True)
B=P[:2,:2];Cross=P[:2,2:];SS=P[2:,2:];inv=s.Matrix([[B[1,1],-B[0,1]],[-B[1,0],B[0,0]]])/s.factor(B.det())
G=(SS-Cross.T*inv*Cross).applyfunc(s.factor)
print('G=',G,flush=True)
expected=s.Matrix([[32*e*x*x*P4/(K*E),16*e*k**3*(R**2-2*K*E)/(K*E*R)],[16*e*k**3*(R**2-2*K*E)/(K*E*R),32*e*x*(P4+x*r*Pd)/(R**2*P4)]])
checks=[]
for i in range(2):
 for j in range(i,2):
  assert s.factor(G[i,j]-expected[i,j])==0,('hessian',i,j,s.factor(G[i,j]/expected[i,j]))
  checks.append('angular Hessian '+str(i)+str(j))
det=256*e*e*x**3*(4*K*K*E-R*R)/(K*K*E*E)
assert s.factor(G.det()-det)==0;checks.append('angular determinant')
ineq=K*(2+x*r)*E-R*R
print('D numerator=',s.factor(D/ineq),flush=True)
# D sign factor may differ from asserted source condition.
etaMin=(1-r)/K;etaMax=(1-R**2/(K*(2+x*r)))/x
print('eta interval width=',s.factor(etaMax-etaMin),flush=True)
Path(__file__).with_suffix('.json').write_text(json.dumps({'status':'PASS','checks':checks,'G':[str(z) for z in G],'D_sign_factor':str(s.factor(D/ineq)),'eta_width':str(s.factor(etaMax-etaMin))},indent=2)+'\n')
