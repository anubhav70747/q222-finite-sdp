"""Exact graph and scalar-slice identities only; no SOS admission."""
from pathlib import Path
import json
import sympy as s
x,u,v,U,V,W,X,Y,Z=s.symbols('x u v U V W X Y Z')
n=(8-5*x*x)/(16*(1+x)**2)
m=3*x*x*(3*x+4)/(16*(1+x)*(4+x-2*x*x))
C=al=(4-x)/(8*x)
A=x*(x+4)*(3*x+4)/(32*(2-x)*(1+x)**2)
D=(2-x)*(3*x+4)/(16*x*(1+x))
Du,Dv=1+u*u,1+v*v
r=u*W-Y; p=v*Y-Z; J=u*W+u*v*X-Y-v*Z
Rm=v*W-X+u*p; B=X+u*Z
F=2*(J*J+Du*p*p+Dv*B*B-Du*Dv*Z*Z)+4*n*Du*Dv*X*X+4*m*Rm*Rm+4*C*Dv*r*r+4*A*Du*Dv*Y*Y+4*D*J*J+4*al*Du*p*p
g={W:1,X:-u*u*v/4,Y:(1-x/2)*u,Z:u*v}
checks=[]
def zero(name,e):
    assert s.cancel(e)==0,name
    checks.append(name)
zero('exact original J coordinate relation',J-(Dv*r+u*v*X-u*v*v*W+v*p))
zero('graph r',r.subs(g,simultaneous=True)-x*u/2)
zero('graph p',p.subs(g,simultaneous=True)+x*u*v/2)
zero('graph J',J.subs(g,simultaneous=True)-u*(x/2-v*v-u*u*v*v/4))
zero('graph Rm',Rm.subs(g,simultaneous=True)-v*(1+u*u/4-x*u*u/2))
phi=s.cancel(F.subs(g,simultaneous=True))
num,den=s.fraction(phi)
poly=s.Poly(num,u,v)
assert all(e[0]%2==0 and e[1]%2==0 for e,c in poly.terms())
checks.append('entire graph scalar even in both angles')
phiUV=sum(c*U**(e[0]//2)*V**(e[1]//2) for e,c in poly.terms())/den
sliceU=(4-x)*(4+x)*(3*x+4)*(V-x)**2/(32*(1+x))
sliceV=x*(U-x)**2*(96+72*x+(32+28*x-11*x*x-10*x**3)*U)/(32*(1+x)*(4+x-2*x*x))
zero('exact U=x scalar slice',phiUV.subs(U,x)-sliceU)
zero('exact V=x scalar slice',phiUV.subs(V,x)-sliceV)
zero('scalar contact value',phiUV.subs({U:x,V:x}))
zero('scalar contact U jet',s.diff(phiUV,U).subs({U:x,V:x}))
zero('scalar contact V jet',s.diff(phiUV,V).subs({U:x,V:x}))
eX,er,ep=s.symbols('eX er ep')
adapt={W:1,X:g[X]+eX,Y:g[Y]-er,Z:v*(g[Y]-er)+x*u*v/2-ep}
# Unscaled state-normal dependence; subsequent scales are pure source factors.
zero('centered original D amplitude relation',J.subs(adapt,simultaneous=True)-J.subs(g,simultaneous=True)-(Dv*er+u*v*eX+v*ep))
report={'status':'PASS','count':len(checks),'checks':checks,
        'scope':'exact identities supporting the first failed bounded-Gram gate; no positivity or all-tests certificate claimed'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
