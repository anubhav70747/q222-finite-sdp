# Scoped separate-agent review: strong C2 UI local theorem

Reviewed 18 October 2026. Author: `c1_scale_review`; reviewer: `coverage_reduction`. This is a same-system separate-agent mathematical review, not external peer review or formal verification.

**Verdict: PASS at the printed local scope; no blocking gap found.** Reviewed `../c2_ui/local_ui_certificate.tex`, `FULL_PARENT_REDUCTION.md`, and `reciprocal_contact_lemma.tex`. The source is the unchanged physical C2 source with d=1, actual u_c=a a positive bounded unit, actual v_c=k positive infinitesimal, and original C,alpha strong. The independent tests satisfy v infinitesimal and u-a infinitesimal. Every projective state, all source upper scales and positive openings, and literal n=0 are included. This review does **not** close the full UI source leaf or its reflected HU orbit: the other independent-angle charts and outer join remain open.

## Exact reduction and bounded coefficients

The source signs force b,h,1-r,Delta to be positive bounded units. The original products mg, A/k², k²Ct, k²Dj, alpha(1-zh) are positive units, while nr is bounded; in particular m is strong. The original C/D parallel identity is exact before any limiting operation. Subtracting the three displayed centered squares leaves precisely the six displayed correction terms. All retained roots vanish at the full source contact, including their first square jets.

The delicate difference C rho+D sigma has an exact pole-free formula, obtained by canceling Ct-Dj before taking residues. It cannot be replaced by separate magnitude estimates for C rho and D sigma. The new source-product checker verifies this cancellation as well as nx,nx²,m mu,m mu²,alpha pi,alpha pi²,C rho k²,D sigma k², and k²CD/(C+D). Their denominators are a,b,Delta and c1*j+c2*t, all units. The last is a unit because c1,c2 are positive units and t+j=Ac is a unit. Consequently the bounded finite-part coefficients have the asserted continuous residues even if a source gap closes faster than k². A/k² has only the additional unit h in its denominator. The small correction terms containing k² times C rho+D sigma vanish in the relevant residue; there is no hidden opening-rate comparison.

The caps n*,m*,alpha* are pure-source coefficients. Centering the corresponding excesses gives the exact cross and constant terms printed in the reduction; no clipped source is asserted to be physical. Every full normal and hard quadratic term is retained in G.

## Division-free complete lift

The graph inverse is polynomial and homogeneous in W. The three identities UI1 follow directly from Q=s vW+QN. The only bounded inverse they use is the pure-source unit 1/s. The occurrence of 1/k in Rh is a pure-source factor in a root, not an unbounded Gram coefficient or a mixed inverse.

On the graph, parity and the exact axis structure put the complete scalar in (k²,xi), xi=v². Divide monically first in u-a and then in xi-k². The coefficient of (u-a)² remains in (k²,xi); exact contact and both angular first derivatives remove the two forbidden constant/linear terms. This gives UI2 for the entire bounded polynomial. Its cross term is RT and its last term is (kR)², so UI1 supplies a bounded exact allocation without introducing v/k as a coefficient.

The complete EX,EZ first-normal coefficients are odd in v and vanish at contact. Their monic divisions give S and v*kR. The complete Er first normal is in (k²,xi), so its division gives kT,vS,kR; its lifted couplings all have zero residue. The state degree is exactly two, hence the remaining hard block is the full quadratic block. These arguments prove a full six-root lift, not merely a restriction to the state kernel or a finite weight calculation.

## Uniform matched Hessian and finite caps

The leading model has the exact contact value and all four first derivatives zero. The Schur formulas now print every entry. All entries are bounded with only unit denominators a,b,Delta, and the ordinary-angle pivot and determinant have positive-unit lower bounds. The n numerator identity gives r<=1/(z+1); the displayed determinant margin is strictly positive, including n=0. Thus the angular Schur form is uniformly strict in a real neighborhood of each allowed source residue. No universal lower constant independent of a,b is needed.

The possible unbounded weights among n,m,alpha occur only on r=0,g=0,1-zb=0. The last two cannot occur together. Every possible pair of diverging centered rows has an invertible hard-state restriction, with a unit determinant. Their coefficients, including angular columns, remain bounded. This supplies a bounded hard competitor that kills the diverging rows exactly for any fixed angular vector.

Here is the quantitative step behind the cap-limit proof. Write a nearby full matched Hessian in state-Schur form with hard block P>=cI, angular Schur G, and minimizing hard vector h_min(q). A bounded competitor h0(q) has bounded quadratic value, because all diverging rows vanish on it. Then

`(h0-h_min)^T P (h0-h_min) = F(h0,q) - q^T G q`

is uniformly bounded by a constant times |q|². Hence h_min is a bounded linear function of q. The strict lower bounds for P and G now give a uniform positive lower bound for the entire matched Hessian in the original hard/angular coordinates. This justifies the limit argument beyond positivity of the determinant alone.

For a vector in the common limiting packet kernel, the unit hard-row determinants allow a vanishing hard-coordinate adjustment into every exact nearby packet kernel. Those packet contributions are then identically zero, so continuity of the bounded finite part transfers the strict lower bound to the limiting constrained form. The elementary penalty lemma therefore supplies finite real caps. Such caps are below the genuinely unbounded original weights; bounded weights can be retained in full. Boundary residues are approached from the leading physical inequality domain, including Qn=0: the admissible b interval has nonzero width, and decreasing r and choosing b slightly inside it makes Qn positive when needed. Thus no n>0 assumption is introduced at a literal n=0 source.

This use of inverses and Schur complements is only real finite-dimensional analysis to choose caps. The tensor identity uses the polynomial graph, source factors, and UI1; it never inverts a mixed matrix or takes a mixed square root.

## Independent angular roots and exact restoration

The residue hard block on Er,EX,EZ,Rh is strict because m*,alpha*,gamma are positive units. The scalar and normal allocation makes S couple only to EX,EZ and T only to Rh; Er couplings vanish. Hence the two remaining angular Schur coefficients have no mutual cross term. On S=T the Gram is the matched Hessian under an invertible bounded coordinate change: the relative-angle derivative in Rh is 2s, a unit. The cap argument makes the sum of these two Schur coefficients strictly positive.

The last identity UI1 transfers a finite real amount of mass between S² and T²; all of its additional coefficients have the factor u-a and zero residue. Choosing the transfer makes each angular Schur coefficient positive. The resulting full six-root Gram has strict residue. Restoring the centered excess packets and both other C/D packets recovers the exact entire parent. Homogeneity includes W=0 and every projective state, with real and imaginary parts supplying complex states.

## Fresh exact replays

- `check_ui_source_products.py`: **PASS12**, exact original rational cancellations.
- `check_reciprocal_contact_lemma.py`: **PASS11**, reciprocal leading completion and full C/D parallel identity.
- `probe_angular_schur.py`: **PASS10**, exact contact jets, angular Schur pivot/determinant, and n-derived margin; the displayed full Schur entries agree with the manuscript.

All three were freshly run with the existing SymPy dependency at `/workspace/scratch/964ce4ea4964/work/advance_2026_10_17/deps`. Their finite algebra verifies the stated identities; the full lift and cap-limit proof were reviewed separately above. No outer-angle or full-source-orbit admission follows from these replays.
