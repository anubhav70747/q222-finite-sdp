# A finite moving frame for the complete parent

This is a proved regular-regime replacement for normal-array bookkeeping. It uses no mixed inverse, numerical Gram search, polynomial-SOS premise, or truncated identity. The exact full parent is retained. The theorem below covers every independent finite nonzero testing angle when the actual source contact and the normalized CHSH coefficient are finite nonzero units. It does not cover source contact angles tending to a commuting axis, a vanishing normalized CHSH coefficient, or independent testing angles tending to a commuting axis.

## 1. Exact statement

Let Kc and Kt be real closed extensions of R, with bounded valuation rings Ac, At and residue field R. Write T=Kc tensor_R Kt, B=Ac tensor_R At, and n=mc tensor At + Ac tensor mt. Source and testing quantities retain these independent roles throughout.

Let P_c(u,v) be the original symmetric 4-by-4, bidegree-at-most-(2,2) Bell-parent matrix, with nonnegative source coefficients normalized by

    d + lambda + n + m + c + A + D + alpha + beta = 1.

The symbol n in this normalization denotes the original event coefficient, not the infinitesimal ideal above. In the formulas below it never denotes a denominator.

Assume:

1. P_c(u,v) is PSD for every source-field angle u,v and every source-field state. The coefficient vector lies in C1 (lambda=n=0) or C2 (lambda=beta=0).
2. d has strictly positive real residue.
3. An actual stationary source contact (uc,vc) has strictly positive finite real residues, det P_c(uc,vc)=0, and its two angle derivatives vanish on its kernel state.

For every independent positive testing angle ut,vt having strictly positive finite real residues, and every bounded testing-state vector psi, the tensor evaluation psi^T P_c(ut,vt) psi is a finite tensor sum of squares.

The source-independent state feature count in the matching-residue construction is five; this means a five-feature bounded Gram representation, not a claim of five tensor squares. Every source coefficient used below is bounded. Unbounded state vectors can first be divided by a pure-testing Euclidean state norm, and restored by its square afterwards.

The only imported local algebraic fact is the bounded-Gram lemma already proved in the locked proof: a symmetric Gram over B whose real residue is positive definite represents a finite tensor SOS, even when the feature vector itself is mixed. A finite decomposition of its infinitesimal entries and strict real reserves proves that lemma; no mixed inverse is implicit in it.

## 2. Only source contact data are inverted

Write psi=(x,z), x=(W,X,Y), z=Z, and partition the original parent

    P(u,v) = [[Q(u,v), r(u,v)], [r(u,v)^T, s(u,v)]].

At z=0 its signed CHSH core is

    2d [(uW+uvX-Y)^2 + (1+u^2)v^2 Y^2 + (1+v^2)X^2].

The displayed three rows form an invertible triangular state frame for u,v>0. At finite unit contact angles and unit d, Q0=Q(uc,vc) consequently has positive-definite real residue. All its entries and all entries of its source inverse Q0^{-1} are bounded. This is inversion entirely inside Kc, at the actual source contact.

Set

    a = -Q0^{-1} r(uc,vc),       h=(a,1),       E=[[I3],[0]].

PSD and zero determinant give P0 h=0. The normalized contact state h is bounded. For j=u,v define

    bj = E^T P_j(uc,vc) h,
    kj = (-Q0^{-1} bj, 0).

Stationarity says h^T P_j h=0. Since P0 h=0, this implies P0 kj=-P_j h: the first three components hold by construction, and their fourth component follows by pairing the difference with h, whose last component is one.

This is the physical change of the minimizing state as the measurement angles move. It is a finite algebraic expression in source contact data, rather than a mixed spectral projector or a source-dependent monomial exponent.

## 3. The literal polynomial, including both normal directions

Put delta=(delta_u,delta_v)=(ut-uc,vt-vc) in the tensor ring and

    v(delta)=h+ku delta_u+kv delta_v,
    psi = E w + z v(delta).

The frame has determinant one because the last component of v is one. Its exact inverse is z=Z and w=x-z[a+(ku)_xyz delta_u+(kv)_xyz delta_v]. No mixed quantity is divided.

For the entire untruncated parent define

    A(delta)=E^T P(uc+delta_u,vc+delta_v) E,
    b(delta)=E^T P(uc+delta_u,vc+delta_v) v(delta),
    f(delta)=v(delta)^T P(uc+delta_u,vc+delta_v) v(delta).

Then the exact identity is

    F = w^T A(delta) w + 2z w^T b(delta) + z^2 f(delta).

The source contact equations and P0 kj=-P_j h give, exactly,

    A(0)=Q0,
    b(0)=0,     partial_u b(0)=partial_v b(0)=0,
    f(0)=partial_u f(0)=partial_v f(0)=0.

Therefore b lies in the square of the contact ideal and f lies in its square. No estimate or omitted remainder is used. Divide their finite monomial lists as follows. In each b_i, send a monomial delta_u^a delta_v^b to delta_u times the remaining monomial if a>0, otherwise to delta_v times the remaining monomial. The resulting coefficients b_{iu},b_{iv} vanish at zero. In f, send terms with a>=2 to delta_u^2, terms with a=1 to 2 delta_u delta_v (dividing the coefficient by two), and terms with a=0 to delta_v^2. This produces an explicit symmetric polynomial matrix G(delta) such that

    F = xi^T G(delta) xi,
    xi=(w1,w2,w3,delta_u z,delta_v z),

and

    G(0) = diag(Q0,C).

Because P has bidegree (2,2), every entry of this exact five-by-five Gram has total delta-degree at most four. The construction is a fixed finite division rule, so scalar and both normal arrays are funded at once.

The relaxed angle stiffness is

    C_ij = (1/2) h^T P_ij h - bi^T Q0^{-1} bj.

The negative term is the energy recovered by allowing the state to readjust. All entries of C are bounded. The issue is strict positivity, resolved next by determinant balance.

## 4. Determinant covariance supplies strict angle stiffness

The exact determinant identity from the locked proof is

    det P(u,v)=16 Du^2 Dv^2 U V L(U,V),
    L(U,V)=h0 + sum_{nu in E} p_nu U^{nu1} V^{nu2},
    U=u^2, V=v^2, E={-1,0,1}^2 minus {(0,0)}.

All p_nu are nonnegative. At the stationary source contact put

    mass_nu=p_nu Uc^{nu1} Vc^{nu2},
    Sigma=sum_nu mass_nu nu nu^T.

Stationarity is the equilibrium equation sum mass_nu nu=0. The Hessian in logarithmic angles is the second moment of these balanced exponent forces. Since the moving frame has determinant one and its cross block has no linear term, comparison of the exact quadratic determinant coefficients gives

    C = [32 Duc^2 Dvc^2 Uc Vc / det Q0]
        diag(1/uc,1/vc) Sigma diag(1/uc,1/vc).

The prefactor is a bounded positive unit. Thus C has positive-definite residue exactly when the positive-residue determinant masses span two angle directions.

In C1 this spanning property is automatic. All t1,...,t8 appearing in the outer coefficients are positive units because each is d plus a nonnegative event sum. Consequently the residue support is determined by the following product incidences:

    q01: alpha m,       q02: m D,       q10: alpha A,
    q12: beta m+c D,    q21: c A,       q22: beta c.

The omitted coefficients q00,q20 are zero. A nonzero balanced support of rank one must be an antipodal pair. A horizontal pair requires alpha,m,c,A all units, which also makes q10 a unit. A vertical pair requires alpha,A units, but vanishing q01 and q21 then force m,c weak, making q12 weak. Both are contradictions. Diagonal pairs are absent.

A zero mass support is also impossible. Its product constraints imply one of only five covering supports. This is a two-line case split: if m is a unit, alpha,beta,D are weak and cA is weak; if m is weak and c is a unit, A,D,beta are weak; if m,c are weak, alpha A is weak. These give {m,A}, {m,c}, {c,alpha}, {A,D,beta}, {alpha,D,beta}. On these five supports, respectively, the residue determinant at u=v=1 is

    -256 d^2 (2A+d)(d+2m),
    -256 d^2 (2c+d)(d+2m),
    -256 d^2 (2alpha+d)(2c+d),
    -256 d (2A+d)(2D+d)(2beta+d),
    -256 d (2alpha+d)(2D+d)(2beta+d).

Each is strictly negative. Subsupports are obtained by setting additional coefficients to zero and retain the same strict sign. Physical PSD rules all of them out. Hence Sigma has positive-definite residue in every C1 contact covered by the theorem, including literal or infinitesimal openings among the event coefficients.

For C2 the same incidence argument leaves only one possible nonzero balanced rank-one support: n,m,A,D are units and alpha,c are weak. The root's companion two-state compression excludes this last possibility: writing s=c+alpha and q=n+m+A+D, PSD at u=v=1 implies 2 s q >= d^2. Since q is bounded and d a unit, s must be a unit. Rank-zero supports again lie in five covers, {A,D}, {A,m}, {D,alpha,n}, {alpha,c,n}, {c,m,n}; their determinants at u=v=1 are, respectively,

    -256 d^2 (2A+d)(2D+d),
    -256 d^2 (2A+d)(d+2m),
    -256 d (2D+d)(2alpha+d)(d+2n),
    -256 d (2alpha+d)(2c+d)(d+2n),
    -256 d (2c+d)(d+2m)(d+2n).

They are strictly negative as well. Thus Sigma also has positive-definite residue for every C2 contact in the theorem. The complete Boolean census and these exact factor identities are independently reproducible in check_residue_covariance_census.py; the short support argument above is the proof, rather than a reliance on enumeration.

There is a stronger physical consequence useful for the remaining testing-angle regimes. C1 forces m,c,A,alpha all to have positive residues, while C2 forces m,c,A,D,alpha all to have positive residues. For C1, alpha weak or A weak first kills the only negative-v mass q10; balance successively kills every mass, a contradiction. With alpha,A units, m weak kills both negative-x masses, forces c weak, and then cannot balance q10. Finally q01=alpha m positive needs a positive-x mass, which forces c unit. Balancing q10 also forces D+beta to be a unit. For C2, alpha weak makes the sum of the two exponent coordinates nonnegative on the remaining support; balance forces cA,cD weak. The compression floor forces c unit, and all masses then vanish. The c-weak case is the symmetric argument, so alpha,c are units. If m is weak, negative-x masses vanish, forcing A weak through cA, then D weak through cD, and hence all masses vanish. If A is weak, negative-v masses vanish, forcing D weak and then m weak. Thus m,A are units, and balancing q10=alpha A forces D to be a unit. These are residue claims, so they exclude infinitesimal openings as well as literal zeros in these particular coefficients. C1 may still have D or beta weak individually, but not both; C2 may still have n weak. The support checker confirms precisely these forced strong sets, using only exact separating lines for the eight integer exponents.

## 5. Independent test angles: near and far

If ut,vt have the same real residues as uc,vc, delta_u,delta_v belong to the tensor infinitesimal ideal. The exact five-feature Gram satisfies

    res G(delta)=diag(res Q0,res C) > 0.

The bounded-Gram lemma therefore proves the full-parent tensor SOS. This is where finite polynomial transport succeeds while fixed contact groundstates fail: it cancels each state's first-order reserve, rather than merely their sum.

If the positive finite test residues differ from the source-contact residues, consider the real-residue Laurent function. Its positive exponent support spans the plane; the sum of exponent monomials is strictly convex in log U,log V. Its stationary zero at the source residue is therefore unique, and the determinant at the testing residue is strictly positive. The three hard state directions remain positive by the explicit core restriction above. Thus res P at the test is positive definite, and the bounded-Gram lemma applies directly to the four original state coordinates. This proves the stated result for all positive finite-unit independent testing angles.

This near/far argument does not dispatch independent testing angles with zero or infinite residue. Such angle regimes are not compactly covered by a strict-positive exit, because their limiting state matrices can acquire kernels. Likewise d losing residue or source angles losing residue invalidates the unit hard block and/or the covariance argument. Those are precisely the remaining weighted regimes for this shortcut.

## 6. Network meaning and exact check

In a finite invertible gain-network frame, put H=diag(h_contact), L=H G_contact H and b_j=H G_j h_contact. Stationarity gives total current sum_i(b_j)_i=0. The same state derivative is the source-only grounded-Laplacian solution

    L t_j = -b_j,    (t_j)_ground=0.

Kirchhoff's tree formula shows its inverse is a ratio of source-only finite forest sums. Whenever a spanning tree has positive residue this inverse is bounded. The moving state is H[1+t_u delta_u+t_v delta_v]. The reduced angle stiffness is the bare angular stiffness minus the electrical relaxation energy. The determinant covariance proves that the resulting two physical angle modes are strictly positive; it does not ask that the unfunded row reserves individually have a sign.

check_moving_graph_frame.py uses the literal rational C1 contact already verified in the prior pass. It constructs this moving network state, divides every monomial of the entire parent, verifies the exact full-parent five-feature identity, verifies both strict residue blocks by exact Sylvester minors, and verifies the determinant-covariance normalization. It exports the complete finite polynomial Gram, not merely its Hessian. check_original_moving_frame.py separately performs the cleaner original-state construction of Sections 2-3, verifying its determinant-one frame and its full 154-term Gram of degree at most four. The original hard block has exact Sylvester minors 3110/143, 1378800/143, 98088000/11; the two-angle curvature has leading minor 10213280/53131 and determinant 4607973/1675. No numerical SDP or sampling is used.
