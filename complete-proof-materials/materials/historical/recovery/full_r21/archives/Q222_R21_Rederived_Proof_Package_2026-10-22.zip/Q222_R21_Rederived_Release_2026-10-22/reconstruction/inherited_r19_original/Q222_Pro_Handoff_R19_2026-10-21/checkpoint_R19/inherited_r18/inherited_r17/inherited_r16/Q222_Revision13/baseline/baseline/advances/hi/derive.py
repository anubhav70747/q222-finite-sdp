import sympy as s
q,y,R,E,t=s.symbols('q y R E t',positive=True)
H=1-q*E; B=H+y*t; K=B+R-E; j=1+R-t
z=1/q; aa=q*y; b=q*B; r=q*R
Delta=1+(1+z)*b+z*(1+z)*b*b+2*z*(1+z)*b*r+z*z*r*r+2*z*r+aa*z*((1+z)*b+1+z*r*(2-r))
Ac=1+z*r; S=Ac+aa*z*t
N=(1+z)*(b+r)*(b+aa*(1-t))-aa*(1+aa*z)*(1-r)*t
n=((b+r)*Ac*S-r*Delta)/(2*r*Delta)
m=(1+aa*z)*(1-r)*Ac*S/(2*((1+z)*b-(1-r+aa*z*t))*Delta)
C=Ac*N/(2*aa*t*Delta)
A=aa*Ac*(b+r)*S/(2*(b-aa*t)*Delta)
D=(1+z)*(b+r)*(b-aa*z*r)*S/(2*aa*j*Delta)
a=z*z*(b+r)*N/(2*(1-z*(b-aa*t))*Delta)
for nm,ex in [('Delta',Delta),('N/q',N/q),('n',n),('m q K',m*q*K),('C y t',C*y*t),('A/qy',A/(q*y)),('D y j',D*y*j),('alpha q E',a*q*E)]:
 print(nm, s.factor(ex), 'res',s.factor(ex.subs({q:0,y:0})))
P,V,x,Q=s.symbols('P V x Q', real=True)
c=(1-R)/R; tt=P*V
f=c*x*x+(P*P+V*V)*(x-tt*Q)**2+(R+1)**2*Q*Q+2*(R+3)*tt*x*Q-(R+3)*tt*tt*Q*Q
sos=(P-V)**2*(x-tt*Q)**2+2*tt*(x+(R+1-tt)*Q)**2+c*(x+R*tt*Q)**2+(R+1)**2*(tt-1)**2*Q*Q
print('LEADING IDENTITY',s.factor(f-sos))
