# Precise remaining checklist — revision 6

**The C1 UI subdomain is now proved at all tests. Six narrowed residual domains remain; the global analytical proof is unfinished.**

Every row below is intersected with original physicality and the complement of all prior admissions and exact symmetry images. A residual listing is not a nonemptiness claim.

- [x] C1 UI: full parent, every state normal, arbitrary opening and testing rates, all projective tests.
- [x] C1 common remote mechanisms: new quantified reductions for C1.1, specified C1.4 parts, and both UH patterns.
- [x] C2 II/HH: common exact source and full-state normal reduction. This is not a positivity admission.
- [x] C2 HI: exact first-normal reduction and full normal SOS in a second parity frame. The soft allocation remains open.

## C1.1

Original native k,zeta infinitesimal, eta unbounded; all three e types and all permitted openings.

**New result:** The full-parent two-adjacent-event theorem covers every test with u not infinitesimal.

**Exact remaining testing domain:** Only u infinitesimal, every projective v, intersected with all prior admissions.

- [ ] Use exact NI3 source formulas for all e types; preserve independent k,eta and opening rates.
- [ ] Construct the full-parent bounded root allocation on the small-u strip, including all state normals and every v chart.
- [ ] Join the strip to CE1–CE10, retaining literal D=0 or beta=0 wherever allowed.

## C1.4

Original native k infinitesimal, zeta noninfinitesimal, L=k²zeta; arbitrary positive eta.

**New result:** Shared adjacent-event and matched weak-event frames reduce two of the four exact source subdomains.

**Exact remaining testing domain:** L unbounded: u bounded,v unbounded. L infinitesimal,eta unbounded: u infinitesimal. L unit and L infinitesimal,eta bounded: unchanged complement of inherited admissions.

- [ ] L unbounded (NI4): complete bounded-u/unbounded-v full-parent conductor.
- [ ] L unit (NI5): prove exclusion or full-parent coverage at every remaining independent test.
- [ ] L infinitesimal,eta bounded (NI6): prove exclusion or full-parent coverage at every remaining independent test.
- [ ] L infinitesimal,eta unbounded (NI6): complete the small-u strip.
- [ ] Retain arbitrary openings and both permitted literal coefficient boundaries, then join the four source alternatives.

## C1.5

Native k unit; only actual UH and its exact stabilizer images remain. Actual UI is now admitted at all tests.

**New result:** C1 UI full-parent all-tests theorem; both actual UH source patterns have a common remote complement.

**Exact remaining testing domain:** Actual UH: u a bounded nonzero unit and v projectively unbounded, for both NI9 and NI10 source patterns.

- [ ] For NI9 (eta unbounded,zeta unit), construct the original-parent conductor on the ordinary-u/unbounded-v strip.
- [ ] For NI10 (zeta unbounded), do the same with the exact weak-event scaling C,m~1/zeta and A,alpha bounded below by constants times zeta.
- [ ] Control every state normal and arbitrary opening rate; retain allowed D=0/beta=0 boundaries.
- [ ] Join CE1–CE21 and the completed UI theorem; restore exact stabilizer images without silently reimposing k<=1.

## C2.W.HH

Original directed weak-C HH, alpha strong, n>=0, outside inherited four-product and real-rational-curve admissions.

**New result:** Exact reflection identifies strong-C/weak-alpha actual II, precisely the B=H+L infinitesimal face. Complete state-normal and angular contact-ideal identities are printed.

**Exact remaining testing domain:** Every independent test not already admitted; the common reduction itself makes no new testing admission.

- [ ] Normalize the B-infinitesimal II face so every coefficient in the chosen root Gram is bounded; 1/B and m B²/z² are not declared bounded.
- [ ] Allocate the DI6 mixed angular term together with all three DI4 first normals and the full DI3 hard quadratic.
- [ ] Prove strict residue or exact SOS at arbitrary relative source/testing rates, retaining n=0 and all openings.
- [ ] Supply original-parent literal projective endpoint joins; higher-degree graph homogenization is not an endpoint proof.
- [ ] Reflect back with the weak-event orientation explicitly recorded and prove exhaustive admission.

## C2.S.II_HH

Original strong-C,strong-alpha actual II/HH residual orbit, arbitrary source shape, n>=0, outside inherited admissions.

**New result:** Actual II is precisely the B-unit face; full parity graph, complete normal SOS/ideals, and contact-centered removal of all unbounded source coefficients at bounded affine tests.

**Exact remaining testing domain:** Every independent test not already admitted; boundedness of the displayed remainder is not positivity.

- [ ] Choose legal weighted angular and state roots for the exact DI5–DI6 identity, retaining every cross term.
- [ ] Use DI8–DI9 centered packets to obtain a strict bounded Gram or exact SOS at all bounded affine tests, without assuming u/sqrt(z) or v/sqrt(y) bounded.
- [ ] Resolve every r,j,1-H opening and literal n=0.
- [ ] Prove original projective endpoint joins and restore the exact II/HH reflection; graph degree must not erase endpoint states.
- [ ] Join all independent source shapes and testing charts.

## C2.S.HI

Original actual HI source. Only p=1/u and v both nonzero infinitesimal remain, up to exact sign gauges; literal axes already admitted.

**New result:** Exact full-parent remainder H6.2; geometric first-normal defects allocated to large centered roots with identity hard-block residue, independent of openings. Exact polynomial parity graph H6.8 has complete normal SOS H6.9.

**Exact remaining testing domain:** The same nonzero small-p/small-v corner; no HI domain admission follows from the new identities alone.

- [ ] Allocate the remaining 4(1-lambda_D)v U x and 4(1-lambda_m)p V x couplings jointly with the explicit soft remainder S and exact dependencies H6.1.
- [ ] Either finish that frame or use H6.8–H6.9 and print/allocate its scalar and every first-normal term.
- [ ] Prove bounded strict residue or exact SOS for independent p,v,q,y rates and every E,t,j,K opening; mixed inverses or a bound on p/sqrt(q),v/sqrt(y) are unavailable.
- [ ] Retain literal n=0, where sqrt(n)x vanishes, and the R~rho relation through R infinitesimal.
- [ ] Join the existing remote theorem and literal axes, then restore sign gauges.

## Acceptance gates for each uncompleted admission

- [ ] G1 Original source entry, signs, and every bounded ratio.
- [ ] G2 Exact full-parent decomposition preserving actual contact and jets.
- [ ] G3 Admissible roots; only pure-source/pure-test inverses or radicals.
- [ ] G4 Every first state normal and every hard quadratic coupling.
- [ ] G5 Strict residue or exact SOS; resolve every equality case.
- [ ] G6 All independent projective tests, signs, real/complex states.
- [ ] G7 Literal retained coefficient boundaries and all positive opening rates.
- [ ] G8 Analytical review plus narrowly scoped exact algebra corroboration.
- [ ] G9 Admit only the proved quantified domain and exact symmetry images.

## Global joins

- [ ] U1: prove exact exhaustion after all six domains close.
- [ ] U2: apply the unchanged finite-lift bridge.
- [x] U3: deliver this reconciled cumulative package.

No evaluated global affine pencil is asserted. The algebra receipts corroborate identities, not missing positivity or coverage.
