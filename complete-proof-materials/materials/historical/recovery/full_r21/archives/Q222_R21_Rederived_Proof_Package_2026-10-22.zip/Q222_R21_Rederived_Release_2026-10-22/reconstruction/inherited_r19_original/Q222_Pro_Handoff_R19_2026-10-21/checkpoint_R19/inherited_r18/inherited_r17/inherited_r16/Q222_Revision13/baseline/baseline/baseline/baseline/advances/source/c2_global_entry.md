# Global positive-chart entry for canonical C2 contacts

This is a source-entry theorem, not a tensor-SOS theorem. It removes a sign-chart hypothesis from the residual-source ledger. It uses the exact inherited parent, curvature, and C1 triple-omission sign theorems listed below. Every analytic argument is first carried out over the reals; the final polynomial implication transfers to every real closed coefficient field.

## Theorem

Suppose the original canonical physical parent has d>0, λ=β=0, m,C,A,D,α>0 and n≥0. Suppose it has an actual finite noncommuting stationary zero. Choose positive half-angle gauges u,v>0. Its kernel has Z≠0; normalize Z=1. Then

W>0, X<0, Y>0, uW−Y>0, 1−vY>0,
Rm=vW−X+uvY−u>0, RD=uW+uvX−Y−v<0,
X+u>0, W+vX>0.

Consequently every such contact enters the original positive rational C2 chart, with no residue, angle-ratio, event-scale, or weak-event assumption:

c=u, a=v/u, b=aW, r=−X/u, t=(uW−Y)/v,
h=aY/u, g=Rm/u, j=−RD/v.

These quantities satisfy a,c,b,t>0, 0<r<1, h,g,j>0,
1−c²h=1−vY>0, b−a²c²r=a(W+vX)>0.
They obey exactly h=b−a²t, g=(1+c²)b−(1−r+a²c²t), j=1+c²r−t.
After d=1, the six unchanged rational formulas in `contact/source_formulas.tex` equal the original coefficients. Literal n=0 is included.

## Exact dependencies

All paths below are relative to `output/Q222_Checklist_Advance_2026-10-18/`.

1. `baseline/baseline/current/prior/inherited/physical_core.tex`: full parent (P), positive definiteness on Z=0 for d>0 and uv≠0, nonnegative outer determinant coefficients, coercivity iff omitted events are pairwise compatible, and stationary-contact sufficiency by the Laurent determinant.
2. `baseline/baseline/current/prior/inherited/structural_terminals.tex`, Automatic angular curvature: every physical finite noncommuting d>0 zero has positive definite Hessian in three projective-state and two angle coordinates.
3. `baseline/baseline/current/prior/inherited/C1_GLOBAL_SIGN_ENTRY.md`, sections 2, 6, 7: negative-core Schur identity, the exact β=0 C1 triple-omission sign theorem, including all amplitude signs. No C2 chart assumption is used in that proof.
4. `baseline/baseline/current/contact/source_determinant.tex`: determinant of the six-column original stationary system.
5. `baseline/baseline/current/contact/source_formulas.tex`: the original six coefficient formulas and their stationary identities.

The proof below restates the real connectedness and maximal-contact argument, rather than assuming that all contacts lie on a connected locus.

## 1. A uniquely defined real maximal-contact graph on the entire positive orthant

First let n,m,C,A,D,α all be strictly positive real numbers, and write w for this six-tuple. Let d_*(w) be the maximum d≥0 for which the original source is physical.

At d=0, the event form is positive definite for every u,v>0: its n, A, C, α amplitudes force successively X=Y=W=Z=0. The six noncentral C2 Laurent coefficients q01,q02,q10,q12,q20,q21 are strictly positive; their exponents span the plane and contain zero in the interior of their convex hull. The Laurent determinant is therefore strictly convex in logarithmic variables and coercive. Its minimum at d=0 is strictly positive.

For completeness, positive minimum is stable under a small coefficient perturbation. If μ=min L>0, choose ε>0 so that each new positive outer coefficient is at least (1−ε) times the old one and the central coefficient changes by at most ε. Then L_new≥(1−ε)L+εh−ε, uniformly at every positive angle, so its minimum remains positive for sufficiently small ε. This applies both at d=0 and at any fixed positive d. Thus d_*(w)>0. A fixed CHSH-violating test has negative signed core and finite positive event contribution; testing it bounds admissible d above. Closedness gives attainment of the finite maximum.

At d=d_*, the Laurent minimum must be zero: otherwise the same supported-perturbation estimate allows d to increase. Strict logarithmic convexity gives exactly one squared-angle minimizer U,V>0, and hence one positive-angle pair u,v. Positive definiteness on Z=0 gives a simple kernel with Z≠0, normalized uniquely by Z=1.

The event form is positive definite at every u,v>0 even if n=0, because A,C,α,m alone have no common nonzero kernel. Therefore at any zero contact the signed-core expectation is strictly negative. The inherited negative-core Schur identity says H≥0 when WZ≤0 for positive u,v; hence W>0 in our gauge.

Every physical noncommuting zero for the fixed w lies on d=d_*: raising d at that same state and angle immediately makes the slack negative, while physicality gives d≤d_*.

Let z=(W,X,Y,u,v), with Z=1, and use the polynomial full parent f(d,w,z). At its contact, the equations (∇_z f,f)=0 have derivative with respect to (z,d)

[ Hess_z f, ∂d∇_z f ; 0, H ],

which is invertible: the inherited automatic-curvature theorem makes Hess_z f positive definite, and H<0. The real analytic implicit-function theorem therefore supplies a local analytic branch (z,d) as w varies.

This branch is physical, rather than merely a stationary formal solution. For nearby w, its three positive transverse state eigenvalues stay positive; its determinant is zero with zero angular derivatives, and its noncentral Laurent coefficients remain positive. Logarithmic convexity makes this stationary zero a global determinant minimum. The inherited inertia criterion and homogeneous endpoint continuity give positivity of the full parent for every measurement. Its negative core makes this d maximal. It therefore equals the uniquely defined (z(w),d_*(w)). Local branches agree on overlaps and yield analytic functions on the connected orthant R^6_{>0}.

## 2. The amplitude walls cannot be crossed

At a zero contact, deleting a positive event whose amplitude vanishes preserves every kernel and angular first derivative equation. The state restriction on Z=0 remains positive definite because d>0. Hence the resulting parent is positive semidefinite at the same point with a simple kernel, and its Laurent determinant has stationary zero. Convexity and the inertia criterion make the deleted source physical globally.

A physical noncoercive source cannot have a finite noncommuting zero: at such a zero automatic angular curvature makes the active outer exponents span the plane, and stationarity expresses zero as a strictly positive combination of all active exponents. Zero is then in the interior of their convex hull, contradicting noncoercivity. This derives the needed routing contradiction from the explicitly inherited results.

Apply this deletion argument to the following putative zero amplitudes:

| Zero amplitude | Delete coefficient | Exclusive omitted pair |
|---|---|---|
| Y | A | λ,A |
| uW−Y | C | β,C |
| vY−1 | α | λ,α |
| Rm | m | λ,m |
| RD | D | β,D |

None can vanish on the positive-orthant contact graph. X cannot vanish either. If X=0, deleting n preserves contact and physicality as above, and produces λ=n=β=0 with the other five retained events positive. This is precisely the admitted C1 triple-omission face. Its inherited exact sign theorem gives X=u(θ−1)<0, a contradiction.

The nonzero continuous amplitudes have constant signs on the connected orthant. The exact positive seed

d=1, n=1/8, m=D=3/8, C=α=1/6, A=5/8,
(u,v;W,X,Y,Z)=(1,1;1,−1/4,1/4,1)

fixes all signs. Its full parent value and all six first derivatives vanish. Its finite contact is physical by the original inertia/convex-Laurent argument. The seed's amplitudes are

X=−1/4, Y=1/4, uW−Y=3/4, vY−1=−3/4, Rm=1/2, RD=−1/2.

`check_c2_global_entry.py` reconstructs the full original parent over exact rational polynomial arithmetic, verifies those identities, and checks the positive principal minors. The checker does not replace the connectedness argument.

## 3. The two omitted-event amplitude signs

There are no β or λ packets to delete, so their signs need a separate argument. The exact original X equation is

0=F_X=8nDuDv X−8m Rm+4(2D+d)uv RD+4d Dv(X+u).

The first term is nonpositive, and the next two are strictly negative by the signs already proved. Hence X+u>0.

Apply the same universal statement to the exact reflected C2 contact

(u',v';W',X',Y',Z')=(1/v,1/u;Z,X,Y,W),

with m↔D and C↔α. Its last coordinate W is positive. After normalizing that coordinate, the inequality X'+u'Z'>0 is X+W/v>0. Thus W+vX>0. This uses the full-parent homogeneous reflection, not an independent event-mask permutation.

## 4. Literal n=0 and real-closed-field transfer

For n=0 no limiting optimizer or source continuation is used. The source itself lies on λ=n=0, β=0, with m,C,A,D,α>0. The inherited C1 global sign-entry theorem, sections 6–7, applies to this exact finite contact and supplies all the signs stated here. Its normalization C=2 is a positive scalar rescaling and does not change the contact or signs.

The resulting assertion is a finite first-order implication in real arithmetic: coefficients and contact coordinates satisfy positivity, polynomial kernel/stationarity equations, and quantified polynomial physicality. The conclusion is the finite list of strict polynomial sign inequalities. Transfer therefore proves it over every real closed coefficient field, without analytic continuation or non-Archimedean compactness assumptions there.

## 5. Exact rational source recovery

The definitions in the theorem yield every stated positive chart inequality. In particular 0<r<1 follows from X<0 and X+u>0. With z=c², the original Δ has the positive expression

Δ=1+(1+z)b+z(1+z)b²+2z(1+z)br+z²r²+2zr
  +a²z[(1+z)b+1+zr(2−r)]≥1.

The inherited six-column stationary determinant is

4^6[−64ac^6 rgt h j(1−zh)(1+c²)²(1+a²c²)²Δ],

which is strictly nonzero, also when n=0. Since the six original rational formulas satisfy the unchanged six stationary equations, they are their unique solution. This proves exact original-coefficient entry and does not replace d or any event weight by a residue approximation.

No all-tests certificate for the now charted residual scales or angle types follows solely from this entry theorem.
