# R9 A-only-unbounded C2: source bounds

Same-system derivation for the targeted five-root audit, not external independent verification.

Assume B=H+L and z,y,B positive infinitesimals; r,1-r,z/B,y/B,G/B,j,L/B positive bounded units; H/y infinitesimal; and the unchanged original rational C2 source with d=1. Write h=H/B, a_c=1+zr, S_c=a_c+L, T_c=B+zr, and Delta for its source denominator.

Then h=(H/y)(y/B) is infinitesimal, L/B=1-h has residue one, and a_c,S_c,1-H are units. All terms in the displayed Delta are nonnegative and Delta/B is a positive bounded unit because z/B,y/B,r are bounded. Likewise T_c/B=1+(z/B)r is a unit.

For M=(1+z)T_c(H+y)-z(1+y)(1-r)L and G=T_c-z(1-H), the exact identity

    M-yG = H(1+z)T_c + z[yj+rL(1+y)]

shows M/B^2 >= (y/B)(G/B), a positive unit lower bound. Its defining expression also gives a bounded upper bound. Thus M/B^2 is a unit.

The unchanged source formulas now show:

- m is a positive bounded unit;
- C,D are positive bounded units;
- alpha/B^2 is a positive bounded unit;
- A h is a positive bounded unit;
- A is unbounded, 1/sqrt(A) is infinitesimal, A h^2 and sqrt(A)h are infinitesimal.

The n coefficient is bounded and nonnegative by the original source hypothesis. In fact its numerator divided by B has residue 1-r, so n is a unit in this narrower chart, though strictness of the proposed Gram needs only n+1/2 a unit.

The proposed residue block on (xi,R2) has determinant m(n+1/2)>0. The remaining proposed pivots 1, a=(C+D+1/2)(1-h)^2+A h^2, and alpha/B^2 are positive units. This verifies strictness once the exact full-parent Gram and bounded entry formulas have been supplied; it is not yet an admission by itself.
