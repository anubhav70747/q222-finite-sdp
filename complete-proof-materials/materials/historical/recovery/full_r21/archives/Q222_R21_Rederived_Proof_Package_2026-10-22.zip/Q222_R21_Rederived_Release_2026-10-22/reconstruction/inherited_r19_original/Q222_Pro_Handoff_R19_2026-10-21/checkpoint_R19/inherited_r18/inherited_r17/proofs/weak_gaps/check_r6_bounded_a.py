#!/usr/bin/env python3
import sympy as s
import json
from pathlib import Path
out={}
def ck(name,z):
    assert s.cancel(z)==0,(name,s.factor(z));out[name]=True
u,v,W,X,Y,Z,e,h,t,K,k,n,A,C,D=s.symbols('u v W X Y Z e h t K k n A C D')
U=u*u;V=v*v;half=s.Rational(1,2);l=1-h
n0=e*e/(2*(1-e*e));A0=t/(2*h*(1+e));C0=(h+t-e*l)/(2*l*(1+e));D0=1/(2*(1+e)*(t-l));kap=1/(2*(1+e))
ck('local_cap_block_determinant',(n+half+K)*(K+2*k)-(K+k)**2-(K*(n+half)+2*k*(n+half)-k*k))
ck('local_source_positive_block_relation',n0+half-kap/(1-e))
M=v*W-X+u*v*Y-u*Z;J=u*W+u*v*X-Y-v*Z
base=n*(1+U)*(1+V)*X*X+C*(1+V)*(u*W-Y)**2+A*(1+U)*(1+V)*Y*Y+D*J*J+half*(J*J+(1+U)*(v*Y-Z)**2+(1+V)*(X+u*Z)**2-(1+U)*(1+V)*Z*Z)
res=s.expand(base.subs(X,v*W+u*v*Y-u*Z))
G=s.hessian(res,(W,Y,Z))/2
# Avoid expensive rational-parametric determinant expansion.
raw=s.factor(G.det(method='domain-ge')/((1+U)**2*(1+V)**2))
poly=s.Poly(s.cancel(raw),u,v)
su={n:n0,A:A0,C:C0,D:D0}
det=sum(s.factor(co.subs(su))*u**ex[0]*v**ex[1] for ex,co in poly.terms())
den=8*h*(1-e)*(1+e)**3*l*(t-l)
target=((h+t)*(e*t*U-V)**2+(h+t-e*l)*(t*(h+t-e)*U*U*V+h*U*V*V))/den
ck('complete_finite_remote_kernel_determinant',det-target)
p,q=s.symbols('p q')
up=s.cancel(p*p*base.subs(u,1/p)).subs(p,0)
ck('single_u_reciprocal_kernel',up.subs(Z,v*Y)-(n*(1+V)*X*X+C*(1+V)*W*W+A*(1+V)*Y*Y+(D+half)*(W+v*X)**2))
vq=s.cancel(q*q*base.subs(v,1/q)).subs(q,0)
ck('single_v_reciprocal_kernel',vq.subs(W,-u*Y)-((n+half)*(1+U)*X*X+C*(1+U)**2*Y*Y+(A+half)*(1+U)*Y*Y+D*(u*X-Z)**2))
P,Q=s.symbols('P Q')
core=half*((X-P)**2+(Y-Q)**2+2*X*P-P*P)
double=n*X*X+C*W*W+A*Y*Y+D*(X-P)**2+K*(Y-Q)**2+core
ck('complete_double_reciprocal_residue',double-((n+half)*X*X+C*W*W+A*Y*Y+D*(X-P)**2+(K+half)*(Y-Q)**2))
payload={'status':'PASS','count':len(out),'checks':out,'scope':'R6 all tests on bounded a=z/B, equivalently unit 1-r. Entire R6 is not admitted: a unbounded remains.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps(payload,indent=2))
