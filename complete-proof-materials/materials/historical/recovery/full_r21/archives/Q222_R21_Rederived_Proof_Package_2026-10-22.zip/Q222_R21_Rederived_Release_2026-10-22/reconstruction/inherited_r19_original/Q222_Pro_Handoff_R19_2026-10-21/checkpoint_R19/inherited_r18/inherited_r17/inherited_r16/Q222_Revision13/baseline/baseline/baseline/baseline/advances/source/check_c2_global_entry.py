"""Exact rational seed/full-parent checks; analytic exhaustion is in c2_global_entry.md."""
from fractions import Fraction as Q
from collections import defaultdict
import json
from pathlib import Path
N=6
class P:
 def __init__(self,x=0): self.a=x if isinstance(x,dict) else ({(0,)*N:Q(x)} if x else {})
 def __add__(self,o):
  o=o if isinstance(o,P) else P(o); a=defaultdict(Q,self.a)
  for k,v in o.a.items(): a[k]+=v
  return P({k:v for k,v in a.items() if v})
 __radd__=__add__
 def __neg__(self): return P({k:-v for k,v in self.a.items()})
 def __sub__(self,o): return self+-P(o) if not isinstance(o,P) else self+-o
 def __rsub__(self,o): return -self+o
 def __mul__(self,o):
  o=o if isinstance(o,P) else P(o); a=defaultdict(Q)
  for k,v in self.a.items():
   for l,w in o.a.items(): a[tuple(x+y for x,y in zip(k,l))]+=v*w
  return P({k:v for k,v in a.items() if v})
 __rmul__=__mul__
 def __pow__(self,n):
  out=P(1)
  for _ in range(n): out=out*self
  return out
 def derivative(self,i):
  a={}
  for k,v in self.a.items():
   if k[i]: l=list(k); l[i]-=1; a[tuple(l)]=v*k[i]
  return P(a)
 def at(self,pt):
  out=Q(0)
  for k,v in self.a.items():
   for x,e in zip(pt,k): v*=x**e
   out+=v
  return out

def det(a):
 a=[r[:] for r in a]; out=Q(1)
 for i in range(len(a)):
  j=next((j for j in range(i,len(a)) if a[j][i]),None)
  if j is None:return Q(0)
  if j!=i:a[i],a[j]=a[j],a[i];out=-out
  pivot=a[i][i];out*=pivot
  for j in range(i+1,len(a)):
   f=a[j][i]/pivot
   for k in range(i+1,len(a)):a[j][k]-=f*a[i][k]
 return out
u,v,W,X,Y,Z=[P({tuple(int(j==i) for j in range(N)):Q(1)}) for i in range(N)]
Du=1+u*u;Dv=1+v*v;Rm=v*W-X+u*v*Y-u*Z;RD=u*W+u*v*X-Y-v*Z;R=u*W-Y;B=X+u*Z
n,m,C,A,D,alpha=Q(1,8),Q(3,8),Q(1,6),Q(5,8),Q(3,8),Q(1,6)
H=2*(RD**2+Du*(v*Y-Z)**2+Dv*B**2-Du*Dv*Z**2)
F=4*n*Du*Dv*X**2+4*m*Rm**2+4*C*Dv*R**2+4*A*Du*Dv*Y**2+4*D*RD**2+4*alpha*Du*(v*Y-Z)**2+H
pt=[Q(1),Q(1),Q(1),Q(-1,4),Q(1,4),Q(1)]
grad=[F.derivative(i).at(pt) for i in range(N)]
assert F.at(pt)==0 and not any(grad)
# Verify the exact F_X identity at arbitrary testing variables for this seed.
row=8*n*Du*Dv*X-8*m*Rm+4*(2*D+1)*u*v*RD+4*Dv*B
assert not (F.derivative(3)-row).a
projective=[2,3,4,0,1]
Hess=[[F.derivative(i).derivative(j).at(pt) for j in projective] for i in projective]
minors=[det([r[:j] for r in Hess[:j]]) for j in range(1,6)]
assert all(x>0 for x in minors)
# Full-parent state matrix on Z=0, useful independent inertia check.
state=[2,3,4]
state_minors=[det([[F.derivative(i).derivative(j).at(pt)/2 for j in state[:q]] for i in state[:q]]) for q in range(1,4)]
result={'seed_coefficients':{k:str(x) for k,x in zip(['d','n','m','C','A','D','alpha'],[Q(1),n,m,C,A,D,alpha])},'contact':[str(x) for x in pt],'full_parent_value':str(F.at(pt)),'full_gradient':[str(x) for x in grad],'full_hessian_leading_minors':[str(x) for x in minors],'state_Z_zero_leading_minors':[str(x) for x in state_minors],'core_value':str(H.at(pt)),'signed_amplitudes':{k:str(p.at(pt)) for k,p in [('W',W),('X',X),('Y',Y),('R',R),('1-vY',Z-v*Y),('Rm',Rm),('RD',RD),('B',B),('W+vX',W+v*X)]},'result':'PASS; these finite identities support but do not prove the analytic global-entry theorem'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
