"""Scoped independent identities for the triangular full normals."""
import json
from pathlib import Path
import sympy as s

u,v,W,X,Y,Z,n,m,C,A,D,alpha,eta,g=s.symbols('u v W X Y Z n m C A D alpha eta g')
Du,Dv=1+u*u,1+v*v
M=v*W-X+u*v*Y-u*Z
J=u*W+u*v*X-Y-v*Z
F=(4*n*Du*Dv*X**2+4*m*M**2+4*C*Dv*(u*W-Y)**2
   +4*A*Du*Dv*Y**2+(4*D+2)*J**2+(4*alpha+2)*Du*(v*Y-Z)**2
   +2*Dv*(X+u*Z)**2-2*Du*Dv*Z**2)
graph={X:v*(1+eta*u*u)*W-(1+g)*u*Z,Y:eta*u*W}
H=1-eta+v*v*(1+eta*u*u)
AX=(8*n*Du*Dv+4*Dv)*(1+eta*u*u)+(8*D+4)*u*u*H
BX=-8*n*Du*Dv*(1+g)-8*m*g-(8*D+4)*v*v*(1+(1+g)*u*u)-4*g*Dv
ew=((8*D+4)*(u*u*v*v-1)*H+(8*alpha+4)*Du*v*v*eta
    +8*n*v*v*Du*Dv*(1+eta*u*u)+4*v*v*Dv*(1+eta*u*u))
ez=v*((8*D+4)*(1+g-v*v-(1+g)*u*u*v*v)-(8*alpha+4)
      -8*n*Du*Dv*(1+g)-4*g*Dv)
checks=[]
def eq(name,lhs,rhs=0):
    assert s.expand(lhs-rhs)==0,name
    checks.append(name)
eq('full X normal',s.diff(F,X).subs(graph,simultaneous=True),v*W*AX+u*Z*BX)
eq('full triangular Y normal',(s.diff(F,Y)+u*v*s.diff(F,X)).subs(graph,simultaneous=True),
   8*Dv*(A*eta*Du-C*(1-eta))*u*W+u*W*ew+(u*u*ez+8*v*(D-alpha))*Z)
Hxx=s.diff(F,X,2)/2;Hxy=s.diff(F,X,Y)/2;Hyy=s.diff(F,Y,2)/2
eq('m cancels from triangular mixed hard coefficient',s.diff(Hxy+u*v*Hxx,m))
eq('m cancels from triangular Y hard coefficient',s.diff(Hyy+2*u*v*Hxy+u*u*v*v*Hxx,m))
result={'result':'PASS','number_of_checks':len(checks),'checks':checks,
        'scope':'Independent exact reconstruction of the entire original C2 parent; confirms two full normals and two triangular m cancellations. Does not establish global source exhaustion.'}
target=Path(__file__).with_name('g_audit_checks.json')
target.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
