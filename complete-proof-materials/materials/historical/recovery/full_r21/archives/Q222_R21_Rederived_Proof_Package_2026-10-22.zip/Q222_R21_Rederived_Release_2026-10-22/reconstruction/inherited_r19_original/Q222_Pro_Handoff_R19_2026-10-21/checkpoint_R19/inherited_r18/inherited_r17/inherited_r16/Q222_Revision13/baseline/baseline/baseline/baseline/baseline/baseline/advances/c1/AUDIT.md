# Independent audit of the arbitrary-state-ratio C1 extension

## Verdict

**Pass.** The new argument closes the native C1 source domain in which `k` is a positive bounded unit and both `eta=f^2` and `zeta=g^2` are positive infinitesimals, for every positive state ratio `s=g/f`, every positive opening `a,t,M,J`, and every independent projective test. This is an extension of the already proved unit-`s` domain. Combined with the inherited infinitesimal-`k` theorem after the exact `0<k<=1` orientation, it covers every positive oriented `k` when both `eta` and `zeta` are infinitesimal. The sign-normalization wording correction noted below was applied by the author.

The audit is of the new argument and its explicitly used conductor/outer-chart identities. It does not independently reprove every historical theorem imported by the cumulative package, and does not certify the remaining global C1/C2 source complement.

## Materials checked

- `arbitrary_state_ratio.tex` in this directory.
- The exact native source, full-parent identity, retained packets, inverse state coordinates, all first normals, hard block, and contact balances in `analysis_atlas/iconic_c1/source_definitions.tex`.
- The unlocalized first- and second-order contact lifts in `analysis_atlas/iconic_c1/contact_conductor_proof.tex`.
- The strict two-pairing circuit frame in the reconciled package.
- The two outer-current identities and the unit-current state chart in the inherited C1 proofs.
- The actual-contact transport and selected contact-system determinant in `analysis_atlas/analytical_push_c1/entry_and_remainder.tex`.
- The reflection/dispatch checker source and the conductor checker source and output, as corroboration only. Their PASS outputs are not premises of the proof.

## Specific checks

1. **Reflection and source transport.** The displayed homogeneous whole-parent reflection includes every event and the signed core. The transformed contact has unnormalized coordinates `(k H_g, -s E, Q_c, k s H_f)`. Hence its normalized native parameters are exactly those in (AS5). The identities `H_g-Q_c=zeta M` and `H_f-E=eta J` make the reflected contact signs strict. The displayed formulas for `M'` and `J'` preserve positive gaps even if their residues vanish. Both new squared shape scales remain infinitesimal, `k'=1/k` remains a bounded unit, and an unbounded `s` becomes infinitesimal `s'`. The selected contact-system determinant has only positive factors on this entry, so the reflected native source equals the reflected coefficient vector after positive normalization. No assumption `k'<=1` is needed for the ordinary-unit theorem itself.

2. **Positive original coefficients.** All native coquotients have the claimed positive unit residues with arbitrary bounded-unit `k`. Formula (AS2) shows that the two subtracted coefficients `D` and `beta` remain strictly positive. Small openings occur only in retained square coefficients; no bound on their inverses is used in the bounded remainder.

3. **Outer test charts.** The exact harmonic-mass cancellation gives `gamma=A g_c/d^2` a positive unit with residue `1/(4 K^3)`, while `d/c` and `d/D` are infinitesimal. The first current identity covers every chart with bounded `1/v`. In the reciprocal-Alice, small-Bob chart, the second identity needs only `4 gamma_bar-c_u_bar^2>0`; here `c_u_bar=0`. Thus it applies even though the stronger sufficient hypothesis `gamma_bar>=1/4` from the historical lemma is unavailable. The normalized homogeneous identities include literal infinities.

4. **Complementary state chart.** For bounded `u`, infinitesimal `v`, and unit `w`, `Q=(1+u^2)w` is a pure testing unit. The exact unit-current identity uses `Delta Z/Q` and `Delta^2 eta Z^2/Q^2` as its only negative correction factors, both infinitesimal when `s` is infinitesimal. Its diagonal coefficients remain positive units for arbitrary bounded `u` and bounded-unit `k`. If `w` is infinitesimal and the testing core is negative, its residue forces both currents `X+uZ` and `uW-Y` to have zero residue. If `Z` were also infinitesimal, the inverse relations would make every normalized state coordinate infinitesimal, a contradiction. Thus `Z` is a unit.

5. **Weight-zero variables are harmless.** Under weights `(1,0,1,0,0,0,1,3)` on `(delta,k,b,a,t,u,w,v)`, every root `x,y,z,h` and each circuit root has weight four. Contact substitution preserves weight, including the weight-zero substitution `u=k`. The monic division and conductor repair preserve the appropriate weight differences; neither divides by `k`, a gap, a source scale, or a mixed source/testing element. Positive coefficient weight therefore means a positive power of at least one of `delta,b,w,v`, all infinitesimal; bounded weight-zero factors do not change the conclusion.

6. **Factored scalar weights.** The bounds `Q-K=O(2)`, `T_n-K^2=O(4)`, `V_n-K^2=O(4)`, `Y_n=O(1)`, and `B_n+K T_n=O(4)` give exactly the five weight-eight contributions

   `8 K^14 D_u [D_u(A_0^2+B_0^2)+K(C_0^2+D_0^2)-2K^2 B_0 C_0]`.

   All other scalar terms have weight at least ten. The two coquotient-difference identities give normal weights at least eight and six. Consequently the explicit conductor construction gives correction-coefficient weights at least two, four, and two, as asserted. This conclusion follows from the factored formulas without relying on expanded numerical or table data.

7. **Restricted conductor hypothesis is respected.** The scalar correction lies in `(A_0,B_0,C_0)^2+(D_0^2)`, not merely the larger square of the four-monomial ideal. This is the necessary hypothesis of the second-order lift. Its exact value and first derivatives vanish at contact because the original native balances and all four retained-packet derivatives do. The full first normals, rather than their contact restrictions, lie in the first-order conductor ideal. Thus the complete scalar and hard-soft terms are allocated.

8. **Strict full Gram.** The two-pairing circuit has a positive definite constant contrast block and unit coefficients on both pairing roots. Retaining `g4^2` separately is valid when its coefficients no longer have zero residue. The exact full hard block on `(N,delta M_B)`, after multiplication by `C_mathcal`, has residue `16 K^14 I_2`: `Delta/delta` has residue one, each `H_i` has residue `8 K^2`, and every remaining term contains `eta` or `v`. The mixed hard-soft correction coefficients are infinitesimal by the preceding first-normal lifts. Hence the whole eight-root remainder Gram is strict; this is stronger than a scalar-only or determinant-only check.

9. **Restoration and exhaustion.** The four retained packets and the separately retained circuit square recover the complete original parent. All multipliers and inverses used for restoration are pure source or pure testing elements. The reflection, unit-`s` theorem, two outer-angle identities, unit-`w` identity, and small-`w` conductor exhaust the stated domain. Literal testing axes and the nonnegative pure-testing core are valid immediate exits. Complex states split into their real and imaginary parts.

## Wording correction applied

In the paragraph entitled “The complementary state chart”, the assertion `w>0` now occurs **after** proving that `Z` is a unit and normalizing `Z=1`. Before that normalization, the corresponding sign assertion is `w Z>0`, not necessarily `w>0`. This was an ordering/presentation correction: the proof of `Z` being a unit does not use the sign of `w`, and the subsequent conductor chart uses the correctly normalized state. The author confirmed applying the correction.

## Coverage boundary

The theorem does not settle native sources with either `eta` or `zeta` non-infinitesimal, except where another independently proved admission applies. It does not eliminate all remaining atlas obligations, give a finite leaf count, or construct an evaluated global affine SDP pencil.
