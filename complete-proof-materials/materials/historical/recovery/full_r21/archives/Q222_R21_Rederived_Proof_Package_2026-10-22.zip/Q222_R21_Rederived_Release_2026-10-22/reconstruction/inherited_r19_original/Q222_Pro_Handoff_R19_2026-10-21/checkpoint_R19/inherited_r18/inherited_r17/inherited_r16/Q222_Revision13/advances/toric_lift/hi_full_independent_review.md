# Same-system independent review of the full HI contact module

Reviewer: `/root/r7_amgm_review`. This is an independent derivation/check within the same agent system, not external proof verification.

Reviewed `retained_contact_module.tex`, `full_hi_retained_contact_module.tex`, and both exact checkers in `analysis_atlas/oct19_r7_hi_n0/`.

Result: the full HI critical-corner admission is supported, conditional only on the previously established original HI source entry and strict bounded-Gram lemma. The full checker was rerun: 18 base identities and 18 full-source identities pass exactly.

- The complete-source checker substitutes ν=f0/Δ. Its full source and contact checks do not invoke `n0_check` or reduce modulo f0=0. The n=0 checks run only as regression checks for the base module. The full graph update explicitly includes the changed A packet through the extra 2Hν DpDv Q² term.
- The retained n packet is exactly 4n DpDv x², with x=X+(R/H)pvY. It is a tensor square packet because n is nonnegative pure source and DpDv positive pure testing. It vanishes at the original source contact. Its subtraction leaves ν=2nR, never a bare unbounded n. Source R remains strictly positive; residue R=0 is permitted without replacing actual R by zero.
- ν is nonnegative and bounded. Its residue is (1-r)/(3+r), r in [0,1]. Thus h=H-ν has positive residue; e has residue 4λ>0; λ=2(1+r)²/(3+r)≥2/3. This covers n=0 and R infinitesimal, including unbounded n.
- E,K,t,j occur in inverse form only in the four retained positive opening packets. The remainder uses bounded E,K,t,j, c,d,μ,a*, Sc inverse, q,y,H,R,ν. Sc is a positive source unit. The normal diagonal residue 4/(3+r) is uniformly positive across every opening.
- The scalar coefficient functions are finite polynomials in p,v with bounded source coefficients. Therefore monic division about p0=√q,v0=√y supplies exactly the bounded Taylor arrays required by `toric_contact_lift.tex`. The state jet gives the inactive Hadamard balance. The half-angle contact identities imply p0 σ_p=−2(fA*-fD*) and v0 σ_v=−2(fB*-fD*), exactly the two active Hadamard balances.
- All four raw first-normal coefficients are infinitesimal. Their sums vanish at the actual source contact. Their bounded monic Taylor arrays and the same conductors therefore give infinitesimal cross-Gram entries, independently of the possibly unbounded ratios p/√q and v/√y.
- The sign of sQ equals the sign of −SY because all omitted source factors are positive. Sign branching and the common sign reversal are therefore pure-testing choices. On sQ>0 all four circuit monomials and their geometric mean are separated, and every radical factors into source and testing radicals. On sQ<0 the mixed graph term has positive leading coefficient on sqrt(T|sQ|), while the four raw graph and two normal pivots remain strict. For sQ=0 omit the fifth scalar root.
- The certificate is a tensor SOS for each pure-testing state. It is not asserted to be a polynomial matrix SOS of the original state degree. This distinction is explicit in the proof and does not weaken the stated pointwise tensor target.
- The new argument covers nonzero critical p,v. Literal axes and remote testing charts are attached from the already established R6 admissions, so no endpoint is silently inferred by mixed continuity.

No new gap was found in this module.
