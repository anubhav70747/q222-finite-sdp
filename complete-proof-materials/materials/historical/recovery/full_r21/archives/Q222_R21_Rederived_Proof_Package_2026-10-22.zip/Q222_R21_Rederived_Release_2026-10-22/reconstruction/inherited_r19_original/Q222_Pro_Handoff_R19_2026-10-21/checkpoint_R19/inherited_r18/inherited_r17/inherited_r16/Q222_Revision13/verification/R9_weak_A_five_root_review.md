# R9 review: five-root local A-unbounded C2 certificate

**Status: pass for the stated local source/testing domain.** This is an adversarial same-system review, not external independent verification. Reviewed `work_r9/weak_A/five_root_local.tex` and its exact checker. No main-package file was edited.

## Scope and source bounds

The theorem keeps the unchanged physical C2 source, original contact and source gaps. Its extra assumptions include positive bounded units z/B and 1-r, in addition to r,G/B,j,y/B,L/B, with B,z,y positive infinitesimals and H/y infinitesimal. These extra unit assumptions are essential for the printed strict pivots; the result does not cover their boundary openings by continuity.

I checked the exact identity

    M-yG = H(1+z)(B+zr) + z[yj+rL(1+y)] > 0.

It gives a unit lower bound for M/B^2. The defining source formulas give a bounded upper bound, Delta/B and (B+zr)/B units, hence alpha/B^2 a positive unit. Also Ah is a positive unit, while h=H/B, Ah^2, sqrt(A)h and 1/sqrt(A) are infinitesimal. Thus the unbounded coefficient A is isolated in the weighted normal q=sqrt(A)(Y-huW). All other coefficients occurring in the Gram are bounded. The detailed source-bound calculation is in `weak_A_source_bounds.md`.

## Exact full-parent identity

The proposed scalar three-root matrix satisfies the four scalar contact consequences, not just a value identity. The normal lifts satisfy the two complete original state-normal contact equations. I inspected the full expansion of F/4 under X=xi-ruZ and Y=eta+huW: its hard entries and both normal rows are exactly those in WA6–WA8. In particular no signed-core term or higher state-normal term is omitted; the state dependence is quadratic.

The abstract contact equations used by the checker are the correct ones at U=z=B/lambda, V=y=B/kappa, with the homogeneous state ratio Z/W=sqrt(zy)/B. As additional narrow review evidence, the self-contained checker `check_weak_A_source_contact.py` clears the known original source denominator and verifies all four scalar plus both normal equations against the unchanged rational source, as well as the radial lower-bound identity. It passes seven exact checks in under one second. This replay is not a new proof dependency.

All WA4 entries are bounded: their only small-source quotient is alpha/B^2, already a unit. The WA6 entries use only unit kappa,lambda denominators. Every WA7 coefficient is bounded because Ah is bounded; division by sqrt(A) then gives infinitesimal couplings. No inverse of an independent testing quantity occurs.

## Strict residue and legal tensor restoration

The only nonzero hard-soft residue is -m between xi and R2. Its 2-by-2 determinant is m(n+1/2)>0. The other residue pivots are 1, C+D+1/2, and alpha/B^2, all positive units. This proves positive definite residue of the full five-root Gram, not merely of the graph scalar.

WA10 is a valid finite separated lift. G(0,0) is a positive definite pure-source matrix with bounded inverse. Pure-source whitening and diagonalization leave finitely many scalars 1/N+lambda*t_j with bounded source lambda and infinitesimal pure-testing monomials t_j. The displayed two-product identity represents each using separate field square roots. There is no mixed Cholesky, mixed inverse, or square root of a mixed tensor.

## Quantifiers and resolved exposition requests

The result covers all four state coordinates, either sign and literal zero of u or v, and complex states by real/imaginary splitting. It imposes no source/testing relative rate. It proves a local both-infinitesimal testing certificate; it does not alone prove a remote-testing join or nonemptiness of the final residual complement.

The author has printed B=H+L and the exact contact explicitly, and renamed the source ratio B/z to ell to distinguish it from the omitted event coefficient lambda=0. The theorem now correctly omits residual-complement membership as a premise: the proof uses only the stated source, gap, and contact conditions. It retains the disclaimer that no residual-intersection nonemptiness is established. These corrections are verified in the current text.

The separately written direct remote join also passes; see `weak_A_remote_review.md`. Together the two modules give all independent testing angles on exactly WA1, including literal projective endpoints. The extra unit hypotheses z/B and 1-r remain essential to this reviewed domain.
