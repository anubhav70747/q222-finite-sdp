"""Six short native source balances underlying the contact derivative proof."""
if not __debug__:raise SystemExit('Run without -O: assertions are proof checks.')
from pathlib import Path
import json,time
from source_from_formulas import variables,native_coquotients
start=time.perf_counter();k,f,g,a,t=variables(5);c=native_coquotients()
kap=k*k;eta=f*f;zet=g*g;Vc=kap*eta*zet;V=1+Vc;K=1+kap
L=1-a*eta;Q=1-kap*zet+a*Vc;R=K-a*kap*eta;T=K-kap*zet*t
checks={
 'first current':c['Cb']-c['C2']-zet*c['C3'],
 'second current':c['C3']-c['C5']+kap*eta*c['Cb'],
 'Alice relation':c['C2']-(1-t*zet)*c['C5'],
 'state Y balance':2*kap*c['C2']+2*V*L*c['C4']-2*kap**2*zet*Q*c['Ca']-Q*c['Cd'],
 'twice scalar balance':2*kap*L*c['C2']+2*c['C5']+2*V*L*L*c['C4']+2*kap*Q*Q*c['Ca']+(kap*zet*L*L-2*L-eta)*c['Cd'],
 'twice Bob balance':2*kap*R*c['C2']+2*t*kap*Vc*c['Cb']+2*a*Vc*c['C3']+2*T*c['C5']+2*K*Vc*L*L*c['C4']-2*kap**2*zet*K*Q*L*c['Ca']-K*(Q*L+eta)*c['Cd']}
for name,p in checks.items():assert not p.terms,name
out={'status':'PASS','identities':list(checks),'seconds':time.perf_counter()-start,'method':'exact multiplication of seven short native coquotients; no full-source expansion'}
Path(__file__).with_name('native_contact_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
