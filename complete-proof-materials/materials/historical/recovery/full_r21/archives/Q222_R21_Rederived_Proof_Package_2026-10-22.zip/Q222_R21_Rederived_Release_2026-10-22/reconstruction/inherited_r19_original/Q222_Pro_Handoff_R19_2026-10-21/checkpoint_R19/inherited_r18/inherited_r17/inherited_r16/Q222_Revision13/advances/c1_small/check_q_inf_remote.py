"""Exact full-parent homogeneous Bob-remote identities."""
import sympy as s,json,time
start=time.time();checks=[]
def ck(name,f):
 ok=s.expand(f)==0;checks.append({'name':name,'passed':ok});print(('PASS ' if ok else 'FAIL ')+name,flush=True)
 if not ok:print(s.factor(f));raise AssertionError(name)
b,u,w,W,X,Y,Z=s.symbols('b u w W X Y Z');Du=1+u*u;Dw=1+w*w
P=u*W/b;Q=Y/b;J=b*Z;V=u*w*Z
Jraw=w*(u*W-Y)+u*X-Z
K=Jraw**2+Du*(Y-w*Z)**2+Dw*(X+u*Z)**2-Du*Dw*Z*Z
claimed=V*V-2*b*u*V*Q-2*w*P*J+2*w*V*X+b*b*w*w*P*P+2*b*u*w*P*X-2*b*b*w*w*P*Q+(Du+w*w)*(X*X+b*b*Q*Q)-2*b*u*w*X*Q
ck('entire homogeneous signed core on five bounded-coefficient roots',K-claimed)
ck('entire D event on remote roots',b*Jraw-(b*b*w*P+b*u*X-b*b*w*Q-J))
ck('entire C event on remote roots',(u*W-Y)/b-(P-Q))
ck('entire A event on remote roots',Y/b-Q)
# This certificate retains the m,alpha,beta packets untouched. No e bound.
open(__file__.replace('.py','.json'),'w').write(json.dumps({'passed':all(x['passed'] for x in checks),'checks':checks,'elapsed_seconds':time.time()-start},indent=2))
print(len(checks),'checks passed')
