import json
from pathlib import Path
import sympy as s
T,R,v,N,B,C=s.symbols('T R v N B C', nonnegative=True)
tau=T*T;rho=R*R
# Parameterize positive source constants so no branch of a radical is inferred.
a=T/s.sqrt(2*(1+T*T));g=R/s.sqrt(2*(1+T*T));d=T*R
lhs=(1+v*v/(1+tau))*N*N+2*(1+tau*v*v)*B*B+2*C*C+4*a*v*v*N*B-4*g*v*N*C-4*d*v*B*C
rhs=2*(C-g*v*N-d*v*B)**2+N*N+2*B*B+(1-rho)*v*v*(N/s.sqrt(1+tau)+s.sqrt(2)*T*B)**2
checks={'full_three_root_residue_Gram':s.simplify(s.expand(lhs-rhs))==0}
assert all(checks.values())
Path(__file__).with_suffix('.json').write_text(json.dumps({'status':'PASS','checks':checks,'scope':'Exact full ordinary-v normal/circuit residue identity; not an unbounded-v admission'},indent=2)+'\n')
print('PASS full ordinary-v normal/circuit residue Gram')
