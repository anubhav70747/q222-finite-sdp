#!/usr/bin/env python3
"""Exact cycle-cover and capped-parent obstruction checks; standard library only."""
from collections import defaultdict
from itertools import permutations
from pathlib import Path
import hashlib
import json

# Integer polynomials in u,v,W,X,Y,Z,mu. u,v also denote p,q in reciprocal charts.
N = 7
ZERO = (0,) * N
class P(dict):
    @staticmethod
    def lift(x):
        return x if isinstance(x, P) else P({ZERO: x}) if x else P()
    def __add__(a, b):
        out = P(a)
        for m, x in P.lift(b).items():
            out[m] = out.get(m, 0) + x
        return P({m: x for m, x in out.items() if x})
    __radd__ = __add__
    def __neg__(a):
        return P({m: -x for m, x in a.items()})
    def __sub__(a, b):
        return a + -P.lift(b)
    def __rsub__(a, b):
        return P.lift(b) + -a
    def __mul__(a, b):
        out = defaultdict(int)
        for m, x in a.items():
            for n, y in P.lift(b).items():
                out[tuple(i + j for i, j in zip(m, n))] += x * y
        return P({m: x for m, x in out.items() if x})
    __rmul__ = __mul__
    def __pow__(a, k):
        out = P.lift(1)
        for _ in range(k):
            out = out * a
        return out
    def at(a, **kw):
        out = P()
        for m, x in a.items():
            n = list(m)
            for var, value in kw.items():
                i = names.index(var)
                x *= value ** n[i]
                n[i] = 0
            out += P({tuple(n): x}) if x else P()
        return out
    def degree_part(a, indices, degrees):
        return P({m: x for m, x in a.items()
                  if sum(m[i] for i in indices) in degrees})

names = ('u', 'v', 'W', 'X', 'Y', 'Z', 'mu')
u, v, W, X, Y, Z, mu = [P({tuple(int(i == j) for i in range(N)): 1})
                         for j in range(N)]
one = P.lift(1)


from fractions import Fraction
from itertools import combinations

def packets(u0,u1,v0,v1):
    Du,Dv=u0*u0+u1*u1,v0*v0+v1*v1
    R2=u0*v1*W-u0*v0*X+u1*v1*Y-u1*v0*Z
    R3=u1*W-u0*Y
    R5=u1*v0*W+u1*v1*X-u0*v0*Y-u0*v1*Z
    Ra,Rb=v1*Y-v0*Z,u0*X+u1*Z
    H=2*(R5**2+Du*Ra**2+Dv*Rb**2-Du*Dv*Z**2)
    return H,[Du*(v0*W+v1*X)**2,R5**2,Dv*R3**2,
              Du*Dv*Y**2,Du*Ra**2,R2**2,Dv*Rb**2,Du*Dv*X**2]

H,pack=packets(one,u,one,v)
indices=(0,1,3,4,5)
Qcore=H.at(W=1).degree_part(indices,{2})
assert Qcore==2*(u-Y)**2+2*X**2
expected=[None,(u-Y)**2,(u-Y)**2,Y**2,Z**2,(v-X)**2,X**2,X**2]
for i in range(1,8):
    assert pack[i].at(W=1).degree_part(indices,{0,1})==P()
    assert pack[i].at(W=1).degree_part(indices,{2})==expected[i]

def dist(a,b):return min((a-b)%8,(b-a)%8)
edges=[list(e) for e in combinations(range(8),2) if dist(*e) in (3,4)]
def five(S):return any({(i+j)%8 for j in range(5)}<=S for i in range(8))
def rank_condition(S):
    return all({(i+j)%8 for j in (3,4,5)}<=S for i in set(range(8))-S)
rows=[]
for mask in range(256):
    S={i for i in range(8) if mask>>i&1};T=set(range(8))-S
    compatible=not any(set(e)<=T for e in edges)
    assert five(S)==rank_condition(S)==compatible
    if {0,7}<=T:
        obstruction=(bool(T&{2,5}) or bool(T&{3,4}) or {1,6}<=T)
        assert obstruction != five(S)
    if {0,6}<=T:
        obstruction=bool(T&{1,2,3,4,5})
        assert obstruction != five(S)
    rows.append({'strong_mask':mask,'five_run':five(S),'strict_corner_rank':rank_condition(S)})
# An arbitrary five-set does not support the cap lemma. This is an exact
# local obstruction for the capped polynomial, not a physical-source counterexample.
S={1,2,5,6,7}
F=H+4*mu*sum((pack[i] for i in S),P())
# u=t, v=3t^2, W=1, X=0, Y=Z=t, mu=1/4.
curve={}
for ex,c in F.items():
    if ex[3]:continue
    degree=ex[0]+2*ex[1]+ex[4]+ex[5]
    value=Fraction(c)*3**ex[1]*Fraction(1,4)**ex[6]
    curve[degree]=curve.get(degree,Fraction())+value
curve={k:v for k,v in curve.items() if v}
assert min(curve)==4 and curve[4]==-5
out=Path(__file__).resolve().parent
report={'arithmetic':'exact rational polynomials and finite C8 combinatorics',
 'status':'PASS','checked_strong_subsets':256,
 'base_ray_quadratic_packets_checked':7,
 'counterexample_selected_cycle_indices':sorted(S),
 'counterexample_curve':{str(k):str(v) for k,v in sorted(curve.items())},
 'counterexample_scope':'Nonphysical capped parent only; no claim against the global physical-source theorem.',
 'strict_rank_claim':'Within the bounded cap plus five-coordinate positive-residue Taylor-Gram method.',
 'patterns':rows}
(out/'cycle_reduction_checks.json').write_text(json.dumps(report,indent=2)+'\n')
graph={'cycle':['lambda','D','c','A','alpha','m','beta','n'],
 'exclusive_weak_pair_edges':edges,
 'edge_orbits_under_dihedral_C8':[
   {'representative':[0,3],'distance':3,'count':8},
   {'representative':[0,4],'distance':4,'count':4}],
 'canonical_source_templates':[
 {'id':'C1_c','literal_zeros':['lambda','n'],'weak':['c'],'reflected_weak':['m'],'reflection':'i -> 7-i mod8'},
 {'id':'C1_A','literal_zeros':['lambda','n'],'weak':['A'],'reflected_weak':['alpha'],'reflection':'i -> 7-i mod8'},
 {'id':'C1_D_beta','literal_zeros':['lambda','n'],'weak':['D','beta'],'reflection':'i -> 7-i mod8'},
 {'id':'C2_D','literal_zeros':['lambda','beta'],'weak':['D'],'reflected_weak':['m'],'reflection':'i -> 6-i mod8'},
 {'id':'C2_c','literal_zeros':['lambda','beta'],'weak':['c'],'reflected_weak':['alpha'],'reflection':'i -> 6-i mod8'},
 {'id':'C2_A','literal_zeros':['lambda','beta'],'weak':['A'],'reflection':'i -> 6-i mod8'}],
 'template_scope':'Source reductions only; all actual-angle regimes and independent tests remain quantified.'}
(out/'source_cover_graph.json').write_text(json.dumps(graph,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='patterns'},indent=2))
