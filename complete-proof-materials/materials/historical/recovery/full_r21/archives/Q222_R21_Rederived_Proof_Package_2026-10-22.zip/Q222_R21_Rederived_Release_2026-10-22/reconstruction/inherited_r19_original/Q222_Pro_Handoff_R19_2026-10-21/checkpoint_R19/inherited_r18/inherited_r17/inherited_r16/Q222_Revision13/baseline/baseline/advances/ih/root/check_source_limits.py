"""Exact normalized-source residue identities, with regular-denominator checks."""
from pathlib import Path
import json
from source_formulas import *
tau,q,ss,e=S.symbols('tau q ss e',positive=True)
checks=[]
def regular(name,expr,sub,zeros,expected):
    print('checking '+name,flush=True)
    f=S.together(expr.subs(sub,simultaneous=True))
    num,den=S.fraction(f)
    # Cancel only common monomials in the small parameters. A multivariate
    # gcd is unnecessary; every remaining source denominator is a unit.
    generators=tuple(zeros)
    pn=S.Poly(num,*generators); pd=S.Poly(den,*generators)
    for i,g in enumerate(generators):
        vn=min(mon[i] for mon,_ in pn.terms()); vd=min(mon[i] for mon,_ in pd.terms())
        common=min(vn,vd)
        if common:
            pn=S.Poly.from_dict({tuple(ex-common if j==i else ex for j,ex in enumerate(mon)):coef for mon,coef in pn.terms()},generators)
            pd=S.Poly.from_dict({tuple(ex-common if j==i else ex for j,ex in enumerate(mon)):coef for mon,coef in pd.terms()},generators)
    num,den=pn.as_expr(),pd.as_expr()
    nn=S.factor(num.subs(zeros)); dd=S.factor(den.subs(zeros))
    assert dd != 0, (name,'vanishing normalized denominator')
    assert S.factor(nn-expected*dd)==0,(name,S.factor(nn/dd-expected))
    checks.append({'name':name,'denominator_at_residue':str(dd)})
base=[('BC',B*C,S.Rational(1,2)),('Bm/z²',B*m/z**2,S.Rational(1,2)),('AH/B',A*H/B,S.Rational(1,2)),('alpha(1-H)/B',al*(1-H)/B,S.Rational(1,2))]
sub={B:1/tau,y:1/(tau*q),r:ss*q}
zero={z:0,tau:0,q:0}
for name,f,target in base: regular('weak rho0 '+name,f,sub,zero,target)
for name,f,target in [('nu/rho',(4*n+2)*r/(B/y),2),('nr/rho',n*r/(B/y),(1-ss)/2),('D/rho²',D/(B/y)**2,S.Rational(1,2)),('k/(B rho)',k/(B*(B/y)),2*ss)]:
    regular('weak rho0 '+name,f,sub,zero,target)
sub={y:1/q,r:ss*B*q};zero={z:0,q:0};cs=(1+B-H)/B
for name,f,target in [('nu/rho',(4*n+2)*r/(B/y),2*cs),('nr/rho',n*r/(B/y),(cs-ss)/2),('D/rho²',D/(B/y)**2,cs/2),('CL',C*(B-H),S.Rational(1,2)),('Bm/z²',B*m/z**2,cs/2),('AH',A*H,(1+B-H)/2),('alpha(1-H)',al*(1-H),B/2),('k/(B rho)',k/(B*(B/y)),2*(B*B*ss+B*H*ss+B*H-B*ss-H*H+H)/(B*B))]:
    regular('strong IH '+name,f,sub,zero,target)
# rho1 uses j=e exactly. The radial r remains an arbitrary bounded parameter.
rhop=(1+z*r-e)/(1-H*tau)
sub={B:1/tau,y:1/(tau*rhop)};zero={z:0,tau:0,e:0}
for name,f,target in [('De',D*e,S.Rational(1,4)),('nu',(4*n+2)*r,1),('nr',n*r,(1-2*r)/4),('BC',B*C,S.Rational(1,4)),('Bm/z²',B*m/z**2,(1-r)/4),('AH/B',A*H/B,S.Rational(1,4)),('alpha(1-H)/B',al*(1-H)/B,S.Rational(1,4)),('kappa/B',(k-8*D*H*r)/B,r)]:
    regular('weak rho1 '+name,f,sub,zero,target)
assert S.factor(M-((1+z)*(B+z*r)*H+y*G+y*z*j+z*r*(B-H)*(1+y)))==0
checks.append({'name':'positive M source decomposition'})
assert S.factor(((B+z*r)*Ac*Q-r*delta).subs(r,1)+(H+y)*(B+z)*(1+z))==0
checks.append({'name':'n numerator at radial endpoint'})
result={'status':'PASS','count':len(checks),'checks':checks,'scope':'Exact rational normalization and residue identities; positivity and boundedness of free opening variables are justified in theorem text.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
