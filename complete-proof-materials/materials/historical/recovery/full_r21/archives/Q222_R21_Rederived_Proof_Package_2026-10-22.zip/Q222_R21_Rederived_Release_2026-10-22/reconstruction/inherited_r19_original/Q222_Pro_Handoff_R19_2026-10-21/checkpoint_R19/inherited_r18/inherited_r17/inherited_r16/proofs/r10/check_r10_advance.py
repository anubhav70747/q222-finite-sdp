"""New R10 normalized source, full-parent hard remainder, and weighted lift checks."""
import sympy as s,json
from pathlib import Path
checks={}
def ck(name,ex):
 assert s.cancel(ex)==0,(name,s.factor(ex));checks[name]=True;print('PASS',name,flush=True)
p,b,w,h,t=s.symbols('p b w h t');x=p*b;a=1/p;B=p*p*b;e=p*w;r=1-e
ca=1+x*r;Sc=1+B*(1-h+a*r);g=1-w+h*x;j=ca-(1-h)/t
Dp=s.expand(p*(a+(1+a*B)+(1+a*B)*B+2*a*B*(1+a*B)*r+a**3*B**2*r*r+2*a*a*B*r+t*B*(1+a+a*B+a*a*B*r*(2-r))))
M=(1+x)*(1+a*r)*(h+t)-a*(1+t*B)*e*(1-h)
QP=1+B*(1+t+a*h+2*a*r+a*t)+B**2*(a*(h+t)+a*a*(h*(r+1)+t*(1+r-r*r)))
KP=(1+p)*(h+t)*(1+x)
ns=(w*QP-b*KP)/(2*r*Dp);n=p*p*ns
ck('exact_normalized_n_slack',2*r*Dp*n-((p+r)*ca*Sc-r*Dp))
m=w*(1+t*B)*ca*Sc/(2*g*Dp)
C=ca*(p*M)/(2*(1-h)*Dp);Ah=t*ca*(p+r)*Sc/(2*Dp);D=(1+x)*(p+r)*(1-t*x*r)*Sc/(2*t*j*Dp);al=p**3*b*b*(p+r)*(p*M)/(2*(1-h*B)*Dp)
qt=n*r*r+(m+s.Rational(1,2))*e*e+al
mu=s.cancel(m-qt/p**2);lam=s.cancel(mu/(t*b));cf=s.cancel((2*m*h+C*(1-h)**2+Ah*h+(al+s.Rational(1,2))*h*h-n*r*r/p**2)/t**2)
corner={p:0,h:0}
for name,E,ans in [('normalized_Delta',Dp,1),('positive_Q_polynomial',QP,1),('positive_K_factor',KP,t),('n_over_p_squared',ns,(w-t*b)/2),('m_over_w',m/w,1/(2*(1-w))),('C',C,t/2),('Ah',Ah,t/2),('D',D,1/(2*(t-1))),('alpha_over_p_cubed_b_squared',al/(p**3*b*b),t/2),('lambda',lam,s.Rational(1,2)),('cF',cf,(t-w+t*b)/(2*t*t))]:
 E=s.cancel(E);ck('source_residue_'+name,E.subs(corner)-ans)
# No normalized source pole in lambda: its denominator remains nonzero at
# p=h=b=0,w arbitrary<1,t>1. The b monomial was canceled exactly.
num,den=s.fraction(lam);assert s.factor(den.subs({p:0,h:0,b:0}))!=0
checks['lambda_no_b_or_p_denominator']=True
# Independent reconstruction of the original full parent hard remainder.
u,v,E,Ny,xi,Z=s.symbols('u v E Ny xi Z');aa,rr,hh,nn,mm,CC,AA,DD,al=s.symbols('a r h n m C Ah D alpha');bh=s.symbols('bh');hh=bh*bh;U=u*u;V=v*v
W=(v*Z+E)/(t*u);Y=hh*(v*Z+E)/t+bh*Ny;X=xi-rr*u*Z
Du=1+U;Dv=1+V
Rm=v*W-X+u*v*Y-u*Z;Rd=u*W+u*v*X-Y-v*Z
F=nn*Du*Dv*X*X+mm*Rm*Rm+CC*Dv*(u*W-Y)**2+(AA/hh)*Du*Dv*Y*Y+(DD+s.Rational(1,2))*Rd*Rd+(al+s.Rational(1,2))*Du*(v*Y-Z)**2+Dv*(X+u*Z)**2/2-Du*Dv*Z*Z/2
q=nn*rr*rr+(mm+s.Rational(1,2))*(1-rr)**2+al;mt=mm-aa*aa*q
Q=q*(aa*v*W-u*Z-aa*xi)**2
N=nn*(rr*(aa*V/t-U)*Z+u*xi)**2
R=s.Poly(s.cancel(F-Q-N-mt*(v*E/(t*u)-xi)**2),E,Ny,xi)
H={}
for i,z in enumerate((E,Ny,xi)):
 for j,z2 in enumerate((E,Ny,xi)):
  if j<i:continue
  co=s.cancel(R.coeff_monomial(z*z2));H[str(i)+str(j)]=str(s.factor(co))
  # All a dependence cancels from hard remainder entirely.
  assert not co.has(aa)
  assert not s.denom(co).has(u,v)
  val=co.subs({u:0,v:0,bh:0,rr:1,nn:0,al:0,CC:t/2,AA:t/2,DD:1/(2*(t-1))})
  expected=0 if i!=j else [1/(2*(t-1)),t/2,s.Rational(1,2)][i]
  ck('full_hard_residue_'+str(i)+str(j),val-expected)
# Exact SF4 coupling in general C2 variables.
c,k,lam,qbar=s.symbols('c k lambda qbar', nonzero=True);aa=t*c*c;xx=k*k;yy=xx/(c*c)
Ef=t*u*W-v*Z;RD=v*(U-xx)*Z;J=(u*v-xx/c)*Z;Rc=k*v*(t*c*W-Z);Qraw=aa*v*W-u*Z-aa*xi
ck('whole_principal_xi_coupling',-2*t*lam*c*k*Rc+2*t*lam*c*(RD-u*J)+2*t*lam*xx*Qraw+2*t*lam*xx*aa*xi)
# Source Schur algebra and strict lower-bound rewrite.
M0,chi,rho,rr,zalpha=s.symbols('M0 chi rho rr zalpha',positive=True);HH=M0+s.Rational(1,2)
ck('weighted_schur_lower_bound_identity',HH-chi**2/(rho*rr**2+HH)-(HH*rho*rr**2/(rho*rr**2+HH)+(HH**2-chi**2)/(rho*rr**2+HH)))
# Remote ordinary-v complete (S,X) block with arbitrary bounded m.
v0,M0=s.symbols('v0 M0');gram=s.Matrix([[v0*v0,-v0*M0],[-v0*M0,M0*M0+(1+v0*v0)/2]])
ck('remote_ordinary_v_bounded_m_determinant',gram.det()-v0*v0*(1+v0*v0)/2)
out={'status':'PASS','count':len(checks),'checks':checks,'hard_coefficients':H,'scope':'R10 exact source bounds; remote all tests outside both-small chart; local all tests on n/e^2 noninfinitesimal. No positive n/e^2 infinitesimal closure claimed.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
