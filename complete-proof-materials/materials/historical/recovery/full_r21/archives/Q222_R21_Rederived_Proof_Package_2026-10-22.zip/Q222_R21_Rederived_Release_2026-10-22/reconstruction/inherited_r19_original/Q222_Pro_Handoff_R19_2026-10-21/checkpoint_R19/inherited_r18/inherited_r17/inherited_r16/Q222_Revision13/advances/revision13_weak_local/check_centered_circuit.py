#!/usr/bin/env python3
"""New focused exact C2 small-gap scalar and full-normal reduction.

No baseline checker is imported or replayed. Positivity is in the companion text.
"""
import json
from pathlib import Path
import sympy as s

checks={}
def ck(name,expr):
    z=s.cancel(expr)
    assert z==0,(name,s.factor(z))
    checks[name]=True
    print('PASS',name,flush=True)

B,a,t,r,h,U,V=s.symbols('B a t r h U V')
n,m,C,Ah,D,al=s.symbols('n m C Ah D alpha')
e=1-r; half=s.Rational(1,2); x=a*B; y=t*B; ss=t/a
ca=1+a*B*r; Sc=1+B*(1-h+a*r)
g=1+a*(h*B+r-1); j=ca-(1-h)/t
dd=a+(1+a*B)+(1+a*B)*B+2*a*B*(1+a*B)*r+a**3*B**2*r*r+2*a*a*B*r+t*B*(1+a+a*B+a*a*B*r*(2-r))
M=(1+a*B)*(1+a*r)*(h+t)-a*(1+t*B)*(1-r)*(1-h)
src={n:((1+a*r)*ca*Sc-r*dd)/(2*r*dd),
     m:a*a*(1+t*B)*(1-r)*ca*Sc/(2*g*dd),
     C:ca*M/(2*(1-h)*dd),
     Ah:t*ca*(1+a*r)*Sc/(2*dd),
     D:(1+a*B)*(1+a*r)*(1-a*t*B*r)*Sc/(2*t*j*dd),
     al:B*B*(1+a*r)*M/(2*(1-h*B)*dd)}

aw=(C+D+half)*(1-h)**2+Ah*h
b2=2*m*h+C*(1-h)**2+Ah*h+(al+half)*h*h
b4=h*h*(m+al+half)+Ah*h
c2=n*r*r+(m+half)*e*e+al
d2=(n+half)*r*r+2*D*r
d4=(n+D+half)*r*r
e0=m*e+D*(1-h)+al*h+half
e1=m*h*e+r*(D+half)*(1-h)+(al+half)*h
Aw=aw*U+Ah*h*U*U+(m+b2*U+b4*U*U)*V
Az=al+c2*U+n*r*r*U*U+(D+d2*U+d4*U*U)*V
S=Aw*V/(t*t*U)+Az-2*V*(e0+e1*U)/t

q=n*r*r+(m+half)*e*e
mt=m-a*a*q
cF=(b2-n*r*r*a*a)/(t*t)
qV=aw/(t*t)+D-2*e0/t+2*a*q/t
fA=Ah*h/(t*t)+d2-2*e1/t+2*a*n*r*r/t+d4*U+b4*V/(t*t)
fB=mt/(t*a*a*B)
fC=(al-cF*y*y+al*U)/(t*a*B*B)
fG=-(qV+2*cF*y)/(a*B)
At2=U*V;Bt2=a*a*B*V*V/(t*U);Ct2=a*t*B*B;G2=a*B*V
Hsq=U-2*a*V/t+a*a*V*V/(t*t*U)
target=q*Hsq+n*r*r*U*Hsq+cF*(V-y)**2+fA*At2+fB*Bt2+fC*Ct2-fG*G2
ck('entire_scalar_two_weighted_binomials_and_three_circuit',S-target)

report={}
source_variables=(n,m,C,Ah,D,al)
unit_den=2*r*g*(1-h)*(1-h*B)*(t-1+h+a*B*t*r)*dd
source_nums={z:s.cancel(unit_den*src[z]) for z in source_variables}
assert all(s.denom(z)==1 for z in source_nums.values())
def source_rat(name,expr,power=0,target=None):
    enum,eden=s.fraction(s.factor(expr))
    ep=s.Poly(enum,*source_variables)
    assert ep.total_degree()<=1,(name,'not linear in source coefficients')
    num=s.expand(ep.coeff_monomial(1)*unit_den+sum(ep.coeff_monomial(z)*source_nums[z] for z in source_variables))
    den=eden*unit_den
    # All nonunit cancellations needed here are monic powers of B only.
    while den.subs(B,0)==0:
        assert num.subs(B,0)==0,(name,'uncancelled B pole')
        num=s.div(num,B,B)[0]
        den=s.cancel(den/B)
    z=num/den
    den0=s.factor(den.subs({B:0,h:0,r:1}))
    assert den0!=0,(name,'singular denominator',s.factor(den))
    if target is not None:
        ck(name+'_joint_residue',z.subs({B:0,h:0,r:1})-target)
    report[name]={'corner_denominator':str(den0),'numerator_degrees':str(s.Poly(num,B,a,t,r,h).total_degree())}
    print('REGULAR',name,flush=True)
    return z

source_rat('m_tilde_over_B',mt/B,target=a*a*t/2)
source_rat('qV_over_B',qV/B,target=-1-3*a/2)
source_rat('cF',cF,target=1/(2*t))
source_rat('fA_constant',fA.subs({U:0,V:0}),target=half)
source_rat('fB',fB,target=half)
source_rat('fC_constant',fC.subs(U,0),target=half)
source_rat('fC_U',s.diff(fC,U),target=(1+a)/(2*a))
source_rat('fG',fG,target=3*half)

# Complete graph X,Y normals and E,N normal transformation.
fw=-m+( -m*h+(D+half)*(1-h))*U
fz=-n*r*(1+U)*(1+V)+m*e-(D+half)*V*(1+r*U)+half*(1+V)*e
kw=-(C+D+half)*(1-h)+Ah+Ah*U+(-C*(1-h)+Ah+m+(al+half)*h)*V+(Ah+h*(m+al+half))*U*V
kz=D-al+(-m*e+r*(D+half)-al-half)*U
PY=2*(kw/t+kz)
PE=2*(Aw/U-m*V/U)/t**2-2*(e0+e1*U)/t
cx=-n*r+(m+half)*e
ZY=(D+half)*(1-h)/t-(D+half)*(1+r*U)+half*e-n*r*(1+U)

# w=v/u is a bounded, purely testing ratio. Homogeneous Z=1.
u,w=s.symbols('u w')
uv={U:u*u,V:u*u*w*w}
H=u*(a*w*w/t-1)
Lx=2*u*(cx-n*r*U-m*w*w*(1+h*U)/t+V*ZY)
LN=u*w*PY
LE=2*m*u*w**3/t**2+u*w*PE
# Extract the entire q and n-dependent angular normal without any q inverse.
Lx_center=-2*a*q*H+2*n*r*u*u*H
LE_center=2*a*q*w*H/t
LN_center=s.Integer(0)
# Residual first normals in polynomial (u,w) coordinates.
RX=s.cancel((Lx-Lx_center).subs(uv))
RE=s.cancel((LE-LE_center).subs(uv))
RN=s.cancel(LN.subs(uv))
KX=cx-a*q
KE=aw/t**2-e0/t+a*q/t
KY=(-(C+D+half)*(1-h)+Ah)/t+D-al
x3=2*((D+half)*((1-h)/t-1)+half*e-n*r*(1+a/t)-m*h/t)
x5=-2*r*(n+D+half)
exRX=2*KX*u-2*mt*u*w*w/t+x3*u**3*w**2+x5*u**5*w**2
exRE=2*KE*u*w+2*mt*u*w**3/t**2+(2*Ah*h/t**2-2*e1/t)*u**3*w+2*b2*u**3*w**3/t**2+2*b4*u**5*w**3/t**2
exRN=2*KY*u*w+2*(Ah/t-m*e+r*(D+half)-al-half)*u**3*w+2*(-C*(1-h)+Ah+m+(al+half)*h)*u**3*w**3/t+2*(Ah+h*(m+al+half))*u**5*w**3/t
ck('finite_X_residual_normal_array',RX-exRX)
ck('finite_E_residual_normal_array',RE-exRE)
ck('finite_Y_residual_normal_array',RN-exRN)
for name,z in [('RX',RX),('RE',RE),('RN',RN)]:
    assert s.denom(z).has(u,w)==False,name
    print('NORMAL_POLYNOMIAL',name,flush=True)

# Sufficient finite circuit allocation: every degree-one u,w coefficient is O(B),
# all degree>=3 coefficients are bounded and give infinitesimal root coefficients.
# Degree-one terms in w with no accompanying u do not occur.
for name,z in [('RX',RX),('RE',RE),('RN',RN)]:
    p=s.Poly(s.expand(z),u,w)
    for (iu,iw),co in p.terms():
        if iu==1:
            source_rat(name+'_linear_w'+str(iw),co/B)
        else:
            assert iu>=3 and iu%2==1 and iw>=1,(name,iu,iw)
            source_rat(name+'_higher_u'+str(iu)+'w'+str(iw),co)

# Direct differentiation of the entire ORIGINAL four-state parent.
W,X,Y,Z,v,E,N,xi,jh=s.symbols('W X Y Z v E N xi sqrt_h')
Du=1+u*u;Dv=1+v*v
RM=v*W-X+u*v*Y-u*Z
RD=u*W+u*v*X-Y-v*Z
F=n*Du*Dv*X*X+m*RM*RM+C*Dv*(u*W-Y)**2+(Ah/h)*Du*Dv*Y*Y+D*RD*RD+al*Du*(v*Y-Z)**2+half*(RD*RD+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z*Z)
ck('literal_u_axis_entire_parent',F.subs(u,0)-n*Dv*X*X-m*(v*W-X)**2-(C+Ah/h+half)*Dv*Y*Y-D*(Y+v*Z)**2-al*(v*Y-Z)**2-half*Dv*X*X)
ck('literal_v_axis_entire_parent',F.subs(v,0)-n*Du*X*X-(m+half)*(X+u*Z)**2-(C+D+half)*(u*W-Y)**2-(Ah/h)*Du*Y*Y-al*Du*Z*Z)
ck('exact_u_sign_gauge_entire_parent',F.subs({u:-u,Y:-Y,Z:-Z},simultaneous=True)-F)
ck('exact_v_sign_gauge_entire_parent',F.subs({v:-v,X:-X,Z:-Z},simultaneous=True)-F)
full=s.expand(F.subs({Z:1,W:(v+E)/(t*u),Y:h*(v+E)/t+N,X:xi-r*u}).subs(v,u*w))
zero={E:0,N:0,xi:0}
ck('full_parent_scalar_restriction',full.subs(zero)-S.subs(uv))
ck('full_parent_E_normal',s.diff(full,E).subs(zero)-LE.subs(uv))
ck('full_parent_Y_normal',s.diff(full,N).subs(zero)-LN.subs(uv))
ck('full_parent_X_normal',s.diff(full,xi).subs(zero)-Lx.subs(uv))
normfull=s.expand(full.subs({h:jh*jh,N:jh*N},simultaneous=True))
hard=s.hessian(normfull,[E,N,xi])/2
corner_hard={u:0,jh:0,n:0,m:0,C:t/2,Ah:t/2,D:1/(2*(t-1)),al:0,r:1}
expected=s.diag(1/(2*(t-1)),t/2,half)
for ii in range(3):
    for jj in range(ii,3):
        ck('full_hard_joint_residue_'+str(ii)+str(jj),s.cancel(hard[ii,jj]).subs(corner_hard)-expected[ii,jj])

# Source comparison estimates for the reciprocal ratio chart.
# A finite two-variable numerator division gives Delta C, Delta Ah, Delta D
# in B*bounded + e*bounded. BS1 then supplies B/e bounded.
for name,expr in [('C',C-(t+h)/(2*(1-h))),('Ah',Ah-t/2),('D',D-1/(2*(t+h-1)))]:
    er=s.cancel(expr.subs(src,simultaneous=True))
    en,ed=s.fraction(er)
    ck('reciprocal_comparison_'+name+'_source_anchor',en.subs({B:0,r:1}))
    assert s.factor(ed.subs({B:0,h:0,r:1}))!=0,name
    bquot=s.div(s.expand(en-en.subs(B,0)),B,B)[0]
    equot=s.div(s.expand(en.subs(B,0)),r-1,r)[0]
    ck('reciprocal_comparison_'+name+'_finite_division',en-B*bquot-(r-1)*equot)

# Complete reciprocal-chart higher-angle identity, independently expanded.
p0,q0,y0=s.symbols('p0 q0 y0')
Cstar=(t+h)/(2*(1-h));Dstar=1/(2*(t+h-1))
compare=Cstar*(p0-y0)**2+t*y0*y0/(2*h)+Dstar*(p0-y0-q0)**2+(p0-y0)**2/2-p0*q0
compare_frame=s.expand(compare.subs({q0:t*p0-E,y0:h*p0+jh*N}).subs(h,jh*jh))
compare_target=(Dstar*E*E-2*Dstar*jh*E*N+t*(t+2*h-1)*N*N/(2*(1-h)*(t+h-1))).subs(h,jh*jh)
ck('reciprocal_exact_h_dependent_comparison_base',compare_frame-compare_target)
HH=U*((Ah/h)*y0*y0-2*D*q0*(p0-y0-q0)+q0*q0/2-p0*q0)+V*(C*(p0-y0)**2+((Ah/h)+half)*y0*y0)+((Ah/h)+half)*U*V*y0*y0+(D+half)*U*U*q0*q0
base=C*(p0-y0)**2+(Ah/h)*y0*y0+D*(p0-y0-q0)**2+(p0-y0)**2/2-p0*q0
noB=C*(1+V)*(p0-y0)**2+(Ah/h)*(1+U)*(1+V)*y0*y0+D*(p0-y0-(1+U)*q0)**2+((p0-y0)**2+(1+U)*V*y0*y0+(1+U)*U*q0*q0-2*(1+U)*p0*q0)/2
ck('reciprocal_entire_higher_angle_identity',noB-base-HH)
kapR=Ah*h-2*D*t*(1-h-t)+t*t/2-t
kapS=C*(1-h)**2+Ah*h+half*h*h
ck('reciprocal_R_strict_pivot',kapR.subs({h:0,Ah:t/2,C:t/2,D:1/(2*(t-1))})-t*t/2)
ck('reciprocal_S_strict_pivot',kapS.subs({h:0,Ah:t/2,C:t/2,D:1/(2*(t-1))})-t/2)

out={'status':'PASS','checks':checks,'source_regularities':report,
     'scope':'Exact new scalar identity, finite complete-normal arrays, complete hard residues and reciprocal identities on original BS1 source. Ordered-field positivity and local-to-remote admission are proved in centered_circuit_closure.tex; scope excludes every other weak-C2 source gap.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'PASS','identities':len(checks),'regularities':len(report)},indent=2))
