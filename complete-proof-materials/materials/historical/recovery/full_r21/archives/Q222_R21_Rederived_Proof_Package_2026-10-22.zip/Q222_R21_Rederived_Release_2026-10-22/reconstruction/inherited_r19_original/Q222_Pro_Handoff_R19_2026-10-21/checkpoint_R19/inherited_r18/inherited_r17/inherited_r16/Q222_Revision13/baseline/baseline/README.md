# Q222 analytical revision 5 — 19 October 2026

Start with the cumulative PDF and CHECKLIST.md. The analytical global proof is unfinished.
Three former residual domains now have all-tests certificates; six remain. C1 UI and C2 HI have further full-parent remote complements. Leading-model certificates are labelled separately.

## Contents

- `Q222_Analytical_Revision_2026-10-18.pdf` and matching TeX: current cumulative manuscript.
- `CHECKLIST.json`, `CHECKLIST.md`, `PROOF_STATUS.json`: authoritative current coverage.
- `advances/`: complete new arguments and exact symbolic checkers, including frontier results.
- `baseline/`: exact 451-file revision 4, unchanged.
- `verification/`: baseline hashes, check inventory and replay receipt.
- `DEPENDENCIES.mmd`: compact dependency graph.

## Reproduce

Use Python 3 and SymPy. `python3 verify.py --integrity-only` verifies file integrity. `python3 verify.py --with-sympy` runs the new exact checks in a temporary copy. Compile the root TeX twice using pdfLaTeX. The previous revision retains its own verifier; it was not globally replayed in this revision.

The archive has no premise based on numerical sampling or a new positivity table. Exact algebra PASS results are corroboration, not proofs of universal coverage. Reviews are from the same agent system.
