"""Focused exact replay for the reconstructed weak-IH open-axis argument.
Run with SymPy. Symbolic identities verify algebra, not the source hypotheses.
"""
import json
from pathlib import Path
import sympy as s
u,w,W,X,Y,Z,H,B,C,A,al,d,L=s.symbols('u w W X Y Z H B C A al d L', real=True)
Du=1+u*u; Dw=1+w*w
J=u*w*W+u*X-w*Y-Z
core=2*(J*J+Du*(Y-w*Z)**2+Dw*(X+u*Z)**2-Du*Dw*Z*Z)
F=4*C*Dw*(u*W-Y)**2+4*A*Du*Dw*Y*Y+4*d*J*J+4*al*Du*(Y-w*Z)**2+core
P=u*W/s.sqrt(B); E=s.sqrt(B)*w*Z; V=u*w*W
checks={}
def ck(name,expr):
    checks[name]=bool(s.simplify(s.expand(expr))==0)
ck('root_relation',P*E-V*Z)
expected=2*V**2-4*(1+H*w*w)*P*E+2/B*(H*H+u*u*(1-H)**2+H*H*w*w)*E**2
ck('scalar_core',core.subs({X:0,Y:H*w*Z})-expected)
LY=2*C*Dw*(H*w*Z-u*W)+2*Du*(A*H*Dw-al*(1-H))*w*Z-2*d*w*(V-(1+H*w*w)*Z)-w*(V-(1+H*w*w)*Z)+Du*(H-1)*w*Z
ck('Y_first_normal',s.diff(F,Y).subs({X:0,Y:H*w*Z})/4-LY)
LX=(1+2*d)*u*V-2*d*u*(1+H*w*w)*Z+u*(1-H)*w*w*Z
ck('X_first_normal',s.diff(F,X).subs({X:0,Y:H*w*Z})/4-LX)
ck('X_quadratic',s.diff(F,X,2)/2-(2*(Du+w*w)+4*d*u*u))
ck('Y_quadratic',s.diff(F,Y,2)/2-(4*C*Dw+4*A*Du*Dw+4*d*w*w+4*al*Du+2*w*w+2*Du))
ck('XY_coefficient',s.diff(F,X,Y)-(-8*d*u*w-4*u*w))
a,r=s.symbols('a r',real=True)
G=s.Matrix([[2+4*d,-4*d-2*(1-a),2*u*(1+2*d)],[-4*d-2*(1-a),4*d,-4*d*u],[2*u*(1+2*d),-4*d*u,2*(1+u*u)+4*d*u*u]])
expected_det=-8*((1+u*u+2*d*u*u)*a*a-2*(1+2*d)*(1+u*u)*a+(1+2*d)*(1+u*u))
ck('VZX_determinant',G.det()-expected_det)
# det is a concave quadratic; its two zeros at d=r^2/(2(1-r^2)).
ss=s.symbols('ss',positive=True)
gdet=s.factor(G.det().subs(d,r*r/(2*(1-r*r))).subs(u*u,ss*ss-1))
ck('determinant_zero_minus',gdet.subs(a,ss/(ss+r)))
ck('determinant_zero_plus',gdet.subs(a,ss/(ss-r)))
# A positive 2x2 principal block makes det>0 equivalent to full positivity.
ck('VX_minor',G.extract([0,2],[0,2]).det()-4*(1+2*d))
result={'description':'Exact symbolic replay of weak-IH open-axis identities; asymptotic source input is separately stated in the theorem.', 'checks':checks, 'passed':sum(checks.values()),'total':len(checks)}
path=Path(__file__).with_suffix('.json'); path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
if not all(checks.values()): raise SystemExit(1)
