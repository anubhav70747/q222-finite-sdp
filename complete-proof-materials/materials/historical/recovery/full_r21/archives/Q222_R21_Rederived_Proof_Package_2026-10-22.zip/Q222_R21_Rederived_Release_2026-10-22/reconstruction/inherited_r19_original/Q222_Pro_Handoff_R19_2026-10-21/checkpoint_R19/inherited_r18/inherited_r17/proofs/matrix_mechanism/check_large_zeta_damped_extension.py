"""New opening-cleared source checks for the large-zeta damped extension.
The complete DG3 identity is inherited unchanged; these checks address
precisely its new a-infinitesimal source normalization.
"""
import json
from pathlib import Path
import sympy as s

checks={}
def ck(name,expr):
    value=s.cancel(expr)
    assert value==0,(name,s.factor(value))
    checks[name]=True

a,L,t,pi,sigma=s.symbols('a L eta pi sigma')
x=a*L
r=1-t*sigma
h=1-L*pi
theta=L*pi
Kx=1+x
Rs=1+x*r
Ts=1+x*h
Ms=Rs-a*theta
y=t*L
Es=1-x*t*h
Qc=1-L*r
Pd=1+2*x*h+r*x*x*h+r*x*L+L+t*(Kx*L+x*x*h*theta)
P4=Ts*Es+(1-r)*(x*h+L)
Cn=Kx*(r+t)*Es/(2*Pd)
Dpj=Kx*(1+y)*(r+t)/(2*Pd)
At=P4/(2*r*Pd)
mn=Kx*(r+t)*h*(1+y)/(2*Ms*Pd) # m/(a^2 L)
aln=(r+t)*(a*Rs*h*(1+y)+Ms*Es)/(2*Qc*Pd) # alpha/L^2
bn=Kx*(r+t)*(1+a*h)/(2*Pd) # Bx*theta/L
m=a*a*L*mn
al=L*L*aln
Btheta=L*bn
qn=aln+m*pi*pi+bn*pi # q/L^2, no a or L inverse
Lt=mn-L*qn # eta*lambda = mu/(a^2 L)
A=t*At
T0=A+al+s.Rational(1,2)
Tm=T0+m
bp=At*r-m*theta-al-s.Rational(1,2)+r*Tm*L/2
G0=2*Lt-2*t
Gfull=2*bp+2*Dpj*h/r-2*t*Btheta*h/r
etaK=Cn*Dpj/(Cn*(Ts-sigma)+Dpj*sigma)
b0=bp-G0/2
Delta=h*h*At*etaK-b0*b0
cUovereta=At-G0*G0/(4*Lt)
dg=Gfull-G0

origin={a:0,L:0,t:0}
ck('eta_lambda_unit',Lt.subs(origin)-s.Rational(1,2))
ck('eta_harmonic_unit',etaK.subs(origin)-s.Rational(1,2))
ck('q_L2_unit',qn.subs(origin)-(1+pi)/2)
ck('b0_unit',b0.subs(origin)+s.Rational(1,2))

targets=[('Delta0',Delta,pi/2+s.Rational(1,4),sigma/2+s.Rational(3,4)),
         ('cU_over_eta',cUovereta,pi+s.Rational(1,2),sigma+s.Rational(3,2)),
         ('gamma_h_minus_G0',dg,pi+s.Rational(1,2),sigma+2)]
for name,f,lco,tco in targets:
    # Vanishing is exact at L=eta=0 for arbitrary a, not merely a=0.
    # Thus there is no untreated pure-a summand in the finite division.
    ck(name+'_vanishes_for_arbitrary_a',f.subs({L:0,t:0}))
    ck(name+'_L_coefficient',s.diff(f.subs(t,0),L).subs({a:0,L:0})-lco)
    ck(name+'_eta_coefficient',s.diff(f.subs(L,0),t).subs({a:0,t:0})-tco)

denominators={'r':r,'h':h,'Pd':Pd,'Qc':Qc,'Ms':Ms,
              'harmonic_denominator':Cn*(Ts-sigma)+Dpj*sigma,
              'eta_lambda':Lt}
residues={}
for name,d in denominators.items():
    val=s.factor(d.subs(origin))
    assert val!=0,(name,val)
    residues[name]=str(val)
checks['all_new_source_expressions_have_unit_denominators_without_a_inverse']=True

# Exact normalized identities for the changed angular and PH scales.
qhat,muhat,B,c=s.symbols('qhat muhat B c',positive=True)
q=L*L*qhat
mu=a*a*L*muhat
ck('angular_cross_squared_scale',mu*mu/(a*a*q*B)-a*a*muhat*muhat/(qhat*B))
# c^2=a/eta, so (x/(c sqrt(q)))^2=a*eta/qhat.
ck('PH_angular_squared_scale',x*x/(q*(a/t))-a*t/qhat)

out={'status':'PASS','count':len(checks),'checks':checks,
     'source_coefficients':{'Delta0_L':'pi/2 + 1/4','Delta0_eta':'sigma/2 + 3/4',
       'cU_over_eta_L':'pi + 1/2','cU_over_eta_eta':'sigma + 3/2',
       'gamma_h_minus_G0_L':'pi + 1/2','gamma_h_minus_G0_eta':'sigma + 2'},
     'unit_denominator_residues':residues,
     'scope':'New C14.3a eta-infinitesimal, a-infinitesimal source normalization for the complete DG identity, with bounded L/eta. No claim at unbounded L/eta.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
