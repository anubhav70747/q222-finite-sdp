#!/usr/bin/env python3
"""Factored checks for the exact one-parameter C2 all-tests dispatch.

The local contact theorem and general noncommuting exit are inherited.
No coefficient/testing scale comparison is made by these identities.
"""
from pathlib import Path
import json
import sympy as s
if not __debug__:
    raise SystemExit('Run without -O: assertions are proof checks.')
x,U,v,z=s.symbols('x U v z')
K=39*x*x+95*x+64
n=(11*x*x+45*x+16)/(2*K)
m=2*(x+2)*(x+3)*(5*x+4)/K
C=4*(x+2)*(x*x+3*x+5)/(3*x*K)
A=5*(x+2)*(5*x+4)/(x*K)
D=15*x*(x+1)*(5*x+4)/(2*(4-x)*K)
alpha=5*x*(x*x+3*x+5)/(2*K)
Du,Dv=1+U,1+v*v
h=(11+5*v*v)/2
k=-5/h+5*x/(8*(4+x))
Xw=3*v/h; Mw=v-Xw+U*v/4; jw=s.Rational(3,4)+v*Xw
fww=4*n*Du*Dv*Xw**2+4*m*Mw**2+s.Rational(9,4)*C*Dv*U
fww+=A*Du*Dv*U/4+4*D*U*jw**2+alpha*Du*v*v*U/4
fww+=2*(U*jw**2+Du*v*v*U/16+Dv*Xw**2)
fzz=4*n*Du*Dv*U*k*k+4*m*U*(k+1)**2+4*D*v*v*(U*k-1)**2+4*alpha*Du
fzz+=2*(v*v*(U*k-1)**2+Du+Dv*U*(k+1)**2-Du*Dv)
g=8*n*Du*Dv*(3/h)*k-8*m*(1-3/h+U/4)*(k+1)
g+=8*D*jw*(U*k-1)-2*alpha*Du+4*jw*(U*k-1)-Du+4*Dv*(3/h)*(k+1)
aa=s.cancel(x*(fww-fww.subs(U,0))/U)
bb=s.cancel((fzz-fzz.subs(U,0))/U)
cc=s.cancel(fww.subs(U,0)/(v*v))
ee=s.cancel(fzz.subs(U,0)/x)
gg=s.cancel(g)
def residue(E):
    E=s.cancel(E)
    num,den=s.fraction(E)
    # After the displayed monic divisions, no mixed denominator or
    # inverse of an infinitesimal survives in any bounded coefficient.
    for factor,power in s.factor_list(den)[1]:
        variables=factor.free_symbols
        if variables <= {x}:
            assert factor.subs(x,0)!=0
        else:
            assert variables <= {v}
            assert s.rem(factor,5*v*v+11,v)==0
    assert s.factor(den.subs({x:0,U:0}))!=0
    return s.factor(E.subs({x:0,U:0}))
expected=[5*Dv/8,5*(1+5*v*v)/(11+5*v*v),
          15*Dv/(11+5*v*v),(15*v*v+25)/32,-50*Dv/(11+5*v*v)]
for E,target in zip((aa,bb,cc,ee,gg),expected):
    assert s.factor(residue(E)-target)==0

# Full normal coefficients.  All divisions by U or v below are exact
# polynomial divisions; the cancelled denominators are units at x=U=0.
lxw=8*n*Du*Dv*3/h-8*m*(1-3/h+U/4)+8*D*U*jw+4*(U*jw+Dv*3/h)
lxz=8*n*Du*Dv*k+8*m*(k+1)+8*D*v*v*(U*k-1)+4*(v*v*(U*k-1)+Dv*(k+1))
assert residue(lxw)==residue(lxz)==0
ew=8*m*v*Mw-8*D*jw+2*alpha*Du*v*v-4*jw+Du*v*v
ez=-8*m*U*(k+1)-8*D*(U*k-1)-8*alpha*Du-4*(U*k-1)-4*Du
ez0=8*(D-alpha)
assert s.cancel(ez.subs(U,0)-ez0)==0
residue((ez-ez0)/U)  # bounded; its coefficient acquires rho*u
B=2*Dv*(x*A*Du-3*x*C)
assert residue(B+x*ew)==0
assert residue(ez0)==0
hxx=4*n*Du*Dv+4*m+4*D*U*v*v+2*(U*v*v+Dv)
hyy=x*(4*m*U*v*v+4*C*Dv+4*A*Du*Dv+4*D+4*alpha*Du*v*v+2*(1+Du*v*v))
assert s.factor(residue(hxx)-h)==0
assert s.factor(residue(hyy)-s.Rational(10,3)*Dv)==0

# Sharp scalar triangle inequality: equality only at z=1.
q=5*(1+z)/8; b=5*(1+5*z)/(11+5*z)
c=15*z*(1+z)/(11+5*z); e=5*(3*z+5)/32
d2=2500*z*(1+z)**2/(11+5*z)**2
J=d2-4*b*c-4*q*e
Jform=-25*(z+1)*(15*z*z-454*z+55)/(64*(5*z+11))
disc=-15625*(z-1)**2*(z+1)**2*(9*z*z-2370*z+121)/(4096*(5*z+11)**2)
assert s.factor(J-Jform)==0
assert s.factor(64*b*c*q*e-J*J-disc)==0
assert 88-s.Rational(10488,5)*s.Rational(55,454)<0

# Two exact core conductors for the infinity charts.
p,q,u,rho,X,L,R,T,N,Z=s.symbols('p q u rho X L R T N Z')
W,Y=s.symbols('W Y')
dp,dq=1+p*p,1+q*q
du=1+u*u
Jv=u*X-Z+q*(u*W-Y)
Hv=Jv**2+du*(Y-q*Z)**2+dq*(X+u*Z)**2-du*dq*Z*Z
candidate=(du+q*q)*X*X+du*rho*rho*L*L+u*u*q*q*Z*Z
candidate+=2*u*q*q*X*Z+q*q*rho*rho*R*R+2*u*q*rho*X*R
candidate-=2*q*rho*R*Z+2*du*q*rho*L*Z
assert s.expand(Hv.subs(W,(rho*R+Y)/u).subs(Y,rho*L)-candidate)==0
Ji=q*W+X-p*q*Y-p*Z
Hi=Ji**2+dp*(Y-q*Z)**2+dq*(p*X+Z)**2-dp*dq*Z*Z
candidate=(1+p*p*dq)*X*X+rho*rho*q*q*R*R+rho*rho*dp*L*L+q*q*Z*Z
candidate+=2*rho*q*X*R+2*p*q*q*X*Z-2*rho*p*q*R*Z-2*rho*dp*q*L*Z
assert s.expand(Hi.subs({W:rho*R+p*rho*L,Y:rho*L},simultaneous=True)-candidate)==0
report={'status':'PASS',
 'scope':'All independent projective testing charts for the displayed exact one-parameter family only',
 'finite_axis_scalar_residues':[str(t) for t in expected],
 'full_normals':'bounded zero-residue coefficients verified for every finite v',
 'exceptional_finite_axis_residues':['v=1','v=-1'],
 'outer_core_identities':2,
 'inherited_inputs':['exact local single-angle terminal','physical noncommuting-residue exit'],
 'coverage':'No comparison of coefficient and testing infinitesimals; no global C2 claim'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
