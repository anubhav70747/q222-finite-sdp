# Exact remaining checklist — revision 5

**Global analytical proof: unfinished. Six conditional residual domains remain.**

All rows mean their exact original domain minus every proved admission and symmetry image. A listed domain is not a nonemptiness claim. Local progress does not close a whole source row.

## Completed from the previous nine

- [x] **C2.W.IH** — every independent test; `advances/ih/weak/ih_all_tests_join.tex`.
- [x] **C2.S.IH** — every independent test; `advances/ih/strong/ih_remote_charts.tex`.
- [x] **C2.S.UI_HU** — every independent test; `advances/ui/ui_all_tests_recovered.tex`.

## C1.1

Native k,zeta infinitesimal, eta unbounded; original physical source and every independent test, minus prior admissions.

- [ ] Use NI3 to split e infinitesimal, unit, or unbounded; retain arbitrary k,eta,opening rates.
- [ ] Construct an exact full-parent conductor for the C,A-large / D,alpha-weak source pattern.
- [ ] Resolve all state normals, all nine testing residue charts and literal D=0 or beta=0 wherever allowed.

## C1.4

Native k infinitesimal, zeta noninfinitesimal, arbitrary positive eta; minus prior admissions.

- [ ] Exhaust NI4–NI6: L=k²zeta unbounded; L unit; L infinitesimal with eta bounded; L infinitesimal with eta unbounded.
- [ ] In each branch prove source exclusion or full-parent bounded Gram, retaining all openings and upper scales.
- [ ] Join every independent testing chart and both literal coefficient boundaries.

## C1.5

Native k unit; actual UI or UH after removing actual UU and inherited admissions.

- [ ] For actual UI choose eta unit,zeta=g² infinitesimal by exact stabilizer; remote complement is now proved.
- [ ] Complete UI only at ordinary u and infinitesimal v: center excess C,A,D packets, print all first-normal polynomials, lift their contact ideals and prove bounded strict Gram through a,r,J opening boundaries.
- [ ] The exact Laurent model CL1–CL6 is proved but does not complete that lift.
- [ ] For actual UH treat NI9 and NI10 source patterns, arbitrary openings, all independent tests and literal D=0/beta=0.
- [ ] Restore exact stabilizer images; do not silently reimpose k<=1 on a reflected source.

## C2.W.HH

d=1, C weak, alpha strong, actual HH, outside four-product and rational-curve admissions; n>=0.

- [ ] Derive source coordinates with bounded normalized ratios for every permitted multiple-parameter opening.
- [ ] Prove a full-parent bounded Gram or an exact exclusion at each independent testing chart.
- [ ] Retain full normals and literal n=0; restore only symmetries preserving the weak-C orientation.

## C2.S.II_HH

d=1, C and alpha strong, actual II/HH orbit, a weak member of m,A,D; outside all admitted real-rational source curves.

- [ ] Treat arbitrary independent source parameters, not only the already admitted one-parameter family.
- [ ] Find a full-parent root allocation controlling every first normal and all relative source/test rates.
- [ ] Resolve all opening boundaries and testing charts, including n=0, then restore exact II/HH reflection.

## C2.S.HI

Original actual HI source; only testing p=1/u and v both nonzero infinitesimal remain (up to sign gauges).

- [ ] Use exact HI-entry: mqK,Cyt,Dyj,alphaqE are units and A~qy; all four large events have remote certificates.
- [ ] Start from HI-SOS and exact source rho=2/(6n+1+sqrt(36n²+20n+1)); preserve literal n=0.
- [ ] Subtract actual-contact centered event squares; choose legal raw normal frames with pure-testing determinants 1 or 1-p²v².
- [ ] Allocate every leftover first-normal term to admissible weighted roots; P=p/sqrt(q) and V=v/sqrt(y) cannot be assumed bounded.
- [ ] Prove a bounded strict Gram or exact tensor SOS for arbitrary E,t,j,K and independent p,v,q,y rates. Literal p=0 or v=0 already have exact SOS.

## Required acceptance gates for every remaining domain

- [ ] G1 Original source entry, signs, and every bounded ratio.
- [ ] G2 Exact full-parent decomposition preserving actual contact and jets.
- [ ] G3 Admissible roots; only pure-source/pure-test inverses or radicals.
- [ ] G4 Every first state normal and every hard quadratic coupling.
- [ ] G5 Strict residue or exact SOS; resolve every equality case.
- [ ] G6 All independent projective tests, signs, real/complex states.
- [ ] G7 Literal retained coefficient boundaries and all positive opening rates.
- [ ] G8 Analytical review plus narrowly scoped exact algebra corroboration.
- [ ] G9 Admit only the proved quantified domain and exact symmetry images.

## Global conclusion

- [ ] U1: prove exact source/test exhaustion after all six rows close.
- [ ] U2: apply the inherited finite-lift bridge with its original universal quantifiers.
- [x] U3: deliver the cumulative package and precise frontier.

No evaluated global affine pencil is asserted. Exact checkers establish identities, not missing coverage.
