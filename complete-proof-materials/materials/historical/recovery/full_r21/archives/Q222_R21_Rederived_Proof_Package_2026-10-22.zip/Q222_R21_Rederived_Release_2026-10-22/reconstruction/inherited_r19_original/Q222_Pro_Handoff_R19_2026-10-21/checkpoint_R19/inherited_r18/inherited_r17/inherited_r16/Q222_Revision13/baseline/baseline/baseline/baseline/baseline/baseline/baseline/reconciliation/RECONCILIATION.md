# Reconciled current status — 17 October 2026

The authoritative status for this cumulative package is ../PROOF_STATUS.json.
All metadata inside current/, parallel/, and the retained ZIP is preserved
historically and describes those packages at their own dates.

The detailed BASELINE_RECONCILIATION.md reconciles the two earlier packages
before the two extensions in advances/. Its references to the one-weak C2
family as LOCAL ONLY are correct for current/ but are superseded here by
the explicit all-tests extension. Its unit-gap C1 scope is likewise
superseded by the arbitrary-positive-opening theorem. Neither update
promotes the global atlas-free theorem to complete.

## Reconciliation

The recovered parallel regular-source moving-frame theorem and weak-angle
C1 D-unit theorem are shorter replacements within inherited positive
TOTAL-NORMALIZED-d coverage. Their unfinished shortcut cases do not reopen
the full inherited source partition. Merely setting d=1 is not equivalent
to positive residue of d divided by the sum of all source weights.

The latest positive-infinitesimal-normalized-d advances are complementary:

- Preserve the complete two-weak C2 finite-contact theorem from current/.
- Extend ordinary-angle C1 from unit a,t,M,J to all positive a,t,M,J,
  retaining k,s=g/f units, eta infinitesimal, and the existing contact entry
  sign/minor domain. Large packet coefficients remain outside the bounded Gram.
- Promote the one explicit rational C2 family from its local contact chart
  to all independent projective tests. This is not a general one-weak theorem.
- Add a reusable bounded weighted Taylor lemma with explicit ideal membership
  and strict scaled Hessian hypotheses. It does not supply those hypotheses
  for every physical source.

## Remaining global obligation

After inherited canonical and closed-face reductions, positive-residue
normalized-d sources and noncommuting testing residues at every source
scale are already analytically covered. The remaining atlas-free obligation
is the complement of all supplied analytical admissions among commuting
tests with positive infinitesimal normalized d. Literal d=0 is event SOS.

The retained full global package supplies the historical computer-assisted
atlas theorem. It is included intact, not newly replayed or externally
verified. An evaluated global affine pencil is still not supplied.

## Proof imports

The new integrated manuscript prints the weighted lemma, two-weak C2 theorem,
original ordinary-angle C1 argument and its extension, local one-weak C2
argument and its all-tests extension, determinant/conductor bridge, and
source/strict-Gram appendices. Baseline reconciliation gives precise paths
and theorem labels for the inherited positive-d cover and parallel proofs.
