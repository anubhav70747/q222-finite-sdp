#!/usr/bin/env python3
"""Exact universal circuit/frame identities. Python standard library only."""
from fractions import Fraction as Q
from pathlib import Path
import json

if not __debug__:
    raise RuntimeError('Assertions must be enabled.')

class P(dict):
    @staticmethod
    def cast(x):
        return x if isinstance(x,P) else P({(0,)*6:Q(x)}) if x else P()
    def __add__(self,other):
        out=P(self)
        for k,v in P.cast(other).items(): out[k]=out.get(k,0)+v
        return P({k:v for k,v in out.items() if v})
    __radd__=__add__
    def __neg__(self):return P({k:-v for k,v in self.items()})
    def __sub__(self,other):return self+-P.cast(other)
    def __rsub__(self,other):return P.cast(other)+-self
    def __mul__(self,other):
        out=P()
        for m,a in self.items():
            for n,b in P.cast(other).items():
                k=tuple(x+y for x,y in zip(m,n));out[k]=out.get(k,0)+a*b
        return P({k:v for k,v in out.items() if v})
    __rmul__=__mul__
    def __pow__(self,n):
        out=P.cast(1)
        for _ in range(n):out=out*self
        return out

def var(i):return P({tuple(int(j==i) for j in range(6)):Q(1)})
a1,a2,a3,a4,_,_=map(var,range(6))
b,c,h=a1*a1-a3*a3,a2*a2-a3*a3,a3*a3-a4*a4
q1,q2=a1*a2-a3*a4,a1*a3-a2*a4
circuit=sum((a**4 for a in [a1,a2,a3,a4]),P())-4*a1*a2*a3*a4
assert circuit==b*b+c*c+h*h-b*c+c*h+q1*q1+q2*q2
assert circuit==(a1*a1-a2*a2)**2+(a3*a3-a4*a4)**2+2*q1*q1
# The three contrast directions have strict rational Gram.
G=[[Q(1),Q(-1,2),Q(0)],[Q(-1,2),Q(1),Q(1,2)],[Q(0),Q(1,2),Q(1)]]
pivots=[G[0][0],G[0][0]*G[1][1]-G[0][1]**2,
        G[0][0]*(G[1][1]*G[2][2]-G[1][2]**2)-G[0][1]**2*G[2][2]]
assert pivots==[Q(1),Q(3,4),Q(1,2)]
# Native variables delta,k,b,u,w,v; no radicals needed for these identities.
delta,k,beta,u,w,v=map(var,range(6))
A,B,C,D0=w*v,delta*v,delta*beta*beta*u*w,delta*delta*k**3*beta*beta
g0,h13,h23,h34=B-C,A-k*C,u*B-k*C,k*C-D0
g4=u*w*v-delta*delta*k**4*beta*beta
assert g4==u*h13+k*h23-k*u*g0+k*h34
Ju,Jw,Jv=u-k,w-delta*k,v-delta*k*k*beta*beta
assert C*Ju==h23-u*g0
assert C*Jw==delta*h13-w*g0
assert C*Jv==beta*beta*(w*h23+delta*k*h13-k*w*g0)
q1_squared=delta*u*w*Jv*Jv
rstar=h13+h23-h34-2*k*g0
assert k*C*rstar==q1_squared-h13*h23
# Why the single three-square pairing cannot absorb arbitrary errors:
# at a=(1,1,i,-i), its three roots vanish but h13=2. Check exactly in Q(i).
def cmul(x,y):return (x[0]*y[0]-x[1]*y[1],x[0]*y[1]+x[1]*y[0])
one=(Q(1),Q(0));imag=(Q(0),Q(1));mi=(Q(0),Q(-1))
assert cmul(one,one)==cmul(one,one)
assert cmul(imag,imag)==cmul(mi,mi)
assert cmul(one,one)==cmul(imag,mi)
assert cmul(one,one)!=cmul(imag,imag)
report={'status':'pass','arithmetic':'standard-library exact rational polynomial arithmetic',
        'circuit_contrast_principal_minors':[str(x) for x in pivots],
        'soft_frame_roots':6,'hard_normal_roots':2,'remainder_strict_gram_dimension':8,
        'checks':['two-pairing circuit identity','strict contrast Gram','g4 conductor',
                  'three first-order conductors','second-order circuit syzygy',
                  'single-pairing complex-zero obstruction'],
        'scope':'Universal identities and frame positivity; full scalar/contact source checks supplied separately.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
