"""New polynomial source checks for small-L, eta-unbounded C1."""
import json
from pathlib import Path
import sympy as s
checks={}
def zero(name,expr):
    val=s.factor(s.together(expr))
    if val!=0: raise AssertionError((name,val))
    checks[name]=True
    print("PASS",name,flush=True)
x,L,si,r,h=s.symbols("x L sigma r h")
th=1-h;K=1+x;R=1+x*r;T=1+x*h;et=1/si;ze=L/x
E=1-x*h/si;e=1-E;Q=1-L*r;M=R-x*th/L;J=T-si*(1-r)
Pd=1+2*x*h+r*x*x*(h+ze)+L+et*x*(K*ze+x*h*th)
P=si*Pd;S=si+L;H0=1+L*(1-r);B=P+x*(J-si)
HH=R*H0+(1-r)*x*h*(2+x*r)-e*(2+x*(1+h+r*th))+K*e*e
P4=T*E+x*(1-r)*(h+ze)
Pa=R*h*(1+L/si)+ze*M*E
B5=K*(1+L/si)*(r+et)-et*J*Pd
Bbeta=K*x*(r+et)*(h+ze)-th*Pd
D=B5/(2*et*J*Pd);be=Bbeta/(2*th*Pd)
m=K*x*(r+et)*h*(1+L/si)/(2*M*ze*Pd)
al=x*x*ze*(r+et)*Pa/(2*Q*Pd)
C=K*(r+et)*E/(2*(1-r)*Pd);A=et*P4/(2*r*Pd)
zero("small_L_cleared_denominator",P-si*(1+L+2*x*h+r*x*L+r*x*x*h)-K*L-x*x*h*th)
zero("small_L_beta_identity",2*th*P*be-h*B+si*H0)
zero("small_L_joint_sphere_identity",2*P*(J*D+x*th*be)-si*si*HH)
b2=2*P*x*th*be/(si*si*HH)
zero("small_L_exact_e_identity",e*B-x*H0-si*HH*b2)
zero("small_L_squared_e_bound_identity",e*e*B/S-(x/S)*(e*H0+h*HH*b2))
zero("small_L_C_opening_product",C*(1-r)-K*(1+si*r)*E/(2*P))
zero("small_L_A_opening_product",A*r-P4/(2*P))
zero("small_L_m_weight",m-K*(1+si*r)*e*S/(2*M*ze*P))
zero("small_L_alpha_weight",al-(1+si*r)*(L*R*e*S+L*L*M*E)/(2*Q*P))
mu=K*(1+si*r)*S/(2*M*ze*P)
zero("small_L_exact_m_sphere_split",m-mu*x*H0/B-mu*si*HH*b2/B)
out={"status":"PASS","identities":len(checks),"checks":checks,"scope":"Source bounds only for C14.4. Exact sphere, weights and e-square identity; no new full-parent all-tests admission."}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({"status":"PASS","checks":len(checks)}))
