import json
from pathlib import Path
import sympy as s
HERE=Path(__file__).resolve().parent
u,v,t=s.symbols('u v t',positive=True)
m,c,A,D,al,be=s.symbols('m c A D alpha beta')
Du,Dv=1+u*u,1+v*v;d=s.Integer(1)
packets=[([v,-1,u*v,-u],4*m),([u,0,-1,0],4*c*Dv),([0,0,1,0],4*A*Du*Dv),([u,u*v,-1,-v],4*D+2*d),([0,0,v,-1],(4*al+2*d)*Du),([0,1,0,u],(4*be+2*d)*Dv),([0,0,0,1],-2*d*Du*Dv)]
P=s.zeros(4)
for row,coef in packets:
 r=s.Matrix(row);P+=coef*r*r.T
h=s.Matrix([1,-s.Rational(5,8)*t*t,t/2,3*t/4]);ct={u:t,v:1}
eq=list(P.subs(ct)*h)+[(h.T*P.diff(z).subs(ct)*h)[0]for z in (u,v)]
sol=s.solve(eq,[m,c,A,D,al,be],dict=True)[0]
assert all(s.cancel(e.subs(sol))==0 for e in eq)
limits={z:s.limit(sol[z],t,0,dir='+')for z in sol}
assert limits=={m:0,c:s.Rational(3,8),A:s.Rational(3,8),D:1,al:1,be:1}
# Positive for 0<t<=1/2: the three potentially negative polynomial factors
# have these exact upper bounds in z=t^2<=1/4.
zmax=s.Rational(1,4)
sign_bounds={'5z-8':5*zmax-8,'5z2-6z-16':5*zmax**2-16,
 '25z3+170z2+32z-128':25*zmax**3+170*zmax**2+32*zmax-128}
assert all(q<0 for q in sign_bounds.values())
# At the weak-angle limit, three hard coordinates X,Y,Z remain strict.
P0=P.subs(limits)
hard0=P0.subs({u:0,v:1})[1:,1:]
assert hard0==s.diag(12,18,8)
hparity=s.Matrix([1,0,u/2,3*u/4])
fparity=s.expand((hparity.T*P0*hparity)[0])
Ucoefficient=s.expand(fparity).coeff(u,2)
assert s.factor(Ucoefficient)==s.Rational(9,2)*(v-1)**2
grad=(P.diff(v).subs(sol).subs({u:t,v:1})*h)[1:,0]
grad_scaled=s.Matrix([s.limit(q/t,t,0,dir='+')for q in grad])
bare=s.limit(((h.T*P.diff(v,2).subs(sol).subs({u:t,v:1})*h)[0]/(2*t*t)),t,0,dir='+')
relaxed=s.factor(bare-(grad_scaled.T*hard0.inv()*grad_scaled)[0])
assert grad_scaled==s.Matrix([0,6,0]) and bare==s.Rational(9,2) and relaxed==s.Rational(5,2)
normal_sum=s.factor(1+sum(sol.values()))
assert s.limit(1/normal_sum,t,0,dir='+')==s.Rational(4,19)
out={'status':'PASS','source_contact':{'u':'t','v':'1','state':list(map(str,h))},
 'parameter_domain':'0<t<=1/2, or positive infinitesimal t in a real closed source field',
 'd':'1','coefficients':{str(q):str(s.factor(sol[q]))for q in sol},
 'limits':{str(q):str(limits[q])for q in sol},
 'six_exact_contact_equations_zero':True,'source_coefficients_positive':True,
 'negative_factor_upper_bounds':{k:str(v)for k,v in sign_bounds.items()},
 'normalized_d_limit':'4/19',
 'global_physicality_proof':'Positive outer Laurent coefficients, exact stationary zero and exponent balance imply determinant nonnegative by weighted AM-GM; original Z=0 core gives three positive directions; literal axes and signed angles use exact core squares and sign conjugation.',
 'hard_XYZ_residue':[[str(a)for a in hard0.row(i)]for i in range(3)],
 'bare_U_vnormal_coefficient_at_residue':str(Ucoefficient),
 'v_state_derivative_divided_by_t_limit':list(map(str,grad_scaled)),
 'bare_v_curvature_over_t2_limit':str(bare),'relaxed_v_curvature_over_t2_limit':str(relaxed),
 'naive_source_vnormal_whitening_failure':'Using source feature t*(v-1) instead of test feature u*(v-1) leaves Gram coefficient (9/2+o(1))*u^2/t^2; after exact state relaxation its leading coefficient is (5/2+o(1))*u^2/t^2. The source coefficient t^-2 is unbounded.',
 'full_weak_source_branch_proved_here':False}
(HERE/'WEAK_SOURCE_FAMILY_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
