# Independent review: C1.4, unbounded L and unit sigma

**Verdict: PASS for this stated subdomain.** Reviewed `../oct19_r7_c14_large_l_unit/large_l_unit.tex` and independently replayed `check_large_l.py`: all **42 exact identities passed**. This is a same-system independent mathematical review, not an external referee certification. It does not admit the sigma-infinitesimal branch or the whole C1.4 row.

The source is the exact NC family with original nonnegative D and beta. The inherited common remote theorem leaves precisely bounded u and projectively unbounded v; the reciprocal endpoint w=0 is included by the polynomial identities. Infinitesimal u and unit u exhaust this remaining strip. The source conclusions h a positive unit and DJ a positive unit justify the stated critical pivots. D=0 is empty in this subdomain; beta=0 remains covered.

For infinitesimal u, the scalar and all three first-normal coefficients have explicit bounded polynomial support. Successive monic division gives the displayed scalar and normal decompositions without division by a small angular difference. The scalar division by z is justified coefficientwise by the displayed support at xi=sigma z. The six roots retain the full quadratic normal block. Their first five residue pivots are positive units. The exact identity

    V² = sigma t A_theta² + u sigma(t-x) A_theta R_h - sigma(t-x) V N_z

allows any fixed finite positive V² pivot at only infinitesimal cost in the other entries. It therefore controls the possible finite N_z V term. No scalar-only positivity argument is substituted for the full normal Gram.

For unit u, the exact raw six-frame square completion uses only E_t G_t=R_t Z. The strict two-block allocation follows from the displayed numerator and discriminant identities and source h >= sigma/(1+sigma). The corrected choice is the intersection

    (-sqrt(AB), sqrt(AB)) intersect (E0-sqrt(CD0), E0+sqrt(CD0)).

Its nonemptiness follows from the strict allocation inequality and it makes both blocks strictly positive. The lower bound D0>0 is explicit. At the double J=theta=0 face, the lower allocation endpoint tends to |u| while sqrt(U(1+U))>|u|, so the constrained gap stays positive. The triangular minimizers are bounded through the single and double faces; this verifies constrained coercivity, not only a determinant sign.

The actual centered cap rows admit the exact right inverse

    Delta F=e_F,  Delta X=e_beta,
    Delta R=(e_D-u e_beta+q w e_F)/u.

Its only denominator is the pure-testing unit u. Thus no mixed inverse or inverse opening parameter is introduced. Fixing the ordinary real u residue gives the ordinary finite-dimensional cap argument. This handles independent b/Q and J/theta opening rates, including their combinations; it does not require comparable rates. Bounded rows retain their full coefficients, while divergent rows admit finite caps by the strictly positive constrained limit and the bounded right inverse. Radicals and delta denominators in the away calculation are used solely to choose ordinary real constants; the exact tensor Gram is the polynomial raw frame with finite caps.

Two presentation corrections identified during review were integrated: the cap right inverse is separated rather than source-only, and the rho interval includes its second upper bound. No remaining mathematical gap was identified within this scope. No broad numerical sampling was used; the replay checks exact rational identities, while the positivity and exhaustion arguments were reviewed directly.
