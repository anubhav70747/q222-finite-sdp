# Review of the arbitrary-opening C1 extension

Reviewed `analysis_atlas/reconcile_c1/arbitrary_shape_openings.tex`
against the current ordinary-angle theorem and the native retained-packet
identity. **No substantive gap found.** The extension legitimately removes
the lower-bound assumptions on all four positive openings
\(a,t,M,J\), while retaining ordinary-unit \(k,s\), infinitesimal
\(\eta>0\), and the stated native source-entry domain.

## Boundedness with arbitrary opening rates

The hypotheses imply \(0<a<T<K\) and \(0<t<R<K\), so \(a,t\) are
bounded even without an explicit boundedness assumption. Since
\(\eta\) is infinitesimal, \(R,T\) have the positive-unit residue of
\(K\). Thus \(p=t/R\) and \(h=a/T\) are bounded in \((0,1)\),
independently of the rates of all four openings. The native coquotients
have the stated shape-independent residues.

The four packet subtractions in (AO3)--(AO4) are exact. All appearances
of potentially unbounded \(t/M,M/t,J/a,a/J\) stay in separately positive
packet coefficients. The remainder uses bounded \(p,h\), bounded
coquotients, and only the source-unit inverses \(R^{-1},T^{-1}\).
The factor \(\Lambda=RTc_3/(2a)\) may be unbounded, but is a positive
pure-source factor; its restoration requires no bounded or mixed inverse.

The inverse coordinate formulas (AO5) are exact. Their sole testing
denominator is \(D_u\), and multiplying the remainder by \(D_u\)
clears it: the weak terms contain \(D_uY^2\) or
\(D_u(vY-Z)^2\), so only one residual power of \(D_u^{-1}\) remains
before this multiplication. No mixed determinant is inverted.

## Endpoint caps

The four inequalities (AO12) follow directly from \(M<R\), \(a<T\),
\(J<T\), \(t<R\) and the original coefficient formulas. Their right
sides have residues, respectively,

\[
\frac{2k^2}{s^2K},\qquad \frac2K,\qquad
\frac2K,\qquad \frac{2k^2}{s^2K},
\]

where the displayed expressions are read at source residue. All are
strictly positive real numbers. A single positive real \(\mu\) below
their minimum therefore makes every excess packet in \(F/a\)
nonnegative. This remains valid when the original \(D\) or \(\beta\)
itself is infinitesimal: the cap is on \(D/a\) or \(\beta/a\), not on
the original coefficient.

The unchanged weak weights satisfy
\(d/a=\eta d_1\), \(A/a=\eta^2A_2\),
\(\alpha/a=\eta^2\alpha_2\), with positive-unit residues
\(4K,2,2s^2k^4\), respectively. Thus the endpoint allocations inherited
from the ordinary-angle proof apply to the capped parent. At the Alice
zero endpoint the signed soft cross coefficient has an extra \(u\);
at the reciprocal endpoint its soft part has an extra \(q=1/u\).
The two weak diagonal reserves remain units in the scaled root frame.
Literal infinity uses the homogeneous polynomial directly.

The capped baseline is used only in these endpoint or strict strong-event
charts. No claim of its global physicality, or of its positivity near an
ordinary matched contact, is needed.

## Finite-unit chart and exact contact

Expanding (AO4) gives the stated six-root bounded remainder. The leading
linear normal coefficients cancel because \(H_2,H_b,H_3,H_5\) have the
same residue. The \(p\)- and \(h\)-dependent scalar coefficients sum
to one. This yields (AO7) with the original scalar \(S\), independently
of all shape-opening residues.

The native exact contact becomes
\((u,w,v,N,L)=(k,sR/K,ks\eta,0,0)\). Each retained packet and its
first derivatives vanish there, even if its pure-source coefficient is
unbounded. Hence the full bounded remainder has exact value and gradient
zero. The displayed bounded ideal membership survives translation by
\(v_c=ks\eta\); finite Taylor allocation gives a Gram on (AO11).
Its hard pivots and scaled three-variable Hessian are exactly the ones
printed in the extension. No comparison such as \(v/\eta\) is used.

## All-tests dispatch and scope

The cases exhaust the two projective angle lines:

- Bob homogeneous sine of nonzero residue: the four capped strong event
  amplitudes have trivial common state kernel at every Alice angle.
- Bob small and Alice zero or infinite in residue: the capped endpoint
  allocations apply.
- Bob small and Alice a finite unit: the bounded retained-packet remainder
  applies; the capacity identity handles unmatched Alice residue, the
  exact state relation handles unmatched state residue, and the five-root
  contact Gram handles the remaining positive-core-state branch. The
  opposite state sign exits through the pure-testing nonnegative core.

State normalization, sign gauges, packet restoration, and splitting complex
states are the same legitimate operations as in the current ordinary-angle
proof. In particular, retaining packets before bounding the remainder
removes the original need for bounded event coefficients in outer charts.

This is a genuine extension of the current ordinary-angle C1 theorem to
**all positive** \(a,t,M,J\) on its unit-\(k\), unit-\(s\),
infinitesimal-\(\eta\) native row. It remains a positive-infinitesimal
normalized-\(d\) result: \(C=2\), while \(d\asymp a\eta\) and \(a\)
is bounded. It does not follow from the recovered parallel package's
positive-normalized-\(d\) theorems.

Do not broaden it to nonunit \(k\) or \(s\), non-small \(\eta\),
literal zero openings undefined by the rational source, or arbitrary
canonical sources without the retained contact-sign/nonzero-minor entry.
The old unit-opening theorem is now a special case; the global remaining
cover is not exhausted.

Re-ran the small standard-library checker
`analysis_atlas/reconcile_c1/check_shape_openings.py`: **34 exact checks
passed** in under a second. The source inequalities, boundedness, and
chart exhaustion above were reviewed analytically rather than inferred
from the check count. No large computation was performed.
