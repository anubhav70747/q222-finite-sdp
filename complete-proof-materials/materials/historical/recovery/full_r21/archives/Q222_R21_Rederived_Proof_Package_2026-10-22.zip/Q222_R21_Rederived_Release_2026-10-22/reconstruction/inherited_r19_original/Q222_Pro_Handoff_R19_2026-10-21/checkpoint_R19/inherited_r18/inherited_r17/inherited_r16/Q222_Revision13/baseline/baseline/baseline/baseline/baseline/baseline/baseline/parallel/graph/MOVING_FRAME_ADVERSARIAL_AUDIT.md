# Adversarial audit of the finite moving frame

This is a same-system mathematical check of the new finite-unit theorem, not external independent review.

1. **Particular hard compression.** Three positive eigenvalues of P alone would not prove the chosen Z=0 block is positive. The actual core restriction does: 2d[(uW+uvX-Y)^2+Du v^2Y^2+Dv X^2]. The three coefficient rows have determinant of nonzero unit magnitude u v sqrt(Du Dv) at finite positive unit contact angles. Adding original nonnegative event squares preserves a positive-definite residue. Therefore Q0^{-1} is a bounded pure-source matrix.

2. **No state chart assumption.** The construction sets h=(-Q0^{-1}r0,1) algebraically. det P0=0 gives P0 h=0, without dividing an actual contact state's Z component. For an arbitrary independent testing state z=Z is allowed to vanish. The state transport has determinant one and is inverted by subtraction, with no division by z or by a mixed expression.

3. **Both cross derivatives.** For each measurement direction j, P0 kj=-P_j h. The first three components follow from the source hard solve; the last follows from exact scalar stationarity h^T P_j h=0 and h_Z=1. Thus every component of the state cross block b has zero constant and both zero linear coefficients. Cancellation only after contraction with h would be insufficient, but is not what is used here.

4. **Full polynomial rather than jet.** Every monomial of b and f is allocated by the stated deterministic contact-ideal division. At no step is a degree-three or higher remainder dropped. Original P has total degree at most four; multiplying by a linear moving state increases the scalar degree to at most six, and dividing by the two explicit angle roots gives Gram degree at most four. The exact anchor export has 154 nonzero Gram terms, and the entire scalar identity was expanded to zero.

5. **Strictness is proved, not assumed.** The curvature C is the exact quadratic determinant coefficient divided only by det Q0 in the source field. Its positive-residue conclusion follows from the balanced exponent incidence proof and physical exclusions. A singular covariance could not be repaired by hard-block positivity; it is separately excluded for finite-unit C1 and C2 sources.

6. **Tensor legality.** Every coefficient of the literal shifted polynomial and finite transport lies in Ac tensor At. If test and source angles have the same real residues r,s, then delta_u=1 tensor(ut-r)-(uc-r)tensor1 and likewise delta_v lie in the infinitesimal tensor ideal. Consequently the residue of the exact Gram is diag(res Q0,res C)>0. The bounded-Gram lemma applies to the mixed feature vector xi as a formal vector over T; it does not require xi itself to be a pure testing vector. This produces separated tensor roots after coefficient decomposition and finite expansion. It neither factors a mixed algebraic eigenvalue nor inverts a mixed unit.

7. **Far test residues.** Positive exponent support spans the two-dimensional exponent space. Its real-residue logarithmic Hessian is therefore positive definite at every finite angle, not just at contact. The stationary zero is unique. A different finite positive testing residue gives strictly positive determinant and all four positive state eigenvalues, so the ordinary strict-residue Gram exit applies.

8. **Scope.** The interior proof just audited uses d unit and finite positive unit source and testing angles. Companion root/ALL_TEST_C1.md and rank_two/ALL_TEST_C2.md now close all independent testing-axis limits for these source hypotheses; their audit is recorded in ALL_TEST_AND_WEIGHTED_ADMISSION_AUDIT.md. Source contact-angle degenerations and d losing residue remain outside this interior lemma. A separate weighted D-unit weak-source theorem has also now been audited, with its narrower source hypotheses stated explicitly.

Executed exact checks: check_residue_covariance_census.py; check_moving_graph_frame.py; check_original_moving_frame.py. All PASS. No numerical SDP, random sampling, or historical atlas replay was used.
