"""Exact source formulas used by reconstructed IH certificates."""
import sympy as S
z,y,B,H,r=S.symbols('z y B H r', positive=True)
L=B-H; Ac=1+z*r; Q=Ac+L; j=Ac-L/y
G=B+z*(H+r-1)
delta=z+(1+z)*B+(1+z)*B**2+2*z*(1+z)*B*r+z**3*r**2+2*z**2*r+y*((1+z)*B+z+z*z*r*(2-r))
M=(1+z)*(B+z*r)*(H+y)-z*(1+y)*(1-r)*L
n=((B+z*r)*Ac*Q-r*delta)/(2*r*delta)
m=z*z*(1+y)*(1-r)*Ac*Q/(2*G*delta)
C=Ac*M/(2*L*delta)
A=y*Ac*(B+z*r)*Q/(2*H*delta)
D=(1+z)*(B+z*r)*(B-z*y*r)*Q/(2*y*j*delta)
al=(B+z*r)*M/(2*(1-H)*delta)
K=4*A*H**2+8*D*H*r+4*al*(1-H)**2+4*m*(H+r-1)**2+2*(H+r-1)**2+4*n*r*r
k=K-4*B*B*m/z**2+8*z*n*r*r+8*A*H*H/y
weights={'n':n,'m':m,'C':C,'A':A,'D':D,'alpha':al}
