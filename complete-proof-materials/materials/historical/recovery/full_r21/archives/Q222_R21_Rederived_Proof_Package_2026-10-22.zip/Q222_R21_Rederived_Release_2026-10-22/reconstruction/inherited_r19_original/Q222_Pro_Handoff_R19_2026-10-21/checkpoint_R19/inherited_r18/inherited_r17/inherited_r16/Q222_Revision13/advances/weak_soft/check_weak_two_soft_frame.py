#!/usr/bin/env python3
"""Exact checks for the weak-B reduction only; no weak-B admission."""
from pathlib import Path
import json
import sympy as s
u,v,W,Z,xi,eta,h,r=s.symbols('u v W Z xi eta h r')
n,m,C,A,D,al=s.symbols('n m C A D alpha')
mb,db,g,e=s.symbols('m_cap D_cap g e')
U=u*u; V=v*v; du=1+U; dv=1+V
X=-r*u*Z+xi; Y=h*u*W+eta
M=v*W-X+u*v*Y-u*Z; J=u*W+u*v*X-Y-v*Z
p=v*Y-Z; bb=X+u*Z
core=2*(J*J+du*p*p+dv*bb*bb-du*dv*Z*Z)
F=4*n*du*dv*X*X+4*m*M*M+4*C*dv*(u*W-Y)**2+4*A*du*dv*Y*Y+4*D*J*J+4*al*du*p*p+core
out={}
def ck(name,x):
    x=s.cancel(s.together(x));out[name]=bool(x==0)
    if x!=0:raise AssertionError((name,s.factor(x)))
aw=m*V*(1+h*U)**2+C*dv*(1-h)**2*U+A*du*dv*h*h*U+(D+s.Rational(1,2))*(1-h)**2*U+(al+s.Rational(1,2))*du*h*h*U*V
az=al+D*V+U*(n*r*r+(m+s.Rational(1,2))*(1-r)**2+al+V*((n+s.Rational(1,2))*r*r+2*D*r))+U*U*(n*r*r+V*(n+D+s.Rational(1,2))*r*r)
b0=m*(1-r)+D*(1-h)+al*h+s.Rational(1,2)
b1=m*h*(1-r)+r*(D+s.Rational(1,2))*(1-h)+(al+s.Rational(1,2))*h
ck('entire_two_soft_scalar',F.subs({xi:0,eta:0})-4*(aw*W*W+az*Z*Z-2*u*v*(b0+b1*U)*W*Z))
ck('negative_mass_bound',b0-b1-(1-h)*(1-r)*(m+D+s.Rational(1,2)))
rm=M-g*v*W; rd=J+e*u*W
ck('m_centered_remainder',4*m*M*M-4*(m-mb)*rm*rm-4*mb*M*M-8*(m-mb)*g*v*W*M+4*(m-mb)*g*g*V*W*W)
ck('D_centered_remainder',4*D*J*J-4*(D-db)*rd*rd-4*db*J*J+8*(D-db)*e*u*W*J+4*(D-db)*e*e*U*W*W)
qs=C*(1-h)**2+A*h*h
bca=A*h-C*(1-h)
ck('C_A_pair',4*C*dv*(u*W-Y)**2+4*A*du*dv*Y*Y-4*dv*(C+A+A*U)*eta*eta-8*dv*u*W*eta*(bca+A*h*U)-4*dv*U*W*W*(qs+A*h*h*U))
ck('n_packet',4*n*du*dv*X*X-4*n*du*dv*(xi*xi-2*r*u*Z*xi+r*r*U*Z*Z))
z,y,H,L,B=s.symbols('z y H L B')
T=B+z*r; ac=1+z*r; Sc=ac+L
Ms=(1+z)*T*(H+y)-z*(1+y)*(1-r)*L
ck('C_A_source_cancellation',Ms-y*T*Sc-T*(1+z)*H+y*T*L-z*(1-r)*(y*T-(1+y)*L))
# This is the exact constant normal block after the retained packets.
G=F-4*(m-mb)*rm*rm-4*(D-db)*rd*rd
normal=s.expand(G.subs({W:0,Z:0,u:0,v:0}))
ck('hard_normal_diagonal',normal-(4*n+4*mb+2)*xi*xi-(4*C+4*A+4*db+2)*eta*eta)
am=(m-mb)*g; ad=(D-db)*e
fw=-mb*(1+h*U)-am+(db+s.Rational(1,2))*(1-h)*U-ad*U
fz=-n*r*du*dv+mb*(1-r)-(db+s.Rational(1,2))*V*(1+r*U)+s.Rational(1,2)*dv*(1-r)
kw=mb*V*(1+h*U)+am*V-C*dv*(1-h)+A*du*dv*h-(db+s.Rational(1,2))*(1-h)+ad+(al+s.Rational(1,2))*du*h*V
kz=-mb*(1-r)*U+(db+s.Rational(1,2))*(1+r*U)-(al+s.Rational(1,2))*du
ck('entire_X_first_normal',s.diff(G,xi).subs({xi:0,eta:0})-8*(v*W*fw+u*Z*fz))
ck('entire_Y_first_normal',s.diff(G,eta).subs({xi:0,eta:0})-8*(u*W*kw+v*Z*kz))
aa,bb,tt,lam=s.symbols('source_u source_v radial_root lam')
ray={u:tt*aa,v:tt*bb,W:B/(aa*bb)*Z,h:H/B,xi:0,eta:0,
     g:(B+aa*aa*(H+r-1))/B,
     e:(bb*bb*(1+aa*aa*r)-(B-H))/B}
ck('m_radial_root',rm.subs(ray)-H*tt*aa*(tt*tt-1)*Z)
ck('D_radial_root',rd.subs(ray)+r*aa*aa*tt*bb*(tt*tt-1)*Z)
fr=s.Poly(s.cancel(F.subs(ray)/(4*Z*Z)),tt)
rad=sum(coef*lam**(power[0]//2) for power,coef in fr.terms())
ar=aa*aa*H*H*(m+A+al+s.Rational(1,2))+aa**4*bb*bb*r*r*(n+D+s.Rational(1,2))
ck('radial_constant',rad.subs(lam,0)-al)
ck('radial_cubic_mass',s.Poly(rad,lam).coeff_monomial(lam**3)-ar)
f1=rad.subs(lam,1); df1=s.diff(rad,lam).subs(lam,1)
ck('radial_factor_mod_exact_contact',rad-(lam-1)**2*(ar*lam+al)-lam*((df1-f1)*(lam-1)+f1))
delta=z+(1+z)*B+(1+z)*B*B+2*z*(1+z)*B*r+z**3*r*r+2*z*z*r+y*((1+z)*B+z+z*z*r*(2-r))
E=(B+z*r)*(1+z*r)*(1+z*r+B-H)-r*delta
ck('positive_source_numerator_identity',E-B*(1-r)*(1+B+2*r*z)+H*(B+z*r)*(1+z*r)+r*y*(B*(1+z)+z+r*z*z*(2-r)))
result={'status':'all_exact_reduction_checks_passed','count':len(out),'checks':out,
 'scope':'Full-parent bounded two-hard/two-soft weak-B reduction. No soft positivity or weak-B leaf admission.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'count':len(out)}))
