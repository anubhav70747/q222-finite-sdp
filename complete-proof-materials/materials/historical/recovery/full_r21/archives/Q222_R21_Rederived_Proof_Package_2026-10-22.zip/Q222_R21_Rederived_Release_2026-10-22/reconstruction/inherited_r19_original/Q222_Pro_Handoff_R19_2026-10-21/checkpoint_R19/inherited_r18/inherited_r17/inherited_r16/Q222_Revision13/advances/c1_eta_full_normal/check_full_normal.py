"""Exact full-normal identities; no numerical scan and no admission."""
import sympy as s, json, time
from pathlib import Path
start=time.monotonic();checks=[]
def ck(name,expr):
    n=s.fraction(s.cancel(expr))[0];ok=s.expand(n)==0
    checks.append({'name':name,'pass':ok})
    print(('PASS ' if ok else 'FAIL ')+name,flush=True)
    if not ok:raise AssertionError((name,s.factor(n)))
u,w,q,x,sg,h,b,W,Z,Nx,Ny,Nz=s.symbols('u w q x sigma h b W Z Nx Ny Nz')
m,C,D,bt,aa,ll=s.symbols('m C D btheta astar lstar')
t=u*u;xi=w*w;Du=1+t;Dw=1+xi;Q=1-b;th=1-h;T=1+t*h+b*xi
mn=-w*Nx+u*q*Ny+u*w*(h-Q)*Nz
rn=-q*Ny-b*w*Nz
jn=u*Nx-w*q*Ny-T*Nz
bn=Nx+u*th*Nz
H=4*Du*(aa*Dw+ll)*Ny*Ny+4*m*mn*mn+4*C*Dw*rn*rn+(4*D+2)*jn*jn
H+=2*Dw*bn*bn+8*bt*u*Dw*Nz*bn-4*bt*u*u*th*Dw*Nz*Nz+2*Du*(q*Ny-Q*w*Nz)**2-2*Du*Dw*Nz*Nz
Hx=2*(1+t+xi)+4*D*t+4*m*xi
Hy=4*Du*(aa*Dw+ll)+4*m*t*q*q+4*C*q*q*Dw+(4*D+2)*xi*q*q+2*Du*q*q
Hz=4*D*T*T+4*bt*th*t*Dw+2*t*Du*h*h+2*b*b*xi*Dw*(1+2*C)+2*t*xi*(h-Q)**2*(1+2*m)
expanded=Hx*Nx*Nx+Hy*Ny*Ny-4*u*q*w*(2*m+2*D+1)*Nx*Ny
expanded+=4*u*(-2*D*T+2*bt*Dw-h*Du-(1+2*m)*xi*(h-Q))*Nx*Nz
expanded+=4*q*w*(2*D*T+b*Dw*(1+2*C)+t*(h-Q)*(1+2*m))*Ny*Nz+Hz*Nz*Nz
ck('EN3 entire exact normal block',H-expanded)
X,Y=s.symbols('X Y');Jw=u*w*W+u*X-w*Y-Z;Bw=X+u*Z
Kw=Jw*Jw+Du*(Y-w*Z)**2+Dw*Bw*Bw-Du*Dw*Z*Z
ck('EN5 defect on complete centered graph',Kw.subs({W:0,X:-u*h*Z,Y:b*w*Z})-Z*Z*(t*Du*h*h+b*b*xi*Dw+t*xi*(h-Q)**2))
# Use a formal square-root variable rb with btheta=rb^2.
rb,Gam=s.symbols('rb Gamma');Zb=rb*u*Gam/sg;Zw=b*w*Gam/sg;Zuw=(h-Q)*u*w*Gam/sg
lift=Hx*Nx*Nx+Hy*Ny*Ny+(4*D/sg**2*T*T+2*t*Du*(h/sg)**2)*Gam*Gam
lift+=4*th*Dw*Zb*Zb+2*Dw*(1+2*C)*Zw*Zw+2*(1+2*m)*Zuw*Zuw
lift+=-4*u*q*w*(2*m+2*D+1)*Nx*Ny+(-8*u*D/sg*T-4*u*h/sg*Du)*Nx*Gam
lift+=8*rb*Dw*Nx*Zb-4*(1+2*m)*w*Nx*Zuw+8*q*w*D/sg*T*Ny*Gam
lift+=4*q*Dw*(1+2*C)*Ny*Zw+4*q*u*(1+2*m)*Ny*Zuw
ck('EN6 complete rescaled normal Gram',H.subs({Nz:Gam/sg,bt:rb*rb})-lift)
# Exact coefficient-boundary diagnostic, specialized only after deriving the formulas.
tt,zz=s.symbols('t xi');T0=1+tt*h+b*zz;Jf=1-T0/sg
Ds=sg**2/(2*(1-sg**2));bts=((1+sg)*h-sg)/(2*(1+sg));ab=1/(2*(1+sg))
cg=4*(1+tt)*(ab*b*(1+zz)+ab*Q)
phi=cg*tt*2*zz/sg+4*Ds*tt*zz*Jf*Jf+4*bts*th*(1+zz)*tt*tt*zz/sg**2
phi+=2*(tt*zz*Jf*Jf+(1+tt)*tt*Q*Q*zz*zz/sg**2+(1+zz)*tt*tt*th*th*zz/sg**2-(1+tt)*(1+zz)*tt*zz/sg**2)
Lz=2*cg-(8*Ds+4)*T0*Jf+8*bts*th*(1+zz)*tt/sg+4*(1+tt)*Q*Q*zz/sg+4*(1+zz)*tt*th*th/sg-4*(1+tt)*(1+zz)/sg
B21=s.Poly(s.expand(phi),tt,zz).coeff_monomial(tt*tt*zz)
Az=s.diff(Lz,tt).subs({tt:0,zz:0})
ck('EN7 scalar mixed coefficient',B21-2*(h+sg)/(sg**2*(1+sg)))
ck('EN7 complete Z first-normal coefficient',Az-4*h/(sg*(1-sg**2)))
pole=2*(h*sg+h+sg*sg-sg)/(sg**2*(1-sg**2))
ck('EN7 combined pole',Az/sg-B21-pole)
Hs=s.symbols('Hs')
ck('EN7 nonzero rescaled pole residue',s.limit(sg*pole.subs(h,sg*Hs),sg,0)-2*(Hs-1))
A=q*(t-x)*W;V=u*w*(t-x)*W;Rh=w*Z/q-u*q*W;Gamma=sg*Z-u*w*W;Vhat=V/sg
ck('EN8 exact rescaled free pivot',Vhat**2-t/sg*A*A-u*(t-x)/sg*A*Rh+(t-x)/sg*Vhat*Gamma)
# New radial boundedness uses h=sigma*Hs, not the old sigma-unit premise.
zs=s.symbols('z');hs=sg*Hs;rs=b*zs;Ks=1+x;Rs=1+x*rs;Ms=Rs-x*zs*(1-hs)
Ps=sg+Ks+sg*zs*(1+b*x+2*x*hs)+sg*b*x*x*hs*zs*zs+x*x*hs*(1-hs)*zs
Anum=zs*(1+x*hs)*(1-x*Hs)+(1-rs)*(1+x*hs*zs)
Lnum=(1+sg*rs)*(x*Hs*Rs*(1+sg*zs)+Ms*(1-x*Hs))
ck('radial source numerator vanishes at z zero',(Anum-Lnum).subs(zs,0))
radial=4*(Anum*b+Lnum*(1-b))/(2*Ps)
ck('radial pivot residue through b openings',radial.subs({x:0,zs:0,sg:0})-2)
out={'scope':'C14.1 d0-unit, h/sigma bounded: complete w-dependent normal Gram only; scalar/first-normal circuit remains open','checks':checks,'passed':len(checks),'seconds':round(time.monotonic()-start,3)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(f'{len(checks)} exact assertions passed in {out["seconds"]} seconds')
