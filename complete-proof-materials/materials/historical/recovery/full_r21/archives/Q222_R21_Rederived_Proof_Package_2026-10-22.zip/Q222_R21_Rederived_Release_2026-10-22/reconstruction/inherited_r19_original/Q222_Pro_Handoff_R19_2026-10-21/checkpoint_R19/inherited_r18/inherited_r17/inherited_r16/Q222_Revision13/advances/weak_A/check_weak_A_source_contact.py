"""Narrow same-system replay of the six contact consequences against the unchanged source.
Clear one known pure-source denominator and work in a sparse polynomial ring.
"""
import sympy as s,json,time
from pathlib import Path
start=time.time()
z,y,H,L,r=s.symbols('z y H L r');B=H+L; ac=1+z*r;Sc=ac+L;Tc=B+z*r
G=B+z*(H+r-1);yj=y*ac-L
Delta=z+(1+z)*B+(1+z)*B**2+2*z*(1+z)*B*r+z**3*r**2+2*z**2*r+y*((1+z)*B+z+z**2*r*(2-r))
M=(1+z)*Tc*(H+y)-z*(1+y)*(1-r)*L
n,m,C,A,D,al=s.symbols('n m C A D alpha');half=s.Rational(1,2)
wm=[m*B**2/z,((C+D+half)*L**2+A*H**2)/y,
    2*m*B*H+C*L**2+(A+al+half)*H**2,A*H**2*z/y,H**2*z*(m+A+al+half)]
zm=[al,D*y,z*(n*r*r+(m+half)*(1-r)**2+al),z*y*((n+half)*r*r+2*D*r),n*r*r*z*z,z*z*y*(n+D+half)*r*r]
N0=2*(m*(1-r)*B+D*L+al*H+B/2)
N1=2*z*(m*H*(1-r)+r*(D+half)*L+(al+half)*H)
exprs={
 'source_graph_value':sum(wm)+sum(zm)-N0-N1,
 'source_graph_u':2*(wm[1]+wm[2])+4*(wm[3]+wm[4])+2*(zm[2]+zm[3])+4*(zm[4]+zm[5])-N0-3*N1,
 'source_graph_v':2*(wm[0]+wm[2]+wm[4]+zm[1]+zm[3]+zm[5])-N0-N1,
 'source_graph_W':2*sum(wm)-N0-N1,
 'source_X_normal':-m*B/z-m*H+(D+half)*L-n*r+(m+half)*(1-r)-n*r*z+(-D-r*(n+half))*y-r*(n+D+half)*z*y,
 'source_Y_normal':(-(C+D+half)*L+A*H+A*H*z+(-C*L+A*H+m*B+(al+half)*H)*y+H*(A+m+al+half)*z*y)/y+D-al+(-m*(1-r)+r*(D+half)-al-half)*z
}
# Den times each unchanged rational source coefficient, explicitly cancelled.
Den=2*r*G*L*H*yj*(1-H)*Delta
scaled={
 n:(Tc*ac*Sc-r*Delta)*G*L*H*yj*(1-H),
 m:z*z*(1+y)*(1-r)*ac*Sc*r*L*H*yj*(1-H),
 C:ac*M*r*G*H*yj*(1-H),
 A:y*ac*Tc*Sc*r*G*L*yj*(1-H),
 D:(1+z)*Tc*(B-z*y*r)*Sc*r*G*L*H*(1-H),
 al:Tc*M*r*G*L*H*yj
}
vs=(z,y,H,L,r)
def pol(a):return s.Poly(a,*vs,domain=s.QQ)
sp={k:pol(v) for k,v in scaled.items()}; dp=pol(Den)
out={}
for name,expr in exprs.items():
 p=s.Poly(s.expand(2*y*z*expr),n,m,C,A,D,al)
 result=pol(0)
 for ex,co in p.terms():
  if sum(ex)==0:term=dp
  else:
   assert sum(ex)==1
   term=sp[(n,m,C,A,D,al)[ex.index(1)]]
  result+=pol(co)*term
 out[name]=result.is_zero
 print(name,out[name],flush=True);assert out[name]
out['radial_lower_bound_identity']=pol(M-y*G-H*(1+z)*Tc-z*(yj+r*L*(1+y))).is_zero
assert out['radial_lower_bound_identity']
Path(__file__).with_suffix('.json').write_text(json.dumps({'same_system_review':True,'checks':out,'seconds':time.time()-start},indent=2)+'\n')
print('PASS',len(out),'seconds',time.time()-start,flush=True)
