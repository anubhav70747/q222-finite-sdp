import json
from pathlib import Path
import sympy as s
p,k,H,E,D,lam,A1,A2,A3,G=s.symbols('p k H E D lam A1 A2 A3 G', nonzero=True)
checks={}
def zero(name,ex):
 q=s.factor(s.cancel(ex));assert q==0,(name,q);checks[name]=True
zero('unbounded_normal_completion',(H+p*p)*E*E+2*(p+k)*E*D+(1+2*k/p)*D*D-(2*k/p*(p*E+D)**2+((p-k)*E+D)**2+(H-k*k)*E*E))
L=A1*A1+A2*A2+A3*A3-3*G*G
rhs=(A1-A3)**2+(1+2*G/A2)*(A2-G)**2
zero('three_circuit_elementary_completion',(L-rhs).subs(A3,G**3/(A1*A2)))
zero('contact_normal_factorization',(p*A2-k*G-(p+k)*(A2-G)).subs(p,k*A2/G))
zero('determinant_positive_identity',(H+p*p)*(1+2*k/p)-(p+k)**2-(H-k*k+2*H*k/p))
R=(p-k)*E+D
zero('coupled_row_bounded_allocation',p*E+D-R-k*E)
w,ss=s.symbols('w ss',positive=True)
zero('circuit_slope_contact_relation',(p*G-k*A2).subs({p:k*w/ss,A2:G*w/ss},simultaneous=True))
P,Q=s.symbols('P Q')
zero('bounded_polynomial_factor_completion',H*E*E+p*p*P*P*E*E+Q*Q*(1+2*k/p)*D*D+2*(p+k)*P*Q*E*D-(2*k/p*(p*P*E+Q*D)**2+((p-k)*P*E+Q*D)**2+(H-k*k*P*P)*E*E))
out={'status':'PASS','count':len(checks),'checks':checks,'scope':'Exact coupled-circuit lemma with unbounded separated p; no full C14.3b admission. Positivity uses k pure-source Inf and inherited bounded-Gram lemma for H-k².'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
