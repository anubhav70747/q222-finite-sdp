"""Exact C1 UI away-contact allocation and source boundary identities."""
from pathlib import Path
import sympy as s,json
u,T,C,A,D,d,h,al=s.symbols('u T C A D d h al',nonzero=True)
Du=1+u*u;sd=4*D+2*d;sc=4*C+sd
P=s.diag(sc,4*A*Du);ell=s.Matrix([1/u,Du/u]);b=s.Matrix([-sd*Du,-2*d*Du]);Pi=s.diag(1/sc,1/(4*A*Du))
da=(ell.T*Pi*ell)[0];ea=(ell.T*Pi*b)[0];ha=sd*Du*Du-2*d*Du-(b.T*Pi*b)[0];c0=4*al*Du
U=u*u
L=A*C*(D+d/2)*U+h*al*(A+C+D+d/2)/U+A*al*(C+D+d/2)/T+h*D*(A+C+d/2)*T/U+h*C*(D+d/2)*U*T+h*(A*D+2*C*D+A*d/2+C*d/2+D*d/2+d*d/4)*T+A*C*D-A*D*d/2+h*al*(C+D+d/2)-d*d*(A+C+D)/4-d**3/8
p=c0+(ha+4*h*da*c0)*T+4*h*(da*ha+ea*ea)*T*T
checks=[]
def check(name,expr):
 assert s.factor(expr)==0,name
 checks.append(name)
 print('PASS '+name,flush=True)
check('full rank-one determinant polynomial',p-16*Du*T*L/(A*sc))
a,J,E=s.symbols('a J E',positive=True)
sub={C:2/a,D:2/(J*E)-d/2}
check('continuous inverse-state da',da.subs(sub)-a*J*E/(8*u*u*(J*E+a))-Du/(4*A*u*u))
check('continuous inverse-state ea',ea.subs(sub)+a*Du/(u*(J*E+a))+d*Du/(2*A*u))
check('continuous inverse-state ha',ha.subs(sub)-8*Du*Du/(J*E+a)+2*d*Du+d*d*Du/A)
check('continuous inverse-state b first', (Pi*b)[0].subs(sub)+a*Du/(J*E+a))
check('continuous inverse-state b second',(Pi*b)[1]+d/(2*A))
check('normalized Laurent U coefficient',(C*(D+d/2)/sc).subs(sub)-1/(2*(J*E+a)))
check('normalized Laurent inverse-T coefficient',al*(C+D+d/2)/sc-al/4)
check('normalized Laurent T coefficient',h*(A*D+2*C*D+A*d/2+C*d/2+D*d/2+d*d/4)/(A*sc)-h*((D+d/2)/sc+2*C*D/(A*sc)+d/(8*A)))
check('normalized Laurent inverse-U coefficient',h*al*(A+C+D+d/2)/(A*sc)-h*al*(1/sc+1/(4*A)))
check('positive boundary ratio',((D+d/2)/sc).subs(sub)-a/(4*(J*E+a)))
x,eta,r=s.symbols('x eta r',positive=True);K=1+x;R=1+x*r;E0=1-x*eta;aa=(1-r)/eta;JJ=K-aa;Pd=1+2*x+r*x*x
dd=4*eta*Pd/(K*(r+eta)*E0);DD=2/(JJ*E0)-dd/2
check('leading D sign factor',DD-(K*(2+x*r)*E0-R*R)*2*eta/((r+eta)*K*E0*(eta*K+r-1)))
check('strict real source interval width',(1-R*R/(K*(2+x*r)))/x-(1-r)/K-R/(x*K*(2+x*r)))
report={'status':'PASS','count':len(checks),'checks':checks,'scope':'Exact determinant/allocation and source-boundary rational identities; positivity and tensor boundedness use the printed analytical arguments.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
