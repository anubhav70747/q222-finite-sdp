# A physical C2 opening floor excludes the proposed flat weak-opening stratum

17 October 2026. This is a necessary condition for the exact C2 parent, proved by a two-state compression. It is not an assertion of global sufficiency.

Use exactly equation (1) of `base/PHYSICAL_PROOF.tex`, with C2 mask `lambda=beta=0`. All remaining coefficients are nonnegative. Write

\[
 q=n+m+A+D,\qquad s=c+\alpha.
\]

## Proposition

Every physical C2 source satisfies

\[
 \boxed{2(c+\alpha)(n+m+A+D)\ge d^2.}\tag{1}
\]

Consequently, under the bounded source normalization

\[
 \rho=d+n+m+c+A+D+\alpha=1,
\]

if `d>=epsilon>0`, then

\[
 c+\alpha\ge\epsilon^2/2,\qquad
 \max(c,\alpha)\ge\epsilon^2/4.\tag{2}
\]

In particular, no physical finite-unit source with `d` a positive unit can have both `c` and `alpha` infinitesimal. This excludes the suggested stratum `n,m,A,D` units with `c,alpha` weak, rather than requiring a weighted division theorem on that stratum. The conclusion uses the fixed parent channel names; it must not be transferred to a differently relabeled C2 convention without translating the channels.

### Proof

Test at the pure real angles `u=v=1` and compress onto the two orthogonal state vectors

\[
 \psi=(1,0,0,1)^T,\qquad \chi=(0,1,-1,0)^T.
\]

Direct substitution into the original parent gives

\[
 \begin{pmatrix}\psi^TP\psi&\psi^TP\chi\\
 \chi^TP\psi&\chi^TP\chi\end{pmatrix}
 =8\begin{pmatrix}s&s+d\\s+d&2(q+d)+s\end{pmatrix}.
\]

Physicality makes this compression PSD. Its determinant is

\[
 64\{s[2(q+d)+s]-(s+d)^2\}
       =64(2sq-d^2),
\]

which proves (1). If `rho=1`, then `q<=1`; (1) gives (2). If `q=0`, (1) forces `d=0`, so no positive-core case was divided by zero.

### Physical meaning

At equal maximally incompatible measurement angles, the maximally entangled direction `psi` annihilates the four strong channels `n,m,A,D`. It has zero CHSH-core expectation, but the core has a nonzero transition matrix element to `chi`. The channels `c,alpha` are therefore forced to fund this transition. They cannot both disappear while the CHSH coefficient stays finite. Only a two-dimensional physical state subspace is needed to see the missing reserve.

## A whole one-parameter family of necessary conditions

The same two state vectors at `u=v=t` give, with `T=t^2` and `D_t=1+T`,

\[
 \begin{pmatrix}\psi^TP\psi&\psi^TP\chi\\
 \chi^TP\psi&\chi^TP\chi\end{pmatrix}
 =4D_t\begin{pmatrix}
 cT+\alpha&t(s+d)\\
 t(s+d)&(q+d)(1+T)+c+\alpha T
 \end{pmatrix}.
\tag{3}
\]

Thus the scalar quadratic

\[
 c(q+d+\alpha)T^2+
 [s(q-d)-2c\alpha-d^2]T+\alpha(q+d+c)\tag{4}
\]

must be nonnegative for every `T>=0`. Since both outer coefficients are nonnegative, this is equivalent to the exact source inequality

\[
 s(q-d)-2c\alpha-d^2
 +2\sqrt{c\alpha(q+d+\alpha)(q+d+c)}\ge0.\tag{5}
\]

The square root belongs purely to the coefficient field. Equality and zero outer coefficients are included. To verify the equivalence, for nonnegative `a,b` the minimum of `aT^2+mT+b` on `T>=0` is nonnegative exactly when `m+2sqrt(ab)>=0`; if either outer coefficient is zero this reduces to `m>=0` (unless both are zero, when the same condition still applies).

Two useful literal-opening consequences are

\[
 c=0\quad\Longrightarrow\quad \alpha(q-d)\ge d^2,
 \qquad
 \alpha=0\quad\Longrightarrow\quad c(q-d)\ge d^2.\tag{6}
\]

These are necessary physical source conditions, not a complete description of the C2 cone. They constrain the surviving opening when the other vanishes.

## Direct determinant check of the doubly absent face

At `c=alpha=0`, symbolic expansion of the entire fixed parent gives

\[
\begin{aligned}
\det P={}&16(1+u^2)^2(1+v^2)^2\\
&\times[4An\,u^2-(4An+2d(A+n)+d^2)v^2]\\
&\times[(4Dm+2d(D+m)+d^2)u^2-4Dm\,v^2].
\end{aligned}
\]

At `u=v=1` this is strictly negative for `d>0`, independently confirming the exclusion. This determinant calculation is supplementary; the two by two compression is the pen-and-paper proof.

The companion `check_c2_opening_floor.py` verifies (3), (4), the specialization (1), and the full doubly absent determinant factorization by exact symbolic arithmetic. No numerical search is used.
