# Audit of the all-testing and weighted extensions

Same-system mathematical review, 17 October 2026. This note reports what was actually audited, not independent external review.

## Finite-unit source C1: root/ALL_TEST_C1.md

All four open-edge square forms agree with the literal parent. The core cancellations at u=0 and v=infinity are essential and have the displayed signs. Four funded events m,c,A,alpha, and the additional unit D+beta, make the open-edge residue matrices strictly positive. At the one-kernel corners the stated source-only hard solves and positive angular stiffnesses supply an exact contact-ideal Gram. If D or beta is weak at the relevant corner, removing precisely that original positive event need not preserve global physicality: the local baseline proof uses its exact zero soft constant, zero first derivatives, and its explicit strict quadratic Gram. The removed event is restored as a separated tensor square. No division by the testing soft-state amplitude occurs in the determinant-one frame. This closes every independent testing angle for the stated finite-unit source stratum.

## Finite-unit source C2: rank_two/ALL_TEST_C2.md

The four open-edge forms and three corner completions are consistent with the original parent and the forced strong set m,c,A,D,alpha. At corner 10, removal of the original weak n event is legitimate and does not require baseline physicality. Its five displayed quadratic forms are independent. In the fixed W/X/Z state charts, a normalized testing state in the residue kernel has a unit soft amplitude, so the only state division is pure testing. States outside that kernel have strictly positive scalar energy residue; the scalar bounded-Gram lemma applies directly. Every higher monomial is retained by exact degree-two division and becomes an infinitesimal Gram perturbation. Thus this proof also closes every independent testing angle for its finite-unit source hypotheses.

For the full parent, both signed-angle reductions are exact without coefficient relabeling:

    P(sigma_u u,sigma_v v)=S^T P(u,v)S,
    S=diag(1,sigma_v,sigma_u,sigma_u sigma_v).

Each original event row maps to its counterpart up to an overall sign. Projective chart factors are pure-testing squares and can be restored even when their inverses are unbounded.

## Weak-source C1 with d,D units: newton/WEAK_SOURCE_DUNIT_LOCAL_ADMISSION.md

The exact scalar identity is correct. The parity state q=(1,x,u*y/uc,u*z/uc) makes f=k0(v)+U k1(v)+U^2 k2(v), with all k_i of degree at most two. Contact equations give f(p,vc)=f_U(p,vc)=f_v(p,vc)=0, p=uc^2. Consequently

    f=C s^2+B u s t+r s j+a0 j^2+(a1+a2 U)t^2,
    s=U-p, t=u(v-vc), j=p(v-vc)=u t-s(v-vc).

The p-divided coefficients are bounded because k0 is coefficientwise O(p^2); this follows from the exact m~p^2 scale and x=O(p), rather than stationarity alone. Both cross-vector identities are bounded polynomial divisions. The hard/source analysis gives a unit XYZ block, x=O(p), y,z=O(uc). The parity ratios y/uc,z/uc are therefore bounded pure-source data.

The full five-component residue Gram splits into (hX,sW) and (hY,hZ,tW). Its two Schur residuals are exactly the residues of detP_UU/(2det A) and detP_vv/(2p det A). The underlying cross derivatives are b_U=(B_X,O(uc),O(uc)) and b_v/uc=(O(uc),R_Y,R_Z), which proves these statements without discarding any hard-state coupling. Stationarity gives D_UU=2vc^2 Q and D_vv=8pN; Q,N are source units in this D-unit branch. Strictness follows. No mixed inverse or hidden soft-state division is used. The weighted local full-parent tensor SOS is therefore proved in its stated testing neighborhood.

## Root's proposed all-testing extension of this weak-source branch

The extension is valid by the following explicit argument. Remove the original m event, which is separately tensor SOS. In the remaining parent W occurs only as uW. Therefore it is an exact bounded four-component Gram on eta=(uW,X,Y,Z) whenever u is infinitesimal and the second angle has a bounded projective chart. At nonmatching finite v residue,

    det H_res(v)=16(1+v^2)^2 q12_res (v^2-vc_res^2)^2 >0.

The residue identities used here are q10_res=vc_res^4 q12_res and h_res=-2vc_res^2 q12_res. They follow directly from the actual stationary source equations and m~p^2. To justify PSD of H_res without assuming global physicality after removal, evaluate the full source parent at u=uc with W=eta_W/uc. The removed event's contribution has coefficients O(m/p)=O(p), so vanishes in residue; full-source physicality gives H_res PSD. Strict determinant then gives PD. At v=0 or projective infinity, the corresponding H residue has strict determinant q10 or q12 and is equally admitted. At the matching v residue use the weighted five-root theorem above.

For u of nonzero finite residue the limiting determinant is strictly positive even at v=vc, because its extra U(q21+q22 V) term is positive. The original four edge identities cover the finite/infinite mixed edges. The remaining u=infinity corners use the previous C1 fixed-corner Grams; their coefficients remain units when m is weak and c,A,D,alpha,d are units. At infinity-infinity a weak beta event is removed and restored exactly as in the regular-source proof. These dispatches exhaust all independent testing angles for the weak-source d,D-unit branch. They do not cover weak D, two weak source angles, or weak normalized d.
