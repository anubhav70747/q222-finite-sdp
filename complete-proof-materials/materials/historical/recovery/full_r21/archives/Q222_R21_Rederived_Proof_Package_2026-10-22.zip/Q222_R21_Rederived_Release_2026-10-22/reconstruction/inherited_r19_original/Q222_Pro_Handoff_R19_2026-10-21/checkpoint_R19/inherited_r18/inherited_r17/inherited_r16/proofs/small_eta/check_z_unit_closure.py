"""Focused exact receipts for the C14.3b bounded-state-ratio local certificate."""
import json
from pathlib import Path
import sympy as s
u,v,W,X,Y,Z,xi,eta,r,h,x,C,A,Dp,bp,gamma=s.symbols('u v W X Y Z xi eta r h x C A Dp bp gamma',nonzero=True)
E=eta*u*W-v*Z; Qt=Y-r*v*Z/eta;P=E/eta-Qt
RD=v*(u*u-x)*Z;T=RD-u*v*xi/h
checks={}
def ck(n,f):
 assert s.cancel(f)==0,(n,s.factor(f))
 checks[n]=True
ck('entire_gamma_state_conductor',gamma*u*v*Qt*xi-(gamma*u*u*(W/Z)*E*xi-gamma*u*(xi/Z)*E*E/eta-gamma*u*v*P*xi))
Hs=C+A+Dp
Ns=P-A/Hs*E/eta-(h*Dp+bp)/Hs*T
sE=A*(C+Dp)/Hs;sT=h*h*Dp-(h*Dp+bp)**2/Hs;sET=bp-A*(h*Dp+bp)/Hs
ck('strict_pre_conductor_source_completion',C*P*P+A*Qt*Qt+Dp*(P-h*T)**2+2*bp*Qt*T-(Hs*Ns*Ns+sE*E*E/eta**2+sT*T*T+2*sET*E*T/eta))
ck('source_P_bounded_allocation',P-(Ns+A/Hs*E/eta+(h*Dp+bp)/Hs*T))
Fb,Ft,T0,Tm,m=s.symbols('Fb Ft T0 Tm m');rho=m+r*Tm*x/2
e4=r*r*Tm/eta**2
rad=C/eta**2*(Fb-r*Ft)**2+r*r*T0/eta**2*Ft**2+(2*m*r/eta**2+e4*x)*Fb*Ft
ck('strict_joint_fullY_radial_completion',rad-(C/eta**2*(Fb-r*(1-rho/C)*Ft)**2+r*r/eta**2*(T0+2*rho-rho*rho/C)*Ft**2))
a,q,B,mu=s.symbols('a q B mu',nonzero=True)
ck('complete_angular_schur',B-mu-mu**2/(a*a*q)-(B-(mu+a*a*q)*mu/(a*a*q)))
zeta,B0=s.symbols('zeta B0')
margin=B0*zeta*(1+zeta)/2+(1+zeta)**2/4-s.Rational(1,4)
ck('angular_margin_at_beta_zero',margin.subs(B0,s.Rational(1,2))-zeta*(3+2*zeta)/4)
# The final circuit squares are polynomial in the testing angles, including axes.
k,c,ll=s.symbols('k c lambda',nonzero=True);xx=k*k
Et=eta*u*W-v*Z;p=c*k*v/u;d=(c*k*v*v/u-k*v)*Z;J=(u*v-xx/c)*Z
L=((u*v)**2+(c*k*v*v/u)**2+(xx/c)**2-3*(k*v)**2)*Z**2
raw=ll*L+ll*p*p*Et**2+2*ll*(p+k)*d*Et
R2=ll*eta**2*k*k*(c*v-u)**2*W**2
T2=2*ll/c*k*k*u*v*(eta*c*W-Z)**2
ck('division_free_full_circuit_squares',raw-(ll*J**2+R2+T2-ll*xx*Et**2))
# At Z=0 the negative scalar packet vanishes identically.
al,mm=s.symbols('alpha m')
M=v*W-X+u*v*Y-u*Z;De=u*W-Y+u*v*X-v*Z
positive=mm*M*M+C*(1+v*v)*(u*W-Y)**2+A*(1+u*u)*(1+v*v)*Y*Y+Dp*De*De+(al+s.Rational(1,2))*(1+u*u)*(v*Y-Z)**2+B*(1+v*v)*(X+u*Z)**2
parent=positive-(1+u*u)*(1+v*v)*Z*Z/2
ck('full_Z_zero_endpoint_is_original_positive_packets',(parent-positive).subs(Z,0))
out={'status':'PASS','count':len(checks),'checks':checks,'scope':'Exact identities for the local C14.3b Z-unit/bounded-state-ratio admission, retaining all source openings and beta=0. Y/Z is unrestricted; the unproved state portion has nonzero Z with W/Z or X/Z unbounded.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
