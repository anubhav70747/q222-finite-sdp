#!/usr/bin/env python3
"""One focused exact pass: physical source scale and endpoint obstruction."""
import json
from pathlib import Path
import sympy as s
checks={}
def ck(name,expr):
    assert s.cancel(expr)==0,name
    checks[name]=True
B,h,a,t,r,e,lam=s.symbols('B h a t r e lam')
ca=1+a*B*r; S=1+B*(1-h+a*r)
g=1+a*(h*B+r-1); j=ca-(1-h)/t
dd=a+(1+a*B)+(1+a*B)*B+2*a*B*(1+a*B)*r+a**3*B**2*r*r+2*a*a*B*r+t*B*(1+a+a*B+a*a*B*r*(2-r))
P=(1+a*r)*ca*S-r*dd
K=(1+a)*(h+t)*(1+a*B)
Q=1+B*(1+t+a*h+2*a*r+a*t)+B*B*(a*(h+t)+a*a*(h*(r+1)+t*(1+r-r*r)))
ck('exact_original_n_numerator',P-((1-r)*Q-B*K))
ck('exact_r_one_negative_n',P.subs(r,1)/(2*dd.subs(r,1))+B*(h+t)*(1+a*B)/(2*(1+B*(1+2*a+t)+a*B*B*(1+a+t))))
corner={B:0,h:0,r:1}
ck('Q_unit_residue',Q.subs(corner)-1)
ck('K_unit_residue',K.subs(corner)-(1+a)*t)
ck('Delta_unit_residue',dd.subs(corner)-(1+a))
# The physical inequality makes lam=B/e bounded. Cancel before reducing.
subst={B:e*lam,r:1-e}
ne=s.cancel(P.subs(subst)/(2*(1-e)*dd.subs(subst)*e))
me=s.cancel(a*a*(1+t*B)*ca*S/(2*g*dd))
ck('n_over_gap_residue',ne.subs({e:0,h:0})-(1-lam*(1+a)*t)/(2*(1+a)))
ck('m_over_gap_residue',me.subs(corner)-a*a/(2*(1+a)))
D=(1+a*B)*(1+a*r)*(1-a*t*B*r)*S/(2*t*j*dd)
n=P/(2*r*dd); half=s.Rational(1,2)
beta=a*a*(n*r*r+B*t*(n+D+half)*r*r)
betagap=s.cancel(beta.subs(subst)/e)
ck('beta_over_gap_residue',betagap.subs({e:0,h:0})-a*a*(1/(2*(1+a))+lam*t/(2*(t-1))))
out={'status':'PASS','count':len(checks),'checks':checks,
 'scope':'Exact source scale bound B/(1-r) bounded and literal r=1 n<0 obstruction. No new local or all-tests tensor-SOS admission.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
