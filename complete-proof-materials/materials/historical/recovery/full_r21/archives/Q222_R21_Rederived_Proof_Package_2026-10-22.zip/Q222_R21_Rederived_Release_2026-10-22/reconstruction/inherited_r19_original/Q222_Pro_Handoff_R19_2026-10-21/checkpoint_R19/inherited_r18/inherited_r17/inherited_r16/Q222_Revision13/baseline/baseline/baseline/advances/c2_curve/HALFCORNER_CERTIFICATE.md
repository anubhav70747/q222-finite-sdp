# Exact witness: a bounded full-normal half-corner certificate

Status: **proved local testing-region advance**. A subsequent, separate
all-tests admission for this exact source family is proved in
`rational_curve_tensor_sos.tex`; the local Gram below remains useful for
a prospective multiparameter extension.
The physical source is the exact double-infinitesimal family documented in
`../oct18b_strong/double_inf/DOUBLE_INF_GRAM_FRONTIER.md`. Its source parameter
is `x=k²>0` infinitesimal, its actual angles are `(k,k)`, and

```
n=(8-5x²)/(16(1+x)²),
m=3x²(3x+4)/(16(1+x)(4+x-2x²)),
C=alpha=(4-x)/(8x),
A=x(x+4)(3x+4)/(32(2-x)(1+x)²),
D=(2-x)(3x+4)/(16x(1+x)).
```

For every independent pair of infinitesimal testing angles with `v≠0` and
`u/v` bounded, the unchanged full parent is tensor SOS for every state.
There is no comparison between `k` and either testing angle. The claim
includes `u/v` infinitesimal and `u=0`. The literal pair `(u,v)=(0,0)` is
also immediate directly from the parent. No claim is made here for
`u/v` unbounded, the remaining outer charts, or a uniform actual-II source
family.

## Entire packet graph and its one exact relation

Use the unchanged parent notation

```
Du=1+u², Dv=1+v²,
r=uW-Y, p=vY-Z, J=uW+uvX-Y-vZ,
B=X+uZ, Rm=vW-X+up,
F=2[J²+Du p²+Dv B²-DuDv Z²]
  +4nDuDv X²+4m Rm²+4C Dv r²+4A DuDv Y²
  +4D J²+4alpha Du p².
```

Put `a=1+x/4`, and define four centered, original-amplitude roots

```
eX = X+x vW/4,
eM = [(r+J)/2+x²uW/8]/k,
ep = [p+xuvW/2]/k,
eP = [J-r+(x+x²/4)uW]/k.
```

All four vanish at each exact source contact with the corresponding angle
signs. Their exact inverse packet expansions are

```
X=eX-xvW/4,
r=xuW/2+k eM-k eP/2,
J=-(x/2+x²/4)uW+k eM+k eP/2,
p=-xuvW/2+k ep,
Y=uW-r,
Z=uvW-kv eM+kv eP/2-k ep.
```

Let `Ftilde` denote the full parent after these substitutions, retaining
`J` as the displayed independent packet. The exact relation restoring
its original amplitude is

```
G = -uv eX-kv² eM-kv ep+k(1+v²/2)eP
    +a u(v²-x)W = 0.
```

Thus adding `G` times any linear form changes none of the original parent.
No retained packet has been capped or discarded.

## Exact scalar allocation

Write `U=u²,V=v²` and let `phi0(U,V)=Ftilde(0,0,0,0,1)`. Define

```
bbase(U)=phi0(U,x)/[x(U-x)²],
cV=[phi0(0,V)/(x²V)-bbase(0)]/(V-x),
b(U,V)=bbase(U)+(V-x)cV,
ell(U,V)=[b(U,V)V(U-x)²-phi0(U,V)]/[a U(V-x)].
```

These are exact divided differences: the apparent angle denominators
cancel. In particular

```
b=(x+4)(3x+4)[(2x²-x-4)V-x²-16x-16]
  /[64(1+x)²(2x²-x-4)],

ell=[3UVx+4UV-6Ux²+4Ux+16U
     +5Vx³+38Vx²+64Vx+32V
     +5x⁴+15x³+24x²+40x+32]/[16(1+x)²].
```

Both have pure source unit denominators, and `b` has residue `1`.
Set `LW=u ell(u²,v²)` and `Q=v(u²-x)W`. The scalar part of
`Ftilde+G LW W` is exactly `b Q²`.

## Entire first-normal allocation

Let the four hard variables be `z=(eX,eM,ep,eP)` and put

```
g=(-uv,-kv²,-kv,k(1+v²/2)),
t_i = (partial Ftilde/partial z_i)|_(z=0,W=1)+LW g_i.
```

Each entire row has the corresponding parity

```
t_X=v f_X(U,V), t_M=u f_M(U,V),
t_p=uv f_p(U,V), t_P=u f_P(U,V).
```

For `X`, use

```
BX(V)=f_X(x,V)/(V-x),
AX(U,V)=[f_X(U,V)-f_X(x,V)]/(U-x),
L_X=-uv BX(V)/(a x),
h_X=AX(U,V)-(V-x)BX(V)/x.
```

Here `BX/x=x(5x+12)/[16(1+x)]` is bounded.
For `i=M,P`, use

```
Ai(U)=f_i(U,x)/(U-x),
Bi(U,V)=[f_i(U,V)-f_i(U,x)]/(V-x),
Li=-Bi/a,
hi=(u/v)Ai(U).
```

The exact source grades are

```
AM=-k³(3x+4)(2x²+9x+12)/[16(1+x)²],
AP= k(3x+4)(2x³+9x²+10x+8)/[32(1+x)²].
```

For `p`, use the same divided differences `Ap,Bp`, and

```
Lp=-v Bp/a, hp=u Ap.
```

In every case the exact entire first-normal identity is

```
t_i+Li a u(v²-x) = v(u²-x) hi.
```

The sole new denominator is the pure testing factor `v`; it occurs only
in the bounded pure testing ratio `u/v`. In particular the `P` row uses
`(u/v)AP`, whose coefficient has source grade `k`, rather than the former
`(uv/x)AP` with its inadmissible source pole.

## Full Gram and strict residue

Define the symmetric four-by-four matrix

```
Hij = (partial² Ftilde/partial zi partial zj)/2
      +(gi Lj+gj Li)/2,
```

and append last column `h/2` and last diagonal entry `b` to obtain `M`.
Then the exact full identity is

```
Ftilde+G[LW W+sum_i Li zi] = (eX,eM,ep,eP,Q) M (eX,eM,ep,eP,Q)^T.
```

All fifteen entries are bounded separated tensors when `u/v` is bounded.
This can be checked transparently by substituting the **pure testing**
blowup `u=qv`: every reduced denominator is a pure source unit, and all
entries are regular at `k=v=q=0`; retaining arbitrary bounded `q` gives
exactly the same residue matrix

```
[4 0 0 0 1]
[0 4 0 0 0]
[0 0 2 0 0]
[0 0 0 1 0]
[1 0 0 0 1].
```

Its hard block is `diag(4,4,2,1)`, its final Schur pivot is `3/4`, and
its determinant is `24`. The inherited strict-residue bounded-Gram lemma
therefore gives tensor SOS. The argument is homogeneous in the complete
state; it does not restrict to `W=1`, and applies to real and imaginary
parts of a complex state separately.

`derive_halfcorner_witness.py` checks the exact full parent identity,
all fifteen boundedness gates, and this residue Schur computation.
`derive_halfcorner_witness.json` records PASS. The longer coefficient
expressions are reproduced by `halfcorner_witness_gram_data.txt`.

## Exact remaining scope

For `u/v` unbounded, the new row `hP=(u/v)AP` need not be bounded.
Returning to the old even conductor gives `hP=(uv/x)AP`, whose leading
term is `uv/k`. Neither comparison is legal between independent fields.
The half-corner certificate therefore leaves that directed ratio endpoint,
then the outer/literal testing charts, and then source-family uniformity.
It is a full-normal certificate on the stated testing region. The
separate rational-curve argument now admits this exact source family at
all tests without resolving this Gram construction’s opposite ratio
endpoint.
