Q222: CONTACT, CIRCUIT, COMPENSATION
17 October 2026 -- structural supplement

START HERE
Q222_Contact_Circuit_Compensation.pdf is the readable proof and graph.
Its LaTeX source and every included module are editable and self-contained
for compilation with pdflatex (two runs).

WHAT IS NEW
1. A universal unlocalized contact-conductor lemma replaces all three C1
   UZ8 ideal-membership computations. The source scalar lies in the precise
   monomial module needed by the second-order lemma. First normals use the
   same first-order conductors. No Groebner basis, stored expansion or
   machine-generated certificate is a premise of the analytical argument.
2. Two circuit pairings give six soft roots. Together with two hard state
   normals these give an eight-root bounded strict-residue Gram for the
   normalized remainder. Four positive packets are restored separately.
3. Physicality gives the exact matching inequality
   mu*T/d^2 >= 1/[16(2+d/(4mu))(1+d/(4mu))], with sharp asymptotic constant
   1/32. Comparable weak C2 packets therefore need no separate product checks.
4. A distance-three/four graph on the eight event cycle yields six canonical
   source templates beyond the five-consecutive-strong exit.

PRECISE LIMIT
The specified uniform C1 source family is now closed analytically, including
its unbounded-e endpoint. The new C2 corollary has the assumptions printed in
the note. The six source templates have NOT all been proved. A wholly
atlas-free proof of the global finite-lift claim remains incomplete.
The old retained-atlas global argument is unchanged and is not freshly
replayed by this supplement. Eight roots is a remainder Gram dimension,
not a global SDP matrix-size bound or an optimal SOS length.

REPRODUCE
  python3 verify.py
Uses the standard library only. Runs native contact balances, complete source reconstruction and
constructive contact division, circuit identities, and exact cycle checks.
Do not use python -O.

  python3 verify.py --with-sympy
Also runs geometry/check_matching_budget.py, requiring SymPy. The latter
uses exact symbolic polynomials/rational functions, never numerical fitting.
It imports physicality of the sharp source from the inherited C2 contact
argument; checking an asymptotic path alone does not prove physicality.

The core C1 replay takes approximately 13 seconds on this workspace; runtime
is machine dependent. It reconstructs all coefficients, multiplies every
lift back and checks weights. Its expanded intermediates are not saved.
No external data files, network connection, Groebner package or old large
certificate are used. The finite event-mask loop is optional verification
of a three-line combinatorial proof, not an enumerative proof premise.

FILES
c1/: universal conductor proof, source formulas, exact constructive checker.
circuit/: six-soft-root identity and exact arithmetic checker.
geometry/: matching inequality, sharp path, C2 corollary and exact checker.
cover/: graph, six-family reduction, exact check and review.
inherited/: selected earlier source and all-tests lemmas, preserved as dated
 snapshots. Their older UZ8 gap language is superseded by this supplement.
verification/: fresh run report, layout checks and manifest.
PROOF_STATUS.json: new results, inherited inputs, remaining scope.
PROOF_GRAPH.json: dependency graph with explicit node status.

RELATION TO THE COMPLETE PREVIOUS PACKAGE
Q222_Human_Computer_Assisted_Proof_Package.zip
SHA256: b03308de894eabba15510392a16855b4ee3117140d012a8de1314868bbe0591e
That archive retains the full global atlas, source dependencies, earlier
human manuscripts and original large local witnesses. This small supplement
adds and supersedes the local C1 algebra; it does not duplicate the archive.
The new proof is not a fresh external peer review: review notes are internal
cross-checks by collaborating agents of the same system.
