import json
from pathlib import Path
import sympy as s
P,V,x,Q,R=s.symbols('P V x Q R')
T=P*V;c=(1-R)/R
f=c*x*x+(P*P+V*V)*(x-T*Q)**2+(R+1)**2*Q*Q+2*(R+3)*T*x*Q-(R+3)*T*T*Q*Q
ss=(P-V)**2*(x-T*Q)**2+2*T*(x+(R+1-T)*Q)**2+c*(x+R*T*Q)**2+(R+1)**2*(T-1)**2*Q*Q
checks={'leading_two_state_identity':s.factor(f-ss)==0}
p,v,q,y,H,B,j,K,X,Y,LD,Lm=s.symbols('p v q y H B j K X Y LD Lm')
aJ=p*Y*(1-y*j/H)-v*X;aM=p*X-v*Y*(1-q*K/H);den=1-p*p*v*v
W=(aJ-p*v*aM+LD-p*v*Lm)/den
Z=(p*v*aJ-aM+p*v*LD-Lm)/den
checks['D_inverse']=s.factor(W+v*X-p*Y-p*v*Z+y*j*p*Y/H-LD)==0
checks['m_inverse']=s.factor(p*v*W-p*X+v*Y-Z-q*K*v*Y/H-Lm)==0
rho,n=s.symbols('rho n')
checks['n_coefficient_reduction']=s.factor((1-rho)/rho-2*n*(rho+3)+ (2*n*rho*(rho+3)+rho-1)/rho)==0
qc,vc=s.symbols('qc vc',positive=True)
cc={p:qc,v:vc,q:qc**2,y:vc**2,X:-R*qc,Y:H/vc}
Ws=B*qc/vc;Zs=s.Integer(1)
for nm,ex in [('C',Ws-B/H*p*Y),('D',Ws+v*X-p*Y-p*v*Zs+y*j*p*Y/H),('m',p*v*Ws-p*X+v*Y-Zs-q*K*v*Y/H),('alpha',Zs-v*Y/H)]:
 e=s.factor(ex.subs(cc).subs({B:H+vc**2*s.Symbol('t'),j:1+R-s.Symbol('t'),K:H+vc**2*s.Symbol('t')+R-s.Symbol('E'),H:1-qc**2*s.Symbol('E')},simultaneous=True))
 # substitute source H after all equations, to avoid order-dependent expansion.
 e=s.factor(e.subs(H,1-qc**2*s.Symbol('E')))
 checks['contact_'+nm]=e==0
mu,a,S,T,N,Z,W,X,Y,v=s.symbols('mu a S T N Z W X Y v')
da=1+a*a
remote=4*mu*(da*S-X-a*Z)**2+(4*mu+2)*da*(a*S-Z)**2+2*(X+a*Z)**2-2*da*Z*Z
remote_TR=4*mu*(da*S-T)**2+4*mu*da*N*N+2*T*T-2*da*a*a*S*S+4*da*a*S*N
checks['remote_coordinate_form']=s.factor(remote.subs({Z:a*S-N,X:T-a*(a*S-N)},simultaneous=True)-remote_TR)==0
mat=s.hessian(remote_TR,(S,T,N))/2
schur=mat[0,0]-mat[0,1]**2/mat[1,1]-mat[0,2]**2/mat[2,2]
checks['remote_schur_pivot']=s.factor(schur-da*(4*mu*mu-a*a*(4*mu+1))/(mu*(2*mu+1)))==0
checks['remote_mu_choice']=s.expand((4*mu*mu-a*a*(4*mu+1)).subs(mu,1+a*a)-(3*a*a+4))==0
u,b,w=s.symbols('u b w')
Du=1+u*u;Dv=1+b*b
J=u*W+u*b*X-Y-b*Z
core=2*J*J+2*Du*(b*Y-Z)**2+2*Dv*(X+u*Z)**2-2*Du*Dv*Z*Z
checks['finite_unit_core_kernel']=s.factor(core.subs({X:b*W,Y:u*W,Z:u*b*W},simultaneous=True)-2*Du*Dv*b*b*W*W)==0
Jw=u*w*W+u*X-w*Y-Z
corew=2*Jw*Jw+2*Du*(Y-w*Z)**2+2*(1+w*w)*(X+u*Z)**2-2*Du*(1+w*w)*Z*Z
checks['infinite_v_core_kernel']=s.factor(corew.subs({w:0,W:0,Y:0,Z:u*X},simultaneous=True)-2*Du*X*X)==0
# Exact remote charts with unbounded Alice testing angle.
p,v,W,X,Y,Z,S,T,P,mu=s.symbols('p v W X Y Z S T P mu')
Dp=1+p*p;Dv=1+v*v
M=p*v*W-p*X+v*Y-Z;J=W+v*X-p*Y-p*v*Z
core=2*J*J+2*Dp*(v*Y-Z)**2+2*Dv*(p*X+Z)**2-2*Dp*Dv*Z*Z
cap=4*mu*(M*M+Dv*(W-p*Y)**2+J*J+Dp*(v*Y-Z)**2)+core
# Substitution introduces only symbolic p denominators; cancellation checked before p=0.
rr=s.cancel(cap.subs({Y:S/p,Z:v*S/p-T},simultaneous=True)).subs(p,0)
A0,B0=s.symbols('A0 B0')
rr=s.expand(rr.subs({W:A0+S,X:B0+v*S},simultaneous=True))
target=(8*mu+2)*T*T+4*mu*Dv*A0*A0+(4*mu+2)*(A0+v*B0)**2+4*Dv*v*S*B0+2*Dv*v*v*S*S
checks['unbounded_u_unit_v_residue']=s.factor(rr-target)==0
w=s.symbols('w')
Dw=1+w*w
M2=p*W-p*w*X+Y-w*Z;J2=w*W+X-p*w*Y-p*Z
core2=2*J2*J2+2*Dp*(Y-w*Z)**2+2*Dw*(p*X+Z)**2-2*Dp*Dw*Z*Z
cap2=4*mu*(M2*M2+Dw*(W-p*Y)**2+J2*J2+Dp*(Y-w*Z)**2)+core2
rr=s.cancel(cap2.subs({Y:P+w*S/p,Z:S/p},simultaneous=True)).subs({p:0,w:0})
checks['both_unbounded_residue']=s.factor(rr-(4*mu*W*W+(8*mu+2)*P*P+4*mu*(X-S)**2+2*X*X))==0
# Source identities against the original unscaled rational C2 coefficients.
q,y,R,E,t=s.symbols('q y R E t')
H=1-q*E;B=H+y*t;K=B+R-E;j=1+R-t
z=1/q;aa=q*y;b=q*B;r=q*R
Delta=1+(1+z)*b+z*(1+z)*b*b+2*z*(1+z)*b*r+z*z*r*r+2*z*r+aa*z*((1+z)*b+1+z*r*(2-r))
Ac=1+z*r;Sc=Ac+aa*z*t
N=(1+z)*(b+r)*(b+aa*(1-t))-aa*(1+aa*z)*(1-r)*t
ns=((b+r)*Ac*Sc-r*Delta)/(2*r*Delta)
ms=(1+aa*z)*(1-r)*Ac*Sc/(2*((1+z)*b-(1-r+aa*z*t))*Delta)
Cs=Ac*N/(2*aa*t*Delta)
As=aa*Ac*(b+r)*Sc/(2*(b-aa*t)*Delta)
Ds=(1+z)*(b+r)*(b-aa*z*r)*Sc/(2*aa*j*Delta)
as_=z*z*(b+r)*N/(2*(1-z*(b-aa*t))*Delta)
Deltahi=(1+q)*(B*B+2*B*R+(1+y)*B)+(1-y*q)*R*R+2*(1+y)*R+1+y
Nb=(1+q)*(B+R)*(H+y)-(1+y)*(1-q*R)*y*t
checks['source_Delta']=s.factor(Delta-Deltahi)==0
checks['source_N']=s.factor(N/q-Nb)==0
for nm,left,right in [
 ('m',ms*q*K,(1+y)*(1-q*R)*(1+R)*Sc/(2*Delta)),
 ('C',Cs*y*t,(1+R)*Nb/(2*Delta)),
 ('A',As/(q*y),(1+R)*(B+R)*Sc/(2*H*Delta)),
 ('D',Ds*y*j,(1+q)*(B+R)*(B-y*R)*Sc/(2*Delta)),
 ('alpha',as_*q*E,(B+R)*Nb/(2*Delta)),
 ('n',ns,((B+R)*(1+R)*Sc-R*Delta)/(2*R*Delta))]:
 checks['source_'+nm+'_product']=s.factor(left-right)==0
n,m,C,A,D,al,p,v,W,X,Y,Z=s.symbols('n m C A D al p v W X Y Z')
Dp=1+p*p;Dv=1+v*v
J=W+v*X-p*Y-p*v*Z;M=p*v*W-p*X+v*Y-Z
F=4*n*Dp*Dv*X*X+4*m*M*M+4*C*Dv*(W-p*Y)**2+4*A*Dp*Dv*Y*Y+(4*D+2)*J*J+(4*al+2)*Dp*(v*Y-Z)**2+2*Dv*(p*X+Z)**2-2*Dp*Dv*Z*Z
checks['literal_p_zero']=s.factor(F.subs(p,0)-(4*n*Dv*X*X+(4*m+4*al+2)*(v*Y-Z)**2+4*C*Dv*W*W+4*A*Dv*Y*Y+(4*D+2)*(W+v*X)**2))==0
checks['literal_v_zero']=s.factor(F.subs(v,0)-(4*n*Dp*X*X+(4*m+2)*(p*X+Z)**2+(4*C+4*D+2)*(W-p*Y)**2+4*A*Dp*Y*Y+4*al*Dp*Z*Z))==0
out={'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'scope':'Exact leading soft identity; state-normal inverses; full-parent all tests outside critical (1/u,v) strictly nonzero infinitesimal corner; original-source HI entry. The strong HI leaf is not closed.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
