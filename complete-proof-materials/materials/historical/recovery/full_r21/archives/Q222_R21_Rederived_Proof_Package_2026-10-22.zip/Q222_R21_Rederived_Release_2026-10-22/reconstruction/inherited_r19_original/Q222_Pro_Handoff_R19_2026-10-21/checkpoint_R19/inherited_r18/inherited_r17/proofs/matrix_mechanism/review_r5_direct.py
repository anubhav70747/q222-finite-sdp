"""Independent direct-Hessian check of the R5 remote determinant formula."""
import json
from pathlib import Path
import sympy as s

u,v,W,Y,Z=s.symbols('u v W Y Z')
A,C,D,m=s.symbols('A C D m')
U,V=u*u,v*v
half=s.Rational(1,2)
M=v*W+u*v*Y-u*Z
J=u*W-Y-v*Z
F=m*M*M+C*(1+V)*(u*W-Y)**2+A*(1+U)*(1+V)*Y*Y+D*J*J
F+=half*(J*J+(1+U)*(v*Y-Z)**2+(1+V)*U*Z*Z-(1+U)*(1+V)*Z*Z)
P=s.hessian(F,(W,Y,Z))/2
direct=s.expand(P[0,0]*(P[1,1]*P[2,2]-P[1,2]**2)
                -P[0,1]*(P[0,1]*P[2,2]-P[1,2]*P[0,2])
                +P[0,2]*(P[0,1]*P[1,2]-P[1,1]*P[0,2]))
c=C*(1+V)+D+half
b=(1+U)*(A*(1+V)+V/2)
d=D*V+U/2
pv=D+half
yv=(1+U)/2
base=U*(c*b*d-b*pv*pv*V-c*yv*yv*V)
adj=V*(b*d-yv*yv*V)+(1+U)**2*V*(c*d-pv*pv*V)+U*U*c*b
adj+=2*(1+U)*pv*yv*V*V-2*U*b*pv*V-2*U*(1+U)*c*yv*V
assert s.expand(direct-base-m*adj)==0

# Compare all polynomial coefficients to R5.8 after the source substitution.
a,h,t=s.symbols('a h t')
ell=1-h
delta=t-ell
sub={m:a*a/(2*(1-a*a)),C:(h+t-a*ell)/(2*ell*(1+a)),
     A:t/(2*h*(1+a)),D:1/(2*(1+a)*delta)}
den=8*h*(1-a)*(1+a)**3*ell*delta
numerator=(1+U)*(1+V)*((h+t)*(t*U-a*V)**2
           +(h+t-a*ell)*(t*delta*U*U*V+(h+(1-a)*t)*U*V*V))
lhs=s.Poly(direct,u,v)
rhs=s.Poly(s.expand(numerator),u,v)
monomials=set(lhs.monoms()) | set(rhs.monoms())
for ex in monomials:
    assert s.cancel(den*lhs.coeff_monomial(ex).subs(sub)-rhs.coeff_monomial(ex))==0,ex
out={'status':'PASS','checks':[
    'R5 generic remote determinant reconstructed directly from full three-state Hessian',
    'Every R5.8 polynomial coefficient checked after exact source substitution'],
    'monomial_count':len(monomials)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
