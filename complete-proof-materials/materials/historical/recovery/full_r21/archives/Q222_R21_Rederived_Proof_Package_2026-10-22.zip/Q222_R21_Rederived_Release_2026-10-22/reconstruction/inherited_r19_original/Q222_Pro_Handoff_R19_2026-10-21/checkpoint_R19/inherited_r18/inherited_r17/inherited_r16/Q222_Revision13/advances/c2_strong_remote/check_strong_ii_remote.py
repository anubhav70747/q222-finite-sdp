#!/usr/bin/env python3
"""Exact polynomial checks for the full-parent remote strong-II admission."""
import json
from pathlib import Path
import sympy as s

checks = {}
def check(name, expr):
    value = s.factor(s.cancel(s.together(expr)))
    if value != 0:
        raise AssertionError((name, value))
    checks[name] = True

u,v,W,X,Y,Z=s.symbols('u v W X Y Z', real=True)
n,m,C,A,D,al,y=s.symbols('n m C A D alpha y', positive=True)
a,b,c,d=s.symbols('a b c d', real=True)
beta,k=s.symbols('beta k', real=True)
du=1+u*u; dv=1+v*v
M=v*W-X+u*v*Y-u*Z
J=u*W+u*v*X-Y-v*Z
F=4*n*du*dv*X*X+4*m*M*M+4*C*dv*(u*W-Y)**2+4*A*du*dv*Y*Y+4*D*J*J+4*al*du*(v*Y-Z)**2+2*(J*J+du*(v*Y-Z)**2+dv*(X+u*Z)**2-du*dv*Z*Z)

# Use unnormalized homogeneous variables for the endpoint-safe identity.
aa,bb,cc,dd=s.symbols('aa bb cc dd', real=True)
hom=0
for (i,j),coef in s.Poly(F,u,v).terms():
    hom+=coef*aa**i*bb**(2-i)*cc**j*dd**(2-j)/4
E=aa*W-bb*Y; K=aa*X-bb*Z; L=bb*X+aa*Z
Jh=dd*E+cc*K; Qh=cc*Y-dd*Z
target=n*(aa*aa+bb*bb)*(cc*cc+dd*dd)*X*X+m*(bb*cc*W-bb*dd*X+aa*cc*Y-aa*dd*Z)**2+C*(cc*cc+dd*dd)*E*E+A*(aa*aa+bb*bb)*(cc*cc+dd*dd)*Y*Y+(D+s.Rational(1,2))*Jh*Jh+(al+s.Rational(1,2))*(aa*aa+bb*bb)*Qh*Qh+s.Rational(1,2)*(cc*cc+dd*dd)*((bb*X+aa*Z)**2-(aa*aa+bb*bb)*Z*Z)
check('original_homogeneous_parent_including_endpoints',hom-target)

P=bb*L
check('orthogonal_core_rotation',L*L-(aa*aa+bb*bb)*Z*Z-(P*P+2*aa*K*P-bb*bb*K*K)/(aa*aa+bb*bb))
# The preceding homogeneous identity specializes to a^2+b^2=1.

E=a*W-b*Y; K=a*X-b*Z; L=b*X+a*Z
N2=(C+D)*(E+D/(C+D)*v*K)**2
gamma=y*C*D/(C+D)
Vq=v*K*Y
check('source_harmonic_pair',C*dv*E*E+D*(E+v*K)**2-N2-gamma*v*v*K*K/y-C*v*v*E*E)
x,z0,ell=s.symbols('x z0 ell', real=True)
check('all_state_toric_zero',(a*(b*X)*(v*Y)-b*b*Z*(v*Y))-b*Vq)

# The normalization relation is used only through this exact remainder.
Mbase=(beta+s.Rational(1,2))*(ell-z0)**2+s.Rational(1,2)*(x*x+2*a*x*z0-b*b*z0*z0)
Mk=Mbase+k*(a*x*ell-b*b*z0*ell)
Mmat=s.hessian(Mk,(x,z0,ell))/2
check('three_state_gram_determinant',Mmat.det().subs(a*a,1-b*b)-(2*beta*b*b*k*k-(2*beta+1)*(k+1)**2)/8)
check('first_schur_pivot',(Mmat[1,1]-Mmat[1,0]**2/Mmat[0,0]-beta).subs(a*a,1-b*b))
identity=s.Rational(1,2)*(x+a*(z0-ell))**2+beta*(z0-ell)**2+s.Rational(1,2)*(b*ell)**2
check('infinite_u_three_square_identity',s.expand(Mk.subs(k,-1)-identity).subs(a*a,1-b*b))

vv,qq,gg,ar=s.symbols('V q gamma a_ratio',real=True)
G=gg*vv*vv+ar*dv*qq*qq+(beta+s.Rational(1,2))*(ell-z0)**2+dv*s.Rational(1,2)*(x*x+2*a*x*z0-b*b*z0*z0)
rhs=dv*Mk+gg*vv*vv+ar*dv*qq*qq-k*dv*b*vv*qq-v*v*(beta+s.Rational(1,2))*(ell-z0)**2
check('complete_bounded_gram_allocation_mod_exact_toric_zero',rhs-G-k*dv*(a*x*ell-b*b*z0*ell-b*vv*qq))

# Full reconstruction in the normalized Alice chart, including all states.
Fhat=n*dv*X*X+m*(b*(v*W-X)+a*(v*Y-Z))**2+C*dv*E*E+A*dv*Y*Y+(D+s.Rational(1,2))*(E+v*K)**2+(al+s.Rational(1,2))*(v*Y-Z)**2+dv*s.Rational(1,2)*(L*L-Z*Z)
positive=n*dv*X*X+m*(b*(v*W-X)+a*(v*Y-Z))**2+N2+C*v*v*E*E+s.Rational(1,2)*(E+v*K)**2+(al-beta)*(v*Y-Z)**2
Graw=gamma*v*v*K*K/y+A*dv*Y*Y+(beta+s.Rational(1,2))*(v*Y-Z)**2+dv*s.Rational(1,2)*((b*X)**2+2*a*(b*X)*Z-b*b*Z*Z)
check('full_parent_with_every_state_normal',s.expand(Fhat-positive-Graw).subs(a*a,1-b*b))

# Leading source units are evaluated only after opening factors have
# been cleared: none of these checks sets a singular source weight.
zs,ys,H,t,r=s.symbols('z_s y_s H t r', positive=True)
Bs=H+ys*t; ac=1+zs*r; js=ac-t
delta=zs+(1+zs)*Bs+(1+zs)*Bs*Bs+2*zs*(1+zs)*Bs*r+zs**3*r*r+2*zs*zs*r+ys*((1+zs)*Bs+zs+zs*zs*r*(2-r))
Ms=(1+zs)*(Bs+zs*r)*(H+ys)-zs*(1+ys)*(1-r)*ys*t
Ss=ac+ys*t
ct=ac*Ms/(2*delta)
dj=(1+zs)*(Bs+zs*r)*(Bs-zs*ys*r)*Ss/(2*delta)
ay=ac*(Bs+zs*r)*Ss/(2*H*delta)
alphacomplement=(Bs+zs*r)*Ms/(2*delta)
gammaexpr=ct*dj/(ct*js+dj*t)
at_zero={zs:0,ys:0}
check('source_Cyt_unit',ct.subs(at_zero)-H/(2*(1+H)))
check('source_Dyj_unit',dj.subs(at_zero)-H/(2*(1+H)))
check('source_A_over_y_unit',ay.subs(at_zero)-1/(2*H*(1+H)))
check('source_harmonic_unit_all_t_j_openings',gammaexpr.subs(at_zero)-H/(2*(1+H)))
check('source_alpha_complement_unit',alphacomplement.subs(at_zero)-H*H/(2*(1+H)))

check('literal_u_infinity_v_zero',hom.subs({aa:1,bb:0,cc:0,dd:1})-(n*X*X+A*Y*Y+(C+D+s.Rational(1,2))*W*W+(m+al+s.Rational(1,2))*Z*Z))
check('literal_both_infinity',hom.subs({aa:1,bb:0,cc:1,dd:0})-(C*W*W+(n+D+s.Rational(1,2))*X*X+(A+m+al+s.Rational(1,2))*Y*Y))
check('literal_u_zero_v_infinity',hom.subs({aa:0,bb:1,cc:1,dd:0})-(m*W*W+(n+s.Rational(1,2))*X*X+(C+A+al+s.Rational(1,2))*Y*Y+D*Z*Z))

result={'status':'all_exact_identity_checks_passed','count':len(checks),'checks':checks,'scope':'Full-parent remote strong-II tensor-SOS; positivity and source asymptotics are proved in the accompanying text. The local both-infinitesimal testing region and the weak B face are not asserted.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'count':len(checks)}))
