# Finite-unit C1 sources: every independent testing regime

This extends the finite-unit moving-frame theorem to every testing angle, including infinitesimal and infinite angles. The source hypotheses remain: bounded nonnegative canonical coefficients, lambda=n=0, positive residue of d, and a genuine stationary contact with uc,vc having finite positive residues. The original full parent P is retained.

## 1. Four funded events

At the finite-unit actual contact, the determinant masses have stationary balance and positive-definite covariance. In C1 the only negative-v exponent is q10, so q10 is a unit: alpha and A are units. A positive x exponent is required and every such term contains c, so c is a unit. A negative x exponent is required and every such term contains m, so m is a unit. A positive v exponent is required and every such term contains D or beta, so at least one of D,beta is a unit.

Thus m,c,A,alpha are positive units, and D+beta is a positive unit. This implication follows from balance and nondegeneracy, not a general assumption on all physical coefficients.

## 2. Interior and open edges

Finite nonzero testing residues are covered by the moving-frame theorem. To cover the four open edges, write P_infty,v=r^2 P(1/r,v), and similarly in the second angle; the removed pure-testing square is restored at the end. At an open edge the remaining angle has finite positive residue. Put Du=1+u^2, Dv=1+v^2.

The following are exact restrictions of the polynomial parent:

u=0:

    4m(vW-X)^2 +(4beta+2d)Dv X^2
    +[4(c+A)+2d]Dv Y^2 +4D(Y+vZ)^2 +4alpha(vY-Z)^2.

u=infinity (homogeneous chart):

    4c Dv W^2 +4A Dv Y^2 +(4D+2d)(W+vX)^2
    +(4m+4alpha+2d)(vY-Z)^2 +4beta Dv Z^2.

v=0:

    (4m+4beta+2d)(X+uZ)^2 +4alpha Du Z^2
    +[4(c+D)+2d](uW-Y)^2 +4A Du Y^2.

v=infinity (homogeneous chart):

    4m(W+uY)^2 +4c(uW-Y)^2 +[4(A+alpha)+2d]Du Y^2
    +2d Du X^2 +4D(uX-Z)^2 +4beta(X+uZ)^2.

The funded events above show directly that each edge matrix has positive-definite residue. In the last display the X,Z block is strict because D+beta is a unit and u is a unit. Hence every test infinitesimally near an open edge has a strict four-feature Gram.

## 3. Four projective corners

Use local coordinates (r,s) and the corresponding polynomial chart. The table gives its diagonal constant matrix in the state order (W,X,Y,Z).

| Corner | Coordinates | Constant diagonal |
|---|---|---|
| (0,0) | (u,v) | (0, 4m+4beta+2d, 4c+4A+4D+2d, 4alpha) |
| (infinity,0) | (1/u,v) | (4c+4D+2d, 0, 4A, 4m+4alpha+4beta+2d) |
| (0,infinity) | (u,1/v) | (4m, 4beta+2d, 4c+4A+4alpha+2d, 4D) |
| (infinity,infinity) | (1/u,1/v) | (4c, 4D+2d, 4m+4A+4alpha+2d, 4beta) |

At (0,infinity), if D has positive residue, the corner is strictly positive. If D has zero residue, remove only the positive original D-event packet, leaving a baseline with D=0. Since beta is then a unit, this baseline has exactly one kernel coordinate and three strict hard coordinates. Likewise (infinity,infinity) is strict when beta is a unit. When beta has zero residue, remove only its positive event packet, leaving a baseline with beta=0; D is then a unit. Each removed packet is already a separated tensor square and is restored afterwards. The two corners requiring a removed event cannot occur simultaneously in a single source residue pattern.

At each remaining one-kernel corner, apply the same finite source-only first-order state transport as in the moving-frame theorem, now about the fixed corner. Its constant hard block is diagonal and has positive-definite residue. The soft diagonal and its first derivatives vanish exactly. The exact full polynomial therefore has a five-feature Gram in (w1,w2,w3,r z,s z), with a block-diagonal residue. The two-by-two reduced angle stiffness is diagonal. Its entries are as follows:

| Corner/baseline | Kernel coordinate | C_rr | C_ss |
|---|---|---|---|
| (0,0) | W | 4A[d+2(c+D)]/[d+2(c+A+D)] | 4m(d+2beta)/[d+2(m+beta)] |
| (infinity,0) | X | 4alpha[d+2(m+beta)]/[d+2(m+alpha+beta)] | 4c(d+2D)/[d+2(c+D)] |
| (0,infinity), D=0 | Z | 4beta d/(d+2beta) | 4alpha[d+2(c+A)]/[d+2(c+A+alpha)] |
| (infinity,infinity), beta=0 | Z | 4D d/(d+2D) | 4A[d+2(m+alpha)]/[d+2(m+A+alpha)] |

Every displayed entry is a positive unit. These formulas can be obtained either by the diagonal hard Schur complement at the fixed corner, entirely in the source field, or by comparing the quadratic determinant coefficients. No test-dependent inverse is used. The finite polynomial contact-ideal division, rather than a truncated Taylor estimate, supplies all higher terms as bounded infinitesimal Gram corrections.

## 4. Scope and completion of the testing quantifier

Each nonnegative testing angle in a real closed field is finite with zero residue, finite with positive residue, or infinite with reciprocal of zero residue. The interior, four open edges, and four corners exhaust the pair of angles. Independent testing signs are reduced by the exact state-sign symmetries. Literal zero and projective infinity are included by evaluating the local chart at zero.

Consequently, for every C1 source satisfying the finite-unit actual-contact and d hypotheses, the full original parent evaluated at every independent testing angle pair and every testing state is a finite tensor sum of squares. Only pure-source inverses and pure-testing projective squares were used. The remaining source issue is genuinely different: this theorem does not cover actual source contacts tending to a commuting angle, or a normalized d with zero residue.

The accompanying symbolic checker verifies the four exact open-edge identities, all four constant corner matrices, and all four corner stiffness formulas with generic symbolic coefficients.
