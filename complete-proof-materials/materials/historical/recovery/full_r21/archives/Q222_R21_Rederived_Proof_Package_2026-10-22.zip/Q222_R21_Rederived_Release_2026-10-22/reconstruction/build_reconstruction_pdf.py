#!/usr/bin/env python3
"""Assemble a clearly scoped supplement without altering recovered sources."""
from pathlib import Path
import hashlib
import json
import re

HERE=Path(__file__).resolve().parent
OUT=HERE/'pdf_supplement'
COMP=OUT/'components'
COMP.mkdir(parents=True,exist_ok=True)
BASE=HERE/'salvaged_checkpoint/Q222_Recovery_Continuation_R21_2026-10-21/checkpoint_R21'
specs=[
 ('physical_assembly',HERE/'restored_context/routing/fresh_physical_normalization_conditional_assembly.tex','Fresh proof; final global implication conditional on LC.'),
 ('strict_bounded_gram',BASE/'inherited_r19/inherited_r18/inherited_r17/inherited_r16/Q222_Revision13/baseline/baseline/baseline/baseline/baseline/baseline/baseline/current/bridge/strict_gram.tex','Intact inherited elementary lemma, copied from the hash-verified checkpoint.'),
 ('actual_source_scalar',HERE/'restored_context/c144/rederived/r1_qo_actual_source_and_scalar.tex','Fresh source and scalar proof, independently reviewed on its stated local scope.'),
 ('small_normal_budgets',HERE/'restored_context/c144/rederived/r1_qo_small_normal_budgets.tex','Fresh helper lemmas; no independent whole-source admission.'),
 ('full_normal_conductor',HERE/'restored_context/weak_c2/fn_reconstructed.tex','Fresh full local conductor; outer testing charts remain outside this theorem.'),
 ('r2_source_entry',HERE/'restored_context/weak_c2/r2_source_entry_reconstructed.tex','Fresh structural source-entry and two-packet extraction; no R2 local or all-tests certificate.'),
 ('state_sign_join',HERE/'restored_context/root_rederived/full_state_sign_join_REDERIVED.tex','Fresh exact full-state, sign and literal projective-endpoint reduction.'),
]

records=[]
for name,path,status in specs:
    text=path.read_text()
    original=text
    # Historical fragments sometimes place a manual tag after the display.
    # Moving only the tag into that same display preserves its mathematics.
    text=re.sub(r'(\\end\{align\*?\})\s*\\tag\{([^}]+)\}',r'\\tag{\2}\n\1',text)
    text=re.sub(r'(\\\])\s*\\tag\{([^}]+)\}',r'\\tag{\2}\n\1',text)
    # These sources use explicit qualified equation tags; suppress unintended
    # automatic numbers on the remaining lines of the same align display.
    text=text.replace(r'\begin{align}',r'\begin{align*}').replace(r'\end{align}',r'\end{align*}')
    # Allow long source names to wrap in the typeset exposition.
    def path_wrap(match):
        return r'\nolinkurl{'+match.group(1).replace(r'\_','_')+'}'
    text=re.sub(r'\\texttt\{([^{}]+)\}',path_wrap,text)
    text=text.replace('unbounded-$q$',r'unbounded-\texorpdfstring{$q$}{q}')
    if name=='actual_source_scalar':
        old=r''' j=\frac{a_sc_s}{R_s},\quad B=\frac{B_sR_s}{c_s},\quad
 T=\frac{t_sc_s}{R_s},\quad p=\frac{a_s(1-r)}{R_s},\quad
 H=\frac{1-h}{t_sc_s},
 \qquad x=jB,\quad y=TB,\quad q_z=jT .'''
        new=r''' \begin{gathered}
 j=\frac{a_sc_s}{R_s},\quad B=\frac{B_sR_s}{c_s},\quad
 T=\frac{t_sc_s}{R_s},\\
 p=\frac{a_s(1-r)}{R_s},\quad H=\frac{1-h}{t_sc_s},\qquad
 x=jB,\quad y=TB,\quad q_z=jT .
 \end{gathered}'''
        assert old in text, 'Expected compact-source display changed'
        text=text.replace(old,new)
    dest=COMP/(name+'.tex')
    dest.write_text(text)
    records.append({'component':name,'source':str(path.relative_to(HERE)),
                    'source_sha256':hashlib.sha256(original.encode()).hexdigest(),
                    'exposition_file':'components/'+dest.name,
                    'exposition_sha256':hashlib.sha256(text.encode()).hexdigest(),
                    'scope':status,
                    'editorial_changes':['Manual display tags moved inside their own display where necessary.','Automatic numbers on otherwise untagged align rows suppressed; all qualified manual equation tags retained.','Monospaced file paths given line-wrap support.','Section bookmarks given plain-text q alternatives.','The compact-source coordinate definitions are split across two display lines.']})

master=r'''\documentclass[11pt]{article}
\usepackage[T1]{fontenc}
\usepackage[utf8]{inputenc}
\usepackage{lmodern}
\usepackage[a4paper,margin=23mm,headheight=14pt]{geometry}
\usepackage{amsmath,amssymb,amsthm,mathtools,mathrsfs}
\usepackage{booktabs,longtable,array,xcolor,microtype}
\usepackage{xurl}
\usepackage[hidelinks,pdfencoding=auto]{hyperref}
\usepackage{fancyhdr}
\pagestyle{fancy}
\fancyhf{}
\fancyhead[L]{\small Q222: R21 reconstruction supplement}
\fancyhead[R]{\small Scoped recovery}
\fancyfoot[C]{\thepage}
\renewcommand{\headrulewidth}{0.3pt}
\newtheorem{theorem}{Theorem}[section]
\newtheorem{lemma}[theorem]{Lemma}
\newtheorem{proposition}[theorem]{Proposition}
\newtheorem{corollary}[theorem]{Corollary}
\newtheorem{claim}[theorem]{Claim}
\theoremstyle{definition}
\newtheorem{definition}[theorem]{Definition}
\theoremstyle{remark}
\newtheorem{remark}[theorem]{Remark}
\newcommand{\R}{\mathbb R}
\newcommand{\res}{\operatorname{res}}
\newcommand{\Sym}{\operatorname{Sym}}
\allowdisplaybreaks[3]
\setlength{\emergencystretch}{3em}
\setlength{\parskip}{3pt}
\raggedbottom
\hypersetup{pdftitle={Q222: R21 Reconstructed Arguments},pdfsubject={Recovery supplement; global completion not restored}}
\begin{document}
\hypersetup{pageanchor=false}
\begin{titlepage}
\vspace*{17mm}
{\LARGE\bfseries Q222: Reconstructed Arguments\par}
\vspace{5mm}
{\Large R21 Recovery Supplement\par}
\vspace{13mm}
{\large Recovery status: partial reconstruction of the later release\par}
\vspace{7mm}
The earlier saved continuation checkpoint has been reconstructed at file-content
level: all 1,202 files in its original manifest match their recorded hashes.
That checkpoint's own verifier explicitly leaves the global theorem open.

The later 549-page completed release was reported previously, but its full
source tree and archive have not been recovered. This supplement contains
freshly derived arguments and one intact elementary inherited lemma. It does
not replace the missing complete release or reinstate its reported checklist
statuses.
\par\vspace{5mm}\noindent
\begin{tabular}{@{}p{0.37\textwidth}p{0.57\textwidth}@{}}
\toprule
Argument & Present mathematical scope\\
\midrule
Physical model and normalization & Exact real-qubit convexification and complete homogeneous parent; final global assembly conditional on LC.\\[3pt]
R1 source and scalar & Actual stationary weights, physicality restriction, scalar certificate and effective current reserve.\\[3pt]
R1 full local parent & Both complete normal rows, their coupling, and literal $n=0$, for the specified local source/testing sector.\\[3pt]
State and projective reduction & Sign gauges, arbitrary positive state ratio, and literal projective endpoints.\\[3pt]
Whole-source/global completion & Missing later C1 branches, R1 outer charts, other weak-C2 completions and the full routing bodies remain unresolved in this recovery.\\
\bottomrule
\end{tabular}
\vfill
\textbf{Review scope.} Fresh analytical review within the same model system and
targeted exact symbolic corroboration. This is not external peer review or a
proof-assistant formalization. Historical acceptance records are preserved as
history and are not used to certify missing derivations.
\end{titlepage}
\hypersetup{pageanchor=true}
\tableofcontents
\clearpage
\section*{How to use this supplement}
\addcontentsline{toc}{section}{How to use this supplement}
Start with the physical model and normalization identity. The assembly theorem
there states its local-certificate hypothesis LC explicitly. The remaining
sections establish recovered or newly reconstructed inputs on their exact
domains. The full normal conductor uses the actual source/scalar estimates,
the elementary bounded-Gram lemma and the displayed finite square budgets.
The final state/sign reduction preserves the arbitrary state ratio required by
the conductor.

The complete earlier checkpoint, original retained fragments, newly written
sources, executable checkers, and current recovery checklist are supplied in
the accompanying ZIP. The two late assembly fragments and the historical
review text are not printed here as an unconditional theorem. Missing proof
bodies are listed in the recovery inventory.

Source names in the text identify files inside the accompanying material.
The exposition copies used for this PDF preserve the mathematics of each
input; formatting changes are recorded in the component manifest.
\clearpage
'''
for name,_,_ in specs:
    master+=r'\input{components/'+name+r'.tex}'+'\n\\clearpage\n'
master+=r'''\section*{Exact-check scope}
\addcontentsline{toc}{section}{Exact-check scope}
The accompanying fresh checkers cover six focused groups: the native source
dictionary and scalar identities; the small normal helpers; the complete
full-parent identities and finite radial budgets; the state/sign/projective
join; the physical probability/CHSH normalization; and the structural R2
source-entry and packet extraction. Their assertion counts
overlap and are not added into a completeness measure. Symbolic identity
checks corroborate the displayed calculations; the analytical bounds and
quantified domain arguments remain in the proofs above.

The reconstruction verifier checks the delivered bytes and can replay the
focused checkers in an isolated temporary copy. A successful run does not
certify the absent later proof components or convert the conditional assembly
into an unconditional finite-lift theorem.
\end{document}
'''
(OUT/'Q222_R21_Reconstructed_Arguments.tex').write_text(master)
(OUT/'COMPONENT_PROVENANCE.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps({'master':str(OUT/'Q222_R21_Reconstructed_Arguments.tex'),'components':len(records)}))
