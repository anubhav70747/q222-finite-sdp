#!/usr/bin/env python3
"""Focused symbolic determinant curvature audit, no full-parent duplicate."""
from pathlib import Path
import json
import sympy as s
U,V,u,v,a,b,H=s.symbols('U V u v a b H',nonzero=True)
q01,q02,q10,q12,q21,q22,h=s.symbols('q01 q02 q10 q12 q21 q22 h')
poly=q01*V+q02*V*V+q10*U+h*U*V+q12*U*V*V+q21*U*U*V+q22*U*U*V*V
p=a*a;w=b*b;Q=q21+q22*w
sub={q01:p*p*Q-q02*w,q10:w*w*(q02/p+q12+q22*p)}
hc=-s.expand((poly-h*U*V).subs({U:p,V:w}))/(p*w)
sub[h]=hc.subs(sub)
def contact(expr):
    return s.factor(expr.subs({U:p,V:w}).subs(sub))
assert contact(poly)==0 and contact(s.diff(poly,U))==0 and contact(s.diff(poly,V))==0
N=q02*w/p+q12*w+q22*p*w
assert contact(s.diff(poly,U,2))-2*w*Q==0
polyv=poly.subs(V,v*v)
assert s.factor(s.diff(polyv,v,2).subs({U:p,v:b}).subs(sub)-8*p*N)==0
det=16*(1+U)**2*(1+V)**2*poly
assert s.factor(contact(s.diff(det,U,2))/(2*H)-16*(1+p)**2*(1+w)**2*w*Q/H)==0
detv=det.subs(V,v*v)
vv=s.diff(detv,v,2).subs({U:p,v:b}).subs(sub)
assert s.factor(vv/(2*p*H)-64*(1+p)**2*(1+w)**2*N/H)==0
receipt={'status':'PASS','arithmetic':'exact symbolic stationary determinant differentiation',
 'checks':['stationary determinant substitutions','D_UU=2wQ','D_vv=8pN',
           'first Schur constant 16','weighted second Schur constant 64'],
 'scope':'weak-source C1 D-unit local curvature; no all-testing claim'}
Path(__file__).with_name('WEAK_C1_DUNIT_CURVATURE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
