"""Leading UI angular Schur computation, used only as a local derivation."""
import sympy as s
from pathlib import Path
import json
a,b,r,u,V,X,Z=s.symbols('a b r u V X Z',nonzero=True)
z=a*a;Du=1+u*u;Ac=1+z*r
Delta=1+(1+z)*b+z*(1+z)*b*b+2*z*(1+z)*b*r+z*z*r*r+2*z*r
g=(1+z)*b-1+r;gap=1-z*b
N0=(1+z)*(b+r)*b
n=((b+r)*Ac*Ac-r*Delta)/(2*r*Delta)
m=(1-r)*Ac*Ac/(2*g*Delta)
alpha=z*z*(b+r)*N0/(2*gap*Delta)
H0=z*(1+z)*(b+r)*b/(2*Delta)
Aweak=Ac*Ac*(b+r)/(2*z*b*Delta)
F=4*n*Du*X*X+4*m*(V*Du-X-u*Z)**2
F+=4*H0*V*V*(u*X-Z)**2+4*Aweak*Du*u*u
F+=(4*alpha+2)*Du*(V*u-Z)**2+2*(X+u*Z)**2-2*Du*Z*Z
c={u:a,V:1,X:-r/b,Z:1/(a*b)}
vs=[X,Z,V,u]
checks=[]
def eq(name,expr):
    assert s.factor(expr)==0,name
    checks.append(name)
eq('full leading model contact value',F.subs(c))
for var in vs:
    eq('full leading model contact derivative '+str(var),s.diff(F,var).subs(c))
H=s.Matrix(4,4,lambda i,j:s.factor(s.diff(F,vs[i],vs[j]).subs(c)/2))
P=H[:2,:2];B=H[:2,2:];T=H[2:,2:]
Pinv=P.adjugate()/s.factor(P.det())
G=(T-B.T*Pinv*B).applyfunc(s.factor)
eq('positive ordinary-angle Schur pivot',G[1,1]-8*(1-r)*Ac**2/(z*b*Delta))
det_expected=16*(b+r)**2*Ac**3*(3*z+4-(z+2)**2*r)/(b*b*Delta**2)
eq('exact angular Schur determinant',G.det()-det_expected)
q_n=1+r*(z-1)-z*(z+2)*r*r-z*(z+1)*b*r
eq('n inequality numerator',((b+r)*Ac**2-r*Delta)-b*q_n)
eq('n and g give the r upper bound',q_n-(1-(z+1)*r)*(1+z*r)+z*r*g)
eq('strict determinant margin at maximal r',
   (3*z+4-(z+2)**2/(z+1))-z*(2*z+3)/(z+1))
out='Hard determinant:\n'+str(s.factor(P.det()))+'\nAngular Schur:\n'+str(G)+'\nDeterminant:\n'+str(s.factor(G.det()))+'\n'
Path(__file__).with_suffix('.txt').write_text(out)
Path(__file__).with_suffix('.json').write_text(json.dumps({'status':'PASS','check_count':len(checks),'checks':checks,
 'scope':'Exact leading contact and state-eliminated angular Hessian identities. Large-weight cap and complete local lifting are proved in the manuscript, not inferred from this finite replay.'},indent=2)+'\n')
print(out)
