# Separate-agent review: global C2 positive-chart entry

**Verdict: PASS; no blocking gap found in the stated entry theorem.**
This review compares `analysis_atlas/oct18b_cover/c2_global_entry.md`
with the exact inherited files it cites. It is a separate-agent review
within the same system, not external or proof-assistant verification.

## Maximal signed coefficient and analytic contact graph

- On the strictly positive six-event orthant, the `d=0` event form is
  positive definite at every positive finite angle pair. Its six positive
  noncentral Laurent coefficients have a spanning support whose convex
  hull contains zero in its interior. Thus the positive Laurent function
  attains a strictly positive minimum. This is stronger than pointwise
  positivity and justifies the uniform supported-perturbation argument
  that gives some admissible `d>0`.
- Physicality is an intersection of closed affine inequalities in `d`,
  so the admissible set is a closed interval containing zero. A fixed
  negative-core state bounds it above. For example at `u=v=1`, the state
  `(W,X,Y,Z)=(1,-1/4,1/4,1)` has raw core `H=-3`; its event contribution
  is finite for every fixed real event tuple. Consequently the claimed
  finite positive maximum is attained.
- A positive Laurent minimum at the maximum would persist under an
  increase of `d`, contradicting maximality. Strict logarithmic convexity
  gives a unique squared-angle minimizer; the inherited strictly positive
  restriction to `Z=0` gives a simple kernel with `Z!=0`.
- Every finite zero has strictly negative core because the retained
  event form is positive definite, including when `n=0`. Hence every
  zero for a fixed event tuple is at the maximal `d`.
- The implicit-function Jacobian is invertible by the exact inherited
  automatic-curvature theorem and the strictly negative `d` derivative.
  The nearby branch has positive `d` and positive retained coefficients.
  Its full kernel and angular stationarity imply a stationary zero of
  the Laurent determinant. Convexity makes this a global minimum, while
  the strictly positive restriction to `Z=0` gives the inertia criterion.
  Therefore the branch is physical and maximal. Uniqueness makes the
  local analytic branches agree on the entire connected real orthant.

## Deleted-amplitude walls

Deleting a positive event at its zero amplitude preserves the entire
kernel and both angular first derivatives. The deleted parent still has
three positive state directions from the unchanged positive `d` core.
Its stationary determinant zero therefore gives physicality by the
same convexity/inertia argument, without assuming coercivity.

The subsequent contradiction is justified: automatic angular curvature
forces the active exponent vectors to span the plane, and stationary
gradient zero is a convex combination with every active weight strictly
positive. Hence zero is in the interior of their convex hull. This
contradicts the inherited equivalence between noncoercivity and an
exclusive omitted pair. Every exclusive pair in the printed wall table
agrees with `physical_core.tex`.

For the `X=0` wall, deleting `n` gives exactly the inherited
`lambda=n=beta=0` C1 triple-omission face with the other five events
positive. Sections 6–7 of `C1_GLOBAL_SIGN_ENTRY.md` apply and give
`X=u(eta-1)<0`, contradicting that wall. The positive seed then fixes
the constant signs on the connected graph.

The remaining signs follow directly from the full `X` equation and the
homogeneous C2 reflection. The reflection preserves nonnegativity,
positive angles, and the positive retained-event conditions. Its final
coordinate is the already proved positive `W`, so the normalization used
to infer `W+vX>0` is legitimate.

## Transfer and exact source recovery

The proof uses compactness, logarithms, and analyticity only over the
reals. The final assertion is a finite first-order implication:
nonnegative coefficients, positive `d` and actual angles, polynomial
kernel/stationarity equations, quantified polynomial physicality, and a
finite list of strict polynomial inequalities. It therefore transfers
to every real closed coefficient field. No analytic branch or maximum
is asserted directly in a non-Archimedean field.

The literal `n=0` case is separately supplied by the cited exact C1
triple-omission theorem, so it does not rely on an unproved limiting
optimizer. The positive expression for `Delta` is the expansion of the
original source definition. The inherited six-column determinant is
strictly nonzero after the proved signs; including the `n` column remains
valid even if the solved coefficient is zero. Thus the rational formulas
recover the original coefficients, rather than merely a source with the
same asymptotic contact.

## Unbounded-b consequence

The canceled formulas in `analysis_atlas/oct18b_cover/unbounded_b_reduction.md`
agree with the original rational source formulas. In particular, for
`B=xb` a positive bounded unit,

```
C L, A H, D j/B, alpha(1-H)/B, m b^2
```

are positive bounded units, while `H,L,j,1-H` have bounded upper bounds.
Thus `C,alpha` both have positive real lower bounds. With `d=1`, actual
`u=sqrt(x)` infinitesimal and `v=k` a bounded unit, every hypothesis of
`thm:strong-complement-pitchfork` is met, regardless of which of
`C,A,D,alpha` diverge. The **entire B-unit row is now an all-tests
admission** under that theorem. The B-infinitesimal row has weak `alpha`
and is outside its hypotheses; the reflected row has weak `C`.

This review certifies positive-chart source entry and the stated B-unit
reduction only. Entry alone does not establish a universal C2 tensor-SOS
cover or resolve other actual-angle residue types.
