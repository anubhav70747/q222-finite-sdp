#!/usr/bin/env python3
"""Integrity plus small exact replays. No global atlas replay."""
from pathlib import Path
import argparse, hashlib, json, shutil, subprocess, sys, tempfile
ROOT=Path(__file__).resolve().parent

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as f:
        for part in iter(lambda:f.read(1024*1024),b''):h.update(part)
    return h.hexdigest()

def main():
    if not __debug__:
        raise SystemExit('Run without -O: assertions are proof checks.')
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--with-sympy',action='store_true')
    ap.add_argument('--integrity-only',action='store_true')
    args=ap.parse_args()
    manifest=json.loads((ROOT/'MANIFEST.json').read_text())
    failures=[]
    for item in manifest['files']:
        p=ROOT/item['path']
        if not p.is_file():failures.append({'path':item['path'],'reason':'missing'})
        elif p.stat().st_size!=item['bytes'] or digest(p)!=item['sha256']:
            failures.append({'path':item['path'],'reason':'size or SHA-256 mismatch'})
    report={'integrity':{'files_checked':len(manifest['files']),'failures':failures},
            'exact_replays':[],'atlas_replayed':False}
    if failures:
        print(json.dumps(report,indent=2));return 1
    scripts=[] if args.integrity_only else [
        'c1/check_dispatch.py','c1/check_analytical_lift.py',
        'c2/check_c2_unbounded_n_pitchfork.py']
    if args.with_sympy and not args.integrity_only:
        scripts.append('c2/check_general_single_angle.py')
    with tempfile.TemporaryDirectory(prefix='q222-checklist-') as td:
        dst=Path(td)/'advances'
        shutil.copytree(ROOT/'advances',dst)
        for name in scripts:
            p=dst/name
            r=subprocess.run([sys.executable,str(p)],cwd=p.parent,
                text=True,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            item={'script':'advances/'+name,'exit_code':r.returncode,
                  'status':'PASS' if r.returncode==0 else 'FAIL'}
            if r.returncode:item.update(stdout=r.stdout[-6000:],stderr=r.stderr[-6000:])
            report['exact_replays'].append(item)
    report['status']='PASS' if all(i['exit_code']==0 for i in report['exact_replays']) else 'FAIL'
    print(json.dumps(report,indent=2))
    return 0 if report['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
