import sympy as s,json,time
start=time.time();checks=[]
def ck(name,p):
 ok=s.factor(p)==0
 checks.append({'name':name,'passed':ok});print(('PASS ' if ok else 'FAIL ')+name,flush=True)
 if not ok: print(s.factor(p));raise AssertionError(name)
b,g,u,v,Qb,Yb,N,Z=s.symbols('b g u v Qb Yb N Z',positive=True)
cB,aB,Db,ab,h2,hb,t,M=s.symbols('cB aB Db ab h2 hb t M',positive=True)
R=M+t;p=t/R;Du=1+u*u;Dv=1+v*v
H=u*Qb/b;V=u*v*Z/b;L=v*Qb/g;Bb=g*N+p*v*Qb
W=b*Qb-u*b*b*Yb;Y=b*b*Yb;X=b*Bb-u*Z
J=u*W+u*v*X-Y-v*Z;Jb=b*b*(H-Du*Yb)+u*b*v*Bb-Du*v*Z
K=J*J+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z*Z
Kbar=b*b*(H-Du*Yb)**2+2*b*u*v*(H-Du*Yb)*Bb+u*u*v*v*Bb*Bb+Du*v*v*b*b*Yb*Yb+Du*V*V-2*Du*V*(Qb+v*Bb)+2*Du*u*u*v*Z*Yb
ck('complete signed core, with every state normal',K/b**2-Dv*Bb**2-Kbar)
ck('complete D current',J-Jb)
parent=4*h2/(g*g*M)*(v*W-X+u*v*Y-u*Z)**2+4*cB/b**2*Dv*(u*W-Y)**2+4*aB/b**2*Du*Dv*Y**2+4*b*b*Db*J**2+4*b*b*g*g*ab*Du*(v*Y-Z)**2+4*(hb/(g*g*t)-s.Rational(1,2))*Dv*(X+u*Z)**2+2*K
ret=4*h2*t/(M*R)*N*N+4*hb*M/(t*R)*Dv*N*N
pair=4/R*((h2+hb*Dv)*N*N+2*(hb*Dv-h2)*L*N+(h2*(1-p)+hb*p*Dv)*L*L)
red=pair+4*Dv*(cB*(H-Du*Yb)**2+aB*Du*Yb**2)+4*Db*Jb**2+4*g*g*ab*Du*(v*b*b*Yb-Z)**2+2*Kbar
ck('full original parent minus both retained positive packets',parent/b**2-ret-red)
ss=cB+aB;rho=cB/ss;hh=cB*aB/ss
Ny=s.symbols('Ny');rho0=s.symbols('rho0')
Yexpr=(Ny/s.sqrt(ss)+rho0*H)/Du
harm=(Ny+s.sqrt(ss)*(rho0-rho)*H)**2+hh*H*H-aB*u*u/Du*(Ny/s.sqrt(ss)+rho0*H)**2
ck('opening-uniform exact harmonic normal',cB*(H-Du*Yexpr)**2+aB*Du*Yexpr**2-harm)
q,r,z,bb=s.symbols('q r z bb',positive=True);x=bb*q;eta=1/bb;aa=bb*(1-r);theta=t*z;hx=1-theta;yc=q*z;KK=1+x;RR=1+x*r;TT=1+x*hx;JJ=TT-aa;EE=1-q*hx;QQ=1-x*z*r;GG=hx+z
Pd=1+2*x*hx+r*x*x*GG+x*z+eta*x*(KK*z+x*hx*theta)
P4=TT*EE+x*(1-r)*GG;Pa=RR*hx*(1+yc)+z*(RR-t)*EE
S0=KK*r*(1+bb*r)*EE+(1-r)*P4
cb=KK*(1+bb*r)*EE/(2*(1-r)*Pd);ac=P4/(2*r*Pd)
rrho=KK*r*(1+bb*r)*EE/S0
ck('source harmonic shape',rrho-cb/(cb+ac))
T0=q*q*hx*hx+q*r*z+2*q*t*z-q*z-2*q+r
delta=-bb*r*(1-r)*KK*T0/S0
ck('all-opening contact centering factor',KK*r-rrho*RR-delta)
ck('positive uniform source harmonic coefficient',cb*ac/(cb+ac)-KK*(1+bb*r)*EE*P4/(2*Pd*S0))
B5=KK*(1+yc)*(r+eta)-(eta*TT-1+r)*Pd
sourceDb=s.cancel(B5/(2*JJ*eta*Pd*bb))
sourceAb=s.cancel(x*x*z*(r+eta)*Pa/(2*QQ*Pd*bb*z))
sourceh2=s.cancel(KK*x*(r+eta)*hx*(1+yc)/(2*Pd))
sourcehb=s.cancel(KK*x*(r+eta)*GG/(2*Pd))
ck('D/b² residue',(sourceDb.subs(bb,0).subs(z,0))-(1-2*q)/2)
ck('alpha/(b²g²) residue',(sourceAb.subs(bb,0).subs(z,0))-q*q/2)
ck('paired h2 residue',(sourceh2.subs(bb,0).subs(z,0))-q/2)
ck('paired hb residue',(sourcehb.subs(bb,0).subs(z,0))-q/2)
ck('paired coefficient difference',sourcehb-sourceh2-KK*q*(1+bb*r)*EE*z/(2*Pd))
HH,LL,VV,Tg,Vz,Qbb=s.symbols('H L V T Vz Qbar');F0=(1-q)*HH**2+q*LL**2+VV**2+(1-2*q)*Vz**2+q*q*Tg*Tg-2*HH*Vz
CIRC=q*HH**2+q*LL**2+VV**2+q*q*Tg*Tg-4*q*HH*Vz
ck('exact leading binomial plus four-term circuit',F0-(1-2*q)*(HH-Vz)**2-CIRC)
c=s.symbols('c',positive=True);ww=s.symbols('w',positive=True)
HA=u*ww/b**2;LA=v*ww/(b*g);VA=u*v/b;DA=c*c*g
A=c*HA;B=c*LA;C=VA;D=DA
ck('separated radical circuit product',A*B*C*D-(c*c*VA*ww/b)**2)
EEr=HA-v;va=A-D-c*EEr;ua=C-D-va;wa=B-D-va
ck('u conductor',HA*(u-b*c)-(u-b*c)*EEr-b*ua)
ck('v conductor',HA*(v-c*g)-(v-c*g)*EEr-v/c*va)
ck('w conductor',HA*(ww-b*g)-(ww-b*g)*EEr-b*g/c*wa)
WW,XX,YY,ZZ,mu,eps=s.symbols('WW XX YY ZZ mu eps')
Jraw=u*WW+u*v*XX-YY-v*ZZ
Kraw=Jraw**2+(1+u*u)*(v*YY-ZZ)**2+(1+v*v)*(XX+u*ZZ)**2-(1+u*u)*(1+v*v)*ZZ**2
caps=4*mu*((1+v*v)*(u*WW-YY)**2+(1+u*u)*(1+v*v)*YY**2+(v*WW-XX+u*v*YY-u*ZZ)**2+(1+v*v)*(XX+u*ZZ)**2)
quad=s.expand((2*Kraw+caps).subs({u:eps*u,v:eps*v,XX:eps*XX,YY:eps*YY})).coeff(eps,2)
claim=2*(u*WW-YY)**2+2*(XX+u*ZZ)**2-4*u*v*WW*ZZ+4*mu*((u*WW-YY)**2+YY**2+(v*WW-XX-u*ZZ)**2+(XX+u*ZZ)**2)
ck('four-event W-state chart full quadratic',quad-claim)
AA,BB,CC,DD=s.symbols('AA BB CC DD',positive=True)
pairings=[(AA,BB,CC,DD),(AA,CC,BB,DD),(AA,DD,BB,CC)]
symmetric=sum((a-bb)**2 for i,a in enumerate([AA,BB,CC,DD]) for bb in [AA,BB,CC,DD][i+1:])/3+sum(2*(s.sqrt(a*bb)-s.sqrt(cc*dd))**2/3 for a,bb,cc,dd in pairings)
ck('symmetric strict four-term circuit Gram',s.expand(symmetric)-(AA**2+BB**2+CC**2+DD**2-4*s.sqrt(AA*BB*CC*DD)))
ck('weighted E pivot syzygy',s.expand(c*s.sqrt(u*ww)*EEr-s.sqrt(u*ww)*(A-D)-b*s.sqrt(c*g)*(s.sqrt(A*D)-s.sqrt(B*C))))
ck('weighted u difference pivot',s.expand(s.sqrt(v*ww)*(u-b*c)-b**s.Rational(3,2)/s.sqrt(c)*(s.sqrt(A*C)-s.sqrt(B*D))))
ck('weighted v difference pivot',s.expand(s.sqrt(u*ww)*(v-c*g)-b*s.sqrt(g/c)*(s.sqrt(B*C)-s.sqrt(A*D))))
ck('weighted w difference pivot',s.expand(s.sqrt(u*v)*(ww-b*g)-b**s.Rational(3,2)*s.sqrt(g)/c*(s.sqrt(A*B)-s.sqrt(C*D))))
Jsrc=s.symbols('Jsrc')
retainD=4*Db*(Jb+Jsrc/R*H)**2
ck('contact-centered D subtraction removes standalone v squared',4*Db*Jb**2-retainD+8*Db*(Jsrc/R)*H*Jb+4*Db*(Jsrc/R)**2*H**2)
# Graph scalar after both exact normals are zero; rho0 is arbitrary here.
afun=1-rho0+p*v*v
AH=4*Dv*(cB*(1-rho0)**2+aB*rho0**2/Du)+2*b*b*(afun**2+v*v*rho0**2/Du)+4*ab*g*g*b**4*v*v*rho0**2/Du-8*Db*(Jsrc/R)*b*b*afun-4*Db*(Jsrc/R)**2
BL=4/R*(h2*(1-p)+hb*p*Dv)
CH=-4*(Du*(1+p*v*v)-u*u*rho0)-8*ab*g*g*b*b*rho0+8*Db*(Jsrc/R)*Du
scalar=AH*H**2+BL*L**2+2*Du*V**2+4*ab*g*g*Du*Z**2+CH*H*v*Z
actual=(red-retainD).subs({N:0,Yb:rho0*H/Du})
ck('complete raw five-term graph scalar',actual-scalar)
GM=(A*B*C*D)**s.Rational(1,4)
ck('circuit geometric mean converts mixed scalar',s.expand(GM**2-c*c*HA*v))
ck('full u conductor through geometric mean',s.expand(GM*(u-b*c)-s.sqrt(u*b*c)*(s.sqrt(A*C)-s.sqrt(B*D))))
ck('full v conductor through geometric mean',s.expand(GM*(v-c*g)-s.sqrt(v*c*g)*(s.sqrt(B*C)-s.sqrt(A*D))))
ck('full w conductor through geometric mean',s.expand(GM*(ww-b*g)-s.sqrt(ww*b*g)*(s.sqrt(A*B)-s.sqrt(C*D))))
ck('half u conductor',s.expand(GM*(s.sqrt(u)-s.sqrt(b*c))-(u*b*c)**s.Rational(1,4)*s.sqrt(GM)*((A*C)**s.Rational(1,4)-(B*D)**s.Rational(1,4))))
ck('half v conductor',s.expand(GM*(s.sqrt(v)-s.sqrt(c*g))-(v*c*g)**s.Rational(1,4)*s.sqrt(GM)*((B*C)**s.Rational(1,4)-(A*D)**s.Rational(1,4))))
# Symbolic positive-variable identities used for the complete finite square lift.
GG=(AA*BB*CC*DD)**s.Rational(1,4)
ck('strict geometric mean variance split',s.expand(sum((x-GG)**2 for x in [AA,BB,CC,DD])+2*GG*(AA+BB+CC+DD-4*GG))-(AA**2+BB**2+CC**2+DD**2-4*GG**2))
ck('linear AMGM square split',s.expand((s.sqrt(AA)-s.sqrt(BB))**2+(s.sqrt(CC)-s.sqrt(DD))**2+2*((AA*BB)**s.Rational(1,4)-(CC*DD)**s.Rational(1,4))**2)-(AA+BB+CC+DD-4*GG))
ck('pair first-jet syzygy exact square lift',s.expand(s.sqrt(AA*BB)-s.sqrt(CC*DD)-(AA+BB-CC-DD)/2+(s.sqrt(AA)-s.sqrt(BB))**2/2-(s.sqrt(CC)-s.sqrt(DD))**2/2))
Gny=s.expand((red-retainD).subs(Yb,(Ny/s.sqrt(ss)+rho0*H)/Du))
LN=8/R*(hb*Dv-h2)*L+4*b*u*v*g*(afun-2*Db*Jsrc/R)*H-4*Du*v*g*V
LY=8*Dv*s.sqrt(ss)*(rho0-rho)*H+H/s.sqrt(ss)*(-8*Dv*aB*u*u*rho0/Du+8*Db*(Jsrc/R)*b*b+8*ab*g*g*b**4*v*v*rho0/Du-4*b*b*afun+4*b*b*v*v*rho0/Du)+4*b*u/s.sqrt(ss)*V-8*ab*g*b*b*v/s.sqrt(ss)*(g*Z)
ck('entire first N normal',s.diff(Gny,N).subs({N:0,Ny:0})-LN)
ck('entire first harmonic normal',s.diff(Gny,Ny).subs({N:0,Ny:0})-LY)
HNN=4*(h2+hb*Dv)/R+2*g*g*u*u*v*v
HYY=4*Dv*(1-aB*u*u/(Du*ss))+4*ab*g*g*b**4*v*v/(Du*ss)+2*b*b/ss*(1+v*v/Du)
HNY=-4*b*u*v*g/s.sqrt(ss)
ck('complete NN hard entry',s.diff(Gny,N,N)/2-HNN)
ck('complete harmonic hard entry',s.diff(Gny,Ny,Ny)/2-HYY)
ck('complete hard cross coefficient',s.diff(Gny,N,Ny)-HNY)
checksfile=__file__.replace('.py','.json')
open(checksfile,'w').write(json.dumps({'passed':all(x['passed'] for x in checks),'checks':checks,'elapsed_seconds':time.time()-start},indent=2))
print(len(checks),'checks passed')
