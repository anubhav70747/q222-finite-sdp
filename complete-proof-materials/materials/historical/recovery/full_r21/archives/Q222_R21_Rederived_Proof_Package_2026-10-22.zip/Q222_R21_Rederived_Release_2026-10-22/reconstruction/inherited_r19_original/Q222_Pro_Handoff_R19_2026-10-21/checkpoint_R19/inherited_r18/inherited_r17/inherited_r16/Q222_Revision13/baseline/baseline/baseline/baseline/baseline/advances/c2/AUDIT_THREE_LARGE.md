# Scoped audit: arbitrary n,A,D in the C2 pitchfork

**Verdict: PASS after the exact Q_12 display correction described below.** The theorem covers the entire original parent and all independent tests for its displayed actual-contact domain. It retains positive-unit d,C,alpha and the actual half-angle residue type k infinitesimal, a a positive unit. No relative-scale bound on n,A,D is used.

This is a separate-agent analytical review within the same assistant system. I read the full stronger theorem, its original-parent checker and receipt, and the audited two-large-event theorem and earlier all-tests corollary. I did not duplicate the author's checker run. The review focuses on the new hypotheses and the complete proof implications.

## Source entry

The initial bounded coercivity estimate uses only d,C,alpha. Retaining the other nonnegative packets yields X_c,Y_c,Z_c=O(k) after W_c=1 and m=O(k^2), without assuming A bounded.

The changed order of state equations is necessary and correct. F_Z contains neither the A packet nor the n packet; with a a unit, it first gives DJ_c=O(k). F_Y then gives AY_c=O(k), and F_X gives NX_c=O(k^2). Thus the products Nx,Ay,Dj in TA1 are bounded before any inverse of A or D is used.

Dividing the exact stationary equations by T_A L controls every coefficient. The normalized factors t_2/T_A, t_6/T_A, t_3/L and t_4 are positive units because m is already bounded and d,C,alpha are units. The first equation's left coefficient is (A/T_A) times a positive unit by the previously audited reciprocal identity. Its right coefficient in TA2 is a positive unit uniformly:

- if D/L is a unit, its second positive summand gives the lower bound;
- if D/L is infinitesimal, D is infinitesimal and L is a unit, while t_8/T_A is a unit, so its first summand gives the lower bound.

Both summands are bounded above because T_A,L are bounded below and the numerator has degree at most one in each possible large weight. This proves TA3.

For precision, the comparability conclusion in TA4 can be expressed without relying on ambiguous O-term cancellation. Put a_s=A/T_A and b_s=D/L. After substitution of TA3 the second equation has the form

`a_s c_0+a_s U c_1=b_s c_2+a_s U b_s c_3`,

with c_0,c_2 positive units and c_1,c_3 bounded. Therefore

`a_s(c_0+U c_1−U b_s c_3)=b_s c_2`.

The bracket is a positive unit because U is infinitesimal and b_s is bounded. Hence the two ratios are comparable, including their possible zero case. If they were infinitesimal, A,D and m would be infinitesimal; the retained physicality contradiction kills the n packet exactly and produces a negative residue polynomial. Thus A/T_A,D/L,m/k^4 are positive units. All inverse factors used later are now bounded legitimately.

## Entire adapted graph and normal restoration

The graph TA6 reproduces X_c,Y_c,J_c and consequently Z_c. Its 1/v denominator is used only where v has a nonzero finite residue. It is a pure testing unit. All coefficient-field inverse factors are also pure and bounded.

The three potentially large packets are exactly adapted to X,Y,J. Their graph and linear coefficients depend on n x^2,nx,Ay^2,sqrt(A)y,Dj^2,sqrt(D)j, all bounded by TA1 and TA5. Their quadratic normal terms are exactly the three normalized diagonal packet squares. Every other source weight is bounded.

The chain-rule normal directions are correct:

`F_X+u F_Z`, `F_Y−F_Z/v`, and `−F_Z/v`.

The first removes both A and D; the second removes n and D; the third removes n and A. This also follows directly by differentiating the amplitudes in the triangular inverse TA8, so it is a whole-parent statement rather than a restriction at contact.

The scalar and first-normal shapes TA10 therefore have bounded Laurent coefficients. The displayed finite difference formula for v^−r is exact and provides bounded contact coquotients using only v^−1 and a^−1. Consequently the scalar second-order division and the first-normal conductors from the preceding theorem remain valid with these changed graphs. No mixed difference is inverted. The X row has infinitesimal coefficients on both soft roots, and the Y,J rows have infinitesimal R coefficients; their potentially nonzero T couplings remain in the final Schur block. State degree two means this restores the whole parent.

## Strict hard block and angular Schur complement

At u=0, the adapted hard coordinates give

`Y=E_Y/sqrt(A)`, `Z=−E_Y/(v sqrt(A))−E_J/(v sqrt(D))`.

The A and D packets then supply the explicit positive pivots

`4(1+v^2) E_Y^2+4 E_J^2`.

The remaining hard form is a bounded nonnegative sum with source weights C,alpha,d. Thus hard positivity is uniform for every combination of bounded or unbounded A,D, without selecting a largest event.

The determinant and Schur numerator are of degree at most one in each of A and D. Their quotients by T_A L are therefore bounded. The determinant contains `16AD(1+v^2)v^2`; for finite-unit v this supplies a positive lower bound after normalization, since A/T_A and D/L are units. The two exterior quartic coefficients are positive units as well.

One exact display was corrected during review. Since the boundary coefficient is

`Q_12=4CD[d+2(alpha+A)]`,

the exact normalized equality is

`Q_12/(T_A L)=4C(D/L)(t_2−2m)/T_A`,

not the originally printed expression containing t_2 alone. The author has incorporated this correction. The corrected last factor is still a positive unit, so no positivity claim changes.

The scaled graph hard coordinates sqrt(A)y and sqrt(D)j are bounded. The normal contact equations identify their residues with the unique hard minimizer, also when one or both large weights diverge. The exact scalar contact jets give f(a_0)=f'(a_0)=0. The normalized even quartic therefore equals its positive leading coefficient times `(v^2−a_0^2)^2`. Its strict second derivative gives the required T Schur pivot. Together with the separate X and R pivots, this proves strict positivity of the full five-root residue Gram.

Only a real residue Schur complement is inverted in this argument. The tensor certificate itself remains the exact bounded Gram obtained by contact division.

## Outer tests and endpoints

Away from the two matched Bob residues but with v still a finite unit, retain m,n and use X,sqrt(A)Y,sqrt(D)J,uW. The exact triangular substitution has only pure testing 1/v and bounded pure coefficient inverse factors. The complete remainder Gram is bounded. Its hard block is the one just verified; its scalar Schur complement is positive by the normalized quartic.

The two endpoints v~0 and v~infinity require a separate construction because the 1/v substitution is unavailable at the first endpoint and is not the chosen homogeneous chart at the second. The proposed capping argument supplies this correctly. After dividing by d, cap C,A,D,alpha at a positive-unit mu and retain all excesses and m,n. The selected parent need not be globally physical. Its endpoint Grams on X,Y,Z,uW are exact whole-parent identities. At v=0, the soft Schur pivot is `8Q_10,mu/det B_mu(0)>0`; at the reciprocal endpoint it is `8Q_12,mu/det B_mu,infinity>0`. Both hard blocks are positive. These two local strictness statements require only positive cap weights, not preservation of the original source's contact quartic.

The other commuting axes and Alice-infinity corners use the already audited capping forms. Their only source requirements are positive lower bounds on C/d,A/d,D/d,alpha/d, all available here. The noncommuting-residue join uses the inherited physical-source theorem. Homogenization in W includes W=0, and real/imaginary splitting gives complex states. Thus the changed A scale leaves no unhandled testing endpoint.

## Check receipt and scope

The reviewed checker builds the original parent, graph, whole first normals, three hard packet terms, normalized Schur polynomial, and endpoint determinants. I requested that its three paired “packet absent” checks assert each derivative separately instead of asserting only their sum: a sum alone could conceal cancellation. The author made this change, and the refreshed receipt reports **33 exact checks passed**. I inspected the separate assertions and receipt. The analytical amplitude argument above independently proves each absence, so this was a receipt-strength correction rather than a gap in the proof.

This theorem removes the source-scale restrictions on n,A,D from this actual-contact family. It does not cover unbounded C/d or alpha/d, different actual-angle residue types, or prove the exhaustive C2 source join. Those restrictions remain explicit and are not closed by this audit.
