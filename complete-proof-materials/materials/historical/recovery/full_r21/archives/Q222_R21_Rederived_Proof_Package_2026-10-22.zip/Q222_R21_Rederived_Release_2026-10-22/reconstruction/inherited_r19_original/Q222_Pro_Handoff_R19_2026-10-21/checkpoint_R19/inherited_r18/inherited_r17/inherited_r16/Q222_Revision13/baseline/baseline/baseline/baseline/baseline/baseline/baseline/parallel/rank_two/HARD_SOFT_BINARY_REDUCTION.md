# Exact hard/soft reduction of the complete parent

17 October 2026. Scope: a new exact reduction and characterization of its singular set. This does not assert cancellation of a mixed multiplier or replace the contact atlas.

## 1. Pure testing spectral frame

Let `B=d H+sum_i c_i w_i w_i^T`, with `d,c_i>=0` in the pure coefficient real closed field and `H,w_i` in the independent testing field. In the normalization of the fixed parent, `||w_i||^2=4`. All eight events and every zero event mask are retained. Put `r=|sin(theta_A)sin(theta_B)|`, `0<=r<=1`. A pure-testing orthogonal change of state coordinates makes

\[
 H=\operatorname{diag}(A_h,C_s),\qquad
 A_h=\operatorname{diag}(h_1,h_2),\quad C_s=\operatorname{diag}(-a,b),
\]
\[
 h_1=1+\sqrt{1+r},\quad h_2=1+\sqrt{1-r},\quad
 a=\sqrt{1+r}-1,\quad b=1-\sqrt{1-r}.
\]

Thus `A_h>=I`, while the soft trace

\[
 \delta=b-a=2-\sqrt{1+r}-\sqrt{1-r}\ge0
\]

is a pure-testing scalar. For `r>0`,

\[
 \delta=\frac{2r^2}{(1+\sqrt{1-r^2})(2+\sqrt{1+r}+\sqrt{1-r})},
 \qquad r^2/4\le\delta\le r^2.
\]

The lower bound uses the denominator at most eight. The upper bound follows from the denominator at least two. At `r=0` both sides are zero. The two hard eigenvalues stay uniformly positive, whereas the two soft eigenvalues vanish with opposite first order and nonnegative second-order trace.

Write `w_i=(x_i,y_i)` with two hard and two soft components, and

\[
 A=dA_h+\sum_i c_i x_ix_i^T,\quad X=\sum_i c_i x_iy_i^T,
 \quad C=dC_s+\sum_i c_i y_iy_i^T,\qquad
 B=\begin{pmatrix}A&X\\X^T&C\end{pmatrix}.
\]

All spectral operations in this paragraph belong only to the testing field. No mixed inverse or square root has occurred.

## 2. The exact binary operator

Define the polynomial matrix

\[
 K=(\det A)C-X^T\operatorname{adj}(A)X.
\]

Then the full parent has the exact no-inverse identity

\[
 (\det A)\,(x,z)^TB(x,z)
 =(Ax+Xz)^T\operatorname{adj}(A)(Ax+Xz)+z^TKz.\tag{1}
\]

The hard matrix and its adjugate already have separated tensor Grams:

\[
 A=d\operatorname{diag}(h_1,h_2)+\sum_i c_ix_ix_i^T,
\quad
 \operatorname{adj}(A)=d\operatorname{diag}(h_2,h_1)
       +\sum_i c_i x_i^{\perp}(x_i^{\perp})^T.
\]

The determinant has the nonnegative separated expansion

\[
 \det A=d^2h_1h_2+d\sum_i c_i(h_2x_{i1}^2+h_1x_{i2}^2)
       +\sum_{i<j}c_ic_j[x_i,x_j]^2,\tag{2}
\]

where `[x_i,x_j]=det(x_i,x_j)`. In particular, if `d>0`, the hard block is invertible in every ordered-field realization and `det A>=d^2`. Equation (1), however, does not use that inverse in the tensor ring.

The key binary decomposition is

\[
 \boxed{K=d(\det A)C_s+R},\tag{3}
\]

where the entire remainder is an explicit matrix tensor SOS:

\[
\begin{aligned}
 R={}&d^2h_1h_2\sum_i c_i y_iy_i^T\\
 &+dh_1\sum_{i<j}c_ic_j
       (x_{i2}y_j-x_{j2}y_i)(x_{i2}y_j-x_{j2}y_i)^T\\
 &+dh_2\sum_{i<j}c_ic_j
       (x_{i1}y_j-x_{j1}y_i)(x_{i1}y_j-x_{j1}y_i)^T\\
 &+\sum_{i<j<k}c_ic_jc_k v_{ijk}v_{ijk}^T,\tag{4}\\
 v_{ijk}={}&[x_i,x_j]y_k-[x_i,x_k]y_j+[x_j,x_k]y_i.
\end{aligned}
\]

Every coefficient root in (4) is taken in the coefficient field and every vector root in the testing field. Thus (4) has at most `8+2*28+56=120` separated vector roots, without any numerical Gram construction. Zero source coefficients simply delete roots. No claim of minimality is made.

### Proof of (4)

Form the four-row matrix with ten columns

\[
 V=(\sqrt{dh_1}\,e_1,\sqrt{dh_2}\,e_2,
                   \sqrt{c_1}w_1,\ldots,\sqrt{c_8}w_8).
\]

Here `sqrt(d h_j)` means `sqrt(d) tensor sqrt(h_j)`. Its Gram is the positive part `diag(d A_h,0)+sum_i c_i w_iw_i^T`. For each soft vector `z`, the three by three Gram formed by its first two rows and the row `z^T` on the soft coordinates has determinant `z^T R z`. Cauchy--Binet expands this determinant as the sum of squared three-column minors. Triples with both hard columns, exactly one hard column, or no hard column give respectively the three types printed in (4). This is a polynomial identity, so it also holds for `d=0` and every degeneracy.

## 3. Nonnegative trace, determinant, and the precise remaining descent

Taking traces in (3) gives

\[
 \tau:=\operatorname{tr}K=d(\det A)\delta+\operatorname{tr}R
                         \in\Sigma (K_c\otimes K_t)^2.\tag{5}
\]

The two by two determinant identity is

\[
 \det K=(\det A)\det B.\tag{6}
\]

It follows over the fraction field from the Schur determinant formula when `det A` is nonzero, and hence as a polynomial identity everywhere; alternatively expand both sides. The two by two characteristic identity gives

\[
 \boxed{\tau K=K^2+(\det A)(\det B)I_2.}\tag{7}
\]

Consequently scalar tensor SOS of `det B` implies matrix tensor SOS of `tau K` and then of `(det A) tau B` by (1). This does not improve the degree of the existing cubic multiplier `e_3(B)`; its value is geometric: it isolates the only indefinite core in a binary soft operator, shows that every event correction to that operator is a separated positive square, and identifies its singular scale exactly.

In particular, positivity of `tau` is not permission to divide by it in the tensor ring. The remaining step is a binary tensor-SOS descent theorem for the special operator (3), with (4), through the mixed scalar (5). Merely applying the two by two characteristic identity would repeat the unresolved cancellation problem.

## 4. The exact singular set and its scale

Assume `d>0`. In any common ordered real closed realization of the two fields, all terms of (5) are nonnegative. The first line of (4) proves

\[
 \tau\ge d^2h_1h_2\left(d\delta+\sum_i c_i\|y_i\|^2\right).
 \tag{8}
\]

Thus `tau=0` if and only if

\[
 r=0,\qquad c_i y_i=0\quad\text{for every }i.\tag{9}
\]

Indeed equality forces both conditions by (8); conversely those conditions make every term of (3)--(4) zero. Therefore the vanishing binary multiplier is exactly the commuting-measurement locus where every active event lies entirely in the two hard modes. At that locus `B=diag(A,0)` has precisely a two-dimensional kernel, and its tensor Gram is immediate. The difficult limit is approaching this locus with both the commutator and soft event openings tending to zero at unrelated rates.

There is a uniform quantitative version. Put `rho=d+sum_i c_i>0`. If `d>=epsilon rho`, `0<epsilon<=1`, then `A<=4 rho I`, `det A<=16 rho^2`, and

\[
 \epsilon^2\rho^2\left(d\delta+\sum_i c_i\|y_i\|^2\right)
 \le\tau\le
 16\rho^2\left(d\delta+\sum_i c_i\|y_i\|^2\right).\tag{10}
\]

The upper bound follows from `R=(det A) sum_i c_i y_iy_i^T-X^T adj(A)X` and positive definiteness of `A`. These are inequalities in a common ordered-field realization, not an order assigned to the tensor ring. The inequalities identify the two competing physical scales without asserting a mixed inverse: squared measurement noncommutativity and total positive event weight in the soft modes.

## 5. A limitation of invariant polynomial shortcuts

There is also an immediate six by six separated positive operator: the additive second compound `L_2(B)` acting on `wedge^2 R^4`. Its eigenvalues for a symmetric operator are all pairwise eigenvalue sums. Since `H` is two-positive and every event is PSD,

\[
 L_2(B)=dL_2(H)+\sum_i c_iL_2(w_iw_i^T)
\]

is a matrix tensor SOS, with the entire matrix factors purely testing. This is linear in the original source coefficients. It explains the positive soft trace without selecting a state-dependent eigenvector. It does not supply the missing binary cancellation at a double-zero eigenvalue.

Even granting positivity of all pairwise eigenvalue sums and nonnegative determinant cannot yield a polynomial quadratic-module identity for a single smallest eigenvalue near a rank-two PSD matrix. Write its local eigenvalues as `(p,q,h_1,h_2)` with positive fixed `h_1,h_2`. At `(p,q)=(0,0)`, the only vanishing pair-sum constraint is `p+q`, while determinant `h_1h_2 p q` has zero first differential. A quadratic-module expression for `p` would have first differential proportional to `d(p+q)`: square terms vanishing at the origin have zero first differential, and terms multiplied by strictly positive constraints must also have zero square factors there. But `dp` is not proportional to `dp+dq`. This rules out that specific invariant polynomial-module route. It does not exclude algebraic testing features, pure-field clearings, valuation-dependent bounded frames, or a dedicated binary descent theorem using more physical information than pair sums and determinant.

## 6. Verification scope

All matrix identities above are proved symbolically by the displayed Cauchy--Binet argument. The companion `check_hard_soft.py` checks the generic block identities (1), (6), (7), and the complete expansions (2), (3)--(4) on three arbitrary formal event vectors. Cubic multilinearity covers every event interaction type. All checks pass by exact symbolic expansion. No SDP solver, numerical sampling, imported external result, or plain-polynomial-SOS search is used.
