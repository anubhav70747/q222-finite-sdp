# Scoped audit: determinant circuits and cancellation

Reviewed only the first two mathematical sections of `report.tex`.
Result: **no mathematical gap found in these sections**, with the stated
bounded-parent and positive-residue hard-block hypotheses retained. This
does not supply the missing conductor or audit the subsequent examples.

1. **The twelve circuits are complete.** A support-minimal positive
   dependence among planar vectors has at most three members. Two-member
   supports are the four antipodal pairs. Among three-member supports,
   the two displayed families and their quarter rotations give exactly
   eight triangles: four with primitive weights `(1,1,1)` and four with
   primitive weights `(1,1,2)`, up to ordering. I independently enumerated
   all pairs and triples of the eight lattice directions using exact
   integer determinants; the counts are 4 and 8. Missing Newton directions
   are simply assigned zero weight. The support-elimination argument works
   over the ordered coefficient field and terminates after finitely many
   support deletions.

2. **All three circuit identities are exact.** For the cubic one, the
   usual identity for `a³+b³+c³−3abc` applies with `abc=1`. Expanding the
   positive factor `a+b+c` makes each coefficient a positive elementary
   tensor, whose square root separates between the fields. In the weighted
   triangle, `sqrt(z)=(xy)^(-1/4)` gives exactly the stated constant term.
   The circuit weights belong solely to the coefficient field.

3. **The endpoint exponents are sufficient.** After expanding the cubic
   prefactor, every root monomial has exponent vector one half of a convex
   combination of the Newton exponents. Multiplication by `sqrt(UV)` puts
   both `U,V` exponents in `[0,1]`; multiplication by `D_u D_v` puts them
   in `[0,2]`. Thus the exponents in `u,v` lie in `[0,4]`. The identities
   extend at the zero axes with nonnegative fractional powers. For literal
   infinity, homogenize each root to degree four in each local angle pair:
   the complementary exponents are also nonnegative. This is the precise
   justification for the text's projective-chart sentence; restoration is
   used only at nonzero chart pivots, not by dividing a vanishing endpoint
   factor. No mixed fractional power occurs.

4. **The adjugate Gram needs exactly the assumptions stated.** The entire
   matrix `P`, hence `A` and its polynomial adjugate, must have bounded
   entries in the chosen normalized chart, and `res(A)` must be positive
   definite. Then `res(adj(A))` is positive definite. If the determinant
   circuit roots are `r_j`, take the combined root vector
   `(Ax+by, y r_1, …, y r_N)` and Gram `diag(adj(A), I_N)`. Source circuit
   weights, including potentially unbounded factors, are absorbed in the
   roots. The roots need not be bounded. No inverse of `A`, `det(A)`, or a
   mixed scalar is required. This construction does not assert that every
   source/test chart has such a hard block.

5. **Both cancellation statements are valid.** Bounded quadratic
   membership makes `(a−res(a))H` a bounded zero-residue matrix, so the
   first lemma preserves the strict Gram residue and divides only by a
   positive real constant. For the product criterion, the displayed
   zero-residue product matrix suffices even if `a_0` was not initially
   chosen to equal `res(a)`; the restoration factor is a positive pure
   coefficient unit. Symmetrizing the two bounded linear memberships gives
   the asserted matrix exactly. Neither lemma silently replaces bounded
   membership by contact vanishing, arbitrary ideal membership, or an
   inverse of the mixed determinant.

No change to the mathematical claims is requested. An optional wording
improvement is to include the degree-four endpoint homogenization from
item 3, so that literal infinity cannot be mistaken for cancellation by
a zero testing multiplier.
