import sympy as s,json
from pathlib import Path
C,A,Dp,h,r,t,b,P,Q,R=s.symbols('C A Dp h r t b P Q R',nonzero=True)
checks={}
def ck(name,x):
 assert s.cancel(x)==0,(name,s.factor(x));checks[name]=True
S=h*h*C*Dp/(C+Dp)-b*b/A
f=(C+Dp)*P*P+A*Q*Q-2*h*Dp*P*R+2*b*Q*R+h*h*Dp*R*R
ck('entire_joint_weighted_completion',f-((C+Dp)*(P-h*Dp/(C+Dp)*R)**2+A*(Q+b/A*R)**2+S*R*R))
u,v,W,Z,X,xi,x=s.symbols('u v W Z X xi x');U=u*u;V=v*v
E=t*u*W-v*Z;RD=v*(U-x)*Z;T=1+x*h;e=t*T;qp=v*Z-u*v*X
ck('opening_safe_full_normal',(e*u*W-qp-(T*E-h*RD+u*v*xi)).subs(X,xi-h*u*Z))
a,y,Ef=s.symbols('a y Ef');F=V-y;Fb=F+v*Ef
# e4 scalar, E-first-normal, and E-hard contributions after contact centering.
raw=x*F*F+V*(U-x)*F+2*v*(U*V-x*y)*Ef+U*V*Ef*Ef
ck('entire_e4_radial_recombination',raw-(U*Fb*Fb+y*(U-x)*(Fb+v*Ef)))
Hu=V*x/(y*u)-u
ck('entire_e4_angular_recombination',raw-((U+x)*Fb*Fb-y*u*Hu*(Fb+v*Ef)-x*V*Ef*Ef))
Pc,Rc,sS=s.symbols('Pc Rc sS',nonzero=True)
ck('complete_D_row_cancellation',(P-h*R)-(P-h*Dp/(C+Dp)*R-h*C/(C+Dp)*R))
Rt=s.symbols('Rt')
ck('D_shift_remaining_cross',(2*b*Q*R).subs(R,Rt+u*v*xi/h)-(2*b*Q*Rt+2*b/h*u*v*Q*xi))
# Entire native-parent hard remainder, independently differentiated.
E,nu,xi,al,m,Bx,a=s.symbols('E nu xi alpha m Bx a')
W=(v+E)/(t*u);Y=r*(v+E)/t+nu;X=xi-h*u
Du=1+U;Dv=1+V;th=1-h
M=v*W-X+u*v*Y-u;Dc=u*W-Y+u*v*X-v
F=m*M*M+C*Dv*(u*W-Y)**2+A*Du*Dv*Y*Y+Dp*Dc*Dc+(al+s.Rational(1,2))*Du*(v*Y-1)**2+Bx*Dv*(X+u)**2-Du*Dv/2
qw=al+(m+Bx)*th*th;mu=m-a*a*qw
Hu=a*V/(t*u)-u
remaining=s.Poly(s.cancel(F-qw*(Hu+a*v/(t*u)*E-a*xi)**2-mu*(v/(t*u)*E-xi)**2),E,nu,xi)
hard=sum(co*E**mon[0]*nu**mon[1]*xi**mon[2] for mon,co in remaining.terms() if sum(mon)==2)
Ps=(1-r)*E/t-nu;Qs=r*E/t+nu;Tm=m+A+al+s.Rational(1,2)
expected=C*Ps*Ps+A*Qs*Qs+Dp*(Ps+u*v*xi)**2+Bx*xi*xi+A*U*Qs*Qs+C*V*Ps*Ps+(A+al+s.Rational(1,2))*V*Qs*Qs+Tm*U*V*Qs*Qs+2*m*V*E*Qs/t-2*m*u*v*Qs*xi+Bx*V*xi*xi
ck('entire_parent_higher_hard_identity',hard-expected)
Fbare=V-y;Fbar=Fbare+v*E;Ftilde=Fbar+t/r*v*nu;e4=r*r*Tm/(t*t)
raw=e4*(U*Fbar*Fbar+y*(U-x)*(Fbar+v*E))+2*r*Tm/t*v*(U*Fbar+y*(U-x))*nu+Tm*U*V*nu*nu
ck('whole_fullY_high_degree_group',raw-e4*(U*Ftilde*Ftilde+y*(U-x)*(Ftilde+v*E+t/r*v*nu)))
# Contact-centered m row; the noncentered original event is not a standalone SOS summand.
ys=x*t/a
Fty=t/r*v*Y-ys
Hs=a*v*W-u-a*xi
Ms=1+x*r-a*(1-h)
ck('contact_centered_original_m_row',M-Ms*u/a-(Hs/a+r/t*u*Fty))
out={'status':'PASS','checks':checks,'count':len(checks),'scope':'Exact frontier lemmas only; no C14.3b closure or coupled-row boundedness assertion.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
