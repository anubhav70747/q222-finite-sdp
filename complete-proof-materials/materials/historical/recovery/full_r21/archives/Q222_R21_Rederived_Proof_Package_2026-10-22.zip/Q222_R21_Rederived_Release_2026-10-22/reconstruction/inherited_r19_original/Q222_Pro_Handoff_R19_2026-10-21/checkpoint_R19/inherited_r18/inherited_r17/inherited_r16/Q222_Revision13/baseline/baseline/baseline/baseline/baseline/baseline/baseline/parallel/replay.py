#!/usr/bin/env python3
"""Replay the new exact checks only. Install sympy==1.14.0 if unavailable."""
from concurrent.futures import ThreadPoolExecutor
import json, os, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parent
scripts=[
 'graph/check_original_moving_frame.py',
 'graph/check_residue_covariance_census.py',
 'newton/check_finite_unit_covariance.py',
 'newton/check_weighted_five_root_identity.py',
 'rank_two/check_c2_opening_floor.py',
 'rank_two/ALL_TEST_C2.py',
 'rank_two/WEAK_SOURCE_EDGE_NORMAL_FORM.py',
 'rank_two/WEAK_C1_DUNIT_CURVATURE_AUDIT.py',
 'root/check_all_test_c1.py',
 'root/check_weak_c1_all_tests.py',
 'graph/derive_weak_source_family.py'
]
def run(rel):
    started=time.monotonic()
    result=subprocess.run([sys.executable,str(ROOT/rel)],cwd=ROOT,text=True,capture_output=True)
    return {'script':rel,'status':'PASS'if result.returncode==0 else'FAIL','returncode':result.returncode,'seconds':round(time.monotonic()-started,2),'output':result.stdout,'error':result.stderr}
with ThreadPoolExecutor(max_workers=3) as pool:
    result=list(pool.map(run,scripts))
(ROOT/'NEW_EXACT_REPLAY.json').write_text(json.dumps({'status':'PASS'if all(z['returncode']==0 for z in result)else'FAIL','checks':result},indent=2)+'\n')
for z in result:print(z['status'],z['script'],z['seconds'])
raise SystemExit(0 if all(z['returncode']==0 for z in result)else 1)
