"""Focused exact checks for the new R4 e-unit extension.
The complete WA matrix and established centered D/m identities are imports.
No historical checker is rerun; only definitions are loaded from its prefix.
"""
import json,time
from pathlib import Path
import sympy as s
started=time.monotonic(); checks={}
def ck(name,expr):
    vals=list(expr) if isinstance(expr,s.MatrixBase) else [expr]
    assert all(s.cancel(v)==0 for v in vals),name
    checks[name]=True
    print('PASS '+name,flush=True)
# Load pure symbolic definitions of complete G, stopping before any checks.
p=Path('work_r17/weak_r8_small_r/check_r8_small_r.py')
src=p.read_text(); definitions=src[src.index('u,v,a,B,r,h,t,j='):src.index('ld=s.Matrix')]
exec(definitions)
e=1-r; l=1-h; ast=s.symbols('alphastar'); N,mu,nu,K,tau=s.symbols('N mu nu K tau',positive=True)
# Exact zero-angle full D-free Gram, followed by the source-unit R1 solve.
Gbase=G.subs(D,0).subs(al,B*B*ast).subs({u:0,v:0})
P=s.Matrix([[1/s.sqrt(N),0,0,0,0],[0,1,0,0,0],
            [0,1/l,0,0,0],[0,0,0,1,0],[0,0,0,0,1]])
Q=P.T*Gbase.subs({n:N-s.Rational(1,2),m:a*a*mu})*P;Q[2,2]+=1
Targ=s.diag(1+a*a*mu/N,A/l**2,1,mu,ast)
Targ[0,3]=Targ[3,0]=-a*mu/s.sqrt(N)
ck('complete_g_unit_local_residue',Q-Targ)
ck('g_unit_two_root_determinant',Targ.extract([0,3],[0,3]).det()-mu)
# Unscaled R2 and the exact mcap correction's zero-angle residue.
Scale=s.diag(1,1,1,a,1);H0=s.zeros(5)
H0[0,3]=H0[3,0]=-1;H0[3,3]=2
Qcap=P.T*(Scale*Gbase.subs({n:N-s.Rational(1,2),m:K})*Scale+tau*H0)*P;Qcap[2,2]+=1
Tcap=s.diag(1+K/N,A/l**2,1,K+2*tau,ast)
Tcap[0,3]=Tcap[3,0]=-(K+tau)/s.sqrt(N)
ck('complete_g_infinitesimal_capped_local_residue',Qcap-Tcap)
ck('capped_two_root_determinant',Tcap.extract([0,3],[0,3]).det()-(K+2*tau-tau*tau/N))
# Unchanged exact source formulas (WE1).
cab=1+a*B*r;SrcS=1+B*(1-h+a*r);gg=1+a*(h*B+r-1)
Delta=a+(1+a*B)+(1+a*B)*B+2*a*B*(1+a*B)*r+a**3*B**2*r*r+2*a*a*B*r+t*B*(1+a+a*B+a*a*B*r*(2-r))
Mstar=(1+a*B)*(1+a*r)*(h+t)-a*(1+t*B)*(1-r)*(1-h)
nrex=((1+a*r)*cab*SrcS-r*Delta)/(2*Delta)
muex=(1+t*B)*(1-r)*cab*SrcS/(2*gg*Delta)
Cex=cab*Mstar/(2*l*Delta);Ahex=t*cab*(1+a*r)*SrcS/(2*Delta)
Djex=(1+a*B)*(1+a*r)*(1-a*t*B*r)*SrcS/(2*t*Delta)
aex=(1+a*r)*Mstar/(2*(1-h*B)*Delta)
corner={B:0,t:l};Ms=1+a*r-a*e*l;gres=1-a*e
for name,expr,expected in [
 ('nr',nrex,e/(2*(1+a))),('mg',a*a*muex*gg,a*a*e/(2*(1+a))),
 ('Ah',Ahex,l*(1+a*r)/(2*(1+a))),('Dj',Djex,(1+a*r)/(2*l*(1+a))),
 ('C',Cex,Ms/(2*l*(1+a))),('alphastar',aex,(1+a*r)*Ms/(2*(1+a))),
 ('mu_gunit',muex,e/(2*gres*(1+a)))]:
    ck('joint_source_residue_'+name,expr.subs(corner,simultaneous=True)-expected)
ck('positive_Mstar_decomposition',Ms-(gres+a*(r+e*h)))
b2ex=2*a*a*muex*h+Cex*l*l+Ahex*h+(B*B*aex+s.Rational(1,2))*h*h
ck('exact_Qstar_cancellation_at_a_zero',(b2ex-aex).subs(a,0))
# Check finite remote full original parent and the critical small-a axis.
W,X,Y,Z,Jhat,S,R,dd,nc,mc,Ac,Cc=s.symbols('W X Y Z Jhat S R dd nc mc Ac Cc')
Du=1+u*u;Dv=1+v*v
Me=v*W-X+u*v*Y-u*Z;Je=u*W+u*v*X-Y-v*Z
core=(Je*Je+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z*Z)/2
base=nc*Du*Dv*X*X+Cc*Dv*(u*W-Y)**2+Ac*Du*Dv*Y*Y+core
# D packet already normalized, original alpha packet retained separately.
p_u=base.subs(W,(dd*Jhat+Y+v*Z-u*v*X)/u)+Jhat*Jhat
ck('u_unit_v_zero_full_remote_residue',p_u.subs({dd:0,v:0})-(Jhat**2+nc*(1+u*u)*X*X+(X+u*Z)**2/2+Ac*(1+u*u)*Y*Y))
p_v=(base+mc*Me*Me).subs(Z,(u*W+u*v*X-Y-dd*Jhat)/v)+Jhat*Jhat
ck('u_zero_v_unit_full_remote_residue',p_v.subs({dd:0,u:0})-(Jhat**2+(nc+s.Rational(1,2))*Dv*X*X+mc*(v*W-X)**2+(Ac+Cc+s.Rational(1,2))*Dv*Y*Y))
JeR=R+u*v*X-Y-v*Z
coreR=(JeR*JeR+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z*Z)/2
small=nc*Du*Dv*X*X+Cc*Dv*(R-Y)**2+Ac*Du*Dv*Y*Y+coreR+mu*(v*S-a*X+a*u*v*Y-a*u*Z)**2+Jhat*Jhat
small=small.subs(R,Y+v*Z-u*v*X+dd*Jhat)
smallres=small.subs({dd:0,u:0,a:0,Ac:l/(2*h),Cc:1/(2*l)})
yz=(l+V)*Y*Y/(2*h)-v*Y*Z+V*(h+V)*Z*Z/(2*l)
ck('small_a_complete_five_root_remote_residue',smallres-(mu*V*S*S+(nc+s.Rational(1,2))*Dv*X*X+Jhat*Jhat+yz))
YZ=s.Matrix([[(l+V)/(2*h),-v/2],[-v/2,V*(h+V)/(2*l)]])
ck('small_a_YZ_positive_determinant',YZ.det()-V*V*(1+V)/(4*h*l))
# Three complete homogeneous endpoint selected-polynomial residues.
pvar,qvar,Pz,Qz,Dc=s.symbols('p q Pz Qz Dc')
sel=base+Dc*Je*Je
hu=s.cancel(pvar*pvar*sel.subs(u,1/pvar))
expected_u=nc*Dv*X*X+Cc*Dv*W*W+Ac*Dv*Y*Y+(Dc+s.Rational(1,2))*(W+v*X)**2+(v*Y-Z)**2/2
ck('complete_u_infinity_selected_residue',hu.subs(pvar,0)-expected_u)
hv=s.cancel(qvar*qvar*sel.subs(v,1/qvar))
expected_v=(nc+s.Rational(1,2))*Du*X*X+Cc*(u*W-Y)**2+(Ac+s.Rational(1,2))*Du*Y*Y+Dc*(u*X-Z)**2
ck('complete_v_infinity_selected_residue',hv.subs(qvar,0)-expected_v)
core2=((qvar*W+X-pvar*qvar*Y-Pz)**2+(1+pvar*pvar)*(Y-Qz)**2+(1+qvar*qvar)*(pvar*pvar*X*X+2*X*Pz-Pz*Pz))/2
ck('double_infinity_exact_half_core',s.cancel(pvar*pvar*qvar*qvar*core.subs({u:1/pvar,v:1/qvar},simultaneous=True))-core2.subs({Pz:pvar*Z,Qz:qvar*Z}))
sel2=nc*(1+pvar*pvar)*(1+qvar*qvar)*X*X+Cc*(1+qvar*qvar)*(W-pvar*Y)**2+Ac*(1+pvar*pvar)*(1+qvar*qvar)*Y*Y+Dc*(qvar*W+X-pvar*qvar*Y-Pz)**2+core2
expected2=(nc+s.Rational(1,2))*X*X+Cc*W*W+Ac*Y*Y+Dc*(X-Pz)**2+(Y-Qz)**2/2
ck('complete_double_infinity_selected_residue',sel2.subs({pvar:0,qvar:0})-expected2)
payload={'status':'PASS','count':len(checks),'checks':checks,'scope':'Weak-C2 R4 with e=1-r a positive bounded unit; full local Gram and both complete finite one-unit-angle charts. Three exact homogeneous infinity charts and inherited all-noncommuting theorem complete all tests.','imported':['complete WA3-WA8 identity','RD3-RD6 full D syzygy','R5.2-R5.4 full centered m gauge','WA10 separated strict Gram lift'],'seconds':round(time.monotonic()-started,3)}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
print(f'{len(checks)} focused checks passed in {payload["seconds"]} seconds',flush=True)
