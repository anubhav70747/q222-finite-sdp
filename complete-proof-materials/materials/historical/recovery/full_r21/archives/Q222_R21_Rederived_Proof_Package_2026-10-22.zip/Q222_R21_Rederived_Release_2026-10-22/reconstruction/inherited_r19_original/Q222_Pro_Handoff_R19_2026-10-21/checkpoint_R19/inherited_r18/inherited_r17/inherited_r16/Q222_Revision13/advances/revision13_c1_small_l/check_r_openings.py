"""New focused check: weighted IC1 extension through r and 1-r openings.

This deliberately does not execute any inherited checker.  Every denominator
is audited after theta=x*pi with pi bounded, not necessarily infinitesimal.
Run: PYTHONPATH=/tmp/q222-deps python check_r_openings.py
"""
import json
from pathlib import Path
import sympy as s

checks = {}
reports = {}
def zero(name, expr):
    q = s.factor(s.cancel(expr))
    if q != 0:
        raise AssertionError((name, q))
    checks[name] = True
    print("PASS", name, flush=True)

x,eta,zeta,r,pi,U,V = s.symbols("x eta zeta r pi U V")
c,a,D,m,al,be,h = s.symbols("c a D m alpha beta h")
theta=1-h;rho=eta+r;j0=eta+r-1
b=r*(1-r)/(eta*(j0+r))
H0=eta*(j0+r)/(2*r*(1-r)*j0)
gamma=rho/(2*eta*(j0+r))
B0=be+s.Rational(1,2)
Du=1+U;Dv=1+V;y=x*eta*zeta
# c=C(1-r), a=Ar.  Neither opening is inverted in these arrays.
Aw=m*V*(1+r*U)**2+c*(1-r)*Dv*U+a*r*Du*Dv*U+(D+s.Rational(1,2))*(1-r)**2*U+(al+s.Rational(1,2))*Du*r*r*U*V
bzero=m*theta+D*(1-r)+al*r+s.Rational(1,2)
bone=m*r*theta+h*(D+s.Rational(1,2))*(1-r)+(al+s.Rational(1,2))*r
kw=m*V*(1+r*U)-c*Dv+a*Du*Dv-(D+s.Rational(1,2))*(1-r)+(al+s.Rational(1,2))*Du*r*V
kz=-m*theta*U+(D+s.Rational(1,2))*(1+h*U)-(al+s.Rational(1,2))*Du
PY=s.expand(2*(kw/eta+kz))
PE=s.cancel(2*(Aw/U-m*V/U)/eta**2-2*(bzero+bone*U)/eta+b*PY)
PY0=PY.subs({U:0,V:0});PE0=PE.subs({U:0,V:0})
cF=(c*(1-r)+a*r+(al+s.Rational(1,2))*r*r+2*m*r)/eta**2
aUV=a*r/eta**2+h*h/2+2*D*h+be*theta**2-2*bone/eta
aUUV=h*h*(D+s.Rational(1,2))
aUVV=r*r*(m+al+s.Rational(1,2))/eta**2+a*r/eta**2
qV=(c*(1-r)+a*r+(D+s.Rational(1,2))*(1-r)**2)/eta**2+D-2*bzero/eta
qU=al+(m+B0)*theta**2
fA=aUV+aUUV*U+aUVV*V
fB=m*zeta/(eta*x)
fC=(al-cF*y*y+qU*U)/(eta*zeta*x*x)
fG=-(qV+2*cF*y)/x

hs=1-x*pi;ths=x*pi;K=1+x;R=1+x*r;T=1+x*hs
M=R-ths/zeta;J=T-(1-r)/eta;Es=1-x*eta*hs;Q=1-x*zeta*r
P4=T*Es+x*(1-r)*(hs+zeta)
Pa=R*hs*(1+y)+zeta*M*Es
Pd=1+2*x*hs+r*x*x*(hs+zeta)+x*zeta+eta*x*(K*zeta+x*hs*ths)
B5=K*(1+y)*rho-eta*J*Pd
Bbeta=K*x*rho*(hs+zeta)-ths*Pd
src={h:hs,c:K*rho*Es/(2*Pd),a:eta*P4/(2*Pd),D:B5/(2*eta*J*Pd),m:K*x*rho*hs*(1+y)/(2*M*zeta*Pd),al:x*x*zeta*rho*Pa/(2*Q*Pd),be:Bbeta/(2*ths*Pd)}
def actual(e):
    return s.factor(s.together(e.subs(src)))

lam=rho/(2*eta)
for name,expr,target in [
    ("cF_residue",cF,rho/(2*eta**2)),
    ("fA_residue",fA.subs({U:0,V:0}),lam),
    ("fB_residue",fB,lam),
    ("fC_residue",fC.subs(U,0),lam),
    ("fG_residue",fG,3*lam),
]:
    zero(name,actual(expr).subs(x,0)-target)

# Denominators may contain only eta, zeta, rho, j0, j0+r and harmless
# positive constants at x=0; in particular never r, 1-r, pi or x.
arrays={
    "c_difference_over_x":(c-rho/2)/x,
    "a_difference_over_x":(a-eta/2)/x,
    "D_difference_over_x":(D-1/(2*j0))/x,
    "m_over_x":m/x,"alpha_over_x2":al/x**2,
    "PY_zero_over_x":PY0/x,"PE_zero_over_x":PE0/x,
    "B0_theta_over_x":B0*theta/x,
    "B0_theta2_over_x2":B0*theta**2/x**2,
    "X_source_over_x":theta*(m+B0)/x,
    "qU_over_x2":qU/x**2,"qV_over_x":qV/x,
}
allowed_factors={
    s.Poly(e,eta,zeta,r).monic().as_expr()
    for e in (eta,zeta,rho,j0,j0+r)
}
for name,expr in arrays.items():
    val=actual(expr)
    den=s.factor(s.denom(val));den0=s.factor(den.subs(x,0))
    if den0==0 or den0.has(pi) or den0.subs(r,0)==0 or den0.subs(r,1)==0:
        raise AssertionError(("uncleared_opening",name,den0))
    for fac,exponent in s.factor_list(den0)[1]:
        monic=s.Poly(fac,eta,zeta,r).monic().as_expr()
        if monic not in allowed_factors:
            raise AssertionError(("unapproved_denominator_factor",name,fac))
    reports[name]=str(den0)
    checks["opening_free_"+name]=True
    print("PASS opening_free_"+name,flush=True)

# Exact hard-base normal coefficients and the opening-cancellation factors.
p,q,Ny=s.symbols("p q Ny")
Y=s.symbols("Y")
c0=rho/2;a0=eta/2;D0=1/(2*j0)
base=c0*(p-Y)**2/(1-r)+a0*Y*Y/r+D0*(p-Y-q)**2+(p-Y)**2/2-p*q
N=Y-r*p-b*(eta*p-q)
zero("weighted_hard_base",base-H0*N*N-gamma*(eta*p-q)**2)
zero("C_weight_over_H0",(c0/(1-r))/H0-r*rho*j0/(eta*(j0+r)))
zero("A_weight_over_H0",(a0/r)/H0-(1-r)*j0/(j0+r))
zero("D_weight_over_H0",D0/H0-r*(1-r)/(eta*(j0+r)))
zero("C_E_coefficient",(1-r)/eta-b-(1-r)*j0/(eta*(j0+r)))
zero("A_E_coefficient",r/eta+b-r*rho/(eta*(j0+r)))

# Beta and the half-core must be combined before normalizing X.
u,v,W,X,Z=s.symbols("u v W X Z")
Bt=s.symbols("Bt")
du=1+u*u;dv=1+v*v
jt=u*W+u*v*X-Y-v*Z
core=jt**2+du*(v*Y-Z)**2+dv*(X+u*Z)**2-du*dv*Z**2
noB=core.subs(X,-u*Z)
delta=s.expand((D*jt**2+be*dv*(X+u*Z)**2+core/2).subs(X,Bt-u*Z)-(D*jt.subs(X,-u*Z)**2+noB/2))
expected=2*(D+s.Rational(1,2))*u*v*Bt*(u*W-Y-du*v*Z)+(D+s.Rational(1,2))*u*u*v*v*Bt*Bt+B0*dv*Bt*Bt
zero("entire_beta_half_core_B_increment",delta-expected)

out={"status":"PASS","identities_and_denominator_checks":len(checks),"checks":checks,"opening_free_denominators_at_x_zero":reports,"scope":"New weighted IC1 extension: eta,zeta,j0 positive bounded units; x infinitesimal; arbitrary 0<r<1; theta=x*pi with pi bounded; beta>=0. Scalar/contact identities not changed; new source denominators and hard opening allocations checked here. Analytical proof supplies full parent and all tests."}
Path(__file__).with_suffix(".json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"status":"PASS","checks":len(checks)},indent=2))
