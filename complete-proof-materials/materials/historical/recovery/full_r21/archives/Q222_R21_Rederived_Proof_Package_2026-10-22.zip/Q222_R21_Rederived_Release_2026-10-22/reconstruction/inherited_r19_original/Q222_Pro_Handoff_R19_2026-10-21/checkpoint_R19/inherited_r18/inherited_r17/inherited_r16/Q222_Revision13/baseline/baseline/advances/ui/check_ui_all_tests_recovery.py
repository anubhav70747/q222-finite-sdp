import json
from pathlib import Path
import sympy as s
u,v,k,p,q,W,X,Y,Z=s.symbols('u v k p q W X Y Z', real=True)
n,m,al,H,Aw,mu,mc,ac=s.symbols('n m al H Aw mu mc ac', real=True)
Du,Dv=1+u*u,1+v*v
M=v*W-X+u*v*Y-u*Z; J=u*W+u*v*X-Y-v*Z
core=2*(J**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)
# Positive caps C=D=mu/k^2, m=mc, alpha=ac, A=Aw*k^2; n retained whole.
F=4*mc*M**2+4*mu/k**2*Dv*(u*W-Y)**2+4*Aw*k**2*Du*Dv*Y**2+4*mu/k**2*J**2+4*ac*Du*(v*Y-Z)**2+core
checks={}
def chk(name,lhs,rhs=0):
    val=s.factor(lhs-rhs)
    checks[name]={'pass':val==0,'residual':str(val)}
def residue(name,expr,small,target):
    expr=s.cancel(expr)
    for var in small:
        expr=s.cancel(expr.subs(var,0))
    chk(name,expr,target)
e,f,R,V,K,P,S,T=s.symbols('e f R V K P S T',real=True)
# Endpoint (0,0), use Y=uW-k e, with vW=V, kuW=K, v(uX-Z)/k=R.
F00=(4*mu*Dv*e**2+4*mu*(e+R)**2
 +4*mc*(Du*V-X-u*Z-u*v*k*e)**2
 +4*ac*Du*(u*V-Z-v*k*e)**2+4*Aw*Du*Dv*(K-k*k*e)**2
 +2*k*k*(e+R)**2+2*Du*(u*V-Z-v*k*e)**2
 +2*Dv*(X+u*Z)**2-2*Du*Dv*Z**2)
chk('00_exact_frame',F00.subs({e:(u*W-Y)/k,R:v*(u*X-Z)/k,V:v*W,K:k*u*W},simultaneous=True),F)
residue('00_strict_residue',F00,[u,v,k],4*mu*(e**2+(e+R)**2)+4*mc*(V-X)**2+4*ac*Z**2+4*Aw*K**2+2*X**2)
# Finite bounded u, finite nonzero v. e=(uW-Y)/k, f=J/k.
subfin={Y:u*W-k*e,Z:u*X+k*(e-f)/v}
Ffin=F.subs(subfin,simultaneous=True)
residue('finite_v_unit_strict_residue',Ffin,[k],4*mu*Dv*e**2+4*mu*f**2+(4*mc*Du**2+(4*ac+2)*Du*u*u)*(v*W-X)**2+2*Dv*Du*X**2)
# Bounded u and v=infinity; q=1/v.
Fq=s.cancel(q*q*F.subs(v,1/q))
subq={Y:u*W-k*e,Z:u*X+k*q*e-k*f}
Fqsub=Fq.subs(subq,simultaneous=True)
residue('v_infinity_strict_residue',Fqsub,[q,k],4*mu*e**2+4*mu*f**2+(4*mc*Du**2+(4*ac+2)*Du*u*u)*W**2+2*Du*X**2)
# u=infinity, v finite unit. Ramp/k=e,J/k=f, P=vY-Z, K=kY,S=pZ.
Dp=1+p*p
Fpu=(4*mu*Dv*e**2+4*mu*f**2+4*mc*(Dp*P-p*k*(f-e)/v+p*v*k*e)**2+4*ac*Dp*P**2+4*Aw*Dp*Dv*K**2
+2*k*k*f**2+2*Dp*P**2+2*Dv*p*p*k*k*(f-e)**2/v**2-4*Dp*Dv*p*k*(f-e)*P/v+4*Dp*Dv*p*(f-e)*K+2*Dp*Dv*S**2)
backpu={e:(W-p*Y)/k,f:(W+v*X-p*Y-p*v*Z)/k,P:v*Y-Z,K:k*Y,S:p*Z}
Fp=s.cancel(p*p*F.subs(u,1/p))
chk('u_infinity_v_unit_exact_frame',Fpu.subs(backpu,simultaneous=True),Fp)
residue('u_infinity_v_unit_strict_residue',Fpu,[p,k],4*mu*Dv*e**2+4*mu*f**2+(4*mc+4*ac+2)*P**2+4*Aw*Dv*K**2+2*Dv*S**2)
# Both infinity.
Dq=1+q*q
Fpq=(4*mu*Dq*e**2+4*mu*f**2+4*mc*(Dp*P+p*k*Dq*e-p*q*k*f)**2+4*ac*Dp*P**2+4*Aw*Dp*Dq*K**2
+2*k*k*f**2+2*Dp*P**2+2*Dq*p*p*k*k*(f-q*e)**2+4*Dq*Dp*k*(f-q*e)*S+2*Dq*Dp*S**2)
backpq={e:(W-p*Y)/k,f:(q*W+X-p*q*Y-p*Z)/k,P:Y-q*Z,K:k*Y,S:p*Z}
chk('double_infinity_exact_frame',Fpq.subs(backpq,simultaneous=True),s.cancel(p*p*q*q*F.subs({u:1/p,v:1/q},simultaneous=True)))
residue('double_infinity_strict_residue',Fpq,[p,q,k],4*mu*(e**2+f**2)+(4*mc+4*ac+2)*P**2+4*Aw*K**2+2*S**2)
# Separate sign symmetries.
chk('u_sign_gauge',F.subs({u:-u,W:-W,X:-X},simultaneous=True),F)
chk('v_sign_gauge',F.subs({v:-v,W:-W,Y:-Y},simultaneous=True),F)
# General ordinary-angle leading determinant.
xi,zz,Vv=s.symbols('xi zz Vv',real=True)
ff=4*n*Du*xi**2+4*m*(Vv*Du*W-xi-u*zz)**2+4*H*Vv**2*(u*xi-zz)**2+4*Aw*Du*u*u*W**2+(4*al+2)*Du*(Vv*u*W-zz)**2+2*(xi+u*zz)**2-2*Du*zz**2
mat=s.hessian(ff,[xi,zz,W])/2
NN=2*n+1;TT=2*m+2*al+1
Laur=4*al*m*NN/u**2+4*Aw*H*TT*u**2+4*Aw*al*(2*m+NN)/Vv**2+4*Aw*n*TT*u**2/Vv**2+2*H*NN*TT*Vv**2+4*H*m*NN*Vv**2/u**2+4*Aw*H*(2*m+NN)-NN*TT
chk('leading_determinant_laurent',mat.det(method='domain-ge'),8*Du**2*u*u*Vv**2*Laur)
Pmat=s.Matrix([[4*n*Du+4*m+2,(4*m+2)*u],[(4*m+2)*u,(4*m+2)*u*u+4*al*Du]])
bvec=s.Matrix([-4*m*Du,-Du*u*(4*m+4*al+2)]);ell=s.Matrix([u,-1]);c0=4*Aw*Du*u*u;c2=4*m*Du**2+(4*al+2)*Du*u*u
chk('leading_block_representation',ff,((s.Matrix([xi,zz]).T*(Pmat+4*H*Vv**2*ell*ell.T)*s.Matrix([xi,zz]))[0]+2*Vv*W*(bvec.T*s.Matrix([xi,zz]))[0]+(c0+c2*Vv**2)*W**2))
# Leading source substitutions and pole-free quantities.
z,b,r=s.symbols('z b r',real=True)
Ac=1+z*r;g=(1+z)*b-1+r
Delta=1+(1+z)*b+z*(1+z)*b*b+2*z*(1+z)*b*r+z*z*r*r+2*z*r
ns=((b+r)*Ac**2-r*Delta)/(2*r*Delta)
ms=(1-r)*Ac**2/(2*g*Delta)
als=z*z*(1+z)*b*(b+r)**2/(2*(1-z*b)*Delta)
Hs=z*(1+z)*(b+r)*b/(2*Delta)
Aws=Ac**2*(b+r)/(2*z*b*Delta)
ins=r*Delta/((b+r)*Ac**2)
tms=(1-r)*(1-z*b)/(2*b*(b+r)*(z+1))
tams=z*z*(b+r)*(1-r)/(4*Delta)
qas=b*z*z*((z+1)*b+(z+2)*r-1)/(2*Ac**2)
ias=2*(1-z*b)*Delta/(z*z*(z+1)*b*(b+r)**2)
source={n:ns,m:ms,al:als,H:Hs,Aw:Aws}
for name,expr,rhs in [('inverse_N',1/NN,ins),('m_over_T',m/TT,tms),('alpha_m_over_T',al*m/TT,tams),('q_alpha',al*(2*m+NN)/(NN*TT),qas),('inverse_alpha',1/al,ias)]:
    chk(name,expr.subs(source),rhs)
Junit=al*(2*m+NN)/(NN*TT)+u*u*(1-1/NN)/2
inN=1/NN;tm=m/TT;tam=al*m/TT;qa=al*(2*m+NN)/(NN*TT);ia=1/al
chk('P_determinant_normalized',Pmat.det()/(NN*TT),8*Du*Junit)
Pinv=Pmat.inv()
for name,expr,rhs in [('d_polefree',(ell.T*Pinv*ell)[0],(u*u*inN+qa*ia)/(4*Junit)),('e_polefree',(ell.T*Pinv*bvec)[0],u*Du/(2*Junit)),('h_polefree',c2-(bvec.T*Pinv*bvec)[0],Du*(4*tam-u*u)/Junit),('minimizer_first',(Pinv*bvec)[0],inN*(u*u-4*tam)/(2*Junit)),('minimizer_second',(Pinv*bvec)[1],-u*(4*tam*inN+(1-inN)*u*u+1)/(2*Junit))]:
    chk(name,expr,rhs)
chk('strict_leading_coefficient', (ell.T*Pinv*ell)[0]*(c2-(bvec.T*Pinv*bvec)[0])+(ell.T*Pinv*bvec)[0]**2, Du*(u*u+2*tm)/(2*Junit))
U,T=s.symbols('U T',positive=True)
Lnorm=4*tams/U+4*Aws*Hs*ins*U+4*Aws*qas/T+2*Aws*(1-ins)*U/T+2*Hs*T+4*Hs*tms*T/U+4*Aws*Hs*qas*ias-1
chk('laurent_contact_value',Lnorm.subs({U:z,T:1}))
chk('laurent_contact_U_derivative',s.diff(Lnorm,U).subs({U:z,T:1}))
chk('laurent_contact_T_derivative',s.diff(Lnorm,T).subs({U:z,T:1}))
# Real interior density, rather than substituting actual b in a leading denominator.
ss=s.symbols('ss',real=True)
ffn=1+r*(z-1)-b*r*z*(z+1)-r*r*z*(z+2)
bs=ss*b+(1-ss)/(1+z);rs=ss*r
chk('leading_n_numerator',2*r*ns*Delta,b*ffn)
chk('interior_density_homotopy',ffn.subs({b:bs,r:rs},simultaneous=True),(1-ss)*(1+ss-ss*r)+ss**2*ffn)
chk('interior_density_g_gap',(1+z)*bs-1+rs,ss*((1+z)*b-1+r))
# Rank-one allocation exact zero on separated roots.
lam=s.symbols('lam',real=True);Qvec=s.Matrix([X,Z]);V0,K0,R0=s.symbols('V0 K0 R0',real=True)
lead=(Qvec.T*Pmat*Qvec)[0]+2*V0*(bvec.T*Qvec)[0]+c2*V0**2+4*H*R0**2+c0*K0**2
allocated=(Qvec.T*Pmat*Qvec)[0]+2*V0*((bvec-lam*ell).T*Qvec)[0]+c2*V0**2+4*H*R0**2+2*lam*R0*K0+c0*K0**2
chk('rank_one_allocation_identity',allocated-lead,2*lam*(R0*K0-(u*X-Z)*V0))
report={'scope':'Reconstructed strong C2 UI all-tests algebra; analytic boundedness and positivity are in the accompanying theorem.','checks':checks,'passed':sum(x['pass'] for x in checks.values()),'total':len(checks),'all_pass':all(x['pass'] for x in checks.values())}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
if not report['all_pass']:raise SystemExit(1)
