# Q222 revision 13

Start with CHECKLIST.md. The global existence proof is **unfinished**, with five newly proved all-tests source domains and a smaller explicit frontier.

ADMISSIONS_REVISION13.json records theorem evidence, dependencies and gates. The full manuscript retains all recovered mathematical sources and adds revision13. Q222_Revision13_Results.pdf presents the principal new theorem and exact frontier.

This is a derivative of a truncated handoff. See provenance/RECOVERY_REPORT.json; original revision12 root files are under provenance/revision12_root/.

Run python3 verify.py --integrity-only and python3 verify.py --revision13-only. SymPy 1.14.0 was used for the focused new computations; replay does not rewrite receipts.
