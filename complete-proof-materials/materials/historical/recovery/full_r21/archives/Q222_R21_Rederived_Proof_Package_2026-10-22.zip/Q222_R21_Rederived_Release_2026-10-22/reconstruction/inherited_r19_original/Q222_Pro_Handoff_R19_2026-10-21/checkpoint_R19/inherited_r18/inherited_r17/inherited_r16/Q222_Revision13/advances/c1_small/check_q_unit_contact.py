"""Six actual-source contact identities, cleared by printed pure-field factors."""
import sympy as s,time,json
start=time.time();checks=[]
def ck(name,value):
 ok=s.expand(value)==0
 checks.append({'name':name,'passed':ok});print(('PASS ' if ok else 'FAIL ')+name,flush=True)
 if not ok:raise AssertionError(name)
bb,z,q,r,t,U,V=s.symbols('bb z q r t U V'); x=bb*q;h=1-t*z;K=1+x;R=1+x*r;T=1+x*h;J=T-bb*(1-r);E=1-q*h;Q=1-x*z*r;G=h+z
Pd=1+2*x*h+r*x*x*G+x*z+q*(K*z+x*h*t*z);P4=T*E+x*(1-r)*G;Pa=R*h*(1+q*z)+z*(R-t)*E
B5=s.expand(K*(1+q*z)*(bb*r+1)-J*Pd); Nal=q*q*(1+bb*r)*Pa/2;Du=1+U;Dv=1+V;S=1-r+t*V
# U=u²,V=v²; each N_i below is Den*f_i, and Ne=Den*f_Gamma.
# B5 here is bb times NC3's B5; Nal=Q*Pd*alpha_b.
Den=bb*Pd*Q*q*q*Du
Na=2*bb*Q*q*Du*Dv*K*(1+bb*r)*E*(1-r)+2*bb*Q*q*Dv*P4*K*K*r+2*bb*bb*Pd*Q*q*(Du*S*S+V*K*K*r*r)+4*bb**3*q*Nal*z*V*K*K*r*r-4*bb*Q*q*Du*B5*S-2*Q*q*Du*B5*J
Nb=2*bb*Q*q*q*Du*K*(1+bb*r)*(h*(1+q*z)*(R-t)+G*t*Dv)
Nc=2*Du*Den;Nd=4*bb*Nal*Du*Du
Ne=4*bb*Pd*Q*q*Du*(Du*(R+t*V)-U*K*r)+8*bb*bb*q*Du*Nal*z*K*r-4*Q*q*Du*Du*B5
P=Na+Nb+Nc+Nd-Ne
contact={U:bb*q,V:q*z}
ck('actual-source contact scalar value',P.subs(contact))
ck('actual-source inactive state jet',(2*Na+2*Nb-Ne).subs(contact))
# The P/(1+U) denominator-derivative term vanishes by the first check.
ck('actual-source u jet',(2*U*s.diff(P,U)+2*Na+2*Nc-Ne).subs(contact))
ck('actual-source v jet',(2*V*s.diff(P,V)+2*Nb+2*Nc-Ne).subs(contact))
# Multiply L_N/H by R*Pd and L_y*sqrt(s)/H by Pd*R*Du*Q.
NLN=4*q*K*(1+bb*r)*(G*Dv-h*(1+q*z))+4*bb*q*z*Pd*S-4*q*z*B5-4*Du*q*z*Pd
NLY=4*Dv*K*(P4-(1+bb*r)*E)*Du*Q-4*Dv*P4*K*U*Q+4*B5*Du*Q+8*Nal*z*bb*bb*V*K*r-4*bb*S*Pd*Du*Q+4*bb*V*K*r*Pd*Q+4*bb*q*Pd*Du*Q-8*Nal*bb*z*Du
ck('actual-source first N normal',NLN.subs(contact))
ck('actual-source first harmonic normal',NLY.subs(contact))
open(__file__.replace('.py','.json'),'w').write(json.dumps({'passed':all(c['passed'] for c in checks),'checks':checks,'elapsed_seconds':time.time()-start},indent=2))
print(len(checks),'contact checks passed')
