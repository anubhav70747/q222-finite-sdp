"""Focused new identities for SP1--SP14; no numerical proof or old replay.

The exact generic JR5/JB1 full-parent identity and original contact jets
are imported dependencies. We check its complete transformation, including
all hard and first normals, rather than only a scalar restriction.
"""
import json
import time
from pathlib import Path
import sympy as s

started = time.monotonic()
checks = []

def check(name, expression):
    numerator = s.fraction(s.cancel(expression))[0]
    passed = s.expand(numerator) == 0
    checks.append({"name": name, "pass": bool(passed)})
    print(("PASS " if passed else "FAIL ") + name, flush=True)
    if not passed:
        raise AssertionError((name, s.factor(numerator)))

x,z,sg,h,b,t,xi = s.symbols("x z sigma h b t xi")
u,w,q,W,X,Y,Z = s.symbols("u w q W X Y Z")
Nx,Ny,Gam,R,At,V,Pb,Xe = s.symbols("Nx Ny Gamma R Atheta V Pbeta Xe")
m,C,D,bt,p,l,mu,ac,lc,kappa = s.symbols(
    "m C D btheta p l mu astar lstar kappa")
Q=1-b; th=1-h; abeta=bt*th; g=h-Q
Du=1+t; Dw=1+xi; de=t-x; delta=xi-sg*z; H=h/sg; e=x*h/sg

# Every coefficient of the imported generic full-parent core is retained.
Ax=-4*h*(2*D+1)/sg
A=4*mu+2*h*h*(2*D+1)*t/sg
Bx=8*mu*x
Ay=8*(p-l)+4*z*((1+2*m)*g+2*D*h+2*p*sg)
S=2*(h*h*(2*D+1)*(t+x)+4*D*h-2*b*p*sg*sg*z+2*abeta+h*h)/sg**2
Z0=(4*D+2*t*(4*D*h+2*abeta+h*h)+2*t*t*h*h*(2*D+1))/sg**2
Zx=-4*u*(2*D-2*bt+h+t*h*(2*D+1))/sg
sigB=2*h*h*(2*D+1)*(t+x)/sg+8*D*h*(1-sg)/sg+8*(p*b+l*Q)
sigB+=2*h*h/sg-4*h+4*abeta/sg
sigB+=4*z*(4*D*b*h+3*p*b*sg+(1+2*m)*g*g+2*abeta)
k0=2*b*((2*C+1)*b+4*D+4*p*sg+2*(2*C+2*D+1)*sg*(b*z-1))
k1=2*(1+2*m)*g*g+8*D*h*b+8*p*b*sg+4*abeta
k2=2*b*b*(2*C+2*D+1)
Kr=k0+k1*t+k2*xi
Rx=-4*(2*D*b+(1+2*m)*g-2*bt)
Ry=4*(t*(2*D*h+2*p*sg+(1+2*m)*g)+b*(2*C+2*D+1)*(xi+sg*z)
      +(2*C+1)*(b-sg)+2*D*(1-sg)+2*p*sg)
Er=2*(C+D)*(b*z-1)+2*p+b*z-1
Rg=-4*(Er+2*p*t)
cG=4*Du*(p*b*Dw+l*Q)
cN=8*Du*(p*Dw-l)
Hx=2*(1+t+xi)+4*D*t+4*m*xi
Hy=4*Du*(ac*Dw+lc)+4*m*t*z+4*C*z*Dw+(4*D+2)*xi*z+2*Du*z
cross=-4*u*q*w*(2*m+2*D+1)*Nx*Ny+q*w*Rg*Ny*Gam+q*w*b*Rg*R*Gam
cross+=u*q*w*Rx*Nx*R+(cN+z*Ry)*Ny*R+q*w*Bx*Nx*At+u*Ay*Ny*At
G=Hx*Nx**2+Hy*Ny**2+Z0*Gam**2+(cG+z*Kr)*R**2+A*At**2+cross
G+=Zx*Nx*Gam+u*Ax*Nx*V+u*sigB*At*R+S*Gam*V

rootvals={Nx:X+u*h*Z, Ny:(Y-b*w*Z)/q,
          Gam:sg*Z-u*w*W,R:w*Z/q-u*q*W,
          At:q*(u*u-x)*W,V:u*w*(u*u-x)*W,
          Pb:u*Z-x*w*W/sg,Xe:X+x*h*w*W/sg}
def realroots(expression):
    return expression.subs({t:u*u,xi:w*w,z:q*q}).subs(rootvals)

check("SP1 beta-contact root without testing inverse",realroots(t*Gam+V-sg*u*Pb))
check("SP1 exact complete hard-normal root",realroots(Nx-h*Pb-Xe))
check("SP2 h-squared packet conductor",realroots(
    t*t*Gam**2+(t+x)*Gam*V+sg*t*At**2-(t*Gam+V)**2+u*sg*de*At*R))

nu=(2*D-2*bt+h)/sg
lam=(8*D*h+4*abeta+2*h*h)/sg-4*b*p*sg*z
lam0=4*D*(1+h)/sg-2*th*nu-4*b*p*sg*z
chi=8*(p*b+l*Q)-4*h+4*e*h*(2*D+1)-8*D*h
chi+=4*z*(4*D*b*h+4*p*b*sg+(1+2*m)*g*g+2*abeta)
check("SP3 exact isolation of the sole H coefficient",lam-2*H-lam0)
check("SP4 full radial quotient pole cancellation",sigB-2*h*h*(2*D+1)*de/sg-lam-chi)

sp6=2*(2*D+1)*(u*Xe)**2+(2*(1+xi)+4*m*xi)*Nx**2+Hy*Ny**2
sp6+=(4*D/sg**2+4*b*p*z*t)*Gam**2+(cG+z*Kr)*R**2-4*u*nu*Nx*Gam+cross
sp6+=4*kappa*H*At**2+lam*u*(Gam*Pb+At*R)+chi*u*At*R
check("SP6 ENTIRE generic parent, both hard and every first normal",realroots(G-sp6).subs(mu,kappa*H))

check("SP7 exact signed scalar contact product",realroots(
    At**2+u*Gam*Pb+u*At*R-sg*Pb**2-(x/sg)*de*delta*W**2))
alpha=2*H*(2*kappa-1); rho=2*x*h/sg**2
bounded=(2*(1+xi)+4*m*xi)*Nx**2+Hy*Ny**2
bounded+=(4*D/sg**2+4*b*p*z*t)*Gam**2+(cG+z*Kr)*R**2-4*u*nu*Nx*Gam+cross
bounded+=alpha*At**2+lam0*u*(Gam*Pb+At*R)+chi*u*At*R
sp8=2*(2*D+1)*(u*Xe)**2+2*h*Pb**2+bounded+rho*de*delta*W**2
check("SP8 ENTIRE parent after both positive-square extractions",realroots(G-sp8).subs(mu,kappa*H))

# Pure-source cancellations: no testing variable enters these checks.
P=sg+1+x+sg*z*(1+b*x+2*x*h)+sg*b*x*x*h*z*z+x*x*h*th*z
J=1+x*h-sg*(1-b*z)
M=1+x*b*z-x*z*th
B=P+x*z*(J-sg)
H0=1+z-b*z
bt_exact=(h*B-sg*H0)/(2*P)
nu_bounded=2*D/sg+(H0-e*z*(J-sg))/P
check("SP9 cancellation of the unbounded hard normal",nu.subs(bt,bt_exact)-nu_bounded)
Nk=(1+x)*(1+sg*b*z)*(1+sg*z)-M*P
Fx=s.cancel(Nk.subs(sg,0)/x)
Fs=s.cancel((Nk-Nk.subs(sg,0))/sg)
assert s.Poly(Fx,x,z,h,b,sg).is_zero is not None
assert s.Poly(Fs,x,z,h,b,sg).is_zero is not None
check("SP10 exact polynomial sigma and x divisibility",Nk-sg*Fs-x*Fx)
kappa_exact=(1+x)*(1+sg*b*z)*(1+sg*z)/(2*M*P)
check("SP10 bounded normalization of alpha_kappa",alpha.subs(kappa,kappa_exact)-2*(h*Fs+e*Fx)/(M*P))
check("SP10 bounded remainder has no automatic angular positivity",alpha.subs(kappa,kappa_exact).subs(z,0)+2*h/(1+x+sg))
HH,b0sq=s.symbols("Hcal b0_squared")
h_sphere=sg*H0/B+sg**2*HH*b0sq/(x*B)
check("SP11 bounded rho source sphere formula",rho.subs(h,h_sphere)-2*x*H0/(sg*B)-2*HH*b0sq/B)
# In the preceding substitution B depends on h: it is an identity with
# B,H0 treated as fixed source quantities before the h substitution.

Bdelta=(w*w-sg*q*q)*W/q
check("SP12 first exact scalar carrier relation",realroots(u*q*R+q*At-w*Pb)-(x*q/sg)*Bdelta)
check("SP12 second exact scalar carrier relation",realroots(sg*q*R-w*Gam)-u*(w*w-sg*q*q)*W)
check("SP8 exact D-zero extra null direction",realroots(sp8).subs({u:0,w:0,W:0,X:0,Y:0})-4*D*Z**2)

# New comparison-model conductor: nonnegative root parametrization clears
# only pure-source radicals and verifies the sign-free identity UVK.
U,Vv,Cc,Tt,ee=s.symbols("U Vabs sqrt2c sqrttau sqrtepsilon", nonnegative=True)
c=Cc**2/2; tau=Tt**2; eps=ee**2
xs=c*eps; sig=tau*eps
A1=Cc*U**2*Vv**2
A2=s.sqrt(2)*Tt**2*ee*U
A3=Tt*Cc**2*ee**2*Vv/s.sqrt(2)
Gc=Tt*Cc*ee*U*Vv
d1,d2,d3=A1-Gc,A2-Gc,A3-Gc
K=sig-U**2*Vv**2
right=-(U*Vv/Cc)*d1+(U*Vv/Cc)*d2+(s.sqrt(2)*U*Tt/Cc**2)*d3
check("SP13 new circuit conductor without E sqrt(epsilon)",U*Vv*K-right)
ta=s.symbols("tau")
Omega=(u*u-x)*Z
model=R**2+(1+2*ta)*At**2+Gam**2+2*ta*Omega*Gam
check("SP14 entire comparison model at literal Z zero",realroots(model).subs(Z,0)
      -(u*q*W)**2-(u*w*W)**2-(1+2*ta)*(q*(u*u-x)*W)**2)

result={
    "status":"New exact full-parent pole reduction plus enlarged JU8 model chart; no whole source branch admitted",
    "scope_full_parent":"C14.1b: every remaining coefficient is bounded, but signed scalar contact product is unallocated; algebraic identity also valid on common BE domain",
    "scope_model":"C14.1a JU8 on Z nonzero and uW/Z bounded in pure testing field; also Z=0; full JU3 correction still unallocated",
    "imported_dependencies":["complete generic JR5/JB1 parent and original source contact jets", "BE source formulas and source sphere", "R14.1--R14.2 circuit identity and bounded positive-Gram criterion"],
    "new_admissions":[],
    "checks":checks,"passed":len(checks),"seconds":round(time.monotonic()-started,3)
}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(f'{len(checks)} focused exact checks passed in {result["seconds"]} seconds',flush=True)
