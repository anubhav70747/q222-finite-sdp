#!/usr/bin/env python3
"""Exact, narrowly targeted obstruction to JG10 and JG13 on a physical source.

No tensor admission is asserted. The determinant dictionary and global
physicality argument are stated in weak_scalar_obstruction.tex.
"""
import json
from pathlib import Path
import sympy as s

e,h,c=s.symbols('e h c', positive=True)
half=s.Rational(1,2)
z=e/2; y=2*e; H=e*h; L=e*(1-h); B=e; r=s.Rational(9,10)
ac=1+z*r; Sc=ac+L; T=B+z*r
G=B+z*(H+r-1); j=ac-L/y
Delta=z+(1+z)*B+(1+z)*B**2+2*z*(1+z)*B*r+z**3*r**2+2*z**2*r+y*((1+z)*B+z+z**2*r*(2-r))
Ms=(1+z)*T*(H+y)-z*(1+y)*(1-r)*L
n=s.factor((T*ac*Sc-r*Delta)/(2*r*Delta))
m=s.factor(z*z*(1+y)*(1-r)*ac*Sc/(2*G*Delta))
C=s.factor(ac*Ms/(2*L*Delta))
A=s.factor(y*ac*T*Sc/(2*H*Delta))
D=s.factor((1+z)*T*(B-z*y*r)*Sc/(2*y*j*Delta))
al=s.factor(T*Ms/(2*(1-H)*Delta))
w01=m*B**2/z
w10=((C+D+half)*L**2+A*H**2)/y
w11=2*m*B*H+C*L**2+(A+al+half)*H**2
w20=A*z*H**2/y
w21=z*H**2*(m+A+al+half)
z00=al; z01=D*y
z10=z*(n*r*r+(m+half)*(1-r)**2+al)
z11=z*y*((n+half)*r*r+2*D*r)
z20=n*r*r*z*z
z21=z*z*y*(n+D+half)*r*r
A1=(w10+z01-z21)/2
K1=s.factor(w10*z01-A1*A1)
ds=s.factor((w11-z00-z20)/2)
R=s.factor(w01*w21); S=s.factor(z00*z20)
Tgap=s.factor(ds*ds-R-S)
checks={}
def zero(name,expr):
    assert s.cancel(expr)==0,name
    checks[name]=True

def corner(expr):
    """Check regularity at the joint corner, then evaluate exactly.

    This is NOT an iterated limit and imposes no comparison between e and h.
    """
    num,den=s.fraction(s.cancel(expr))
    den0=den.subs({e:0,h:0})
    assert den0!=0,('nonregular corner',expr)
    return s.factor(num.subs({e:0,h:0})/den0)

expected={
 'n':s.Rational(1,27),'m':s.Rational(1,114),
 'C':s.Rational(19,20),'D':s.Rational(29,60),
 'hA':s.Rational(29,30),'alpha/e2':s.Rational(551,400),
 'deltaTot/h':s.Rational(30,29),
 'G/e':s.Rational(19,20),'j':half,'Delta/e':s.Rational(3,2),
 'Ms/e2':s.Rational(57,20),'Bminuszyr/e':s.Integer(1),
 'K1/e4':-s.Rational(841,32000),
 'dstar/e2':-s.Rational(87,400),'R/e4':s.Integer(0),
 'S/e4':s.Rational(1653,160000),
 'Tgap/e4':s.Rational(1479,40000),
 'radical_gap/e8':s.Rational(2187441,1600000000),
}
expressions={
 'n':n,'m':m,'C':C,'D':D,'hA':h*A,'alpha/e2':al/e**2,
 'deltaTot/h':1/(h*(1+n+m+C+A+D+al)),
 'G/e':G/e,'j':j,'Delta/e':Delta/e,'Ms/e2':Ms/e**2,
 'Bminuszyr/e':(B-z*y*r)/e,'K1/e4':K1/e**4,
 'dstar/e2':ds/e**2,'R/e4':R/e**4,'S/e4':S/e**4,
 'Tgap/e4':Tgap/e**4,'radical_gap/e8':(Tgap*Tgap-4*R*S)/e**8,
}
limits={}
for name,expr in expressions.items():
    value=corner(expr)
    assert value==expected[name],(name,value,expected[name])
    limits[name]=str(value)
checks['joint_corner_values_and_regular_denominators']=True

# Full original parent, not a graph-only or contact-Hessian test.
u,v,W,X,Y,Z=s.symbols('u v W X Y Z')
nn,mm,CC,AA,DD,aa=s.symbols('nn mm CC AA DD aa')
Du=1+u*u; Dv=1+v*v
Rm=v*W-X+u*v*Y-u*Z
RD=u*W+u*v*X-Y-v*Z
F=4*nn*Du*Dv*X**2+4*mm*Rm**2+4*CC*Dv*(u*W-Y)**2+4*AA*Du*Dv*Y**2+4*DD*RD**2+4*aa*Du*(v*Y-Z)**2+2*(RD**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)
zero('negative_u_exact_state_conjugation',F.xreplace({u:-u,Y:-Y,Z:-Z})-F)
zero('negative_v_exact_state_conjugation',F.xreplace({v:-v,X:-X,Z:-Z})-F)
assert s.degree(F,u)==2 and s.degree(F,v)==2
checks['full_parent_bidegree_2_2_for_projective_endpoints']=True
point={u:c,v:2*c,W:1,X:-r*c,Y:h*c,Z:1}
wt=dict(zip([nn,mm,CC,AA,DD,aa],[s.factor(q.subs(e,2*c*c)) for q in [n,m,C,A,D,al]]))
zero('full_original_parent_value',F.subs(point).subs(wt))
for var in [u,v,W,X,Y,Z]:
    zero('full_original_derivative_'+str(var),s.diff(F,var).subs(point).subs(wt))

# Verify the six positive Laurent masses obey the required exponent balance.
# The determinant dictionary is inherited, not numerically inferred here.
t1=1+2*(n+D); t2=1+2*(al+m+A); t3=1+2*(C+D)
t4=1+2*(al+m); t5=1+2*n; t6=1+2*(al+C+A)
t7=1+2*(n+m); t8=1+2*(C+A+D)
q01=4*al*m*t5*t8; q02=4*m*D*t5*t6
q10=4*al*A*t7*t3; q12=4*C*D*t5*t2
q20=4*n*A*t3*t4; q21=4*C*A*t1*t4
zero('Laurent_first_exponent_balance',-q01/z-q02*y/z+q20*z/y+q21*z)
zero('Laurent_second_exponent_balance',q02*y/z-q10/y+q12*y-q20*z/y)

# Finite six-exponent physicality certificate, valid in a real closed field.
xv,yv=s.symbols('xv yv',positive=True)
ma,mb,mc,md,me,mf,tau=s.symbols('ma mb mc md me mf tau')
la=1/xv; lb=yv/xv; lc=1/yv; ld=yv; le=xv/yv; lf=xv
balanced=ma*(la-1)+mb*(lb-1)+mc*(lc-1)+md*(ld-1)+me*(le-1)+mf*(lf-1)
plus=mf*(la+lf-2)+mb*(lb+le-2)+mc*(lc+ld-2)+tau*(la+ld+le-3)
minus=ma*(la+lf-2)+me*(lb+le-2)+md*(lc+ld-2)+tau*(lb+lc+lf-3)
zero('six_exponent_certificate_positive_balance',balanced.subs({ma:mf+tau,me:mb+tau,md:mc+tau},simultaneous=True)-plus)
zero('six_exponent_certificate_negative_balance',balanced.subs({mf:ma+tau,mb:me+tau,mc:md+tau},simultaneous=True)-minus)
zero('positive_triangle_product_one',la*ld*le-1)
zero('negative_triangle_product_one',lb*lc*lf-1)

# Polynomial SOS support reduction used in the strengthened corollary.
bb,ss,qa,qb,qc,qd=s.symbols('bb ss qa qb qc qd')
root=qa*bb*ss+qb*bb+qc*ss+qd
zero('global_polynomial_SOS_parity_block_reduction',
     (root**2+root.xreplace({bb:-bb,ss:-ss})**2)/2
     -(qa*bb*ss+qd)**2-(qb*bb+qc*ss)**2)

# Exact finite-curve factorization retained for a readily reviewable check.
Kcurve=-841*e**4*(9*e+20)*(20*e**2-29*e-20)**2*(4275*e**4+12560*e**3-5809*e**2-13050*e+9000)/(1440000*(19*e+10)*(679*e**2+1560*e+400)**2)
zero('WC2_exact_K1_factor',K1.subs(h,e)-Kcurve)
zero('second_dstar_contact_expression',ds-(z10-w01-w21)/2)

payload={
 'status':'PASS','checks':checks,'count':len(checks),
 'joint_corner_values':limits,
 'family':'B=e,H=e*h,L=e*(1-h),z=e/2,y=2e,r=9/10; e,h independent positive infinitesimals',
 'physicality':'Full exact contact and stationary derivatives checked. Positive outer Laurent dictionary, positive transverse state restriction, and the finite pair/triangle AM-GM identity prove global physicality in the real closed source field. Source signs alone are not substituted for that proof.',
 'conclusion':'K1<0 and JG13 fails on this physical weak-B family. No source polynomial splitter JG7-JG9 or global polynomial SOS in Kc[t,b,s] can exist there.',
 'scope':'Global polynomial-SOS obstruction only. It does not exclude tensor SOS at independent tests using other pure-test elements or local charts. No original-parent normal allocation, residual-row admission, or membership in the complement of all inherited admissions is asserted.'
}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps(payload,indent=2))
