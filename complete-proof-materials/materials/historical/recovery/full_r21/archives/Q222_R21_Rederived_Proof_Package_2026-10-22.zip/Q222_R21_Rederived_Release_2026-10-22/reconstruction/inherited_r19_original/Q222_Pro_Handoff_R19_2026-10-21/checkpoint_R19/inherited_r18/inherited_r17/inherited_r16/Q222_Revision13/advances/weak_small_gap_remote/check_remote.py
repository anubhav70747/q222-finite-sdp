from pathlib import Path
import sympy as s,json
checks={}
def ck(k,x):
 assert s.cancel(x)==0,k
 checks[k]=True
u,v,p,q,W,X,Y,Z,n,m,C,A,D,al=s.symbols('u v p q W X Y Z n m C A D al');half=s.Rational(1,2);Du=1+u*u;Dv=1+v*v
F=n*Du*Dv*X**2+m*(v*W-X+u*v*Y-u*Z)**2+C*Dv*(u*W-Y)**2+A*Du*Dv*Y**2+D*(u*W+u*v*X-Y-v*Z)**2+al*Du*(v*Y-Z)**2+half*((u*W+u*v*X-Y-v*Z)**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)
# Entire six-root parent for u infinity, v infinitesimal.
Nh,Vh,K,Rh,Yh,sm,sa,ey=s.symbols('Nh Vh K Rh Yh sm sa ey')
Dp=1+p*p
J=W+Dp*Vh-p*Y-p*v*K
H=Dp*Dv*Nh**2+m*(p*v*W+v*Y-K)**2+C*Dv*(W-p*Y)**2+Dp*Dv*Yh**2+D*J**2+Dp*(Rh+sa*(v*Y-K))**2
H+=half*(J**2+(1-p*p*v*v)*K*K+Dp*(v*v*Y*Y-2*v*Y*K+2*p*Y*Vh+2*p*v*K*Vh-p*p*Vh*Vh))
ck('six_root_u_infinity_full_parent',H.subs({Nh:s.sqrt(n)*X,Vh:v*X,K:p*X+Z,Rh:sa*p*X,Yh:s.sqrt(A)*Y,sa:s.sqrt(al)})-p*p*F.subs(u,1/p))
Hn=s.expand(H.subs(Y,ey*Yh))
Hres=Hn.subs({p:0,v:0,m:0,sa:0,ey:0})
Hexp=Nh*Nh+Rh*Rh+Yh*Yh+C*W*W+(D+half)*(W+Vh)**2+half*K*K
ck('six_root_u_infinity_complete_residue',Hres-Hexp)
ck('six_root_WV_block_determinant',(C+D+half)*(D+half)-(D+half)**2-C*(D+half))
# Other degenerate axis: u infinitesimal and finite unit v, or reciprocal v.
S,R=s.symbols('S R')
G=n*Du*Dv*X*X+(v*S-sm*X+sm*u*v*Y-sm*u*Z)**2+C*Dv*(R-Y)**2+Du*Dv*Yh*Yh+D*(R+u*v*X-Y-v*Z)**2+al*Du*(v*Y-Z)**2
G+=half*((R+u*v*X-Y-v*Z)**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)
ck('finite_axis_full_parent',G.subs({S:sm*W,R:u*W,Yh:s.sqrt(A)*Y,m:sm*sm})-F.subs(m,sm*sm))
Gr=s.expand(G.subs(Y,ey*Yh)).subs({u:0,n:0,sm:0,al:0,ey:0})
Ge=v*v*S*S+half*Dv*X*X+Dv*Yh*Yh+(C*Dv+D+half)*R*R-2*(D+half)*v*R*Z+D*v*v*Z*Z
ck('finite_axis_full_residue',Gr-Ge)
t=s.symbols('t');C0=t/2;D0=1/(2*(t-1))
ck('finite_axis_RZ_determinant',((C*Dv+D+half)*D*v*v-(D+half)**2*v*v-C*D*v**4).subs({C:C0,D:D0}))
QG=s.expand(q*q*G.subs(v,1/q))
ck('reciprocal_v_five_root_full_residue',QG.subs(Y,ey*Yh).subs({u:0,q:0,n:0,sm:0,al:0,ey:0})-(S*S+C*R*R+half*X*X+Yh*Yh+D*Z*Z))
# Finite pair with both nonzero residues.
F3=F.subs({Y:0,n:0,m:0,al:0});M=s.hessian(F3,(W,X,Z))/2
U=u*u;V=v*v
ck('finite_two_unit_determinant',(M.det()-Du*Dv*U*V*(C*(2*D+1)*U/4+C*D*V/2)).subs({C:C0,D:D0}))
# Literal double infinity, exact original WR6 identity after normalized Y.
Pz,Qz=s.symbols('Pz Qz')
J2=q*W+X-p*q*Y-Pz
FD=n*(1+p*p)*(1+q*q)*X*X+m*(p*W-p*q*X+Y-Qz)**2+C*(1+q*q)*(W-p*Y)**2+(1+p*p)*(1+q*q)*Yh*Yh+D*J2*J2+al*(1+p*p)*(Y-Qz)**2+half*(J2*J2+(1+p*p)*(Y-Qz)**2+p*p*(1+q*q)*X*X+2*(1+q*q)*X*Pz-(1+q*q)*Pz*Pz)
ck('double_projective_full_identity',FD.subs({Pz:p*Z,Qz:q*Z,Yh:s.sqrt(A)*Y})-p*p*q*q*F.subs({u:1/p,v:1/q}))
ck('double_projective_strict_residue',FD.subs(Y,ey*Yh).subs({p:0,q:0,n:0,m:0,al:0,ey:0})-(C*W*W+Yh*Yh+(D+half)*X*X-2*D*X*Pz+D*Pz*Pz+half*Qz*Qz))

# The six-root chart actually covers every bounded p, not only p infinitesimal.
Hp=Hn.subs({v:0,m:0,sa:0,ey:0})
Hpe=Dp*(Nh*Nh+Rh*Rh+Yh*Yh)+C*W*W+(D+half)*(W+Dp*Vh)**2+half*K*K-half*Dp*p*p*Vh*Vh
ck('six_root_every_bounded_p_residue',Hp-Hpe)
blk=s.hessian(Hpe,(W,Vh))/2
ck('six_root_every_bounded_p_block_determinant',(blk.det()-Dp*C*(D+half)).subs({C:C0,D:D0}))
Path(__file__).with_suffix('.json').write_text(json.dumps({'status':'PASS','checks':checks,'scope':'Complete remote parent identities; local both-infinitesimal corner not asserted.'},indent=2)+'\n');print(len(checks),'PASS')
