#!/usr/bin/env python3
"""Exact matching compression and optimization identities. Requires SymPy."""
from pathlib import Path
import json
import sympy as s
if not __debug__:raise SystemExit('Run without -O')
u,v,W,X,Y,Z,d,n,m,C,A,D,al,la,be=s.symbols('u v W X Y Z d n m C A D alpha lambda beta')
t,z=s.symbols('t z',positive=True)
Du,Dv=1+u*u,1+v*v
Rm=v*W-X+u*v*Y-u*Z;Rd=u*W+u*v*X-Y-v*Z
H=2*(Rd**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)
F=4*la*Du*(W+v*X)**2+4*n*Du*Dv*X**2+4*m*Rm**2+4*C*Dv*(u*W-Y)**2+4*A*Du*Dv*Y**2+4*D*Rd**2+4*al*Du*(v*Y-Z)**2+4*be*Dv*(X+u*Z)**2+d*H
sub={u:t,v:t*z,W:1,X:0,Y:0,Z:z}
assert s.expand(Rm.subs(sub,simultaneous=True))==0
value=s.expand(F.subs(sub,simultaneous=True))
P=la+z*z*al;Q=C+z*z*be
expected=4*t*t*(D*(z*z-1)**2-d*(z*z-1)/2)+4*(1+t*t)*P+4*t*t*(1+z*z*t*t)*Q
assert s.expand(value-expected)==0
# Exact angle minimization: t^4=P/(z^2 Q); square identity for t part.
pp,qq=s.symbols('P Q',nonnegative=True)
assert s.expand(pp/t**2+z*z*qq*t*t-2*z*s.sqrt(pp)*s.sqrt(qq)-(s.sqrt(pp)/t-z*s.sqrt(qq)*t)**2)==0
# C2 alpha=a^2, C=b^2: the minimizing t^2=a/b is independent of z.
a,b,e=s.symbols('a b e',positive=True)
compression=D*e*e-d*e/2+(1+e)*a*a+b*b+2*(1+e)*a*b
expected_quad=D*e*e+(a*a+2*a*b-d/2)*e+(a+b)**2
assert s.expand(compression-expected_quad)==0
r=d/2-a*a-2*a*b
assert s.expand(expected_quad.subs(e,r/(2*D))-((a+b)**2-r*r/(4*D)))==0
# Exact C2 trace on X=Y=0 is a stronger necessary parent restriction.
WW=m*v*v+(D+d/2+C)*u*u+C*u*u*v*v
ZZ=(m+d/2+al)*u*u+D*v*v+al
K=m+D+d/2
trace=4*(WW*W*W+ZZ*Z*Z-2*K*u*v*W*Z)
assert s.expand(F.subs({la:0,be:0,X:0,Y:0})-trace)==0
report={'status':'PASS','identities':['three matching amplitudes vanish','complete eight-event compression','angle minimization square identity','C2 positive quadratic in epsilon','optimized quadratic value','C2 two-state trace'], 'scope':'Exact physicality necessary inequalities; not a tensor-SOS sufficiency theorem.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
