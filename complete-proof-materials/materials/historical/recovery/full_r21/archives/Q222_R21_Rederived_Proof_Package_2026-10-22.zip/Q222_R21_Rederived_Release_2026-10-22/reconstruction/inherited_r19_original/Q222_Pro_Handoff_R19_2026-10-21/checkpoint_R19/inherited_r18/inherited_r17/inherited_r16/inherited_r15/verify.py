import argparse,hashlib,json,subprocess,sys
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--algebra',action='store_true');a=p.parse_args();r=Path(__file__).resolve().parent
m=json.loads((r/'MANIFEST.json').read_text())
for rel,h in m.items():
 assert hashlib.sha256((r/rel).read_bytes()).hexdigest()==h,rel
print('PASS:',len(m),'integrity hashes',flush=True)
if a.algebra:
 for rel in ['proofs/r9_contact/check_reciprocal_contact.py','proofs/c1_contact/check_coupled_circuit.py','proofs/c1_contact/audit_r9_full_parent.py','proofs/c1_contact/check_large_zeta_contact.py','proofs/c1_contact/check_small_eta_conductors.py','proofs/c1_small_eta/check_weighted_frontier.py']:
  subprocess.run([sys.executable,str(r/rel)],cwd=r,check=True)
 print('PASS: all new symbolic checkers; historical suite not run',flush=True)
