"""Exact independent checks for centered_a_outer.tex; no samples or rate grids.

Only SymPy is needed. No centered scalar, contact lift, or cached source
computation is imported. The native coquotients and full parent are
reconstructed directly from their short printed formulas.
"""
from pathlib import Path
import json
import sympy as s

HERE = Path(__file__).resolve().parent
checks = []


def eq(name, lhs, rhs):
    assert s.cancel(lhs - rhs) == 0, name
    checks.append(name)


# Short original source formulas. Native r=1-a*eta is imposed only when
# taking its small-r residue; the common r factors cancel identically.
k, eta, zeta, a, t, r, e = s.symbols('k eta zeta a t r e')
K = 1+k*k
Vc = k*k*eta*zeta
Hc = r+eta
Qc = 1-k*k*zeta+a*Vc
S3 = 1-k*k*eta+t*Vc
R = 1+k*k*r
T = 1+k*k-k*k*zeta*t
M = R-t
J = T-a
P4 = (1+k*k+eta*k*k*(a-k*k-1)-zeta*k*k*t
      +Vc*(-zeta*k*k*t*t+2*k*k*t+a*(1-t)+t))
Pd = ((1+k*k)**2-a*eta*k**4
      +zeta*k*k*((k*k+1)-(k*k+2)*t)
      +Vc*(-zeta*k*k*t*t+k*k*a*(t-1)+k*k*t+k*k+1))
c2 = 2*K*(1-t*zeta)*r*(1+Vc)*Hc*Qc
c3 = 2*K*r*Hc*Qc*S3
c5 = 2*K*r*Hc*Qc*(1+Vc)
c4 = 2*Qc*P4
cd = 4*r*Qc*Pd
d_source = 2*a*eta*cd/c3
m_source = 2*a*e*e*c2/(M*c3)
A_source = 2*a*eta*eta*c4/c3
D_source = 2*a*c5/(J*c3)-d_source/2

d_cancelled = 4*a*eta*Pd/(K*Hc*S3)
L_cancelled = 2*a*eta*eta*P4/(K*Hc*S3)
D_numerator = K*Hc*(1+Vc)-J*eta*Pd
eq('exact cancellation in d', d_source, d_cancelled)
eq('exact cancellation in A*r', A_source*r, L_cancelled)
eq('exact cancelled m/d', m_source/d_source,
   e*e*K*(1-t*zeta)*(1+Vc)*Hc/(2*M*eta*Pd))
eq('exact cancelled c/d', 2/d_source, K*Hc*S3/(2*a*eta*Pd))
eq('exact cancelled A/d', A_source/d_source, eta*P4/(2*r*Pd))
eq('exact cancelled D/d', D_source/d_source,
   D_numerator/(2*J*eta*Pd))


def residue(expr):
    cancelled = s.cancel(expr.subs(a, (1-r)/eta))
    return s.cancel(cancelled.subs({k: 0, zeta: 0, r: 0}))


eq('d residue', residue(d_cancelled), 4/eta)
eq('A*r residue', residue(L_cancelled), 2)
eq('D numerator residue', residue(D_numerator), 1)
eq('J residue', residue(J), 1-1/eta)
eq('J*D residue including small J', residue(J*D_source), 2/(eta*eta))
eq('D residue when eta residue exceeds one', residue(D_source),
   2/(eta*(eta-1)))
eq('P4 positive unit residue', residue(P4), 1)
eq('Pd positive unit residue', residue(Pd), 1)

# Rebuild the complete original parent, with c=2, from all six events
# and the signed core. Its selected difference retains exactly the
# positive original event excesses specified in the manuscript.
u, v, W, X, Y, Z, d, m, A, D, al, be = s.symbols(
    'u v W X Y Z d m A D alpha beta')
ms, Ds = s.symbols('m_star D_star')
Du, Dv = 1+u*u, 1+v*v
rm = v*W-X+u*v*Y-u*Z
rb = X+u*Z
r3 = u*W-Y
r5 = u*W+u*v*X-Y-v*Z
ra = v*Y-Z
core = 2*(r5*r5+Du*ra*ra+Dv*rb*rb-Du*Dv*Z*Z)
parent = (4*m*rm*rm+8*Dv*r3*r3+4*A*Du*Dv*Y*Y
          +4*D*r5*r5+4*al*Du*ra*ra+4*be*Dv*rb*rb+d*core)
retained = (4*(m-ms)*rm*rm+4*(D-Ds)*r5*r5
            +4*al*Du*ra*ra+4*be*Dv*rb*rb)
selected = parent-retained
original_selected = (4*ms*rm*rm+8*Dv*r3*r3+4*A*Du*Dv*Y*Y
                     +(4*Ds+2*d)*r5*r5+2*d*Dv*rb*rb
                     +2*d*Du*(ra*ra-Dv*Z*Z))
eq('exact full selected parent and retained original events',
   selected, original_selected)

h, L, H, B, U, V, q = s.symbols('h L H B U V q')
Yr = r*U+h*H
C = 4*Ds+2*d
base_frame = (8*Dv*((1-r)*U-h*H)**2+4*Du*Dv*H*H
              +4*L*r*Du*Dv*U*U+8*L*h*Du*Dv*U*H
              +C*((1-r)*U-h*H+u*v*B-Du*V)**2
              +2*d*Dv*B*B
              +2*d*Du*(v*v*Yr*Yr-2*Yr*V-V*V))

# Ordinary-u chart: ms=0, so W does not require any q=W/Z relation.
ordinary_original = s.expand(original_selected.subs(ms, 0).subs(
    {W: U/u, X: B-u*Z, Y: Yr, A: 1/(h*h)}, simultaneous=True))
ordinary_original = s.cancel(ordinary_original.subs(Z, V/v))
eq('exact ordinary-u full centered root identity', ordinary_original,
   base_frame.subs(L, r/(h*h)))
assert not s.denom(s.cancel(base_frame)).has(u, v, r, h)
assert s.Poly(base_frame, H, B, U, V).total_degree() == 2
assert all(sum(mon) == 2 for mon, coefficient in
           s.Poly(base_frame, H, B, U, V).terms())
checks.append('complete ordinary-u bounded four-root allocation')
ordinary_residue = (4*Du*H*H+2*d*B*B+8*U*U
                    +C*(U-Du*V)**2-2*d*Du*V*V)
eq('complete ordinary-u Gram residue',
   base_frame.subs({r: 0, h: 0, v: 0}), ordinary_residue)
UV = s.hessian(ordinary_residue, (U, V))/2
det_uv = s.factor(s.det(UV))
eq('ordinary-u exact UV determinant', det_uv,
   Du*(8*C*Du-2*d*(8+C)))
eq('ordinary-u eta above one determinant',
   det_uv.subs({d: 4/eta, Ds: 2/(eta*(eta-1))}),
   64*u*u*Du/(eta-1))
eq('ordinary-u eta one arbitrary real D cap determinant',
   det_uv.subs(d, 4), 32*Du*(Ds*u*u+2*u*u-2))

# Unit-W/unit-Z chart: q=W/Z is pure testing. Form the original roots
# with uW=U before using W=qZ in the one remaining vW occurrence.
unit_original = (4*ms*(v*q*Z+u*v*Yr-B)**2
                 +8*Dv*(U-Yr)**2+4*Du*Dv*Yr*Yr/(h*h)
                 +C*(U+u*v*(B-u*Z)-Yr-v*Z)**2
                 +2*d*Dv*B*B+2*d*Du*((v*Yr-Z)**2-Dv*Z*Z))
unit_original = s.cancel(s.expand(unit_original).subs(Z, V/v))
unit_frame = base_frame+4*ms*(q*V+u*v*Yr-B)**2
eq('exact unit-W full centered root identity', unit_original,
   unit_frame.subs(L, r/(h*h)))
assert not s.denom(s.cancel(unit_frame)).has(u, v, r, h)
assert all(sum(mon) == 2 for mon, coefficient in
           s.Poly(unit_frame, H, B, U, V).terms())
checks.append('complete unit-W bounded four-root allocation')
unit_residue = (4*H*H+2*d*B*B+4*ms*(q*V-B)**2
               +8*U*U+C*(U-V)**2-2*d*V*V)
eq('complete unit-W Gram residue',
   unit_frame.subs({r: 0, h: 0, u: 0, v: 0}), unit_residue)
mu = s.symbols('mu')
mu_exact = 4*d*ms*q*q/(d+2*ms)
eq('unit-W B Schur additional V mass',
   4*ms*q*q-(4*ms*q)**2/(2*d+4*ms), mu_exact)
unit_det = (8+C)*(C-2*d+mu)-C*C
eq('unit-W eta above one determinant',
   unit_det.subs({d: 4/eta, Ds: 2/(eta*(eta-1))}),
   8*eta*mu/(eta-1))
eq('unit-W eta one arbitrary real D cap determinant',
   unit_det.subs(d, 4), mu*(4*Ds+16)-64)

# State entry uses no source quantities or rate comparisons.
w, current = s.symbols('w current')
eq('state-entry W inverse',
   ((W+u*Y)+u*(u*W-Y))/Du, W)
eq('state-entry Y inverse',
   (u*(W+u*Y)-(u*W-Y))/Du, Y)
eq('finite-v-zero pure core', core.subs(v, 0),
   2*((X+u*Z)**2+(u*W-Y)**2))

out = {
    'status': 'PASS',
    'check_count': len(checks),
    'checks': checks,
    'scope': ('Independent exact short-source and full-parent checks for '
              'centered_a_outer.tex. The inherited outer projective routing '
              'is invoked through its unchanged positive lower bounds; '
              'the remaining infinitesimal u,v,w contact chart is excluded. '
              'No contact scalar computation is imported.'),
}
(HERE/'centered_a_outer_checks.json').write_text(json.dumps(out, indent=2)+'\n')
print(json.dumps(out, indent=2))
