from pathlib import Path
import json
import sympy as s
checks={}
def ck(name,e):
 assert s.cancel(e)==0,name
 checks[name]=True
u,v,W,X,Y,Z,Xh,Yh=s.symbols('u v W X Y Z Xh Yh');m,C,D,n,A,al,ex,ey,a,t=s.symbols('m C D n A al ex ey a t')
Du=1+u*u;Dv=1+v*v;half=s.Rational(1,2)
F=n*Du*Dv*X**2+m*(v*W-X+u*v*Y-u*Z)**2+C*Dv*(u*W-Y)**2+A*Du*Dv*Y**2+D*(u*W+u*v*X-Y-v*Z)**2+al*Du*(v*Y-Z)**2+half*((u*W+u*v*X-Y-v*Z)**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)
# Normalize both hard source state variables, using the pure-source ex=1/sqrt(n), ey=1/sqrt(A).
FN=F.subs({X:ex*Xh,Y:ey*Yh,n:ex**-2,A:ey**-2}).expand()
res=s.expand(FN.subs({ex:0,ey:0,al:0}))
P=m*(v*W-u*Z)**2+C*Dv*u*u*W*W+(D+half)*(u*W-v*Z)**2+half*Dv*u*u*Z*Z-half*Du*v*v*Z*Z
ck('full_bounded_residue',res-Du*Dv*(Xh*Xh+Yh*Yh)-P)
m0=a*a/(2*(1-a*a));C0=(t-a)/(2*(1+a));D0=1/(2*(1+a)*(t-1));subs={m:m0,C:C0,D:D0}
M=s.hessian(P,(W,Z))/2;det=s.factor(M.det())
U=u*u;V=v*v
fact=D*m*(V-t*U/a)**2+C*(2*m+1)*U*U*V/2+C*D*U*V*V
ck('complete_two_state_determinant',(det-fact).subs(subs))
p,q=s.symbols('p q')
# The inherited remote packet identities are polynomial and valid for arbitrary n,A.
RU=s.expand(p*p*FN.subs(u,1/p)).subs({p:0,ex:0,ey:0,al:0})
EU=(C*Dv+D+half)*W*W+Dv*(Xh*Xh+Yh*Yh)+(m+half)*Z*Z
ck('single_u_infinity_complete_residue',RU-EU)
RV=s.expand(q*q*FN.subs(v,1/q)).subs({q:0,ex:0,ey:0,al:0})
EV=(m+C*U)*W*W+Du*(Xh*Xh+Yh*Yh)+D*Z*Z
ck('single_v_infinity_complete_residue',RV-EV)
Pz,Qz=s.symbols('Pz Qz')
# Full double-homogeneous packet, before the two source normalizations.
Fdouble=n*(1+p*p)*(1+q*q)*X*X+m*(p*W-p*q*X+Y-Qz)**2+C*(1+q*q)*(W-p*Y)**2+A*(1+p*p)*(1+q*q)*Y*Y+D*(q*W+X-p*q*Y-Pz)**2+al*(1+p*p)*(Y-Qz)**2+half*((q*W+X-p*q*Y-Pz)**2+(1+p*p)*(Y-Qz)**2+p*p*(1+q*q)*X*X+2*(1+q*q)*X*Pz-(1+q*q)*Pz*Pz)
ck('full_double_projective_identity',Fdouble.subs({Pz:p*Z,Qz:q*Z})-p*p*q*q*F.subs({u:1/p,v:1/q}))
FDN=s.expand(Fdouble.subs({X:ex*Xh,Y:ey*Yh,n:ex**-2,A:ey**-2}))
ck('double_infinity_strict_residue',FDN.subs({ex:0,ey:0,p:0,q:0,al:0})-(C*W*W+Xh*Xh+Yh*Yh+D*Pz*Pz+(m+half)*Qz*Qz))

# Joint r-infinitesimal, a-infinitesimal corner: keep both soft W roots.
mu,Sr,Rr=s.symbols('mu Sr Rr')
Ffinite=n*Du*Dv*X**2+mu*(v*Sr-a*X+a*u*v*Y-a*u*Z)**2+C*Dv*(Rr-Y)**2+A*Du*Dv*Y**2+D*(Rr+u*v*X-Y-v*Z)**2+al*Du*(v*Y-Z)**2+half*((Rr+u*v*X-Y-v*Z)**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)
ck('joint_corner_finite_full_parent',Ffinite.subs({Sr:a*W,Rr:u*W})-F.subs(m,a*a*mu))
FfinN=s.expand(Ffinite.subs({X:ex*Xh,Y:ey*Yh,n:ex**-2,A:ey**-2}))
ffres=FfinN.subs({a:0,ex:0,ey:0,al:0,u:0})
ffexp=mu*v*v*Sr*Sr+Dv*(Xh*Xh+Yh*Yh)+(C*Dv+D+half)*Rr*Rr-2*(D+half)*v*Rr*Z+D*v*v*Z*Z
ck('joint_corner_finite_full_residue',ffres-ffexp)
Cj=t/2;Dj=1/(2*(t-1))
ck('joint_corner_finite_block_determinant',((C*Dv+D+half)*D*v*v-(D+half)**2*v*v-C*D*v**4).subs({C:Cj,D:Dj}))
Freq=n*Du*(1+q*q)*X**2+mu*(Sr-a*q*X+a*u*Y-a*u*q*Z)**2+C*(1+q*q)*(Rr-Y)**2+A*Du*(1+q*q)*Y**2+D*(q*Rr+u*X-q*Y-Z)**2+al*Du*(Y-q*Z)**2+half*((q*Rr+u*X-q*Y-Z)**2+Du*(Y-q*Z)**2+(1+q*q)*(X+u*Z)**2-Du*(1+q*q)*Z**2)
ck('joint_corner_reciprocal_full_parent',Freq.subs({Sr:a*W,Rr:u*W})-q*q*F.subs({v:1/q,m:a*a*mu}))
FreqN=s.expand(Freq.subs({X:ex*Xh,Y:ey*Yh,n:ex**-2,A:ey**-2}))
ck('joint_corner_reciprocal_strict_residue',FreqN.subs({a:0,ex:0,ey:0,al:0,u:0,q:0})-(mu*Sr*Sr+C*Rr*Rr+Xh*Xh+Yh*Yh+D*Z*Z))
jointfact=t*t/(4*(t-1))*U*U+Cj/2*U*U*V+Cj*Dj*U*V*V
ck('joint_corner_u_unit_complete_determinant',det.subs({m:0,C:Cj,D:Dj})-jointfact)
Path(__file__).with_suffix('.json').write_text(json.dumps({'status':'PASS','checks':checks,'scope':'Full-parent remote and literal endpoint identities for r infinitesimal, a=z/B positive bounded (unit or infinitesimal) and G/B a unit, all other printed source hypotheses retained.'},indent=2)+'\n')
print(len(checks),'exact assertions PASS')
