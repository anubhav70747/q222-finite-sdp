Bounded full-parent Omega-conductor reduction (JU1--JU11)

Status: exact reduction and precise remaining allocation; NO new source
admission. The earlier JR/JB admitted domains are unchanged.

Source: original physical C1.4, x,z,sigma positive infinitesimals,
H=h/sigma bounded, Mbeta=beta*theta/sigma^2 unbounded.
Tests: u,w infinitesimal, including either zero and all signs.

Main identity: replace V by sigma*Omega-(u^2-x)*Gamma, where
Omega=(u^2-x)Z. The complete parent now has bounded coefficients
without x/u or x/u^2. The four changed entries, all retained radial
and first-normal terms, and their source bounds are printed in JU2--JU5.

Remaining lemma: the exact Gamma-Omega conductor/circuit allocation
through the D=0 endpoint, including the full radial first normal and
all original-parent corrections. The free six-root residue matrix is
not positive, and a bounded multiple of its displayed syzygy cannot
repair that frame. This is a method obstruction, not a counterexample.

JU10's radical circuit is explicitly a pointwise, state-homogeneous
radial-kernel identity. Its separated factors and Z=0 branch are
printed. It is not a state-linear full-parent Gram or an asserted lift.

Run:
  PYTHONPATH=/tmp/q222_sympy python3 check_bounded_u_conductor.py

Latest receipt: 22 NEW exact assertions passed in 0.525 seconds.
The original source jets and verified JR/JB parent identity are
explicit imported dependencies; no historical checker was replayed.
