#!/usr/bin/env python3
"""R7 bounded-a: exact source entry, full-parent D gauge and all remote kernels."""
import sympy as s
import json
from pathlib import Path
out={}
def ck(name,expr):
    seq=list(expr) if isinstance(expr,s.MatrixBase) else [expr]
    for z in seq: assert s.cancel(z)==0,(name,s.factor(z))
    out[name]=True
u,v,W,X,Y,Z,xi,eta,a,B,h,r,t,n,m,A,C,D,al=s.symbols('u v W X Y Z xi eta a B h r t n m A C D al')
U=u*u;V=v*v;Du=1+U;Dv=1+V;half=s.Rational(1,2);l=1-h;k=1/t;ell=1/a;j=1+a*B*r-l/t
# Entire unnormalized WA matrix, now with scaled R2'=aR2.
a0=(C+D+half)*l*l+A*h*h;a4=A*h*h
b2=2*m*h+C*l*l+(A+al+half)*h*h;b4=h*h*(m+A+al+half)
c4=n*r*r;d2=(n+half)*r*r+2*D*r;d4=(n+D+half)*r*r
beta=(B*d4+k*c4)/(k*ell**2);gamma=b4+d4/(k*ell)
j0=(B*d4-a4*k*k*ell+d2*ell)/(2*k*ell**2);j1=d4/(2*k*ell);Js=j0+j1*U
fs=(b2-c4/ell**2-al/B**2-B*d4/(k*ell**2))/2
p0=(D+r*(n+half))/k;p1=r*(n+D+half)/k;q1=(n*r+B*p1)/ell
fx=-m*h+(D+half)*l-p0-q1
py=-(C+D+half)*l+A*h;pyp=A*h
kv=-C*l+A*h+m+(al+half)*h;kuv=h*(A+m+al+half)
kz=-m*(1-r)+r*(D+half)-al-half;qy=(-kz-k*pyp-B*kuv)/ell;fy=kv-qy
G=s.zeros(5)
G[0,0]=n*Du*Dv+m+(D+half)*U*V+half*Dv
G[1,1]=A*Du*Dv+C*Dv+D+half+m*U*V+(al+half)*Du*V
G[0,1]=G[1,0]=-u*v*(m+D+half)
G[0,2]=G[2,0]=u*v*(p0+p1*U);G[0,3]=G[3,0]=(-m+q1*U)/a;G[0,4]=G[4,0]=u*(fx-p1*U)
G[1,2]=G[2,1]=py+pyp*U;G[1,3]=G[3,1]=u*v*qy/a;G[1,4]=G[4,1]=v*(fy+kuv*U)
G[2,2]=a0+a4*U;G[2,3]=G[3,2]=u*v*Js/a;G[2,4]=G[4,2]=-v*Js
G[3,3]=(m+beta*U)/a**2;G[3,4]=G[4,3]=u*(fs-j1*U)/a;G[4,4]=al/B**2+gamma*U
roots=s.Matrix([xi,eta,u*W-v*Z/t,a*v*W-u*Z,u*v*W-B*Z])
ld=s.Matrix([u*v,-1,l,r*u*v,-a*r*v])
S=s.Matrix([0,0,(a*B-U)*v,-(B-V/t)*u,U-a*V/t])
L=s.Matrix([-2*r*t*u,0,0,-r*r*t*u,a*r*r*t])
HD=s.zeros(5)
HD[0,2]=HD[2,0]=t*u*v;HD[0,4]=HD[4,0]=-t*u
HD[2,3]=HD[3,2]=r*t*u*v;HD[2,4]=HD[4,2]=-a*r*t*v
ck('full_WA_D_syzygy_matrix',G.diff(D)-ld*ld.T-(S*L.T+L*S.T)/2-j*HD)
ck('exact_D_syzygy_zero',(S.T*roots)[0])
J=u*W+u*v*X-Y-v*Z
ck('centered_D_full_state_row',(ld.T*roots)[0].subs({xi:X+r*u*Z,eta:Y-h*u*W})-(J+j*v*Z))
# Thus G = D ldld^T + G|D0 + Dj HD modulo an exact zero.
ck('D_gauge_entire_quadratic_identity',(roots.T*(G-D*ld*ld.T-G.subs(D,0)-D*j*HD)*roots)[0])
K=s.symbols('K')
ck('exact_D_cap_event_identity',D*J*J-(D-K)*(J+j*v*Z)**2-(K*J*J-2*(D-K)*j*v*Z*J-(D-K)*j*j*V*Z*Z))
# Pure-source joint residue formulas: B=h=g=0, a=1/e, r=1-e.
e=s.symbols('e');rr=1-e;aa=1/e
Nexpr=((1+aa*rr)-rr*(1+aa))/(2*rr*(1+aa))
Cexpr=((1+aa*rr)*t-aa*(1-rr))/(2*(1+aa))
Dexpr=(1+aa*rr)/(2*(t-1)*(1+aa))
AHexpr=t*(1+aa*rr)/(2*(1+aa))
alexpr=(1+aa*rr)*((1+aa*rr)*t-aa*(1-rr))/(2*(1+aa))
mgexpr=aa*aa*(1-rr)/(2*(1+aa))
n0=e*e/(2*(1-e*e));C0=(t-e)/(2*(1+e));D0=1/(2*(1+e)*(t-1));kap=1/(2*(1+e))
ck('bounded_a_source_residues',s.Matrix([Nexpr-n0,Cexpr-C0,Dexpr-D0,AHexpr-t/(2*(1+e)),alexpr-(t-e)/(2*e*(1+e)),mgexpr-kap]))
ck('Dj_unbounded_D_residue',s.cancel(D0*(1-1/t)).subs(t,1)-kap)
# Full original finite core with Y=0 (A hard); no n normal omitted.
M=v*W-X-u*Z;J0=u*W+u*v*X-v*Z
core=half*(J0*J0+Du*Z*Z+Dv*(X+u*Z)**2-Du*Dv*Z*Z)
base=n*Du*Dv*X*X+C*Dv*U*W*W+D*J0*J0+core
ker=s.expand(base.subs(X,v*W-u*Z));Gker=s.hessian(ker,(W,Z))/2
raw=s.factor(Gker.det())
finite=s.cancel(raw.subs({n:n0,C:C0,D:D0}))
target=Du*Dv*((e*t*U-V)**2+(t-e)**2*U*U*V)/(4*(1-e)*(1+e)**2*(t-1))
ck('finite_remote_r_unit_j_unit_kernel',finite-target)
# n also hard when r infinitesimal: X=Y=0, M=vW-uZ.
smallr=base.subs({X:0,n:0,C:(t-1)/4,D:1/(4*(t-1))})
ck('finite_remote_small_r_kernel',smallr.subs(W,u*Z/v)-Z*Z*((t*U-V)**2+(t-1)**2*U*U*V)/(4*(t-1)*V))
# D unbounded: t=1, r unit, common M=J=0 kernel vector.
vec={W:v*Du,X:V-U,Z:u*Dv}
ck('double_gap_kernel_M',M.subs(vec))
ck('double_gap_kernel_J',J0.subs(vec))
based=base.subs(D,0)
value=based.subs(vec).subs({n:n0,C:C0.subs(t,1)})
target=Du*Dv*((e*U-V)**2+(1-e)**2*U*U*V)/(2*(1-e)*(1+e))
ck('finite_remote_double_gap_kernel_positive_form',value-target)
# Reciprocal chart kernels, all finite values of remaining angle.
p,q=s.symbols('p q')
up=s.cancel(p*p*base.subs(u,1/p)).subs(p,0)
ck('reciprocal_u_M_kernel',up.subs(Z,0)-(n*Dv*X*X+C*Dv*W*W+(D+half)*(W+v*X)**2))
upD=s.cancel(p*p*based.subs(u,1/p)).subs(p,0)
ck('reciprocal_u_M_D_kernel',upD.subs({Z:0,W:-v*X})-(n*Dv+C*Dv*V)*X*X)
vq=s.cancel(q*q*base.subs(v,1/q)).subs(q,0)
ck('reciprocal_v_M_kernel',vq.subs(W,0)-((n+half)*Du*X*X+D*(u*X-Z)**2))
vqD=s.cancel(q*q*based.subs(v,1/q)).subs(q,0)
ck('reciprocal_v_M_D_kernel',vqD.subs({W:0,Z:u*X})-(n+half)*Du*X*X)
P,Q=s.symbols('P Q')
dbl=n*X*X+C*W*W+D*(X-P)**2+half*((X-P)**2+Q*Q+2*X*P-P*P)
ck('double_reciprocal_complete_Yzero_residue',dbl-((n+half)*X*X+C*W*W+D*(X-P)**2+half*Q*Q))
ck('double_reciprocal_common_kernel',dbl.subs({D:0,P:X,Q:0})-((n+half)*X*X+C*W*W))
payload={'status':'PASS','count':len(out),'checks':out,'scope':'R7 all tests on bounded a=z/B, equivalently unit 1-r, retaining exclusion of simultaneous infinitesimal r,j. Full R7 a-unbounded endpoint remains.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps(payload,indent=2))
