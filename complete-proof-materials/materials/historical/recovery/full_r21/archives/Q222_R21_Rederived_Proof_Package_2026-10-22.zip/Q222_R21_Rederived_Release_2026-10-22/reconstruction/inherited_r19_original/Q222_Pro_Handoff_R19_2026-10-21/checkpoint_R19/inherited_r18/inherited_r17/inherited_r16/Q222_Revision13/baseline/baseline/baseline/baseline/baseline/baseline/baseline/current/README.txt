Q222: PHYSICAL CONTACT DETERMINES THE ROOTS
Analytical continuation, 17 October 2026

START HERE
Read Q222_Physical_Contact_Closure.pdf. Editable LaTeX source is beside it.
This is a cumulative continuation: prior/ contains the previous complete
small package, extracted unchanged from its distribution ZIP.

NEW COMPLETE BRANCH RESULTS
1. C2: a physical canonical source with an actual finite noncommuting
   stationary zero and both C/d, alpha/d infinitesimal enters the radial
   all-tests certificate. Neither a positive source chart, signs of the
   contact gaps, strength of the four other weights, bounded contact
   shapes, nor comparability of the weak weights is assumed. Physicality
   and an angular CHSH bound derive them. This is a complete finite-contact
   two-weak branch theorem, importing the supplied analytical radial proof.
2. C1: ordinary bounded-unit k, unit state ratio s=g/f, infinitesimal
   eta=f^2, and positive bounded-unit a,t,M,J give full parent tensor SOS
   at all independent projective tests. One angular factorization and a
   strict five-root weighted Hessian replace source/test rate comparisons.
   This includes the previous k=s=1, a=t=1/2 entry obstruction.

ADDITIONAL PROVED LOCAL RESULT
For the explicitly displayed one-weak C2 family, the reflected contact
chart Z=1, u,W infinitesimal, v-1 infinitesimal has an exact six-root
strict residue Gram. Both complete state-normal terms are restored.
THIS IS LOCAL ONLY. Other independent testing charts are not asserted
covered for this family.

COMMON STRUCTURE
Twelve elementary Newton-square circuits give the determinant SOS.
An elementary cancellation lemma recovers the full parent if bounded
quadratic membership in the same roots is supplied. That membership
is an explicit hypothesis, not a consequence of contact vanishing.

GLOBAL STATUS
The exhaustive atlas-free proof is unfinished. Remaining obligations
include the complementary C1 shape/rate regimes and C2 one-weak or
weak-matching commuting regimes, plus any source boundaries not already
covered by inherited closed-face arguments. The global finite-lift claim
still uses the separately retained computational atlas. No new global
matrix pencil is extracted here. See PROOF_STATUS.json and PROOF_GRAPH.json.

PEN-AND-PAPER REPRODUCTION
The PDF proves the new deductions. Appendices print the strict-Gram lemma,
C2 source and short determinant, and C1 native contact identities.
The inherited C2 all-tests inputs and their dependencies are supplied in
prior/inherited/. The earlier conductor supplement is prior/prior_core/.
The exact scripts are optional audits of finite algebra, not mathematical
premises replacing physicality, bounded division, or chart exhaustion.

CHECKS
  python3 verify.py
    Two short suites using only Python's standard library.
  python3 verify.py --with-sympy
    Four short suites, adding C2 contact identities and physical witnesses.
  python3 verify.py --with-local
    Also rerun the more extensive one-weak local full-parent check.
Optional dependency: requirements-optional.txt.
The four-suite packaged replay and the completed separate local check are
retained in verification/ and c2/check_single_angle_terminal.json.
No numerical sampling, optimization, or archived coefficient table is
needed for these new arguments. Reviews are by agents in the same system,
not external peer review. Inherited theorem proofs and the full atlas
were not all freshly replayed in this continuation.

BUILD
Run twice from this directory:
  pdflatex -interaction=nonstopmode -halt-on-error Q222_Physical_Contact_Closure.tex
Standard TeX Live article, AMS, TikZ and Latin Modern packages suffice.
The distribution omits build logs, temporary images and caches.

PROVENANCE
Unchanged prior package:
  Q222_Analytical_Coverage_Advance.zip
  SHA-256 603f99491315624468aad7cb1892ee9dc62bd172b1a850c65cf3dea22fa6ae37
Full global atlas package, not duplicated here:
  Q222_Human_Computer_Assisted_Proof_Package.zip
  SHA-256 b03308de894eabba15510392a16855b4ee3117140d012a8de1314868bbe0591e
Nested manifests preserve the prior source snapshots. The new manifest
hashes all distributable files in this continuation ZIP.

HISTORICAL NOTES
bridge/research_audit.tex is a research audit made before the two new
branch closures. Its final frontier section is superseded by the present
manuscript and PROOF_STATUS.json. Its first two sections are incorporated
and reviewed in bridge/common_bridge.tex. Similarly the earlier narrower
positive-chart result in c2/automatic_matching_strength.tex is strengthened
by contact/chart_free_c2.tex. These older statements are retained with
their provenance, not used to weaken or broaden the new theorem scopes.
