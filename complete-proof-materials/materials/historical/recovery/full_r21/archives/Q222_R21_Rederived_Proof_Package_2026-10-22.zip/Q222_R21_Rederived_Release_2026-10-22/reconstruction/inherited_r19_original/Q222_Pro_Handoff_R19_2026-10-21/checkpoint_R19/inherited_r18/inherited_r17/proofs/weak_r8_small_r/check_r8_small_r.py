"""New R8 small-r full-parent D gauge and normalized Gram checks.

The exact six-contact WA parent identity is imported. This checker retains
its complete scalar block, both first normals and complete hard block.
"""
import json
import time
from pathlib import Path
import sympy as s
started=time.monotonic()
checks={}
def ck(name,expr):
    if isinstance(expr,s.MatrixBase):
        assert all(s.cancel(v)==0 for v in expr),name
    else:
        assert s.cancel(expr)==0,(name,s.factor(expr))
    checks[name]=True
    print('PASS '+name,flush=True)
u,v,a,B,r,h,t,j=s.symbols('u v a B r h t j')
U=u*u;V=v*v;k=1/t;ell=1/a;l=1-h;x=a*B
n,m,C,A,D,al=s.symbols('n m C A D alpha')
xi,eta,R1,R2,T=s.symbols('xi eta R1 R2 T'); roots=s.Matrix([xi,eta,R1,R2,T])
aa=(C+D+s.Rational(1,2))*l*l+A*h*h;a4=A*h*h
b2=2*m*h+C*l*l+(A+al+s.Rational(1,2))*h*h;b4=h*h*(m+A+al+s.Rational(1,2))
c2=n*r*r+(m+s.Rational(1,2))*(1-r)**2+al;c4=n*r*r
d2=(n+s.Rational(1,2))*r*r+2*D*r;d4=(n+D+s.Rational(1,2))*r*r
beta=(B*d4+k*c4)/(k*ell**2);gamma=b4+d4/(k*ell)
j0=(B*d4-a4*k*k*ell+d2*ell)/(2*k*ell**2);j1=d4/(2*k*ell);Js=j0+j1*U
fs=(b2-c4/ell**2-al/B**2-B*d4/(k*ell**2))/2
SS=s.Matrix([[aa+a4*U,u*v*Js/a,-v*Js],[u*v*Js/a,(m+beta*U)/a**2,u*(fs-j1*U)/a],[-v*Js,u*(fs-j1*U)/a,al/B**2+gamma*U]])
p0=(D+r*(n+s.Rational(1,2)))/k;p1=r*(n+D+s.Rational(1,2))/k;q1=(n*r+B*p1)/ell
fx=-m*h+(D+s.Rational(1,2))*l-p0-q1
Lx=s.Matrix([[u*v*(p0+p1*U),(-m+q1*U)/a,u*(fx-p1*U)]])
py=-(C+D+s.Rational(1,2))*l+A*h;pyp=A*h
kv=-C*l+A*h+m+(al+s.Rational(1,2))*h;kuv=h*(A+m+al+s.Rational(1,2));kz=-m*(1-r)+r*(D+s.Rational(1,2))-al-s.Rational(1,2)
qy=(-kz-k*pyp-B*kuv)/ell;fy=kv-qy
Ly=s.Matrix([[py+pyp*U,u*v*qy/a,v*(fy+kuv*U)]])
hxx=n*(1+U)*(1+V)+m+(D+s.Rational(1,2))*U*V+(1+V)/2
hxy=-u*v*(m+D+s.Rational(1,2));hyy=A*(1+U)*(1+V)+C*(1+V)+D+s.Rational(1,2)+m*U*V+(al+s.Rational(1,2))*(1+U)*V
G=s.zeros(5);G[:2,:2]=s.Matrix([[hxx,hxy],[hxy,hyy]]);G[0,2:5]=Lx;G[1,2:5]=Ly;G[2:5,0]=Lx.T;G[2:5,1]=Ly.T;G[2:5,2:5]=SS
ld=s.Matrix([u*v,-1,l,r*u*v,-r*a*v])
Srow=s.Matrix([0,0,(x-U)*v,-(B-V/t)*u,U-a*V/t])
Lrow=s.Matrix([-2*r*t*u,0,0,-r*r*t*u,a*r*r*t])
HD=s.zeros(5)
for ii,jj,val in [(0,2,t*u*v),(0,4,-t*u),(2,3,r*t*u*v),(2,4,-a*r*t*v)]:
    HD[ii,jj]=HD[jj,ii]=val
jactual=1+x*r-l/t
gauge=(Srow*Lrow.T+Lrow*Srow.T)/2
ck('entire_D_channel_modulo_one_exact_syzygy',s.diff(G,D)-ld*ld.T-gauge-jactual*HD)

W,X,Y,Z=s.symbols('W X Y Z')
physical=s.Matrix([X+r*u*Z,Y-h*u*W,u*W-v*Z/t,a*v*W-u*Z,u*v*W-B*Z])
ck('physical_contact_root_syzygy',(Srow.T*physical)[0])
Devent=u*W+u*v*X-Y-v*Z
ck('centered_D_row_full_original_event',(ld.T*physical)[0]-Devent-jactual*v*Z)
ck('full_parent_identity_with_all_normals',((physical.T*(G-D*ld*ld.T-G.subs(D,0)-D*jactual*HD)*physical)[0]))

# Normalize n and A first, then solve R1 through the centered D root.
# sr=sqrt(r), sh=sqrt(h), sd=1/sqrt(D), nn=sqrt(nr), aa=sqrt(Ah).
sr,sh,sd,nn,aa,dj,mu,ca,Qstar=s.symbols('sr sh sd nn aa Dj mu alphastar Qstar', positive=True)
G0=G.subs(D,0)
fsreg=(a*Qstar-c4*a*a-B*t*d4.subs(D,0)*a*a)/2
G0reg=G0.copy()
G0reg[3,4]=G0reg[4,3]=u*(fsreg-j1.subs(D,0)*U)/a
Qdefinition=(b2-al/B**2)/a
ck('regular_a_opening_rewrite_preserves_full_matrix',G0-G0reg.subs(Qstar,Qdefinition))

Pmap=s.Matrix([[sr/nn,0,0,0,0],[0,sh/aa,0,0,0],
              [-u*v*sr/(nn*(1-sh*sh)),sh/(aa*(1-sh*sh)),sd/(1-sh*sh),
               -sr*sr*u*v/(1-sh*sh),sr*sr*a*v/(1-sh*sh)],
              [0,0,0,1,0],[0,0,0,0,1]])
subs={n:nn*nn/sr**2,A:aa*aa/sh**2,r:sr*sr,h:sh*sh,m:a*a*mu,al:B*B*ca}
source_matrix=(G0reg+dj*HD).subs(subs).applyfunc(s.cancel)
normalized=(Pmap.T*source_matrix*Pmap).applyfunc(s.cancel)
normalized[2,2]+=1
regular_corner={sr:0,sh:0,sd:0,B:0,a:0,t:1}
for ii in range(5):
    for jj in range(ii,5):
        den=s.denom(s.cancel(normalized[ii,jj]))
        assert s.cancel(den.subs(regular_corner))!=0,(ii,jj,den)
checks['all_15_normalized_entries_have_unit_denominators_at_joint_opening']=True
print('PASS all_15_normalized_entries_have_unit_denominators_at_joint_opening',flush=True)
res=normalized.subs({u:0,v:0,sr:0,sh:0,sd:0,B:0,t:1})
ck('entire_normalized_Gram_strict_residue',res-s.diag(1,1,1,mu,ca))

# The only new a denominator: exact source cancellation with no j or D.
cab=1+a*B*r; SrcS=1+B*(1-h+a*r)
gg=1+a*(h*B+r-1)
Delta=a+(1+a*B)+(1+a*B)*B+2*a*B*(1+a*B)*r+a**3*B**2*r*r+2*a*a*B*r+t*B*(1+a+a*B+a*a*B*r*(2-r))
Mstar=(1+a*B)*(1+a*r)*(h+t)-a*(1+t*B)*(1-r)*(1-h)
Nexact=((1+a*r)*cab*SrcS-r*Delta)/(2*Delta)
muexact=(1+t*B)*(1-r)*cab*SrcS/(2*gg*Delta)
Cexact=cab*Mstar/(2*(1-h)*Delta)
Ahexact=t*cab*(1+a*r)*SrcS/(2*Delta)
Djexact=(1+a*B)*(1+a*r)*(1-a*t*B*r)*SrcS/(2*t*Delta)
caexact=(1+a*r)*Mstar/(2*(1-h*B)*Delta)
corner={B:0,h:0,r:0,t:1}
for name,expr,target in [
 ('nr',Nexact,1/(2*(1+a))),('Ah',Ahexact,1/(2*(1+a))),
 ('Dj',Djexact,1/(2*(1+a))),('mu',muexact,1/(2*(1-a*a))),
 ('C',Cexact,(1-a)/(2*(1+a))),('alphastar',caexact,(1-a)/(2*(1+a)))]:
    ck('joint_R8_source_residue_'+name,expr.subs(corner)-target)
sourceb2=2*a*a*muexact*h+Cexact*(1-h)**2+Ahexact*h+(B*B*caexact+s.Rational(1,2))*h*h
ck('Qstar_exact_a_zero_cancellation',(sourceb2-caexact).subs(a,0))
num,den=s.fraction(s.cancel(sourceb2-caexact))
quo,rem=s.div(s.Poly(num,a),s.Poly(a,a))
assert rem.is_zero
checks['Qstar_numerator_divisible_by_a']=True
den0=s.factor(den.subs(corner))
ck('Qstar_unit_denominator_through_joint_j_r_h_opening',den0-2*(a-1)*(a+1))
ck('Qstar_exact_divided_expression',quo.as_expr()/den-(sourceb2-caexact)/a)
ck('Qstar_joint_residue_zero',quo.as_expr().subs(corner))

payload={'status':'PASS','count':len(checks),'checks':checks,
 'scope':'Complete R8 r-infinitesimal local parent at all independently infinitesimal or zero u,v, all states; exact D-syzygy gauge and strict normalized Gram',
 'imported_dependencies':['exact full six-contact WA3-WA8 identity','finite separated lift WA10'],
 'source_openings':'B,h,j,r positive infinitesimal independently; a bounded with residue <1; no relative-rate restriction',
 'seconds':round(time.monotonic()-started,3)}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
print(f'{len(checks)} new focused exact checks passed in {payload["seconds"]} seconds',flush=True)
