"""Build the integrated proof using an installed LaTeX distribution."""
from pathlib import Path
import subprocess
root=Path(__file__).resolve().parent
for _ in range(2):
    subprocess.run(["pdflatex","-interaction=nonstopmode","-halt-on-error", "Q222_R16_Analytical_Proof.tex"],cwd=root,check=True)
