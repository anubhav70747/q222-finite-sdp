#!/usr/bin/env python3
"""Small exact checks for the bounded-shape one-weak C2 theorem.

No Groebner basis, source search, test-point sampling, or rate comparison.
The analytical bounded-division and strict-Gram arguments are in the TeX.
"""
from pathlib import Path
import json
import sympy as s
if not __debug__:
    raise SystemExit('Run without -O: assertions are proof checks.')
checks=[]
def eq(name, lhs, rhs=0):
    assert s.factor(lhs-rhs)==0, name
    checks.append(name)

# Original source, in the general single-angle scaling.
x,k,b,r,h=s.symbols('x k b r h')
a2=k*k/x; t=x*(b-h)/(k*k)
g=b-1+r+x*h; j=1+x*r-t; Ac=1+x*r; Sc=Ac+a2*x*t
Delta=(1+x)*x*b*b+2*x*(1+x)*b*r+(1+x)*(1+a2*x)*b
Delta+=x*x*(1-a2)*r*r+2*x*(1+a2*x)*r+1+a2*x
Num=(1+x)*(b+r)*(b+a2*(1-t))-a2*(1+a2*x)*(1-r)*t
n=((b+r)*Ac*Sc-r*Delta)/(2*r*Delta)
m=(1+a2*x)*(1-r)*Ac*Sc/(2*g*Delta)
C=Ac*Num/(2*a2*t*Delta)
A=a2*Ac*(b+r)*Sc/(2*h*Delta)
D=(1+x)*(b+r)*(b-a2*x*r)*Sc/(2*a2*j*Delta)
alpha=x*x*(b+r)*Num/(2*(1-x*h)*Delta)
delta0=(1+k*k)*(b+1)
n0=(b+r-r*delta0)/(2*r*delta0)
m0=(1-r)/(2*(b-1+r)*(b+1))
Cs=k*k*(b+r)/(2*(b-h)*delta0)
As=k*k*(b+r)/(2*h*delta0)
Ds=(b+r)*(b-k*k*r)/(2*k*k*delta0)
Es=k*k*(b+r)**2/(2*delta0)
for name,E,target in zip(('Delta','n','m','xC','xA','D/x','alpha/x'),
    (Delta,n,m,x*C,x*A,D/x,alpha/x),
    (delta0,n0,m0,Cs,As,Ds,Es)):
    eq('source residue '+name,s.cancel(E).subs(x,0),target)
eq('source gaps h',b-a2*t,h)
eq('source gaps g',(1+x)*b-(1-r+a2*x*t),g)
eq('positive N identity',Num,(1+x)*(b+r)*h+a2*(g+j+r*t*(1+a2*x)))
eq('eta residue',h/b,Cs/(Cs+As))
H0=lambda v:(4*n0+2)*(1+v*v)+4*m0
eq('graph contact correction residue',-r-(4*m0*b-(4*m0+2))/H0(k))

# Contact identities: evaluate amplitudes before inserting weights.
# Each derivative has been divided only by its known common rho or k
# factor for the purpose of checking a zero polynomial.
eq('contact F_W/rho',8*m*k*g+8*C*(1+k*k)*x*(b-h)/k-8*D*k*j-4*k*j)
eq('contact F_X/rho',-8*n*(1+x)*(1+k*k)*r-8*m*g-8*D*k*k*j
   +4*(-k*k*j+(1+k*k)*(1-r)))
eq('contact F_Y',8*m*x*k*g-8*C*(1+k*k)*x*(b-h)/k
   +8*A*(1+x)*(1+k*k)*x*h/k+8*D*k*j
   -8*alpha*(1+x)*k*(1-x*h)+4*(k*j-(1+x)*k*(1-x*h)))
eq('contact F_Z',-8*m*x*g+8*D*k*k*j+8*alpha*(1+x)*(1-x*h)
   +4*(k*k*j+(1+x)*(1-x*h)+x*(1+k*k)*(1-r)-(1+x)*(1+k*k)))

# Exact angular derivatives with contact amplitudes substituted first.
rho,u,v,W,X,Y,Z=s.symbols('rho u v W X Y Z')
nn,mm,CC,AA,DD,ee=s.symbols('nn mm CC AA DD ee')
du=1+u*u; dv=1+v*v
M=v*W-X+u*v*Y-u*Z; J=u*W+u*v*X-Y-v*Z
core=J*J+du*(v*Y-Z)**2+dv*(X+u*Z)**2-du*dv*Z*Z
F=4*nn*du*dv*X*X+4*mm*M*M+4*CC*dv*(u*W-Y)**2
F+=4*AA*du*dv*Y*Y+4*DD*J*J+4*ee*du*(v*Y-Z)**2+2*core
at={u:rho,v:k,W:rho*b/k,X:-rho*r,Y:x*h/k,Z:1}
weights={nn:n,mm:m,CC:C,AA:A,DD:D,ee:alpha}
for angle in (u,v):
    value=s.expand(s.diff(F,angle).subs(at,simultaneous=True))
    value=s.rem(value,rho*rho-x,rho)
    eq('contact angular '+str(angle),value.subs(weights,simultaneous=True))

# The scalar determinant identity on the entire positive logarithmic plane.
nu,mu,Q,E0,E2,z,S=s.symbols('nu mu Q E0 E2 z S')
H=nu*(1+z)+mu-1
bs=2*mu*(nu*(1+z)-1)/H
cs=2*(mu-1)*z*nu*(1+z)/H
d2=16*mu*mu*z*nu*nu*(1+z)**2/H**2
qs=Q*(1+z); es=E2*z+E0
det=(qs*S+cs)*(bs*S+es)-d2*S/4
laurent=2*Q*mu*(nu-1)*S/z+2*Q*mu*nu*S
laurent+=2*(mu-1)*nu*E2*z/S+2*(mu-1)*nu*E0/S
laurent+=Q*E0*(nu+mu-1)/z+Q*E2*nu*z
laurent+=Q*(E2*(nu+mu-1)+E0*nu)-4*mu*nu
eq('global Laurent determinant',H*det/((1+z)*S*z),laurent)

# The positive-quadrant uniqueness proof: balanced directed cycles.
Pp,Qq,Rr,tau,Tt=s.symbols('Pp Qq Rr tau Tt')
pair=Pp*(S/Tt+Tt/S-2)+Qq*(S+1/S-2)+Rr*(Tt+1/Tt-2)
forward=(Pp+tau)*S/Tt+Qq*S+Pp*Tt/S+(Qq+tau)/S
forward+=Rr/Tt+(Rr+tau)*Tt-2*(Pp+Qq+Rr)-3*tau
reverse=Pp*S/Tt+(Qq+tau)*S+(Pp+tau)*Tt/S+Qq/S
reverse+=(Rr+tau)/Tt+Rr*Tt-2*(Pp+Qq+Rr)-3*tau
eq('forward balanced three-cycle',forward,pair+tau*(S/Tt+1/S+Tt-3))
eq('reverse balanced three-cycle',reverse,pair+tau*(Tt/S+S+1/Tt-3))

# Exact leading contact; this binds its stationary zero to the source.
Qsrc=4*Cs*As/(Cs+As)
src={nu:2*n0+1,mu:2*m0+1,Q:Qsrc,E0:4*Es,E2:4*Ds}
for name,E in [('value',laurent),('S derivative',s.diff(laurent,S)),
               ('z derivative',s.diff(laurent,z))]:
    eq('Laurent contact '+name,E.subs({S:1,z:k*k}).subs(src,simultaneous=True))

# Generic graph scalar and full normals: keep scaled coefficients independent.
cn,cm,cC,cA,cD,ca,eta,gamma=s.symbols('cn cm cC cA cD ca eta gamma')
nr,mr=s.symbols('nr mr'); H=(4*nr+2)*dv+4*mr
Xg=4*mr*v*W/H+u*Z*(-(4*mr+2)/H+gamma)
Yg=eta*u*W
scaled={nn:cn,mm:cm,CC:cC/x,AA:cA/x,DD:x*cD,ee:x*ca}
Fg=F.subs(scaled).subs({X:Xg,Y:Yg},simultaneous=True)
LX=s.diff(F,X).subs(scaled).subs({X:Xg,Y:Yg},simultaneous=True)
FY=s.diff(F,Y).subs(scaled).subs({X:Xg,Y:Yg},simultaneous=True)
leading={x:0,u:0,cn:nr,cm:mr,gamma:0,eta:cC/(cC+cA)}
def axis_res(E):
    return s.factor(s.cancel(E).subs(leading,simultaneous=True))
fww=s.expand(Fg).coeff(W,2)
fzz=s.expand(Fg).coeff(Z,2)
fwz=s.expand(Fg).coeff(W,1).coeff(Z,1)
aq=x*(fww-fww.subs(u,0))/u**2
bq=(fzz-fzz.subs(u,0))/u**2
cq=fww.subs(u,0)/v**2
eq0=fzz.subs(u,0)/x
gq=fwz/(u*v)
expect=(4*cC*cA*dv/(cC+cA),(4*mr+2)*(H-4*mr-2)/H,
        4*mr*(H-4*mr)/H,4*cD*v*v+4*ca,-2*(4*mr+2)*(H-4*mr)/H)
for name,E,target in zip(('q','b','cbar','e','g'),(aq,bq,cq,eq0,gq),expect):
    eq('axis scalar '+name,axis_res(E),target)
eq('axis LX V leading',axis_res(s.expand(LX).coeff(W)/v))
eq('axis LX B leading',axis_res(s.expand(LX).coeff(Z)/u))
B2=8*dv*(cA*eta*du-cC*(1-eta))
FYrem=s.expand(FY-u*W*B2/x)
ew=s.cancel(FYrem.coeff(W)/u)
ez=s.cancel((FYrem.coeff(Z)-8*v*x*(cD-ca))/u**2)
eq('Y normal constant',s.cancel(FYrem.coeff(Z)).subs(u,0),8*v*x*(cD-ca))
eq('Y normal leading',axis_res(B2+x*ew))
assert s.cancel(ez).subs(x,0) is not s.nan
checks.append('Y normal residual quotient bounded (no x or u pole)')
den=s.denom(s.cancel(ez)); assert den.subs({x:0,u:0})!=0

# Special zero-zero corner permits n=0 exactly.
Hc=4*nn+4*mm+2; zeta=(4*mm+2)/Hc; xi=4*mm/Hc
et=cC/(cC+cA); eps=4*x*ca+4*nn*(4*mm+2)/Hc
corner=F.subs({CC:cC/x,AA:cA/x,DD:x*cD,ee:x*ca})
corner=corner.subs({X:xi*v*W-zeta*u*Z,Y:et*u*W},simultaneous=True)
czz=s.expand(corner).coeff(Z,2)
base=4*x*ca+eps*u*u+4*nn*zeta*zeta*u**4+4*x*cD*v*v
Bc=s.cancel((czz-base)/(u*u*v*v))
eq('corner exact v=0 scalar',czz.subs(v,0),base.subs(v,0))
eq('corner T pivot',Bc.subs({x:0,nn:0,u:0,v:0}),2)
assert s.denom(Bc).subs({x:0,u:0,v:0})!=0
lcx=s.diff(F,X).subs({CC:cC/x,AA:cA/x,DD:x*cD,ee:x*ca})
lcx=lcx.subs({X:xi*v*W-zeta*u*Z,Y:et*u*W},simultaneous=True)
eq('corner X normal at v=0',s.expand(lcx).coeff(Z).subs(v,0),-8*nn*zeta*u**3)
zrest=s.cancel((s.expand(lcx).coeff(Z)+8*nn*zeta*u**3)/(u*v*v))
assert s.denom(zrest).subs({x:0,u:0,v:0})!=0
checks.append('corner X normal uv^2 division bounded')
ly=s.diff(F,Y).subs({CC:cC/x,AA:cA/x,DD:x*cD,ee:x*ca})
ly=ly.subs({X:xi*v*W-zeta*u*Z,Y:et*u*W},simultaneous=True)
eq('corner large Y normal',8*dv*(cA*et*du-cC*(1-et)),8*dv*cA*et*u*u)
yr=s.expand(ly-u*W*(8*dv*cA*et*u*u)/x)
yz=s.cancel((yr.coeff(Z)-8*v*x*(cD-ca))/(u*u*v))
assert s.denom(yz).subs({x:0,u:0,v:0})!=0
checks.append('corner Y normal u^2 v division bounded')

# Four outer core identities, all independently polynomial.
p,q,R,L,B,V,T,N=s.symbols('p q R L B V T N')
dp,dq=1+p*p,1+q*q
sub={W:rho*(R+L)/u,X:B-u*Z,Y:rho*L}
cand=(1+du*v*v)*B*B+u*u*du*v*v*Z*Z-2*u*v*v*du*B*Z
cand+=2*rho*R*(u*v*B-du*v*Z)+rho*rho*R*R-2*du*rho*L*v*Z+du*rho*rho*v*v*L*L
eq('finite u unit v zero core',core.subs(sub,simultaneous=True),cand)
Jp=W+v*X-p*Y-p*v*Z
corep=Jp*Jp+dp*(v*Y-Z)**2+dv*(p*X+Z)**2-dp*dv*Z*Z
sub={W:rho*R+p*rho*L,Y:rho*L,Z:B-p*X}
cand=B*B+dp*v*v*X*X+2*rho*dp*R*v*X-2*rho*p*v*R*B+rho*rho*R*R
cand+=2*dp*rho*p*L*v*X-2*dp*rho*v*L*B+dp*rho*rho*v*v*L*L
eq('u infinity finite v core',corep.subs(sub,simultaneous=True),cand)
Jq=u*X-Z+q*(u*W-Y)
coreq=Jq*Jq+du*(Y-q*Z)**2+dq*(X+u*Z)**2-du*dq*Z*Z
sub={W:rho*(R+L)/u,Y:rho*L}
cand=(du+q*q)*X*X+du*rho*rho*L*L+u*u*q*q*Z*Z+2*u*q*q*X*Z
cand+=q*q*rho*rho*R*R+2*u*q*rho*X*R-2*q*rho*R*Z-2*du*q*rho*L*Z
eq('v infinity bounded u core',coreq.subs(sub,simultaneous=True),cand)
Jpq=q*W+X-p*q*Y-p*Z
corepq=Jpq*Jpq+dp*(Y-q*Z)**2+dq*(p*X+Z)**2-dp*dq*Z*Z
sub={W:rho*R+p*rho*L,Y:rho*L}
cand=(1+p*p*dq)*X*X+rho*rho*q*q*R*R+rho*rho*dp*L*L+q*q*Z*Z
cand+=2*rho*q*X*R+2*p*q*q*X*Z-2*rho*p*q*R*Z-2*rho*dp*q*L*Z
eq('both infinity core',corepq.subs(sub,simultaneous=True),cand)

report={'status':'PASS','checks':checks,'count':len(checks),
 'scope':'Exact bounded-shape one-weak C2 source domain in general_single_angle.tex; all independent projective tests, n>=0',
 'analytical_inputs':['strict bounded tensor Gram lemma','physical noncommuting-residue exit','monic contact division'],
 'limits':'No global one-weak classification; physical canonical source assumed; strictness and exhaustive dispatch proved in text'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
