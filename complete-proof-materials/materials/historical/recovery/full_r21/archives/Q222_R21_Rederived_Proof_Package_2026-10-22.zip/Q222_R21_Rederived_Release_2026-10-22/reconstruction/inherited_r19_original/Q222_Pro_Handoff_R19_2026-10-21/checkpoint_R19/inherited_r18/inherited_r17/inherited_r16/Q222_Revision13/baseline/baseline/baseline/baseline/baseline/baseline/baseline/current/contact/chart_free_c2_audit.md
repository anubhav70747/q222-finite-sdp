# Adversarial review: chart-free two-weak C2 entry

Reviewed `chart_free_c2.tex` against the current inherited radial and matching-strength theorems. No substantive mathematical gap found in the stated finite-contact domain. This is same-system review, not external peer review.

## Checks that could have broken the argument

1. **Core normalization.** With `M` the matrix of the displayed polynomial signed core and `L=Du Dv`, the stated square identity gives the eigenvalue bound `L-sqrt(L²+4uvL) >= -2uv`. Thus at a unit-state zero, `4 e_i L_i² <= 2uv`, exactly the displayed `e_i L_i² <= uv/2`. No factor of two is missing.

2. **Every matching mass really diverges.** The displayed witness annihilates the other three matching amplitudes exactly, so arbitrarily large coefficients on them cause no error. Its remaining signed contribution is exactly `-2 delta`, and its four complementary contributions are infinitesimal for fixed real delta. Even cycle rotations preserve the matching/complement partition. This covers a zero matching coefficient as well as a bounded positive one.

3. **Compact geometry is not being mistaken for relative geometry.** The normalized-probability argument supplies only the ordinary/zero/infinite alternative. The subsequent `sqrt(uv)` estimate is genuinely stronger. If `a=v/u` were unbounded, the first relative equation forces `sqrt(a) W` infinitesimal and the second forces `sqrt(a) Z` infinitesimal, since W and Z are bounded. Hence both state components vanish in residue, a contradiction. The reciprocal case is identical. Once a is a unit, the two residue equations force a=1 and W=Z in residue, with both nonzero. This establishes all later divisions by W and Z.

4. **The alpha rate is established before differentiation.** Direct expansion gives the stated polynomial `H/u²`. Its residue is zero at `(u,x,y,Z,q)=(0,0,0,1,1)`. The zero-contact equation and packet nonnegativity give `0 <= 4(alpha/u²) Du (u² q y-Z)² <= -H/u²`. The last square factor is a unit. Thus `alpha/u²` is infinitesimal without assuming any scaled stationarity equation or source formula.

5. **The inverse is pointwise and coefficient-side.** The local-coordinate Jacobian is bounded with determinant residue 2. A pointwise inverse over the coefficient field is sufficient to transform the exact stationary gradient. No inverse map over the tensor product, no uniform neighborhood, and no integration of a local chart are used. In particular no unbounded event coefficient is multiplied by an uncontrolled Taylor error: the entire matching part is exactly `4 sum e_i ell_i²` in these coordinates.

6. **Both gradients and their signs check.** In small-angle variables, the original-coordinate gradient of the scaled core has residue `(4,-4,0,-4)`. Multiplying the claimed ell-gradient `2(1,-1,-1,1)` by `J0^T` gives exactly that vector. Hence the matching products have residues `(-1,1,1,-1)/4`. At ordinary angles the coordinate Jacobian determinant is `2u(1+u²)²`; its transpose sends `2u(1,-1,-1,1)` to the correct original-coordinate gradient `(4u(1+u²),-4u(1+u²),0,-4u)`. The weak complementary gradients are bounded times C,alpha there. The strict signs of X,Y,Rm,RD follow.

7. **Every source gap is exact.** The definitions give `h=aY/(uZ)`, `g=Rm/(uZ)`, `j=-RD/(vZ)`, `r=-X/(uZ)`. Their positivity and infinitesimal size follow from the established signs and relative bounds. The identities `1-c²h=(Z-vY)/Z` and `b-a²c²r=a(W+vX)/Z` are exact and have positive unit residues. Normalizing the original state by Z then gives precisely the canonical state `(b/a,-cr,c(b/a-at),1)` used by the Cramer determinant.

8. **Uniqueness and positivity are not circular.** All factors of the inherited six-by-six determinant are nonzero once the gaps are proved. The source denominator is positive by the positive expansion below. The actual coefficients already solve the six stationary equations, hence equal the rational source. The positive identity for N then proves C,alpha strictly positive even if the initial hypotheses permitted literal zero. No positivity of the rational chart was assumed to obtain these signs.

9. **The all-tests imports match.** Small c gives exactly `thm:c2-radial-corner` and `cor:c2-radial-outer`: c,r,h,g,j positive infinitesimal and a,1-r,t units. Ordinary bounded-unit c gives exactly `cor:c2-ordinary-angle-radial` in `c2_matching_strength.tex`, whose proof supplies both sets of product bounds. These assertions include every independent testing angle and state; the pointwise coefficient-field argument has imposed no condition on the testing field.

## Exposition-only improvements

- At the final determinant step, either cite `eq:we-positive-Delta` explicitly or display
  `Delta = 1+(1+z)b+z(1+z)b²+2z(1+z)br+z²r²+2zr + a²z[(1+z)b+1+zr(2-r)]`.
  Its nonnegativity uses the already proved `0<r<1`; thus `Delta>=1` is transparent despite the negative-looking term in the original expansion.
- Name the final inherited corollaries explicitly: `cor:c2-radial-outer` for small c and `cor:c2-ordinary-angle-radial` for ordinary c.
- Optionally say that a complex actual kernel can be replaced by a nonzero real kernel part, since the parent matrix is real and positive semidefinite. Alternatively state at the outset that the canonical actual contact is real, as in the existing source reduction.

The result does remove the complete two-weak-complementary-event C2 finite-contact source-entry obligation. It does not claim that one weak complementary event forces the other to be weak, or settle source domains without an actual finite noncommuting contact.
