"""Small exact source-based identities for unit-eta C1 extension.
No numerical sampling; source polynomial reconstruction takes a few seconds.
"""
from pathlib import Path
import sys,json,time
sys.path.insert(0,str(Path(__file__).resolve().parent))
from source_from_formulas import Poly,variables,reconstruct_source
from arithmetic import subtract
start=time.perf_counter()
delta,k,b,a,t,u,w,v=variables(8)
eta=b*b;r=1-a*eta;H=r+eta;rho=r*H-1
A=w*v;B=delta*v;C=delta*eta*u*w;D0=delta**2*k**3*eta
x=B-C;y=A-k*C;z=u*B-k*C;h=k*C-D0
q2=A*u*B+k*C*D0-2*k*k*B*C
T4=y*y+z*z+h*h-2*y*z+2*q2
source=reconstruct_source();E=Poly(subtract(source['scalar_terms'],source['leading_terms']),8)
L1,L2=(Poly(q,8)for q in source['linears_terms'])
weights=(1,1,0,0,0,1,2,3)
def wt(poly):return min((sum(x*y for x,y in zip(m,weights))for m in poly.terms),default=None)
def truncate(poly,cap):return Poly({m:c for m,c in poly.terms.items()if sum(x*y for x,y in zip(m,weights))<=cap},8)
assert not (truncate(E,10)-8*rho*T4+8*(rho+eta)*k*k*x*x).terms
assert not (truncate(L2,5)-16*eta*x).terms
assert not truncate(L1,5).terms
report={'status':'passed','identities':['E_le10=8(rH-1)T4-8(rH-1+eta)k²x²','L2_le5=16eta*x','L1_le5=0'], 'weights':weights,'remaining_minimum_weights':{'scalar':wt(E-8*rho*T4+8*(rho+eta)*k*k*x*x),'L1':wt(L1),'L2':wt(L2-16*eta*x)},'source_terms':len(E.terms),'seconds':time.perf_counter()-start}
assert report['remaining_minimum_weights']['scalar']>=12
assert report['remaining_minimum_weights']['L1']>=6
assert report['remaining_minimum_weights']['L2']>=6
Path(__file__).with_name('unit_eta_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
