import sympy as s
p,v,H,q,y,K,j,X,Y,ED,Em,D,m=s.symbols('p v H q y K j X Y ED Em D m',nonzero=True)
den=1-p*p*v*v
aJ=p*Y*(1-y*j/H)-v*X
aM=p*X-v*Y*(1-q*K/H)
W=s.expand(aJ-p*v*aM)/den
Z=s.expand(p*v*aJ-aM)/den
for nm,ex in [('Cgraph',(W-p*Y)*den),('alphagraph',(v*Y-Z)*den)]: print(nm,s.factor(ex),s.Poly(s.expand(ex),X,Y))
