import sympy as s,json
from pathlib import Path
u,v,k,c,E,Fcoef,e4,eta,r,nu,Q,q,a,h,xi=s.symbols('u v k c E Fcoef e4 eta r nu Q q a h xi')
x=k*k;y=x/c**2;U=u*u;V=v*v
At=u*v;Bt=c*k*V/u;Ct=x/c;G=k*v;d=Bt-G;J=At-Ct;F=V-y;p=c*k*v/u;Rc=p*E+d;RD=v*(U-x)
checks={}
def ck(n,ex):
 assert s.cancel(ex)==0,(n,s.factor(ex));checks[n]=True
ck('bare_difference_conductor',u*d-k*(c*F-J))
ck('dangerous_E_F_allocation',e4*x*v*E*F-(e4*k/c*u*Rc*F-e4*x*F*F+e4*x/c*J*F))
Hu=c*c*V/u-u
ck('scalar_radial_rescue',(Fcoef+e4*x)*F**2+e4*v*RD*F-((Fcoef+e4*(U+x))*F**2-e4*y*u*Hu*F))
Qt=r*E/eta+nu
ck('full_D_shift_cross_allocation',u*v*Qt-(r*U/(eta*c*k)*Rc-r*u/eta*F+r*u/(eta*c)*J+u*v*nu))
TD=RD-u*v*xi/h;b,P,Dp=s.symbols('b P Dp')
ck('centered_D_quadratic_packet_retained',Dp*(P-h*RD+u*v*xi)**2-Dp*(P-h*TD)**2)
j=s.symbols('j')
ck('complete_D_event_retained',Dp*(P-h*RD+u*v*xi-j*v/eta)**2-Dp*(P-h*TD-j*v/eta)**2)
ck('full_D_source_cross_shift',2*b*Qt*RD-(2*b*Qt*TD+2*b/h*u*v*Qt*xi))
Fbar=F+v*E;Hfull=Hu+c*c*v/u*E;Qn=Hfull-a*xi;D0=u-c*v;ll=s.symbols('lambda')
ck('full_Q_relation',Qn-(-D0+c/k*Rc-a*xi))
ck('full_principal_xi_cancellation',-2*eta*ll*c*k*Rc*xi+2*eta*ll*c*(RD-u*J)*xi-(-2*eta*ll*x*Qn*xi-2*eta*ll*x*a*xi*xi))
ck('full_radial_conductor',u*Rc-k*(c*Fbar-J))
ck('full_angular_radial_relation',U-x-(c*c*Fbar-u*Hfull))
ck('complete_e4_radial_group',e4*(U*Fbar**2+y*(U-x)*(Fbar+v*E))-(e4*(U+x)*Fbar**2-e4*y*u*Hfull*Fbar+e4*y*E*RD))
zeta=s.symbols('zeta');Bx=s.symbols('Bx')
margin=Bx*zeta*(1+zeta)/2+(1+zeta)**2/4-s.Rational(1,4)
ck('angular_margin_at_beta_zero',margin.subs(Bx,s.Rational(1,2))-zeta*(3+2*zeta)/4)
W,Y,theta=s.symbols('W Y theta');M=1+x*r-a*theta
Rm=v*W-xi-theta*u+u*v*Y
Qfull=a*v*W-u-a*xi
Ftilde=eta*v*Y/r-eta*x/a
ck('contact_centered_m_event',Rm-M*u/a-(Qfull/a+r*u*Ftilde/eta))
out={'status':'PASS','checks':checks,'count':len(checks),'scope':'Exact angular/radial conductors and positive source margin; contact-centered simultaneous D/m allocation remains, so C14.3b is not admitted.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
