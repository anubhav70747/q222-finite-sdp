"""Finite exact identities for QI1--QI10; no sampling or numeric bounds."""
import sympy as s,json,time
start=time.time();checks=[]
def ck(name,f):
 ok=s.factor(f)==0;checks.append({'name':name,'passed':ok});print(('PASS ' if ok else 'FAIL ')+name,flush=True)
 if not ok: print(s.factor(f));raise AssertionError(name)
z,r,t,U,V=s.symbols('z r t U V');Du=1+U;Dv=1+V;J=1-z*(1-r);S=1-r+t*V
a0=2*Dv*((1+z*r)*(1-r)+r/Du)+2*z*(S*S+V*r*r/Du)+2*z*z*S*S/J
b0=-4*(Du*(1+t*V)-U*r)-4*z*S*Du/J;c0=2*Du*Du/J
bp=b0+4*t*Du*V;X=a0+bp+c0;Y=-bp-2*c0
XV=2+2*z*r*(1-2*t)+2*z*(1+z*r)*t*t*V/J;YV=4*z*t/J
ck('exact q-zero X V coquotient',X.subs(U,0)-V*XV)
ck('exact q-zero Y V coquotient',Y.subs(U,0)-V*YV)
XU=s.cancel((X-X.subs(U,0))/U);YU=s.cancel((Y-Y.subs(U,0))/U)
ck('finite X difference identity',X-U*XU-V*XV)
ck('finite Y difference identity',Y-U*YU-V*YV)
b,u,v,h,c,g=s.symbols('b u v h c g',positive=True);C=u*v/b;E=h-v;F=v*h-c*c*g*g;A=c*h;D=c*c*g;G=c*s.sqrt(h*v)
sub={z:b*b,U:u*u,V:v*v};a0x=a0.subs(sub);b0x=b0.subs(sub);c0x=c0.subs(sub)
q0lift=c0x*E*E+XU.subs(sub)*(u*E+b*C)**2+YU.subs(sub)*u*(u*E+b*C)*E+XV.subs(sub)*(v*h)**2+YV.subs(sub)*v*(v*h)*E-4*t*(1+u*u)*v**3*h
ck('complete q-zero scalar lift',a0x*h*h+b0x*h*v+c0x*v*v-q0lift)
q,a1,b1,c1=s.symbols('q a1 b1 c1')
ck('q-part geometric-mean lift',q*(a1*h*h+b1*h*v+c1*v*v)-((a1-c1)*q*h*h+(b1+2*c1)*q*h*v+q*c1*E*E))
RF2=g*G/c**2*(G-D)**2;d4=D-G
ck('protected F square and first jet',s.expand((v*h)**2-(F*F+2*RF2+2*g*F*d4+g*g*D*D-4*g*g*G*d4)))
V0=c*v;RE2=G*(A+V0-2*G);d1=A-G
ck('E first-jet square lift',s.expand(c*G*E-2*G*d1+RE2))
ck('F first-jet square lift',s.expand(G*F+2*g*G*d4-RF2/g))
ck('strict E variance pivot',s.expand(c*c*E*E-4*RE2-(A+V0-2*G)**2))
T=1+b*b*c*c*(1-t*g*g)
Jstar=(T+b*b*t*v*v)*h-(1+u*u)*v
claim=E+b*b*c*(1-t*g*g)*A-b*u*C+b*b*t*v*F+b*b*t*v*g*D
ck('full centered D root in protected frame',Jstar-claim)
ss=(1+z*r*r)/(2*r*(1-r));delta=-z*r*r*(1-r)/(1+z*r*r)
ck('harmonic H coefficient q U V zero',8*ss*delta+4*r*z)
# Fully separated weighted conductor; optional remote/negative-t tool.
e=c/g;Q23=s.sqrt(e*h)*(v-c*g);Nh=h-s.sqrt(h*v)
ck('exact protected v conductor',s.expand(F-s.sqrt(v/e)*Q23-(v-c*g)*Nh-g*(A-D)))
open(__file__.replace('.py','.json'),'w').write(json.dumps({'passed':all(x['passed'] for x in checks),'checks':checks,'elapsed_seconds':time.time()-start},indent=2))
print(len(checks),'checks passed')
