#!/usr/bin/env python3
"""Exact compact scalar and complete centered-normal identities for R9.

Depends only on the new R15 scalar/source checker; no numerical assertions.
The independently checked full parent hardblock is in c1_contact.
"""
import runpy,json
from pathlib import Path
import sympy as s
p=Path(__file__).resolve()
g=runpy.run_path(str(p.parent.parent/'scalar/check_centered_scalar.py'))
checks={}
def ck(name,expr):
    z=s.cancel(expr)
    assert z==0,(name,s.factor(z))
    checks[name]=True
    print('PASS',name,flush=True)
# All exact source arrays and positive-unit denominator are reused unchanged.
for name in ('B','a','t','r','h','n','m','C','Ah','D','al','aw','b2','b4','d2','d4','e0','e1','qs','qt','cf','fb','fc','fg','weights','uden','nums'):
    globals()[name]=g[name]
def source_zero(name,expr):
    en,de=s.fraction(s.factor(expr));poly=s.Poly(en,*weights)
    assert poly.total_degree()<=1
    num=s.expand(poly.coeff_monomial(1)*uden+sum(poly.coeff_monomial(z)*nums[z] for z in weights))
    assert num==0,(name,'nonzero source polynomial')
    checks[name]=True
    print('PASS',name,flush=True)
KX=-n*r+(m+s.Rational(1,2))*(1-r)-a*qt
KE=aw/t**2-e0/t+a*qt/t
KY=(-(C+D+s.Rational(1,2))*(1-h)+Ah)/t+D-al
x3=2*((D+s.Rational(1,2))*((1-h)/t-1)+(1-r)/2-n*r*(1+a/t)-m*h/t)
x5=-2*r*(n+D+s.Rational(1,2))
aE=2*Ah*h/t**2-2*e1/t;bE=2*b2/t**2;cE=2*b4/t**2
aY=2*(Ah/t-m*(1-r)+r*(D+s.Rational(1,2))-al-s.Rational(1,2))
bY=2*(-C*(1-h)+Ah+m+(al+s.Rational(1,2))*h)/t
cY=2*(Ah+h*(m+al+s.Rational(1,2)))/t
x=a*B;y=t*B
source_zero('RC6_original_E_contact',2*KE+aE*x+bE*y+cE*x*y+2*fb*x)
source_zero('RC6_original_X_contact',2*KX+x3*y+x5*x*y-2*t*fb*x)
source_zero('RC6_original_Y_contact',2*KY+aY*x+bY*y+cY*x*y)
# Symbolic compact scalar, using the exact source balances checked above.
U,V,x,y,la,b4,d4,cf,t=s.symbols('U V x y lambda b4 d4 cF t',nonzero=True)
A2=U*V;B2=s.Symbol('Bc2');C2=x*y;G2=x*V
S=(la-2*d4*x-b4*y/t**2+d4*U+b4*V/t**2)*A2+la*B2+(la+b4*y/t**2)*C2-(3*la-d4*x+b4*y/t**2)*G2+cf*(V-y)**2
T=la*(A2+B2+C2-3*G2)+d4*V*(U-x)**2+(cf+b4*x/t**2)*(V-y)**2+b4/t**2*V*(U-x)*(V-y)
ck('RC2_exact_entire_scalar_remainder',S-T)
# Independent generic normal arrays; contact eliminates their constant terms.
u,v,k,c,t,la=s.symbols('u v k c t lambda',nonzero=True)
AE,BE,CE,AY,BY,CY,X3,X5=s.symbols('aE bE cE aY bY cY x3 x5')
x=k*k;y=k*k/(c*c);U=u*u;V=v*v;mu=t*t*c*c*k*k*la
ke=-(AE*x+BE*y+CE*x*y+2*la*x)/2
kx=-(X3*y+X5*x*y-2*t*la*x)/2
ky=-(AY*x+BY*y+CY*x*y)/2
A=u*v;Bc=c*k*v*v/u;Cc=k*k/c;G=k*v;d=Bc-G;J=A-Cc
Rad=v*(U-x);Fv=V-y;p0=c*k*v/u
RE=2*ke*v+2*mu*v**3/(t*t*u*u)+AE*U*v+BE*v**3+CE*U*v**3
RX=2*kx*u-2*mu*v*v/(t*u)+X3*u*v*v+X5*u**3*v*v
RY=2*ky*v+AY*U*v+BY*v**3+CY*U*v**3
ck('RC7_exact_centered_E',RE-(2*la*(p0+k)*d+(AE+CE*V)*Rad+(BE+CE*x)*v*Fv))
ck('RC8_exact_centered_X',RX-(-2*t*la*c*k*d+(2*t*la*c+X5*u*v)*Rad-2*t*la*c*u*J+u*(X3+X5*x)*Fv))
ck('RC9_exact_centered_Y',RY-((AY+CY*V)*Rad+(BY+CY*x)*v*Fv))
ck('xi_exact_centering_identity',x*u-c*k*G-(c*Rad-c*u*J))
E,xi=s.symbols('E xi')
L3=A*A+Bc*Bc+Cc*Cc-3*G*G
ck('RC10_circuit_difference_identity',L3-J*J-(1+2*k/p0)*d*d)
ck('RC10_complete_coupled_lift',la*L3+la*p0*p0*E*E+2*la*(p0+k)*E*d-(la*J*J+2*la*k/p0*(p0*E+d)**2+la*((p0-k)*E+d)**2-la*k*k*E*E))
ck('RC11_entire_unbounded_xi_cross',-2*mu*E*xi*v/(t*u)-2*t*la*c*k*d*xi-(-2*t*la*c*k*xi*((p0-k)*E+d)-2*t*la*c*k*k*E*xi))
ck('singular_rankrow_normalization',mu/(t*t)*(v/u)**2-la*p0*p0)
block=s.Matrix([[1,-1],[-1,t]])/(2*(t-1))
ck('RC12_positive_residue_determinant',block.det()-1/(4*(t-1)))
W,Z=s.symbols('W Z')
Eh=t*u*W-v*Z
ck('RC13_coupled_sum_without_testing_inverse',p0*Eh+d*Z-k*v*(t*c*W-Z))
ck('RC13_strict_coupled_root_without_testing_inverse',(p0-k)*Eh+d*Z-t*k*(c*v-u)*W)
ck('RC13_weighted_square_without_testing_inverse',2*la*k/p0*(p0*Eh+d*Z)**2-2*la/c*k*k*u*v*(t*c*W-Z)**2)
out={'status':'PASS','checks':checks,'count':len(checks),'dependencies':['../scalar/check_centered_scalar.py','../c1_contact/audit_r9_full_parent.py'],'scope':'R9 reciprocal contact: exact compact scalar, three original source contact balances, all centered normal identities, entire coupled-row and xi cancellation. Source positivity and tensor SOS are proved in companion text.'}
p.with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print('FINAL',len(checks),flush=True)
