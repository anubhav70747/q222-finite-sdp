#!/usr/bin/env python3
"""Boolean event-support census plus exact exclusion of rank-zero covariance."""
import itertools,json
from pathlib import Path
import sympy as s
HERE=Path(__file__).resolve().parent
d,la,n,m,c,A,D,al,be=s.symbols('d lambda n m c A D alpha beta',nonnegative=True)
syms=[la,n,m,c,A,D,al,be]
rows=[([1,1,0,0],8*la),([0,1,0,0],16*n),([1,-1,1,-1],4*m),([1,0,-1,0],8*c),([0,0,1,0],16*A),([1,1,-1,-1],4*D+2*d),([0,0,1,-1],8*al+4*d),([0,1,0,1],8*be+4*d),([0,0,0,1],-8*d)]
P=s.zeros(4)
for row,coef in rows:
    v=s.Matrix(row);P+=coef*v*v.T
t1=d+2*(la+n+D);t2=d+2*(al+m+A);t3=d+2*(la+c+D);t4=d+2*(al+be+m)
t5=d+2*(la+be+n);t6=d+2*(al+c+A);t7=d+2*(be+n+m);t8=d+2*(c+A+D)
outer={(-1,-1):4*la*al*t7*t8,(-1,0):4*(la*D*t7*t6+al*m*t5*t8),(-1,1):4*m*D*t5*t6,
 (0,-1):4*(al*A*t7*t3+la*n*t8*t4),(0,1):4*(be*m*t1*t6+c*D*t5*t2),
 (1,-1):4*n*A*t3*t4,(1,0):4*(be*n*t3*t2+c*A*t1*t4),(1,1):4*be*c*t1*t2}
out={}
for family,forced in [('C1',{la,n}),('C2',{la,be})]:
    free=[z for z in syms if z not in forced]
    patterns=[]; full_rank_balanced_supports=[]
    for mask in itertools.product([0,1],repeat=len(free)):
        supp={z for z,b in zip(free,mask) if b}
        assign={d:1,**{z:int(z in supp) for z in syms}}
        exps=[nu for nu,coef in outer.items() if coef.subs(assign)>0]
        if exps and s.Matrix(exps).rank()==2:
            normals=[(sign*(-a[1]),sign*a[0])for a in exps for sign in (-1,1)]
            separated=any(all(z[0]*a[0]+z[1]*a[1]>=0 for a in exps) and any(z[0]*a[0]+z[1]*a[1]>0 for a in exps)for z in normals)
            if not separated:
                required={m,c,A,al} if family=='C1' else {m,c,A,D,al}
                assert required<=supp,(family,supp,exps)
                full_rank_balanced_supports.append(supp)
        if not exps:kind='rank0'
        elif len(exps)==2 and exps[0]==tuple(-z for z in exps[1]):kind='rank1'
        else:continue
        patterns.append((supp,exps,kind))
    rank0=[a for a in patterns if a[2]=='rank0']
    maxzero=[a for a in rank0 if not any(a[0]<b[0] for b in rank0)]
    zero_proofs=[]
    for supp,exps,kind in maxzero:
        zero={z:0 for z in syms if z not in supp}
        determinant=s.Poly(s.expand(P.subs(zero).det(method='domain-ge')),d,*sorted(supp,key=str))
        coeffs=determinant.coeffs()
        assert all(q<=0 for q in coeffs), (family,supp,determinant.as_expr())
        assert determinant.coeff_monomial(d**4)<0
        zero_proofs.append({'maximal_unit_support':sorted(map(str,supp)),
           'det_P_at_1_1':str(s.factor(determinant.as_expr())),
           'all_coefficients_nonpositive_and_d4_negative':True})
    rank1=[{'unit_support':sorted(map(str,a[0])),'outer_exponents':a[1]}for a in patterns if a[2]=='rank1']
    out[family]={'rank0_pattern_count':len(rank0),'rank0_maximal_patterns_and_exact_exclusions':zero_proofs,
       'possible_rank1_balanced_patterns':rank1,
       'full_rank_balanced_support_pattern_count':len(full_rank_balanced_supports),
       'forced_unit_event_coefficients':sorted(map(str,set.intersection(*full_rank_balanced_supports)))}
assert out['C1']['possible_rank1_balanced_patterns']==[]
assert len(out['C2']['possible_rank1_balanced_patterns'])==1
assert out['C2']['possible_rank1_balanced_patterns'][0]['unit_support']==['A','D','m','n']
Pc2=P.subs({la:0,be:0})
compression=s.Matrix([[1,0],[0,1],[0,-1],[1,0]])
ss=c+al; qq=n+m+A+D
claimed=8*s.Matrix([[ss,ss+d],[ss+d,2*(qq+d)+ss]])
assert s.expand(compression.T*Pc2*compression-claimed)==s.zeros(2)
assert s.expand(claimed.det()-64*(2*ss*qq-d*d))==0
result={'status':'PASS','hypotheses':'Source coefficients normalized and bounded; d has positive residue; contact u,v have positive finite residues; exact stationarity; physical PSD for all testing angles',
 'conclusions':{'C1':'determinant covariance necessarily has positive definite residue',
 'C2':'determinant covariance necessarily has positive definite residue; only potential rank-one support is excluded by 2(c+alpha)(n+m+A+D)>=d^2'},
 'C2_compression':{'basis':[[1,0,0,1],[0,1,-1,0]],'matrix':[[str(q) for q in claimed.row(i)]for i in range(2)],'determinant':str(s.factor(claimed.det()))},
 'families':out}
(HERE/'RESIDUE_COVARIANCE_CENSUS.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
