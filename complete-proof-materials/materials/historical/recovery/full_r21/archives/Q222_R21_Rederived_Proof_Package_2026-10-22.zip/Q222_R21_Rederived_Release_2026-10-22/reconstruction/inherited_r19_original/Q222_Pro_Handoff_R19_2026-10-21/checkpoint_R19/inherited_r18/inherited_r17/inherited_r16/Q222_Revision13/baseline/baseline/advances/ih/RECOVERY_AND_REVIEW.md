# IH recovery and same-system review, 19 October 2026

The authoritative revision-4 archive was materialized and verified by the coordinating agent. The preserved IC3–IC12 proof and exact checker were copied from that archive. The subsequent weak-IH endpoint, remote, and open-axis arguments, and the strong-IH entry/local/remote arguments, were reconstructed from mathematical text supplied in the active collaboration. No lost historical execution receipt is asserted to have survived.

The completed mathematical scope is **C2.W.IH and C2.S.IH**, with all independent testing pairs, all state normals, n=0, arbitrary allowed source openings, and literal projective testing endpoints. This does not claim that the other seven original residual leaves are closed.

## Proof files

- `weak/inherited_ih_source_frontier.tex`: exact source entry and normalized estimates preserved from revision 4.
- `weak/inherited_ih_interior_corner.tex`: preserved interior-source local full-parent theorem, including IC7 and both normal factorizations.
- `weak/ih_source_endpoints.tex`: complete rho=0 and rho=1 source-residue corner extensions.
- `weak/ih_remote_charts.tex`: finite-second-angle and both-projective testing charts, including the n=0 remote join.
- `root/weak_ih_open_axis.tex`: ordinary first angle / infinite second angle; full X,Y normals and all source residues.
- `weak/ih_all_tests_join.tex`: explicit exhaustion and sign gauges.
- `strong/strong_angle_entry.tex`: positive source entry and exact coefficient formulas.
- `strong/ih_local_corner.tex`: full local Gram, explicit C packet cap, and large real conductor coefficient.
- `strong/ih_remote_charts.tex`: all remote charts, opening penalties, and exhaustive strong-IH join.

The original interior file's statements that its own theorem was only local remain unmodified as historical theorem scope. The new join supersedes the old all-tests frontier. The inherited bounded positive-residue Gram lemma, noncommuting-testing theorem, original canonical reduction and independent-field setup remain supplied by the preserved baseline; these notes do not replace those dependencies.

## Fresh exact executions

Executed using the primary Python runtime with SymPy from `.proof_dependencies`:

| Script | Exact checks passed |
|---|---:|
| `weak/check_ih_toric_gram.py` | 15 |
| `root/check_weak_ih_open_axis.py` | 11 |
| `root/check_source_limits.py` | 26 |
| `root/check_endpoint_local.py` | 10 |
| `root/check_remote_charts.py` | 20 |

The source-residue checker cancels only common small-parameter monomials, then verifies a nonzero denominator at the simultaneous residue. Weak endpoint denominators are nonzero constants. Strong denominators are nonzero constants times positive powers of B, which the entry theorem proves is a bounded positive unit. This explicitly covers simultaneous limits of all source openings; it is not a numerical or iterated-limit test.

The checks establish exact polynomial/rational identities and residue determinant formulas. Positivity, boundedness, quantifier scope and coverage are proved in the texts, not inferred solely from checker success. During reconstruction an omitted finite 2w² term in an intermediate X-quadratic checker expectation was corrected; the full displayed residue and theorem were unaffected. No known failed identity remains in these receipts.

## Same-system mathematical review

The coordinating agent reviewed the weak open-axis Gram, strong remote matrices and source denominator receipts. The UI recovery agent separately within the same assistant system reviewed the weak endpoint D-square removal, all local normal divisions, the strong C-packet cap and local determinants. Its substantive clarification was incorporated: subtracting the shifted D-square changes the X/Y monic-polynomial constants by −2De and +2De, respectively; the monic quotient coefficients are unchanged. These are same-system reviews, not independent verification.

The present author also checked the open-axis allocation directly, reran IC7 and its full normal identities, and recomputed the remote full normals and strong opening determinants. No mixed source/testing inverse or radical is used in the completed arguments. Real finite-dimensional inverses occur only in choosing a strict residue Gram or finite penalty.
