"""New C14.2 bounded-Bob source Gram and exact full-parent allocation."""
import json
from pathlib import Path
import sympy as S
L,r,s0,ss,c,u,W,X,Y,Z,P,T,f=S.symbols('L r s0 s c u W X Y Z P T f')
C=1/(2*L*(1-r)); A=(1+L*(1-r))/(2*L*r); al=L/(2*(1-L*r)); C1=C+(1-s0*s0)/2
M=S.Matrix([[C1,-C1,-s0/2],[-C1,C1+A+s0*s0*(al+S.Rational(1,2)),-al*s0],[-s0/2,-al*s0,al]])
checks={}
def ck(name,expr):
    assert S.cancel(expr)==0,name
    checks[name]=True;print('PASS '+name)
ck('strict_source_Gram_determinant',M.det()-(1-s0*s0)*(1+L*(1-r))**2/(8*L*r*(1-r)*(1-L*r)))
ck('source_Gram_second_minor',M[:2,:2].det()-C1*(A+s0*s0*(al+S.Rational(1,2))))
for value in M.cofactor_matrix():
    S.Poly(S.cancel(8*L*L*r*(1-r)*(1-L*r)*value),L,r,s0)
checks['all_source_inverse_cofactors_opening_regular']=True
print('PASS all_source_inverse_cofactors_opening_regular')
ee=1-r; cc0=1-s0*s0; BL=1+L*ee
Minv=S.Matrix([[2*L,2*L*r,2*s0],[2*L*r,2*L*r*(1-s0*s0*ee),2*s0*r*(1+L*ee*cc0)],[2*s0,2*s0*r*(1+L*ee*cc0),2*(1-L*r*cc0)*(1+L*ee*cc0)/L]])/(cc0*BL)
assert all(S.cancel(t)==0 for t in M*Minv-S.eye(3))
checks['explicit_opening_regular_source_inverse']=True
print('PASS explicit_opening_regular_source_inverse')
B0=(1-s0*s0)*(P-Y)**2+s0*s0*Y*Y-2*s0*P*T
K=(c*(P-Y)+u*ss*X-ss*Z)**2+(1+u*u)*(ss*Y-c*Z)**2+(X+u*Z)**2-(1+u*u)*Z*Z
K=K.subs(Z,(T+(ss-s0)*Y)/c)
Ktarget=X*X+B0+(ss-s0)*P*(-(ss+s0)*P+2*s0*Y-2*T)+2*u*c*X*(ss*P-s0*Y+T)+u*u*ss*ss*X*X+u*u*(s0*Y-T)**2
num=S.fraction(S.cancel(K-Ktarget))[0]
ck('complete_homogeneous_core_freezing_identity',S.rem(num,c*c+ss*ss-1,c))
Mform=(S.Matrix([P,Y,T]).T*M*S.Matrix([P,Y,T]))[0]
selected=f*(C*(P-Y)**2+A*(1+u*u)*Y*Y+al*(1+u*u)*(s0*Y-T)**2)+Ktarget/2
target=f*Mform+X*X/2+f*A*u*u*Y*Y+f*al*u*u*(s0*Y-T)**2+u*u*ss*ss*X*X/2+u*u*(s0*Y-T)**2/2+(1-f)*B0/2+(ss-s0)*P*(-(ss+s0)*P+2*s0*Y-2*T)/2+u*c*X*(ss*P-s0*Y+T)
ck('entire_selected_parent_freezing_and_factor_identity',selected-target)
payload={'status':'PASS','count':len(checks),'checks':checks,'scope':'C14.2 u infinitesimal and v bounded: exact source Gram, bounded inverse through openings, full core and all selected-parent errors; no reciprocal-corner closure.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
print(str(len(checks))+' focused checks passed')
