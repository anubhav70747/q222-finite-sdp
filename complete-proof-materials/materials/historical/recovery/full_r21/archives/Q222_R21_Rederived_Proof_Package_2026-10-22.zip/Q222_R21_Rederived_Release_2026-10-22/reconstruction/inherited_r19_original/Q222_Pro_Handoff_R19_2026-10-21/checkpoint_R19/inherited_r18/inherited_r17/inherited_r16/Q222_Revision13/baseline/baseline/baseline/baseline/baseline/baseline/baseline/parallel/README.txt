Q222 analytical advance - 17 October 2026

Read output/pdf/REGULAR_SOURCE_PROOF.pdf first (editable LaTeX source alongside).

NEW COMPLETE THEOREMS, INCLUDING EVERY INDEPENDENT TESTING REGIME
1. Physical C1/C2, normalized d a positive unit, actual source contact angles
   finite positive units: the full original parent is tensor SOS.
2. Physical C1, normalized d and D positive units, actual uc infinitesimal and
   vc a finite positive unit: the full original parent is tensor SOS.

The decisive construction in (2) uses the five features
  hX,hY,hZ,(u_test^2-uc^2)W,u_test(v_test-vc)W.
It is an exact full-polynomial identity with bounded Gram coefficients and
strict real residue. It is not a truncation or a plain polynomial-SOS claim.
No mixed inverse is used. Literal beta=0 is covered.

REMAINING IN THE NEW SHORTCUT
Weak-D one-weak-source C1 patterns; other degenerate C2 sources; doubly
commuting source corners; and normalized d of zero residue. Full weighted
parent allocation remains necessary there. The global affine pencil has not
been extracted. No global completion of this new shortcut is claimed.

PRESERVED PRIOR WORK
prior/Q222_Physical_Proof_Development_2026-10-15.zip contains the complete
recovered 58-member prior frontier, including the unchanged locked analytical
source PDF, prior scoped exact lifts and their coefficient arrays. Its own
manifest was verified on recovery. The historical global existence lock is
preserved; this pass does not claim a fresh audit of every old terminal.

DETAIL AND AUDIT
graph/ contains the finite-unit moving frame, its full 154-term exported Gram,
support census, exact weak-source family and adversarial audits.
newton/ contains the exact weighted identity, local weak-source proof and
source-rate analysis. rank_two/ contains physical opening floors, all C2
testing boundaries, and independent weighted-curvature/all-test audits.
root/ contains all-testing C1 proofs and exact boundary checks.

REPLAY
Use Python 3 with sympy==1.14.0 installed, then run python3 replay.py.
Eleven exact checks run, without numerical SDP or numerical sampling. The
saved receipt is NEW_EXACT_REPLAY.json. Rebuild the PDF by running pdflatex
twice on REGULAR_SOURCE_PROOF.tex with output directory output/pdf.

Audit standard: same-team analytical and exact symbolic verification.
External peer review and formal proof-assistant certification are not claimed.
