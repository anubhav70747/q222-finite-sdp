# A five-root full-parent admission at a weak C1 source angle

Date: 2026-10-17. This is a new local tensor-SOS theorem for the complete original parent. Its testing scope is stated explicitly below.

## Theorem and domains

Let `Kc,Kt` be the independent real closed source/testing fields of the locked proof. Normalize the nonnegative C1 coefficients by a positive pure-source trace factor, so that all are bounded. Assume:

1. `lambda=n=0`, and the source is physical for every signed real angle pair over `Kc`.
2. `d,D` have positive real residues.
3. The source has an actual zero contact `(uc,vc,psi_c)`, with `uc>0` infinitesimal and `vc>0` a bounded unit.
4. On the independent testing side, `u` is infinitesimal and `v-vc` belongs to the tensor residue ideal. Equivalently `v` is bounded and its real residue equals the residue of `vc`. No source/testing rate comparison is imposed.

Then the full C1 polynomial parent `F`, on every testing state, is a finite sum of tensor squares. Literal `beta=0` is permitted. The proof supplies a bounded Gram matrix with strictly positive real residue on five explicit roots.

This theorem does not cover testing angles with a different nonzero real residue of `v`, projective testing ends, weak `D`, two weak source angles, or weak normalized `d`.

## 1. Forced units and the correct quartic source scale

Put `p=uc^2`, `w=vc^2`. Exact logarithmic U-stationarity gives

    q01+q02 w = p^2 (q21+q22 w).

Write `Q=q21+q22 w`. Then `Q` has positive residue. Indeed `q01,q02` are weak from this equality, and V-stationarity gives in residue `q10=w^2 q12`. If `Q` were weak, the residue support would be a vertical antipodal pair or empty. The coefficient product identities exclude the pair in C1, while the explicit integer physical witnesses in FINITE_UNIT_COVARIANCE.md exclude empty support.

Since `Q=4c t1(A t4+beta t2 w)` is a unit, `c` is a unit. Since `D` is a unit, so is `q12`, and V-stationarity then makes `q10` a unit. Thus `alpha,A,c,D` all have positive residues. Finally

    m/p^2 = Q/[4 t5(alpha t8+D t6 w)]

is a positive bounded unit. In particular the weak original event `m` has exactly the quartic scale `uc^4`. No opening is inverted except this displayed nonzero pure-source unit denominator.

The residue original matrix at `u=0,v=vc` has kernel exactly the W-axis and a positive definite XYZ principal block. The core gives strict X,Y energy, while strong D/alpha events give strict Z energy. First normalize the nonzero projective contact state to Euclidean norm one using a pure-source square root. Its residue is nonzero and lies on the W-axis, so its W coordinate is a unit. Now divide by that coordinate:

    psi_c=(1,x,y,z).

This normalization is by a pure-source unit. The contact equations and the hard-block inverse in the source field imply, coefficientwise in valuation order,

    x=O(p),   y=O(uc),   z=O(uc).

For completeness, the hard X-to-YZ couplings are `O(uc)`, its W-to-X forcing is `O(p)+O(m)=O(p)`, and W-to-YZ forcing is `O(uc)`. Solving the bounded, residue-PD hard block first gives `y,z=O(uc)+O(uc*x)`, then `x=O(p)+O(p*x)`, hence the asserted bounds.

## 2. A bounded parity transport of the complete state

Define the exact source/testing vector

    q(u)=(1,x,u*y/uc,u*z/uc),
    h=(X-xW, Y-u*y/uc*W, Z-u*z/uc*W).

The quotients `y/uc,z/uc` are bounded pure-source elements. This is a triangular state congruence of determinant one. Write the entire original polynomial exactly as

    F=h^T A(u,v) h+2 W b(u,v)^T h+W^2 f(u,v),

where A is the original XYZ principal block, `b=(P q)_XYZ`, and `f=q^T P q`. Every coefficient is bounded in the specified source/testing corner, and `res(A)` is positive definite.

Original parity `(u,Y,Z)->(-u,-Y,-Z)` implies that `f` is a polynomial of degree at most two in `U=u^2` and at most two in `v`:

    f(U,v)=k0(v)+U k1(v)+U^2 k2(v).

Moreover the exact constant term is

    k0(v)=4m(v-x)^2+(4beta+2d)(1+v^2)x^2.

Thus every coefficient of `k0/p^2` is bounded. This uses both the forced scale `m=O(p^2)` and `x=O(p)`; it is not a Taylor-jet premise.

## 3. An exact weighted ideal-square identity

Put

    delta=v-vc,  s=U-p,  t=u delta,  j=p delta=u t-s delta.

All five final roots will be `(hX,hY,hZ,sW,tW)`. The auxiliary `j` is already a bounded linear combination of `s,t` in this testing corner.

Contact zero and stationarity give `f(p,vc)=f_U(p,vc)=f_v(p,vc)=0`. Define the following pure-source coefficients:

    C=k2(vc), B=k2'(vc),
    r=[k1'(vc)+p k2'(vc)]/p = -k0'(vc)/p^2,
    a0=k0''/(2p^2), a1=k1''/2, a2=k2''/2.

They are all bounded. Here `k_i''` are constant because the k_i have degree at most two. The following is an exact polynomial identity, including every higher term:

    f=C s^2+B u s t+r s j+a0 j^2+(a1+a2 U)t^2.       (1)

After substituting `j=u t-s delta`, this is a bounded two-root Gram representation. Its residue diagonal is `(res(C),res(a1))` and its off-diagonal vanishes, because `u,delta` are infinitesimal. No mixed inverse is present.

The state-cross polynomials have equally simple exact membership. Parity gives

    bX=bX0(v)+U bX1(v),
    bY=u[bY0(v)+U bY1(v)],
    bZ=u[bZ0(v)+U bZ1(v)].

All coefficient polynomials are bounded; `bX0` is coefficientwise `O(p)` because it comes from `m`, `x`, and the constant-U hard block. Since `b(p,vc)=0`, polynomial division only by `v-vc` gives bounded polynomial coefficients B_i,R_i such that

    bX=s B_X(v)+p delta R_X(v)
      =s[B_X(v)-delta R_X(v)]+u t R_X(v),

    bY=u s B_Y(v)+t R_Y(v),
    bZ=u s B_Z(v)+t R_Z(v).                           (2)

For bX, divide `[bX0(v)+p bX1(v)]/p` by `v-vc`; its coefficients are bounded and its value at `vc` vanishes. For bY,bZ, divide `b_i0(v)+p b_i1(v)` by `v-vc`. These divisions are polynomial remaindering at a bounded source point, not inversion of a mixed element.

Equations (1)-(2) construct an exact bounded symmetric five-by-five Gram G for the complete F on the stated five roots.

## 4. Strict positivity of the full residue Gram

Do not infer strictness from the soft diagonal alone. The hard/state crosses are retained. Since `A_X,YZ=O(u)`, the residue Gram splits into two blocks:

    (hX,sW)    and    (hY,hZ,tW).

The first hard Schur complement has residue

    res[ det(P)_{UU}(uc,vc) / (2 det(A(uc,vc))) ].      (3)

To check this, ordinary source-field Schur differentiation at the actual contact is legitimate: `b=f=0` there. In U differentiation, `bY_U,bZ_U=O(uc)`, while `bX_U` tends exactly to the hX-s coefficient. The derivative therefore leaves precisely the first residue block's Schur complement.

The second hard Schur complement has residue

    res[ det(P)_{vv}(uc,vc) / (2p det(A(uc,vc))) ].    (4)

Indeed `bX_v=O(p)`, whereas `bY_v/uc,bZ_v/uc` tend to the hY/hZ-t coefficients. Also `f_vv/(2p)` tends to `a1`, since `k0''=O(p^2)` and p is weak.

For the exact cleared determinant `det P=16(1+U)^2(1+V)^2 D(U,V)`, where `D=sum qij U^i V^j`, contact zero and stationarity give

    D_UU(p,w)=2w Q,
    D_vv(p,w)=8p N,
    N=q10/w=q02*w/p+q12*w+q22*p*w.

Both Q and N are positive units in this branch. The prefactor is a positive unit and `det(A(uc,vc))` is a positive unit. Consequently both (3) and (4) have strictly positive real residues. Together with the positive hard blocks, this proves `res(G)>0`.

The bounded-Gram lemma now converts the exact full-parent equality into tensor SOS. It permits the displayed roots themselves to have arbitrary size and requires only bounded coefficients and strictly positive residue Gram, which have just been proved.

## 5. Interpretation and verification scope

The weak source angle produces a quartic mode `u^2-uc^2`; the other angle enters multiplied by the testing opening `u(v-vc)`. Using the source weight `uc(v-vc)` alone would generally leave unbounded higher-term coefficients. Retaining the testing opening in the root makes the complete quartic polynomial admit bounded exact division.

The companion standard-library script verifies the universal identity (1), its five-root substitution, and the cross identities (2) as formal polynomial identities. The source unit arguments and the positivity of the residue blocks are the analytical proof above. This is a local weak-source admission theorem, not an all-testing or global C1 completion claim.
