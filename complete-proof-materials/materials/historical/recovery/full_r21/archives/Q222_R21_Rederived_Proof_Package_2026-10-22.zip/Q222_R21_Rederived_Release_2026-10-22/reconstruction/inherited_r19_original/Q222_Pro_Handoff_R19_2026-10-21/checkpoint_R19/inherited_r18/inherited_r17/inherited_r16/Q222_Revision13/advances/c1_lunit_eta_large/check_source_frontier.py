#!/usr/bin/env python3
import json
from pathlib import Path
import sympy as s
checks={}
def ck(name,expr):
    val=s.factor(s.cancel(s.together(expr)))
    if val!=0: raise AssertionError((name,val))
    checks[name]=True
x,L,r,h,eta=s.symbols('x L r h eta')
theta=1-h;K=1+x;T=1+x*h
p0=1+L+2*x*h+r*x*L+r*x*x*h
p1=K*L+x*x*h*theta
a2=K*L-T*p1
a1=K*(1+L*r)-T*p0+(1-r)*p1
a0=K*r+(1-r)*p0
b1=-L*h*r*x-L*h-L*r+L-h*h*r*x*x+h*h*r*x-3*h*h*x-2*h*r*x+h*x-3*h+1
ck('exact_negative_quadratic_coefficient',a2+x*h*(K*L+x*theta*(1+x*h)))
ck('exact_bounded_linear_coefficient',a1-x*b1)
Pd=p0+eta*p1;y=L*eta
B5=K*(1+y)*(r+eta)-(eta*T-1+r)*Pd
ck('exact_B5_decomposition',B5-a2*eta*eta-x*b1*eta-a0)
P,Y,H=s.symbols('P Y H')
C=1/(2*L*(1-r));A=(1+L*(1-r))/(2*L*r);al=L/(2*(1-L*r))
f=C*(P-Y)**2+A*Y*Y+al*(Y-H)**2+Y*Y/2-P*H
g=C*(P-Y-L*(1-r)*H)**2+(A+al+s.Rational(1,2))*(Y-L*r*H)**2
ck('leading_full_three_state_two_square_identity',f-g)

# An exact native source diagnostic for the failed unchanged C2-IH pivot.
ss=s.symbols('s',positive=True);bb=s.Rational(1,2)
xx=ss**2;ee=1/ss;rn=ss;hn=4*ss;th=1-hn;zet=bb/xx
kk=1+xx;rr=1+xx*rn;tt=1+xx*hn;gg=hn+zet;mm=rr-th/zet
jj=tt-(1-rn)/ee;en=1-xx*ee*hn;qq=1-bb*rn;yy=bb*ee
p4=tt*en+xx*(1-rn)*gg;pal=rr*hn*(1+yy)+zet*mm*en
pd=1+2*xx*hn+rn*xx**2*gg+xx*zet+ee*xx*(kk*zet+xx*hn*th)
b5=kk*(1+yy)*(rn+ee)-ee*jj*pd;bbet=kk*xx*(rn+ee)*gg-th*pd
cw=kk*(rn+ee)*en/(2*(1-rn)*pd);aw=ee*p4/(2*rn*pd)
dw=b5/(2*ee*jj*pd);mw=kk*xx*(rn+ee)*hn*(1+yy)/(2*mm*zet*pd)
alw=xx**2*zet*(rn+ee)*pal/(2*qq*pd);bw=bbet/(2*th*pd)
HH=bb*rn
kone=4*aw*HH**2+8*dw*HH*hn+4*alw*(1-HH)**2+4*mw*(HH+hn-1)**2+2*(HH+hn-1)**2+4*bw*(1-hn)**2
smallk=kone-4*bb**2*mw/xx**2+8*aw*HH**2/yy
for name,expr,target in [('C',cw,1),('A_scale',ss*aw,s.Rational(3,2)),
 ('D_scale',dw/ss**2,s.Rational(3,2)),('m_scale',mw/xx**2,4),
 ('alpha',alw,s.Rational(1,4)),('beta_scale',bw/ss,s.Rational(1,2)),
 ('failed_C2_scalar_pivot',smallk,-1)]:
 ck('diagnostic_'+name,s.cancel(expr).subs(ss,0)-target)
result={'status':'all_exact_checks_passed','count':len(checks),'checks':checks,'scope':'Source E~1 and leading quadratic identity only. No remaining full-parent domain is admitted.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'count':len(checks)}))
