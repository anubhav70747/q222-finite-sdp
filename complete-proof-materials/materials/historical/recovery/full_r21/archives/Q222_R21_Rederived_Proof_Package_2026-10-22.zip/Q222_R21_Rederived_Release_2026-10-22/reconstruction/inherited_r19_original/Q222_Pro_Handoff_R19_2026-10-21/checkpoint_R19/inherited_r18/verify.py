from pathlib import Path
import argparse,hashlib,json,subprocess,sys,shutil,tempfile
root=Path(__file__).resolve().parent
p=argparse.ArgumentParser();p.add_argument('--identities',action='store_true');a=p.parse_args()
if a.identities:
    receipt=json.loads((root/'VERIFICATION_R18.json').read_text())
    with tempfile.TemporaryDirectory(prefix='q222_r18_verify_') as tmp:
        copy=Path(tmp)/'proof_package'
        shutil.copytree(root,copy,ignore=shutil.ignore_patterns('__pycache__','*.aux','*.log','*.out','*.toc'))
        for name in receipt['executables']:
            print('Running',name,flush=True)
            subprocess.run([sys.executable,str(copy/name)],cwd=copy,check=True)
    print('PASS: focused new algebra. This does not prove global coverage.')
else:
    data=json.loads((root/'MANIFEST_R18.json').read_text())
    for item in data['files']:
        f=root/item['path']
        if hashlib.sha256(f.read_bytes()).hexdigest()!=item['sha256']:
            raise SystemExit('Integrity mismatch: '+item['path'])
    f=json.loads((root/'FRONTIER_R18.json').read_text())
    assert f['closed_C1_subbranches']==['C14.3a','C14.3b']
    assert f['open_C1']==['C14.1a','C14.1b','C14.2','C14.4']
    assert f['global_theorem']=='OPEN'
    for group in ('C1','weak_C2'):
        for branch in f[group].values():
            for evidence in branch.get('evidence',[]):
                assert (root/evidence).is_file(),evidence
    print('PASS:',len(data['files']),'file hashes and milestone accounting.')
