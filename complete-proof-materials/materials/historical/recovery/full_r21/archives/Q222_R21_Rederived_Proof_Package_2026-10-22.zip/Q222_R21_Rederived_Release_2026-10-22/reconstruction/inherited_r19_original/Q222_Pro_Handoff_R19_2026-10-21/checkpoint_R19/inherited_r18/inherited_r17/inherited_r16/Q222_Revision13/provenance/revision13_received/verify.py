#!/usr/bin/env python3
"""Revision-13 derivative integrity and focused exact replay.

This is not the unavailable verifier from the truncated input ZIP.
Default operation is read-only. Replays run in temporary directories.
"""
from pathlib import Path, PurePosixPath
import argparse, hashlib, json, os, re, shutil, subprocess, sys, tempfile
from concurrent.futures import ThreadPoolExecutor, as_completed
ROOT=Path(__file__).resolve().parent
IGNORED_SUFFIXES={".aux",".log",".out",".toc",".synctex",".gz",".pyc"}
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def require(test,message):
 if not test: raise RuntimeError(message)
def registry(): return json.loads((ROOT/"CHECK_REGISTRY.json").read_text())
def check_receipt(obj):
 checks=obj.get("checks",{})
 if isinstance(checks,dict): require(all(v is True for v in checks.values()),"A stored exact check did not pass.")
 else: require(all(isinstance(v,dict) and v.get("pass") is True for v in checks),"A stored exact check did not pass.")
 require(bool(checks),"Empty receipt.")
 require(obj.get("status","PASS")=="PASS","Nonpassing receipt status.")
 return len(checks)+len(obj.get("source_regularities",{}))
def inputs(entry):
 seen=set();todo=[entry]
 while todo:
  name=todo.pop()
  if name in seen: continue
  seen.add(name)
  path=ROOT/name
  require(path.is_file(),"Missing TeX input: "+name)
  text=path.read_text()
  for command,child in re.findall(r"\\(input|include)\{([^{}]+)\}",text):
   if "\\" in child or "#" in child: continue
   if not Path(child).suffix: child+=".tex"
   todo.append(child)
 return seen
def integrity():
 manifest=ROOT/"MANIFEST.sha256"
 require(manifest.is_file(),"MANIFEST.sha256 is missing; this is not a completed release package.")
 listed={}
 for line in manifest.read_text().splitlines():
  sha,name=line.split("  ",1)
  q=PurePosixPath(name)
  require(not q.is_absolute() and ".." not in q.parts,"Unsafe manifest path.")
  require(name not in listed,"Duplicate manifest member: "+name)
  path=ROOT/name
  require(path.is_file() and not path.is_symlink(),"Missing/nonregular manifest member: "+name)
  require(digest(path)==sha,"SHA-256 mismatch: "+name)
  listed[name]=sha
 actual={str(p.relative_to(ROOT)) for p in ROOT.rglob("*") if p.is_file() and
         p.name!="MANIFEST.sha256" and p.suffix not in IGNORED_SUFFIXES and
         "__pycache__" not in p.parts}
 require(actual==set(listed),"Manifest membership differs: "+str(sorted(actual^set(listed))[:8]))
 # The input ZIP was incomplete, but every completely recovered original
 # member must survive verbatim, either in place or in the preserved root.
 recovery=json.loads((ROOT/"provenance/RECOVERY_REPORT.json").read_text())
 source_prefix=PurePosixPath("Q222_Pro_Handoff_2026-10-19/Q222_Analytical_Revision_2026-10-18")
 recovered=0
 for member in recovery["recovered_complete_members"]:
  rel=PurePosixPath(member["name"]).relative_to(source_prefix)
  candidates=[ROOT/str(rel)]
  if len(rel.parts)==1:
   candidates.append(ROOT/"provenance/revision12_root"/str(rel))
  require(any(p.is_file() and digest(p)==member["sha256"] for p in candidates),
          "A recovered original member is missing or changed: "+str(rel))
  recovered+=1
 deps=inputs("Q222_Analytical_Revision_2026-10-18.tex")|inputs("Q222_Revision13_Results.tex")
 require(deps<=set(listed),"A mathematical input is not covered by the manifest.")
 old=json.loads((ROOT/"provenance/revision12_root/CHECKLIST.json").read_text())
 now=json.loads((ROOT/"CHECKLIST.json").read_text())
 require([x["id"] for x in old["work_items"]]==[x["id"] for x in now["work_items"]],"Original work-item identities changed.")
 for before,after in zip(old["work_items"],now["work_items"]):
  for key in ["task","completion_criterion","required_acceptance_gates"]:
   require(before[key]==after[key],"Original task/criterion changed: "+before["id"])
 require(now["global_status"]=="unfinished","Global status requires separate universal proof, absent in this release.")
 count=0
 for edition,entries in registry().items():
  if not isinstance(entries,list):continue
  for item in entries:
   obj=json.loads((ROOT/item["receipt"]).read_text())
   require(check_receipt(obj)==item["total"],"Receipt count mismatch: "+item["receipt"])
   count+=item["total"]
 result={"status":"PASS","sha256_members":len(listed),"tex_dependency_files":len(deps),
         "focused_registry_checks":count,"original_task_and_criterion_strings":"preserved",
         "recovered_original_members_preserved":recovered,
         "original_input_archive_complete":False}
 print(json.dumps(result,indent=2),flush=True)
 return result
def replay_one(item):
 with tempfile.TemporaryDirectory(prefix="q222-replay-") as temp:
  src=ROOT/item["script"]
  copy=Path(temp)/src.name
  shutil.copy2(src,copy)
  env=dict(os.environ)
  env["PYTHONDONTWRITEBYTECODE"]="1"
  run=subprocess.run([sys.executable,str(copy)],cwd=temp,env=env,
                     stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
  require(run.returncode==0,item["script"]+" failed:\n"+run.stdout[-6000:])
  out=copy.with_suffix(".json")
  require(out.is_file(),"Replay produced no receipt: "+item["script"])
  obj=json.loads(out.read_text())
  old=json.loads((ROOT/item["receipt"]).read_text())
  require(check_receipt(obj)==item["total"],"Replay count mismatch: "+item["script"])
  require(obj["checks"]==old["checks"],"Replay changed the named exact results: "+item["script"])
  require(obj.get("source_regularities",{})==old.get("source_regularities",{}),
          "Replay changed the finite source regularity audit: "+item["script"])
  if os.environ.get("Q222_WRITE_REPLAY")=="1":
   shutil.copy2(out,ROOT/item["receipt"])
  return {"script":item["script"],"status":"PASS","exact_checks":item["total"]}
def main():
 parser=argparse.ArgumentParser(description=__doc__)
 mode=parser.add_mutually_exclusive_group()
 mode.add_argument("--integrity-only",action="store_true",help="verify the complete derivative manifest and ledger/dependency consistency")
 mode.add_argument("--revision13-only",action="store_true",help="replay only the new revision13 exact scripts")
 mode.add_argument("--revision12-only",action="store_true",help="replay only the 20 revision12 checks")
 mode.add_argument("--with-sympy",action="store_true",help="replay this focused registry (revision12+13), not the unavailable historical full suite")
 mode.add_argument("--list-checks",action="store_true",help="show the focused replay registry")
 args=parser.parse_args()
 integrity()
 if args.list_checks:
  print(json.dumps(registry(),indent=2));return 0
 groups=["revision13"] if args.revision13_only else ["revision12"] if args.revision12_only else ["revision12","revision13"] if args.with_sympy else []
 if not groups:return 0
 try: import sympy
 except ImportError: raise RuntimeError("SymPy is required for algebra replay. Install requirements.txt in your Python environment.") from None
 entries=[x for group in groups for x in registry()[group]]
 results=[]
 with ThreadPoolExecutor(max_workers=3) as pool:
  tasks=[pool.submit(replay_one,item) for item in entries]
  for task in as_completed(tasks):
   result=task.result();results.append(result)
   print(json.dumps(result),flush=True)
 print(json.dumps({"status":"PASS","groups":groups,"scripts":len(results),
  "exact_checks":sum(r["exact_checks"] for r in results),"sympy":sympy.__version__,
  "stored_receipts_rewritten":os.environ.get("Q222_WRITE_REPLAY")=="1"},indent=2))
 if os.environ.get("Q222_WRITE_REPLAY")=="1":
  print("Receipts were deliberately rewritten. Regenerate MANIFEST.sha256 before packaging.",file=sys.stderr)
 return 0
if __name__=="__main__":
 try: raise SystemExit(main())
 except (OSError,ValueError,RuntimeError,KeyError) as exc:
  print("FAIL: "+str(exc),file=sys.stderr);raise SystemExit(1)
