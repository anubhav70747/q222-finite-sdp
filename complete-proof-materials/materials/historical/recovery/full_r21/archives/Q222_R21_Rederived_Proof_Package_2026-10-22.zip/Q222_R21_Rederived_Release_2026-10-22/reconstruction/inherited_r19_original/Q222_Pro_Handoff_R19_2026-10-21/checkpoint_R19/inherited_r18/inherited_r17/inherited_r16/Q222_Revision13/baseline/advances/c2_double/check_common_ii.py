#!/usr/bin/env python3
"""Exact identities only; this checker does not claim a tensor-SOS admission."""
import json
from pathlib import Path
import sympy as s

out = {}
def check(name, expr):
    value = s.cancel(s.together(expr))
    ok = value == 0
    out[name] = ok
    if not ok:
        raise AssertionError((name, s.factor(value)))

u,v,W,xi,eta,ze = s.symbols('u v W xi eta ze')
U,V,z,y,H,L,r = s.symbols('U V z y H L r')
n,m,C,A,D,al = s.symbols('n m C A D al')
B=H+L; ac=1+z*r; j=ac-L/y; q=H+r-1
du=1+u*u; dv=1+v*v
X=-r*u*u*v/B*W+xi; Y=H*u/B*W+eta; Z=u*v/B*W+ze
M=v*W-X+u*v*Y-u*Z; J=u*W+u*v*X-Y-v*Z
p=v*Y-Z; b=X+u*Z; c=u*W-Y
core=2*(J*J+du*p*p+dv*b*b-du*dv*Z*Z)
F=4*n*du*dv*X*X+4*m*M*M+4*C*dv*c*c+4*A*du*dv*Y*Y+4*D*J*J+4*al*du*p*p+core
Q=(4*m+2)*(xi+u*ze-u*v*eta)**2+(4*n*du*dv+2*du*v*v)*xi*xi+(4*C*dv+4*A*du*dv+2*dv)*eta*eta+4*D*(u*v*xi-eta-v*ze)**2+4*al*du*(v*eta-ze)**2
check('full_normal_quadratic',F.subs(W,0)-Q)

polys=[
 -4*n*(1+U)*(1+V)*r*U-4*m*(B+U*q)+(4*D+2)*U*(L-V*(1+r*U))+2*(1+V)*(1-r)*U,
 4*m*V*(B+U*q)-4*C*(1+V)*L+4*A*(1+U)*(1+V)*H-(4*D+2)*(L-V*(1+r*U))-(4*al+2)*(1+U)*V*(1-H),
 -4*m*(B+U*q)-(4*D+2)*(L-V*(1+r*U))+(4*al+2)*(1+U)*(1-H)+2*(1+V)*(1-r)*U-2*(1+U)*(1+V)]
As=[-4*n*r*(1+y)*(1+U+z)-4*m*q+(4*D+2)*(L-y*(1+r*(U+z)))+2*(1+y)*(1-r),
 4*m*y*q+4*A*H*(1+y)+(4*D+2)*r*y-(4*al+2)*y*(1-H),
 -4*m*q+(4*D+2)*r*y+(4*al+2)*(1-H)-2*r*(1+y)]
Bs=[-4*n*r*U*(1+U)-(4*D+2)*U*(1+r*U)+2*(1-r)*U,
 4*m*(B+U*q)-4*C*L+4*A*H*(1+U)+(4*D+2)*(1+r*U)-(4*al+2)*(1+U)*(1-H),
 4*D*(1+r*U)]
for idx,(pp,aa,bb) in enumerate(zip(polys,As,Bs)):
    check(f'first_normal_ideal_{idx}',pp-pp.subs({U:z,V:y})-(U-z)*aa-(V-y)*bb)
graph=F.subs({xi:0,eta:0,ze:0})
lin=2*W/B*(v*xi*polys[0].subs({U:u*u,V:v*v})+u*eta*polys[1].subs({U:u*u,V:v*v})+u*v*ze*polys[2].subs({U:u*u,V:v*v}))
check('all_state_normals_no_discard',F-Q-graph-lin)

f=n*r*r*U*(1+U)*(1+V)+m*(B+U*q)**2/U+C*L*L*(1+V)/V+A*H*H*(1+U)*(1+V)/V+(D+s.Rational(1,2))*(L-V*(1+r*U))**2/V+(al+s.Rational(1,2))*(1+U)*(1-H)**2+s.Rational(1,2)*(1+V)*(1-r)**2*U-s.Rational(1,2)*(1+U)*(1+V)
check('graph_laurent',graph-4*u*u*v*v*W*W/B**2*f.subs({U:u*u,V:v*v}))
p2=r*r*(D+n+s.Rational(1,2)); p1=2*D*r+n*r*r+r*r/2
P=p2*U*U+p1*U+D; q1=A*H*H; q0=A*H*H+(C+D+s.Rational(1,2))*L*L
d0=m*B*B; ay=n*r*r+y*p2; K=y*p2*(U+z)+y*p1-q1/y
f0=f.subs({U:z,V:y}); fu0=s.diff(f,U).subs({U:z,V:y}); fv0=s.diff(f,V).subs({U:z,V:y})
box=V*(U-z)**2*(ay*U+d0/z**2)+U*(V-y)**2*P+U*(U-z)*(V-y)*K
# The three contact residuals are kept visible in this generic identity.
check('angular_contact_ideal',U*V*f-box-U*V*(f0+(U-z)*fu0)-U*y*fv0*(V-y))
coeffs=s.Poly(s.expand(U*V*f),U,V)
expected={(2,1):p2,(2,0):n*r*r,(1,1):p1,(1,-1):q1,(0,1):D,(0,-1):q0,(-1,0):d0}
for ij,val in expected.items():
    check('laurent_coefficient_'+str(ij),coeffs.coeff_monomial(U**(ij[0]+1)*V**(ij[1]+1))-val)

delta=z+(1+z)*B+(1+z)*B*B+2*z*(1+z)*B*r+z**3*r*r+2*z*z*r+y*((1+z)*B+z+z*z*r*(2-r))
S=ac+L; G=B+z*(H+r-1)
Ms=(1+z)*(B+z*r)*(H+y)-z*(1+y)*(1-r)*L
src={n:((B+z*r)*ac*S-r*delta)/(2*r*delta),m:z*z*(1+y)*(1-r)*ac*S/(2*G*delta),C:ac*Ms/(2*L*delta),A:y*ac*(B+z*r)*S/(2*H*delta),D:(1+z)*(B+z*r)*(B-z*y*r)*S/(2*(y*ac-L)*delta),al:(B+z*r)*Ms/(2*(1-H)*delta)}
check('source_E_at_one',((B+z*r)*ac*S-r*delta).subs(r,1)+(H+y)*(B+z)*(1+z))
# Every contact residual is affine in the six weights.  Clear its common
# source denominator term by term; do not ask cancel() to multiply six
# rational denominators before discovering their common factors.
weights=list(src)
den=2*r*G*L*H*(y*ac-L)*(1-H)*delta*z*y
scaled={w:s.cancel(s.together(den*src[w])) for w in weights}
def source_check(name,expr):
    value=s.expand(s.cancel(s.together(den*expr.subs({w:0 for w in weights}))))
    for w in weights:
        value += s.expand(s.cancel(s.together(s.diff(expr,w)*scaled[w])))
    check(name,s.expand(value))
for idx,pp in enumerate(polys):
    source_check(f'original_source_kernel_{idx}',pp.subs({U:z,V:y}))
for name,expr in [('source_graph_zero',f0),('source_graph_U_derivative',fu0),('source_graph_V_derivative',fv0)]:
    source_check(name,expr)

ns,als=s.symbols('n_cap alpha_cap')
x0=-r*u*u*v/B; c0=L*u/B; p0=-(1-H)*u*v/B
PC=4*C*dv*eta*eta; PD=4*D*(J+y*j/B*u*W)**2
PN=4*(n-ns)*du*dv*xi*xi; PA=4*(al-als)*du*(v*eta-ze)**2
GC=4*C*dv*(c0*c0*W*W-2*c0*W*eta)
GD=-8*D*y*j/B*u*W*J-4*D*(y*j/B)**2*u*u*W*W
GN=4*ns*du*dv*X*X+4*(n-ns)*du*dv*(x0*x0*W*W+2*x0*W*xi)
GA=4*als*du*p*p+4*(al-als)*du*(p0*p0*W*W+2*p0*W*(v*eta-ze))
check('full_bounded_remainder_identity',F-PC-PD-PN-PA-GC-GD-GN-GA-4*m*M*M-4*A*du*dv*Y*Y-core)

result={'status':'all_exact_identity_checks_passed','checks':out,'count':len(out),'scope':'Common exact II source and full-parent reductions only. No remaining leaf admitted; boundedness and source-face claims require the accompanying analytical proof.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'count':len(out)}))
