"""Targeted exact C2/formal-C1 stress and new contact-zero n row."""
import sympy as s,json
from pathlib import Path
checks={}
def ck(name,ex):
 assert s.cancel(ex)==0,name;checks[name]=True;print('PASS',name,flush=True)
p,b,w,h,t=s.symbols('p b w h t');x=p*b;B=p*p*b;e=p*w;r=1-e;y=t*B;K=1+x;ca=1+x*r;Sc=1+B*(1-h)+x*r;g=1-w+h*x;j=ca-(1-h)/t
Dp=s.expand(1+(1+x)*p+(1+x)*B*p+2*x*(1+x)*r*p+x*x*r*r+2*x*r+t*B*(p+1+x*p+x*r*(2-r)))
Qstar=1+B*(1+t+h/p+2*r/p+t/p)+B*B*((h+t)/p+(h*(r+1)+t*(1+r-r*r))/(p*p));Kstar=(1+p)*(h+t)*K
n=p*p*(w*Qstar-b*Kstar)/(2*r*Dp)
R=1+x*h;T=ca;M=g;J=j;EE=1-x*t*r;QQ=1-x*p*h
P4=T*EE+x*(1-h)*(r+p);Pal=R*r*(1+y)+p*M*EE
Pd=1+2*x*r+h*x*x*(r+p)+x*p+t*x*(K*p+x*r*e)
M2=K*(p+r)*(h+t)-p*w*(1+y)*(1-h)
C2=ca*M2/(2*(1-h)*Dp);Ah2=t*ca*(p+r)*Sc/(2*Dp);m2=w*(1+y)*ca*Sc/(2*g*Dp);D2=K*(p+r)*(1-t*x*r)*Sc/(2*t*j*Dp);al2=p**3*b*b*(p+r)*M2/(2*(1-h*B)*Dp)
C1=K*(h+t)*EE/(2*(1-h)*Pd);Ah1=t*P4/(2*Pd);m1=K*x*(h+t)*r*(1+y)/(2*M*p*Pd);al1=x*x*p*(h+t)*Pal/(2*QQ*Pd);D1=(K*(1+y)*(h+t)-(t*T-1+h)*Pd)/(2*J*t*Pd);beta1=(K*x*(h+t)*(r+p)-e*Pd)/(2*e*Pd)
qpart=1+2*beta1;fac=s.cancel((1+2*n)/qpart);theta=n/B
Pkap=ca*ca+p*x*(1+t)+p*x*x*(r+h*e+t)
PD=t*x*x*r*r+x*((t-1)+e*(1-h-2*t))-1
PA=1+p-2*e+x*(r*r+p*(r+h*e))
ck('stress_m',m2-fac*m1)
ck('stress_C',C2-fac*C1+theta*ca/(1-h))
ck('stress_Ah',Ah2-fac*Ah1+theta*t*ca*Sc/(K*(h+t)))
ck('stress_D',D2-fac*D1-theta*Sc*PD/(K*(h+t)*t*j))
ck('stress_alpha',al2-fac*al1+n*x*PA/(K*QQ))
ck('stress_multiplier',fac-1-2*theta*Pkap/(K*(h+t)))
ck('stress_beta_half',-fac*beta1+(1-fac)/2+n)
ck('overlap_slack',-2*beta1-2*r*Dp*n/(p*p*w*Pd))
# Full original state polynomial n row. Kc is a positive pure source.
u,v,wt,Z,N,Kc,pp,rr,nn=s.symbols('u v wt Z N Kc pp rr nn', nonzero=True)
Du=1+u*u;Dv=1+v*v;Avec=v*wt;X=N+pp*Du*Avec-u*Z;gam=rr/Kc
new=nn*Du*Dv*(X+gam*Avec)**2
rem=2*nn*gam*Du*Dv*u*Avec*Z-(2*nn*gam*pp*Du+nn*gam*gam)*Du*Dv*Avec*Avec-2*nn*gam*Du*Dv*Avec*N
ck('entire_n_packet_after_contact_zero_row',nn*Du*Dv*X*X-new-rem)
kk,de,EE,tt=s.symbols('k delta E t');K=1+kk*kk;QQ=s.symbols('Q');RR=K*K/QQ;Kc0=de*de*EE*kk*kk;zeta=Kc0*QQ/K;rr0=1-tt*zeta
ck('new_n_row_exact_contact',(X+gam*Avec).subs({N:0,u:kk,Z:1,wt:de*kk,v:de*kk*kk*EE,pp:tt/RR,rr:rr0,Kc:Kc0}))
# Source weights of the n row in the two existing conductor charts.
rho,psi,eps,jj,ss=s.symbols('rho psi epsilon jj s',positive=True)
# Kc=s*K/Q, source w=theta1/zeta. These identities require no limit.
ck('n_gamma_squared_scale',(rho*(ss*w)**2)*(rr/(ss*K/QQ))**2-rho*w*w*rr*rr*QQ*QQ/(K*K))
# SE w=t_native=epsilon²*tau, s=zeta=j² Q E/K.
tau=s.symbols('tau');nse=rho*(jj*jj*QQ*EE/K)**2*(eps*eps*tau)**2;gse=rr/(jj*jj*EE)
ck('SE_n_row_A_squared_scale',nse*gse*gse/(eps*eps)-rho*eps*eps*tau*tau*rr*rr*QQ*QQ/(K*K))
ck('SE_n_row_normal_A_scale',nse*gse/eps-rho*eps**3*jj*jj*QQ*QQ*EE*tau*tau*rr/(K*K))
ck('SE_constant_stress_scale',nse*(eps*jj)**2/(eps**4*jj**6*EE**2)-rho*eps*eps*QQ*QQ*tau*tau/(K*K))
out={'status':'PASS','count':len(checks),'checks':checks,'scope':'Exact source stress relative to formal C1, full contact-zero n row, and CA/SE bounded source coquotients; the conductor and outer joins require companion analytic proof.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
