# Reconciliation of the recovered parallel advance

Date: 2026-10-17. This is a scope and dependency reconciliation, based on
the stated proofs and supplied review records. No large check suite or
historical atlas was rerun. The authoritative current branch status is
`output/Q222_Physical_Contact_Closure/PROOF_STATUS.json`; the recovered
parallel status is interpreted as a status of its **new shortcut**, not
as a replacement for the inherited coverage.

## 1. Conclusion

The packages are compatible. The recovered package provides two useful
short, fully quantified proof replacements inside the already inherited
positive-normalized-\(d\) domain:

1. Regular-source C1/C2, with both actual contact angles positive bounded
   units: a source-only moving frame plus determinant covariance, with
   every independent testing chart supplied.
2. C1 with positive-unit normalized \(d,D\), actual \(u_c\) infinitesimal
   and \(v_c\) a positive bounded unit: a weighted five-feature parity
   proof, again with every independent testing chart supplied.

Neither theorem enlarges the full inherited source cover. In particular,
the regular-source theorem is already contained in the inherited
five-consecutive-event theorem, after applying its own forced-unit
deduction. The second theorem replaces the inherited finite-angle C1
pitchfork entry, terminal, and outer dispatch.

The latest current package's two all-tests advances lie instead in
positive **infinitesimal** total-normalized \(d\). They are genuinely
complementary to these recovered proof replacements. Its explicit
one-weak C2 theorem remains **local only** and is not promoted by any
recovered theorem.

The smallest correct common global frontier remains:

> After the inherited canonical reduction and closed-face results,
> all positive-normalized-\(d\) canonical sources and all noncommuting
> independent testing residues are already covered. The unfinished
> atlas-free obligation is the remaining commuting-test cover for
> sources with positive infinitesimal normalized \(d\), after removing
> the stated all-tests subdomains and local certificates.

The retained computer-assisted global theorem and the absence of an
extracted affine pencil retain their existing statuses. This
reconciliation does not give a new global analytical proof.

## 2. Paths and conventions

All path abbreviations below expand against the workspace
`/workspace/scratch/f695f02f9e9c/`:

| Abbreviation | Exact directory |
|---|---|
| `CURRENT` | `output/Q222_Physical_Contact_Closure/` |
| `PARALLEL` | `reconcile_inputs/parallel_advance/` |
| `RETAINED` | `output/Q222_Human_Computer_Assisted_Proof_Package/` |

Thus, for example, `PARALLEL/REGULAR_SOURCE_PROOF.tex` means
`/workspace/scratch/f695f02f9e9c/reconcile_inputs/parallel_advance/REGULAR_SOURCE_PROOF.tex`.

The parent matrices agree channel by channel. The recovered lower-case
event `c` is the current upper-case event `C`. It is **not** the actual
C2 contact half-angle called `c` in the rational source charts. Both use
C1: \(\lambda=n=0\), and C2: \(\lambda=\beta=0\). Both retain
the factors four on event packets and the signed core with coefficient
\(2d\). No source-channel relabeling is needed to import these results.

Let

\[
\tau=d+\lambda+n+m+C+A+D+\alpha+\beta,
\qquad \widehat d=d/\tau.
\]

The recovered full theorems assume \(\operatorname{res}\widehat d>0\).
Equivalently, after setting \(d=1\), **every** event-to-\(d\) ratio is
bounded. Merely writing \(d=1\) does not satisfy this hypothesis if some
event ratios are unbounded. The current relative-strength convention
allows exactly those unbounded ratios.

“Finite noncommuting actual contact” also needs its original meaning:
the half-angles are nonzero field elements in finite projective charts;
they need not be bounded units relative to the real numbers. The
recovered regular theorem explicitly imposes the stronger bounded-unit
condition on both actual angles.

## 3. Existing inherited coverage must not be reopened

The broad positive-normalized-\(d\) result is supported by actual retained
proof modules, not just a sentence in an old status file.

| Inherited result | Precise proof import |
|---|---|
| Exhaustive positive-\(d\) C1/C2 source partition | `RETAINED/human/proof/positive_d_source_partition.tex`, labels `prop:c1-positive-d-partition`, `prop:c2-positive-d-partition` |
| All positive-\(d\) C2 sources | `RETAINED/human/proof/reciprocal_bounded_state_entry.tex`, label `thm:c2-positive-d-all-tests` |
| All positive-\(d\) C1 sources | `RETAINED/human/proof/c1_reciprocal_unbounded_state.tex`, label `thm:c1-positive-d-all-tests` |
| Combined canonical statement | The same C1 file, label `cor:all-positive-d-canonical-tests` |
| Full dependency assembly | `RETAINED/human/proof/Q222_Structural_Proof.tex` includes the source partition, pitchforks, reciprocal entries, terminals, and outer dispatches |
| Every noncommuting testing residue at arbitrary coefficient scales | `RETAINED/human/proof/zero_d_induction.tex`, label `thm:all-noncommuting`; human reading route `penpaper_noncommuting.tex` |
| Noncoercive closed faces | `RETAINED/human/proof/closed_faces_short.tex`, label `cor:all-closed-faces` |

The positive-\(d\) theorem is for bounded physical **coercive canonical**
sources with an actual finite noncommuting stationary zero. Other sources
are routed by the inherited canonical/closed-face reduction; those
hypotheses should not be silently removed from the displayed theorem.

The current small package retains the partition at
`CURRENT/prior/prior_core/inherited/positive_d_source_partition.tex`, and
its inherited companion states this completed coverage. The full retained
archive supplies the associated proof modules. Their presence is therefore
not a reason to infer a missing proof from an isolated small-package
cross-reference, and the recovered shortcut's narrower frontier is not a
reason to downgrade them.

This is consistent with `RETAINED/PROOF_STATUS.json`, which explicitly
lists all canonical positive-normalized-\(d\) sources among the completed
human branches. It also explicitly leaves the normalized-\(d\)-zero
commuting cover unfinished.

## 4. Exact domains and overlaps of the recovered full theorems

### 4.1 Regular-source moving frame

**Domain.** Physical nonnegative C1 or C2 source; \(\tau=1\);
\(\operatorname{res}d>0\); an actual stationary zero with
\(u_c,v_c>0\) both bounded units. **Conclusion:** full original parent
tensor SOS at every independent projective test and state.

**Import paths.**

- Consolidated complete proof: `PARALLEL/REGULAR_SOURCE_PROOF.tex`,
  Theorem `main` and the sections through “Complete independent
  testing-angle coverage”. This is a standalone document, not a
  section-only file suitable for a literal nested `\input`.
- Exact interior construction:
  `PARALLEL/graph/FINITE_UNIT_MOVING_FRAME_THEOREM.md`.
- Necessary covariance/support argument:
  `PARALLEL/newton/FINITE_UNIT_COVARIANCE.md` and the corresponding
  integrated section in the consolidated proof.
- C1 outer testing charts: `PARALLEL/root/ALL_TEST_C1.md`.
- C2 outer testing charts: `PARALLEL/rank_two/ALL_TEST_C2.md`.
- Supplied reviews: `PARALLEL/graph/MOVING_FRAME_ADVERSARIAL_AUDIT.md`
  and `PARALLEL/graph/ALL_TEST_AND_WEIGHTED_ADMISSION_AUDIT.md`.

The graph theorem **alone** has only finite nonzero testing-angle scope.
The all-tests conclusion is legitimate only with the two outer-chart
modules, or with their integrated proofs in `REGULAR_SOURCE_PROOF.tex`.
The recovered package provides these dependencies; its full theorem is
not an unsupported promotion of the graph theorem.

**Why this is exact coverage overlap.** Its support proof forces:

\[
\begin{array}{ll}
\text{C1:}&m,C,A,\alpha\text{ units},\quad D+\beta\text{ a unit};\\
\text{C2:}&m,C,A,D,\alpha\text{ units}.
\end{array}
\]

In the event cycle \((\lambda,D,C,A,\alpha,m,\beta,n)\), C2 therefore
has the five consecutive strong events \((D,C,A,\alpha,m)\). For C1,
nonnegativity makes either \(D\) or \(\beta\) a unit, giving either
that window or \((C,A,\alpha,m,\beta)\). The existing theorem
`CURRENT/prior/inherited/five_retained_events.tex`, label
`thm:five-retained-events`, already gives all tests, and permits even
unbounded event-to-\(d\) ratios. Consequently this recovered theorem
does not enlarge the current source cover. It supplies a concise,
source-only finite moving-frame proof and a useful physical covariance
interpretation.

### 4.2 C1 weak-angle, D-unit parity theorem

**Domain.** Physical nonnegative normalized C1 source; \(d,D\) positive
bounded units; actual \(u_c>0\) infinitesimal and \(v_c>0\) a bounded
unit. Literal \(\beta=0\) is permitted. **Conclusion:** full original
parent tensor SOS at every independent projective test and state.

**Import paths.**

- Consolidated complete proof: `PARALLEL/REGULAR_SOURCE_PROOF.tex`,
  Theorem `weak`, including its subsequent determinant/outer-chart
  argument and the earlier corner identities it invokes.
- Weighted local proof:
  `PARALLEL/newton/WEAK_SOURCE_DUNIT_LOCAL_ADMISSION.md`.
- Source-unit and curvature normalization review:
  `PARALLEL/rank_two/WEAK_C1_DUNIT_CURVATURE_AUDIT.md`.
- Essential all-tests extension:
  `PARALLEL/root/WEAK_C1_DUNIT_ALL_TESTS.md`, with the corner identities
  from `PARALLEL/root/ALL_TEST_C1.md`.
- Supplied all-tests review:
  `PARALLEL/rank_two/WEAK_C1_DUNIT_ALL_TESTS_AUDIT.md`.

The local source analysis derives \(C,A,\alpha,D\) as units,
\(m\asymp u_c^4\), a W-axis residue kernel, and the exact bounded
contact-state quotients. The all-tests extension retains the original
\(m\) packet and constructs the exact baseline on \((X,Y,Z,uW)\)
away from the matched remote angle; it includes the reciprocal Bob
chart and the two remaining Alice-infinite corners. Thus the recovered
local-to-all-tests extension has explicit proof content.

This is not generally a five-consecutive-event case: \(m\) is weak and
\(\beta\) can vanish. It is nevertheless already covered by
`RETAINED/human/proof/c1_pitchfork.tex`, labels `thm:c1-pitchfork`
and `prop:c1-pitchfork-entry`, together with
`RETAINED/human/proof/positive_d_source_partition.tex`, label
`lem:positive-d-strong-dispatch`. The recovered forced-unit argument
supplies the hypotheses of that older terminal.

The two local root choices are also directly compatible. Write
\(p=u_c^2\), \(a=v_c\), \(\delta=v-a\),
\(s=u^2-p\), \(t=u\delta\). The older soft root satisfies exactly

\[
R_{\rm old}=u^2-(p/a)v
=(1+\delta/a)s-(u/a)t.
\]

The determinant of this bounded local two-root change is
\(1+\delta/a=v/a\); its inverse is the separate-field product \(a/v\),
a unit in the matched remote-angle chart. The older X graph differs
from the new constant-contact X graph by a bounded source multiple of
\(sW\). This makes the recovered theorem a genuine compact proof
replacement of the same pitchfork mechanism, rather than a new source
stratum disguised by notation.

## 5. Complementarity with the current new branches

| Current result | Domain relative to total normalization | Relation to recovered full theorems |
|---|---|---|
| `CURRENT/contact/chart_free_c2.tex`, `thm:chart-free-c2` | Physical finite-contact C2; \(C/d,\alpha/d\) infinitesimal; all tests | The proof forces the matching weights to be unbounded after \(d=1\), hence \(\widehat d\) infinitesimal. Outside both recovered domains. Preserve this full branch independently. |
| `CURRENT/c1/ordinary_angle.tex` | Native C1 with \(k,s,a,t,M,J\) units, \(\eta\) infinitesimal; all tests | Here \(d\asymp\eta\), while \(C=2\) and the strong retained weights are units; hence \(\widehat d\) infinitesimal. Also actual angles are \((k,ks\eta)\), not two ordinary angles. A symmetry cannot repair the failed normalized-\(d\) hypothesis. |
| `CURRENT/c2/single_angle_terminal.tex`, `thm:single-angle-local` | One explicit reflected source; only \(Z=1,u,W\) infinitesimal, \(v-1\) infinitesimal | Its \(C,A\asymp1/x\), \(d=1\), so \(\widehat d\asymp x\) is infinitesimal. Neither recovered theorem supplies its missing testing charts. Keep LOCAL ONLY. |
| `CURRENT/bridge/common_bridge.tex` | Determinant circuit theorem and conditional bounded-conductor cancellation | Compatible auxiliary algebra. Neither moving-frame covariance nor scalar determinant SOS proves the missing conductor hypotheses outside their stated regimes. |

The current one-weak source counterexample in
`CURRENT/c2/one_weak_frontier.tex` therefore continues to be useful.
Its normalized signed coefficient vanishes even though the unnormalized
source was written with \(d=1\). The recovered positive-normalized-\(d\)
edge theory does not settle it.

## 6. Additional recovered results worth preserving

These are proved auxiliary deductions, not new whole-source certificates:

| Result | Precise import and scope |
|---|---|
| \(2(C+\alpha)(n+m+A+D)\ge d^2\) | `PARALLEL/rank_two/C2_OPENING_FLOOR.md`; exact physical C2 two-state compression, homogeneous in all weights. Its equal-angle quadratic family is also printed there. Necessary, not sufficient. |
| \(D+\alpha\ge d^2/(36\tau)\) in C2 | `PARALLEL/rank_two/WEAK_SOURCE_EDGE_NORMAL_FORM.md` and the final section of `PARALLEL/REGULAR_SOURCE_PROOF.tex`; necessary physical floor. The resulting four-normal jet is not a completed general edge terminal. |
| Uniform C1 covariance conditioning | `PARALLEL/newton/C1_UNIFORM_COVARIANCE_AND_SMALL_ANGLE_RATES.md`, §1: after pure-source diagonal scaling, eigenvalues are at least \(1/2\). This holds across source-angle rates when its positive stationary masses are present; it controls the Hessian only. |
| Rank-three state residue at a single ordinary source edge | The same rate note, §2a, and the consolidated proof's “No two-soft state line” lemma; requires positive normalized \(d\). Does not cover normalized-\(d\)-zero rank degenerations. |
| Necessity of a testing-owned weighted opening | `PARALLEL/graph/EXACT_WEAK_SOURCE_FAMILY.md`; exact physical example and rate obstruction. It supports the five-root mechanism, not an all-source theorem. |

The first floor is fully consistent with the current two-weak C2 theorem:
it rules out both weak complementary weights only when the other weights
are bounded after \(d=1\). Without that boundedness it instead forces a
large matching-weight sum. It therefore must not be used to delete the
current two-weak domain as “physically impossible”.

These floors complement the existing relative inequalities in
`CURRENT/prior/cover/relative_forbidden_faces.tex` and optimized matching
budget in `CURRENT/prior/budget/optimized_matching_budget.tex`. None
should be recast as a full-parent positivity or tensor-SOS criterion.

## 7. Status wording and forbidden scope promotions

1. **Do not reopen inherited positive-\(d\) coverage.** The recovered
   phrases “weak-D”, “other degenerate C2”, and “doubly commuting actual
   source corners” describe what its *new shortcut* has not replaced.
   Within positive normalized \(d\), these are already addressed by the
   retained source partition and terminal assembly.
2. **Do not broaden “positive d”.** A positive unnormalized coefficient,
   or the convention \(d=1\), is weaker than positive residue after total
   normalization. This is the main possible false promotion when joining
   the packages.
3. **Keep local and all-tests dependencies together.** The recovered graph
   note is interior-only, and its newton note is local-only. Their
   integrated all-tests theorems are validly broader because the recovered
   root/rank-two dispatch modules provide the missing charts. Importing
   only the local note while copying the all-tests status would omit a
   necessary proof.
4. **Keep the current C2 six-root statement local.** The recovered package
   has no zero-normalized-\(d\), one-weak C2 all-tests theorem.
5. **Do not infer a uniform full-parent conductor from covariance.**
   The recovered rate note explicitly leaves bounded scalar/normal
   allocation as a separate obligation. This agrees with the current
   cancellation lemma and its nonautomatic-membership examples.
6. **Distinguish proof from check scope.** The recovered 154-term moving
   Gram is an exact anchor example; the universal statement is supplied
   by the finite construction and analytical support argument. Eleven
   saved exact replays do not alone establish the theorem's quantifiers.
   This reconciliation read their receipts and scoped proofs; it did not
   rerun them or freshly audit the historical global atlas.
7. **Preserve the global proof category.** Both package frontiers leave the
   new atlas-free route incomplete and the affine pencil unextracted.
   Historical “locked proof” wording preserves the retained route; it
   does not convert this union of short results into a new global proof.

No substantive contradiction between the claimed theorem domains was
found. The main required correction to a merged frontier is editorial:
intersect broad phrases such as “remaining C1/C2 source shapes” with the
failure of inherited coverage, rather than treating every domain not
closed by one new shortcut as globally open.

## 8. Smallest common coverage and recommended import

For the full canonical proof, the following non-disjoint cover is enough
to preserve every proved result without duplicating obligations:

1. Literal \(d=0\): original event-square sum.
2. Noncoercive closed faces: inherited closed-face theorem and canonical
   reduction.
3. Noncommuting independent testing residues at any coefficient scale:
   inherited `thm:all-noncommuting`.
4. Positive total-normalized \(d\): inherited
   `cor:all-positive-d-canonical-tests`, at all independent tests. Use the
   recovered regular and D-unit parity proofs as shorter optional
   replacements on their exact subdomains.
5. Positive infinitesimal total-normalized \(d\), commuting tests:
   preserve the inherited five-consecutive-event exit, the global
   three-event-wall exit (`RETAINED/human/proof/global_three_event_wall.tex`,
   `thm:global-three-event-wall`), the completed exact uniform families,
   and the current chart-free two-weak C2 and ordinary-angle C1 all-tests
   branches. The current local one-weak C2 theorem covers only its stated
   part of this domain.
6. The complement of these admissions remains the single global
   atlas-free commuting-cover obligation. It is still supplied only by
   the separately retained atlas route for the historical global theorem.

For a concise merged manuscript, retain the whole recovered standalone
`REGULAR_SOURCE_PROOF.tex`/PDF as a clearly scoped proof supplement, and
link its two theorems as replacement nodes beneath the inherited
positive-normalized-\(d\) node. For an even shorter proof route, its
regular forced-unit lemma can lead directly to the existing five-event
theorem; keep the moving frame as an explanatory alternative. Preserve
the D-unit parity theorem with its all-tests dispatch intact.

Keep `CURRENT`'s new zero-normalized-\(d\) branch nodes separate. Do not
rewrite their metadata as subsumed by the parallel package, and do not
add a “global cover completed” edge. The merged package should distinguish
**inherited complete coverage**, **new short replacements**,
**new zero-normalized-\(d\) branch closures**, and **local-only progress**.

This reconciliation changes no theorem or authoritative status file.

## 9. Check of the new reusable weighted lemma

Also reviewed
`output/Q222_Reconciled_Complete_Package_2026-10-17/reconciliation/weighted_contact_lemma.tex`,
label `lem:weighted-taylor`. **No algebra or scope correction is needed.**

Membership in the bounded polynomial ring gives the displayed bounded
coefficient decomposition
\(F=\varepsilon^2f_0+\varepsilon\sum_iN_if_i+
\sum_{|a|\ge2}N^af_a\). Contact and stationarity imply the required
vanishings of \(f_0,f_i\) by cancellation inside the coefficient field.
The monomial allocation then has constant Gram equal to
\(\tfrac12\nabla^2[\varepsilon^{-2}F(\varepsilon n,U)](0,0)\).
Every higher allocated term retains an evaluated infinitesimal \(N_i\)
or \(U_j\), so its coefficient has zero residue. Formal normal degree
\(j\ge2\) gains only the bounded source factor
\(\varepsilon^{j-2}\).

In particular, no boundedness of an actual \(N_i/\varepsilon\) enters.
The explicit bounded-ring membership and strict scaled Hessian are real
hypotheses; neither follows from stationary contact alone. The lemma
correctly packages the current ordinary-angle C1 argument and explicitly
leaves singular product-root divisions and the global coverage problem
separate. It should be marked a reusable sufficient lemma, not an
additional whole-source terminal.
