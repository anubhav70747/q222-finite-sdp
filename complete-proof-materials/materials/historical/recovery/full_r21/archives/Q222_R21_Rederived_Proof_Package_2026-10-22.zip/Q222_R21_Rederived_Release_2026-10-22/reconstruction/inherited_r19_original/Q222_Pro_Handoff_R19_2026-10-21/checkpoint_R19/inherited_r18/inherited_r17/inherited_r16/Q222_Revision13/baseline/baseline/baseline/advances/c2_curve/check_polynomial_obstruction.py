from pathlib import Path
import json
import sympy as s
x,u,v,W,X,Y,Z=s.symbols('x u v W X Y Z')
n=(8-5*x*x)/(16*(1+x)**2)
m=3*x*x*(3*x+4)/(16*(1+x)*(4+x-2*x*x))
C=al=(4-x)/(8*x)
A=x*(x+4)*(3*x+4)/(32*(2-x)*(1+x)**2)
D=(2-x)*(3*x+4)/(16*x*(1+x))
Du,Dv=1+u*u,1+v*v
r=u*W-Y;p=v*Y-Z;J=r+v*(u*X-Z);B=X+u*Z;Rm=v*W-X+u*p
F=s.Poly(s.expand(2*(J*J+Du*p*p+Dv*B*B-Du*Dv*Z*Z)+4*n*Du*Dv*X*X+4*m*Rm*Rm+4*C*Dv*r*r+4*A*Du*Dv*Y*Y+4*D*J*J+4*al*Du*p*p),u,v,W,X,Y,Z)
checks={}
for name,monom,value in [('W2_zero',W*W,0),('uvZ2_zero',u*u*v*v*Z*Z,0),('uY2_diagonal',u*u*Y*Y,4*A),('vX2_diagonal',v*v*X*X,2+4*n)]:
 checks[name]=s.cancel(F.coeff_monomial(monom)-value)==0
aval=x*(1-x/2);bval=-x*x/4
imbalance=s.factor(4*A*aval**2-(2+4*n)*bval**2)
claimed=(x+4)*(3*x+4)*x**3*(4-3*x)/(64*(1+x)**2)
checks['strict_positive_contact_imbalance_identity']=s.cancel(imbalance-claimed)==0
assert all(checks.values())
out={'status':'PASS: ALL POLYNOMIAL SOS IMPOSSIBLE','checks':checks,'positive_contact_imbalance':str(imbalance),'sign':'positive for positive infinitesimal x','proof':'Parity block00 has two zero diagonals, leaving a 2x2 PSD block whose exact contact kernel forces this positive imbalance to vanish.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
