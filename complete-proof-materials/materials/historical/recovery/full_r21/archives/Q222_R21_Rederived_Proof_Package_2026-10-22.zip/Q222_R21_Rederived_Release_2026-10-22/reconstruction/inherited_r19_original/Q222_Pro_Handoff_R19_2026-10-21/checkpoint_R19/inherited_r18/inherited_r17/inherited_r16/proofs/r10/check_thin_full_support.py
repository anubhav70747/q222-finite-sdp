"""Full-state stress reconstruction and scalar/normal support, no old suite."""
import sympy as s,json
from pathlib import Path
checks={}
def ck(name,ex):
 assert s.cancel(ex)==0,name;checks[name]=True;print('PASS',name,flush=True)
u,v,W,X,Y,Z=s.symbols('u v W X Y Z');h,n,gam=s.symbols('h n gamma');dc,da,dd,dal,ddbell=s.symbols('dc da dd dal ddBell');Du=1+u*u;Dv=1+v*v
Rm=v*W-X+u*v*Y-u*Z;RD=u*W+u*v*X-Y-v*Z;core=(RD*RD+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z*Z)/2
# dBeta+dBell/2=-n is the independently source-checked identity.
dbeta=-n-ddbell/2
whole=n*Du*Dv*X*X+dc*Dv*(u*W-Y)**2+da*Du*Dv*Y*Y+dd*RD*RD+dal*Du*(v*Y-Z)**2+dbeta*Dv*(X+u*Z)**2+ddbell*core
wt=(W+u*Y)/Du;at=v*wt;nrow=n*Du*Dv*(X+gam*at)**2
center=da*Du*Dv*(Y-h*u*W)**2
expected=-2*n*gam*Du*Dv*X*at-n*gam*gam*Du*Dv*at*at-n*Dv*(X+u*Z)**2+dc*Dv*(u*W-Y)**2+(dd+ddbell/2)*RD*RD+dal*Du*(v*Y-Z)**2+ddbell*Du*((v*Y-Z)**2-Dv*Z*Z)/2+da*h*Du*Dv*(2*u*W*Y-h*u*u*W*W)
ck('entire_original_parent_stress_restoration',whole-center-nrow-expected)
# Full two-normal inverse, with all source coefficients arbitrary.
wt,N,MB,pp,hh=s.symbols('wt N MB pp hh');at=v*wt;Xn=N+pp*Du*at-u;qb=v*(Du-u*N-pp*u*Du*v*wt);Wn=wt+u*(MB+hh*qb)/Du;Yn=u*wt-(MB+hh*qb)/Du
poly=s.Poly(s.cancel(expected.subs({W:Wn,Y:Yn,X:Xn,Z:1})),N,MB)
scalar=s.cancel(poly.coeff_monomial(1)-dal*Du)
num,den=s.fraction(scalar);assert not den.has(wt,N,MB)
for (iu,iv,iw),co in s.Poly(num,u,v,wt).terms():
 assert iv>=2 or (iu>=2 and iw>=2) or (iu>=1 and iv>=1 and iw>=1),(iu,iv,iw)
checks['entire_scalar_restricted_raw_square_support']=True
for z in (N,MB):
 num,den=s.fraction(s.cancel(poly.coeff_monomial(z)));assert not den.has(wt,N,MB)
 for (iu,iv,iw),co in s.Poly(num,u,v,wt).terms():
  assert iv>=1 or (iu>=1 and iw>=1),(z,iu,iv,iw)
 checks['entire_'+str(z)+'_first_normal_raw_support']=True
assert poly.total_degree()<=2
checks['no_omitted_higher_normal_degree']=True
out={'status':'PASS','count':len(checks),'checks':checks,'scope':'Exact reconstruction of complete original-parent stress after contact-zero n row and centered A packet; complete scalar and both first normals have required restricted raw support. SE normalized coefficient divisibility is proved by TL8-TL10.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
