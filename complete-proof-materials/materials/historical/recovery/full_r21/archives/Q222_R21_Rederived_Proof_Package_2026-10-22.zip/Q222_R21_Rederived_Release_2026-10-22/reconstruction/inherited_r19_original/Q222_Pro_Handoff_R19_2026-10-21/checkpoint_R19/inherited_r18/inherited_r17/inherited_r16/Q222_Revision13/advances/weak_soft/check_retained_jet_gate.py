#!/usr/bin/env python3
"""Exact retained-jet and polynomial-splitter identities; no leaf admission."""
import json
from pathlib import Path
import sympy as s

out = {}
def ck(name, value):
    value = s.factor(s.cancel(s.together(value)))
    if value != 0:
        raise AssertionError((name, value))
    out[name] = True

a,b0,t,b,ss,Z,xi,eta,H,B,r=s.symbols('a b0 t b ss Z xi eta H B r')
u=a*t; v=b0*b; W=B*ss*Z/(a*b0)
z=a*a; y=b0*b0; h=H/B
g=(B+z*(H+r-1))/B
e=(y*(1+z*r)-(B-H))/B
X=-r*u*Z+xi; Y=h*u*W+eta
M=v*W-X+u*v*Y-u*Z
J=u*W+u*v*X-Y-v*Z
Rm=M-g*v*W; RD=J+e*u*W
T=(t-1)*Z; R=(ss-b)*Z; S=(b*ss-1)*Z
lm=-xi+a*b0*eta+a*((2*H-(1-r))*T+(1-r)*S)
ld=a*b0*xi-eta+b0*((1-z*r)*T+(1+z*r)*R)
em=(u*v-a*b0)*eta+a*H*(t-1)*T+a*H*(t*t-1)*S
ed=(u*v-a*b0)*xi+b0*(1+z*r)*(t-1)*R+b0*((b-1)*(1-z*r*t)-z*r*(t-1))*T
ck('exact_m_jet_and_remainder',Rm-lm-em)
ck('exact_D_jet_and_remainder',RD-ld-ed)

eps,dt,db,ds,dx,de=s.symbols('eps dt db ds dx de')
near={t:1+eps*dt,b:1+eps*db,ss:1+eps*ds,xi:eps*dx,eta:eps*de,Z:1}
for name,rem in [('m',em),('D',ed)]:
    p=s.Poly(s.expand(rem.subs(near)),eps)
    ck(name+'_remainder_has_zero_value_and_first_jet',p.coeff_monomial(1)+eps*p.coeff_monomial(eps))
Tc=s.symbols('Tc')
lmf=-xi+a*b0*eta+a*((2*H-(1-r))*Tc+(1-r)*Tc)
ldf=a*b0*xi-eta+b0*((1-z*r)*Tc-(1+z*r)*Tc)
ck('m_common_radial_jet',lmf.subs({xi:0,eta:0})-2*a*H*Tc)
ck('D_common_radial_jet',ldf.subs({xi:0,eta:0})+2*z*r*b0*Tc)

# The exact block completion behind the retained-jet obstruction.
h11,h12,h22,j1,j2,x1,x2,ee=s.symbols('h11 h12 h22 j1 j2 x1 x2 ee')
Hx=h11*x1*x1+2*h12*x1*x2+h22*x2*x2
lx=j1*x1+j2*x2
ck('retained_jet_Schur_identity',Hx+2*lx*ee+ee*ee-(Hx-lx*lx)-(ee+lx)**2)

# Two source polynomial blocks for the exact scalar support, with every
# contact correction retained as a polynomial rather than a Hessian value.
aa,bb,dc,kc,q1,q2=s.symbols('aa bb dc kc q1 q2')
tau=t-1
dd=aa+tau*(t+1)*dc
cc=bb+tau*(t+1)*kc
e1=(aa+dd-tau*tau*q1)/2
e2=(bb+cc-tau*tau*q2)/2
et=(aa+bb+cc+dd-tau*tau*(q1+q2))/2
P=aa*ss*ss+bb*b*b*ss*ss+cc+dd*b*b-2*et*b*ss
split=aa*ss*ss-2*e1*ss*b+dd*b*b+bb*b*b*ss*ss-2*e2*b*ss+cc
ck('entire_scalar_two_block_split',P-split)
ck('first_polynomial_block_determinant',4*(aa*dd-e1*e1)-tau*tau*(2*(aa+dd)*q1-tau*tau*q1*q1-(t+1)**2*dc*dc))
ck('second_polynomial_block_determinant',4*(bb*cc-e2*e2)-tau*tau*(2*(bb+cc)*q2-tau*tau*q2*q2-(t+1)**2*kc*kc))

# The unique odd cubic split and explicit source Grams; no matrix-SOS theorem.
a2,a4,d0,d4,b0m,b2,b4,c0,c4,lam=s.symbols('a2 a4 d0 d4 b0m b2 b4 c0 c4 lam')
d2=a2+a4-d0-d4
A1=(a2+d0-d4)/2; B1=(a2+2*a4-d0+d4)/2
ma=a2*t*t+a4*t**4; md=d0+d2*t*t+d4*t**4
ee1=A1*t+B1*t**3
ck('unique_first_cubic_determinant',ma*md-ee1*ee1-t*t*(t*t-1)**2*(a4*d4*t*t+a2*d0-A1*A1))
rr1=t*ss-b;rr2=t*rr1;rr3=(t*t-1)*b
ck('explicit_first_source_Gram',ma*ss*ss+md*b*b-2*ee1*ss*b-a2*rr1*rr1-a4*rr2*rr2-d4*rr3*rr3-2*(A1-a2)*rr1*rr3)
c2=b0m+b2+b4-c0-c4
A2=(2*b0m+b2+c0-c4)/2;B2=(b2+2*b4-c0+c4)/2
mbb=b0m+b2*t*t+b4*t**4;mcc=c0+c2*t*t+c4*t**4
ee2=A2*t+B2*t**3
kap=b2*c4+b4*c2-B2*B2+2*b4*c4
ck('unique_second_cubic_determinant',mbb*mcc-ee2*ee2-(t*t-1)**2*(b4*c4*t**4+kap*t*t+b0m*c0))
pp,qq=s.symbols('pp qq')
rr1=t*pp-qq;rr2=t*rr1;rr3=(t*t-1)*qq;rr4=(t*t-1)*pp
ev=(c0-c4-lam)/2;od=(lam-b2-2*b0m)/2
gg=lam*rr1*rr1+c4*rr3*rr3+2*ev*rr1*rr3+(b0m+b2+b4-lam)*rr2*rr2+b0m*rr4*rr4+2*od*rr2*rr4
ck('explicit_second_source_Gram',mbb*pp*pp+mcc*qq*qq-2*ee2*pp*qq-gg)
ck('even_source_block_interval',4*(lam*c4-ev*ev)-4*c0*c4+(lam-c0-c4)**2)
ck('odd_source_block_interval',4*((b0m+b2+b4-lam)*b0m-od*od)-4*b0m*b4+(lam-b2)**2)
k=s.symbols('k');lk=(b2-c0-c4)/2-k
rr1=pp-t*qq;rr2=t*t*pp-t*qq;ss1=t*pp-qq;ss2=t*pp-t*t*qq
gg2=b0m*rr1*rr1+2*k*rr1*rr2+b4*rr2*rr2+c0*ss1*ss1+2*lk*ss1*ss2+c4*ss2*ss2
ck('second_Gram_as_two_fixed_diagonal_blocks',mbb*pp*pp+mcc*qq*qq-2*ee2*pp*qq-gg2)

result={'status':'all_exact_gate_checks_passed','count':len(out),'checks':out,
 'scope':'Exact centered-packet jets, their retained-jet Schur condition, unique odd scalar polynomial splitter, and explicit source Grams conditional on two unproved source inequalities. No generic scalar positivity, full-normal lift, or residual-row admission is asserted.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':result['status'],'count':len(out)}))
