"""Exact finite coefficient collection from the full centered-A remainder.

This is arithmetic in the quotient by monomials of weight greater than 6.
All inverse series are finite exact inverses in that quotient. Their
weight-zero term is a monomial in the positive unit E only.
The bounded positive coefficient delta is never inverted.
No ell or k inverse occurs.
"""
from fractions import Fraction as F
from pathlib import Path
import json

CAP=6
WT=(0,1,0,1,0,1,1,2,3,2)
DIM=len(WT)
def wt(m):return sum(a*b for a,b in zip(m,WT))
class P:
 def __init__(self,d):self.d={m:F(c) for m,c in d.items() if c and wt(m)<=CAP}
 def lift(self,q):return q if isinstance(q,P) else P({(0,)*DIM:q})
 def __add__(self,q):
  q=self.lift(q);o=dict(self.d)
  for m,c in q.d.items():o[m]=o.get(m,0)+c
  return P(o)
 __radd__=__add__
 def __neg__(self):return P({m:-c for m,c in self.d.items()})
 def __sub__(self,q):return self+-self.lift(q)
 def __rsub__(self,q):return self.lift(q)+-self
 def __mul__(self,q):
  q=self.lift(q);o={}
  for m,c in self.d.items():
   for n,b in q.d.items():
    v=tuple(x+y for x,y in zip(m,n))
    if wt(v)<=CAP:o[v]=o.get(v,0)+c*b
  return P(o)
 __rmul__=__mul__
 def __pow__(self,n):
  if n<0:return self.inv()**(-n)
  o=self.lift(1)
  for _ in range(n):o=o*self
  return o
 def inv(self):
  leading={m:c for m,c in self.d.items() if wt(m)==0}
  assert len(leading)==1,leading
  (m,c),=leading.items();base=P({tuple(-x for x in m):1/c})
  assert all(m[i]==0 for i in range(DIM) if i not in (0,2))
  h=self*base-1;assert all(wt(m)>0 for m in h.d)
  o=self.lift(1);power=self.lift(1)
  for j in range(1,CAP+1):power=power*(-h);o=o+power
  result=base*o
  assert not (self*result-1).d,'exact inverse in the truncated ring'
  return result
 def __truediv__(self,q):return self*self.lift(q).inv()
 def __rtruediv__(self,q):return self.lift(q)*self.inv()

def var(i):return P({tuple(int(i==j) for j in range(DIM)):1})
delta,k,E,ell,t,u,w,v,N,M=map(var,range(DIM))
K=1+k*k;Q=K*K-ell*k*k;a=(K-ell)/E
eta=K*E/Q;r=ell/Q;Delta=delta*Q/K
zeta=delta*delta*k*k*Q*E/K
R=K*K/Q;T=K-k*k*t*zeta
H=r+eta;Vc=k*k*eta*zeta;Qc=1-k*k*zeta+a*Vc
P4=1+k*k+eta*k*k*(a-k*k-1)-zeta*k*k*t
P4+=Vc*(-zeta*k*k*t*t+2*k*k*t+a*(1-t)+t)
Pa=1+k*k-a*eta*k*k+zeta*((1+k*k)-(2+k*k)*t)
Pa+=Vc*(-zeta*t*t+a*(t-1)+t)
Pd=K*K-a*eta*k**4+zeta*k*k*(K-(2+k*k)*t)
Pd+=Vc*(-zeta*k*k*t*t+k*k*a*(t-1)+k*k*t+K)
# These are exact c_i/ell formulas: no inverse of ell is used.
c2=2*K*(1-t*zeta)*(1+Vc)*H*Qc/Q
cb=2*K*(1+(1-t)*zeta)*H*Qc/Q
c3=2*K*H*Qc*(1-k*k*eta+t*Vc)/Q
c5=2*K*H*Qc*(1+Vc)/Q
c4=2*Qc*P4;ca=2*H*Pa/Q;cd=4*Qc*Pd/Q
B2=8*a*c2*K*K/(R*c3*Q*Q)
Bb=8*a*cb*K*K/(R*c3*Q*Q)
B3=8*a/T;B5=8*a*c5/(T*c3)
Ar=2*a*eta*eta*c4/(Q*c3)
bell_d=2*a*eta*cd/c3
alpha=2*a*Delta*Delta*k**6*eta*eta*ca/c3
Astar=1/a
Du=1+u*u;Dv=1+v*v;p=t/R;h=a/T
qA=v*Du*w
qB=v*(Du-u*N-p*u*Du*v*w)
W=delta*w+u*(M+delta*h*qB)/Du
Y=delta*u*w-(M+delta*h*qB)/Du
center=Y-r*u*W
G=B2*(N*N-2*qA*N+(1-p)*qA*qA)
G+=Bb*Dv*(N*N+2*qA*N+p*qA*qA)
G+=B3*Dv*(M*M+2*delta*qB*M+delta*delta*h*qB*qB)
G+=B5*(M*M-2*delta*qB*M+delta*delta*(1-h)*qB*qB)
G+=4*Astar*Du*Dv*center*center
G+=4*Ar*Du*Dv*(2*u*W*Y-r*u*u*W*W)
G+=4*alpha*Du*(v*Y-delta)**2
G+=2*bell_d*Du*((v*Y-delta)**2-delta*delta*Dv)
assert all(mon[0]>=0 for mon in G.d),'delta is never inverted'

def pick(n,m,maxwt=None):
 return {ex[:8]:c for ex,c in G.d.items()
         if ex[8:]==(n,m) and (maxwt is None or wt(ex)-3*n-2*m<=maxwt)}
parts={'scalar':pick(0,0),'N':pick(1,0,3),'M':pick(0,1,3),
       'NN':pick(2,0,0),'NM':pick(1,1,0),'MM':pick(0,2,0)}
out={name:[[list(m),str(c)] for m,c in sorted(poly.items())] for name,poly in parts.items()}
if __name__=='__main__':
 dest=Path(__file__).with_name('centered_a_low_weights.json')
 dest.write_text(json.dumps(out,indent=2)+'\n')
 print({name:len(poly) for name,poly in parts.items()})
