"""Exact source and full-normal certificates for the interior small-L theorem."""
import json
from pathlib import Path
import sympy as s
checks={}
def check(name, expression):
    val=s.factor(s.together(expression))
    if val != 0: raise AssertionError((name,val))
    checks[name]=True
    print('PASS',name,flush=True)

u,v,W,X,Y,Z,U,V=s.symbols('u v W X Y Z U V')
m,C,A,D,al,be,eta,zeta,r,h=s.symbols('m C A D alpha beta eta zeta r h')
theta=1-h; Du=1+U;Dv=1+V
rho=eta+r;j0=eta+r-1
b=r*(1-r)/(eta*(eta+2*r-1))
H0=eta*(eta+2*r-1)/(2*r*(1-r)*j0)
gamma=rho/(2*eta*(eta+2*r-1))
Aw=m*V*(1+r*U)**2+C*Dv*(1-r)**2*U+A*Du*Dv*r*r*U+(D+s.Rational(1,2))*(1-r)**2*U+(al+s.Rational(1,2))*Du*r*r*U*V
Az=al+D*V+U*((m+s.Rational(1,2))*theta**2+al+V*(h*h/2+2*D*h))+U*U*V*(D+s.Rational(1,2))*h*h+be*theta**2*U*Dv
b0=m*theta+D*(1-r)+al*r+s.Rational(1,2)
b1=m*r*theta+h*(D+s.Rational(1,2))*(1-r)+(al+s.Rational(1,2))*r
fw=-m*(1+r*U)+(D+s.Rational(1,2))*(1-r)*U
fz=m*theta-(D+s.Rational(1,2))*V*(1+h*U)+(be+s.Rational(1,2))*Dv*theta
kw=m*V*(1+r*U)-C*Dv*(1-r)+A*Du*Dv*r-(D+s.Rational(1,2))*(1-r)+(al+s.Rational(1,2))*Du*r*V
kz=-m*theta*U+(D+s.Rational(1,2))*(1+h*U)-(al+s.Rational(1,2))*Du

x,k,pt,t,ss=s.symbols('x k ptheta t s')
y=x*eta*zeta
cF=(C*(1-r)**2+A*r*r+(al+s.Rational(1,2))*r*r+2*m*r)/eta**2
aUV=A*r*r/eta**2+h*h/2+2*D*h+be*theta**2-2*b1/eta
aUUV=h*h*(D+s.Rational(1,2))
aUVV=r*r*(m+A+al+s.Rational(1,2))/eta**2
fV=(C*(1-r)**2+A*r*r+(D+s.Rational(1,2))*(1-r)**2)/eta**2+D-2*b0/eta
bU=al+(m+be+s.Rational(1,2))*theta**2
fA=aUV+aUUV*U+aUVV*V
fB=m*zeta/(eta*x)
fC=(al-cF*y*y+bU*U)/(eta*zeta*x*x)
fG=-(fV+2*cF*y)/x
scalar=Aw*V/(eta**2*U)+Az-2*V*(b0+b1*U)/eta
check('exact_scalar_three_circuit_plus_binomial',scalar-cF*(V-y)**2-fA*U*V-fB*x*V**2/(eta*zeta*U)-fC*eta*zeta*x*x+fG*x*V)

PY=s.expand(2*(kw/eta+kz))
PE=s.cancel(2*(Aw/U-m*V/U)/eta**2-2*(b0+b1*U)/eta+b*PY)
assert s.denom(PE).has(U,V)==False
def quotients(P):
    P00=P.subs({U:0,V:0})
    Pu=s.cancel((P-P.subs(U,0))/U)
    Pv=s.cancel((P.subs(U,0)-P00)/V)
    return P00,Pu,Pv
PY0,PYU,PYV=quotients(PY);PE0,PEU,PEV=quotients(PE)
check('finite_Y_normal_division',PY-PY0-U*PYU-V*PYV)
check('finite_E_normal_division',PE-PE0-U*PEU-V*PEV)
LX=2*u*theta*(m+be+s.Rational(1,2))-2*m*u*t*t*(1+r*U)/eta+2*u*V*((be+s.Rational(1,2))*theta-(D+s.Rational(1,2))*(1+h*U)+(D+s.Rational(1,2))*(1-r)/eta)
check('full_X_normal_support',(LX-2*u*(t*t*fw/eta+fz)).subs(V,U*t*t))

# Independently differentiate the entire original parent, not its graph alone.
ee,nn,xx=s.symbols('E N xi')
du=1+u*u;dv=1+v*v
jt=u*W+u*v*X-Y-v*Z
mt=v*W-X+u*v*Y-u*Z
core=jt**2+du*(v*Y-Z)**2+dv*(X+u*Z)**2-du*dv*Z**2
F4=m*mt**2+C*dv*(u*W-Y)**2+A*du*dv*Y**2+D*jt**2+al*du*(v*Y-Z)**2+be*dv*(X+u*Z)**2+core/2
check('exact_u_sign_gauge',F4.subs({u:-u,Y:-Y,Z:-Z},simultaneous=True)-F4)
check('exact_v_sign_gauge',F4.subs({v:-v,X:-X,Z:-Z},simultaneous=True)-F4)
check('literal_u_axis_core',core.subs(u,0)-dv*(X*X+Y*Y))
check('literal_v_axis_core',core.subs(v,0)-(u*W-Y)**2-(X+u*Z)**2)
full=s.expand(F4.subs({Z:1,W:(v+ee)/(eta*u),Y:r*(v+ee)/eta+b*ee+nn,X:-h*u+xx}).subs(v,u*t))
zer={ee:0,nn:0,xx:0};uv={U:u*u,V:u*u*t*t}
check('whole_parent_first_E',s.diff(full,ee).subs(zer)-(2*m*u*t**3/eta**2+u*t*PE.subs(uv)))
check('whole_parent_first_Y',s.diff(full,nn).subs(zer)-u*t*PY.subs(uv))
check('whole_parent_first_X',s.diff(full,xx).subs(zer)-LX.subs(uv))
raw_hard=s.hessian(full,[ee,nn,xx])/2
base={C:rho/(2*(1-r)),A:eta/(2*r),D:1/(2*j0),m:0,al:0,h:1,u:0}
check('bounded_ratio_hard_E_residue',raw_hard[0,0].subs(base)-gamma)
check('bounded_ratio_hard_Y_residue',raw_hard[1,1].subs(base)-H0)
check('bounded_ratio_hard_EY_residue',raw_hard[0,1].subs(base))
check('bounded_ratio_hard_X_beta_pivot',raw_hard[2,2].subs(u,0)-m-be-s.Rational(1,2))

# Original NC source with theta=x*ptheta. All denominator factors below are units.
hs=1-x*pt;ths=x*pt;K=1+x;R=1+x*r;T=1+x*hs
M=R-ths/zeta;J=T-(1-r)/eta;Esrc=1-x*eta*hs;Qsrc=1-x*zeta*r
P4=T*Esrc+x*(1-r)*(hs+zeta)
Pa=R*hs*(1+y)+zeta*M*Esrc
Pd=1+2*x*hs+r*x*x*(hs+zeta)+x*zeta+eta*x*(K*zeta+x*hs*ths)
B5=K*(1+y)*rho-eta*J*Pd
Bbeta=K*x*rho*(hs+zeta)-ths*Pd
src={h:hs,m:K*x*rho*hs*(1+y)/(2*M*zeta*Pd),C:K*rho*Esrc/(2*(1-r)*Pd),A:eta*P4/(2*r*Pd),D:B5/(2*eta*J*Pd),al:x*x*zeta*rho*Pa/(2*Qsrc*Pd),be:Bbeta/(2*ths*Pd)}
def rat(expr): return s.factor(s.together(expr.subs(src)))
def at0(expr): return s.factor(rat(expr).subs({x:0,pt:0}))
lam=rho/(2*eta)
check('scalar_cF_residue',at0(cF)-rho/(2*eta**2))
check('scalar_fA_residue',at0(fA.subs({U:0,V:0}))-lam)
check('scalar_fB_residue',at0(fB)-lam)
check('scalar_fC_residue',at0(fC.subs(U,0))-lam)
check('scalar_fG_residue',at0(fG)-3*lam)

coquotients={
 'm_over_x':m/x,'alpha_over_x2':al/x**2,
 'C_minus_base_over_x':(C-rho/(2*(1-r)))/x,
 'A_minus_base_over_x':(A-eta/(2*r))/x,
 'D_minus_base_over_x':(D-1/(2*j0))/x,
 'PY_zero_over_x':PY0/x,'PE_zero_over_x':PE0/x,
 'beta_theta_over_x':be*theta/x,
 'beta_theta2_over_x2':be*theta**2/x**2,
 'X_source_over_x':theta*(m+be+s.Rational(1,2))/x,
 'bU_over_x2':bU/x**2,'fV_over_x':fV/x,
}
denominators={}
for name,expr in coquotients.items():
    val=rat(expr);den=s.factor(s.denom(val));den0=s.factor(den.subs(x,0))
    if den0==0:raise AssertionError(('uncancelled_x_denominator',name,den))
    if den0.has(pt):raise AssertionError(('opening_in_denominator',name,den0))
    denominators[name]=str(den0);checks['finite_source_'+name]=True

hfun=s.expand(fA+fB+fC-fG)
hv=s.diff(hfun,V);hu=s.diff(hfun,U)
atcontact={U:x,V:y}
check('scalar_contact_value',rat(hfun.subs(atcontact)))
check('scalar_contact_u_jet',rat((2*(fA-fC)+2*x*(hu+eta*zeta*hv)).subs(atcontact)))
check('scalar_contact_t_jet',rat((2*(fB-fC)+2*y*hv).subs(atcontact)))
check('full_Y_normal_contact',rat(PY.subs(atcontact)))
check('full_E_normal_contact',rat((2*m*eta*zeta/eta**2+PE).subs(atcontact)))
check('full_X_normal_contact',rat((2*theta*(m+be+s.Rational(1,2))-2*m*zeta*(1+r*U)+2*V*((be+s.Rational(1,2))*theta-(D+s.Rational(1,2))*(1+h*U)+(D+s.Rational(1,2))*(1-r)/eta)).subs(atcontact)))

# Exact scalar finite Taylor arrays in (u,t), source contact (k,s).
a0,b0c=s.symbols('a0 b0c');dd=u-k;dt=t-ss
ht=a0*(u*u-k*k)+b0c*(u*u*t*t-k*k*ss*ss)
check('finite_scalar_second_Taylor',ht-2*k*(a0+b0c*ss*ss)*dd-2*k*k*ss*b0c*dt-(a0+b0c*t*t)*dd*dd-2*k*b0c*(t+ss)*dd*dt-k*k*b0c*dt*dt)

# Entire higher-angle identity at B=X+uZ=0; this certifies the other ratio chart.
p0,q0,yy=s.symbols('p q Y0')
high=U*(A*yy**2-2*D*q0*(p0-yy-q0)+q0*q0/2-p0*q0)+V*(C*(p0-yy)**2+(A+s.Rational(1,2))*yy**2)+(A+s.Rational(1,2))*U*V*yy**2+(D+s.Rational(1,2))*U*U*q0*q0
basequad=C*(p0-yy)**2+A*yy**2+D*(p0-yy-q0)**2+(p0-yy)**2/2-p0*q0
exact_noB=C*Dv*(p0-yy)**2+A*Du*Dv*yy**2+D*(p0-yy-Du*q0)**2+((p0-yy)**2+Du*V*yy**2+Du*U*q0*q0-2*Du*p0*q0)/2
check('exact_unbounded_ratio_higher_identity',exact_noB-basequad-high)
kapR=A*r*r-2*D*eta*(1-r-eta)+eta*eta/2-eta
kapS=C*(1-r)**2+(A+s.Rational(1,2))*r*r
check('unbounded_ratio_R_pivot',kapR.subs(base)-rho*eta/2)
check('unbounded_ratio_S_pivot',kapS.subs(base)-rho/2)

output={'status':'PASS','identities':len(checks),'checks':checks,'source_denominators_at_x_zero':denominators,'scope':'Interior eta,zeta,r,1-r,eta+r-1 units; x infinitesimal; total scale infinitesimal. Exact source/scalar/normal certificates for bounded and unbounded pure-testing v/u charts. Ordered-field bounds and closure are in interior_closure.tex.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({'status':'PASS','identities':len(checks)},indent=2))
