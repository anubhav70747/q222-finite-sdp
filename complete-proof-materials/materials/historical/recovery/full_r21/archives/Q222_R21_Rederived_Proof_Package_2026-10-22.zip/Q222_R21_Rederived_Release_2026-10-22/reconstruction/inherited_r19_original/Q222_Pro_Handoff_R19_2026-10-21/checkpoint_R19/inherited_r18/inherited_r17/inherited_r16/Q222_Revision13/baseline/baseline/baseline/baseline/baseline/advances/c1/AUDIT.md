# Scoped audit: C1 with unit eta and r, unbounded e

**Verdict: the stated all-tests theorem is justified, conditional on the unchanged native-source, contact-conductor, strict-residue, and full-parent reflection imports explicitly identified below.** This is a separate-agent mathematical review of this new extension, not a fresh audit of the entire retained package and not a global C1 or Q222 completion.

Reviewed source: `unit_eta_unbounded_e.tex`, SHA-256 `890eea5f538b9dae39c62552c1150d873a898f4e2a9e6e261d95f0c6b8b744c2` after the two precision repairs described below. Review date: 2026-10-18.

## Scope

The physical native C1 source has positive infinitesimal `k,zeta`, positive bounded-unit `eta` and `r=1-a eta`, and unbounded `e=k sqrt(eta/zeta)`. All four native shapes/gaps `a,t,M,J` are strictly positive, but may be infinitesimal. Testing and coefficient fields remain independent. Every independent projective testing pair and every real or complex state is covered in this domain.

The result does not include infinitesimal r, unbounded eta, bounded e, literal zero shapes, or any other uncovered native domain. The source retains its original event signs. In this particular domain the formulas actually force D and beta to be positive, so the theorem does not silently import a literal D=0 or beta=0 endpoint.

## Imports examined

Relative to `output/Q222_Checklist_Advance_2026-10-17/`:

- `baseline/current/prior/prior_core/c1/source_definitions.tex`: all seven native coquotients, the entire parent (SD2), four retained packets (SD3), exact remainder (SD4), state-coordinate inverse (SD5), source substitution (SD6), both full first normals (SD8), exact contact identities, and complete quadratic hard block.
- `baseline/current/prior/prior_core/c1/contact_conductor_proof.tex`: first-order and restricted second-order monic lifts, their proof without source inverses, five-term scalar, full normal factorizations, and weight-preservation mechanism.
- `baseline/current/prior/prior_core/circuit/circuit_frame.tex`: the two-pairing circuit identity and its positive definite 3-by-3 contrast matrix.
- `baseline/current/prior/inherited/c1_uniform_all_tests.tex`: exact two-current and critical-current identities, including homogeneous angle interpretation.
- `baseline/current/prior/inherited/c1_unbounded_e_w_unit.tex`: the exact five-root current identity (UW2)-(UW3).
- `advances/c1/arbitrary_state_ratio.tex`: full-parent Alice reflection and its m/c, beta/D permutation.

No large atlas replay was performed or used as a premise of this extension.

## Main algebra checks

Write H=r+eta, D_u=1+u^2 and use the four scalar monomials A=wv, B=delta v, C=delta b^2 u w, D0=delta^2 k^3 b^2. At residue, b^2=eta.

For ordinary u, directly taking bounded coefficient residues in the five-term source scalar gives

    8rH D_u^2 A^2 + 8rH D_u^2 B^2
    + 8D_u(C-a eta B)^2 + 8rH D_u D0^2
    + 8rD_u[eta(-1+2a) B^2 - 2BC].

The B,C part equals `8D_u[(B-C)^2+u^2 rH B^2]`, because

    rH + a^2 eta^2 + r eta(-1+2a) = (r+a eta)^2 = 1.

This validates (UE1) independently of the contact lift. The complete first-normal coefficients have residues 0 and `16 eta(B-C)`. Thus the relevant Gram off-diagonal entry is `8 eta`, not `16 eta`. The hard block has residue `diag(16rH,16rH+8eta^2/D_u)`, and its coupling to the `8D_u(B-C)^2` pivot has determinant `128D_u rH>0`. The remaining ordinary-u B pivot is strictly positive. All omitted coefficients are polynomials or bounded unit-denominator expressions with zero residue. This gives the claimed six-root strict Gram without contact division or a mixed inverse.

For infinitesimal u, the weights `(1,1,0,0,0,1,2,3)` preserve all three contact substitutions. The soft root weights are 4 for x and 5 for y,z,h,q1,q2. The three low-weight identities in (UE3) were re-executed against the native source reconstruction. The scalar remainder after the displayed correction starts at weight 12, L1 at weight 9, and L2-16b^2 x at weight 6. The paper's weaker lower bounds are sufficient. The residual scalar lies in the restricted monomial ideal and vanishes with its first contact jets: both properties survive subtracting T4 and k^2x^2. The residual first normals likewise remain in the monomial ideal and vanish at contact. Therefore the already-proved monic lifts yield scalar coefficient weights at least 2 and normal coefficient weights at least 1. No negative source exponents or inverses of delta,k,b,a,t arise.

The nonzero change in soft residue is exactly `8(rH-1)T4`; the `k^2x^2` correction has zero coefficient residue. Together with the old positive g4 square, this leaves `8x^2+8rH T4`. The two-pairing identity gives a strict Gram on y,z,h,q1,q2, with contrast principal minors 1,3/4,1/2 before multiplication by 8rH. The full hard-soft determinant is `128rH>0`. The nonzero normal residue has therefore been included, not discarded.

## Outer charts and endpoint checks

The exact formulas show both m/d and beta/d unbounded, uniformly in the positive openings. The Alice reflection sends this pair to c,D while leaving v unchanged. The two-current identity thus covers every bounded reciprocal Bob coordinate, including literal Bob infinity and every Alice coordinate/state.

At infinitesimal v and Alice infinity, the critical-current proof requires only bounded epsilon=d/g_c and positive-unit gamma=A g_c/d^2. Its potentially dangerous correction has factors c_u or v, so bounded sqrt(epsilon) suffices; infinitesimal epsilon is not required on this chart. The four-root residue is `diag(1,2,2,4 gamma_bar)`.

The cancellation in D/a must be performed before division by the possibly infinitesimal J. Using J+a=T and T-1 infinitesimal, the numerator `2c5/c3-J eta cd/c3` has residue 2/H. The harmonic denominator has residue

    residue(JH+a) = 1 + eta_bar(1-a_bar)^2 > 0.

Consequently epsilon is bounded and gamma is a positive bounded unit, even if a or J is infinitesimal. This establishes the advertised infinity chart without an unjustified d/c,d/D infinitesimal assumption.

For bounded u and infinitesimal v, unit w gives a pure-testing unit Q=D_u w. The five positive UW pivots have residues 8rH (four times) and 8D_u. The two negative corrections carry delta or delta^2 eta, hence zero residue. The other state case, on the negative-core branch, forces Z to be a unit by the displayed residue core. After Z=1, the exact core Schur identity forces w>0; positive-angle gauges and literal axes are inherited exactly. The remaining two u charts are exhaustive. All normalizations and homogeneous projective clearing factors are pure-testing factors. Complex states split into real and imaginary quadratic evaluations.

## Repairs made during review

1. The outer m,beta exit now identifies the exact Alice reflection and two-current identity, rather than leaving an unspecified universal adjacent-pair citation.
2. The text now identifies the normal coefficient versus Gram off-diagonal factor of two.
3. The phrase `J asymptotic to 1-a` was removed. It would be unsafe for infinitesimal J; 1-a can even be negative infinitesimal. The proof now uses the exact J+a=T identity and the canceled unit numerator, which validates the conclusion at those openings.

## Executed checks and limitations

- Re-executed `check_unit_eta.py`: all three exact low-weight identities passed; minimum residual weights were 12,9,6. This is algebraic checking from the native formula, not numerical sampling.
- Ran the separate small checker `audit_small_identities.py`: ordinary-u five-packet residue, both hard-soft determinants, harmonic denominator, two-pairing identity, and strict circuit principal minors passed (six checks).
- Confirmed `analysis_atlas/checklist_c1/source_from_formulas.py` is byte-identical to the packaged source reconstruction (`c6bb008e5941d8196e9645ff7d1ccccf7837d2543f8ee7aef0a2f00b3fedff94`).

These checks support the reviewed analytical argument. They do not certify global source exhaustion, lift extraction, or any unreviewed extension to bounded e.
