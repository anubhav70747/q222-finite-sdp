#!/usr/bin/env python3
"""Exact source-only C1/C2 contact correspondence; no new tensor admission."""
import json
from pathlib import Path
import sympy as s
B,z,y,H,r=s.symbols('B z y H r')
e=1-r; K=1+z; T=B+z*r; ac=1+z*r; S=ac+B-H
Delta=z+(1+z)*B+(1+z)*B**2+2*z*(1+z)*B*r+z**3*r**2+2*z**2*r+y*((1+z)*B+z+z**2*r*(2-r))
Pn=B+B**2+2*B*z*r+B*H*z+y*B*(1+z)+H*r*z**2+y*z**2*r*e
En=T*ac*S-r*Delta
checks={}
def ck(name,expression):
 assert s.cancel(expression)==0,name
 checks[name]=True
eta=y/B;zeta=B/z; rn=H/B;hn=r;theta=e
Pd=1+2*z*hn+rn*z*z*(hn+zeta)+z*zeta+eta*z*((1+z)*zeta+z*hn*theta)
ck('native_positive_denominator',Pn-B*Pd)
ck('positive_source_partition',e*Pn-K*(H+y)*T-En)
beta1=K*z*(rn+eta)*(hn+zeta)/(2*theta*Pd)-s.Rational(1,2)
n2=En/(2*r*Delta)
ck('formal_C1_beta',beta1+r*Delta*n2/(e*Pn))
ck('positive_half_core_weight',beta1+s.Rational(1,2)-K*(H+y)*T/(2*e*Pn))
# Source asymptotics on the BS chart B=e*l,z=aB,y=tB,H=hB.
a,t,h,gap,l=s.symbols('a t h gap l')
q=s.cancel((K*(H+y)*T/(e*Pn)).subs({z:a*B,y:t*B,H:h*B}).subs({B:gap*l,r:1-gap}))
ck('partition_weight_residue',q.subs({gap:0,h:0})-l*t*(1+a))
result={'status':'PASS','count':len(checks),'checks':checks,'scope':'Exact contact/source partition only. Physical C1 overlap requires n=0. Formal continuation has negative beta for n>0 and is not admitted as a physical C1 source.'}
if __name__=='__main__':
 print(json.dumps(result,indent=2))
 Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
