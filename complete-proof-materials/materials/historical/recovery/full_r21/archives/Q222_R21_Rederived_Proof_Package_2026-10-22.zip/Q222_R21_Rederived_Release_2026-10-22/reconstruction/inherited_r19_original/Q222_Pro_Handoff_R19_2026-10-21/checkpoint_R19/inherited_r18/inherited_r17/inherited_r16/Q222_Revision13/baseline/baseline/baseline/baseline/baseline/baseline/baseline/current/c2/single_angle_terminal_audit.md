# Local single-angle C2 terminal: bounded audit

Reviewed `single_angle_terminal.tex` and its exact checker/report.
**No substantive gap found.** The conclusion remains local to the
displayed reflected rational source and the independent testing chart
\(Z=1\), \(u,W\) infinitesimal, \(v-1\) infinitesimal. No all-tests
conclusion is inferred.

The three invariant conductor identities are exact. Substituting them
into the first monic expansion, and using
\(W=\kappa(u-S)\), gives the printed scalar identity

\[
f=R^2Q+\kappa^2S^2G_\eta+\rho R\mathcal A
  +uS\mathcal B+G_0(v).
\]

At contact the \((R,S)\)-Jacobian has determinant \(-2\). Thus exact
angle and state stationarity imply \(\mathcal A_c=\mathcal B_c=0\).
This cancellation establishes vanishing; it introduces no inverse of
\(\rho\) into a Gram coefficient. A second monic division gives bounded
coefficients on \((R,S,U,T)\): invariant differences supply the bounded
factors \(u\rho,W\rho,x,u^2,uW\), and the two angular remainder terms
are exactly \(RU\) and \(ST\). Also \(G_0=xg_0\) with bounded
\(g_0\), and exact value and Bob stationarity yield
\(g_0\in(v-1)^2\), giving the \(U^2\) term.

Both full-normal gates are valid:

- For \(L_X=uA_1+WB_1\), the graph cancels the entire degree-one
  leading function for every \(v\), so the invariant coefficient
  functions \(A_1,B_1\) vanish at the scaled origin. The decomposition
  \(L_X=-\kappa B_1S+uD_1\), followed by contact division of \(D_1\),
  has zero-residue coefficients on \((R,S,T)\). In particular its
  \(T\)-coefficient remains infinitesimal because the leading function
  vanishes identically in \(v\), rather than only at \(v=1\).
- For \(L_Y\), the complete singular contribution is
  \((p/\rho)B_2\), with bounded \(B_2\) vanishing at the scaled origin.
  The residual \(\rho E_0\) is bounded and has the same vanishing
  property; the potentially constant signed-core derivatives cancel.
  Hence \(L_Y=RB_2+\rho E_2\), with \((E_2)_c=0\), admits a
  zero-residue lift on \((R,S,U)\). This includes its angular quotient.

The hard block is bounded after scaling the Y normal, with residue
\(\operatorname{diag}(8,20/3)\). The scalar residue and exact zero
correction give the stated soft blocks with determinants
\(1245/1024\) and \(5/16\). Restoring both normal lifts therefore
preserves a strict six-root residue matrix.

The potentially unbounded root \(R=(uW-\kappa x)/\rho\) is harmless:
the strict-Gram input requires bounded coefficients, not bounded roots.
No coefficient in the argument divides by \(u+\rho\),
\(W+\kappa\rho\), \(u/\rho\), or a mixed contact expression.

The companion checker reports PASS, including all seven exact contact
identities, source reflection, both normal leading identities for every
\(v\), and the displayed soft determinants. I inspected that checker
and independently checked the division logic above; I did not rerun its
slower symbolic expansion. The complex-state extension is valid because
the imaginary part after normalizing \(Z=1\) has \(Z=0\), where the
negative core term disappears and the original expression is a sum of
positive packets.
