"""Exact full-parent remote identities. No source/test rate comparison."""
import sympy as s,json
from pathlib import Path
u,v,p,w,g,mu,nu,c,a,b=s.symbols('u v p w g mu nu c a b')
W,X,Y,Z=s.symbols('W X Y Z')
Q,B,U,V,S,R,EQ,EB,Zg,Za=s.symbols('Q B U V S R EQ EB Zg Za')
Du,Dv=1+u*u,1+v*v
r=u*W-Y; M=v*W-X+u*v*Y-u*Z; J=u*W+u*v*X-Y-v*Z
core=J**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2
checks=[]
def check(name,expr):
    q=s.factor(expr)
    assert q==0,(name,q)
    checks.append(name)
def residue(expr,small):
    return s.expand(expr).subs({x:0 for x in small},simultaneous=True)
def check_bounded(name,expr,variables):
    s.Poly(s.expand(expr),*variables)
    checks.append(name)
# Negative angle gauges work in the complete parent.
F=4*mu*M*M+4*c*Dv*r*r+4*a*Du*Dv*Y*Y+4*nu*J*J+4*b*Du*(v*Y-Z)**2+core
check('Alice sign gauge',F-F.subs({u:-u,W:-W,X:-X},simultaneous=True))
check('Bob sign gauge',F-F.subs({v:-v,W:-W,Y:-Y},simultaneous=True))
# (finite ordinary u, v infinity), Q=W+uY, B=X+uZ.
Dw=1+w*w
K1=(w*(u*g*EQ-Du*Y)+u*g*EB-Du*Z)**2+Du*(Y-w*Z)**2+Dw*g*g*EB*EB-Du*Dw*Z*Z
check('ordinary/infinity exact core', w*w*core.subs(v,1/w).subs({W:g*EQ-u*Y,X:g*EB-u*Z},simultaneous=True)-K1)
check('ordinary/infinity residue',residue(K1,[g,w])-Du*(Y*Y+u*u*Z*Z))
# (u small, v infinity): U=uZ, Za=g*w*Z. No division by u or w in final Gram.
A0=w*(u*g*EQ-Du*Y)+u*g*EB
K1small=A0**2+Du*Y**2+Dw*g*g*EB**2+Du*U**2-2*Du*g*(w*EQ+EB)*U+2*w*Du*u*Y*U
check('small/infinity exact core',K1-K1small.subs(U,u*Z))
check_bounded('small/infinity bounded core',K1small,[u,w,g,EQ,EB,Y,U])
check('small/infinity residue',residue(K1small,[u,w,g])-Y*Y-U*U)
F1small=2*K1small+4*mu*(EQ-w*EB)**2+4*nu*Dw*EB**2+4*b*Du*(g*Y-Za)**2
check('small/infinity full selected residue',residue(F1small,[u,w,g])-(4*mu*EQ**2+4*nu*EB**2+2*Y**2+2*U**2+4*b*Za**2))
# (u small, v unit), use U=uZ; perform cancellations before replacing Z.
K2=s.expand(core.subs({W:g*EQ-u*Y,X:g*EB-u*Z},simultaneous=True))
K2=s.cancel(K2.subs(Z,U/u))
check_bounded('small/ordinary bounded core',K2,[u,g,v,EQ,EB,Y,U])
check('small/ordinary residue',residue(K2,[u,g])-(1+v*v)*Y*Y-v*v*U*U)
# alpha packet can use independent pure source root Za=sqrt(alpha) Z.
check('small/ordinary alpha residue',residue(4*Du*(g*v*Y-Za)**2,[u,g])-4*Za**2)
# (u small, v small): U=uQ,V=vQ/g,EB=B/g,Zg=gZ,S=uvZ.
K3=(U-Du*Y+u*v*g*EB)**2+Du*v*v*Y*Y+Dv*g*g*EB*EB+Du*S*S+2*Du*u*Y*S-2*Du*u*V*Zg-2*Du*v*g*EB*S
check('small/small exact core',core.subs({W:Q-u*Y,X:g*EB-u*Z},simultaneous=True)-K3.subs({U:u*Q,V:v*Q/g,Zg:g*Z,S:u*v*Z},simultaneous=True))
check('small/small residue',residue(K3,[u,v,g])-(U-Y)**2-S*S)
# first infinity, finite v. Q=pW+Y, B=pX+Z.
Dp=1+p*p
Kp=s.cancel(p*p*core.subs(u,1/p))
K4=s.expand(Kp.subs({Y:g*EQ-p*W,Z:g*EB-p*X},simultaneous=True))
check_bounded('infinity/ordinary bounded core',K4,[p,g,v,EQ,EB,W,X])
check('infinity/ordinary residue',residue(K4,[p,g])-(W+v*X)**2)
# first infinity, v small, retain Y and R=vX.
K5=(W+Dp*R-p*Y-p*v*g*EB)**2+Dp*(v*v*Y*Y-2*v*g*Y*EB+2*p*Y*R-(v*g*EB-p*R)**2)+Dv*g*g*EB*EB
check('infinity/small exact core',Kp.subs(Z,g*EB-p*X)-K5.subs(R,v*X))
check('infinity/small residue',residue(K5,[p,v,g])-(W+R)**2)
# both infinite.
K6=s.cancel(w*w*Kp.subs(v,1/w)).subs({Y:g*EQ-p*W,Z:g*EB-p*X},simultaneous=True)
check_bounded('infinity/infinity bounded core',K6,[p,w,g,EQ,EB,W,X])
check('infinity/infinity residue',residue(K6,[p,w,g])-X*X)
# Exact leading C1 UI determinant and deleted-event boundaries.
h,C,A,D,al,d=s.symbols('h C A D al d')
t=s.symbols('t')
f=4*h*v*v*(W+u*Y)**2+4*C*(u*W-Y)**2+4*A*Du*Y*Y+(4*D+2*d)*(u*W-Y-v*Du*Z)**2+4*al*Du*Z*Z-4*d*Du*v*Y*Z-2*d*Du*v*v*Z*Z
mat=s.hessian(f,(W,Y,Z))/2
det=s.factor(mat.det())
Path(__file__).with_name('leading_determinant.txt').write_text(str(det)+'\n')
for name,sub,states in [('C', {W:Y/u},(Y,Z)),('A',{Y:0},(W,Z)),('D',{W:Y/u+v*Du*Z/u},(Y,Z))]:
    restricted=s.expand(f.subs(sub))
    det2=s.factor((s.hessian(restricted,states)/2).det())
    Path(__file__).with_name('deleted_'+name+'_determinant.txt').write_text(str(det2)+'\n')
report={'status':'PASS','count':len(checks),'checks':checks,'unverified_exports':['leading determinant','C-deleted determinant','A-deleted determinant','D-deleted determinant'],'scope':'Exact algebra only; positivity/exhaustion require remote_complement.tex. Leading determinants do not close the UI contact strip.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
