"""Focused exact checks for the all-tests source chart x/eta bounded.
The analytic bounded-Gram argument is in damped_gamma_source_subchart.tex.
No inherited-suite rerun and no numerical rate experiment.
"""
import sympy as s
import json
from pathlib import Path
checks={}
def ck(name,value):
    value=s.cancel(value)
    if value != 0:
        raise AssertionError((name,s.factor(value)))
    checks[name]=True

# Generic affected block: all substitutions are source-only.
u,v,W,Z,xi,Q=s.symbols('u v W Z xi Q')
k,c,t,h,l,A,C,D,bp,gam=s.symbols('k c eta h sqrtlambda A C Dp bprime gamma', nonzero=True)
x=k*k;lam=l*l;G=2*t*lam-2*t
E=t*u*W-v*Z;P=E/t-Q
H=t*c*c*v*W-u*Z;tau=t*c*W-Z
J=(u*v-x/c)*Z;R=l*t*k*(c*v-u)*W
T=v*(u*u-x)*Z-u*v*xi/h
source=C*P*P+A*Q*Q+D*(P-h*T)**2+2*bp*Q*T
old=source+lam*J*J+R*R+2*lam*x/c*u*v*tau*tau-lam*x*E*E+A*u*u*Q*Q+gam*u*v*Q*xi
b0=bp-G/2
source0=C*P*P+A*Q*Q+D*(P-h*T)**2+2*b0*Q*T
Rhat=R+G*k*Q/(2*l);Jhat=l*J+G*u*Q/(2*l)
cU=A-G*G/(4*lam)
new=source0-lam*x*(t*P+t/lam*Q)**2+Rhat**2+Jhat**2+cU*u*u*Q*Q+2*x/c*u*v*tau*tau+G*x/c*(u-c*v)**2*W*Z+G*x/c*P*H+(gam-G/h)*u*v*Q*xi
ck('DG3_entire_damped_two_circuit_block',old-new)
ck('DG3_extra_circuit_coefficient',2*lam-G/t-2)
pp,qq,tt,bb=s.symbols('P Q T b0')
K=C*D/(C+D);Delta=h*h*A*K-bb*bb
source0=C*pp**2+A*qq**2+D*(pp-h*tt)**2+2*bb*qq*tt
roots=(C+D)*(pp-h*D/(C+D)*tt)**2+h*h*K*(tt+bb/(h*h*K)*qq)**2+Delta/(h*h*K)*qq**2
ck('DG8_complete_source_three_root_identity',source0-roots)

# Unit-denominator native source formulas, with the original gaps cleared.
x,t,a,pi,ss=s.symbols('x eta a pi sigma')
r=1-t*ss;h=1-x*pi;th=x*pi;Kx=1+x;Rs=1+x*r;Ts=1+x*h
Ms=Rs-a*th;y=x*t/a;Es=1-x*t*h;Qc=1-x*r/a
Pd=1+2*x*h+r*x*x*(h+1/a)+x/a+t*x*(Kx/a+x*h*th)
P4=Ts*Es+x*(1-r)*(h+1/a)
Cn=Kx*(r+t)*Es/(2*Pd);Dpj=Kx*(1+y)*(r+t)/(2*Pd)
Bxth=Kx*(r+t)*x*(h+1/a)/(2*Pd)
At=P4/(2*r*Pd);As=t*At
m=Kx*x*a*(r+t)*h*(1+y)/(2*Ms*Pd)
al=x*x/a**2*(r+t)*(a*Rs*h*(1+y)+Ms*Es)/(2*Qc*Pd)
Lt=s.cancel(m/x)/a-a*(s.cancel(al/x)+s.cancel(m*th*th/x)+s.cancel(Bxth*th/x))
T0=As+al+s.Rational(1,2);Tm=T0+m
bp=At*r-m*th-al-s.Rational(1,2)+r*Tm*x/(2*a)
G=2*Lt-2*t
b0=bp-G/2
etaK=Cn*Dpj/(Cn*(Ts-ss)+Dpj*ss)
D0=h*h*At*etaK-b0*b0
# cU/eta=A/eta-G^2/(4 eta lambda), no eta denominator.
CUt=At-G*G/(4*Lt)
expected_dx=pi/2+s.Rational(1,4)+1/(4*a)
expected_dt=ss/2+s.Rational(3,4)
expected_ex=pi+1+1/(2*a)
expected_et=ss+s.Rational(3,2)
for name,f,ex,et in [('source_soft_determinant',D0,expected_dx,expected_dt),('higher_U_coefficient',CUt,expected_ex,expected_et)]:
    ck(name+'_origin_zero',f.subs({x:0,t:0}))
    ck(name+'_x_coefficient',s.diff(f.subs(t,0),x).subs(x,0)-ex)
    ck(name+'_eta_coefficient',s.diff(f.subs(x,0),t).subs(t,0)-et)
    checks[name+'_finite_source_division']=True
# These are precisely the source denominators in the expressions above;
# Lt is a positive unit, including after both original gap factors cancel.
for name,denom in [('a',a),('r',r),('Pd',Pd),('Qc',Qc),('Ms',Ms),('eta_harmonic_denominator',Cn*(Ts-ss)+Dpj*ss),('eta_lambda',Lt)]:
    assert s.factor(denom.subs({x:0,t:0}))!=0,name
checks['all_coefficient_formulas_have_source_unit_denominators']=True
Gfull=2*bp+2*Dpj*h/r-2*t*Bxth*h/r
ck('remaining_gamma_coefficient_origin_zero',(Gfull-G).subs({x:0,t:0}))
ck('remaining_gamma_eta_coefficient',s.diff((Gfull-G).subs(x,0),t).subs(t,0)-(ss+2))
ck('remaining_gamma_x_coefficient',s.diff((Gfull-G).subs(t,0),x).subs(x,0)-expected_ex)
out={'status':'PASS','count':len(checks),'checks':checks,
 'positive_source_residues':{'Delta0_x':str(expected_dx),'Delta0_eta':str(expected_dt),'cU_over_eta_x':str(expected_ex),'cU_over_eta_eta':str(expected_et)},
 'scope':'All-tests source subchart x/eta bounded, combined with the independently checked half-core WZ<=0 sign lemma and inherited remote theorem. No admission of x/eta unbounded.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
