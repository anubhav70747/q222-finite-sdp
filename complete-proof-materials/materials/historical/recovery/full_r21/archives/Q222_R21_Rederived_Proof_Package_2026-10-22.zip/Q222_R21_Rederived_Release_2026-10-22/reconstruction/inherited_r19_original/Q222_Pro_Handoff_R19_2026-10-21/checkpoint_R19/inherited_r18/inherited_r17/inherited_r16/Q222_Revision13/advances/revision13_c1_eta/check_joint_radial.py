"""Focused exact checks of JR1--JR8; does not replay baseline checks.

Run with SymPy 1.14 or later. The complete contact remainder is displayed
and checked algebraically below; its vanishing on the original source uses
the already verified six source jets explicitly listed in the new proof.
"""
import json
import time
from pathlib import Path
import sympy as s

start = time.monotonic()
checks = []
def ck(name, expr):
    num = s.fraction(s.cancel(expr))[0]
    ok = s.expand(num) == 0
    checks.append({"name": name, "pass": bool(ok)})
    print(("PASS " if ok else "FAIL ") + name, flush=True)
    if not ok:
        raise AssertionError((name, s.factor(num)))

x,z,b,h,sg,t,xi = s.symbols("x z b h sigma t xi")
u,w,q,W,X,Y,Z,Nx,Ny,Gam,R,Aroot,V = s.symbols(
    "u w q W X Y Z Nx Ny Gamma R Aroot V")
m,C,D,bt,p,l,aa,ll,mu,S0 = s.symbols(
    "m C D btheta p l astar lstar mu S0")
Q = 1-b; th = 1-h; g = h-Q; Du = 1+t; Dw = 1+xi
T = 1+t*h+b*xi; Jf = 1-T/sg
Mf = 1+t*g*xi/sg; Rf = 1-b*xi/sg
cG = 4*Du*(p*b*Dw+l*Q); cN = 8*Du*(p*Dw-l)
phi = 4*m*Mf**2+4*C*Dw*t*Rf**2+cG*t*(2*xi/sg-z)
phi += 4*D*t*xi*Jf**2+4*bt*th*Dw*t*t*xi/sg**2
phi += 2*(t*xi*Jf**2+Du*t*Q**2*xi**2/sg**2
          +Dw*t*t*th**2*xi/sg**2-Du*Dw*t*xi/sg**2)
Lx = -8*m*Mf+t*((8*D+4)*Jf+(8*bt+4*th)*Dw/sg)
Ly = 8*m*Mf-8*C*Dw*Rf+cN-(8*D+4)*xi*Jf-4*Du*Q*xi/sg
Lz = 8*m*g*Mf-8*C*Dw*b*Rf+2*cG-(8*D+4)*T*Jf
Lz += 8*bt*th*Dw*t/sg+4*Du*Q**2*xi/sg+4*Dw*t*th**2/sg-4*Du*Dw/sg

delta = xi-sg*z
Cr = s.cancel(s.div(s.div(phi,delta,xi)[0],delta,xi)[0]/t)
B = s.div(s.cancel(s.diff(phi,xi).subs(xi,sg*z)/t),t-x,t)[0]
Aq = s.cancel(s.div(phi.subs(xi,sg*z),(t-x)**2,t)[0]/z)
Az = s.div(Lz.subs(xi,sg*z),t-x,t)[0]
Bxq = s.div(Lx.subs(xi,sg*z),t-x,t)[0]
Ay = s.div(Ly.subs(xi,sg*z),t-x,t)[0]
Cx = s.cancel(s.div(Lx,delta,xi)[0]/t)
By = s.div(Ly,delta,xi)[0]
Bz = s.div(Lz,delta,xi)[0]
S = Az/sg-B

k0 = 2*b*((2*C+1)*b+4*D+4*p*sg+2*(2*C+2*D+1)*sg*(b*z-1))
k1 = 2*(1+2*m)*g*g+8*D*h*b+8*p*b*sg+4*bt*th
k2 = 2*b*b*(2*C+2*D+1)
Kr = k0+k1*t+k2*xi
Rx = -4*(2*D*b+(1+2*m)*g-2*bt)
Ry = 4*(t*(2*D*h+2*p*sg+(1+2*m)*g)
        +b*(2*C+2*D+1)*(xi+sg*z)
        +(2*C+1)*(b-sg)+2*D*(1-sg)+2*p*sg)
Er = 2*(C+D)*(b*z-1)+2*p+b*z-1
Rg = -4*(Er+2*p*t)
Z0 = (4*D+2*t*(4*D*h+2*bt*th+h*h)+2*t*t*h*h*(2*D+1))/sg**2
Zx = -4*u*(2*D-2*bt+h+t*h*(2*D+1))/sg
Hx = 2*(1+t+xi)+4*D*t+4*m*xi
Hy = 4*Du*(aa*Dw+ll)+4*m*t*z+4*C*z*Dw+(4*D+2)*xi*z+2*Du*z
Hz = 4*D*T*T+4*bt*th*t*Dw+2*t*Du*h*h
Hz += 2*b*b*xi*Dw*(1+2*C)+2*t*xi*g*g*(1+2*m)

ck("full scalar radial quotient including beta and BR3", sg**2*Cr-Kr)
ck("complete X radial quotient", sg*Cx-Rx)
ck("complete Y radial quotient", sg*By-Ry)
ck("joint Z diagonal cancellation including beta", Hz/sg**2+xi*Cr-xi/sg*Bz-Z0)
ck("joint radial Z first-normal cancellation", Bz-2*sg*Cr-b*Rg)
ck("joint Y Z cancellation", 4/sg*(2*D*T+b*Dw*(1+2*C)+t*g*(1+2*m))-By-Rg)
ck("joint X Z cancellation", 4*u/sg*(-2*D*T+2*bt*Dw-h*Du-(1+2*m)*xi*g)-u*xi*Cx-Zx)
ck("complete S angular slope", S-S.subs(t,x)-2*h*h*(2*D+1)/sg**2*(t-x))
Sshort=2*(h*h*(2*D+1)*(t+x)+4*D*h-2*b*p*sg**2*z+2*bt*th+h*h)/sg**2
ck("short exact S coefficient, no beta numerator reduction",S-Sshort)

# Exact divisions and their full contact remainders: no source remainder
# is suppressed by a generic-weight symbolic check.
phi0=phi.subs({t:x,xi:sg*z})
phit=s.diff(phi,t).subs({t:x,xi:sg*z})
phixi=s.diff(phi,xi).subs({t:x,xi:sg*z})
remphi=phi0+phit*(t-x)+delta*t*phixi/x
ck("complete scalar division and contact remainder",
   phi-z*(t-x)**2*Aq-t*(t-x)*delta*B-t*delta**2*Cr-remphi)
ck("complete X division and contact remainder",
   Lx-(t-x)*Bxq-t*delta*Cx-Lx.subs({t:x,xi:sg*z}))
ck("complete Y division and contact remainder",
   Ly-(t-x)*Ay-delta*By-Ly.subs({t:x,xi:sg*z}))
ck("complete Z division and contact remainder",
   Lz-(t-x)*Az-delta*Bz-Lz.subs({t:x,xi:sg*z}))

# Coefficient supports use the source contact once, with the remainder
# printed in the equality. For beta=0 these give A and Bx in JR2.
a1=2*h*h*(2*D+1)/sg
ck("angular A support and its exact contact remainder",
   Aq-(4*m/(x*x*z)+a1*t)+(phi0-x*phit)/(x*x*z))
ax=-4*h*(2*D+1)/sg
ck("angular X support and its exact contact remainder",
   Bxq-(t*ax+8*m/x)-Lx.subs({t:x,xi:sg*z})/x)
ck("angular Y exact coefficient", Ay-8*(p-l)-4*z*((1+2*m)*g+2*D*h+2*p*sg))

zphys=Gam/sg+u*w*W/sg
rootvals={Nx:X+u*h*Z,Ny:(Y-b*w*Z)/q,Gam:sg*Z-u*w*W,
          R:w*Z/q-u*q*W,Aroot:q*(u*u-x)*W,V:u*w*(u*u-x)*W}
ts={t:u*u,xi:w*w,z:q*q}
ck("complete scalar mixed conductor",(t*(t-x)*delta*W**2).subs(ts)
   -(u*sg*Aroot*R-V*Gam).subs(rootvals))
ck("complete scalar radial conductor",(t*delta**2*W**2).subs(ts)
   -(sg**2*(q*R-w*Gam/sg)**2).subs(rootvals))
ck("complete Z radial conductor",(u*w*delta*W*(sg*Z-u*w*W)/sg).subs(ts)
   -(q*w*R*Gam-w*w/sg*Gam**2).subs(rootvals))
ck("free V pivot through zero tests",(V**2-sg*t*Aroot**2-u*sg*(t-x)*Aroot*R+(t-x)*V*Gam).subs(ts).subs(rootvals))

# The exact six-root quadratic for generic bt. The scalar and angular
# remainders above must vanish on the source; beta=0 then has bounded S.
G=Hx*Nx**2+Hy*Ny**2+Z0*Gam**2+(cG+z*Kr)*R**2+Aq*Aroot**2
G+=-4*u*q*w*(2*m+2*D+1)*Nx*Ny+Zx*Nx*Gam+q*w*Rg*Ny*Gam+q*w*b*Rg*R*Gam
G+=u*q*w*Rx*Nx*R+(cN+z*Ry)*Ny*R+w*Bxq.subs(t,0)/q*Nx*Aroot
G+=u*Ay*Ny*Aroot+u*ax*Nx*V+u*sg*B*Aroot*R+S*Gam*V
# Full polynomial with the centered-cap remainder and no suppressed normal.
Mw=W-w*X+u*Y-u*w*Z; Rw=u*W-Y
Jw=u*w*W+u*X-w*Y-Z; Bw=X+u*Z
duc=1+u*u; dwc=1+w*w
Kw=Jw**2+duc*(Y-w*Z)**2+dwc*Bw**2-duc*dwc*Z**2
raw=4*m*Mw**2+4*C*dwc*Rw**2+4*(p/b)/q**2*duc*dwc*Y**2
raw+=4*D*Jw**2+4*(l/Q)/q**2*duc*(Y-w*Z)**2+4*bt/th*dwc*Bw**2+2*Kw
caps=4*(p/b-aa)*duc*dwc*((Y-b*w*Z)/q)**2
caps+=4*(l/Q-ll)*duc*((Y-b*w*Z)/q)**2+4*bt/th*dwc*(X+u*h*Z)**2
remainder=remphi*W**2+w*Lx.subs({t:x,xi:sg*z})*W*Nx
remainder+=u*q*Ly.subs({t:x,xi:sg*z})*W*Ny
remainder+=u*w*Lz.subs({t:x,xi:sg*z})*W*Gam/sg
ck("ENTIRE original parent equals six-root form plus all contact remainders",
   raw-caps-G.subs(ts).subs(rootvals)-remainder.subs(ts).subs(rootvals))

# Explicit positive residue block, including all finite t and either b opening.
la=2*(t*t+t+1)/(1+t)**2
hard=s.Matrix([[2*(1+t),-2*u*(1+t)],[-2*u*(1+t),2*(1+t+t*t)]])
v=s.Matrix([-2*u,1+t+la*t/2])
sch=(la-(v.T*hard.inv()*v)[0])
ck("exact bounded-u hard determinant",hard.det().subs(u*u,t)-4*(1+t))
ck("exact bounded-u last Schur complement",
   s.cancel(sch).subs(u*u,t)-(4*t+3)/(2*(1+t)**4))
ck("exact bounded-u angular radial determinant",
   s.det(s.Matrix([[2,2*u],[2*u,2*(1+t)]])).subs(u*u,t)-4)

# Check the residue of every reduced entry, retaining b symbolically.
H,dd,cc=s.symbols("H dd cc")
Az_explicit=4*((h*h/sg)*(2*D+1)*(t+x)+2*D*h/sg*(2-sg)
               +2*(p*b+l*Q)+h*h/sg-h
               +z*(4*D*b*h+2*p*b*sg+(1+2*m)*g*g))
ck("beta-zero exact bounded Az formula",Az.subs(bt,0)-Az_explicit)
Sbeta=S0+2*h*h*(2*D+1)/sg**2*(t-x)
Aexact=4*mu+a1*t
Gbeta=Hx*Nx**2+Hy*Ny**2+Z0*Gam**2+(cG+z*Kr)*R**2+Aexact*Aroot**2
Gbeta+=-4*u*q*w*(2*m+2*D+1)*Nx*Ny+Zx*Nx*Gam+q*w*Rg*Ny*Gam+q*w*b*Rg*R*Gam
Gbeta+=u*q*w*Rx*Nx*R+(cN+z*Ry)*Ny*R+q*w*8*mu*x*Nx*Aroot
Gbeta+=u*Ay*Ny*Aroot+u*ax*Nx*V+u*(Az_explicit-sg*Sbeta)*Aroot*R+Sbeta*Gam*V
Gbeta+=la*(V**2-sg*t*Aroot**2-u*sg*(t-x)*Aroot*R+(t-x)*V*Gam)
Glim=s.cancel(Gbeta.subs({bt:0,h:sg*H,D:dd*sg**2,C:cc*z,m:mu*x*x*z}))
Glim=s.expand(Glim).subs({x:0,z:0,sg:0,w:0,q:0,xi:0,H:1,dd:s.Rational(1,2),
                        mu:s.Rational(1,2),p:s.Rational(1,2),l:s.Rational(1,2),
                        aa:s.Rational(1,4),ll:s.Rational(1,4),S0:2})
expected=2*(1+t)*Ny**2+2*Aroot**2+4*u*Aroot*R+2*(1+t)*R**2
expected+=2*(1+t)*Nx**2-4*u*(1+t)*Nx*Gam+2*(1+t+t*t)*Gam**2
expected+=-4*u*Nx*V+(2*(1+t)+la*t)*Gam*V+la*V**2
ck("every full-parent residue entry, b and Q openings retained",Glim-expected)

# Beta-positive consequences of the same exact generic coefficient identity.
Az_generic=Az_explicit+8*bt*th*(1+sg*z)/sg
ck("generic exact Az formula",Az-Az_generic)
Ggeneric=Hx*Nx**2+Hy*Ny**2+Z0*Gam**2+(cG+z*Kr)*R**2+Aexact*Aroot**2
Ggeneric+=-4*u*q*w*(2*m+2*D+1)*Nx*Ny+Zx*Nx*Gam+q*w*Rg*Ny*Gam+q*w*b*Rg*R*Gam
Ggeneric+=u*q*w*Rx*Nx*R+(cN+z*Ry)*Ny*R+q*w*8*mu*x*Nx*Aroot
Ggeneric+=u*Ay*Ny*Aroot+u*ax*Nx*V+u*(Az_generic-sg*Sshort)*Aroot*R+Sshort*Gam*V
Cb=4*bt*th/sg**2
Ghat=Ggeneric-Cb*t*Gam**2-Cb*(1+x/t)*Gam*V-Cb*sg*Aroot**2-Cb*sg*(t-x)/u*Aroot*R
Pbeta=u*Z-x*w*W/sg
ck("exact beta contact root without inverse u",
   (t*Gam+V).subs(ts).subs(rootvals)-sg*u*Pbeta)
ck("entire beta-square and angular-reserve allocation",
   (Ggeneric-Ghat).subs(ts).subs(rootvals)-4*bt*th*Pbeta**2)
kp,H0,BB,PP=s.symbols("kappa H0 Bsource Psource")
ck("exact shared m reserve from beta source equation",
   (kp*h/sg-bt*th/sg-kp*H0/BB-bt/sg*(2*kp*PP/BB-th)).subs(h,(sg*H0+2*PP*bt)/BB))

# Normalize only source products already bounded by BE3--BE6.
# The replacement c = x*btheta*theta/sigma^2 is exact; no x/sigma
# comparison is used to compute the residue below.
cv,Bval=s.symbols("c_source Bval")
Ghat_normalized=Ggeneric-Cb*t*Gam**2-Cb*Gam*V-4*cv/t*Gam*V-Cb*sg*Aroot**2-Cb*sg*(t-x)/u*Aroot*R
ck("exact source-product normalization of beta remainder",
   Ghat-Ghat_normalized.subs(cv,x*bt*th/sg**2))
normal=s.cancel(Ghat_normalized.subs({h:sg*H,D:dd*sg**2,bt:sg*Bval,C:cc*z,m:mu*x*x*z}))
normal=s.expand(normal).subs({x:0,z:0,sg:0,w:0,q:0,xi:0,
                            mu:H/2,Bval:(H-1)/2,p:s.Rational(1,2),l:s.Rational(1,2),
                            aa:s.Rational(1,4),ll:s.Rational(1,4)})
Jres=2*(1+t)*Ny**2+2*Aroot**2+4*u*Aroot*R+2*(1+t)*R**2
Jres+=2*(1+t)*Nx**2+(4*dd+2*H**2*t*(1+t))*Gam**2
Jres+=-4*u*(1+H*t)*Nx*Gam-4*H*u*Nx*V+(2*H**2*(1+t)-4*cv/t)*Gam*V
ck("every bounded-H unit-u beta remainder residue",s.cancel(normal-Jres).subs(u*u,t))
kernel=s.expand(Jres.subs(V,-t*Gam)).subs(cv,s.Rational(1,2)-dd)
Kexpected=2*(1+t)*Ny**2+2*Aroot**2+4*u*Aroot*R+2*(1+t)*R**2
Kexpected+=2*(1+t)*Nx**2-4*u*Nx*Gam+2*Gam**2
ck("complete beta-cap kernel through D=0 and beta sphere endpoint",kernel-Kexpected)
ck("strict beta-cap kernel determinant",
   s.det(s.Matrix([[2*(1+t),-2*u],[-2*u,2]])).subs(u*u,t)-4)

Mb=s.symbols("Mbeta",nonnegative=True)
small_u=Ggeneric+(1+2*Mb)**2*(V**2-sg*t*Aroot**2-u*sg*(t-x)*Aroot*R+(t-x)*V*Gam)
small_u=s.cancel(small_u.subs({h:sg*H,D:dd*sg**2,bt:sg**2*Mb,C:cc*z,m:mu*x*x*z}))
small_u=s.expand(small_u).subs({x:0,z:0,sg:0,w:0,q:0,xi:0,u:0,t:0,H:1,dd:s.Rational(1,2),
                               mu:s.Rational(1,2),p:s.Rational(1,2),l:s.Rational(1,2),
                               aa:s.Rational(1,4),ll:s.Rational(1,4)})
small_expect=2*(Nx**2+Ny**2+Gam**2+R**2+Aroot**2)+(2+4*Mb)*Gam*V+(1+2*Mb)**2*V**2
ck("entire bounded-beta infinitesimal-u residue including all normals",small_u-small_expect)
ck("strict bounded-beta infinitesimal-u Schur complement",
   (1+2*Mb)**2-(1+2*Mb)**2/2-(1+2*Mb)**2/2)

out={"scope":"C14.1, x,z,sigma positive infinitesimal: all-tests full-parent proof for btheta/sigma^2 bounded (includes beta=0); bounded-H unit-u residual tests also proved through D=0. Infinitesimal-u with unbounded btheta/sigma^2 and the H-unbounded source remain open.",
     "imported_source_identities":["six original complete source contact jets",
                                  "BE sphere and source asymptotics",
                                  "large-L remote complement for all-tests join"],
     "checks":checks,"passed":len(checks),"seconds":round(time.monotonic()-start,3)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(f'{len(checks)} new exact assertions passed in {out["seconds"]} seconds',flush=True)
