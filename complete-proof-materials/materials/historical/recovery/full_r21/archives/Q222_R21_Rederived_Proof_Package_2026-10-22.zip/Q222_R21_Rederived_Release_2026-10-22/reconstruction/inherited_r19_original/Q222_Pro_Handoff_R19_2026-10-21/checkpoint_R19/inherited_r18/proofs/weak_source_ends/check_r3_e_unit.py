"""Focused R18 R3 unit-e identities; imports only WA symbolic definitions.
No historical test suite is rerun. Analytical positivity is in the TEX file.
"""
import json,time
from pathlib import Path
import sympy as s
start=time.monotonic(); checks={}
def ck(name,expr):
    vals=list(expr) if isinstance(expr,s.MatrixBase) else [expr]
    assert all(s.cancel(v)==0 for v in vals),name
    checks[name]=True
    print('PASS '+name,flush=True)
base=Path(__file__).resolve().parents[2]
sources=[base/'inherited_r17/proofs/weak_r8_small_r/check_r8_small_r.py',
         base/'work_r17/weak_r8_small_r/check_r8_small_r.py']
prefix=next(p for p in sources if p.is_file()).read_text()
exec(prefix[prefix.index('u,v,a,B,r,h,t,j='):prefix.index('ld=s.Matrix')])
N,mu,nu,K,tau,ast,cc,sl=s.symbols('N mu nu K tau ast cc sl',positive=True)
# Complete zero-angle G after C-hard normalization; l=sl^2.
Gn=G.subs(al,B*B*ast).subs({u:0,v:0})
P=s.diag(1/s.sqrt(N),sl/cc,1,1,1)
res=(P.T*Gn.subs({n:N-s.Rational(1,2),m:a*a*mu,C:cc*cc/sl**2,h:1-sl*sl})*P).applyfunc(s.cancel).subs(sl,0)
target=s.diag(1+a*a*mu/N,1,A,mu,ast)
target[0,3]=target[3,0]=-a*mu/s.sqrt(N)
ck('complete_C_hard_local_residue',res-target)
ck('g_unit_local_block_determinant',target.extract([0,3],[0,3]).det()-mu)
# Exact R5 centered m identity is imported, including its complete H_m.
Scale=s.diag(1,1,1,a,1);H0=s.zeros(5)
H0[0,3]=H0[3,0]=-1;H0[3,3]=2
cap=Scale*Gn.subs(m,K)*Scale+tau*H0
capres=(P.T*cap.subs({n:N-s.Rational(1,2),C:cc*cc/sl**2,h:1-sl*sl})*P).applyfunc(s.cancel).subs(sl,0)
tcap=s.diag(1+K/N,1,A,K+2*tau,ast)
tcap[0,3]=tcap[3,0]=-(K+tau)/s.sqrt(N)
ck('complete_C_hard_m_capped_residue',capres-tcap)
ck('g_infinitesimal_local_block_determinant',tcap.extract([0,3],[0,3]).det()-(K+2*tau-tau*tau/N))
# Source formula regular products, no cancellation by source inequalities.
cab=1+a*B*r;SrcS=1+B*(1-h+a*r);gg=1+a*(h*B+r-1)
Delta=a+(1+a*B)+(1+a*B)*B+2*a*B*(1+a*B)*r+a**3*B**2*r*r+2*a*a*B*r+t*B*(1+a+a*B+a*a*B*r*(2-r))
Ms=(1+a*B)*(1+a*r)*(h+t)-a*(1+t*B)*(1-r)*(1-h)
nrex=((1+a*r)*cab*SrcS-r*Delta)/(2*Delta)
muex=(1+t*B)*(1-r)*cab*SrcS/(2*gg*Delta)
Clex=cab*Ms/(2*Delta);Ahex=t*cab*(1+a*r)*SrcS/(2*Delta)
Djex=(1+a*B)*(1+a*r)*(1-a*t*B*r)*SrcS/(2*t*Delta)
aex=(1+a*r)*Ms/(2*(1-h*B)*Delta)
corner={B:0,h:1};e=1-r;g0=1-a*e
for name,expr,want in [
 ('nr',nrex,e/(2*(1+a))),('mg',a*a*muex*gg,a*a*e/(2*(1+a))),
 ('A',Ahex/h,t*(1+a*r)/(2*(1+a))),('D',Djex,(1+a*r)/(2*t*(1+a))),
 ('Cl',Clex,(1+a*r)*(1+t)/(2*(1+a))),
 ('alphastar',aex,(1+a*r)**2*(1+t)/(2*(1+a))),
 ('mu_gunit',muex,e/(2*g0*(1+a)))]:
    ck('R3_joint_source_residue_'+name,expr.subs(corner,simultaneous=True)-want)
# Qstar regularity: l cancels before division, exact a=0 factor.
b2ex=2*a*a*muex*h+Clex*(1-h)+Ahex*h+(B*B*aex+s.Rational(1,2))*h*h
ck('Qstar_exact_a_zero_cancellation',(b2ex-aex).subs(a,0))
num,den=s.fraction(s.cancel(b2ex-aex));quo,rem=s.div(s.Poly(num,a),s.Poly(a,a))
assert rem.is_zero
checks['Qstar_numerator_divisible_by_a']=True
# No l or r denominator remains, also at a=B=0,h=1.
assert s.cancel(den.subs({a:0,B:0,h:1}))!=0
checks['Qstar_unit_denominator_at_joint_a_l_r_opening']=True
ck('Qstar_exact_quotient',quo.as_expr()/den-(b2ex-aex)/a)
# Entire selected original parent, including the signed half-core.
W,X,Y,Z,J,S,R,dc,nc,mc,Ac,Dc=s.symbols('W X Y Z J S R dc nc mc Ac Dc')
Du=1+u*u;Dv=1+v*v
Me=v*W-X+u*v*Y-u*Z;Je=u*W+u*v*X-Y-v*Z
core=(Je*Je+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z*Z)/2
base=nc*Du*Dv*X*X+Ac*Du*Dv*Y*Y+Dc*Je*Je+core
pu=base.subs(W,(Y+dc*J)/u)+Dv*J*J
ck('complete_finite_u_unit_remote_residue',pu.subs({dc:0,v:0})-(J*J+nc*Du*X*X+Ac*Du*Y*Y+(X+u*Z)**2/2))
pv=(base+mc*Me*Me).subs(Y,u*W-dc*J)+Dv*J*J
ck('complete_finite_v_unit_a_unit_remote_residue',pv.subs({dc:0,u:0})-(Dv*J*J+(nc+s.Rational(1,2))*Dv*X*X+mc*(v*W-X)**2+Dc*V*Z*Z))
JeR=R+u*v*X-Y-v*Z
coreR=(JeR*JeR+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z*Z)/2
small=nc*Du*Dv*X*X+Ac*Du*Dv*Y*Y+Dc*JeR*JeR+coreR+mu*(v*S-a*X+a*u*v*Y-a*u*Z)**2+Dv*J*J
small=small.subs(Y,R-dc*J)
RZ=(t*(1+V)+V)*R*R/2-v*R*Z+V*Z*Z/(2*t)
ck('complete_small_a_finite_v_remote_residue',small.subs({dc:0,u:0,a:0,Ac:t/2,Dc:1/(2*t)})-(Dv*J*J+mu*V*S*S+(nc+s.Rational(1,2))*Dv*X*X+RZ))
RZmat=s.Matrix([[(t*(1+V)+V)/2,-v/2],[-v/2,V/(2*t)]])
ck('small_a_RZ_block_determinant',RZmat.det()-V*V*(t+1)/(4*t))
# Finite dihedral stabilizer, exact discrete claim.
stabilizer=[(sign,shift) for sign in (1,-1) for shift in range(8) if {(sign*i+shift)%8 for i in (0,6)}=={0,6}]
assert stabilizer==[(1,0),(-1,6)]
checks['C2_omitted_pair_dihedral_stabilizer']=True
payload={'status':'PASS','count':len(checks),'checks':checks,'scope':'Weak-C2 R3 e=1-r positive bounded unit; all tests after imported exact R4E14-16 endpoint joins. R3 e-infinitesimal remains open.','imported':['WA3-WA8 complete parent','R5.2-R5.4 complete mcap identity','WA10 bounded strict Gram lemma','R4E14-R4E16 homogeneous selected parent endpoints'],'seconds':round(time.monotonic()-start,3)}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
print(f'{len(checks)} checks passed in {payload["seconds"]} seconds',flush=True)
