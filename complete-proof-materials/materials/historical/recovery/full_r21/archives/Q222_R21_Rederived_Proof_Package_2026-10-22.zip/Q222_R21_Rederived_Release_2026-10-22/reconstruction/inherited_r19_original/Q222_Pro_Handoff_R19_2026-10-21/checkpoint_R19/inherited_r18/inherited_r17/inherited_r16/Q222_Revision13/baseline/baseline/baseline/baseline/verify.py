"""Reproduce small exact checks without modifying distributed receipts."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys,tempfile

ROOT=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description=__doc__)
parser.add_argument('--integrity-only',action='store_true')
parser.add_argument('--with-sympy',action='store_true')
args=parser.parse_args()
manifest=json.loads((ROOT/'MANIFEST.json').read_text())
bad=[]
for row in manifest['files']:
 p=ROOT/row['path']
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=row['sha256']:
  bad.append(row['path'])
if bad:
 raise SystemExit('Integrity failure: '+', '.join(bad))
print('PASS: integrity of',len(manifest['files']),'distributed files')
if args.integrity_only:raise SystemExit(0)
checks=json.loads((ROOT/'verification/CHECK_RUNS.json').read_text())['checks']
selected=[c for c in checks if args.with_sympy or not c.get('requires_sympy',False)]
if args.with_sympy:
 try:import sympy
 except ImportError:raise SystemExit('Install SymPy to run --with-sympy.')
with tempfile.TemporaryDirectory(prefix='q222_exact_') as tmp:
 dst=Path(tmp)
 shutil.copytree(ROOT/'advances',dst/'advances')
 native=dst/'baseline/advances/c1'
 native.parent.mkdir(parents=True)
 shutil.copytree(ROOT/'baseline/advances/c1',native)
 for c in selected:
  p=subprocess.run([sys.executable,str(dst/c['script'])],cwd=dst,text=True,capture_output=True)
  if p.returncode:
   print(p.stdout);print(p.stderr,file=sys.stderr)
   raise SystemExit('FAIL: '+c['script'])
  print('PASS:',c['script'])
print('Exact identities corroborated; global source/test exhaustion is not asserted.')
