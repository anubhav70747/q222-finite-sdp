# Scoped review of the rational-curve certificate

Reviewed 18 October 2026 by `coverage_reduction`, a separate agent in the same system. This is mathematical review and exact replay, not external peer review or formal verification.

**Verdict: PASS; no blocking gap found. Final two-square version reviewed and frozen.** Reviewed `rational_curve_tensor_sos.tex` and `check_curve_certificate.py`. The theorem admits the exact displayed rational source curve with 0<x<1/4, and the general corollary admits every real-rational source curve physical on a real interval, at every independent projective test and real or complex state. Both have a degree-independent bound of two tensor squares. Neither identifies the generic strong actual-II source domain with one of these curves.

## Interval factorization and transfer

The lemma holds over an arbitrary testing real closed field. Roots lying strictly inside the real interval have even multiplicity by sign change in that field. Their factors evaluate directly to tensor squares. Irreducible quadratic factors are positive sums of two pure-testing-coefficient polynomial squares. An exterior or endpoint linear root is handled by the displayed sum of a pure-source square and a pure-testing square, comparing the root only with the real interval endpoint. No order or identification of the two independent fields is used. The oriented constant is positive by evaluation at an interior nonroot; its square root is pure testing.

Every factor contributes at most two squares. The exact identity

`(A²+B²)(C²+D²)=(AC-BD)²+(AD+BC)²`

holds in every commutative ring, so its iteration preserves a bound of **two squares, independently of polynomial degree**. A single square is padded by a zero square, and the zero polynomial is immediate. Thus the former 2^N/64 bounds can be sharpened to two. Polynomial evaluation into the tensor ring preserves this identity even if that ring has zero divisors. Division by sqrt(L(x)) is by a nonzero pure-source element and restores the original parent exactly.

Physicality must be transferred as the single universal real assertion in both the interval parameter and the complete testing coordinates. The proof does this: after clearing positive source denominators, it is a polynomial first-order assertion over the reals, hence remains true in the testing real closed extension. Fixing its arbitrary testing experiment then gives P(T)>=0 for **all testing-field T in the interval**, which is what the factorization lemma needs. It does not merely transfer positivity at real T separately, and it does not embed the tensor product into an ordered field.

An explicit endpoint-positivity assumption is unnecessary in the general corollary. If the rational coefficient denominators have no zeros in the open real interval, their product of squares is a positive polynomial clearing factor. For each complete real testing experiment the cleared parent is a real polynomial, nonnegative on the open interval; continuity forces nonnegative values at both finite endpoints. This universal endpoint assertion transfers along with interior nonnegativity. Poles of the uncleared source at an endpoint cause no problem.

## Exact original source and physicality

All six original event coefficients and all printed source gaps are positive for every real 0<x<=1/4. For example, 8-5x²>=123/16, Qx>=31/8, 2-x>=7/4, and 4-x>=15/4. Also h>=7/2, g>=33/8, j>1/2, 1-xh=x/2>0, and b-xr>=63/16. Thus no source boundary or sign is silently crossed on this interval.

I separately reconstructed the six inherited rational source formulas at a=1,b=1/x,r=1/4,t=1/2,z=x and verified all six displayed coefficients exactly. I also reconstructed the entire original parent, substituted x=k² and the printed contact, and verified its value and all four state plus two angular derivatives are zero: **13 additional exact identities PASS**.

The required inherited dependency is the general parent geometry in `advances/dependencies/physical_core.tex` (reproduced in the main appendix) within the revision package, specifically the full parent (P), positive-definite Z=0 restriction, determinant identity, and convex Laurent form. This dependency has no bounded-b or infinitesimal-angle premise. At the displayed noncommuting contact there are three strictly positive transverse state eigenvalues and one zero. State and angular stationarity therefore make the determinant a stationary zero. Its Laurent convexity makes that zero its global minimum; the inertia criterion proves nonnegativity at all noncommuting angles, and the homogeneous commuting endpoints have nonnegative signed core directly. This proves physicality throughout the whole real interval, including x=1/4. No previously proved all-tests tensor certificate is being used to justify physicality.

## Full parent, endpoints, and square bound

The seven cleared packet coefficients are those of the original complete parent, including the signed core and every state-normal term. They have degree at most six in x. The lower endpoint is exactly

`P(0)=512[(1+v²)(uW-Y)² + (uW+uvX-Y-vZ)² + (1+u²)(vY-Z)²]`.

It is nonnegative for every testing-field state and angle. The upper endpoint is covered by the real-interval physicality proof and transfer. The degree-six calculation remains correct useful certificate data, but the improved multiplication identity gives at most **two squares** for the cleared scalar parent and, after the pure-source division, for F.

For literal projective endpoints, first homogenize each measurement pair using its two projective coordinates. The same source clearing polynomial and degree bound apply, and the endpoint expression remains a nonnegative homogeneous sum. There is no division by a vanishing measurement coordinate. State coordinates were arbitrary and homogeneous throughout, so every projective state is included. For a complex state, combine its real and imaginary evaluations **before** factorizing the resulting degree-six polynomial; the bound remains two. Restoring normalized probabilities, if desired, uses only positive pure-testing measurement and state norm factors.

## Consequence for the exact rational frontier examples

The corollary is a general all-tests admission for **every exact real-rational physical source curve**, not only the displayed actual-II family. For a one-parameter witness with coefficients in R(epsilon), positive leading terms of its finitely many source gaps and weights give one sufficiently small real interval 0<epsilon<delta on which all required signs hold. Its exact stationary identities and the general inertia/Laurent argument give physicality there. Shrink delta to avoid denominator zeros, clear by the product of denominator squares, and apply the corollary. Endpoint positivity is automatic as above.

In particular this applies to the exact epsilon families printed in `../c2_weak/ih_source_frontier.tex` and `../c2_weak/hh_and_boundary_frontier.tex`: the directed IH example, the reflected HH example, and the smaller-r unrestricted-Gram obstruction. Their original coefficients are real-rational in epsilon, and their checked positive leading signs give the required real interval. Reflection only permutes coefficients and preserves rationality and physicality. These examples therefore have all-tests two-square certificates by the new corollary.

They still disprove the proposed uniform reciprocal-product or initial-Gram bounds, and they still demonstrate physical nonemptiness of their **coarse angle/event types**. They do **not** witness nonemptiness of the residual sets obtained after removing the rational-curve admission. The generic multiparameter IH, HH, and strong-II domains are neither closed nor shown nonempty after all admissions by these rational examples alone.

## Fresh replay and limits

Fresh command:

```sh
PYTHONPATH=/workspace/scratch/964ce4ea4964/work/advance_2026_10_17/deps python analysis_atlas/oct18c_c2_strong/check_curve_certificate.py
```

Result after the expanded checker: **PASS21**, verifying six clearing identities, six original-source identities, five source-gap identities, the degree bound, the full endpoint coefficients, and two interval positivity bounds. The additional 13 source/contact identities above were checked directly during review (the six source substitutions now overlap the expanded checker). The supplied checker itself does not claim to prove the factorization lemma or the physicality theorem. Those arguments and the universal two-square product identity were reviewed separately.

No generic multiparameter strong-II closure follows. The result applies because this source's coefficients lie on the exact real rational curve displayed in the theorem; it does not replace independent source parameters by real constants.
