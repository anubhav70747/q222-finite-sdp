#!/usr/bin/env python3
"""Formal polynomial checks of the weighted full-parent division formulas."""
from collections import defaultdict
from pathlib import Path
import json

names=('u','p','delta','C','B','r','a0','a1','a2','BX','RX','BY','RY')
n=len(names)
def const(c):return {tuple([0]*n):c} if c else {}
def var(name):
 e=[0]*n;e[names.index(name)]=1
 return {tuple(e):1}
def add(*polys):
 d=defaultdict(int)
 for P in polys:
  for m,c in P.items():d[m]+=c
 return {m:c for m,c in d.items() if c}
def neg(P):return {m:-c for m,c in P.items()}
def sub(P,Q):return add(P,neg(Q))
def mul(P,Q):
 d=defaultdict(int)
 for a,c in P.items():
  for b,e in Q.items():d[tuple(x+y for x,y in zip(a,b))]+=c*e
 return {m:c for m,c in d.items() if c}
def prod(*polys):
 P=const(1)
 for Q in polys:P=mul(P,Q)
 return P
def sq(P):return mul(P,P)
v={name:var(name) for name in names}
u,p,delta,C,B,r,a0,a1,a2=(v[x] for x in names[:9])
U=sq(u);s=sub(U,p);t=mul(u,delta);j=mul(p,delta)
assert j==sub(mul(u,t),mul(s,delta))

# Most general biquadratic f consistent with f(p,0)=f_U(p,0)=f_delta(p,0)=0
# and the coefficientwise k0=O(p^2) normalization.
k0=prod(sq(p),add(C,neg(mul(r,delta)),mul(a0,sq(delta))))
k1=add(prod(const(-2),p,C),prod(p,sub(r,B),delta),mul(a1,sq(delta)))
k2=add(C,mul(B,delta),mul(a2,sq(delta)))
f=add(k0,mul(U,k1),mul(sq(U),k2))
rhs=add(mul(C,sq(s)),prod(B,u,s,t),prod(r,s,j),mul(a0,sq(j)),
        prod(add(a1,mul(a2,U)),sq(t)))
assert f==rhs

# Substitute j=u*t-s*delta, giving the explicit bounded two-root Gram.
gss=add(C,neg(mul(r,delta)),mul(a0,sq(delta)))
gst=prod(u,add(B,r,prod(const(-2),a0,delta)))  # coefficient of s*t, twice the Gram off-diagonal
gtt=add(a1,prod(add(a2,a0),U))
expanded=add(mul(gss,sq(s)),prod(gst,s,t),mul(gtt,sq(t)))
assert f==expanded

BX,RX,BY,RY=(v[x] for x in ('BX','RX','BY','RY'))
bX=add(mul(s,BX),prod(p,delta,RX))
bXframe=add(prod(s,sub(BX,mul(delta,RX))),prod(u,t,RX))
assert bX==bXframe
bY=prod(u,add(mul(s,BY),mul(delta,RY)))
bYframe=add(prod(u,s,BY),mul(t,RY))
assert bY==bYframe

receipt={
 'formal_polynomial_variables':list(names),
 'exact_scalar_biquadratic_identity':True,
 'exact_two_root_Gram_expansion':True,
 'exact_auxiliary_j_membership':True,
 'exact_even_state_cross_identity':True,
 'exact_odd_state_cross_identity':True,
 'f_expanded_monomials':len(f),
 'scope':'Universal exact identities only. Physical source unit/rate bounds and strict Gram residues are proved in WEAK_SOURCE_DUNIT_LOCAL_ADMISSION.md.',
 'mixed_inverses_used':False}
Path(__file__).with_name('WEIGHTED_FIVE_ROOT_CHECKS.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
