"""Upgrade the retained HI module to every n>=0 by an exact n packet."""
import json
import runpy
from pathlib import Path

out = Path(__file__).parent
base = runpy.run_path(str(out/'check_retained_contact_module.py'))
s = base['s']
for name in ('p','v','q','y','Sc','t','E','c','d','mu','al','H','R','r','z','ss','QQ','nc','nm','dp','dv','deltap','deltav','j','K','g','a','b','cs_raw','ms_raw','src','f0','Ds','Hs','Scs','contact','X'):
    globals()[name] = base[name]
nu = s.symbols('nu')
checks = {}


def check(name, expr):
    num = s.cancel(expr).as_numer_denom()[0]
    assert s.expand(num) == 0, (name,s.factor(num))
    checks[name] = True


cc = 2*(H**2-nu*(2*H+R))*dp*dv
dd = 2*H*(R+nu)*dp*dv
ee = 4*(H-nu)*dp*dv*g
cs = 4*dv*(y*((R+nu)*(1+q)-dp*g)+2*d*t*deltav/Sc)
ms = 4*dp*(q*(dv*g-(R+nu)*(1+y))-2*mu*E*deltap/Sc)
check('full_Nc_coefficient',cs_raw.subs(c,d+y*((R+nu)*(1+q)-t)/2)-cs)
check('full_Nm_coefficient',ms_raw.subs(al,mu-q*(E-(R+nu)*(1+y))/2)-ms)

TPQ = p*v*QQ/(r*z)
x = X+R*TPQ
check('actual_n_packet_center',x+g*ss-(H+R)*TPQ-v*z*nc+p*r*nm)
packet_delta = 2*nu*dp*dv*(X**2-x**2)/R
expected_delta = (
    4*nu*dp*dv*g*TPQ*ss
    -2*nu*(2*H+R)*dp*dv*TPQ**2
    -4*nu*dp*dv*TPQ*(v*z*nc-p*r*nm)
)
check('full_n_packet_difference',packet_delta-expected_delta)
check('full_graph_update', (cc-base['cc'])*TPQ**2+(dd-base['dd'])*QQ**2-(ee-base['ee'])*TPQ*ss-expected_delta.subs({nc:0,nm:0})-2*H*nu*dp*dv*QQ**2)

src_full = {**src,nu:f0/Ds}
check('full_source_c_minus_d',(c-d-y*((R+nu)*(1+q)-t)/2).subs(src_full))
check('full_source_mu_minus_alpha',(mu-al-q*(E-(R+nu)*(1+y))/2).subs(src_full))
astar,bstar,cstar,dstar,estar = [contact(f) for f in (a,b,cc,dd,ee)]
sig = a+b+cc+dd-ee
check('full_graph_source_value',(astar+bstar-cstar-dstar).subs(src_full))
check('full_graph_state_jet',(estar-2*(cstar+dstar)).subs(src_full))
check('full_graph_p_half_angle_jet',(contact(2*p*s.diff(sig,p))+4*(astar-dstar)).subs(src_full))
check('full_graph_v_half_angle_jet',(contact(2*v*s.diff(sig,v))+4*(bstar-dstar)).subs(src_full))
check('full_Nc_contact',(contact(cs)+4*(H-nu)*y*(1+q)*(1+y)).subs({H:Hs,Sc:Scs}))
check('full_Nm_contact',(contact(ms)-4*(H-nu)*q*(1+q)*(1+y)).subs({H:Hs,Sc:Scs}))

# Uniform residue throughout Rbar in [0,1], including Rbar=0.
rr = s.symbols('rr')
resnu = (1-rr)/(3+rr)
lam = 2*(1+rr)**2/(3+rr)
check('common_residue_fC',2*(1-resnu*(2+rr))-lam)
check('common_residue_fD',2*(rr+resnu)-lam)
check('common_residue_e',4*(1-resnu)*(1+rr)-4*lam)
check('common_residue_fA_fB',4*(1+rr)/(2*(3+rr))*(1+rr)-lam)
check('normal_diagonal_residue',4*(2*(1+rr)/(2*(3+rr)))/(1+rr)-4/(3+rr))

payload = {'status':'PASS','checks':checks,'base_checks':len(base['checks']),'scope':'Exact full-HI retained module and actual contact jets for every n>=0. No mixed inverses; source R is never replaced by its residue in exact identities.'}
(out/'check_full_hi_contact_module.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps({'status':'PASS','full_checks':len(checks),'base_checks':len(base['checks'])},indent=2))
