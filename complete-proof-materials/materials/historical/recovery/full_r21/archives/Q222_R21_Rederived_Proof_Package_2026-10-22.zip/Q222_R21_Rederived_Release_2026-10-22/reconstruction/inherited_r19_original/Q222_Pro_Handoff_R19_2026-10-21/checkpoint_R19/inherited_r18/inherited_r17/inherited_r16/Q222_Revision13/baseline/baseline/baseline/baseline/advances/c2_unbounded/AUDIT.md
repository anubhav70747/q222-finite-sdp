# Audit: unbounded b with B=xb infinitesimal

**Verdict: PASS for the full original parent and all independent projective tests in the source domain of `unbounded_b_small_B.tex`.** This includes literal `n=0`, unbounded `n`, either arbitrarily small complementary opening, and arbitrary coefficient ratio `B/sigma`. The physical noncommuting-residue theorem remains an explicit inherited input. This is a theorem about this rational C2 source leaf, not a classification of every physical C2 source. This review was conducted by a separate agent in the same system, not by an external referee.

I found no analytical gap or correction needed in the frozen proof. The scalar lemma is used together with both complete state-normal identities and the hard block; it is not promoted directly to a full-parent conclusion.

## Source bounds and complete scalar

The cancelled source formulas preserve all original weights. The source inequality gives `r0 <= 1/(1+K²) < 1`, so `1-r` is a positive unit, `m/sigma²` is a positive unit, and `D/B, alpha/B` are positive units. The identity `Nr=2(1+sigma r)AcSc/Delta_hat`, with `N=4n+2`, makes every occurrence of `nr` or `nr²` bounded without dividing by `r`. The normal factors `1/N` and `1/sqrt(N)` remain bounded when `n=0` or `n` is unbounded.

The opening identities use `Cz` and `Ay`, not separate upper bounds on `C` and `A`. In particular, `H_B=B(C+A)` can be unbounded; only its bounded reciprocal is used. The five whole scalar coquotients in (UB6) are bounded and have exactly the leading functions printed in (UB7).

At remote finite-angle residues the `(P,E)` block is strict by the global identity (UB9). The additional coupling of `B_u` to `E_X` is retained. Its exact Schur expression is `2-4/(N Dv)`, understood as a bounded expression also when `N` is unbounded. It is strict for nonzero finite `v`, and at `v=0` unless `n0=0`. The exceptional corner is therefore identified exactly, rather than discarded.

## Homogeneous matched contact and both normals

The scalar lemma does not normalize `W` or `Z`. Its monic divisions follow from the exact state, `u`, and `v` stationarity equations. Its Gram coefficients contain no inverse of `B`, `sigma`, or a mixed expression. Hence arbitrary actual `W/Z=k^(-1)sqrt(B/sigma)` and literal `Z=0` are included.

For the first full normal, the exact decomposition (UB16) has bounded coefficients after division by `sqrt(N)`. Its `R,S` coefficients vanish in residue, while its `T` coefficient can have the nonzero residue `gamma`; the proof explicitly keeps this term. The second full normal has the complete opening-cancelled form (UB13). Its homogeneous monic lifts are bounded with zero residue, including when `H_B` is unbounded.

The scalar `(R,U)` Schur margin is `8/(1+K²)²>0`. The radial `S²` residue is `2(1-r0)>0`. The hard pivots are `DK` and `4DK`, with zero mixed hard residue. The exact identity

```
T² − sigma U² − ST(v−k) − sigma k RU(v−k) = 0
```

is crucial: adding its real multiple `delta` introduces a positive `T²` diagonal at zero residue cost to the `(R,U)` block. The stated choice

```
delta > ell²/(4s0) + gamma²/(4DK)
```

is precisely the Schur bound for the complete `(S,E_X,T)` block. Thus both full normals are restored in a strict six-root Gram; no scalar-only step is being used in their place.

## Weak m and the n0=v0=0 corner

Here `Hc=4n+4m+2` is a positive unit, `zeta -> 1`, and `xi_c=O(m)`. The reserve

```
epsilon = 4alpha + 4n(4m+2)/Hc
```

has both `n/epsilon` and `B/epsilon` bounded, including literal `n=0`. The strong harmonic product is a positive unit even at either opening endpoint. Indeed, with `TC=Cz` and `TA=Ay`,

```
BCA/(C+A) = TC TA / [TC eta + TA(1−eta)],
```

whose denominator is a positive unit uniformly for `0<=eta<=1`.

The entire scalar `Z²` identity in the proof supplies the `B_epsilon` and `T0` pivots. The full `W²` coefficient at `u=0` retains its positive `m/sigma²` contribution on `V=sigma vW`; the `xi_c² v⁴` correction divided by `sigma²` is bounded and has zero residue. The mixed state term contains no strong `C,A` weight and is a bounded multiple of `uvWZ=vPE`, so its coefficient has zero residue at this corner. All five displayed scalar diagonal residues are strictly positive.

The full `X` normal at `v=0` is exactly `-8n zeta u³Z`, and its allocation to `B_epsilon` uses the bounded ratio `n/epsilon`. The remaining `Z` part is `uv²Z` times a bounded coefficient and is therefore small on `T0`. The `W` row must be split as the proof does:

* `u²vW` is allocated to `P=uW/sqrt(B)`, with coefficient `u sqrt(B) v`.
* The remaining `mvW` term is allocated to `V=sigma vW`, with coefficient `m/sigma=O(sigma)`.

Both coefficients have zero residue. No term `u²/sigma` is introduced. This is valid with no comparison between testing and source infinitesimals.

I independently reconstructed the complete corner `Y` normal using `H=C+A`, `t=C/H`, and the actual graph. It is exactly

```
F_Y|g = 8Dv H t(1−t) u³W
        + uW ew + u²Z ez + 8v(D−alpha)Z,
```

where `ew,ez` are bounded rational functions with only the positive-unit `Hc` denominator and are independent of the possibly unbounded `H`. This gives the claimed harmonic-opening lift after normalizing by `sqrt(C+A)`. The hard residue is exactly `diag(1,4)`. Thus the corner proof restores the entire parent even at literal `n=0`.

## Other projective tests and state endpoints

The four original outer-core identities remain exact after replacing their auxiliary source scale `x` by `B`. The cap `s=min(1,BC,BA)` is a positive unit, and the excess original `C,A` packets are nonnegative. In the first two outer charts the core itself supplies the pivot `2`, so replacing the former `4m0+2` by `2` is strict and requires no positive lower bound on `m`. The other two charts retain the entire `m` packet without using it for strictness. The reciprocal-`v` chart uses the independently proved positive unit `D/B`.

These identities cover the remaining commuting-angle axes and their literal projective endpoints. The matched finite-axis computation is homogeneous in state throughout, and the remote and double-zero computations are also identities in `W,Z`; no bounded-state chart is hidden in the all-tests join. The simultaneous sign copy and the real/imaginary splitting complete the stated projective and complex-state scope. The noncommuting test exit still uses the explicitly assumed physicality of the original source.

## Verification record

The following exact checks were replayed successfully:

| Checker | Exact checks | Scope |
|---|---:|---|
| `../oct18b_root/check_unbounded_b.py` | 17 | Cancelled original source and residues |
| `check_full_parent.py` | 33 | Complete scalar, both normal arrays, hard isolation, remote Schur, corner identities |
| `check_homogeneous_scalar_lemma.py` | 9 | Homogeneous scalar lift, conductor zero, scalar Schur margin |
| `check_audit_corner.py` | 9 | Independent complete corner Y normal, strong harmonic extraction, scalar cross bounds |

No numerical samples were used. The exact checks support the displayed algebra; the boundedness, positive residue, state endpoint, and all-tests arguments are reviewed above and in the proof.
