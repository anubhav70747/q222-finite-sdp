# Q222 analytical revision 6 — 19 October 2026

Start with the cumulative PDF and CHECKLIST.md.

The actual C1 UI subdomain now has a full-parent all-tests proof. Shared C1 event lemmas narrow other strips; both UH patterns leave only ordinary u/unbounded v. The two C2 double corners have a common exact II reduction, and HI has a complete new first-normal reduction. Six narrowed residual domains remain. The global atlas-free proof is unfinished.

## Contents

- Cumulative PDF and matching TeX: current proof first, complete earlier dependencies afterward.
- CHECKLIST.json, CHECKLIST.md, PROOF_STATUS.json: authoritative current quantified scope.
- advances/: four new analytical modules, six focused exact checkers, review records.
- baseline/: exact preceding revision, unchanged.
- verification/: new check receipts, baseline hashes, scope and review record.
- DEPENDENCIES.mmd: current proof graph.

## Reproduce

Python 3 and SymPy suffice for the algebra. Run `python3 verify.py --integrity-only` to check archive integrity, or `python3 verify.py --with-sympy` to replay the six new exact checkers in a temporary copy. Use pdfLaTeX twice on the root TeX. The old verifier remains available in baseline/; its broad historical checks were not rerun in this revision.

Exact algebra PASS results corroborate identities. The printed proofs establish the stated boundedness/positivity arguments, and the checklist retains every unresolved coverage obligation. No numerical sampling premise, external peer review, formal verification, or completed global pencil is asserted.
