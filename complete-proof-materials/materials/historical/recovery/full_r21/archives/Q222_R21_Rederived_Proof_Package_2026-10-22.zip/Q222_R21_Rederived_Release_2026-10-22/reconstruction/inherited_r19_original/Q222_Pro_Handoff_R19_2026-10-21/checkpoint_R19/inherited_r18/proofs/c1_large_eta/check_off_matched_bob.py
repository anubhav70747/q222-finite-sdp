#!/usr/bin/env python3
"""Focused exact corroboration; no numeric sampling and no source/test order."""
import json
from pathlib import Path
import sympy as sp

u, s, c, W, X, Y, Z, t = sp.symbols('u s c W X Y Z t', real=True)
C, A, m, D, alpha, beta = sp.symbols('C A m D alpha beta', positive=True)
Du = 1 + u*u
Au = 1 + u*u*s*s
p, q, y = u*W/t, t*Z, Y/t
b = X + u*Z
Nb0 = X + u*c*c*Z/Au
checks = []

def zero(name, expr):
    num = sp.together(expr).as_numer_denom()[0]
    rem = sp.rem(sp.Poly(sp.expand(num), c), sp.Poly(c*c+s*s-1, c)).as_expr()
    assert sp.expand(rem) == 0, (name, sp.factor(rem))
    checks.append(name)

# CE2 after division by D_v, in homogeneous Bob coordinates.
core = (c*(u*W-Y)+u*s*b)**2 + b*b + Du*s*s*Y*Y + Du*u*u*s*s*Z*Z \
       -2*Du*u*s*c*W*Z -2*Du*u*s*s*Z*b
Nb2 = Au*Nb0**2
Nr2 = Du*u*u*s*s*c*c*Z*Z/Au
frame_core = Nb2+Nr2-2*Du*s*c*p*q+t*t*c*c*(p-y)**2+t*t*Du*s*s*y*y \
    +2*t*u*s*c*(p-y)*Nb0 \
    +2*t*u*u*s**3*c*Du*(p-y)*Z/Au
zero('EB5 entire core', core-frame_core)

# The displayed normalized roots with their square roots canceled.
zero('m row EB6',
     s*(W+u*Y)-c*b - (s*W-c*Nb0-Du*u*s*s*c*Z/Au+t*u*s*y))
zero('D row EB6',
     c*(u*W-Y)+u*s*b-Du*s*Z
     -(t*c*(p-y)+u*s*Nb0-Du*s*q/(Au*t)))
zero('alpha row EB6', s*Y-c*Z-(t*s*y-c*q/t))
rho = C/(C+A)
Hs = t*t*(C+A)
ah = t*t*C*A/(C+A)
zero('harmonic source EB3 and EB7',
     C*(u*W-Y)**2+A*Du*Y*Y
     -(Hs*(y-rho*p)**2+ah*p*p+A*t*t*u*u*y*y))

nu, ell, P, Q = sp.symbols('nu ell P Q', real=True)
leading = (P*P-2*s*c*P*Q+(nu*nu*s*s+(1-nu)**2*c*c)*Q*Q)/2
zero('EB10 exact two squares', leading-((P-s*c*Q)**2+(s*s-(1-nu))**2*Q*Q)/2)
zero('EB9 determinant', (nu*nu*s*s+(1-nu)**2*c*c-s*s*c*c)/4-(s*s-(1-nu))**2/4)

out = {'status':'PASS','checks':len(checks),'identities':checks,
       'scope':'Exact homogeneous full-state identities and leading factorization only; source estimates and tensor-SOS domain require the analytical proof.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out, indent=2)+'\n')
print(json.dumps(out, indent=2))
