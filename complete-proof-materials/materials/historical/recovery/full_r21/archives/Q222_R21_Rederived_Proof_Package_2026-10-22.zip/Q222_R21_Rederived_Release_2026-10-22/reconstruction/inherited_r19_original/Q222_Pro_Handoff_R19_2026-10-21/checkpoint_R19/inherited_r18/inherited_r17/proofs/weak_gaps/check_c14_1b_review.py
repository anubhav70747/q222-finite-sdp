#!/usr/bin/env python3
"""Independent focused source-opening and reciprocal-endpoint review.
Does not replay the author's full-parent checker or a historical suite.
"""
import sympy as s
from pathlib import Path
import json
out={}
def ck(name,z):
    assert s.cancel(z)==0,(name,s.factor(z));out[name]=True
x,z,sg,h,b,e=s.symbols('x z sigma h b e')
th=1-h;r=b*z
P=sg+1+x+sg*z*(1+b*x+2*x*h)+sg*b*x*x*h*z*z+x*x*h*th*z
M=1+x*b*z-x*z*th
Np=z*(1+x*h)*(1-e)+(1-b*z)*(1+x*h*z)
Nl=(1+sg*b*z)*(e*(1+x*b*z)*(1+sg*z)+M*(1-e))
q=s.cancel((Np-Nl)/z)
s.Poly(q,x,z,sg,h,b,e)
ck('opening_cleared_p_minus_l_is_z_times_bounded_polynomial',Np-Nl-z*q)
ck('opening_cleared_p_has_half_residue',(Np/(2*P)).subs({x:0,z:0,sg:0})-s.Rational(1,2))
ck('opening_cleared_l_has_half_residue',(Nl/(2*P)).subs({x:0,z:0,sg:0})-s.Rational(1,2))
# Critical SP10 residue is computed after exact x/sigma divisibility,
# rather than multiplying a generic infinitesimal by h/sigma.
Nk=(1+x)*(1+sg*b*z)*(1+sg*z)-M*P
Fx=s.cancel(Nk.subs(sg,0)/x)
Fs=s.cancel((Nk-Nk.subs(sg,0))/sg)
s.Poly(Fx,x,z,sg,h,b);s.Poly(Fs,x,z,sg,h,b)
ck('exact_alpha_kappa_cancellation_source_polynomials',Nk-x*Fx-sg*Fs)
# Separate explicit evaluation with e->0, preserving arbitrary residue h.
ck('alpha_kappa_residue_minus_two_h',(2*(h*Fs+e*Fx)/(M*P)).subs({x:0,z:0,sg:0,e:0})+2*h)
# Original reciprocal quarter-core K_w, independent of source coefficients.
u,w,W,X,Y,Z=s.symbols('u w W X Y Z')
Du=1+u*u;Dw=1+w*w
J=u*w*W+u*X-w*Y-Z
core=J*J+Du*(Y-w*Z)**2+Dw*(X+u*Z)**2-Du*Dw*Z*Z
ck('literal_w_zero_core_exit',core.subs(w,0)-Du*(X*X+Y*Y))
ck('literal_u_zero_core_exit',core.subs(u,0)-Dw*(X*X+Y*Y))
ck('Z_zero_reciprocal_core_direct_squares',core.subs(Z,0)-((u*w*W+u*X-w*Y)**2+Du*Y*Y+Dw*X*X))
payload={'status':'PASS','count':len(out),'checks':out,'scope':'Same-system review: opening-cleared p/l bound, exact alpha_kappa source cancellation, and reciprocal sign-exit endpoints. The author separately checked all transformed full-parent identities.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n');print(json.dumps(payload,indent=2))
