#!/usr/bin/env python3
"""R14 focused joint-a boundary regularity and bounded-ratio Gram checks.

No baseline checker is imported or replayed. Positivity is in the companion text.
"""
import json
from pathlib import Path
import sympy as s

checks={}
def ck(name,expr):
    z=s.cancel(expr)
    assert z==0,(name,s.factor(z))
    checks[name]=True
    print('PASS',name,flush=True)

B,a,t,r,h,U,V=s.symbols('B a t r h U V')
n,m,C,Ah,D,al=s.symbols('n m C Ah D alpha')
e=1-r; half=s.Rational(1,2); x=a*B; y=t*B; ss=t/a
ca=1+a*B*r; Sc=1+B*(1-h+a*r)
g=1+a*(h*B+r-1); j=ca-(1-h)/t
dd=a+(1+a*B)+(1+a*B)*B+2*a*B*(1+a*B)*r+a**3*B**2*r*r+2*a*a*B*r+t*B*(1+a+a*B+a*a*B*r*(2-r))
M=(1+a*B)*(1+a*r)*(h+t)-a*(1+t*B)*(1-r)*(1-h)
src={n:((1+a*r)*ca*Sc-r*dd)/(2*r*dd),
     m:a*a*(1+t*B)*(1-r)*ca*Sc/(2*g*dd),
     C:ca*M/(2*(1-h)*dd),
     Ah:t*ca*(1+a*r)*Sc/(2*dd),
     D:(1+a*B)*(1+a*r)*(1-a*t*B*r)*Sc/(2*t*j*dd),
     al:B*B*(1+a*r)*M/(2*(1-h*B)*dd)}

aw=(C+D+half)*(1-h)**2+Ah*h
b2=2*m*h+C*(1-h)**2+Ah*h+(al+half)*h*h
b4=h*h*(m+al+half)+Ah*h
c2=n*r*r+(m+half)*e*e+al
d2=(n+half)*r*r+2*D*r
d4=(n+D+half)*r*r
e0=m*e+D*(1-h)+al*h+half
e1=m*h*e+r*(D+half)*(1-h)+(al+half)*h
Aw=aw*U+Ah*h*U*U+(m+b2*U+b4*U*U)*V
Az=al+c2*U+n*r*r*U*U+(D+d2*U+d4*U*U)*V
S=Aw*V/(t*t*U)+Az-2*V*(e0+e1*U)/t

q=n*r*r+(m+half)*e*e
mt=m-a*a*q
cF=(b2-n*r*r*a*a)/(t*t)
qV=aw/(t*t)+D-2*e0/t+2*a*q/t
fA=Ah*h/(t*t)+d2-2*e1/t+2*a*n*r*r/t+d4*U+b4*V/(t*t)
fB=mt/(t*a*a*B)
fC=(al-cF*y*y+al*U)/(t*a*B*B)
fG=-(qV+2*cF*y)/(a*B)
At2=U*V;Bt2=a*a*B*V*V/(t*U);Ct2=a*t*B*B;G2=a*B*V
Hsq=U-2*a*V/t+a*a*V*V/(t*t*U)
target=q*Hsq+n*r*r*U*Hsq+cF*(V-y)**2+fA*At2+fB*Bt2+fC*Ct2-fG*G2

source_variables=(n,m,C,Ah,D,al)
unit_den=2*r*g*(1-h)*(1-h*B)*(t-1+h+a*B*t*r)*dd
source_nums={z:s.cancel(unit_den*src[z]) for z in source_variables}
report={}
def regular(name,expr,target):
    enum,eden=s.fraction(s.factor(expr)); ep=s.Poly(enum,*source_variables)
    assert ep.total_degree()<=1
    num=s.expand(ep.coeff_monomial(1)*unit_den+sum(ep.coeff_monomial(z)*source_nums[z] for z in source_variables)); den=eden*unit_den
    divisions=[]
    for var in (B,a):
        while s.expand(den).subs(var,0)==0:
            quo,rem=s.div(num,var,var); assert rem==0,(name,var,'nondivisible'); num=quo; den=s.cancel(den/var); divisions.append(str(var))
    corner={B:0,a:0,h:0,r:1}; den0=s.factor(den.subs(corner)); assert den0!=0,(name,'singular',den)
    ck(name+'_joint_residue',num.subs(corner)/den0-target)
    report[name]={'monic_divisions':divisions,'corner_denominator':str(den0),'residue':str(target)}
    print('REGULAR',name,flush=True)
regular('cF',cF,1/(2*t))
regular('fA_constant',fA.subs({U:0,V:0}),half)
regular('fB',fB,half)
regular('fC_constant',fC.subs(U,0),half)
regular('fG',fG,3*half)
regular('m_tilde_over_B',mt/B,0)
KX=-n*r+(m+half)*e-a*q
KE=aw/t**2-e0/t+a*q/t
KY=(-(C+D+half)*(1-h)+Ah)/t+D-al
regular('KX_over_B',KX/B,t/2)
regular('KE_over_B',KE/B,-half)
regular('KY_over_B',KY/B,0)
regular('d4',d4,t/(2*(t-1)))
regular('b4',b4,0)
regular('alpha_over_B2',al/B**2,t/2)
u,w,k,c=s.symbols('u w k c')
# Independent c,k satisfy c²=a/t,k²=aB; avoid radicals in exact identities.
Aroot=u*u*w; Broot=c*k*u*w*w; Croot=k*k/c; G=k*u*w
ck('negative_circuit_infinitesimal_cross',G*G-c*w*Aroot*Croot)
Fv=u*u*w*w-t*B
for j0 in range(4):
    ck('normal_Buw_allocation_'+str(j0),B*u*w**j0-(u*w**(j0+1)*Aroot-u*w**j0*Fv)/t)
for i,j0 in [(3,1),(3,2),(3,3),(5,2),(5,3)]:
    ck('normal_higher_allocation_'+str(i)+'_'+str(j0),u**i*w**j0-u**(i-2)*w**(j0-1)*Aroot)
# Entire inherited scalar identity, now rewritten in a bounded root frame.
ck('bounded_ratio_entire_scalar_rewrite',S-(q*U*(1-a*V/(t*U))**2+n*r*r*U**2*(1-a*V/(t*U))**2+cF*(V-y)**2+fA*At2+fB*Bt2+fC.subs(U,0)*Ct2-fG*G2+al*U))
out={'status':'PASS','scope':'R9 with bounded pure-testing v/u, not reciprocal-ratio closure','checks':checks,'source_regularities':report,'count':len(checks)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print('FINAL',len(checks),len(report),flush=True)
