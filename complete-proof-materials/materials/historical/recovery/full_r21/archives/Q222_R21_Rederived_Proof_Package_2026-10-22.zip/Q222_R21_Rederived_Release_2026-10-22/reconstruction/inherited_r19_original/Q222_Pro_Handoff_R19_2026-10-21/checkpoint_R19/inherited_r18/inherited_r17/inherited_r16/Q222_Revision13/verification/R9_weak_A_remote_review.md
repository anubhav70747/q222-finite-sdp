# R9 review: direct all-tests join on the A-unbounded C2 subchart

**Status: pass for exactly the source domain WA1.** This is an adversarial same-system review, not external independent verification. Reviewed the current `work_r9/weak_A/five_root_remote.tex`, its exact checker and receipt, and its interface with the local five-root theorem. No main-package file was edited. The original physical source, strict gaps, and exact stationary contact remain hypotheses.

## Source reduction and finite testing charts

The four finite source residues in WR1 follow from joint regular reduction in B and h=H/B, with no comparison between their infinitesimal rates. The positive-unit assumptions on z/B, y/B, G/B, j, r, and 1-r imply rho>0, tau>1, 0<r0<1, and g0>0. Consequently n0,m0,C0,D0 are all strictly positive. In particular n is a unit on this restricted subchart, which is needed for the single-u-infinite endpoint. The identity for the numerator of C0 gives its strict positivity without an unstated sign assumption.

Scaling Y by sqrt(A) is pure source and retains the entire parent. Every normalized matrix coefficient is bounded, and all off-diagonal couplings of this hard state vanish in residue. The complete three-state residue WR2 has the determinant WR3. Its positive coefficients make this determinant strictly positive whenever U+V>0, including either axis. The W,X restriction at Z=0 is positive definite from the positive n,m,C event squares and the nonnegative restricted core. The real Schur criterion therefore proves strict positivity of the entire three-state residue, not merely its determinant. Both zero angle residues are handled by the already-reviewed local five-root identity.

## Reciprocal charts and literal endpoints

I checked both single-reciprocal residue identities against the complete original parent. WR4 is strictly positive for every finite residue of v, including zero; WR5 is strictly positive for every finite residue of u, including zero. Each includes the separately positive normalized Y pivot. No assumption on the relative source and testing rates enters these reductions.

WR6 is an exact identity for the full double-reciprocal parent, not a truncated expansion. In particular the signed core's final terms reduce exactly to

    p^2(1+q^2)X^2 + 2(1+q^2)XP - (1+q^2)P^2,

with P=pZ. Together with Q=qZ, these retain the original Z dependence. The five-root residue WR7 is strictly positive because the nontrivial block has determinant D0(n0+1/2)>0 and the remaining pivots are C0,1,m0+1/2. At literal p=q=0 the roots P,Q vanish, so the original Z-null direction is preserved.

The chart list is exhaustive: bounded/bounded testing angles, exactly one unbounded angle, and two unbounded angles; bounded angles with both residues zero use the local theorem. Literal infinities use polynomial homogenized chart values. Restoration away from zero uses only pure-testing squares p^-2, q^-2, or (pq)^-2. No division at a literal endpoint is performed. Signed charts and arbitrary state magnitudes are covered, and complex states follow by real/imaginary splitting.

## Tensor lift, evidence, and scope correction

Each strict residue matrix is lifted using WA10 after expansion in pure-testing deviations from its real chart center. Pure-source whitening has bounded inverse; the finite positive-product decomposition uses separate source and testing square roots. There is no mixed inverse, mixed square root, source/testing rate comparison, or imported strong-II remote admission.

The author's portable checks record 13 local identities and 38 remote identities as passing. The remote checks include joint source residues, the finite determinant and both balance identities, both single-infinity parents, the entire double-reciprocal identity, all 25 residue matrix entries, and its positive block determinant. My separate source-contact review checker verifies seven unchanged-source identities and is additional review evidence, not a proof dependency.

One quantifier issue was found and corrected: residual-complement membership was initially carried as a theorem premise although the proofs never used it, while the SO1 corollary had no established membership in that complement. Both current theorem texts now require only the actual source, gap, and contact hypotheses. They explicitly make no assertion that any residual intersection is nonempty. This makes the SO1 corollary valid on the entire stated two-parameter physical family; its prior global-polynomial-SOS obstruction is compatible with the separate-field radical lift used here.

No concrete mathematical gap remains in the reviewed local-plus-remote admission. The conclusion is confined to WA1, particularly its positive-unit assumptions on z/B and 1-r; their boundary openings are not admitted by this review.
