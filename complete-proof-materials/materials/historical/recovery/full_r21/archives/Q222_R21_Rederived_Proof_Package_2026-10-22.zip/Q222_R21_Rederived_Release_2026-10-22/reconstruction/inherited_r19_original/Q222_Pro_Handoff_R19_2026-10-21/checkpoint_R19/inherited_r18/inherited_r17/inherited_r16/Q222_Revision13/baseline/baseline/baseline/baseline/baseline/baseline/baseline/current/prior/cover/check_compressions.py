#!/usr/bin/env python3
"""Exact coefficient-field compression identities; standard library only."""
if not __debug__:
    raise SystemExit('Run without -O: assertions are proof checks.')
from collections import defaultdict
from itertools import permutations
from pathlib import Path
import hashlib
import json

# Integer polynomials in u,v,W,X,Y,Z,mu. u,v also denote p,q in reciprocal charts.
N = 7
ZERO = (0,) * N
class P(dict):
    @staticmethod
    def lift(x):
        return x if isinstance(x, P) else P({ZERO: x}) if x else P()
    def __add__(a, b):
        out = P(a)
        for m, x in P.lift(b).items():
            out[m] = out.get(m, 0) + x
        return P({m: x for m, x in out.items() if x})
    __radd__ = __add__
    def __neg__(a):
        return P({m: -x for m, x in a.items()})
    def __sub__(a, b):
        return a + -P.lift(b)
    def __rsub__(a, b):
        return P.lift(b) + -a
    def __mul__(a, b):
        out = defaultdict(int)
        for m, x in a.items():
            for n, y in P.lift(b).items():
                out[tuple(i + j for i, j in zip(m, n))] += x * y
        return P({m: x for m, x in out.items() if x})
    __rmul__ = __mul__
    def __pow__(a, k):
        out = P.lift(1)
        for _ in range(k):
            out = out * a
        return out
    def at(a, **kw):
        out = P()
        for m, x in a.items():
            n = list(m)
            for var, value in kw.items():
                i = names.index(var)
                x *= value ** n[i]
                n[i] = 0
            out += P({tuple(n): x}) if x else P()
        return out
    def degree_part(a, indices, degrees):
        return P({m: x for m, x in a.items()
                  if sum(m[i] for i in indices) in degrees})

names = ('u', 'v', 'W', 'X', 'Y', 'Z', 'mu')
u, v, W, X, Y, Z, mu = [P({tuple(int(i == j) for i in range(N)): 1})
                         for j in range(N)]
one = P.lift(1)


from fractions import Fraction
from itertools import combinations

def packets(u0,u1,v0,v1):
    Du,Dv=u0*u0+u1*u1,v0*v0+v1*v1
    R2=u0*v1*W-u0*v0*X+u1*v1*Y-u1*v0*Z
    R3=u1*W-u0*Y
    R5=u1*v0*W+u1*v1*X-u0*v0*Y-u0*v1*Z
    Ra,Rb=v1*Y-v0*Z,u0*X+u1*Z
    H=2*(R5**2+Du*Ra**2+Dv*Rb**2-Du*Dv*Z**2)
    return H,[Du*(v0*W+v1*X)**2,R5**2,Dv*R3**2,
              Du*Dv*Y**2,Du*Ra**2,R2**2,Dv*Rb**2,Du*Dv*X**2]


def sub(poly, mapping):
    vals=[mapping.get(name, P({tuple(int(i==j) for i in range(N)):1})) for j,name in enumerate(names)]
    ans=P()
    for ex,c in poly.items():
        term=P.lift(c)
        for val,n in zip(vals,ex):term*=val**n
        ans+=term
    return ans
checks=[]
def check(name,left,right):
    assert left==right,(name,left-right)
    checks.append(name)
# In the infinity-zero homogeneous chart the variables u,v denote p,v.
H,pack=packets(u,one,one,v)
state={'W':u,'X':P(),'Y':one,'Z':v}
h=sub(H,state);ev=[sub(p,state) for p in pack]
check('A_compression_core',h,-2*u*u*v*v)
for index in [2,4,7]:check('A_compression_zero_packet_'+str(index),ev[index],P())
check('A_compression_A',ev[3],(1+u*u)*(1+v*v))
check('A_compression_m',ev[5],u**4*v*v)
check('A_compression_D',ev[1],u*u*v**4)
check('A_compression_beta',ev[6],v*v*(1+v*v))
# C1 complementary chart: variables u,v denote u,q=1/v_old.
H,pack=packets(one,u,v,one)
state={'W':one,'X':-u*u*v,'Y':u*v*v,'Z':u*v}
h=sub(H,state);ev=[sub(p,state) for p in pack]
check('mc_compression_core',h,2*u*u*v*v*((u*u+v*v)**2-(1+u*u)*(1+v*v)))
for index in [4,6]:check('mc_compression_zero_packet_'+str(index),ev[index],P())
check('mc_compression_m',ev[5],(1+u*u*v*v)**2)
check('mc_compression_c',ev[2],(1+v*v)*u*u*(1-v*v)**2)
check('mc_compression_A',ev[3],(1+u*u)*(1+v*v)*u*u*v**4)
check('mc_compression_D',ev[1],u*u*v*v*(u*u+v*v)**2)
check('mc_diagonal_core',sub(h,{'v':u}),2*u**4*(3*u**4-2*u*u-1))
# Rational constants used for 0<x<=1/8; remaining bounds are monotonic
# or the displayed exact identity (1+x)(1-x)^2 <= 1.
x=Fraction(1,8)
assert 2*(1+x)**2<=3 and 2*(1+x)<=3
assert 4*(1+x*x)**2<=5 and 4*(1+x)**2<=6
assert 3*x<=2
checks.append('rational_interval_constants')
report={'status':'PASS','checks':checks,'count':len(checks),
 'arithmetic':'standard-library exact integer polynomials and rational constants',
 'scope':'Complete homogeneous coefficient-field test identities; human proof supplies nonnegative comparisons and scale consequences.',
 'no_bounded_d_normalized_source_assumption':True}
out=Path(__file__).resolve().with_suffix('.json');out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
