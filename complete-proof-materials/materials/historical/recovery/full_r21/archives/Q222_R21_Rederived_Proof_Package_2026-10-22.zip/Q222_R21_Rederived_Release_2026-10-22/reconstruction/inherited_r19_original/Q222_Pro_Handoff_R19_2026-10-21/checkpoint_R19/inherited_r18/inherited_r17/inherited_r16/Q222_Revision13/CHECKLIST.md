# Q222 revision 13: reconciled checklist, 20 October 2026

**Five new scoped all-tests admissions are retained after focused review. The global proof remains unfinished: four original rows are closed; C1.4 and C2.W.HH remain open.**

This update reconciles the Pro output with the intact revision-12 package. It adds no new mathematical result. The ten original work-item IDs and acceptance criteria remain unchanged; the actions below specify their current residual complements. All 76 files missing from Pro's reconstructed package have been restored, and all 722 revision-12 manifest entries are preserved in place or in provenance.

## Completed scoped parts

- [x] C14.1: large-L, large-eta bounded-M_beta source domain, including beta=0, for all tests.
- [x] C14.3: entire eta,zeta-unit small-L source region by RO+JO+HO, including all r and actual-j openings.
- [x] C14.4: ES source-bound prerequisite only. Its testing allocation remains open.
- [x] W.2-W.5 on exactly BS1/GR1: complete centered-circuit full parent and all projective joins, including n=0.
- [x] R9 remote testing complement only. Its local full parent remains open.

The five new registered theorem domains may overlap prior admissions; they are not five disjoint remaining tasks. The total is twelve registered subdomain theorems under the two open rows, not twelve disjoint regions.

## Current actions for the ten original work items

- [ ] **C14.1**: Work only on C14.1a (unbounded M_beta, bounded h/sigma, infinitesimal u,w) and C14.1b (unbounded h/sigma). The bounded-M_beta all-tests chart is closed. C14.1a needs the complete JU11 radial-normal conductor lift and all JU3 corrections, retaining the D=0 zero.

- [ ] **C14.2**: Prove the full parent for L a positive unit and eta unbounded through both shared-source sphere endpoints. No large-L admission is imported.

- [ ] **C14.3**: Close C14.3a: zeta unbounded with eta bounded; and C14.3b: zeta a positive unit with eta infinitesimal. The entire eta,zeta-unit region is now removed by RO+JO+HO, including actual-j and r openings.

- [ ] **C14.4**: Use the completed ES source estimates to allocate the complete parent at every residual infinitesimal-u test and every original Bob-angle type. The M/theta openings remain; no uniform m bound or bounded-eta estimate may be assumed.

- [ ] **C14.5**: Join the remaining six C1 source branches after their certificates, all registered admissions, original boundaries, signs and projective endpoints. Do not recount the newly closed source charts as open.

- [ ] **W.1**: Assign a full-parent certificate to each surviving ordered shape R1-R10 after the stated physicality, scale and prior-admission exclusions. The source partition is available; whole-row certificate coverage is not.

- [ ] **W.2**: Construct scalar or direct full-parent certificates on R1-R10. The BS1 centered q_s certificate is complete and removed; the polynomial-SOS obstruction remains compatible with SO1 tensor admission.

- [ ] **W.3**: Treat the remaining source-gap shapes. On R9 (e and a both infinitesimal with retained regular gaps), only the both-infinitesimal/zero local parent remains. The current WC chart assumes a a unit and cannot be imported: sqrt(t/a) and n/m lose its bounds.

- [ ] **W.4**: Where centered event packets are used on R1-R10, allocate all excess jets and higher terms without a uniform Hessian determinant bound. The BS1 allocation is already complete.

- [ ] **W.5**: Complete testing, projective, sign and exact reflection joins for R1-R10. The BS1 all-tests join is complete; R9 has only its remote complement proved.

## Precise limitations retained

- JU bounded coefficients and the radial-kernel circuit do not control the nonzero JU11 first radial normal or every JU3 correction. A strict cap on the old soft coordinates is impossible at the retained D=0 zero.
- ES gives source bounds, not the remaining C14.4 full-parent certificate; no uniform m bound is supplied at the M opening.
- R9 is remote-only: a=z/B infinitesimal makes sqrt(t/a) unbounded, and n/m=O(a^-2) does not give the old reciprocal control. R10 has no new all-tests result.
- The exact C2-to-C1 source overlap imports a physical C1 theorem only on the qualified n=0 boundary. At n>0 the formal C1 beta is negative.
- RO15 negative-beta coverage is local only under its explicit lower bound on beta+1/2; it does not supply a physical all-tests admission.

The two narrow next targets are R9.local and C14.1a.conductor. Completing either closes only its stated source/test complement; all other leaves and U1/U2 remain mandatory.

## New all-tests source theorems

| Admission | Exact source domain | Proof |
|---|---|---|
| C1.4.L_large_eta_large_bounded_beta_scale | Original C1.4: x=k^2,z=1/L,sigma=1/eta positive infinitesimals; M_beta=beta*(1-h)/sigma^2 bounded. No extra h/sigma or sphere-pivot hypothesis. Includes beta=0 and both b,1-b openings. | advances/revision13_c1_eta/joint_radial_beta_zero.tex, advances/revision13_c1_eta/beta_positive_extension.tex |
| C1.4.small_L_r_openings | Original native C1: x positive infinitesimal; eta,zeta,j0=eta+r-1 positive bounded units; arbitrary 0<r<1 and beta>=0. All independent tests/states. | advances/revision13_c1_small_l/r_opening_closure.tex |
| C1.4.small_L_actual_j_opening | Original C1: x and actual j=eta*(1+x*h)-1+r positive infinitesimals; eta,zeta,r,1-r positive bounded units. Includes j0=0 or slightly negative, beta=0 and arbitrary j/x. | advances/revision13_c1_small_l/j_opening_closure.tex |
| C1.4.small_L_simultaneous_r_j_opening | Original physical native C1: x=k^2,r and actual j=eta*(1+x*h)-1+r positive infinitesimals; eta,zeta positive bounded units. Includes beta=0 and arbitrary independent x,r,j and testing rates. | advances/revision13_c1_small_l/simultaneous_r_j_closure.tex |
| C2.W.HH.small_e_a_unit | Exactly physical BS1/GR1: B,z,y,e=1-r,h=H/B positive infinitesimals; a=z/B,t=y/B,G/B,j,L/B positive bounded units; n>=0 and all original intersections; residue(t)>1. All independent projective tests/states. | advances/revision13_weak_local/centered_circuit_closure.tex |

Intersect with unchanged original physicality, stationary contact, strict source gaps, nonnegative event weights, positive infinitesimal total scale, and the complement of prior admissions and exact symmetry images. A residual listing does not establish nonemptiness.

RO expands IC1 through both r openings; JO and HO close the remaining actual-j types when eta,zeta are units. These are five source theorems, not whole-row closures.

## Smallest remaining C1 frontier

| Leaf | Source | Tests left | Missing allocation |
|---|---|---|---|
| C14.1a | L,eta unbounded; h/sigma bounded; M_beta unbounded | u,w=1/v infinitesimal at residual tests | Finite separated circuit/conductor lift of the JU11 first radial normal and every correction in the bounded exact JU3 parent, respecting the extra D=0 zero. |
| C14.1b | L,eta unbounded; h/sigma unbounded | Inherited bounded u and infinitesimal w | Opening-uniform full-parent allocation on the shared source sphere. |
| C14.2 | L a positive unit; eta unbounded | Inherited residual testing complement | Full scalar and all-normal certificate through both sphere endpoints. |
| C14.3a | L infinitesimal; eta bounded; zeta unbounded | Only u,v both infinitesimal | Contact-root lift retaining the large-zeta scale. |
| C14.3b | L infinitesimal; zeta unit; eta infinitesimal | Only u,v both infinitesimal | Joint eta and source-gap opening frame. |
| C14.4 | L infinitesimal; eta unbounded; zeta noninfinitesimal | u infinitesimal; all original Bob angle types | Full native parent allocation from S=sigma+L bounds, retaining M and theta openings. |

C14.3 is an exact ordered exhaustion: split zeta unbounded versus unit, then eta infinitesimal versus unit. With eta,zeta units, actual j is either a unit (RO) or infinitesimal. In the latter case 1-r is a unit; r a unit is JO, and r infinitesimal is HO. Thus eta,zeta units are fully covered. No comparison of j with x.

## Weak-C2 frontier

BS1/GR1 is entirely removed. See advances/revision13_weak_local/frontier_audit.tex for the ordered residual source partition. On its nice-A part, e infinitesimal leaves a=z/B infinitesimal or unbounded. The joint e,a-infinitesimal chart has only local both-infinitesimal tests left after source-checked GR transfer; its local WC extension is unproved.

The global polynomial-SOS obstruction is preserved. Its SO1 family is already covered by the earlier tensor proof. A failed frame is not a counterexample to tensor SOS.


Types: I = positive infinitesimal; U = positive bounded unit; O = unbounded. Put a=z/B, t=y/B, h=H/B, l=1-h, e=1-r, g=G/B. Every shape retains all original source conditions and prior exclusions; the rows are not assertions of nonemptiness.

| Weak-C2 row | Ordered residual shape | Necessarily unbounded weights |
|---|---|---|
| R1 | t I | C,D |
| R2 | t O | C,A |
| R3 | t,h U; l I | C |
| R4 | t,h,l U; j I | D |
| R5 | t,h,l,j U; r I | n |
| R6 | t,h,l,j,r U; g I | m |
| R7 | t U; h,g I; exclude r,j both I | A,m |
| R8 | t,g U; h,j I | A,D |
| R9 | t,g,j U; h,e,a I | A |
| R10 | t,g,j U; h,e I; a O | A |

## Original work items and unchanged criteria

### C14.1 — open

**Original task.** Complete the joint scalar, radial and first-normal allocation. On beta=0 retain the exact contact cancellation and first radial square BR1; allocate the surviving kappa22 t^2 xi^2 packet from BR3, its centered lower terms, every radial first normal, and Zuw, including the 8(ab)b/sigma term through Q=1-b infinitesimal. Then cover beta>0, complementary d0,b0,h/sigma branches and every bounded u.

**Completion criterion.** A finite full-parent Gram controls all w-dependent terms through d0=0 and b0=0, every bounded u, independent testing rate and projective join.

**Revision 13 progress.** beta=0 and the larger bounded-M_beta source chart are closed for all tests. Bounded h/sigma with unbounded M_beta has all unit-u tests covered, including D=0. For infinitesimal u there, JU removes every coefficient pole but leaves an exact circuit/normal lifting obligation. Unbounded h/sigma remains.

### C14.2 — open

**Original task.** For L a positive unit and eta unbounded, build a full-parent allocation from the source sphere BE6 and shared packet BE8. Cover both d0=0 and b0=0 and all inherited residual tests. The new EN theorem assumes L unbounded and cannot be imported here.

**Completion criterion.** Exact full-parent finite SOS on the L-unit eta-unbounded residual domain; no assumed bound on x eta^2 h and no lost coefficient opening.

**Revision 13 progress.** Open in its exact original scope. The large-L proof is not imported at unit L.

### C14.3 — open

**Original task.** After removing IC1, close L infinitesimal and eta bounded with eta infinitesimal, zeta unbounded, or at least one of r,1-r,j0=eta+r-1 not a positive bounded unit. Retain the positive actual j=eta(1+xh)-1+r opening; j0 may vanish or be slightly negative. Allocate SN1-SN2 and its negative defect with all original normals and independent rates.

**Completion criterion.** One legal weighted positive Gram for the entire printed remainder, uniform in all SB source openings and independent rates; retain the proved remote complement.

**Revision 13 progress.** RO, JO and HO together admit the entire eta,zeta-unit region, including all r and actual-j openings. Remaining: zeta unbounded with eta bounded; or zeta unit with eta infinitesimal.

### C14.4 — open

**Original task.** For L infinitesimal and eta unbounded, first prove source-weight bounds valid in this regime, then allocate SN1-SN5 and SN8-SN11 on every residual infinitesimal-u test chart. Do not use bounded-eta estimates SN7 or SN12 or an unproved map to C1.1.

**Completion criterion.** Exact full-parent certificates for every residual Bob angle type, with all source openings and projective joins. No unproved mapping to C1.1.

**Revision 13 progress.** Source-bound prerequisite completed by ES1-ES10 through all original openings and coefficient endpoints. Complete original-parent allocation for the residual infinitesimal-u tests remains open.

### C14.5 — open

**Original task.** Join the four residual source alternatives with the four now-admitted C1.4 source subdomains, all inherited admissions, exact sign gauges, literal coefficient boundaries and projective endpoints.

**Completion criterion.** A quantified union of the four new source charts, four admitted C1.4 subdomains, inherited admissions, source openings and retained coefficient boundaries covers the entire original C1.4 row.

**Revision 13 progress.** New local/remote joins are explicit. Their union with inherited domains still leaves the stated C14.1-C14.4 complement; the original row is open.

### W.1 — open

**Original task.** Exhaust the complement of the expanded weak-C2 admission. On 1-r infinitesimal with z/B a unit and the other GR1 hypotheses, retain the exact physical constraint (1-r)Q>=BK, including equality n=0. The source-only ratios B/(1-r),n/(1-r) are bounded. The literal r=1,B>0 anchor is invalid. Other source-gap openings and z/B types remain separate.

**Completion criterion.** Every residual physical source configuration from the proved source alternatives is assigned to a valid full-parent certificate; no source gap or total-scale intersection is dropped.

**Revision 13 progress.** BS1 removed in its exact scope. Other source-ratio and gap openings remain; the frontier audit gives an ordered residual partition.

### W.2 — open

**Original task.** Construct scalar or direct full-parent certificates on the complement of the expanded admission. Preserve the polynomial-SOS obstruction and its already proved SO1 tensor admission.

**Completion criterion.** An exact scalar certificate on every original residual source/test pair. Any restriction excluding SO1 must be justified by proved prior admissions; scalar success alone does not close the parent.

**Revision 13 progress.** Complete scalar and full-parent certificate proved on BS1. Global polynomial-SOS obstruction preserved; SO1 remains tensor-admitted. Other source domains open.

### W.3 — open

**Original task.** On the small-(1-r), z/B-unit chart of BS1/GR1, construct a complete local full-parent certificate for u,v both infinitesimal or zero, retaining (1-r)Q>=BK and n=0. The simple sqrt(1-r)R2 Gram still has the known Js and fs poles, despite bounded diagonal coefficients. Then treat every remaining source-gap chart.

**Completion criterion.** A finite legal weighted Gram contains both soft states, every first state normal and every hard quadratic coupling in the independent source/testing fields.

**Revision 13 progress.** COMPLETED ON BS1: complete local parent, both soft directions, every first normal and hard coupling, n=0 and arbitrary B/e,h/e. The broad item remains open on other source-gap charts.

### W.4 — open

**Original task.** For branches still using centered m,D packets, control every excess jet and higher term with an exact joint Gram, without a positive real lower bound on a possibly vanishing Hessian determinant. The direct WA proof avoids that subtraction only on its own source domain.

**Completion criterion.** An exact joint allocation controls centered-packet jets and all higher terms, including zero or arbitrarily small source-Hessian determinant; justify any subtraction by its own inequality.

**Revision 13 progress.** On BS1 the joint q_s packet allocates its angular and normal remainders without a Hessian lower bound or physicality claim for a subtracted remainder. Other centered-packet domains open.

### W.5 — open

**Original task.** Join a valid local certificate on BS1/GR1 to its now-proved remote complement. Complete remote, literal-projective, sign and exact weak-event reflection joins for the other unproved source charts.

**Completion criterion.** All residual testing charts, literal projective endpoints, signs and exact reflected weak-event orientation are covered, completing the original C2.W.HH row.

**Revision 13 progress.** COMPLETED ON BS1: WC joins GR2-GR7, axes, signs, complex states and exact reflected orientation. Other source charts prevent a whole-row closure.

## Universal steps

- **U1: blocked.** Residual C1.4 and weak-C2 branches prevent universal exhaustion.
- **U2: blocked by U1.** Corollary 3.19 was checked in the primary source. Its universal SOS hypothesis is sufficient for existence, but remains unproved here.
- **U3: completed.** Current ledgers and archive are reconciled; all missing revision-12 members are restored. The original Pro truncation report is retained as history. PDFs and mathematical source text are preserved unchanged from Pro.

## Acceptance gates

- G1 Original source entry, signs, and every bounded ratio.
- G2 Exact full-parent decomposition preserving actual contact and jets.
- G3 Admissible roots; only pure-source/pure-test inverses or radicals.
- G4 Every first state normal and every hard quadratic coupling.
- G5 Strict residue or exact SOS; resolve every equality case.
- G6 All independent projective tests, signs, real/complex states.
- G7 Literal retained coefficient boundaries and all positive opening rates.
- G8 Analytical review plus narrowly scoped exact algebra corroboration.
- G9 Admit only the proved quantified domain and exact symmetry images.

## Verification and input integrity

- Pro records **190 named exact checks + 21 finite source-regularity audits**, in nine new scripts. Together with 632 prior records, this is 843 recorded checks in 48 scripts.
- This reconciliation verified all nine script/receipt SHA-256 bindings and the input package's integrity and ledger/dependency checks. No algebra suite was rerun.
- Two focused same-system reviews checked new C1 and weak-C2 theorem scopes, complete-normal and projective joins, source partitions, and explicit limitations. This is not external or formal verification or a new end-to-end audit.
- Pro's earlier input was truncated. Its original recovery report remains intact. Here all 76 missing revision-12 files are restored from the intact saved package; every one of the 722 original manifest entries has a verified preserved location.
- Root verify.py retains Pro's focused replay interface. --with-sympy means revision12+13 only, not all 48 scripts. The recovered historical 39-script catalog is separately preserved at verification/CHECK_RUNS.json.
- Mathematical TeX and the two PDFs are unchanged from Pro. Current operational checklist/status and reconciliation records take precedence over historical administrative notes.

## Reproduce

```bash
python3 verify.py --integrity-only
python3 verify.py --revision13-only
python3 verify.py --revision12-only
pdflatex -interaction=nonstopmode -halt-on-error Q222_Analytical_Revision_2026-10-18.tex
pdflatex -interaction=nonstopmode -halt-on-error Q222_Analytical_Revision_2026-10-18.tex
```

Python 3 and SymPy required for replay. Default replay uses a temporary directory and never rewrites stored receipts. The original historical verifier and records are restored as provenance; the current root verifier remains the revision-13 focused verifier with additional restoration checks.
