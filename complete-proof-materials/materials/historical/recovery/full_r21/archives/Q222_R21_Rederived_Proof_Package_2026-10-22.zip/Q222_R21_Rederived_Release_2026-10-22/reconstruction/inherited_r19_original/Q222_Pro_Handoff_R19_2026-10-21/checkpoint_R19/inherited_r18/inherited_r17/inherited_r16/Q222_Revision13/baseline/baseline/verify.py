"""Verify the archive and reproduce current exact algebra without changing receipts."""
from pathlib import Path
import argparse,hashlib,json,shutil,subprocess,sys,tempfile
ROOT=Path(__file__).resolve().parent
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('--integrity-only',action='store_true')
p.add_argument('--with-sympy',action='store_true')
p.add_argument('--with-baseline',action='store_true',help='Also run the preceding revision verifier in a temporary copy')
a=p.parse_args()
m=json.loads((ROOT/'MANIFEST.json').read_text())
bad=[r['path'] for r in m['files'] if not (ROOT/r['path']).is_file() or hashlib.sha256((ROOT/r['path']).read_bytes()).hexdigest()!=r['sha256']]
if bad:raise SystemExit('Integrity failure: '+', '.join(bad))
b=json.loads((ROOT/'verification/EXACT_BASELINE.json').read_text())
for r in b['files']:
 f=ROOT/'baseline'/r['path']
 if not f.is_file() or hashlib.sha256(f.read_bytes()).hexdigest()!=r['sha256']:raise SystemExit('Baseline altered: '+r['path'])
print('PASS: '+str(len(m['files']))+' files; exact '+str(len(b['files']))+'-file prior baseline',flush=True)
if a.integrity_only:raise SystemExit(0)
if not a.with_sympy:
 print('Add --with-sympy to replay the current exact checks.');raise SystemExit(0)
try:import sympy
except ImportError:raise SystemExit('Install SymPy before running --with-sympy.')
checks=json.loads((ROOT/'verification/CHECK_RUNS.json').read_text())['checks']
with tempfile.TemporaryDirectory(prefix='q222_revision5_') as tmp:
 dst=Path(tmp)
 shutil.copytree(ROOT/'advances',dst/'advances')
 for c in checks:
  print('RUN: '+c['purpose'],flush=True)
  r=subprocess.run([sys.executable,str(dst/c['script'])]+c.get('args',[]),cwd=dst,text=True,capture_output=True)
  if r.returncode:
   print(r.stdout);print(r.stderr,file=sys.stderr);raise SystemExit('FAIL: '+c['script'])
  print('PASS: '+c['script']+' '+' '.join(c.get('args',[])),flush=True)
 if a.with_baseline:
  shutil.copytree(ROOT/'baseline',dst/'baseline')
  subprocess.run([sys.executable,str(dst/'baseline/verify.py'),'--with-sympy'],cwd=dst/'baseline',check=True)
print('PASS: all selected exact checks. Global source/test exhaustion remains open.')
