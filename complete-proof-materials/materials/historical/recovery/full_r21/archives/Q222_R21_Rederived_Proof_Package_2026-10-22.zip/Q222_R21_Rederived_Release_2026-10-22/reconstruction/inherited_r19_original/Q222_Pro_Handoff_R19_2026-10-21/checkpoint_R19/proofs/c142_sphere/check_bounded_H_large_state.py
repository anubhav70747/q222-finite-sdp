"""New HG algebra only; source/parent dependencies are retained, not replayed."""
import json
from pathlib import Path
import sympy as s
checks={}
def ck(name,e):
    assert s.cancel(e)==0,(name,s.factor(e))
    checks[name]=True
    print('PASS '+name,flush=True)

u,w,W,t,x,sg,q,lam,kappa,D,chi=s.symbols('u w W t x sigma q lambda kappa D chi')
Z=t*W; U=u*u; z=q*q
Gam=sg*Z-u*w*W; Pb=u*Z-x*w*W/sg
A=q*(U-x)*W; R=w*Z/q-u*q*W
rho=lam*x/sg; dd=4*D/sg**2
ck('HG1 whole singular first normal',lam*u*Gam*Pb-rho*Gam**2-lam*t*A*Gam/q)
H=s.symbols('H')
old=dd*Gam**2+4*kappa*H*A**2+lam*u*(Gam*Pb+A*R)+chi*u*A*R
new=(dd+rho)*Gam**2+4*kappa*H*A**2+lam*t*A*Gam/q+(lam+chi)*u*A*R
ck('HG2 complete angular Gamma radial packet',old-new)

h,b,p,P,J,Hcal,H0,B,b02=s.symbols('h b p P J Hcal H0 B b0_squared')
th=1-h
bt=(sg**2*Hcal/(2*P)-J*D)/x
lam_exact=(8*D*h+4*bt*th+2*h*h)/sg-4*b*p*sg*z
rho_alt=D*(8*h*x-4*th*J)/sg**2+2*x*h*h/sg**2+2*th*Hcal/P-4*b*p*x*z
ck('HG3 exact opening-uniform source pivot',lam_exact*x/sg-rho_alt)
hs=sg*H0/B+sg**2*Hcal*b02/(x*B)
ck('HG4 exact sphere source allocation',(x*h*h/sg**2-x*h*H0/(sg*B)-h*Hcal*b02/B).subs(h,hs))
d02,h0,H00=s.symbols('d0_squared h0 H00')
rho_res=(H00*d02/2)*(-4*(1-h0))+2*h0*H00*(1-d02)+2*(1-h0)*H00
ck('HG5 source residue through both sphere endpoints',rho_res-2*H00*(1-d02))

aa,ll,C,Ny,Rf=s.symbols('a ell C Ny R')
Q=1-b; pp=aa*b; l=ll*Q
Hy0=4*(aa+ll)+4*C*z+2*z
Kr0=4*(pp*b+l*Q)+2*z*(2*C+1)*b*b
cross0=8*(pp-l)+4*z*(2*C+1)*b
formal=Hy0*Ny*Ny+Kr0*Rf*Rf+cross0*Ny*Rf
M=(4*aa+2*z*(2*C+1))*(Ny+b*Rf)**2+4*ll*(Ny-Q*Rf)**2
ck('HG7 complete pure-source radial hard form',formal-M)

result={'status':'PASS','count':len(checks),'checks':checks,
 'scope':'C14.2 H=h/sigma bounded; u,w Inf; W nonzero and Z/W Inf; full-parent admission; accepted analytical review recorded in REVIEW_R19.txt',
 'remaining':'Other C14.2 source/state charts are not certified by this file',
 'dependencies':['Full exact SP6 parent','LC3 complete centered C extraction','BE2-BE9 actual source formulas/sphere','bounded separated-Gram criterion']}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
