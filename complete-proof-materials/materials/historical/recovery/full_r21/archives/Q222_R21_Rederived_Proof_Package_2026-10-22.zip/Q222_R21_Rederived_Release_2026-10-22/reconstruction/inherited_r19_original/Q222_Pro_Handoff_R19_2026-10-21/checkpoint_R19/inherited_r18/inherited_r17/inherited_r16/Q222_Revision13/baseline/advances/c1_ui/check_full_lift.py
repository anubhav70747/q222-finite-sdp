"""Full C1 UI exact reduction, normal parities and contact jets. SymPy only."""
import sympy as s,json,time
started=time.monotonic()
from pathlib import Path
u,v,g,k,f,r,t=s.symbols('u v g k f r t',nonzero=True)
Q,Y,Z,N,L,Rh,EQ,EY,W,X=s.symbols('Q Y Z N L Rh EQ EY W X')
C,A,D,al,d,h2,hb,aa,Js,cs,As,Ds=s.symbols('C A D al d h2 hb aa Js cs As Ds')
Du=1+u*u;Dv=1+v*v;x=k*k;eta=f*f;KK=1+x;RR=1+x*r;pp=t/RR;MM=RR-t;kap=k*f;eps=kap*g;ss=RR/(k*eta)
rt=u*Q-Du*Y;J=rt-Du*v*Z+u*g*v*N+u*pp*v*v*Q
ca=(C-cs)*aa;Ar=(A-As)*r;DJ=(D-Ds)*Js
cN=4/RR*(h2+hb*Dv);cL=4/RR*(h2*(1-pp)+hb*pp*Dv)
rest=4*cs*Dv*rt**2+8*ca*Dv*v*Z*rt-4*ca*aa*Dv*v*v*Z*Z+4*As*Du*Dv*Y*Y+8*Ar/eta*Du*Dv*v*Z*Y-4*Ar*r/eta**2*Du*Dv*v*v*Z*Z+4*Ds*J*J-8*DJ*v*Z*J-4*DJ*Js*v*v*Z*Z+4*al*Du*(g*v*Y-g*Z)**2+2*d*(J*J+Du*(v*v*Y*Y-2*v*Y*Z-v*v*Z*Z))
G=cN*N*N+8/RR*(hb*Dv-h2)*L*N+cL*L*L+rest
G0=cN*N*N+8*k*(hb*Dv-h2)*g*N*Z+cL*(2*k*RR*v*Q*Z-k*k*RR*RR*g*g*Z*Z)+rest
checks=[]
def chk(name,expr):
 assert s.cancel(expr)==0,name
 checks.append(name)
 print('PASS '+name+' ['+format(time.monotonic()-started,'.2f')+'s]',flush=True)
# Entire polynomial including all state normals, with generic event weights.
B=g*N+pp*v*Q;wm=Q-u*Y;xm=B-u*Z
M=v*wm-xm+u*v*Y-u*Z
original=4*h2/(g*g*MM)*M*M+4*C*Dv*rt*rt+4*A*Du*Dv*Y*Y+(4*D+2*d)*J*J+(4*al*g*g+2*d)*Du*(v*Y-Z)**2+4*hb/(g*g*t)*Dv*B*B-2*d*Du*Dv*Z*Z
pack=4*h2*t/(MM*RR)*N*N+4*hb*MM/(t*RR)*Dv*N*N+4*(C-cs)*Dv*(rt-aa*v*Z)**2+4*(A-As)*Du*Dv*(Y-r/eta*v*Z)**2+4*(D-Ds)*(J+Js*v*Z)**2
chk('exact full-parent CU5 including every state normal',original-pack-G.subs(L,v*Q/g))
Rhex=(v*Q-ss*eps*eps*Z)/eps
chk('exact relative-root elimination CU6/CU7',G.subs(L,v*Q/g)-(G0+cL*kap*kap*Rh*Rh+8*kap/RR*(hb*Dv-h2)*N*Rh).subs(Rh,Rhex))
# Never expand the full generic normal polynomial. Differentiate its
# short structured expression, evaluate the normal origin, and compare
# with independently printed compact formulas.
xi,cat,Art,DJt=s.symbols('xi cat Art DJt')
bb=r/eta
F=u*ss-Du*bb
JJ=F-Du+u*pp*xi*ss
HH=(8*Ds+4*d)*JJ-8*DJt
Dxi=1+xi
cLxi=4/RR*(h2*(1-pp)+hb*pp*Dxi)
LQ=2*cLxi*k*RR+8*Dxi*u*(cs*F+cat)+u*(1+pp*xi)*HH
LY=-8*Dxi*Du*(cs*F+cat)+8*Du*Dxi*(As*bb+Art/eta)-Du*HH+8*al*Du*g*g*(bb*xi-1)+4*d*Du*(bb*xi-1)
LN=8*k*(hb*Dxi-h2)+u*xi*HH
phi=cLxi*(2*k*RR*ss*xi-k*k*RR*RR*g*g)+4*cs*Dxi*F*F*xi+8*cat*Dxi*F*xi-4*cat*aa*Dxi*xi+4*As*Du*Dxi*bb*bb*xi+8*Art/eta*Du*Dxi*bb*xi-4*Art*r/eta**2*Du*Dxi*xi+4*Ds*JJ*JJ*xi-8*DJt*JJ*xi-4*DJt*Js*xi+4*al*Du*g*g*(bb*xi-1)**2+2*d*(JJ*JJ*xi+Du*(bb*bb*xi*xi-2*bb*xi-xi))
formal={cat:ca,Art:Ar,DJt:DJ,xi:v*v}
normal_origin={Q:ss*v*Z,Y:bb*v*Z,N:0}
for label,var,compact,scale in [('Q',Q,LQ,v*Z),('Y',Y,LY,v*Z),('N',N,LN,g*Z)]:
    chk('complete printed '+label+' first normal',s.diff(G0,var).subs(normal_origin,simultaneous=True)-scale*compact.subs(formal,simultaneous=True))
chk('complete printed scalar',G0.subs(normal_origin,simultaneous=True)-Z*Z*phi.subs(formal,simultaneous=True))

# Polynomials in independent xi=v² make the parity assertions explicit.
# Coefficient variables are generic; only the h_b-h_2 identity is used
# when the N normal is tested for its extra ideal.
for name,expr in [('scalar',phi),('Q normal',LQ),('Y normal',LY),('N normal',LN)]:
    s.Poly(expr,xi,g)
    checks.append(name+' exact even-v parity')
chk('scalar ideal (g²,xi)',phi.subs({g:0,xi:0}))
chk('N normal ideal (g²,xi)',LN.subs(hb,h2+2*x*eta*g*g).subs({g:0,xi:0}))

# Cancel the opening factors before substituting source coefficients:
# only C*a, A*r, D*J occur after caps have been set to zero. This removes
# all small-opening denominators from the exact contact-jet calculation.
a=(1-r)/eta
Jsource=KK-x*t*g*g-a
E=1-x*eta+t*x*eta*g*g
hh=1-t*g*g;yy=x*eta*g*g;Qc=1-x*g*g*r
TT=KK-x*t*g*g;GG=1+(1-t)*g*g
P4=TT*E+x*(1-r)*GG
Pa=RR*hh*(1+yy)+g*g*MM*E
Pd=1+2*x*hh+r*x*x*GG+x*g*g+eta*x*(KK*g*g+x*hh*t*g*g)
d0=4*eta*Pd/(KK*(r+eta)*E)
source={aa:a,Js:Jsource,cat:2,
        Art:2*eta*eta*P4/(KK*(r+eta)*E),
        DJt:2*(1+yy)/E-d0*Jsource/2,
        al:2*x*x*eta*Pa/(KK*Qc*E),d:d0,
        h2:2*x*eta*hh*(1+yy)/E,hb:2*x*eta*GG/E}
point={u:k,xi:eps*eps}
caps_zero={cs:0,As:0,Ds:0}
def source_jet(expr):
    # Keeping additive terms separate until their unit denominators have
    # canceled avoids an expanded generic coefficient/source cross product.
    at=expr.subs(caps_zero).subs(point,simultaneous=True)
    pieces=[s.cancel(term.subs(source,simultaneous=True)) for term in s.Add.make_args(at)]
    return sum(pieces)
for name,expr in [('scalar contact',phi),('u contact jet',s.diff(phi,u)),
                  ('xi contact jet',s.diff(phi,xi)),('Q normal contact',LQ),
                  ('Y normal contact',LY),('N normal contact',LN)]:
    chk(name,source_jet(expr))

# The cap dependence is exactly a centered square. Its value and complete
# first derivative vanish at contact. Check this generic identity before
# source substitution and all six contact jets on the short square itself.
centered=[('cs',cs,4*Dv*(rt-aa*v*Z)**2),
          ('As',As,4*Du*Dv*(Y-bb*v*Z)**2),
          ('Ds',Ds,4*(J+Js*v*Z)**2)]
contact={u:k,v:eps,Q:ss*eps*Z,Y:bb*eps*Z,N:0}
for name,cap,square in centered:
    chk('cap '+name+' exact centered-square dependence',s.diff(G0,cap)-square)
    for label,var in [('value',None),('u',u),('v',v),('Q',Q),('Y',Y),('N',N)]:
        ex=square if var is None else s.diff(square,var)
        chk('cap '+name+' preserves '+label+' contact jet',ex.subs(contact,simultaneous=True).subs({aa:a,Js:Jsource}))

# Exact local root relations: the only inverse is a pure-source inverse.
delv=u-k;Rs=(v*v-eps*eps)*Z/eps;Sex=v*delv*Z;Tex=eps*delv*Z;EQex=Q-ss*v*Z
chk('local relative relation',eps*Rs-(eps*Rhex-v*EQex)/ss)
chk('local product relation',Rs*Tex-(Rhex*Tex-Sex*EQex)/ss)
chk('local angular redistribution',Sex*Sex-Tex*Tex-delv*(Rhex*Tex-Sex*EQex)/ss)
report={'status':'PASS','count':len(checks),'checks':checks,
        'elapsed_seconds':round(time.monotonic()-started,3),
        'scope':'Exact full parent identity, complete compact scalar and first normals, contact jets, parity/ideals, all cap jets, and local root identities; analytical strictness and exhaustion are separate.',
        'method':'Structured differentiation and opening-cancelled termwise rational source substitution; no numerical sampling.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print('TOTAL',len(checks),'TIME',report['elapsed_seconds'],flush=True)
