# Scoped review: interior-shape weak-C IH testing corner

Reviewer: `c1_scale_review`, a separate agent in the same system. This is scoped author-independent review, not external peer review or formal verification.

## Outcome and exact scope

PASS. No blocking mathematical gap was found in the current `ih_interior_corner.tex` theorem, using `ih_source_frontier.tex` for source entry. The admitted statement is local in the independent testing pair: u and w = 1/v are infinitesimal or zero, with arbitrary state coordinates. The actual source is weak-C IH, with rho = B/y and 1-rho positive bounded units. The positive radial parameter r and both source openings H, 1-H may be arbitrarily infinitesimal, and n may be unbounded. Literal n = 0, literal testing endpoints, and complex states are included.

This review does not admit the source subdomain at all independent tests. It does not cover source rho infinitesimal or 1-rho infinitesimal, and it does not remove any whole IH leaf from the global frontier.

## Fresh exact replay

Both relevant updated checkers passed:

- `check_ih_toric_gram.py`: 13 recorded exact checks, including the four complete scalar remainder coefficients, both toric conductor identities, the current uniform-r determinant, both full first-normal factorizations, their exact source contact vanishings, and the bounded Y-normal conductor.
- `check_ih_source.py`: 25 recorded exact checks, including all six original source formulas, the positive source numerator identity, and the stated physical witness family's leading coefficients and source gaps.

These checks corroborate the printed identities. Boundedness, strictness, the independent-field interpretation, and the exact scope were reviewed from the formulas rather than inferred from PASS labels.

## Original source and uniform bounds

The H,L,B,R variables and all six WI1 coefficients agree with the unchanged original rational C2 source. The positive numerator identity is exact. In the bounded-B alternative, the estimate z <= 4(B+R) bounds the required denominator ratio, while Nhat/[y(B+R)] has residue one; this proves that weak C forces B unbounded. For unbounded B, WI2 gives C weak and the uniform WI3 relations. No lower bound on r, H, or 1-H enters that derivation.

With rho and 1-rho units, e = 1-rho+R+H/y is a unit, so D is bounded with the residue in IC2. From n >= 0 and N = 4n+2 one obtains nu = Nr with positive unit residue 2rho/(1+rho). Hence 1-r is a unit and 0 <= r_0 <= rho_0/(1+rho_0), including r_0 = 0 when n is unbounded. The products

    BC, Bm/z^2, AH/B, alpha(1-H)/B, nr, D

are bounded, with the required positive unit residues where asserted. Every term in K/B and k/B is therefore bounded. Direct residue collection gives (k/B)_0 = 2r_0/(1+rho_0), uniformly in the two H openings and the radial parameter.

## Exact scalar certificate and the new radial pivot

IC3 is precisely the original homogeneous parent w^2 F(u,1/w), including all original events and the full signed core. Its polynomial expression also defines the literal projective endpoint. Restriction to the stated X,Y graph gives IC7 exactly; it is not merely a leading model. The checker's remaining four monomials vanish under the complete original source formulas.

The two toric identities can also be checked directly from the roots. In particular,

    zR0-uR1 = sqrt(B) w (u^2-z) Z,
    uR0-R1 = (u^2-z) W/sqrt(B).

These give IC8a exactly. Its added rho T^2 coefficient has positive unit residue. Its other Gram coefficients contain u or z and are infinitesimal; expanding the product introduces no hidden source inverse. This repairs the loss of the old radial pivot when r is infinitesimal and n is unbounded.

The only nonzero off-diagonal scalar residue is the printed (R2,T) block. Its determinant simplifies to the stated positive expression. The first summand 2rho/(1-rho^2) is already a positive unit, so no strictness is lost at r_0 = 0. At literal n = 0 the source relation gives the other allowed endpoint r_0 = rho/(1+rho); the same determinant remains strict. The R0, R1, and E residue pivots are positive as printed. Thus the full five-root scalar Gram is bounded and strictly positive in residue.

## Complete normals, with no small-opening inverse in the Gram

The X and Y rows were differentiated from the full homogeneous parent before restricting to the graph. The factor 4 in the definitions of L_X,L_Y is retained when restoring the linear normal terms.

For the X row, every coefficient of P_X is bounded: in particular nr is bounded and mB/z is of order z. Monic division at U=z,V=1/y preserves bounded coefficients. The exact identity

    B(V-1/y)Z = R2-sqrt(B) wR0

gives IC11 without division by sqrt(H). The multiplier m sqrt(B)/z is of order z/sqrt(B), hence infinitesimal. Every other displayed multiplier has an explicit infinitesimal u or w and a bounded remaining factor. Dividing the entire row by sqrt(N) is harmless because N >= 2. Neither 1/r nor a negative power of an H opening is inserted into the bounded Gram.

For the Y row, P_Y/B has bounded coefficients because AH/B and alpha(1-H)/B are bounded. Monic division consequently gives bounded f_Y/B and g_Y/B. In IC12, f(V) is infinitesimal since m and C are infinitesimal and V=w^2 is infinitesimal. The remaining multipliers contain z, u, or w. The factors sqrt(H(1-H)) and sqrt(1-H) are bounded. Hence all full Y-normal couplings have zero residue even when H or 1-H is arbitrarily small.

The normal roots themselves may be large. Their radicals and inverses are pure coefficient quantities, so they are legitimate separated tensor roots and do not require a mixed inverse or mixed radical.

## Complete hard block and endpoints

The complete quadratic normal block is exactly the one printed at the end of the theorem. Its scaled X diagonal has residue one, since (4n+2)/N = 1 and the other terms vanish after scaling. The Y diagonal has residue

    4(AH/B)(1-H) + 4(alpha(1-H)/B)H = 2/(1+rho).

This uses H+(1-H)=1 and is uniform at either infinitesimal opening. The scaled cross coefficient is infinitesimal. There are no state-normal terms above degree two, so no further hard terms remain unaccounted for. Joining this block to IC11–IC12 gives the claimed strict seven-root Gram for the entire parent.

The identities are polynomial in the testing u,w and homogeneous in the state. Consequently they include literal u = 0 and w = 0 and impose no state normalization or bounded-root condition. Testing signs do not affect boundedness or residue strictness. The parent is real, so splitting a complex state into real and imaginary parts supplies the stated complex case.

## Remaining boundary

The manuscript correctly keeps the remote all-tests join open. In particular, the separate infinity-infinity joining pivot proportional to n has not been made uniform as n tends to zero. This local theorem must retain its independent-test restriction in every checklist and dependency graph.
