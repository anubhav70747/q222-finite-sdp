from pathlib import Path
import sympy as s,json
u,w,W,Z,z,y,B,H,r,n,m,C,A,D,al=s.symbols('u w W Z z y B H r n m C A D al')
ss=1/y;be=B/y;N=4*n+2
X=-r*u*Z;Y=H*w*Z;Du=1+u*u;Dw=1+w*w
M=W-w*X+u*Y-u*w*Z;J=u*w*W+u*X-w*Y-Z
G=4*n*Du*Dw*X*X+4*m*M*M+4*C*Dw*(u*W-Y)**2+4*A*Du*Dw*Y*Y+4*D*J*J+4*al*Du*(Y-w*Z)**2
G+=2*(J*J+Du*(Y-w*Z)**2+Dw*(X+u*Z)**2-Du*Dw*Z*Z)
P=u*W-B*w*Z;Q=z*W-B*u*w*Z;V=u*w*W-be*Z;T=(u*u-z)*Z;E=(w*w-ss)*Z
K=4*A*H**2+8*D*H*r+4*al*(1-H)**2+4*m*(H+r-1)**2+2*(H+r-1)**2+4*n*r*r
k=K-4*B*B*m/z**2+8*z*n*r*r+8*ss*A*H*H
candidate=4*C*P*P+4*m/z**2*Q*Q+2*(2*C+2*D+1)*V*V
candidate+=-4*r*(2*D+1)*V*T-4*H*(2*C+2*D+1)*V*E
candidate+=(4*n*r*r*w*w+2*r*r*(2*D+2*n+1))*T*T
candidate+=(4*A*H*H*u*u+2*H*H*(2*A+2*C+2*D+1))*E*E+k*T*E
rem=s.Poly(s.expand(G-candidate),W,Z,u,w)
ns={};exec(Path(__file__).with_name('check_ih_source.py').read_text().split("e=s.symbols('e',positive=True)")[0],ns)
subvar={ns['z']:z,ns['y']:y,ns['H']:H,ns['L']:B-H,ns['R']:z*r}
subcoef={symbol:ns['weights'][name].subs(subvar,simultaneous=True) for symbol,name in [(n,'n'),(m,'m'),(C,'C'),(A,'A'),(D,'D'),(al,'alpha')]}
checks=[]
for mon,coef in rem.terms():
 value=s.factor(coef.subs(subcoef,simultaneous=True));assert value==0,(mon,value)
 checks.append('exact source toric Gram remainder '+str(mon))
assert s.factor(B*T*E-(T*V-z*P*P/B+u*P*Q/B))==0
checks.append('exact toric mixed-radial conductor')
radial_zero=be*T*T+(u*u-z)*T*V-u*(z*P-u*Q)*(u*P-Q)/B
assert s.factor(radial_zero)==0
checks.append('exact positive radial conductor for unit beta')

# Interior residue identities use β,r,H and N=2β/[r(1+β)].
beta,NN=s.symbols('beta NN',positive=True)
a=2/(1-beta**2);b=1+2*beta**2/((1-beta**2)*NN);c=-1/((1-beta)*s.sqrt(NN))
det=s.factor(a*b-c*c)
expected=(2*(1+beta)*NN-(3*beta+1))/((1-beta)*(1+beta)**2*NN)
assert s.factor(det-expected)==0
checks.append('strict interior R2-T block determinant')
rr=s.symbols('rr')
nu=2*beta/(1+beta);DD=beta**2/(2*(1-beta**2))
newdet=2/(1-beta**2)*(beta+rr*nu+4*DD*rr**2)-rr**2/(1-beta)**2
newexpected=2*beta/(1-beta**2)+rr*(4*beta-rr*(3*beta+1))/((1-beta)*(1+beta)**2)
assert s.factor(newdet-newexpected)==0
checks.append('uniform-r residue block determinant after radial conductor')
XX,YY=s.symbols('XX YY')
MM=W-w*XX+u*YY-u*w*Z;JJ=u*w*W+u*XX-w*YY-Z
FF=4*n*Du*Dw*XX**2+4*m*MM**2+4*C*Dw*(u*W-YY)**2+4*A*Du*Dw*YY**2+4*D*JJ**2+4*al*Du*(YY-w*Z)**2
FF+=2*(JJ**2+Du*(YY-w*Z)**2+Dw*(XX+u*Z)**2-Du*Dw*Z**2)
LX=s.diff(FF,XX).subs({XX:X,YY:Y})/4
LY=s.diff(FF,YY).subs({XX:X,YY:Y})/4
UU,VV=s.symbols('UU VV')
PX=(2*D+1)*be-2*m*B/z*VV-2*n*r*(1+UU)*(1+VV)-r*(2*D+1)*UU-2*D-r
PX+=VV*(1-H-r-2*D*H-2*m*(H+r-1))
ff=2*m-2*C*(1+VV)-(2*D+1)*VV
PY=B*ff+2*A*H*(1+UU)*(1+VV)+2*C*H*(1+VV)+2*D*H*VV+2*D*r*UU+2*D
PY+=-2*al*(1-H)*(1+UU)+2*m*(H+r-1)*UU+(H+r-1)*UU+H*(VV+1)
fx=-2*n*r*(1+VV)-r*(2*D+1)
gx=-2*m*B/z-2*n*r*(1+z)+1-H-r-2*D*H-2*m*(H+r-1)
fy=2*A*H*(1+VV)+2*D*r-2*al*(1-H)+(2*m+1)*(H+r-1)
gy=-B*(2*C+2*D+1)+2*A*H*(1+z)+2*C*H+2*D*H+H
for label,pol,fu,gv in [('X bounded monic quotient',PX,fx,gx),('Y bounded monic quotient',PY,fy,gy)]:
 assert s.factor(pol-(UU-z)*fu-(VV-ss)*gv-pol.subs({UU:z,VV:ss}))==0,label
 checks.append(label)
xxform=(2*D+1)*u*V-2*m/z*w*Q+u*Z*PX.subs({UU:u*u,VV:w*w})
yyform=ff.subs(VV,w*w)*P+w*Z*PY.subs({UU:u*u,VV:w*w})
for label,left,right in [('full X normal factorization',LX,xxform),('full Y normal factorization',LY,yyform)]:
 assert s.factor(left-right)==0,label
 checks.append(label)
for label,pol in [('X normal exact contact',PX),('Y normal exact contact',PY)]:
 value=s.factor(pol.subs({UU:z,VV:ss}).subs(subcoef,simultaneous=True));assert value==0,label
 checks.append(label)
assert s.factor((u*u-z)*B*w*Z-(z*P-u*Q))==0
checks.append('Y normal bounded conductor')
result={'status':'PASS','count':len(checks),'checks':checks,'scope':'Exact full-parent interior IH corner Gram, including both normal factorizations. It is local in the independent testing pair; no all-tests admission or unrestricted IH closure is claimed.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
