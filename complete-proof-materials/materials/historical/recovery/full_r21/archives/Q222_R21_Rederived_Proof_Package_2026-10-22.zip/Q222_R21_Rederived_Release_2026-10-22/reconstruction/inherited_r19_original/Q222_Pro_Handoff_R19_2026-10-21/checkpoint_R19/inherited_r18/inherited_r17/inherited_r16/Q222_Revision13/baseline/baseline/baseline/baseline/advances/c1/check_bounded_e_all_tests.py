"""Small exact checks for bounded_e_all_tests.tex; no sampling or searches."""
from pathlib import Path
import json
import sys
import sympy as s

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
checks = []

def eq(name, lhs, rhs):
    assert s.expand(lhs-rhs) == 0, name
    checks.append(name)

u,v,p,q,W,X,Y,Z,d,c,m,A,D,al,be = s.symbols(
    'u v p q W X Y Z d c m A D alpha beta')
Du,Dv=1+u*u,1+v*v
core=2*((u*W+u*v*X-Y-v*Z)**2+Du*(v*Y-Z)**2
        +Dv*(X+u*Z)**2-Du*Dv*Z**2)
parent=(4*m*(v*W-X+u*v*Y-u*Z)**2
        +4*c*Dv*(u*W-Y)**2+4*A*Du*Dv*Y**2
        +4*D*(u*W+u*v*X-Y-v*Z)**2
        +4*al*Du*(v*Y-Z)**2+4*be*Dv*(X+u*Z)**2+d*core)
hom=s.cancel(p*p*q*q*parent.subs({u:1/p,v:1/q}))
printed=(4*m*(p*W-p*q*X+Y-q*Z)**2
 +4*c*(1+q*q)*(W-p*Y)**2+4*A*(1+p*p)*(1+q*q)*Y**2
 +(4*D+2*d)*(q*W+X-p*q*Y-p*Z)**2
 +(4*al+2*d)*(1+p*p)*(Y-q*Z)**2
 +(4*be+2*d)*(1+q*q)*(p*X+Z)**2
 -2*d*(1+p*p)*(1+q*q)*Z**2)
eq('exact whole infinity-infinity parent',hom,printed)
eps=s.symbols('eps')
quad=s.expand(hom.subs({al:0,be:0,Z:1}).subs(
    {p:eps*p,q:eps*q,W:eps*W,X:eps*X,Y:eps*Y},simultaneous=True)).coeff(eps,2)
correct=4*c*W**2+2*d*X**2+4*D*(X-p)**2+4*A*Y**2+(4*m+2*d)*(Y-q)**2
eq('correct complete quadratic, including missing 2d q squared',quad,correct)
G=s.hessian(correct,(Y,q))/2
eq('Y-q determinant',s.det(G),4*A*(4*m+2*d))

# Full selected parent, including every cross coefficient, on four roots.
selected=s.expand(hom.subs({m:0,D:0,al:0,be:0}))
for mon,coef in s.Poly(selected,W,X,Y,Z,p,q).terms():
    iw,ix,iy,iz,ip,iq=mon
    assert iw+ix+iy+iz == 2 and iq >= iz
checks.append('infinity-infinity complete four-root ideal membership')
T=s.symbols('T')
selected_frame=s.expand(selected.subs(Z,T/q))
assert not s.denom(s.cancel(selected_frame)).has(q)
eq('infinity-infinity four-root full Gram residue',selected_frame.subs({p:0,q:0}),
   4*c*W**2+2*d*X**2+4*A*Y**2+2*d*(Y-T)**2)

# Infinity-zero: eliminate Z by the exact hard root, then collect vX.
R,V=s.symbols('R V')
inf0=s.cancel(p*p*parent.subs({u:1/p,m:0,D:0,al:0,be:0}))
inf0=s.expand(inf0.subs(Z,R-p*X))
for mon,coef in s.Poly(inf0,W,X,Y,R,p,v).terms():
    iw,ix,iy,ir,ip,iv=mon
    assert iv >= ix
checks.append('infinity-zero complete four-root ideal membership')
inf0frame=s.expand(inf0.subs(X,V/v))
assert not s.denom(s.cancel(inf0frame)).has(v)
eq('infinity-zero full Gram residue',inf0frame.subs({p:0,v:0}),
   2*d*R**2+2*d*(W+V)**2+4*c*W**2+4*A*Y**2)

# The zero-Z, unit-W endpoint keeps all source/event normals.
endpoint=s.expand(parent.subs({W:1,c:0,D:0,al:0,be:0}))
for mon,coef in s.Poly(endpoint,u,v,X,Y,Z).terms():
    assert sum(mon[:4]) >= 2
checks.append('unit-W zero-Z full normal ideal membership')
endpointquad=s.expand(endpoint.subs(Z,0).subs(
    {u:eps*u,v:eps*v,X:eps*X,Y:eps*Y},simultaneous=True)).coeff(eps,2)
eq('unit-W zero-Z exact leading form',endpointquad,
   2*d*(X*X+(u-Y)**2)+4*m*(v-X)**2+4*A*Y**2)

# Residues of the five factored scalar terms and complete first normals.
a,E,U,A0,B0,C0,D0,MB,N=s.symbols('a E U A0 B0 C0 D0 MB N')
r=1-a*E;H=r+E;DU=1+U*U
raw=(8*r*H*DU**2*A0**2+8*r*H*DU**2*B0**2
     +8*DU*(C0-a*E*B0)**2+8*r*H*DU*D0**2
     +8*r*DU*(E*(2*a-1)*B0**2-2*B0*C0))
target=(8*r*H*DU**2*A0**2
        +8*DU*((B0-C0)**2+U**2*r*H*B0**2)+8*r*H*DU*D0**2)
eq('five-term raw residue collection',raw,target)
dd,tt,vv,ww=s.symbols('delta t vv ww')
DV=1+vv*vv
Vn=1-tt*U*vv*ww;Yn=U*ww-a*vv*Vn;Bn=vv*Yn-1
C2=Cb=C3=C5=2*r*H;C4=2;Cd=4*r
Ac=C5+a*(C3*DV-C5)
SBfull=-8*a*E*E*C4*DV*Vn+4*E*Cd*Bn
SCfull=8*E*C4*DV
L1coeff=(8*(Cb*DV-C2)*DU,
         -8*dd*U*DU*vv*Vn*Ac+dd*a*U*vv*SBfull,
         dd*a*U*vv*SCfull)
for j,co in enumerate(L1coeff):
    eq('full first-normal raw coefficient '+str(j),co.subs(vv,0),0)
L2raw=B0*(8*DU*Vn*(C3*DV-C5)-SBfull)-C0*SCfull
eq('full second-normal residue',L2raw.subs(vv,0),16*E*(B0-C0))
H2=Hb=H3=H5=8*r*H
CB=H3*DV*a+H5*(1-a)
BY=8*dd*dd*E*E*DU*DV+8*dd*dd*E*r*DU*vv*vv
hard11=H2+Hb*DV+dd*dd*CB*U*U*vv*vv+BY*a*a*U*U*vv*vv/DU**2
hard12=-dd*(H3*DV-H5)*U*vv-BY*a*U*vv/(dd*DU**2)
hard22=H3*DV+H5+BY/(dd*dd*DU**2)
eq('complete hard normal first diagonal residue',hard11.subs(vv,0),16*r*H)
eq('complete hard normal cross residue',hard12.subs(vv,0),0)
eq('complete hard normal second diagonal residue',hard22.subs(vv,0),16*r*H+8*E*E/DU)
coupled=s.Matrix([[16*r*H+8*E*E/DU,8*E],[8*E,8*DU]])
eq('ordinary-u coupled determinant',s.det(coupled),128*DU*r*H)
ell,x=s.symbols('ell x')
unitw=s.expand((target+16*r*H*N*N+(16*r*H+8*E*E/DU)*MB*MB
               +16*E*MB*(B0-C0)).subs({U:0,B0:ell*A0,C0:ell*A0-x}))
eq('unit-w raw frame exact residue',unitw,
   8*r*H*A0*A0+8*x*x+8*r*H*D0*D0+16*r*H*N*N
   +(16*r*H+8*E*E)*MB*MB+16*E*MB*x)

# Compact coefficient collection from the unchanged native reconstruction.
native=HERE if (HERE/'source_from_formulas.py').is_file() else (
 HERE)
sys.path.insert(0,str(native))
from source_from_formulas import Poly,variables,reconstruct_source
delta,k,b,aa,tt,uu,ww,vv=variables(8)
source=reconstruct_source()
weights=(0,1,0,0,0,1,1,2)
def trunc(terms,cap):
    return Poly({mon:coef for mon,coef in terms.items()
                 if sum(i*j for i,j in zip(mon,weights))<=cap},8)
def peq(name,lhs,rhs):
    assert not (lhs-rhs).terms,name
    checks.append(name)
pa=ww*vv;pb=delta*vv;pc=delta*b*b*uu*ww;pd=delta*delta*k**3*b*b
px=pb-pc;py=pa-k*pc;pz=uu*pb-k*pc;ph=k*pc-pd
q1square=pa*(delta*uu*vv)+(k*pc)*pd-2*(k*pc)*(k*pb)
T4=py*py+pz*pz+ph*ph-2*py*pz+2*q1square
rho=(1-aa*b*b)*(1+(1-aa)*b*b)-1
E0=Poly(source['scalar_terms'],8)-Poly(source['leading_terms'],8)
peq('native bounded-delta scalar regrading',trunc(E0.terms,6),
    8*rho*T4-8*(rho+b*b)*k*k*px*px)
peq('native complete first normal regrading',trunc(source['linears_terms'][0],3),0*delta)
peq('native complete second normal regrading',trunc(source['linears_terms'][1],3),16*b*b*px)

out={'status':'PASS','checks':checks,
     'scope':'Exact local identities and full normals for bounded_e_all_tests.tex; no numerical or rate search.'}
(HERE/'bounded_e_all_tests_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
