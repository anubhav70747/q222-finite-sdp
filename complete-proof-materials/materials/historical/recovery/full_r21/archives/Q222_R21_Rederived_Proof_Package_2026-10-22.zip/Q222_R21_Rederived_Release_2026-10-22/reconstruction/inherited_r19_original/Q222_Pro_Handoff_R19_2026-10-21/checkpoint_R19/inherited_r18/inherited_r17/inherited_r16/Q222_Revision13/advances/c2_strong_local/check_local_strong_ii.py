#!/usr/bin/env python3
"""Narrow exact checks for the strong-II local Gram construction.

This checks the algebraic identities and the only nontrivial finite block.
The accompanying proof supplies the bounded coefficient extraction, exact
stationarity inherited from the already checked source, and positivity.
"""
from pathlib import Path
import json
import sympy as s

checks = {}
def ck(name, value):
    value = s.cancel(s.together(value))
    checks[name] = value == 0
    if value != 0:
        raise AssertionError((name, s.factor(value)))

u,v,W,xi,ze,N,Rh,R,T1 = s.symbols('u v W xi ze N Rh R T1')
U,V,z,k,B,t,r = s.symbols('U V z k B t r')
c,d,g,q,mu,a,nu,sigma,ec,alc = s.symbols('c d g q mu a nu sigma ell_cap alpha_cap')
y=k*k; H=B-y*t; ac=1+z*r; j=ac-t; sc=ac/B
K=u*k*W; Qn=u*xi-ze
rh_actual=v*Qn/k-sc*u*(v*v-y)*W/k
r_actual=v*(u*u-z)*W
t1_actual=u*k*(u*u-z)*W
toric=T1*T1-u*u*R*R-(u*u-z)/sc*Rh*T1+u*(u*u-z)/sc*R*Qn
ck('toric_conductor',toric.subs({Rh:rh_actual,R:r_actual,T1:t1_actual}))
ck('gauge_identity',rh_actual*K-u*v*W*Qn+sc*u*u*(v*v-y)*W*W)
ck('angular_cross',u*u*(u*u-z)*(v*v-y)*W*W+(rh_actual*t1_actual-u*r_actual*Qn)/sc)
ck('xi_V_allocation',z*v*(v*v-y)*W-(u*v*v*Qn-u*v*k*rh_actual)/sc+(v*v-y)*r_actual)
ck('zeta_V_allocation',u*v*(v*v-y)*W-(v*v*Qn-v*k*rh_actual)/sc)
ck('N_V_allocation',u*k*(v*v-y)*W-(v*k*Qn-y*rh_actual)/sc)

ell=c/t+d/j
qq=d*t/(c*j+d*t)
gg=c*d/(c*j+d*t)
Qc=t/B*K-N-qq*Rh
Jc=(1-qq)*Rh-N-j/B*K
pair=4*ell*N*N+4*gg*Rh*Rh+8*(d-c)/B*K*N-8*gg*sc*K*Rh+4*(c*t+d*j)/B**2*K*K
ck('weighted_C_D_pair',4*c/t*Qc*Qc+4*d/j*Jc*Jc-pair)
ck('extra_C_packet',4*c/t*v*v*Qc*Qc-4*c/t*v*v*(N+qq*Rh)**2-4*c*t/B**2*v*v*K*K+8*c/B*v*v*K*(N+qq*Rh))

# Exact bounded remainder, with q and g kept abstract bounded parameters.
# The source dictionary is m=z^2 mu, A=y a, nr=nu,
# alpha(1-H)=sigma, CL=c, Dyj=d.
eta=k*(N+q*Rh)
X=-z*r*v/B*W+xi
Y=H*u/B*W+eta
Z=u*v/B*W+ze
du=1+u*u; dv=1+v*v
M=v*W-X+u*v*Y-u*Z
J=u*W+u*v*X-Y-v*Z
p=v*Y-Z; bb=X+u*Z
core=2*(J*J+du*p*p+dv*bb*bb-du*dv*Z*Z)
G=(4*ec*N*N+4*g*Rh*Rh+8*(d-c)/B*K*N-8*g*sc*K*Rh
   +4*(c*t+d*j)/B**2*K*K+4*c*t/B**2*v*v*K*K
   -8*c/B*v*v*K*(N+q*Rh)
   +4*nu*du*dv*(z*z*r*v*v/B**2*W*W-2*z*v/B*W*xi)
   +4*alc*du*(v*eta-ze)**2
   +4*sigma*du*((1-H)*u*u*v*v/B**2*W*W-2*u*v/B*W*(v*eta-ze))
   +4*z*z*mu*M*M+4*y*a*du*dv*Y*Y+core)
G=s.expand(G)
rho=s.cancel(G.coeff(Rh,1).coeff(W,1)/(u*k))
assert rho.is_polynomial(u,v)
checks['Rh_W_factor_is_u_k'] = True
Gg=s.expand(G-u*k*rho*Rh*W+rho*(u*v*W*Qn-sc*u*u*(v*v-y)*W*W))
ck('no_Rh_W_after_gauge',Gg.coeff(Rh,1).coeff(W,1))
ck('gauge_preserves_actual_polynomial',(Gg-G).subs(Rh,rh_actual))

def even(expr,pu=0,pv=0,pk=0):
    expr=s.cancel(expr/(u**pu*v**pv*k**pk))
    poly=s.Poly(expr,u,v)
    ans=0
    for (iu,iv),coef in poly.terms():
        if iu % 2 or iv % 2:
            raise AssertionError(('parity',iu,iv))
        ans += coef*U**(iu//2)*V**(iv//2)
    return s.expand(ans)

Pxi=even(Gg.coeff(xi,1).coeff(W,1),pv=1)
Pze=even(Gg.coeff(ze,1).coeff(W,1),pu=1,pv=1)
PN=even(Gg.coeff(N,1).coeff(W,1),pu=1,pk=1)
phi=even(Gg.coeff(W,2))
ck('xi_support_in_U_z',Pxi.subs({U:0,z:0}))
checks['scalar_degree_U_at_most_two']=bool(s.degree(phi,U)<=2)
assert checks['scalar_degree_U_at_most_two']
dd=4/B**2*(z*z*mu*(B+z*r)**2+z*z*(nu*r+r*r/2))
ee=4/B**2*z*z*(nu*r+r*r/2)
ck('scalar_at_U_zero',phi.subs(U,0)-V*(dd+ee*V))

# Every normal quadratic has the asserted strict diagonal residue.
normal=Gg.subs(W,0).subs({u:0,v:0,z:0,k:0})
ck('hard_residue',normal-4*ec*N*N-2*xi*xi-4*alc*ze*ze-4*g*Rh*Rh)

h,rr=s.symbols('h rr')
res={B:h,r:rr,c:h/(2*(1+h)),d:h/(2*(1+h)),g:h/(2*(1+h)),q:t,
     mu:(1-rr)/(2*h*h*(1+h)),a:1/(2*h*(1+h)),
     nu:1/(2*(1+h))-rr/2,sigma:h*h/(2*(1+h))}
cross=s.diff(Pxi,U).subs({U:0,V:0,z:0,k:0}).subs(res)
ck('xi_R_cross_residue',cross-4/(h*(1+h)))
Rdiag=s.cancel(dd/z**2).subs({z:0,k:0}).subs(res)
ck('R_diagonal_residue',Rdiag-2/(h*h*(1+h)))
ck('xi_R_schur',Rdiag-(cross/2)**2/2-2/(h*(1+h)**2))

# General bounded scalar extraction lemma, independent of source formula.
aa,bb,cc,dd0,ee0=s.symbols('aa bb cc dd0 ee0')
A1=aa+bb*V; C1=cc+dd0*V
base=V*(dd0+ee0*V)/z**2*(U-z)**2
constructed=base+U*(U-z)*(V-y)*A1+U*(V-y)**2*C1
ck('scalar_lifting_contact_value',constructed.subs({U:z,V:y}))
ck('scalar_lifting_contact_U',s.diff(constructed,U).subs({U:z,V:y}))
ck('scalar_lifting_contact_V',s.diff(constructed,V).subs({U:z,V:y}))
ck('scalar_lifting_at_U_zero',constructed.subs(U,0)-V*(dd0+ee0*V))

result={'status':'all_exact_checks_passed','checks':checks,'count':len(checks),
 'scope':'Strong-II local full-parent construction for infinitesimal independent tests, including axes. Remote charts and original projective endpoints are separate.',
 'source_checks':'No new broad source substitution. Uses the six original exact stationarity checks in R6; checks here concern the new pair, gauge, conductor, support, and finite residue block.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
Path(__file__).with_name('extracted_coefficients.txt').write_text('\n\n'.join([
 'rho = '+str(s.factor(rho)), 'P_xi = '+str(s.factor(Pxi)),
 'P_zeta = '+str(s.factor(Pze)), 'P_N = '+str(s.factor(PN)),
 'phi = '+str(s.collect(phi,U))])+'\n')
print(json.dumps({'status':result['status'],'count':len(checks)}))
