"""Exact local identities only. No all-tests admission is asserted."""
import json
from pathlib import Path
import sympy as s

checks = {}
def check(name, expr):
    value = s.factor(s.together(expr))
    checks[name] = value == 0
    if value != 0:
        raise AssertionError((name, value))
    print('PASS', name, flush=True)

u,v,W,X,Y,Z,xi,nu=s.symbols('u v W X Y Z xi nu')
m,C,A,D,al,be,r,h=s.symbols('m C A D alpha beta r h')
U,V=u*u,v*v
Du,Dv=1+U,1+V
Jt=u*W+u*v*X-Y-v*Z
Mt=v*W-X+u*v*Y-u*Z
Kt=Jt**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2
F4=m*Mt**2+C*Dv*(u*W-Y)**2+A*Du*Dv*Y**2+D*Jt**2+al*Du*(v*Y-Z)**2+be*Dv*(X+u*Z)**2+Kt/2

Aw=m*V*(1+r*U)**2+C*Dv*(1-r)**2*U+A*Du*Dv*r*r*U+(D+s.Rational(1,2))*(1-r)**2*U+(al+s.Rational(1,2))*Du*r*r*U*V
Az=al+D*V+U*((m+s.Rational(1,2))*(1-h)**2+al+V*(h*h/s.Integer(2)+2*D*h))+U*U*V*(D+s.Rational(1,2))*h*h+be*(1-h)**2*U*Dv
b0=m*(1-h)+D*(1-r)+al*r+s.Rational(1,2)
b1=m*r*(1-h)+h*(D+s.Rational(1,2))*(1-r)+(al+s.Rational(1,2))*r
Fg=Aw*W*W+Az*Z*Z-2*u*v*(b0+b1*U)*W*Z
fw=-m*(1+r*U)+(D+s.Rational(1,2))*(1-r)*U
fz=m*(1-h)-(D+s.Rational(1,2))*V*(1+h*U)+(be+s.Rational(1,2))*Dv*(1-h)
kw=m*V*(1+r*U)-C*Dv*(1-r)+A*Du*Dv*r-(D+s.Rational(1,2))*(1-r)+(al+s.Rational(1,2))*Du*r*V
kz=-m*(1-h)*U+(D+s.Rational(1,2))*(1+h*U)-(al+s.Rational(1,2))*Du
Hxx=m+be*Dv+(D+s.Rational(1,2))*U*V+Dv/2
Hyy=m*U*V+C*Dv+A*Du*Dv+D+s.Rational(1,2)+(al+s.Rational(1,2))*Du*V
Hxy=-(m+D+s.Rational(1,2))*u*v
full=Fg+2*xi*(v*W*fw+u*Z*fz)+2*nu*(u*W*kw+v*Z*kz)+Hxx*xi*xi+2*Hxy*xi*nu+Hyy*nu*nu
check('full_original_parent_all_normals', F4.subs({X:-h*u*Z+xi,Y:r*u*W+nu})-full)

# Whole source, with no opening inverted except its original positive factor.
x,eta,zeta=s.symbols('x eta zeta')
theta=1-h; K=1+x; R=1+x*r; T=1+x*h
M=R-theta/zeta; j=eta*T-1+r; J=j/eta
E=1-x*eta*h; Q=1-x*zeta*r; y=x*eta*zeta
P4=T*E+x*(1-r)*(h+zeta)
Pa=R*h*(1+y)+zeta*M*E
Pd=1+2*x*h+r*x*x*(h+zeta)+x*zeta+eta*x*(K*zeta+x*h*theta)
B5=K*(1+y)*(r+eta)-j*Pd
Bbeta=K*x*(r+eta)*(h+zeta)-theta*Pd
src={C:K*(r+eta)*E/(2*(1-r)*Pd),A:eta*P4/(2*r*Pd),m:K*x*(r+eta)*h*(1+y)/(2*M*zeta*Pd),al:x*x*zeta*(r+eta)*Pa/(2*Q*Pd),D:B5/(2*j*Pd),be:Bbeta/(2*theta*Pd)}
def at_angles(expr):
    return s.expand(expr).subs({u**2:x,v**2:y})
check('complete_first_X_contact', (zeta*at_angles(fw)+at_angles(fz)).subs(src))
check('complete_first_Y_contact', (at_angles(kw)+eta*at_angles(kz)).subs(src))
contact=s.expand(at_angles(Aw)*zeta/eta+at_angles(Az)-2*x*zeta*at_angles(b0+b1*U))
check('native_scalar_contact',contact.subs(src))
la=s.symbols('lambda')
rad=s.expand(Aw.subs({u**2:la*x,v**2:la*y})*zeta/eta+Az.subs({u**2:la*x,v**2:la*y})-2*la*x*zeta*(b0+b1*la*x))
arad=x*(x*zeta)**2*r*r*(m+A+al+s.Rational(1,2))+x*x*y*h*h*(D+s.Rational(1,2))
check('exact_radial_scalar_including_beta', (rad-(la-1)**2*(arad*la+al)).subs(src))

# Exact hard-Y completion of the auxiliary quadratic base, with actual weights.
p,t=s.symbols('p t')
H=C+A+D+s.Rational(1,2)
aa=A*(C+D+s.Rational(1,2))/H
cc=D*(C+A+s.Rational(1,2))/H
bb=s.Rational(1,2)+A*D/H
base=C*(p-Y)**2+A*Y*Y+D*(p-Y-t)**2+(p-Y)**2/2-p*t
normal=Y-(C+D+s.Rational(1,2))*p/H+D*t/H
check('actual_quadratic_base_full_normal',base-H*normal**2-aa*p*p-cc*t*t+2*bb*p*t)
N=8*A*C*D-4*A*D-2*A-2*C-2*D-1
check('actual_soft_determinant',aa*cc-bb*bb-N/(8*H))

# Opening-safe comparison weights: e=eta*T makes j=e+r-1 positive.
e=s.symbols('e')
j0=e+r-1
comp={C:(r+e)/(2*(1-r)),A:e/(2*r),D:1/(2*j0)}
H0=e*(j0+r)/(2*r*(1-r)*j0)
a0=r*(e+r)/(j0+r); bnormal=r*(1-r)/(e*(j0+r))
gamma=(e+r)/(2*e*(j0+r))
check('comparison_full_normal_and_binomial',base.subs(comp)-H0*(Y-a0*p+bnormal*t)**2-gamma*(e*p-t)**2)
check('comparison_C_ratio',src[C]/comp[C].subs(e,eta*T)-K*(r+eta)*E/((r+eta*T)*Pd))
check('comparison_A_ratio',src[A]/comp[A].subs(e,eta*T)-P4/(T*Pd))
check('comparison_D_ratio',src[D]/comp[D].subs(e,eta*T)-B5/Pd)

# Exact polynomial controlling the negative soft determinant.
L=s.symbols('L')
A1=-eta**2*h*h*x*x-eta**2*h*h*x-2*eta*h*h*r*x*x-2*eta*h*h*x+2*eta*h*r*x*x+3*eta*h*x+eta*h+2*h*r*r*x*x+6*h*r*x+4*h+2*r
A0=eta**2*h**4*x*x-eta**2*h**3*x*x+eta**2*h**3*x-eta**2*h*h*x-2*eta*h**3*r*x*x-4*eta*h**3*x+eta*h*h*r*x*x-eta*h*h*r*x+2*eta*h*h*x-4*eta*h*h+2*eta*h+h*h*r*r*x*x+4*h*h*r*x+4*h*h+2*h*r
Delta=R*(eta*K+R)*L*L+(2+x*A1)*L+x*(4*h-1+x*A0)
expected=-eta*(r+eta)**2*K*P4*Delta.subs(L,x*zeta)/(r*(1-r)*j*Pd**3)
check('negative_soft_defect_source_factor',N.subs(src)-expected)
check('defect_L2_coefficient',s.expand(Delta).coeff(L,2)-R*(eta*K+R))
check('defect_L_coefficient_residue',s.expand(Delta).coeff(L,1).subs(x,0)-2)
check('defect_x_coefficient_residue',s.expand(Delta.subs(L,0)/x).subs(x,0)-(4*h-1))
check('beta_opening_product',2*theta*src[be]*Pd-(K*(r+eta)*(x*h+x*zeta)-theta*Pd))

output={"status":"PASS","identities":len(checks),"checks":checks,"scope":"Exact original full-normal reduction and source soft-defect factor. No new all-tests admission; both C14.3/C14.4 remain open."}
path=Path(__file__).with_suffix('.json');path.write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
