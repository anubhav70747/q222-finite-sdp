"""Exact n=0 HI retained module and contact jets; no positivity sampling."""
import json
from pathlib import Path

import sympy as s

out = Path(__file__).parent
checks = {}


def check(name, expr):
    num = s.cancel(expr).as_numer_denom()[0]
    assert s.expand(num) == 0, (name, s.factor(num))
    checks[name] = True


p, v, q, y, Sc, t, E = s.symbols('p v q y Sc t E')
c, d, mu, al = s.symbols('c d mu al')
nc, nm, L, Lm = s.symbols('nc nm L Lm')
dp, dv = 1+p**2, 1+v**2
deltap, deltav = p**2-q, v**2-y
j, K = Sc-t*(1+y), Sc-E*(1+q)
ND = dv*nc-t*deltav*L/Sc
NM = dp*nm+E*deltap*Lm/Sc
pair_c = 4*c*dv*(nc-t*L/Sc)**2/t + 4*d*(ND+j*L/Sc)**2/j
exc_c = 4*c*j*dv*nc**2/(t*Sc) + 4*d*t*(1+y)*ND**2/(j*Sc)
rem_c = 4*(c*(1+y)*dv*nc**2+d*ND**2-2*c*dv*nc*L+2*d*ND*L+(c*t*dv+d*j)*L**2/Sc)/Sc
check('C_D_retained_pair', pair_c-exc_c-rem_c)
pair_m = 4*mu*(NM-K*Lm/Sc)**2/K+4*al*dp*(nm+E*Lm/Sc)**2/E
exc_m = 4*mu*E*(1+q)*NM**2/(K*Sc)+4*al*K*dp*nm**2/(E*Sc)
rem_m = 4*(mu*NM**2+al*(1+q)*dp*nm**2-2*mu*NM*Lm+2*al*dp*nm*Lm+(mu*K+al*E*dp)*Lm**2/Sc)/Sc
check('m_alpha_retained_pair', pair_m-exc_m-rem_m)

r, z, ss, QQ, H, R = s.symbols('r z ss QQ H R')
rt = {q:r*r, y:z*z}
A0 = z*nc+t*v*ss
B0 = r*nm-E*p*ss
S = -Sc*ss
Y = H*QQ/(r*z)
W = p*Y+A0
Z = v*Y-B0
X = S+v*A0-p*B0+p*v*Y
J = W+v*X-p*Y-p*v*Z
M = p*v*W-p*X+v*Y-Z
check('J_common_state', J-dv*A0-v*S)
check('M_common_state', M-dp*B0+p*S)
core = 2*J**2+2*dp*B0**2+2*dv*(p*X+Z)**2-2*dp*dv*Z**2
g = Sc-t*v*v-E*p*p
graph_core_ss = 2*v*v*(t*deltav-j)**2+2*p*p*dv*(E*deltap-K+t*v*v)**2-2*E*E*p*p*v*v*dp
core_cs = 4*z*v*dv*(t*(1+v*v+p*p*v*v)+E*p*p*dp-Sc*dp)
core_ms = 4*r*p*dp*(Sc*dv-E*(1+p*p+p*p*v*v)-t*v*v*dv)
core_expected = (
    2*z*z*dv*(1+v*v+p*p*v*v)*nc**2
    +2*r*r*dp*(1+p*p+p*p*v*v)*nm**2
    -4*r*z*p*v*dp*dv*nc*nm
    +core_cs*nc*ss+core_ms*nm*ss
    +4*H*(p/r)*v*v*dp*dv*nc*QQ
    -4*H*(v/z)*p*p*dp*dv*nm*QQ
    +graph_core_ss.subs(rt)*ss**2
    -4*H*(p*v/(r*z))*dp*dv*g*ss*QQ
    +2*H*H*(p*v/(r*z))**2*dp*dv*QQ**2
)
check('full_core_in_normal_module', core-core_expected)

# Retained graph, including A=q*y*R/(2H), valid at literal n=0.
a = 4*(mu*K+al*E*dp-2*mu*E*deltap+mu*E**2*deltap**2/Sc)+2*q*dv*(E*deltap-K+t*v*v)**2-2*E**2*q*v*v*dp
b = 4*(c*t*dv+d*j-2*d*t*deltav+d*t*t*deltav**2/Sc)+2*y*(t*deltav-j)**2
cc, dd, ee = 2*H*H*dp*dv, 2*H*R*dp*dv, 4*H*dp*dv*g
graph = (a*(p/r)**2*ss**2+b*(v/z)**2*ss**2+cc*(p*v/(r*z))**2*QQ**2+dd*QQ**2-ee*(p*v/(r*z))*ss*QQ).subs(rt)
ret_graph = (rem_c.subs({nc:0,L:-Sc*v*ss/z})+rem_m.subs({nm:0,Lm:-Sc*p*ss/r})).subs(rt)
check('four_term_graph_module', ret_graph+core_expected.subs({nc:0,nm:0})+2*H*R*dp*dv*QQ**2-graph)

cs_raw = 8*dv*((c-d)+d*t*deltav/Sc)+4*y*dv*(t*(1+v*v+p*p*v*v)+E*p*p*dp-Sc*dp)
ms_raw = 8*dp*((mu-al)-mu*E*deltap/Sc)+4*q*dp*(Sc*dv-E*(1+p*p+p*p*v*v)-t*v*v*dv)
cs = 4*dv*(y*(R*(1+q)-dp*g)+2*d*t*deltav/Sc)
ms = 4*dp*(q*(dv*g-R*(1+y))-2*mu*E*deltap/Sc)
check('Nc_coefficient_after_source_difference', cs_raw.subs(c,d+y*(R*(1+q)-t)/2)-cs)
check('Nm_coefficient_after_source_difference', ms_raw.subs(al,mu-q*(E-R*(1+y))/2)-ms)

# Verify exact rational source identities modulo the n=0 numerator.
Hs = 1-q*E
Bs = Hs+y*t
Scs = 1+R+y*t
Ds = (1+q)*(Bs**2+2*Bs*R+(1+y)*Bs)+(1-y*q)*R**2+2*(1+y)*R+1+y
Ns = (1+q)*(Bs+R)*(Hs+y)-(1+y)*(1-q*R)*y*t
f0 = s.expand((Bs+R)*(1+R)*Scs-R*Ds)
src = {H:Hs,Sc:Scs,c:(1+R)*Ns/(2*Ds),d:(1+q)*(Bs+R)*(Bs-y*R)*Scs/(2*Ds),mu:(1+y)*(1-q*R)*(1+R)*Scs/(2*Ds),al:(Bs+R)*Ns/(2*Ds)}
check('source_c_minus_d', (c-d-y*(R*(1+q)-t)/2).subs(src)-y*(1+q)*f0/(2*Ds))
check('source_mu_minus_alpha', (mu-al-q*(E-R*(1+y))/2).subs(src)+q*(1+y)*f0/(2*Ds))


def contact(expr):
    # All expressions passed here are even separately in p and v.
    return s.Poly(s.expand(expr),p,v).eval({p:0,v:0}) if expr == 0 else s.expand(expr).subs({p**2:q,v**2:y})


def n0_check(name, expr):
    num = s.cancel(expr.subs(src)).as_numer_denom()[0]
    remainder = s.rem(s.Poly(num,R),s.Poly(f0,R)).as_expr()
    assert s.expand(remainder) == 0, (name,s.factor(remainder))
    checks[name] = True


astar, bstar, cstar, dstar, estar = [contact(f) for f in (a,b,cc,dd,ee)]
sig = a+b+cc+dd-ee
n0_check('graph_contact_state_a_plus_b', astar+bstar-cstar-dstar)
check('graph_contact_state_e', (estar-2*(cstar+dstar)).subs({H:Hs,Sc:Scs}))
# z_p=sqrt(p): z_p d/dz_p = 2 p d/dp.
n0_check('graph_contact_p_half_angle_jet', contact(2*p*s.diff(sig,p))+4*(astar-dstar))
n0_check('graph_contact_v_half_angle_jet', contact(2*v*s.diff(sig,v))+4*(bstar-dstar))
check('Nc_raw_coefficient_contact', (contact(cs)+4*H*y*(1+q)*(1+y)).subs({H:Hs,Sc:Scs}))
check('Nm_raw_coefficient_contact', (contact(ms)-4*H*q*(1+q)*(1+y)).subs({H:Hs,Sc:Scs}))

# Pure monomial half-angle conductors and exact quadratic jet remainders.
aa, bb, ccc, ddd, GG = s.symbols('aa bb ccc ddd GG')
check('geometric_mean_linear_jet', (aa*ccc-(aa**2+ccc**2)/2)+(aa-ccc)**2/2)
check('four_term_AMGM_expansion', sum(x**4-2*GG**2*x*x+GG**4 for x in (aa,bb,ccc,ddd))+2*GG**2*(aa*aa+bb*bb+ccc*ccc+ddd*ddd-4*GG**2)-(aa**4+bb**4+ccc**4+ddd**4-4*GG**4))
payload = {'status':'PASS','checks':checks,'scope':'Exact retained n=0 module, actual source contact and first jets. Bounded AM-GM lift is a separate analytic argument.'}
(out/'check_retained_contact_module.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps({'status':'PASS','count':len(checks)},indent=2))
