# Audit of the all-testing extension for the weak-source C1 D-unit branch

17 October 2026. Same-team focused audit of `root/WEAK_C1_DUNIT_ALL_TESTS.md` and the corresponding integration into `REGULAR_SOURCE_PROOF.tex`. No additional research branch was opened.

## Result

No mathematical gap was found in the stated all-testing extension, conditional on the previously audited exact local weighted admission. In particular:

1. With `p=u_c^2`, `w=v_c^2`, source stationarity and `m=O(p^2)` give the exact real-residue polynomial
   `Dbar(U,V)=U q12bar(V-wbar)^2+U^2 V(q21bar+q22bar V)`.
   Both `q12bar,q21bar` are strictly positive.
2. Removing only the original positive `m` packet gives an exact polynomial baseline Gram on `(X,Y,Z,uW)`. All terms containing `W` do have a factor `u` once `m=0`; no inverse of `u` occurs in its coefficients.
3. Its determinant identity is `det P_baseline=u^2 det H`, obtained by a state-frame determinant square. Cancellation here is a polynomial identity used to identify coefficients, not division of a tensor SOS by a mixed factor.
4. At testing `u` of zero residue, the limiting determinant is
   `16(1+v^2)^2 q12bar(v^2-wbar)^2`.
   The hard `XYZ` block is strictly positive for all real finite `v`, using the strong `alpha,D` pivots. Thus the baseline matrix is strict whenever the testing `v` residue is different from the signed contact residues. It is strict at `v=0` as well.
5. In the reciprocal chart `b=1/v`, the correct matrix is `b^2 H(u,1/b)`. Its determinant at `u=b=0` is the degree-eight leading coefficient `16 q12bar>0`; its hard block is also strict since `D` is a unit. The normalization denominator becomes `(1+u^2)(1+b^2)`, a permitted pure-testing factor. This genuinely covers testing `v` infinity.
6. Signed contact residues reduce exactly by the whole-parent diagonal sign conjugation. The local theorem therefore covers both signs without a second weighted argument.
7. For ordinary testing `u,v`, the residue determinant is strict because its second summand contains the unit `q21`. The remaining edges have strict four-state residue from the printed exact square forms. The corners `(infinity,0)` and `(infinity,infinity)` use positive-unit stiffnesses even though `m` is weak; the latter retains the exact `beta` packet when `beta` is weak. These cases exhaust the testing projective square.

The regular-source proof's finite state transport, strict bounded-Gram lemma, determinant normalization, edge forms, and C2 kernel-corner arguments are consistent with this extension. Its abstract and final frontier sentences must be updated when the additional theorem is inserted: they should no longer say that every degenerating source angle is outside the shortcut. Weak `D`, two degenerating source angles, and zero-residue normalized `d` remain outside the new weak-source result.

This audit is analytical checking by a second collaborating agent. It is neither external peer review nor a verification of the remaining source terminals.
