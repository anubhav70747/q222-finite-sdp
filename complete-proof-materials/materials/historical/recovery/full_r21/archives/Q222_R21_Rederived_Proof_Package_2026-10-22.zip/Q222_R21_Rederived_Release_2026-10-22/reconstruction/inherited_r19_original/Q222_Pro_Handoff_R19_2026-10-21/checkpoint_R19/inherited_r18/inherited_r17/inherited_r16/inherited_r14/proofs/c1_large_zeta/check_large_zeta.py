"""New large-zeta C1 bounded testing-ratio certificate: exact source checks."""
import json
from pathlib import Path
import sympy as s
# Original finite polynomial definitions, reproduced for standalone use.
checks = {}
reports = {}
def zero(name, expr):
    q = s.factor(s.cancel(expr))
    if q != 0:
        raise AssertionError((name, q))
    checks[name] = True
    print("PASS", name, flush=True)

x,eta,zeta,r,pi,U,V = s.symbols("x eta zeta r pi U V")
c,a,D,m,al,be,h = s.symbols("c a D m alpha beta h")
theta=1-h;rho=eta+r;j0=eta+r-1
b=r*(1-r)/(eta*(j0+r))
H0=eta*(j0+r)/(2*r*(1-r)*j0)
gamma=rho/(2*eta*(j0+r))
B0=be+s.Rational(1,2)
Du=1+U;Dv=1+V;y=x*eta*zeta
# c=C(1-r), a=Ar.  Neither opening is inverted in these arrays.
Aw=m*V*(1+r*U)**2+c*(1-r)*Dv*U+a*r*Du*Dv*U+(D+s.Rational(1,2))*(1-r)**2*U+(al+s.Rational(1,2))*Du*r*r*U*V
bzero=m*theta+D*(1-r)+al*r+s.Rational(1,2)
bone=m*r*theta+h*(D+s.Rational(1,2))*(1-r)+(al+s.Rational(1,2))*r
kw=m*V*(1+r*U)-c*Dv+a*Du*Dv-(D+s.Rational(1,2))*(1-r)+(al+s.Rational(1,2))*Du*r*V
kz=-m*theta*U+(D+s.Rational(1,2))*(1+h*U)-(al+s.Rational(1,2))*Du
PY=s.expand(2*(kw/eta+kz))
PE=s.cancel(2*(Aw/U-m*V/U)/eta**2-2*(bzero+bone*U)/eta+b*PY)
PY0=PY.subs({U:0,V:0});PE0=PE.subs({U:0,V:0})
cF=(c*(1-r)+a*r+(al+s.Rational(1,2))*r*r+2*m*r)/eta**2
aUV=a*r/eta**2+h*h/2+2*D*h+be*theta**2-2*bone/eta
aUUV=h*h*(D+s.Rational(1,2))
aUVV=r*r*(m+al+s.Rational(1,2))/eta**2+a*r/eta**2
qV=(c*(1-r)+a*r+(D+s.Rational(1,2))*(1-r)**2)/eta**2+D-2*bzero/eta
qU=al+(m+B0)*theta**2
fA=aUV+aUUV*U+aUVV*V
fB=m*zeta/(eta*x)
fC=(al-cF*y*y+qU*U)/(eta*zeta*x*x)
fG=-(qV+2*cF*y)/x


L,z=s.symbols('L z')
xx=L*z;hs=1-L*pi;ths=L*pi;yy=eta*L
K=1+xx;R=1+xx*r;T=1+xx*hs
M=R-ths*z;J=T-(1-r)/eta;Es=1-xx*eta*hs;Q=1-L*r
P4=T*Es+(1-r)*(xx*hs+L)
Pa_z=z*R*hs*(1+yy)+M*Es
Pd=1+2*xx*hs+r*xx*(xx*hs+L)+L+eta*(K*L+xx*xx*hs*ths)
B5=K*(1+yy)*rho-eta*J*Pd
Bbeta=K*rho*(xx*hs+L)-ths*Pd
src={h:hs,c:K*rho*Es/(2*Pd),a:eta*P4/(2*Pd),D:B5/(2*eta*J*Pd),m:K*xx*z*rho*hs*(1+yy)/(2*M*Pd),al:L*L*rho*Pa_z/(2*Q*Pd),be:Bbeta/(2*ths*Pd)}
# Clear the common unit denominator before exact monic division.
bt=s.symbols('bt')
weights=(c,a,D,m,al,bt)
src[bt]=K*rho*(xx*hs+L)/(2*Pd)
unit_den=2*M*Q*(eta*J)*Pd
nums={q:s.cancel(unit_den*src[q]) for q in weights}
def audit(name,expr,target=None):
    expr=s.cancel(expr.subs(be,bt/(1-h)-s.Rational(1,2)))
    expr=s.factor(expr.subs({x:xx,zeta:1/z,h:hs}))
    enum,eden=s.fraction(expr)
    ep=s.Poly(enum,*weights)
    assert ep.total_degree()<=1,(name,'nonlinear')
    num=s.expand(ep.coeff_monomial(1)*unit_den+sum(ep.coeff_monomial(q)*nums[q] for q in weights))
    den=s.factor(eden*unit_den)
    divisions=[]
    for var in (L,z):
        while den.subs(var,0)==0:
            quo,rem=s.div(num,var,var)
            assert rem==0,(name,var,'nondivisible')
            num=quo;den=s.cancel(den/var);divisions.append(str(var))
    den0=s.factor(den.subs({L:0,z:0}))
    assert den0!=0 and not den0.has(pi),(name,den0)
    allowed={s.Poly(q,eta,r).monic().as_expr() for q in (eta,eta+r-1,eta+2*r-1)}
    for fac,_ in s.factor_list(den0)[1]:
        assert s.Poly(fac,eta,r).monic().as_expr() in allowed,(name,fac)
    res=s.factor(num.subs({L:0,z:0})/den0)
    if target is not None: zero(name+'_residue',res-target)
    reports[name]={'monic_divisions':divisions,'denominator_at_corner':str(den0),'residue':str(res)}
    checks[name+'_regular']=True
    print('PASS',name,flush=True)
lam=rho/(2*eta)
audit('cF',cF,rho/(2*eta**2))
audit('fA0',fA.subs({U:0,V:0}),lam)
audit('fB',fB,lam)
audit('fC0',fC.subs(U,0),lam)
audit('fG',fG,3*lam)
for name,e in {'c_error_L':(c-rho/2)/L,'a_error_L':(a-eta/2)/L,'D_error_L':(D-1/(2*j0))/L,'PY00_L':PY0/L,'PE00_L':PE0/L,'X00_L':theta*(m+B0)/L,'m_Lz2':m/(L*z*z),'alpha_L2':al/L**2,'Bx_theta_L':B0*theta/L,'qU_L2':qU/L**2}.items():audit(name,e)
u,w=s.symbols('u w');v=u*w;At=u*v;Fv=v*v-eta*L
zero('Lu_allocation',L*u-(v*At-u*Fv)/eta)
zero('Lv_allocation',L*v-(u*w*w*At-v*Fv)/eta)
# Radical-free check of G^2=(w/slope) A C, s^2=eta/z.
k,slope=s.symbols('k slope');Ct=k*k*slope;G=k*v
zero('negative_circuit_cross',G*G-w/slope*At*Ct)
out={'status':'PASS','checks':checks,'count':len(checks),'reports':reports,'scope':'Source and root identities for C14.3a subdomain eta,j0 units, zeta unbounded, bounded testing v/u. No all-tests claim.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
