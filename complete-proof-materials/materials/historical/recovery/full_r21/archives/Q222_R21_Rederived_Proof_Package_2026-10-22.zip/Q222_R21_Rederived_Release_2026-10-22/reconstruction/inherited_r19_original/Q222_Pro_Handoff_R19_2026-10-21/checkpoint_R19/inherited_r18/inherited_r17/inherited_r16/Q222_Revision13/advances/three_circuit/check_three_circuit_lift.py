"""Generic finite three-circuit identities; no source-domain certification."""
import json
from pathlib import Path
import sympy as S

checks = {}
k, s, u, t = S.symbols('k s u t', positive=True)
A = [u*u*t, k*u*t*t/s, k*k*s]
G = k*u*t
d = [a-G for a in A]
checks['toric_product'] = S.cancel(S.prod(A)-G**3) == 0
checks['u_conductor'] = S.expand(G*(u-k)-k*d[0]) == 0
checks['t_conductor'] = S.expand(G*(t-s)-s*d[1]) == 0

a = S.symbols('a1:4', positive=True)
g = S.prod(a)
q = g*(sum(x**3 for x in a)-3*g)
qs = S.Rational(1,2)*sum(g*a[l]*(a[i]-a[j])**2
       for i,j in [(0,1),(0,2),(1,2)] for l in range(3))
checks['nine_root_Q_identity'] = S.expand(q-qs) == 0
checks['strict_L_identity'] = S.expand(sum(x**6 for x in a)-3*g*g
                       -sum((x**3-g)**2 for x in a)-2*q) == 0

# Verify a formal identity modulo precisely the two conductor relations.
aa = S.symbols('A1:4')
gg, du, dt, bu, bt, e3 = S.symbols('G du dt bu bt e3')
dd = [x-gg for x in aa]
K = S.Matrix(3,2,lambda i,j:S.Symbol(f'K{i}{j}'))
H = S.Matrix(2,2,lambda i,j:S.Symbol(f'H{i}{j}'))
e0 = [e3-k*bu/2,e3-s*bt/2,e3]
ee = [e0[i]+K[i,0]*du+K[i,1]*dt for i in range(3)]
hh = bu*du+bt*dt+H[0,0]*du**2+(H[0,1]+H[1,0])*du*dt+H[1,1]*dt**2
actual = sum(ee[i]*(aa[i]**2-gg**2) for i in range(3))+hh*gg**2
rhs = (sum(ee[i]*dd[i]**2 for i in range(3))+2*e3*gg*sum(dd)
       +2*sum(k*K[i,0]*dd[0]*dd[i]+s*K[i,1]*dd[1]*dd[i] for i in range(3))
       +k*k*H[0,0]*dd[0]**2+k*s*(H[0,1]+H[1,0])*dd[0]*dd[1]
       +s*s*H[1,1]*dd[1]**2)
# Purely algebraic substitution in the checker; the proof uses conductors,
# and never inverts G in the tensor ring.
checks['exact_error_identity'] = S.cancel((actual-rhs).subs({du:k*dd[0]/gg,dt:s*dd[1]/gg})) == 0
ju,jt = S.symbols('Ju Jt')
c0,c1,c2 = S.symbols('c0 c1 c2')
checks['normal_conductor_identity'] = S.expand(
 G*(ju*(u-k)+jt*(t-s))-k*ju*d[0]-s*jt*d[1]) == 0
assert all(checks.values()), checks
out = {'status':'PASS','scope':'seven generic exact identities; source finite arrays and normal bounds are not certified here','checks':checks}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'PASS','exact_checks':len(checks)}))
