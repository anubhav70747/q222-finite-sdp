"""Only new C14.2 reciprocal-strip identities; no inherited replay."""
import json
from pathlib import Path
import sympy as s
u,w,W,X,Y,Z,P,T,L,r,f=s.symbols('u w W X Y Z P T L r f', nonzero=True)
U=u*u; Du=1+U; Dw=1+w*w
C0=1/(2*L*(1-r)); A0=(1+L*(1-r))/(2*L*r); al0=L/(2*(1-L*r))
J=u*w*W+u*X-w*Y-Z
core=J*J+Du*(Y-w*Z)**2+Dw*(X+u*Z)**2-Du*Dw*Z*Z
Kr=s.cancel(core.subs({W:P/u,Z:T/w},simultaneous=True))
K0=Du*X*X+Du*Y*Y+U*T*T-2*U*T*Y-2*P*T
checks={}
def ck(name,expr):
    assert s.cancel(expr)==0,name
    checks[name]=True
    print('PASS '+name)
ck('complete_reciprocal_core_split',Kr-K0-w*w*((P-Y)**2+X*X)-2*u*w*X*(T+P-Y))
Q0=C0*(P-Y)**2+A0*Du*Y*Y+al0*Du*(Y-T)**2+K0/2
target=Du*X*X/2+C0*(P-Y-L*(1-r)*T)**2+(A0+al0+s.Rational(1,2))*(Y-L*r*T)**2+U*(A0*Y*Y+(al0+s.Rational(1,2))*(Y-T)**2)
ck('complete_leading_selected_square_identity',Q0-target)
selected=f*(C0*Dw*(P-Y)**2+A0*Du*Dw*Y*Y+al0*Du*(Y-T)**2)+Kr/2
account=f*target+f*w*w*(C0*(P-Y)**2+A0*Du*Y*Y)+(1-f)*K0/2+(Kr-K0)/2
ck('actual_common_factor_full_signed_accounting',selected-account)
payload={'status':'PASS','count':len(checks),'checks':checks,'scope':'New full selected-polynomial identities on C14.2 unit-u reciprocal-Bob strip; opening-uniform source estimates and remote inherited identities are analytical imports.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
print(str(len(checks))+' focused checks passed')
