"""Exact complete WA matrix, centered m correction, RA3 transform and source leading matrix. Used by the focused R18 checker only."""
import sympy as z
s,b,w,nu,c,h,t,K,g,kap=z.symbols('s b w nu c h t K g kap')
u,v=z.symbols('u v');U=u*u;V=v*v
A,C,D=z.symbols('A C D');r=1-s*w;B=s*s*b;n=s*s*nu;al=s**3*b*b*c;l=1-h;ell=s;k=1/t;m=K
aw=(C+D+z.Rational(1,2))*l*l+A*h*h;a4=A*h*h
b2=2*m*h+C*l*l+(A+al+z.Rational(1,2))*h*h;b4=h*h*(m+A+al+z.Rational(1,2));c4=n*r*r
d2=(n+z.Rational(1,2))*r*r+2*D*r;d4=(n+D+z.Rational(1,2))*r*r
beta=(B*d4+k*c4)/(k*ell**2);gam=b4+d4/(k*ell)
j0=(B*d4-a4*k*k*ell+d2*ell)/(2*k*ell**2);j1=d4/(2*k*ell);Js=j0+j1*U
fs=(b2-c4/ell**2-al/B**2-B*d4/(k*ell**2))/2
SS=z.Matrix([[aw+a4*U,u*v*Js,-v*Js],[u*v*Js,m+beta*U,u*(fs-j1*U)],[-v*Js,u*(fs-j1*U),al/B**2+gam*U]])
p0=(D+r*(n+z.Rational(1,2)))/k;p1=r*(n+D+z.Rational(1,2))/k;q1=(n*r+B*p1)/ell
fx=-m*h+(D+z.Rational(1,2))*l-p0-q1
Lx=z.Matrix([[u*v*(p0+p1*U),-m+q1*U,u*(fx-p1*U)]])
py=-(C+D+z.Rational(1,2))*l+A*h;pyp=A*h
kv=-C*l+A*h+m+(al+z.Rational(1,2))*h;kuv=h*(A+m+al+z.Rational(1,2));kz=-m*(1-r)+r*(D+z.Rational(1,2))-al-z.Rational(1,2)
qy=(-kz-k*pyp-B*kuv)/ell;fy=kv-qy
Ly=z.Matrix([[py+pyp*U,u*v*qy,v*(fy+kuv*U)]])
hxx=n*(1+U)*(1+V)+m+(D+z.Rational(1,2))*U*V+(1+V)/2
hxy=-u*v*(m+D+z.Rational(1,2));hyy=A*(1+U)*(1+V)+C*(1+V)+D+z.Rational(1,2)+m*U*V+(al+z.Rational(1,2))*(1+U)*V
G=z.zeros(5);G[:2,:2]=z.Matrix([[hxx,hxy],[hxy,hyy]]);G[0,2:5]=Lx;G[1,2:5]=Ly;G[2:5,0]=Lx.T;G[2:5,1]=Ly.T;G[2:5,2:5]=SS
Hm=z.zeros(5)
for i,j,val in [(0,3,-1),(1,4,v),(3,3,2-g),(3,4,h*u)]:Hm[i,j]=Hm[j,i]=val
P=z.eye(5);P[4,3]=u;P[4,4]=s
GN=(P.T*(G+kap*Hm)*P).applyfunc(z.cancel)
lead=GN.subs(s,0).subs({w:1,g:0,kap:z.Rational(1,2),A:t/(2*h),C:(h+t)/(2*l),D:1/(2*(t-l)),c:(h+t)/2}).applyfunc(z.factor)
