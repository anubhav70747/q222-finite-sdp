#!/usr/bin/env python3
"""Finite exact algebra behind SP1--SP7; not a full-parent tensor proof."""
import json
from pathlib import Path
import sympy as s

X,Y=s.symbols('X Y',positive=True)
a,b,c,d,e,f,t,h=s.symbols('a b c d e f t h')
checks={}
def zero(name,expr):
    assert s.cancel(expr)==0,name
    checks[name]=True

L2=a*(1/X-1)+b*(Y/X-1)+c*(1/Y-1)+d*(Y-1)+e*(X/Y-1)+f*(X-1)
plus=f*(X+1/X-2)+b*(X/Y+Y/X-2)+c*(Y+1/Y-2)+t*(1/X+Y+X/Y-3)
minus=a*(X+1/X-2)+e*(X/Y+Y/X-2)+d*(Y+1/Y-2)+h*(Y/X+1/Y+X-3)
zero('SP2_C2_positive_balance',L2.subs({a:f+t,e:b+t,d:c+t},simultaneous=True)-plus)
zero('SP3_C2_negative_balance',L2.subs({f:a+h,b:e+h,c:d+h},simultaneous=True)-minus)
L1=a*(1/X-1)+b*(Y/X-1)+c*(1/Y-1)+d*(Y-1)+e*(X-1)+f*(X*Y-1)
plus1=t*(X+1/X-2)+d*(Y+1/Y-2)+b*(Y/X+X+1/Y-3)+f*(X*Y+1/X+1/Y-3)
minus1=d*(Y+1/Y-2)+e*(Y/X+X+1/Y-3)+a*(X*Y+1/X+1/Y-3)+h*(Y/X+X*Y+2/Y-4)
zero('SP5_C1_positive_balance',L1.subs({a:f+t,e:b+t,c:b+d+f},simultaneous=True)-plus1)
zero('SP6_C1_negative_balance',L1.subs({b:e+h,f:a+h,c:e+a+2*h+d},simultaneous=True)-minus1)
p,q,r=s.symbols('p q r')
zero('SP4_algebraic_three_term_AM_GM',p**3+q**3+r**3-3*p*q*r-(p+q+r)*((p-q)**2+(q-r)**2+(r-p)**2)/2)
xs,ys=s.symbols('xs ys',positive=True)
zero('SP7_weighted_four_term_circuit',(Y/X+X*Y+2/Y-4).subs({X:xs**2,Y:ys**2})-(ys/xs-xs*ys)**2-2*(ys-1/ys)**2)
zero('two_term_pair',(X+1/X-2).subs(X,xs**2)-(xs-1/xs)**2)
for i,tri in enumerate([(1/X,Y,X/Y),(Y/X,1/Y,X),(Y/X,X,1/Y),(X*Y,1/X,1/Y)],1):
    zero('triangle_product_'+str(i),s.prod(tri)-1)
record={'status':'PASS','checks':checks,'count':len(checks),
        'scope':'Exact balanced Laurent circuit identities only. Source physicality follows by the printed positive-transverse-block argument; tensor determinant SOS does not admit the full parent.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
