import sympy as s,json
from pathlib import Path
u,w,E,N,xi=s.symbols('u w E N xi');a,b,t,r,m,n,C,Ah,D,al=s.symbols('a b t r m n C Ah D alpha');h=b*b;v=u*w;U=u*u;V=v*v
W=(v+E)/(t*u);Y=h*(v+E)/t+b*N;X=xi-r*u;Du=1+U;Dv=1+V
Rm=v*W-X+u*v*Y-u;RD=u*W+u*v*X-Y-v
F=n*Du*Dv*X*X+m*Rm*Rm+C*Dv*(u*W-Y)**2+(Ah/h)*Du*Dv*Y*Y+(D+s.Rational(1,2))*RD*RD+(al+s.Rational(1,2))*Du*(v*Y-1)**2+Dv*(X+u)**2/2-Du*Dv/2
q=n*r*r+(m+s.Rational(1,2))*(1-r)**2+al;mt=m-a*a*q
Hu=a*V/(t*u)-u
Q=q*(Hu+a*w*E/t-a*xi)**2
NR=n*u*u*(r*Hu+xi)**2
sing=mt*(w*E/t-xi)**2
R=s.Poly(s.cancel(F-Q-NR-sing),E,N,xi)
checks={};report={}
def ck(name,ex):
 assert s.cancel(ex)==0,(name,s.factor(ex));checks[name]=True
norm=[s.expand(R.coeff_monomial(z)) for z in (E,N,xi)]
# Exact source-free polynomial arrays from WC13/17a after q*=qs+alpha.
aw=(C+D+s.Rational(1,2))*(1-h)**2+Ah*h
b2=2*m*h+C*(1-h)**2+Ah*h+(al+s.Rational(1,2))*h*h
b4=h*h*(m+al+s.Rational(1,2))+Ah*h
e0=m*(1-r)+D*(1-h)+al*h+s.Rational(1,2)
e1=m*h*(1-r)+r*(D+s.Rational(1,2))*(1-h)+(al+s.Rational(1,2))*h
KE=aw/t**2-e0/t+a*q/t
Ae=2*Ah*h/t**2-2*e1/t;Be=2*b2/t**2;Ce=2*b4/t**2
ck('whole_E_normal_after_full_square_subtraction',norm[0]-(2*mt*v*w*w/t**2+2*KE*v+Ae*u*u*v+Be*v**3+Ce*u*u*v**3))
KX=-n*r+(m+s.Rational(1,2))*(1-r)-a*q
x3=2*((D+s.Rational(1,2))*((1-h)/t-1)+(1-r)/2-n*r*(1+a/t)-m*h/t)
x5=-2*r*(n+D+s.Rational(1,2))
ck('whole_xi_normal_after_full_square_subtraction',norm[2]-(2*KX*u-2*mt*u*w*w/t+x3*u**3*w*w+x5*u**5*w*w))
KY=(-(C+D+s.Rational(1,2))*(1-h)+Ah)/t+D-al
Ay=2*(Ah/t-m*(1-r)+r*(D+s.Rational(1,2))-al-s.Rational(1,2))
By=2*(-C*(1-h)+Ah+m+(al+s.Rational(1,2))*h)/t
Cy=2*(Ah+h*(m+al+s.Rational(1,2)))/t
ck('whole_Ny_normal_after_full_square_subtraction',norm[1]-b*(2*KY*v+Ay*u*u*v+By*v**3+Cy*u*u*v**3))
for i,z in enumerate((E,N,xi)):
 for j,z2 in enumerate((E,N,xi)):
  if j<i:continue
  coeff=s.expand(R.coeff_monomial(z*z2));pol=s.Poly(coeff,u,w)
  bad=[(mon,co) for mon,co in pol.terms() if mon[0]<mon[1] or min(mon)<0]
  assert not bad,(z,z2,bad)
  checks['hard_no_unbounded_testing_ratio_'+str(i)+str(j)]=True
  corner={a:0,b:0,r:1,m:0,n:0,al:0,C:t/2,Ah:t/2,D:1/(2*(t-1)),u:0}
  value=s.factor(coeff.subs(corner))
  expected=0 if i!=j else [1/(2*(t-1)),t/2,s.Rational(1,2)][i]
  ck('hard_residue_'+str(i)+str(j),value-expected)
ck('E_RD_coefficient_residue',Ae.subs({b:0,r:1,m:0,n:0,al:0,D:1/(2*(t-1))})+1/(t-1))
M=s.Matrix([[1,-1],[-1,t]])/(2*(t-1));ck('E_RD_strict_determinant',M.det()-1/(4*(t-1)))
k,c=s.symbols('k c');vv=u*w;x=k*k;G=k*vv;At=u*vv;Ct=x/c;Rad=vv*(u*u-x)
ck('xi_residual_without_radical_root',x*u-c*k*G-(c*Rad-c*u*(At-Ct)))
# Large-zeta C1 joint hard/radial Schur pivot requested by root.
eta,rr=s.symbols('eta rr');j0=eta+rr-1;rho=eta+rr;H0=eta*(j0+rr)/(2*rr*(1-rr)*j0);gamma=rho/(2*eta*(j0+rr));d4=rho/(2*j0)
ck('C1_large_zeta_joint_Schur_pivot',d4-gamma*(1-rr)**2-rho**2/(4*j0*j0*H0)-rho/(2*eta))
out={'status':'PASS','checks':checks,'count':len(checks),'important':'Direct E residual B coefficient is 2 b2/t² before any further full Fv-square recombination; it is bounded. These checks do not replace exact source contact or scalar identities.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
