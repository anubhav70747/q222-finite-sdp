"""Exact original-source cancellations for the local UI cap argument."""
from pathlib import Path
import json
import sympy as s
a,b,r,t,k2=s.symbols('a b r t k2',nonzero=True)
z=a*a;e=k2/z
h=b-e*t;g=(1+z)*b-1+r-k2*t;Ac=1+z*r;S=Ac+k2*t;j=Ac-t
Delta=1+(1+z)*b+z*(1+z)*b*b+2*z*(1+z)*b*r+z*z*r*r+2*z*r
Delta+=e*z*((1+z)*b+1+z*r*(2-r))
N=(1+z)*(b+r)*(b+e*(1-t))-e*(1+e*z)*(1-r)*t
n=((b+r)*Ac*S-r*Delta)/(2*r*Delta)
m=(1+k2)*(1-r)*Ac*S/(2*g*Delta)
C=Ac*N/(2*e*t*Delta)
D=(1+z)*(b+r)*(b-e*z*r)*S/(2*e*j*Delta)
alpha=z*z*(b+r)*N/(2*(1-z*h)*Delta)
x=-r/b;mu=g/b;pi=(z*h-1)/(a*b);rho=t/(a*b);sigma=-j/(a*b)
c1=z*Ac*N/(2*Delta);c2=z*(1+z)*(b+r)*(b-k2*r)*S/(2*Delta)
checks=[]
def eq(name,p,q):
 assert s.factor(p-q)==0,name
 checks.append(name)
eq('n x',n*x,-((b+r)*Ac*S-r*Delta)/(2*b*Delta))
eq('n x squared',n*x*x,x*(-((b+r)*Ac*S-r*Delta)/(2*b*Delta)))
eq('m mu',m*mu,(1+k2)*(1-r)*Ac*S/(2*b*Delta))
eq('m mu squared',m*mu*mu,mu*(1+k2)*(1-r)*Ac*S/(2*b*Delta))
eq('alpha pi',alpha*pi,-z*z*(b+r)*N/(2*a*b*Delta))
eq('alpha pi squared',alpha*pi*pi,pi*(-z*z*(b+r)*N/(2*a*b*Delta)))
eq('C rho k squared',C*rho*k2,c1/(a*b))
eq('D sigma k squared',D*sigma*k2,-c2/(a*b))
eq('k squared harmonic C D',k2*C*D/(C+D),c1*c2/(c1*j+c2*t))
cancelled=((1+z)*(b+r)*(Ac*j-z*t*(b-e*z*r))-Ac*(1+e*z)*(1-r)*t)/(2*Delta)
eq('exact C t minus D j',C*t-D*j,cancelled)
eq('exact bounded average first normal',C*rho+D*sigma,cancelled/(a*b))
H0=z*(1+z)*(b+r)*b/(2*Delta.subs(k2,0))
eq('harmonic coefficient limit',s.cancel(c1*c2/(c1*j+c2*t)).subs(k2,0),H0)
out={'status':'PASS','check_count':len(checks),'checks':checks,'scope':'Original-source rational identities; positivity and cap-limit arguments are in the manuscript.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
