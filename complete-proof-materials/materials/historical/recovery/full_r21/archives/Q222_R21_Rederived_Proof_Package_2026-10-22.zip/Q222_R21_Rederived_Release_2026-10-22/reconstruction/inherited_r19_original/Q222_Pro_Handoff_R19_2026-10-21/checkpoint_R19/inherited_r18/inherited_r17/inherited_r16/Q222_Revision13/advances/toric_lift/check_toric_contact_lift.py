"""Exact generic identities only; no numerical or source-domain assumptions."""
import json
from pathlib import Path
import sympy as s

A = s.symbols('A1:5')
g, mu = s.symbols('g mu')
x0 = s.symbols('x01:4')
dx = s.symbols('dx1:4')
b = s.symbols('b1:4')
K = s.Matrix(4, 3, lambda i,j:s.Symbol(f'K{i}{j}'))
H = s.Matrix(3, 3, lambda i,j:s.Symbol(f'H{i}{j}'))
pairs = [(0,2),(1,2),(0,1)]
had = [[1 if i in pair else -1 for i in range(4)] for pair in pairs]
d = [a-g for a in A]
Q = g*sum(d)
e0 = [mu-sum(x0[j]*b[j]*had[j][i] for j in range(3))/4 for i in range(4)]
e = [e0[i]+sum(dx[j]*K[i,j] for j in range(3)) for i in range(4)]
h = sum(b[j]*dx[j] for j in range(3))+sum(H[j,k]*dx[j]*dx[k] for j in range(3) for k in range(3))
actual = sum(e[i]*(A[i]**2-g**2) for i in range(4))+h*g**2
claimed = (sum(e[i]*d[i]**2 for i in range(4))
 + (2*mu+sum(x0[j]*b[j] for j in range(3))/2)*Q
 +sum(x0[j]*b[j]*d[i]*d[k] for j,(i,k) in enumerate(pairs))
 +2*sum(K[i,j]*dx[j]*g*d[i] for i in range(4) for j in range(3))
 +sum(H[j,k]*dx[j]*dx[k]*g**2 for j in range(3) for k in range(3)))
residual=sum(b[j]*(dx[j]*g**2-x0[j]*(A[i]*A[k]-g**2)) for j,(i,k) in enumerate(pairs))
checks={'generic_error_identity_mod_toric_relations':s.expand(actual-claimed-residual)==0}
for j,(i,k) in enumerate(pairs):
    jet = (x0[j]*(A[i]*A[k]-g**2)-x0[j]*g*sum(had[j][l]*d[l] for l in range(4))/2
           -x0[j]*Q/2-x0[j]*d[i]*d[k])
    checks[f'first_jet_cancellation_{j+1}']=s.expand(jet)==0

# Positive Laurent parametrization with common geometric mean z^4.
a,bp,c,z=s.symbols('a bp c z', positive=True)
roots=[z*a*bp*c,z*a/(bp*c),z*bp/(a*c),z*c/(a*bp)]
Av=[r**4 for r in roots]
G=z**4
L=sum(v**2 for v in Av)-4*G**2
Qv=G*(sum(Av)-4*G)
checks['base_amgm_identity']=s.cancel(L-sum((v-G)**2 for v in Av)-2*Qv)==0
for j,(i,k) in enumerate(pairs):
    r,t=[l for l in range(4) if l not in (i,k)]
    sqrtpair=roots[i]**2*roots[k]**2
    sqrtcomp=roots[r]**2*roots[t]**2
    quartpair=roots[i]*roots[k]
    quartcomp=roots[r]*roots[t]
    q_sos=G*((roots[i]**2-roots[k]**2)**2+(roots[r]**2-roots[t]**2)**2+2*(quartpair-quartcomp)**2)
    l_sos=((Av[i]-Av[k])**2+(Av[r]-Av[t])**2
        +2*(sqrtpair-G)**2+2*(sqrtcomp-G)**2+4*G*(quartpair-quartcomp)**2)
    checks[f'Q_sos_partition_{j+1}']=s.cancel(Qv-q_sos)==0
    checks[f'L_strict_roots_partition_{j+1}']=s.cancel(L-l_sos)==0
assert all(checks.values()),checks
out=Path(__file__).with_name('check_toric_contact_lift.json')
out.write_text(json.dumps({'status':'PASS','scope':'generic exact algebraic identities; hypotheses require source-specific audit','checks':checks},indent=2)+'\n')
print(json.dumps({'status':'PASS','exact_checks':len(checks)},sort_keys=True))
