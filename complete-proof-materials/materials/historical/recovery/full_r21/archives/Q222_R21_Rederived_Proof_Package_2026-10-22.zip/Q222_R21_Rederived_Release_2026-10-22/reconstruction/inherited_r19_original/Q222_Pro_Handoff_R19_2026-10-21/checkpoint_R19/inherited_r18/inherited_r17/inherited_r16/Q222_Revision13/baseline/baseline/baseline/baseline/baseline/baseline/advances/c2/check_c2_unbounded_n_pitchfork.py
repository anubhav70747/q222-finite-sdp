"""Focused exact checks for the n-unbounded C2 pitchfork; no external packages."""
if not __debug__:
    raise SystemExit("Run without -O: assertions are proof checks.")

from fractions import Fraction as Q
from pathlib import Path
from itertools import permutations
import json
import time

started = time.perf_counter()
checks = []

class P:
    def __init__(self, terms, n):
        self.p = {m:c for m,c in terms.items() if c}
        self.n = n
    def lift(self, q):
        if isinstance(q, P):
            assert q.n == self.n
            return q
        return P({(0,)*self.n:q},self.n)
    def __add__(self, q):
        q=self.lift(q); out=dict(self.p)
        for m,c in q.p.items():out[m]=out.get(m,0)+c
        return P(out,self.n)
    __radd__=__add__
    def __neg__(self):return P({m:-c for m,c in self.p.items()},self.n)
    def __sub__(self,q):return self+-self.lift(q)
    def __rsub__(self,q):return self.lift(q)+-self
    def __mul__(self,q):
        q=self.lift(q);out={}
        for m,c in self.p.items():
            for r,d in q.p.items():
                t=tuple(x+y for x,y in zip(m,r));out[t]=out.get(t,0)+c*d
        return P(out,self.n)
    __rmul__=__mul__
    def __pow__(self,e):
        assert isinstance(e,int) and e>=0
        out=self.lift(1);p=self
        while e:
            if e&1:out=out*p
            p=p*p;e//=2
        return out
    def diff(self,i):
        out={}
        for m,c in self.p.items():
            if m[i]:
                r=list(m);r[i]-=1;out[tuple(r)]=c*m[i]
        return P(out,self.n)
    def sub(self, replacements):
        vs=variables(self.n);vs=[self.lift(replacements.get(i,p)) for i,p in enumerate(vs)]
        powers=[{0:self.lift(1)} for _ in vs]
        out=self.lift(0)
        for m,c in self.p.items():
            term=self.lift(c)
            for i,e in enumerate(m):
                if e not in powers[i]:powers[i][e]=vs[i]**e
                term=term*powers[i][e]
            out=out+term
        return out

def variables(n):
    return [P({tuple(int(i==j) for i in range(n)):1},n) for j in range(n)]
def zero(name,p):
    assert not p.p,(name,len(p.p))
    checks.append(name)
def determinant(A):
    n=len(A);out=A[0][0].lift(0)
    for perm in permutations(range(n)):
        sign=(-1)**sum(perm[i]>perm[j] for i in range(n) for j in range(i+1,n))
        term=A[0][0].lift(sign)
        for i,j in enumerate(perm):term=term*A[i][j]
        out=out+term
    return out

def coefficient(poly,i,e):
    out={}
    for mon,c in poly.p.items():
        if mon[i]==e:
            r=list(mon);r[i]=0;out[tuple(r)]=c
    return P(out,poly.n)

def allocate(name,poly,roots,small):
    mons=[]
    for root in roots:
        assert len(root.p)==1
        (mon,c),=root.p.items();assert c==1
        mons.append(mon)
    pairs=[tuple(a+b for a,b in zip(r,s)) for i,r in enumerate(mons) for s in mons[i:]]
    for mon,c in poly.p.items():
        assert any(all(x>=y for x,y in zip(mon,pair)) and
                   (not small or any(mon[i]>pair[i] for i in small))
                   for pair in pairs),(name,mon,c)
    checks.append(name)



d,n,m,c,A,D,al,u,v,W,X,Y,Z,x,y,z,mu,p,q=variables(19)
ui,vi,wi,xi,yi,zi,ni,pi,qi=7,8,9,10,11,12,1,17,18
Du=1+u*u;Dv=1+v*v
R2=v*W-X+u*v*Y-u*Z;R5=u*W+u*v*X-Y-v*Z
Rc=u*W-Y;Ra=v*Y-Z;Rb=X+u*Z
core=2*(R5**2+Du*Ra**2+Dv*Rb**2-Du*Dv*Z**2)
F=d*core+4*n*Du*Dv*X**2+4*m*R2**2+4*c*Dv*Rc**2+4*A*Du*Dv*Y**2+4*D*R5**2+4*al*Du*Ra**2
sub={wi:1,xi:x*u*u,yi:y*u,zi:z*u}
G=F.sub(sub)
FX=F.diff(xi).sub(sub);FY=F.diff(yi).sub(sub);FZ=F.diff(zi).sub(sub)

def degrees(name,poly,index,minimum,parity):
    assert all(mon[index]>=minimum and mon[index]%2==parity for mon in poly.p),name
    checks.append(name)

degrees('entire scalar =4mv2+u2 H(u2,v)',G-4*m*v*v,ui,2,0)
degrees('entire X normal =-8mv+u2 L_X(u2,v)',FX+8*m*v,ui,2,0)
degrees('entire Y normal =u L_Y(u2,v)',FY,ui,1,1)
degrees('entire Z normal =u L_Z(u2,v)',FZ,ui,1,1)
zero('entire n scalar contribution',G-G.sub({ni:0})-4*n*x*x*u**4*Du*Dv)
zero('entire n X-normal contribution',FX-FX.sub({ni:0})-8*n*x*u*u*Du*Dv)
zero('n has no Y-normal contribution',FY-FY.sub({ni:0}))
zero('n has no Z-normal contribution',FZ-FZ.sub({ni:0}))
zero('entire n quadratic state block',F.diff(xi).diff(xi)-F.diff(xi).diff(xi).sub({ni:0})-8*n*Du*Dv)
# The complete outer remainder has no W monomial without its u factor.
outer=F.sub({ni:0,2:0})
assert all(mon[ui]>=mon[wi] for mon in outer.p)
checks.append('entire outer remainder quadratic in X,Y,Z,uW')

def reciprocal(poly,index,newindex):
    terms={}
    for mon,coef in poly.p.items():
        assert mon[index]<=2
        r=list(mon);r[newindex]+=2-r[index];r[index]=0
        terms[tuple(r)]=terms.get(tuple(r),0)+coef
    return P(terms,poly.n)
outer_bob=reciprocal(outer,vi,qi)
assert all(mon[ui]>=mon[wi] for mon in outer_bob.p)
checks.append('entire reciprocal-Bob outer remainder quadratic in X,Y,Z,uW')
cap=F.sub({0:1,1:0,2:0,3:mu,4:mu,5:mu,6:mu})
inf0=reciprocal(cap,ui,pi)
infinf=reciprocal(inf0,vi,qi)
zero('infinity-zero cap state form',inf0.sub({pi:0,vi:0})-((2+8*mu)*W*W+4*mu*Y*Y+(2+4*mu)*Z*Z))
zero('infinity-infinity cap state form',infinf.sub({pi:0,qi:0})-(4*mu*W*W+(2+4*mu)*X*X+(2+8*mu)*Y*Y))

def quadratic(poly,indices):
    assert all(sum(mon[i] for i in indices)>=2 for mon in poly.p)
    return P({mon:a for mon,a in poly.p.items() if sum(mon[i] for i in indices)==2},poly.n)
q10=(2+4*mu)*(W+v)**2+2*(Z+p)**2+4*mu*(W*W+Y*Y+Z*Z)
q11=2*X*X+(2+4*mu)*(Y-q)**2+4*mu*(W*W+Y*Y+(X-p)**2)
zero('CN10 entire homogeneous quadratic part',quadratic(inf0.sub({xi:1}),[pi,vi,wi,yi,zi])-q10)
zero('CN11 entire homogeneous quadratic part',quadratic(infinf.sub({zi:1}),[pi,qi,wi,xi,yi])-q11)
# The real boundary Schur expression, computed without n.
lead=quadratic(G.sub({2:0}),[ui]) # coefficient degree two in u; graph x appears only higher
lead=coefficient(lead,ui,2)
b11=(4*(c+A)+2*d)*Dv+4*D+4*al*v*v
b22=4*D*v*v+4*al
b12=4*v*(D-al)
ell1=-4*c*Dv-(4*D+2*d);ell2=-(4*D+2*d)*v
cc=4*c*Dv+4*D+2*d
zero('complete boundary quadratic in y,z',lead-(b11*y*y+2*b12*y*z+b22*z*z+2*ell1*y+2*ell2*z+cc))
detB=b11*b22-b12*b12
num=detB*cc-(b22*ell1*ell1-2*b12*ell1*ell2+b11*ell2*ell2)
Q10=4*al*A*(d+2*(c+D));Q12=4*c*D*(d+2*(al+A))
H0=coefficient(num,vi,2)*Q(1,8)-Q10
zero('CN8 exact boundary Schur numerator',num-8*Dv*(Q10+H0*v*v+Q12*v**4))
zero('Bob sign identity',F.sub({vi:-v,xi:-X,zi:-Z})-F)
report={'status':'PASS','checks':checks,'count':len(checks),'arithmetic':'standard-library exact rational polynomial arithmetic','scope':'full scalar and first-normal structure, whole outer quadratic-root allocation, two exact cap corner forms, boundary Schur identity; no atlas replay','seconds':round(time.perf_counter()-started,4)}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
