"""Reconstruct UZ4--UZ6 from the seven short native source coquotients.

No source expansion or membership result is read. Standard library only.
"""
from arithmetic import add, subtract, multiply, power, add_into, rational

class Poly:
    def __init__(self, terms, dimension):
        self.terms=terms;self.dimension=dimension
    def lift(self,value):
        if isinstance(value,Poly):
            assert value.dimension==self.dimension
            return value
        return Poly({(0,)*self.dimension:value} if value else {},self.dimension)
    def __add__(self,other):
        return Poly(add(self.terms,self.lift(other).terms),self.dimension)
    __radd__=__add__
    def __neg__(self):return Poly({m:-c for m,c in self.terms.items()},self.dimension)
    def __sub__(self,other):return self+-self.lift(other)
    def __rsub__(self,other):return self.lift(other)+-self
    def __mul__(self,other):
        return Poly(multiply(self.terms,self.lift(other).terms),self.dimension)
    __rmul__=__mul__
    def __pow__(self,n):return Poly(power(self.terms,n),self.dimension)

def variables(n):
    return [Poly({tuple(int(i==j) for i in range(n)):1},n) for j in range(n)]

def native_coquotients():
    k,f,g,a,t=variables(5)
    K,eta,zeta=k*k,f*f,g*g
    Vc=K*eta*zeta
    Lc,Hc,Qc=1-a*eta,1+(1-a)*eta,1-K*zeta+a*Vc
    P4=1+K+eta*K*(a-K-1)-zeta*K*t+Vc*(-zeta*K*t*t+2*K*t+a*(1-t)+t)
    Pa=1+K-a*eta*K+zeta*((1+K)-(2+K)*t)+Vc*(-zeta*t*t+a*(t-1)+t)
    Pd=(1+K)**2-a*eta*K*K+zeta*K*((K+1)-(K+2)*t)
    Pd+=Vc*(-zeta*K*t*t+K*a*(t-1)+K*t+K+1)
    return {'C2':2*(1+K)*(1-t*zeta)*Lc*(1+Vc)*Hc*Qc,
            'Cb':2*(1+K)*Lc*(1+(1-t)*zeta)*Hc*Qc,
            'C3':2*(1+K)*Lc*Hc*Qc*(1-K*eta+t*Vc),
            'C5':2*(1+K)*Lc*Hc*Qc*(1+Vc),
            'C4':2*Qc*P4,'Ca':2*Lc*Hc*Pa,'Cd':4*Lc*Qc*Pd}

def reconstruct_source():
    delta,k,b,a,t,u,w,v=variables(8)
    K=1+k*k;Q=K+a*k*k*b*b;Tn=K*K-t*delta**2*k**4*Q*b*b
    D,Dv=1+u*u,1+v*v
    clear=K**6*Q**4*Tn
    native=native_coquotients();co={}
    powers={diff:(K**(2+diff)*Q**(3-diff)).terms for diff in range(-2,4)}
    for name,poly in native.items():
        answer={}
        for m,c in poly.terms.items():
            j,fr,gs,ap,tp=m
            assert fr%2==0 and gs%2==0
            r,s=fr//2,gs//2
            assert -2<=r-s<=3
            shift=(2*s,j+2*s,2*(r+s),ap,tp,0,0,0)
            add_into(answer,powers[r-s],shift,c)
        co[name]=Poly(answer,8)
    C2,Cb,C3,C5,C4,Ca,Cd=(co[name] for name in ('C2','Cb','C3','C5','C4','Ca','Cd'))
    Vn=K*K-t*Q*u*v*w
    Yn=K*Tn*u*w-a*v*Vn
    B0=v*Yn-K*Tn
    Ac=C5*Tn+a*K*(C3*Dv-C5)
    F=4*K*Q*Tn*Tn*(C2*(K*K-t*Q)+Cb*Dv*t*Q)*D*D*v*v*w*w
    F+=4*delta*delta*Q*Q*Ac*D*D*v*v*Vn*Vn
    F+=4*delta*delta*K**3*b**4*C4*D*Dv*Yn*Yn
    F+=4*delta**4*K*Q*Q*k**6*b**4*Ca*D*B0*B0
    F+=2*delta*delta*K*K*Q*b*b*Cd*D*(B0*B0-Dv*K*K*Tn*Tn)
    Sn=8*delta*delta*K*K*b**4*C4*Dv*Yn
    Sn+=8*delta**4*Q*Q*k**6*b**4*Ca*v*B0
    Sn+=4*delta*delta*K*Q*b*b*Cd*v*B0
    L1=8*K**3*Q*Tn*Tn*(Cb*Dv-C2)*D*v*w
    L1-=8*delta*delta*K*K*Q*Q*u*D*v*v*Vn*Ac
    L1+=K**3*a*u*v*Sn
    numerator=8*delta*delta*K*K*Q*Q*Tn*D*v*Vn*(C3*Dv-C5)-K*K*Tn*Sn
    assert all(m[0]>=2 for m in numerator.terms)
    L2={(m[0]-1,)+m[1:]:c for m,c in numerator.terms.items()}
    P=D*(w*w+delta*delta)*v*v+delta*delta*K*b**4*u*u*w*w
    P+=delta**4*K*k**6*b**4-2*delta*delta*K*K*b*b*u*w*v
    leading_part=8*K*K*D*clear*P
    return {'scalar_terms':F.terms,'linears_terms':[L1.terms,L2],
            'clear_terms':clear.terms,'leading_terms':leading_part.terms,
            'coquotient_term_counts':{name:len(poly.terms) for name,poly in co.items()}}

def assert_source_equal(component):
    rebuilt=reconstruct_source()
    def raw_rows(items):return {tuple(m):rational(c) for m,c in items}
    for key in ('scalar_terms','clear_terms','leading_terms'):
        assert rebuilt[key]==raw_rows(component[key]),('source formula mismatch',key)
    for i in range(2):
        assert rebuilt['linears_terms'][i]==raw_rows(component['linears_terms'][i]),('normal formula mismatch',i)
    return {'whole_scalar_terms':len(rebuilt['scalar_terms']),
            'whole_first_normal_terms':[len(x) for x in rebuilt['linears_terms']],
            'coquotient_term_counts':rebuilt['coquotient_term_counts']}
