"""Exact HP scalar circuit, quadratic domination and entire SP6 reassembly."""
import json
from pathlib import Path
import sympy as s

checks={}
def ck(name,e):
    assert s.cancel(e)==0,(name,s.factor(e))
    checks[name]=True
    print('PASS '+name,flush=True)

u,w,W,Z,k,sg,q,r,srho=s.symbols('u w W Z k sigma q r sqrt_rho',positive=True)
x=k*k; z=q*q; rho=srho*srho; lam=rho*sg/x
U=u*u; Gam=sg*Z-u*w*W; R=w*Z/q-u*q*W
A=q*(U-x)*W; Pb=u*Z-x*w*W/sg
packet=lam*sg*Pb**2+rho*(U-x)*(w*w-sg*z)*W**2
aa=srho*sg*u*Z/k; bb=srho*u*w*W; cc=srho*k*sg*q*W/s.sqrt(sg)
# c^2=lambda*z*x^2*W^2; c itself need not be expanded below.
aa2=lam*sg*U*Z*Z; bb2=rho*U*w*w*W*W; cc2=lam*z*x*x*W*W
K=lam*x*z*U*W*W
Zr=r**3*z*u*W/w
ck('HP3 cube-root monomial identification',(aa2*bb2*cc2-(K*r*r)**3).subs(Z,Zr))
circuit=aa2+bb2+cc2-3*K*r*r+K*r*r*(r-1)**2*(r*r+2*r+3)
ck('HP3 exact complete signed scalar circuit',(packet+lam*x*R*R-circuit).subs(Z,Zr))
a,b,c,g2=s.symbols('a b c g_squared')
ck('HP4 exact difference-pivot refinement',a*a+b*b+c*c-3*g2-
   ((a-b)**2+(b-c)**2+(c-a)**2)/2-(a*b+b*c+c*a-3*g2))
al,be,ga=s.symbols('alpha beta gamma')
ck('HP5 exact product AMGM SOS',al**3+be**3+ga**3-3*al*be*ga-
   (al+be+ga)*((al-be)**2+(be-ga)**2+(ga-al)**2)/2)

D1=(aa-bb)/s.sqrt(2); delta=w/q; T=q*u*(u-k)*W
ck('HP6 exact first Gamma conductor',u*Gam-s.sqrt(2)*k*D1/srho+delta*T)
ck('HP7 exact angular domination',A*A-T*T-q*q*(u-k)**2*W*W*(k*k+2*u*k))
f=W/Z
qwGam=q*z*f*u*Gam+z*(sg-u*w*f)*R
ck('HP10 exact second Gamma conductor',q*w*Gam-qwGam)

Nx,Ny,D,mu,H,nu,chi,Hy,Kr,Rg,b,p,Rx,Ry,cN,Bx,Ay,tC=s.symbols(
    'Nx Ny D mu H nu chi Hy Kr Rgamma b p Rx Ry cN Bx Ay tC')
hh=s.symbols('h'); KA=4*mu-lam; Xe=Nx-hh*Pb
dd=4*D/sg**2; Hx=s.symbols('Hx')
common=Hx*Nx*Nx+Hy*Ny*Ny+Kr*R*R+2*(2*D+1)*U*Xe*Xe
common+=(dd+4*b*p*z*U)*Gam*Gam
basic=-4*u*q*w*(s.symbols('twomplus2Dplus1'))*Nx*Ny
basic+=u*q*w*Rx*Nx*R+(cN+z*Ry)*Ny*R+q*w*Bx*Nx*A+u*Ay*Ny*A
old=common+basic-4*nu*Nx*u*Gam+Rg*(Ny+b*R)*q*w*Gam
old+=4*mu*A*A+lam*u*(Gam*Pb+A*R)+chi*u*A*R
old-=8*tC*(Ny+b*R)*(z*sg*R-q*w*Gam)
UG=s.sqrt(2)*k*D1/srho-delta*T
WG=q*z*f*UG+z*(sg-u*w*f)*R
new=common+basic-4*nu*Nx*UG+Rg*(Ny+b*R)*WG+chi*u*A*R
new+=(KA-delta)*A*A+delta*T*T+delta*(A*A-T*T)
new+=(packet+lam*x*R*R)-lam*x*R*R
new-=8*tC*(Ny+b*R)*(z*sg*R-WG)
ck('HP full original SP6 plus complete centered C correction',old-new)

payload={'status':'PASS','count':len(checks),'checks':checks,
 'scope':'C14.2 bounded H and positive lambda: bounded-state missing-Gamma conductor; combined with HG and d0-unit argument yields all states',
 'remaining':'lambda nonpositive and unbounded-H source cases are not proved by this file',
 'dependencies':['Exact SP6/BS2/LC3 parent','HG source sphere and radial frame','separated bounded-Gram lemma','original core sign/axis exits'],
 'review_boundary':'New exact algebra only; analytical proof accepted in REVIEW_R19.txt; not formal or external verification'}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
