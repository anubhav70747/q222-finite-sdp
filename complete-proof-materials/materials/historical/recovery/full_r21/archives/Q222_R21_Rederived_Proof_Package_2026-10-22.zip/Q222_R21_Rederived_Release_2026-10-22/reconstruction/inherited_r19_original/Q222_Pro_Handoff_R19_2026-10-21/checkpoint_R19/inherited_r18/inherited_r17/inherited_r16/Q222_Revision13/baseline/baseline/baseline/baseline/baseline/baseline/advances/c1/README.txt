C1 ordinary actual Alice angle: arbitrary positive state ratio
=============================================================

Main result: arbitrary_state_ratio.tex proves the complete all-tests
tensor-SOS assertion for the unchanged native C1 source with k a positive
bounded unit, f,g positive infinitesimals, and arbitrary positive
a,t,M,J satisfying the exact source relations. The ratio s=g/f may be
infinitesimal, a bounded unit, or unbounded. Original event coefficients
may be unbounded; no opening is capped in the source.

The module is cumulative: it explicitly uses the retained native source
definitions, full-parent packet identities, universal contact-conductor
lemma, strict bounded-Gram lemma, and previous unit-s arbitrary-opening
theorem. It does not replace source-entry/sign/minor proof dependencies
with a computational status. Its reflection is checked on the complete
nine-channel homogeneous parent, including the signed core.

New analytical mechanism
-----------------------
1. Exact C1 reflection replaces unbounded s by infinitesimal s while
   preserving infinitesimal f,g, unit k, and every positive shape gap.
2. The two-current identity handles Bob away from zero. The same
   critical-current identity handles Alice infinity because its last
   diagonal residue is 4 gamma > 0, with gamma residue 1/(4 K^3).
3. The unit-w chart is the existing five-current argument with
   Q=(1+u^2)w a pure testing unit; small u is unnecessary there.
4. The remaining Z=1 chart uses the same universal polynomial conductor
   with weights (delta,k,b,a,t,u,w,v)=(1,0,1,0,0,0,1,3).
   Every soft root has weight4. The five-term scalar gives target weights
   at least10,8,6 and therefore coefficient weights at least2,4,2.
   Thus k and u may have nonzero residue. Retain g4^2 as a positive square.
   Both full hard normals remain present.

Exact checks executed
---------------------
  python check_dispatch.py
      PASS, 26 checks, 0.0024 seconds on the execution used for this note.
      Report: dispatch_checks.json.

  python check_analytical_lift.py
      PASS, 33 checks, 9.94 seconds on the execution used for this note.
      Report: unit_k_conductor_checks.json.
      Target weights: E0=10, L1=8, L2=6.
      Constructed polynomial coefficient weights: E0=2, L1=4, L2=2.

The second checker reconstructs the entire scalar and both first normals
from the seven short source polynomials. It multiplies back the same
monic conductor construction, with no Groebner basis and no stored witness.
It does perform polynomial expansions for confirmation; the proof's weight
argument is given directly on the five factored channels in the TeX.
Both checkers reject Python -O. They use Python's standard library only.
The local files arithmetic.py and source_from_formulas.py are copied,
unchanged algebra helpers; all imports resolve inside this directory.

Precise scope advance
---------------------
Joining this result to the complete small-k theorem closes every source
with eta,zeta both infinitesimal after the inherited orientation 0<k<=1.
The remaining native complement is:
  (i) k small,zeta small,eta a unit or unbounded;
  (ii) k small,zeta non-infinitesimal;
  (iii) k a unit, at least one of eta,zeta non-infinitesimal.
Every row is still intersected with physicality and the complement of all
other inherited admissions and symmetry images. These are not claims that
each row is nonempty or wholly open. No whole-global proof is asserted.
