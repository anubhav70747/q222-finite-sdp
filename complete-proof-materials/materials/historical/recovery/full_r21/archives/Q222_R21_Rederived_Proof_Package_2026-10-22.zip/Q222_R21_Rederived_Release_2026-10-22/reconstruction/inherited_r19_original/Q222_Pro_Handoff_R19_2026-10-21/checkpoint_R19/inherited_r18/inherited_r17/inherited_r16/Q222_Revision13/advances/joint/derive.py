import sympy as s
import json
from pathlib import Path

out=Path(__file__).parent
p,v,u=s.symbols('p v u', real=True)
W,X,Y,Z=s.symbols('W X Y Z')
A,C,D,m,alpha,n=s.symbols('A C D m alpha n')
Du,Dv,Dp=1+u*u,1+v*v,1+p*p
F=4*n*Du*Dv*X**2+4*m*(v*W-X+u*v*Y-u*Z)**2+4*C*Dv*(u*W-Y)**2+4*A*Du*Dv*Y**2+(4*D+2)*(u*W+u*v*X-Y-v*Z)**2+(4*alpha+2)*Du*(v*Y-Z)**2+2*Dv*(X+u*Z)**2-2*Du*Dv*Z**2
w,xi,eta,zeta=s.symbols('w xi eta zeta')
coefs={
 '10':A*eta**2+(m+alpha+s.Rational(1,2))*(eta-zeta)**2,
 '1m1':A*eta**2,
 '01':D*(xi-zeta)**2+(n+s.Rational(1,2))*xi**2,
 '0m1':(C+D+s.Rational(1,2))*(w-eta)**2+A*eta**2,
 'm11':(n+s.Rational(1,2))*xi**2,
 'm10':m*(w-xi)**2+(n+s.Rational(1,2))*xi**2,
 '00':n*xi**2+2*m*(w-xi)*(eta-zeta)+C*(w-eta)**2+A*eta**2+(2*D+1)*(w-eta)*(xi-zeta)+(alpha+s.Rational(1,2))*(eta-zeta)**2+xi*zeta-zeta**2/s.Integer(2)
}
laurent=u*u*coefs['10']+u*u/v**2*coefs['1m1']+v*v*coefs['01']+coefs['0m1']/v**2+v*v/u**2*coefs['m11']+coefs['m10']/u**2+coefs['00']
parity=s.expand(F.subs({W:w,X:v*xi,Y:u*eta,Z:u*v*zeta})-4*u*u*v*v*laurent)
assert parity==0, parity

a0,b0,S=s.symbols('a0 b0 S')
state={W:p*Y+a0,Z:v*Y-b0,X:S+v*a0+p*v*Y-p*b0}
J=W+v*X-p*Y-p*v*Z
M=p*v*W-p*X+v*Y-Z
assert s.expand(J.subs(state)-(Dv*a0+v*S))==0
assert s.expand(M.subs(state)-(Dp*b0-p*S))==0
core=2*J**2+2*Dp*(v*Y-Z)**2+2*Dv*(p*X+Z)**2-2*Dp*Dv*Z**2
newcore=s.Poly(s.expand(core.subs(state)),a0,b0,S,Y)
core_terms={str(mon):str(s.factor(c)) for mon,c in newcore.terms()}
payload={'parity_matrix_identity':True,'common_state_pair_identities':True,'core_terms_a0_b0_S_Y':core_terms}
(out/'derive.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps(payload,indent=2))
