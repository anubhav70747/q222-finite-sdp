#!/usr/bin/env python3
"""Literal original C1 parent: exact source-only finite moving frame, full Gram."""
import json
from pathlib import Path
import sympy as s
HERE=Path(__file__).resolve().parent
u,v,x,y=s.symbols('u v x y')
du,dv=1+u*u,1+v*v
d,m,c,A,D,al,be=map(s.Rational,['437/30','3/11','2','244/15','79/780','351/20','823/60'])
packets=[([v,-1,u*v,-u],4*m),([u,0,-1,0],4*c*dv),([0,0,1,0],4*A*du*dv),
 ([u,u*v,-1,-v],4*D+2*d),([0,0,v,-1],(4*al+2*d)*du),
 ([0,1,0,u],(4*be+2*d)*dv),([0,0,0,1],-2*d*du*dv)]
P=s.zeros(4)
for row,coef in packets:
    rr=s.Matrix(row);P+=coef*rr*rr.T
P=P.applyfunc(s.expand)
ct={u:s.Rational(1,2),v:s.Integer(2)}
P0=P.subs(ct);E=s.eye(4)[:,:3];Q0=P0[:3,:3]
h=s.Matrix([*(Q0.inv()*(-P0[:3,3])),1])
assert h==s.Matrix([2,-s.Rational(3,8),s.Rational(1,4),1])
assert P0*h==s.zeros(4,1)
assert all(Q0[:i,:i].det()>0 for i in range(1,4))
trans=[]
for t in (u,v):
    grad=P.diff(t).subs(ct)*h
    assert (h.T*grad)[0]==0
    k=s.Matrix([*(-Q0.inv()*grad[:3,0]),0])
    assert P0*k==-grad
    trans.append(k)
vdelta=h+trans[0]*x+trans[1]*y
Pdelta=P.subs({u:ct[u]+x,v:ct[v]+y})
AA=(E.T*Pdelta*E).applyfunc(s.expand)
bb=(E.T*Pdelta*vdelta).applyfunc(s.expand)
ff=s.expand((vdelta.T*Pdelta*vdelta)[0])
GG=s.zeros(5);GG[:3,:3]=AA
for i in range(3):
    for (aa,b0),coef in s.Poly(bb[i],x,y).terms():
        assert aa+b0>=2
        if aa: jj,term=3,coef*x**(aa-1)*y**b0
        else: jj,term=4,coef*y**(b0-1)
        GG[i,jj]+=term;GG[jj,i]+=term
for (aa,b0),coef in s.Poly(ff,x,y).terms():
    assert aa+b0>=2
    if aa>=2:GG[3,3]+=coef*x**(aa-2)*y**b0
    elif aa==1:
        term=coef*y**(b0-1)/2;GG[3,4]+=term;GG[4,3]+=term
    else:GG[4,4]+=coef*y**(b0-2)
GG=GG.applyfunc(s.expand)
w1,w2,w3,z=s.symbols('w1 w2 w3 z')
w=s.Matrix([w1,w2,w3]);psi=E*w+vdelta*z;xi=s.Matrix([w1,w2,w3,x*z,y*z])
assert s.expand((psi.T*Pdelta*psi)[0]-(xi.T*GG*xi)[0])==0
G0=GG.subs({x:0,y:0});CC=G0[3:,3:]
assert G0[:3,:3]==Q0 and G0[:3,3:]==s.zeros(3,2)
assert CC[0,0]>0 and CC.det()>0
assert max(s.Poly(a,x,y).total_degree()for a in GG)<=4
def mat(M):return [[str(z)for z in M.row(i)]for i in range(M.rows)]
out={'status':'PASS','scope':'Exact full original parent, source-only inverse, determinant-one state transport, entire five-feature Gram, positive hard and both angle residue blocks',
 'h':list(map(str,h)),'transport':[list(map(str,k))for k in trans],
 'hard_Q0':mat(Q0),'hard_sylvester_minors':[str(Q0[:i,:i].det())for i in range(1,4)],
 'curvature_C':mat(CC),'curvature_sylvester_minors':[str(CC[0,0]),str(CC.det())],
 'full_polynomial_identity_verified':True,'mixed_inversions':0,
 'max_gram_total_degree':max(s.Poly(a,x,y).total_degree()for a in GG),
 'gram_nonzero_terms':sum(len(s.Poly(a,x,y).terms())for a in GG if a!=0)}
(HERE/'ORIGINAL_MOVING_FRAME_CHECKS.json').write_text(json.dumps(out,indent=2)+'\n')
(HERE/'ORIGINAL_MOVING_FRAME_GRAM.json').write_text(json.dumps({'variables':['x','y'],'features':['w1','w2','w3','xz','yz'],
 'Q':[[[[list(exp),str(coef)]for exp,coef in s.Poly(GG[i,j],x,y).terms()]for j in range(5)]for i in range(5)]},indent=2)+'\n')
print(json.dumps(out,indent=2))
