"""New exact identities only. Does not rerun inherited suites or claim closure."""
import json
from pathlib import Path
import sympy as s
u,v,k,c,eta,r,h,C,A,Dp,al,m,Bx,E,nu,xi=s.symbols('u v k c eta r h C A Dp alpha m Bx E nu xi', nonzero=True)
x=k*k; a=eta*c*c; y=x/c**2; U=u*u;V=v*v
q=al+(m+Bx)*(1-h)**2;mu=m-a*a*q;lam=mu/(eta*a*x)
T0=A+al+s.Rational(1,2);Tm=T0+m
e4=r*r*Tm/eta**2
cF=(r*r*T0+C*(1-r)**2+2*m*r)/eta**2
dY=(r*T0-C*(1-r)+m)/eta
b=A*r/eta-(m*(1-h)+al+s.Rational(1,2))
P=(1-r)*E/eta-nu;Qt=r*E/eta+nu
F=V-y;Fb=F+v*E;Ft=Fb+eta/r*v*nu
RD=v*(U-x);TD=RD-u*v*xi/h
J=u*v-x/c;p=c*k*v/u;d=c*k*V/u-k*v;Rc=p*E+d
Hu=c*c*V/u-u;H=Hu+c*c*v/u*E;Hq=H-a*xi
kap=2*(Bx*(1-h)-Dp*(eta*(1+x*h)+r-1)/eta-m*r/eta)
AE=-2*h*Dp*(1-r)/eta+2*r*b/eta;AY=2*(h*Dp+b)
CE=2*e4;CY=2*r*Tm/eta;BE=2*cF;BY=2*dY
checks={}
def ck(name,e):
 z=s.cancel(e)
 assert z==0,(name,s.factor(z))
 checks[name]=True
low=cF*F**2+2*cF*v*F*E+2*dY*v*F*nu+V*(C*P**2+T0*Qt**2+2*m*E*Qt/eta)
low_new=cF*Fb**2+2*dY*v*Fb*nu+(C+T0)*V*nu**2
ck('entire_low_radial_with_all_m_crosses',low-low_new)
high=e4*x*F**2+e4*v*RD*F+(CE*V*RD+CE*x*v*F)*E+(CY*V*RD+CY*x*v*F)*nu+Tm*U*V*Qt**2
high_new=e4*U*Ft**2+e4*x*Fb*Ft-e4*y*u*H*Ft+e4*y*eta/r*Qt*RD
ck('entire_high_radial_with_all_nu_terms',high-high_new)
ck('full_R_D_angular_conductor',RD-(u*J+k*Rc-x/c*H))
ck('full_D_state_conductor',u*v*xi-h*(u*J+k*Rc-x/c*H-TD))
delta=e4*y*eta/r;bp=b+delta/2;g=bp/h-m
source=C*P**2+A*Qt**2+Dp*(P+u*v*xi)**2+(AE*E+AY*nu)*RD+Dp*h*h*RD**2-2*h*Dp*u*v*RD*xi+delta*Qt*RD-2*m*u*v*Qt*xi
source_new=C*P**2+A*Qt**2+Dp*(P-h*TD)**2+2*bp*Qt*TD+2*g*u*v*Qt*xi
ck('full_D_source_and_m_cross_shift',source-source_new)
ck('bare_radial_xi_exact_dependency',kap*u*F*xi+2*g*u*v*Qt*xi-(kap*u*Fb*xi+(2*g*Qt-kap*E)*u*v*xi))
gamma=2*bp/h+2*Dp*(eta*(1+x*h)+r-1)/r-2*eta*Bx*(1-h)/r
ck('fullY_radial_xi_exact_dependency',kap*u*F*xi+2*g*u*v*Qt*xi-(kap*u*Ft*xi+gamma*u*v*Qt*xi))
L=(u*v)**2+(c*k*V/u)**2+(x/c)**2-3*(k*v)**2
hard=C*P**2+A*Qt**2+Dp*(P+u*v*xi)**2+Bx*xi**2+A*U*Qt**2+C*V*P**2+T0*V*Qt**2+Tm*U*V*Qt**2+2*m*V*E*Qt/eta-2*m*u*v*Qt*xi+Bx*V*xi**2
LE=2*lam*(p+k)*d+(AE+CE*V)*RD+(BE+CE*x)*v*F
LY=(AY+CY*V)*RD+(BY+CY*x)*v*F
LX=-2*eta*lam*c*k*d+(2*eta*lam*c-2*h*Dp*u*v)*RD-2*eta*lam*c*u*J+kap*u*F
centered=q*Hq**2+mu*(v/(eta*u)*E-xi)**2+hard+(cF+e4*x)*F**2+lam*L+Dp*h*h*RD**2+e4*v*RD*F+LE*E+LY*nu+LX*xi
master=q*Hq**2-2*eta*lam*x*Hq*xi+(Bx-mu)*xi**2+lam*J**2+2*lam*k/p*Rc**2+lam*(Rc-k*E)**2-lam*x*E**2+C*P**2+A*Qt**2+Dp*(P-h*TD)**2+2*bp*Qt*TD+low_new+e4*U*Ft**2+e4*x*Fb*Ft-e4*y*u*H*Ft+A*U*Qt**2+Bx*V*xi**2+kap*u*Fb*xi+(2*g*Qt-kap*E)*u*v*xi
ck('entire_centered_full_parent_master_identity',centered-master)
# Independent reconstruction from the original parent. The remaining source
# identities are exactly the inherited value and four first contact equations.
W=(v+E)/(eta*u);Y=r*(v+E)/eta+nu;X=xi-h*u
M=v*W-X+u*v*Y-u;Drow=u*W-Y+u*v*X-v
raw=m*M**2+C*(1+V)*(u*W-Y)**2+A*(1+U)*(1+V)*Y**2+Dp*Drow**2+(al+s.Rational(1,2))*(1+U)*(v*Y-1)**2+Bx*(1+V)*(X+u)**2-(1+U)*(1+V)/2
rr=s.Poly(s.cancel(raw-centered),E,nu,xi)
for mon,co in rr.terms():
 if sum(mon)==2:
  ck('raw_parent_hard_'+str(mon),co)
for name,var,div in [('E',E,v),('nu',nu,v),('xi',xi,u)]:
 residual=s.cancel(rr.coeff_monomial(var)/div)
 ck('raw_'+name+'_normal_only_contact_constant_u',s.diff(residual,u))
 ck('raw_'+name+'_normal_only_contact_constant_v',s.diff(residual,v))
scalar=s.Poly(s.cancel(rr.coeff_monomial(1)),u,v)
assert set(scalar.monoms()) <= {(0,0),(0,2),(2,2)},scalar.terms()
checks['raw_scalar_residual_determined_by_three_contact_jets']=True
# A scalar with this support vanishes if its value and two first jets do.
ss=scalar.as_expr();jet0=ss.subs({u:k,v:k/c});jetU=(s.diff(ss,u)/(2*u)).subs({u:k,v:k/c});jetV=(s.diff(ss,v)/(2*v)).subs({u:k,v:k/c})
ck('raw_scalar_contact_jet_reconstruction',ss-(jet0+jetU*(U-x)+jetV*(V-y)+jetU/y*(U-x)*(V-y)))
# Check source completion after exact full-D shift, without changing contact roots.
Hs=C+A+Dp
normal=P-A/Hs*E/eta-(h*Dp+bp)/Hs*TD
schE=A*(C+Dp)/Hs
schT=h*h*Dp-(h*Dp+bp)**2/Hs
schET=bp-A*(h*Dp+bp)/Hs
ck('exact_source_schur_on_E_and_T',C*P**2+A*Qt**2+Dp*(P-h*TD)**2+2*bp*Qt*TD-(Hs*normal**2+schE*E**2/eta**2+schT*TD**2+2*schET*E/eta*TD))
# Residue obstruction for the independent Gram strategy described in the note.
ee,tt,qq,dd=s.symbols('e t Q d',real=True)
res=(ee-tt)**2/2+qq**2-dd*ee*qq
ck('negative_residue_direction',res.subs({tt:ee,qq:dd*ee/2})+dd**2*ee**2/4)
out={'status':'PASS','checks':checks,'count':len(checks),'scope':'Exact full-parent reassembly and precise obstruction to treating its retained rows as independent strict bounded-Gram pivots. No C14.3b closure.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
