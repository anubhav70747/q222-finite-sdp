# Adversarial review of the C1 UI candidate

Reviewed `analysis_atlas/oct19_r6_c1_ui/ui_all_tests.tex` against the exact
leading model CL1–CL7, the rank-one lemma UA1–UA3, and the reported four
exact Hessian checks. This is a same-system analytical review; no new CAS
routine or broad inherited test was run for this review.

No blocking analytical gap was found in the exact bounded frame, monic
contact lift, finite source-boundary caps, or away-from-contact rank-one
allocation, provided the stated bounded positive-residue Gram lemma and
the inherited physical-source remote theorem are used with their existing
scope.

The local lift is valid for independent source/test rates. In particular,
CU9 replaces the potentially troublesome scalar difference by products
of the printed roots without an inverse of a mixed quantity. The N first
normal has the extra ideal `(g²,xi)`, so its couplings have zero residue.
The S/T diagonal redistribution changes other Gram coefficients only by
a multiple of `delta`, which has zero residue in the local chart. The
matched tangent map is invertible: `R_h/g = E_Q/g + 2s kappa dV_1` to
first order, while `T/g = kappa du`.

The boundary cap argument retains the necessary distinction between
centered divergent rows and their bounded hard-state parts. The only
possible two-row divergent pair is A,D, with hard-state determinant k;
the C divergence is isolated. A bounded exact competitor annihilates
these rows, so the state minimizer stays bounded. CU10 gives a uniform
positive angular Schur complement. These facts justify positivity on
the limiting hard kernel and then finite caps. The leading source
interval has positive width, so its boundary approximation is available.

Away from contact, the normalized Laurent coefficients retain exponents
`U,T,T^-1` and either `U^-1` or `T/U`. Their convex hull contains the
origin in its interior; the Hessian in logarithmic coordinates remains
strict and the function remains coercive. The normalized contact zero
therefore remains unique. The polynomial p(T) has positive constant
and leading coefficients and is strictly positive for fixed `u² != x`,
which supplies the strict allocation interval at every source boundary.
The explicit inverse-state formulas CU13 bound the state minimizers
needed for the second cap argument.

## Recommended strengthening: print the complete normal polynomials

The present coefficient-extraction prescription is exact, but short
closed expressions make the full-normal claim easier to audit. Define

```
b = r/eta
F = u s - Du b
G = F - Du + u p xi s
H = (8 D_* + 4 d0) G - 8 D_J
```

After the prescribed substitution into G0, its complete linear terms
are `v Z L_Q E_Q + v Z L_Y E_Y + g Z L_N N`, with

```
L_Q = 2 cL k R + 8 Dv u (c_* F + c_a) + u (1+p xi) H
L_Y = -8 Dv Du (c_* F + c_a)
      + 8 Du Dv (A_* b + A_r/eta) - Du H
      + 8 alpha0 Du g² (b xi-1) + 4 d0 Du (b xi-1)
L_N = 8 k (hb Dv-h2) + u xi H.
```

These follow directly by differentiation of CU5/CU7. They immediately
show the claimed `(g²,xi)` factor for L_N because
`hb Dv-h2 = 2x eta g² + hb xi`.

The full scalar coefficient is also short:

```
phi = cL (2k R s xi - k² R² g²)
    + 4 c_* Dv F² xi + 8 c_a Dv F xi - 4 c_a a Dv xi
    + 4 A_* Du Dv b² xi + 8 A_r/eta Du Dv b xi
      - 4 A_r r/eta² Du Dv xi
    + 4 D_* G² xi - 8 D_J G xi - 4 D_J J_s xi
    + 4 alpha0 Du g² (b xi-1)²
    + 2 d0 [G² xi + Du (b² xi² - 2b xi - xi)].
```

This makes `phi in (g²,xi)` and the exact monic division input explicit.
The full quadratic hard-normal block remains the coefficient collection
of the same exact CU5/CU7 frame; no higher normal degrees exist.
