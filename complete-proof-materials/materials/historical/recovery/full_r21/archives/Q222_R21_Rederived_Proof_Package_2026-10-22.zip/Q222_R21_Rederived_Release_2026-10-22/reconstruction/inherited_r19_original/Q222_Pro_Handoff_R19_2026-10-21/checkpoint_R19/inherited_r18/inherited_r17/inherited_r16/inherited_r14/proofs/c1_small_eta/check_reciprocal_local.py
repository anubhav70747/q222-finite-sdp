import json
from pathlib import Path
import sympy as s
u,v,W,X,Y,Z,h,xi=s.symbols('u v W X Y Z h xi')
C,A,D,m,al,be=s.symbols('C A D m alpha beta')
r,e,j,rho,ell,n=s.symbols('r e j rho ell n')
p,q=s.symbols('p q')
U,V=u*u,v*v; Du,Dv=1+U,1+V
Q=u*W-Y; J=Q+u*v*X-v*Z; Mt=v*W-X+u*v*Y-u*Z
Bx=be+s.Rational(1,2); theta=1-h
F=m*Mt**2+C*Dv*Q**2+A*Du*Dv*Y**2+D*J**2+al*Du*(v*Y-Z)**2+be*Dv*(X+u*Z)**2+(J**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)/2
qp=v*Z-u*v*X
base=C*Q**2+A*Y**2+D*J**2+Q**2/2-u*W*qp
ret=m*Mt**2+al*Du*(v*Y-Z)**2+Bx*Dv*(X+u*Z)**2+C*V*Q**2+A*(U+V+U*V)*Y**2
R=Du*V*Y**2/2-theta*U*v*Z*Y+(h-s.Rational(1,2))*U*(v*Z)**2+h*h*U*U*(v*Z)**2/2-u*v*xi*(Y+(1+h*U)*v*Z)+U*V*xi**2/2
checks={}
def chk(name,f):
 z=s.factor(s.together(f)); checks[name]=z==0
 if z!=0: raise AssertionError((name,z))
chk('complete_parent_remainder', (F-base-ret).subs(X,-h*u*Z+xi)-R)
Cp=(r+e)/(2*(1-r)); Ap=e/(2*r); Dp=1/(2*(e+r-1))
yst=r*p-rho*ell-n; qp=e*p+ell; qq=p-yst; jj=qq-qp
Bstar=Cp*qq**2+Ap*yst**2+Dp*jj**2+qq**2/2-p*qp
hard=(Cp+Ap+s.Rational(1,2))*(rho*ell+n)**2+Dp*((1-rho)*ell-n)**2
chk('reference_base_exact_hard',Bstar-hard)
H=C+D; K=C*D/H
ss=s.symbols('ss')
chk('harmonic_diagonal', (C*(rho*ell+n)**2+D*((1-rho)*ell-n)**2).subs(rho,D/H)-K*ell**2-H*n**2)
# Relative source comparisons: no endpoint denominator survives at x=0.
x,eta,zeta,pi=s.symbols('x eta zeta pi')
hs=1-x*pi; rs=1-eta*ss; es=eta*(1+x*hs); js=es-1+rs
Kx=1+x; Rc=1+x*rs; T=1+x*hs; Ec=1-x*eta*hs; Qc=1-x*zeta*rs
Pd=1+2*x*hs+rs*x*x*(hs+zeta)+x*zeta+eta*x*(Kx*zeta+x*hs*(1-hs))
P4=T*Ec+x*(1-rs)*(hs+zeta)
B5=Kx*(1+x*eta*zeta)*(rs+eta)-js*Pd
ratios={'C':Kx*(rs+eta)*Ec/((rs+es)*Pd),'A':P4/(T*Pd),'D':B5/Pd}
coquotients={}
for name,f in ratios.items():
 quotient=s.cancel((f-1)/x); num,den=s.fraction(quotient)
 chk('relative_'+name+'_difference',f-1-x*quotient)
 den0=s.factor(den.subs(x,0).subs(eta,0))
 checks['relative_'+name+'_unit_denominator']=den0!=0
 if den0==0: raise AssertionError(name)
 coquotients[name+'_denominator_at_x_eta_zero']=str(den0)
output={'status':'PASS','assertions':len(checks),'checks':checks,'coquotients':coquotients,'scope':'Exact algebra for partial C14.3b local closure with u/v bounded. Source/testing rates independent; does not certify remaining v/u infinitesimal chart.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps(output,indent=2))
