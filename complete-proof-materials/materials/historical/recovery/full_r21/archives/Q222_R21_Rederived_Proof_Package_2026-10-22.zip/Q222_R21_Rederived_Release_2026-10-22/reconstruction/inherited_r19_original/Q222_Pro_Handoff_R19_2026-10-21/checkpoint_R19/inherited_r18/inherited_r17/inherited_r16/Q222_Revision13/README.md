# Q222 revision 13, reconciled 20 October 2026

Start with CHECKLIST.md and CHECKLIST.json. Five new scoped all-tests admissions are retained after focused same-system review. Four original rows are closed; C1.4 and C2.W.HH remain open. Six C1 residual branches and ten ordered weak-C2 source shapes remain, followed by the U1/U2 global gates. No evaluated global affine pencil is supplied.

This reconciliation preserves all mathematical source files and both PDFs from Pro. It restores the 76 revision-12 files missing from Pro's reconstructed input, with byte-verified preservation of all 722 original revision-12 manifest entries. The older truncation report is historical; see provenance/RECONCILIATION_RESTORATION.json for the present complete restoration.

Use each work item's current_remaining_task for new work; task and completion_criterion preserve the original acceptance contract. ADMISSIONS_REVISION13.json contains the exact admitted domains. RECONCILIATION_REVIEW.json records this review's limited scope and remaining obstructions.

Run python3 verify.py --integrity-only. Optional --revision13-only replays the nine new scripts; --revision12-only replays the previous 20 assertions. --with-sympy covers those two groups only. The historical full catalog is restored at verification/CHECK_RUNS.json. No algebra suite was rerun for this reconciliation.

The 260-page main PDF and 27-page results PDF retain Pro's reported verification history. This turn did not rebuild or re-audit their layout. Root ledgers supersede all preserved historical frontier claims.
