"""Only the two new algebraic identities for the R18 completed-J conductor.

The actual-parent DG3 identity and source estimates are reviewed R17 imports.
No historical source or parent checker is replayed here.
"""
import json
from pathlib import Path
import sympy as S

eta, lam, x, c, G0, eps = S.symbols('eta lambda x c G0 epsilon', nonzero=True)
u, v, W, Z, xi, P = S.symbols('u v W Z xi P', nonzero=True)
E = eta*u*W-v*Z
Q = E/eta-P
J = (u*v-x/c)*Z
# jh is Jhat/sqrt(lambda), so no square-root simplification is needed.
jh = J+G0*u*Q/(2*lam)
jh = jh.subs(G0, 2*eta*lam-2*eta)
phi = xi/Z
checks = {}

def check(name, expression):
    assert S.cancel(expression) == 0, name
    checks[name] = True
    print('PASS '+name)

check('completed_J_row_exact',
      jh-(eta*u*u*W-(x/c)*Z-eta*u*(P+Q/lam)))
new_rhs = eps*phi*E*jh/eta + eps*phi*u*E*(P+Q/lam) + eps*x*E*xi/(eta*c)
check('remaining_normal_completed_J_conductor',
      eps*u*u*(W/Z)*E*xi-new_rhs)

payload = {
    'status': 'PASS', 'count': len(checks), 'checks': checks,
    'scope': 'New exact completed-J conductor only; unchanged full parent and source deficits are R17 imports.',
}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload, indent=2)+'\n')
print(str(len(checks))+' focused checks passed')
