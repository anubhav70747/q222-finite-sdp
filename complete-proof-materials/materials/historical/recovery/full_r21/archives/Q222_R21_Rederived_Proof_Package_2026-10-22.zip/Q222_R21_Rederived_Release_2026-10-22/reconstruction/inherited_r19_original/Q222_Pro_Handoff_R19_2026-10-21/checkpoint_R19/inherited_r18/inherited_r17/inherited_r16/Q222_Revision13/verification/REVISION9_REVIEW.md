# Revision 9: supervisory reconciliation

Two all-tests source subdomains are admitted; no whole original row is newly closed.

- IC1: original C1, x infinitesimal and eta,zeta,r,1-r,eta+r-1 positive bounded units. Root derived the three-term lift; a separate same-system reviewer checked its finite identities and the complete source application. Both pure-testing ratio branches, all state normals, source denominator cancellations, axes, signs, homogeneous state restoration and the inherited remote theorem were reviewed.
- WA1: original weak-B C2, the printed positive-unit source ratios and H/y infinitesimal, additionally z/B and 1-r units. The exact local five-root parent, source pivots and separate-field Gram lift were reviewed. A direct new remote proof was reviewed at finite nonlocal, single reciprocal and double reciprocal testing charts, including literal endpoints.
- The unused residual-complement premise was removed from the WA theorems. This is necessary for the correctly stated SO1 corollary. The entire physical two-parameter SO1 family is now admitted for all tests; the polynomial-SOS obstruction itself is preserved.
- EN1-EN8: root reviewed the full normal-block factorization, strict residue and radial source bounds on the stated restricted eta-large branch. The exact scalar pole remains; no whole-parent admission is inferred.
- The delivered source-contact review script was made portable by changing only its receipt output path to its own directory. It is part of the six-script targeted replay.

The detailed reports are the R9_*.md files here. Their work_r9 authoring paths correspond to the delivered advances/three_circuit, advances/c1_small_interior, advances/weak_A and advances/c1_eta_full_normal modules. All reviews are within the same agent system, not an external referee or formal verification. Optional exact scripts corroborate algebra; ordered-field bounds and coverage are in the printed proofs. No numerical positivity table is a premise.
