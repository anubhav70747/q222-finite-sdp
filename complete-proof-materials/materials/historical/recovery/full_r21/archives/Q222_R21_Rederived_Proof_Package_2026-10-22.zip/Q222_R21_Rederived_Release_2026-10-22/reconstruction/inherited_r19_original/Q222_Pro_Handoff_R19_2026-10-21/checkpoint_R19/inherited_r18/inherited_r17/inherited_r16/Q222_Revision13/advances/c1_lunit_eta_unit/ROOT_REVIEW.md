# Scoped root review: C1, L and eta positive units

The full-parent argument in eta_unit.tex has been reviewed against the local strong-II contact-ideal allocation and the original native source formulas. It admits this precise subdomain of C1.4, not the whole row.

- The original source forces the four consecutive events D, C, A, alpha to be strong. The exact inverse cycle sends the only untreated strip to u infinitesimal, v a nonzero bounded unit; the inherited homogeneous theorem covers its entire complement.
- All potentially unbounded weights enter the remainder only through bounded opening products or finite caps. The new A and beta centered packets vanish with their first jets at the actual source contact.
- The full normal and scalar monic divisions remain valid when y is a unit. The exact relation T=(u sqrt(y)/v)R uses only separated factors and has an infinitesimal bounded coefficient in this strip.
- LU8 is an identity on all three state variables. LU9 includes the finite normal terms that were infinitesimal in the former double-small chart, and is strictly positive on all three normal roots.
- LU10 is the remaining complete two-root block. With bounded beta its full original coefficient yields LU11; with unbounded beta, LU12 is strictly positive on the centered event kernel and a sufficiently large finite real cap suffices.
- Both signs, literal u=0, all original opening limits, and beta=0 are included. D=0 is excluded by an original source implication, not by an additional premise.

The companion exact checker passes seventeen assertions, including the full original parent with all five retained packets and every native source residue used above. This is an analytical review within the same agent system; no external referee or formal verification is claimed.
