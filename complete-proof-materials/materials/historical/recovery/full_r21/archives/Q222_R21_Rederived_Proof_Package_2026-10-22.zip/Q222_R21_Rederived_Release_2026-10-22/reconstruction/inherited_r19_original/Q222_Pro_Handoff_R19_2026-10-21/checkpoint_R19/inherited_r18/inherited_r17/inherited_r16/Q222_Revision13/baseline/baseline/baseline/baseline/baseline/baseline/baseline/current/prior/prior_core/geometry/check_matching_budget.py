#!/usr/bin/env python3
"""Small exact checks for the matching-budget lemma and its sharp path."""
import json
from pathlib import Path
import sympy as s
u,v,W,X,Y,Z,d,mu,lam,C,al,be=s.symbols('u v W X Y Z d mu lam C al be')
x=s.symbols('x', positive=True)
ss=s.symbols('s', positive=True)
Du,Dv=1+u*u,1+v*v
Rm=v*W-X+u*v*Y-u*Z
Rd=u*W+u*v*X-Y-v*Z
Rc=u*W-Y;Ra=v*Y-Z;Rb=X+u*Z;Rl=W+v*X
H=2*(Rd**2+Du*Ra**2+Dv*Rb**2-Du*Dv*Z**2)
F=4*mu*Rd**2+d*H+4*lam*Du*Rl**2+4*C*Dv*Rc**2+4*al*Du*Ra**2+4*be*Dv*Rb**2
f=s.expand(F.subs({u:1,W:1,X:0,Y:0,Z:v},simultaneous=True))
expected=4*mu*(v*v-1)**2-2*d*(v*v-1)+8*lam+4*C*(1+v*v)+8*al*v*v+4*be*(1+v*v)*v*v
assert s.expand(f-expected)==0
corner={u:ss,v:s.sqrt(5)*ss/2,W:1,X:0,Y:0,Z:s.sqrt(5)/2,d:1,mu:1,lam:0,C:0,al:0,be:0}
assert s.simplify(Rm.subs(corner, simultaneous=True))==0
assert s.simplify(F.subs(corner, simultaneous=True)+ss*ss/4)==0
budget=s.expand(expected.subs(v*v,1+d/(4*mu)))
assert s.factor((4*mu*(v*v-1)**2-2*d*(v*v-1)).subs(v*v,1+d/(4*mu))+d*d/(4*mu))==0
# c=1, r=x, h=g=j=x^2; all rational formulas use a only through a^2.
z=s.Integer(1);r=x;h=g=j=x*x
t=1+x-x*x;b=1-x;a2=(1-x-x*x)/t;Ac=1+z*r
Delta=((1+z)*z*b*b+2*z*(1+z)*b*r+(1+z)*(1+a2*z)*b
       +z*z*(1-a2)*r*r+2*z*(1+a2*z)*r+1+a2*z)
N=(1+z)*(b+r)*(b+a2*(1-t))-a2*(1+a2*z)*(1-r)*t
S=Ac+a2*z*t
n=((b+r)*Ac*S-r*Delta)/(2*r*Delta)
m=(1+a2*z)*(1-r)*Ac*S/(2*g*Delta)
cw=Ac*N/(2*a2*t*Delta)
A=a2*Ac*(b+r)*S/(2*h*Delta)
D=(1+z)*(b+r)*(b-a2*z*r)*S/(2*a2*j*Delta)
alpha=z*z*(b+r)*N/(2*(1-z*h)*Delta)
assert s.factor(b-a2*t-h)==0
assert s.factor(1+z*r-t-j)==0
assert s.factor((1+z)*b-(1-r+a2*z*t)-g)==0
assert s.factor(N-((1+z)*(b+r)*h+a2*(g+j+r*t*(1+a2*z))))==0
expected_limits={
 'Delta':(Delta,8),'N_over_x':(N/x,2),'x_n':(x*n,s.Rational(1,8)),
 'x2_m':(x*x*m,s.Rational(1,4)),'x2_A':(x*x*A,s.Rational(1,8)),
 'x2_D':(x*x*D,s.Rational(1,4)),
 'C_over_x':(cw/x,s.Rational(1,8)),'alpha_over_x':(alpha/x,s.Rational(1,8)),
 'sharp_product':(n*(cw+alpha),s.Rational(1,32))}
limits={}
for name,(expr,value) in expected_limits.items():
    actual=s.limit(s.cancel(expr),x,0,dir='+')
    assert actual==value,(name,actual,value)
    limits[name]=str(actual)
report={'status':'all exact checks passed','witness':'full original matching test with all four complementary packets',
        'path_source_identities':True,'four_packet_commuting_counterexample':True,'normalized_limits':limits,
        'Delta_factorization':str(s.factor(Delta)),
        'scope':'Exact budget identity and sharp admissible C2 path; physicality uses the established exact-contact determinant argument.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
