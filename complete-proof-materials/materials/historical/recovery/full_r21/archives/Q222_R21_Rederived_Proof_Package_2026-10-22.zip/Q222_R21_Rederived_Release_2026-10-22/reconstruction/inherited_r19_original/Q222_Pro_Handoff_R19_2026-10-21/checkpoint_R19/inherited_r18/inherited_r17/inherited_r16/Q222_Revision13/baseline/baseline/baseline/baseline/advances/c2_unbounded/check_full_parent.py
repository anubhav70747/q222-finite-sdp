"""Exact full-parent checks for the unbounded-b, small-B C2 proof.

The analytical positivity and all-tests join are in the accompanying TeX.
This module performs no numerical samples and no source enumeration.
"""
from pathlib import Path
import json
import sympy as s

u,v,W,X,Y,Z=s.symbols('u v W X Y Z')
B,sigma,eta,r,k=s.symbols('B sigma eta r k')
n,m,C,A,D,alpha=s.symbols('n m C A D alpha')
nr,cm,tc,ta,cd,ca=s.symbols('nr cm tc ta cd ca')
Du,Dv=1+u*u,1+v*v
M=v*W-X+u*v*Y-u*Z
J=u*W+u*v*X-Y-v*Z
F=(4*n*Du*Dv*X**2+4*m*M**2+4*C*Dv*(u*W-Y)**2
   +4*A*Du*Dv*Y**2+(4*D+2)*J**2+(4*alpha+2)*Du*(v*Y-Z)**2
   +2*Dv*(X+u*Z)**2-2*Du*Dv*Z**2)
weights={n:nr/r,m:sigma**2*cm,C:tc/(B*(1-eta)),A:ta/(B*eta),D:B*cd,alpha:B*ca}
weighted=s.expand(F.subs(weights))
graph={X:-r*u*Z,Y:eta*u*W}
f=s.expand(weighted.subs(graph,simultaneous=True))
checks=[]
def eq(label,lhs,rhs=0):
    assert s.factor(lhs-rhs)==0,label
    checks.append(label)
def bounded(label,E):
    den=s.factor(s.denom(s.cancel(E)))
    assert den.subs({B:0,sigma:0,r:0,eta:0})!=0,(label,den)
    assert den.subs({B:0,sigma:0,r:0,eta:1})!=0,(label,den)
    checks.append(label)

fw=f.coeff(W,2);fz=f.coeff(Z,2);fwz=f.coeff(W).coeff(Z)
q=s.cancel(B*(fw-fw.subs(u,0))/u**2)
a0=s.cancel(fw.subs(u,0)/sigma**2)
e=s.cancel(fz.subs(u,0)/B)
bs=s.cancel((fz-fz.subs(u,0))/u**2)
d=s.cancel(fwz/(2*u))
for label,E in [('Q bounded',q),('a0 bounded',a0),('e bounded',e),('b bounded',bs),('d bounded',d)]:
    bounded(label,E)
dk=1+k*k
lead={B:0,sigma:0,u:0,tc:k*k/(2*dk),ta:k*k/(2*dk),
      nr:(1/dk-r)/2,cm:(1-r)/2,cd:1/(2*k*k*dk),ca:k*k/(2*dk)}
for label,E,target in [('Q residue',q,2*k*k*Dv/dk),
                       ('a0 residue',a0,2*(1-r)*v*v),
                       ('e residue',e,2*(v*v/k**2+k*k)/dk),
                       ('b residue',bs,2*r*Dv/dk-4*r+2),
                       ('d residue',d,-2*v)]:
    eq(label,E.subs(lead,simultaneous=True),target)

Fx=s.expand(s.diff(weighted,X).subs(graph,simultaneous=True))
Ax=s.cancel(Fx.coeff(Z)/u)
Bx=s.cancel(Fx.coeff(W))
B0=-8*cm*v*(1+eta*u*u)
B1=v*(8*B*cd+4)*(1-eta)
eq('entire X W row scaling',Bx,u*u*B1+sigma*sigma*B0)
for label,E in [('X A bounded',Ax),('X B0 bounded',B0),('X B1 bounded',B1)]:bounded(label,E)
L=s.cancel(Ax+B*B1/k+sigma*B0/k)
eq('X leading derivative',L.subs(lead,simultaneous=True),4-4*Dv/dk)
N=s.symbols('N', positive=True)
bstar=N*r*r*Dv-4*r+2
astar=4-2*N*r*Dv
eq('remote entire X Schur',bstar-astar**2/(4*N*Dv),2-4/(N*Dv))

Fy=s.expand(s.diff(weighted,Y).subs(graph,simultaneous=True))
B2=8*Dv*(ta*Du-tc)
Fyr=s.expand(Fy-u*W*B2/B)
ew=s.cancel(Fyr.coeff(W)/u)
ez=s.cancel((Fyr.coeff(Z)-8*v*B*(cd-ca))/u**2)
eq('entire Y constant row',Fyr.coeff(Z).subs(u,0),8*v*B*(cd-ca))
for label,E in [('Y ew bounded',ew),('Y ez bounded',ez)]:bounded(label,E)
eq('Y P coefficient zero residue',(B2+B*ew).subs(lead,simultaneous=True))
Hxy=s.diff(weighted,X,Y)/2
eq('hard mixed no C',s.diff(Hxy,tc))
eq('hard mixed no A',s.diff(Hxy,ta))

# Homogeneous conductors, requiring neither bounded W/Z nor a state chart.
rhoB=s.symbols('rhoB')
R=(u*W-B*Z/k)/rhoB
S=u*Z-sigma*k*W
U=rhoB*(v-k)*Z
T=u*(v-k)*Z
def root_eq(label,expr):eq(label,s.cancel(expr).subs(B,rhoB*rhoB))
root_eq('W homogeneous conductor',(u*u-sigma*B)*W-u*rhoB*R-B*S/k)
root_eq('Z homogeneous conductor',(u*u-sigma*B)*Z-u*S-sigma*k*rhoB*R)
root_eq('homogeneous T reserve',T*T-sigma*U*U-S*T*(v-k)-sigma*k*R*U*(v-k))
root_eq('entire X homogeneous lift',Fx-(u*rhoB*B1*R-sigma*B0*S/k+u*Z*L))

# Weak m, literal n=0 double-zero test: exact inherited epsilon identity.
Hc=4*n+4*m+2;zeta=(4*m+2)/Hc;xi=4*m/Hc
et=C/(C+A)
corner=s.expand(F.subs({X:xi*v*W-zeta*u*Z,Y:et*u*W},simultaneous=True))
eps=4*alpha+4*n*(4*m+2)/Hc
czz=s.expand(corner).coeff(Z,2)
base=4*alpha+eps*u*u+4*n*zeta*zeta*u**4+4*D*v*v
eq('corner exact v=0 scalar',czz.subs(v,0),base.subs(v,0))
Cb=s.cancel((czz-base)/(u*u*v*v))
eq('corner T pivot',Cb.subs({n:0,m:0,D:0,alpha:0,u:0,v:0}),2)
cw=s.expand(corner).coeff(W,2)
eq('corner exact u=0 W coefficient',s.factor(cw.subs(u,0)),
   4*m*(2*n+1)*v*v/(2*n+2*m+1)+(4*n+2)*xi**2*v**4)
lcx=s.expand(s.diff(F,X).subs({X:xi*v*W-zeta*u*Z,Y:et*u*W},simultaneous=True))
eq('corner X normal v=0',lcx.coeff(Z).subs(v,0),-8*n*zeta*u**3)
wrow=s.cancel(lcx.coeff(W)/v)
eq('corner W row constant cancellation',wrow.subs({u:0,v:0}))
# After u² division the quotient is bounded; at u=0 the rest has m factor.
eq('corner W row residual has m factor',s.cancel(wrow.subs(u,0)).subs(m,0))
zrow=s.cancel((lcx.coeff(Z)+8*n*zeta*u**3)/(u*v*v))
assert s.denom(zrow).subs({n:0,m:0,u:0,v:0})!=0
checks.append('corner Z uv^2 coquotient bounded')

result={'status':'PASS','count':len(checks),'checks':checks,
        'scope':'Entire scaled scalar, full X/Y normals, homogeneous conductors, hard mixed isolation, remote X Schur, and weak-m/literal-n=0 double-zero corner. Positivity and all-tests exhaustion are analytical obligations in the proof.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
