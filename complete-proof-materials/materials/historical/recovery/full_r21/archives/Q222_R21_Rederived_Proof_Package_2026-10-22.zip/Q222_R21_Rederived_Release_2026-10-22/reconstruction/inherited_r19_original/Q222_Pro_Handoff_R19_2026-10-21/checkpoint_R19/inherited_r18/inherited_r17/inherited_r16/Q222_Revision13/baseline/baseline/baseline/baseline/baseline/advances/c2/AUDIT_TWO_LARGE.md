# Scoped audit: two large retained C2 events

**Verdict: PASS for Theorem `thm:c2-two-large` as stated.** The result permits arbitrary n and D, retains bounded A and positive-unit d,C,alpha, and assumes an actual physical stationary contact with k infinitesimal and a a positive unit. It supplies all independent testing angles and all states in that source domain. It is not a global source classification.

This is a separate-agent analytical review within the same assistant system. I read the entire candidate, its initial 25-check symbolic checker and PASS receipt, and the preceding unbounded-n theorem including its all-tests corollary. The author's later receipt has **26 checks passed**, after splitting the Z-normal packet-absence assertion into two separate derivative assertions; I inspected this strengthening. I did not rerun the existing suite: the changed estimates and proof implications, rather than another run of the same symbolic expansion, were the subject of this review.

## Entry and the uniform source equations

At u=0, the signed core has hard form `2d(1+v^2)(X^2+Y^2)`. Adding C and alpha gives a positive hard block on X,Y,Z even before adding A or D. Thus the first completion uses only bounded coefficients and remains valid when n,m,D are arbitrarily large. The omitted packets are nonnegative. At a zero, W cannot vanish, and normalizing W=1 gives X,Y,Z=O(k). The m amplitude has residue a, hence the retained m packet gives m=O(k^2).

The Y state equation then gives DJ=O(k), since all its other weights are bounded. In the X equation, the coefficient of X is proportional to `d+2n(1+k^2)`, which is comparable to N=d+2n because `2n/N<=1`. Thus NX=O(k^2) follows without assuming n bounded. This proves all of TD2, including Nx bounded after x=X/k^2. The J bound itself follows from the bounded contact coordinates and does not use 1/D.

The two equations TD3 are precisely the preceding stationary Laurent equations with their displayed coefficients divided by N. Dividing once more by L=d+2D is allowed in the coefficient field. The important positive sum is exactly

`n/N + (1+2D/N)/L = (n+1)/N + 2n/(NL)`.

This is valid for arbitrary d, not only d=1. Its first term is bounded above and below by positive real constants when d is a positive bounded unit; the second is nonnegative and bounded. The factors t_3/L and t_8/L are likewise positive units. Consequently the first stationary equation gives m/k^4 comparable to A, uniformly in the ratio n/D.

In the second equation, the leading left term is A times a positive unit. The extra left term is O(Ak^2). On the right the coefficient is D/L times a positive unit, with the additional contribution O(Ak^2). If A were infinitesimal, D/L would be infinitesimal. Since d is a unit, this forces D itself to be infinitesimal, and then m is infinitesimal. The stated physical test kills n exactly and produces the displayed strictly negative u^2 coefficient in the residue polynomial. Its higher coefficients are bounded in this contradiction regime. Therefore physicality excludes that case. A, D/L, and m/k^4 are positive units. In particular D is bounded below and 1/D is bounded, even though D need not be bounded above.

No lower bound on D is used before this argument supplies it.

## Full-parent graph and normals

The graph is exactly centered: at u=k,v=a it reproduces X_c,Z_c,J_c and therefore Y_c. The inverse TD8 is triangular and uses only pure coefficient inverses 1/sqrt(N),1/sqrt(D). Both are bounded.

The potentially large graph coefficients are controlled individually:

- n x^2 is bounded because Nx and x are bounded;
- D j^2 is bounded because Dj and j are bounded;
- the X-normal contribution n x/sqrt(N) is bounded;
- the J-normal contribution sqrt(D) j=(Dj)/sqrt(D) is bounded.

The adapted X derivative is F_X+uvF_Y. The D derivative cancels from it exactly. The adapted Z derivative is F_Z−vF_Y, from which D also cancels exactly. The n packet affects only the X row. Thus the whole first-normal coefficient polynomials are bounded, not merely their evaluations at contact. The exact scalar and three first-normal shapes in TD9 and TD11 are confirmed by the author's full-parent symbolic expansions.

The scalar contact identities imply

`H_0(K,a)=−gamma K`, `partial_U H_0(K,a)=gamma`, and `partial_v H_0(K,a)=−2 gamma K/a`.

Their finite monic Taylor expansion yields TD10 exactly. Substitution `U−K=R+(K/a)(v−a)` introduces no inverse of an infinitesimal testing element. Its R pivot is gamma; all additional R diagonal or R,T mixed terms have infinitesimal coefficients.

The normal contact identities and the same monic division give TD12. In the X row, m/K=O(K), u and K are infinitesimal, and 1/sqrt(N) is bounded, so both coefficients have zero residue. The R coefficients in the J and Z rows also contain u and have zero residue. Their T coefficients may survive and are correctly retained in the final Schur complement. The two large quadratic packets reduce exactly to their normalized diagonal squares. State degree two leaves no omitted higher normal terms.

## Strict full residue Gram

The X pivot is `2(1+a_0^2)` after its N normalization. The R pivot is gamma_0>0. They decouple in residue from the remaining block.

For bounded D, TD13 is positive definite and its change to the J,Z coordinates has invertible residue. For unbounded D, 1/sqrt(D) has zero residue and the adapted hard block becomes

`4 E_J^2 + ([4(C_0+A_0)+2d_0](1+v^2)v^2 + 4 alpha_0(1+v^2)^2) E_Z^2`,

which is positive definite at every finite real v. The hard determinant divided by L is a positive unit. The checker explicitly establishes its affine dependence on D and its positive leading coefficient. The same affine dependence bounds Q_0/L. Q_10/L and Q_12/L are positive units, using A unit and D/L unit already established at entry.

The boundary minimization is used to calculate a real residue Schur complement. It is not used to invert a mixed tensor element in the certificate. The graph's contact normal equations identify its limiting hard coordinates with the unique hard minimizer, including when D is unbounded: in that case sqrt(D)j has zero residue and the J hard coordinate minimizes at zero. The scalar contact jets give f(a_0)=f'(a_0)=0.

An even quartic with positive leading coefficient and a double zero at positive a_0 must be exactly `c(v^2−a_0^2)^2`: the derivative fixes the quadratic coefficient, and the value fixes the constant coefficient. Thus the angular Schur complement is strictly positive. It is the Schur complement of the retained E_J,E_Z,T block, so together with the separate X and R pivots it proves strict positivity of the entire five-root Gram. This is stronger than checking only its determinant or a normal-free restriction.

## Independent outer tests and restoration

For the finite u=0 residue axis away from the two matching Bob residues, retaining the m,n packets removes their scales entirely. The substitution using K_J=sqrt(D)J leaves an exact bounded Gram on X,Z,K_J,uW. Its hard block is the already verified adapted hard block, and its soft Schur complement f(v) is positive at every real v other than ±a_0, including zero.

The reciprocal-Bob chart is polynomial after homogeneous substitution. Its hard form is positive after the same D normalization; `det B_infinity/L` is a unit because D/L is a unit. Its soft pivot `8(Q_12/L)/(det B_infinity/L)` is strictly positive. Hence the literal endpoint is included without a limiting tensor operation.

The remaining open axes and two Alice-infinity corners use the baseline capping argument. Its hypotheses are lower bounds on C/d,A/d,D/d,alpha/d; all four have now been proved or assumed. An upper bound on D is never used, because the excess D packet is retained. The full m,n packets are retained as well. The baseline corner forms and positive quadratic-part completion therefore apply unchanged under the enlarged source hypothesis.

The matched proof homogenizes in W as a polynomial identity, so W=0 is included. The other charts are already whole-state identities. The sign copy, separate pure testing projective factors, and real/imaginary splitting restore all states and angles. The inherited noncommuting-residue theorem applies under exactly the retained source-physicality assumption.

No correction to the theorem or proof was required. Any extension allowing A unbounded is outside this audit and must separately control the A packet and recheck the source entry and outer joins.
