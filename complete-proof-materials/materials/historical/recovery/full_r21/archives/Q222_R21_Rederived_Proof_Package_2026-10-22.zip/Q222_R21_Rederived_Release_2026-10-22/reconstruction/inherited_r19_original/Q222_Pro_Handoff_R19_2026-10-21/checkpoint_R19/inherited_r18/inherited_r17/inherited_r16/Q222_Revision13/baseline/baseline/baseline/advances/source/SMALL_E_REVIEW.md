# Scoped separate-agent review: small-e C1 candidate

Reviewed 18 October 2026. Author: `critical_c1_completion`; reviewer: `coverage_reduction`. This is a same-system separate-agent mathematical review, not external peer review or formal verification.

## Current verdict

**Contact proposition: no blocking gap found.** Reviewed `../c1_scales/small_e_all_r_contact.tex` and `check_small_e_all_r_contact.py`; freshly replayed the clean checker, **PASS33**. This approves only the printed local proposition: k,zeta,e infinitesimal, eta a bounded positive unit, every original 0<r<1 and positive opening, and independent u,v,w infinitesimal with Z=1 and w>0.

**Outer/state join and integration theorem: PASS scoped mathematical review; no blocking gap found.** Reviewed `../c1_scales/outer_small_e/outer_small_e.tex` and `../c1_scales/small_e_all_tests.tex`. The final outer checker, including the direct finite-angle determinant and both complete hard restrictions, freshly replayed **PASS50**. The resulting all-tests scope is exactly the physical native C1 domain k,zeta,e positive infinitesimal, eta bounded positive unit, arbitrary positive native r and openings. This closes the small-e unit-eta C1.3 leaf in its entirety, after the original canonical-entry and total-deficit intersection. No infinitesimal/unbounded-eta branch is included.

## Full source and restoration

- SE1 is the exact original source change, with k=epsilon*j and t=epsilon^2*tau. The beta inequality bounds tau after the original common r factor is canceled. E, E+ell, and 1+ell(E+ell) are positive units even as ell tends to zero or one. No inverse of r, ell, a, t, epsilon, or j survives in the bounded remainder coefficients.
- The new centered cap A*=ArH/(1+rH) satisfies A-A*=A/(1+rH)>0 for every positive r. Its retained square vanishes with every first derivative at the exact contact. Subtracting it gives precisely the displayed bounded A*/a and Ar/a terms; normalizing by a is restored as a positive pure-source factor.
- The three unchanged original packets and the modified fourth packet are retained exactly. In the normalized second packet its N² coefficient is ((4 beta+2d)/a)(R-t)/R. The inserted normal mass nu=(d/a)(R-t)/R is at most half this coefficient. Thus the remaining retained packet is nonnegative, including literal beta=0; there is no deletion of an original event or assumption that a clipped source is physical.
- SE4 carries the full polynomial in N and M_B through degree two. It is not a scalar restriction. Every complete first normal and hard-normal cross coefficient is included.

## Rational tail and conductor

This review did not infer the tail from the finite weight calculation. At zero normals, q_A=D_u*w*v, q_B=D_u*v*V0, uW=C/E+u²h*v*V0, and Y=C/E-h*v*V0, where V0=1-p*u*v*w and p has epsilon². These formulas give the complete rational scalar allocation in A², B², BC, C², D0². In particular no AB or AC generator is needed. The sole constant comes from alpha and has alpha_0/D0²=2*c_alpha_tilde/c_3_tilde exactly. The raw allocation coefficients depend on w only through V0; modulo epsilon they are w-free and even in u,v.

After clearing unit denominators that are independent of w and even in u,v, monic contact division can be performed polynomially. For the first scalar conductor, modulo epsilon, T_u is divisible by u, T_w is zero, and T_v is divisible by v. The first lifted coefficients therefore acquire w-dependence modulo (epsilon,u) only in the form E*w*v*P(v²). The second-stage monic w-quotient belongs to (epsilon,v). The exact extra identity SE6 and conductor SE7 handle precisely this ideal, without dividing by epsilon. This repairs the earlier insufficient epsilon-only divisibility claim. The full normal raw coefficients are likewise w-free modulo epsilon, so their one conductor already has T_w in (epsilon).

The scalar contact value and all three scalar first derivatives are unchanged by the retained squares. The normal contact values vanish too. The old square-lift repair follows: the only contact syzygy among x,y,z,h0 has coefficients (-2k,1,1,-1), and the h0 coefficient identifies its multiplier as 2k*rho_contact. The circuit identity removes it with no small inverse. These arguments apply to the full cleared rational expression, not just the low-weight truncation.

The squared circuit monomials are A,uB,kC,D0, whose product is (k²BC)²; the manuscript has the corrected product. Their two separated radical pairings supply the inherited strict circuit Gram.

## Weights, full normals, and strictness

The contact substitutions preserve weights (epsilon,j,u,w,v,N,M_B)=(1,1,2,1,3,5,3). Root x has weight 3 and the other soft roots weight 5. Both conductor identities preserve this grading, including the v-part of the new quotient split. Thus scalar terms above weight 10 and normal coefficients above weight 5 lift with strictly positive coefficient weights. This justifies discarding their residues after the full-tail membership proof, not before it.

The clean checker reconstructs the complete SE4 expression in the finite quotient, independently collects all normal degrees, performs the monic lifts, and checks SE9–SE11. The M_B/x off-diagonal uses half the full linear-normal coefficient, as required. Its determinant is 64(E²+2E ell+4E+4ell)/((E+ell)²(1+ell(E+ell))), a positive unit throughout the original eta-unit/all-r domain. The N pivot and circuit block are also strict. The checker uses no sampled parameter values.

## Literal boundaries

Beta=0 is included by the exact reservation above. Literal D=0 is actually impossible in this source domain: with k,zeta infinitesimal and eta bounded unit, the exact original B5 numerator has residue 1, while D/d=B5/(2J eta P_d) and all denominator factors are strictly positive. This is a source exclusion derived from the unchanged formula, not an extra hypothesis. Positive native openings may still approach zero at arbitrary rates.

## Outer source correction and complete critical parent

The two cases a unit and a infinitesimal are exhaustive since eta is a bounded positive unit and 0<a eta<1. In the first case the exact correction c*-2 has a polynomial k² factor after the native cancellation, with unit denominator QL; Q has residue 16 eta² a(r+eta). This remains uniform even when r or J is infinitesimal. In the second case r,J are units, the exact correction (A*-A)/a has a polynomial k² factor with unit denominator r L B0, and B0 has residue 16(r+eta). Thus the positive critical increase epsilon is O(k²) after the indicated normalization, while m/sigma is a positive unit times e². The comparison epsilon/(m/sigma)=O(zeta) is infinitesimal. No small mixed inverse or lower positive-unit bound on m is used.

SEO11 is the full critical parent, with all hard-normal terms. In the first source case the HD root isolates the possibly unbounded D square exactly, and the HA root isolates A. Boundedness follows from A y², sqrt(A)y, C s² and sqrt(C)s; the latter two use C s=4cb with c bounded. In the second case the Hc root isolates the unbounded c square, with c/(4c+C), cb/sqrt(4c+C), and cb² bounded. The complete hard-V entries vanish through angular degree one, and their allocation to uV,vV leaves infinitesimal coefficients. The printed zero-section forms have positive-unit u² and v² coefficients. This is a full five-root critical Gram, not a determinant-only contact argument.

For unit W at the small-angle corner, the exact pure-testing identity V=Z(Rm+B)/(1+uY) is valid for all bounded state coordinates, including Z=0 and either sign of Z. The denominator is a testing unit. The critical deficit is represented by a combination of the critical roots and sqrt(m/sigma) Rm whose coefficients are all infinitesimal, including the potentially delicate coefficient sqrt(epsilon/(m/sigma)). The complete original m event gives the additional positive pivot. The other original events and positive critical excess are restored unchanged.

## Every finite outer angle and projective endpoint

The direct finite-angle proof in SEO20 removes the formerly unclear inherited-source reference. I checked the displayed Gram matrix on (B,Y,Jt,V), its determinant, and both complete hard restrictions. For the first normalized frame the determinant is

`32 c d Du² Dv² [u² + D(2A+d)/(A(2D+d)) v²]`.

Here its coefficient ratio is a bounded positive unit even if A or D is unbounded. In the second frame the determinant is the original positive expression divided by A(4c+C), with c/(4c+C) a positive unit. The hard restrictions on V=0 have explicit strict bounded Gram residues in both frames. Whenever either bounded angle has nonzero residue, the full determinant has positive-unit residue; Schur complement with the strict hard restriction proves that the full bounded four-root residue is positive definite. The critical deficit is an infinitesimal correction on these roots. This covers both finite-unit angles without assuming a continuation of a contact branch or the physicality of the corrected source.

At projective infinity, only positive pure-source coefficients are clipped; their original excess squares and all m,alpha,beta events are retained. The infinity-infinity and infinity-zero strict four-root identities do not require m. At infinity-unit, the signed core retains the (vY-Z)² pivot. At zero-infinity the complete root ideal is (X,Y,uW,Z)²; every W occurrence has u, and the displayed residue is strict on all four roots. This repairs the invalid alternative of asking the weak m event to supply unit W mass. Literal axes are covered by the homogeneous endpoint identities and unchanged original-event SOS.

For the final state join, normalize by a maximal state coordinate. A negative testing-core branch at two infinitesimal angles has X,Y infinitesimal. Either W is a unit, already handled for every Z, or Z is a unit and its normalization leaves w infinitesimal. The exact testing Schur/sign routing is the inherited one and introduces no coefficient-dependent testing normalization; it enters precisely the positive u,v,w chart of the contact proposition. Real and imaginary state parts add. Thus the integration theorem covers every independent test and state in its stated source domain.

## Replay scope

The final contact checker with raw scalar pairs AA,BB,BC,CC freshly replayed PASS33. The finite quotient verifies the printed leading collections and complete first normals; the full-tail proof is the separate algebraic argument reviewed above. The final outer checker freshly replayed PASS50. Its last radical identity is canonicalized by exact factorization after cancellation; it uses no forced radical sign or numerical simplification. No numerical samples or low-weight-only argument were used to infer the all-tests theorem.

Replay commands (the PYTHONPATH supplies the existing SymPy dependency):

```sh
PYTHONPATH=/workspace/scratch/964ce4ea4964/work/advance_2026_10_17/deps python analysis_atlas/oct18c_c1_scales/check_small_e_all_r_contact.py
PYTHONPATH=/workspace/scratch/964ce4ea4964/work/advance_2026_10_17/deps python analysis_atlas/oct18c_c1_scales/outer_small_e/check_outer_small_e.py
```
