#!/usr/bin/env python3
"""Regenerate revision-13 ledgers; preserve the original ten task/criterion strings."""
from pathlib import Path
import copy, json
ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/"provenance"/"revision12_root"
def read(name): return json.loads((OLD/name).read_text())
def put(name,obj): (ROOT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+"\n")
d=read("CHECKLIST.json"); s=read("PROOF_STATUS.json")
original_tasks=copy.deepcopy(d["work_items"])
edition="19 October 2026, revision 13"
common=("Intersect with unchanged original physicality, stationary contact, strict source gaps, nonnegative event weights, positive infinitesimal total scale, and the complement of prior admissions and exact symmetry images. A residual listing does not establish nonemptiness.")
gates={
"G1":"Original source formulas and all opening-cleared bounds are proved in the indicated source modules.",
"G2":"Exact entire-parent identities retain the actual stationary contact and first jets.",
"G3":"Pure-source, pure-testing or separated positive roots; no mixed inverse or order.",
"G4":"Every first state normal and complete hard quadratic share the controlled roots.",
"G5":"Explicit strict real residue Gram or retained exact positive packets, including equality cases.",
"G6":"Both testing-ratio charts and exact remote/projective joins, signs and complex states.",
"G7":"All source rates in each stated chart and all retained literal coefficient boundaries.",
"G8":"Same-system analytical review and focused exact checks; no external or formal verification claim.",
"G9":"Only the printed quantified chart and its exact symmetry images are admitted."}
admissions=[
{"id":"C1.4.L_large_eta_large_bounded_beta_scale","parent_row":"C1.4","status":"proved_all_tests","proved_in_revision":13,
"scope":"Original C1.4: x=k^2,z=1/L,sigma=1/eta positive infinitesimals; M_beta=beta*(1-h)/sigma^2 bounded. No extra h/sigma or sphere-pivot hypothesis. Includes beta=0 and both b,1-b openings.",
"proof":["advances/revision13_c1_eta/joint_radial_beta_zero.tex","advances/revision13_c1_eta/beta_positive_extension.tex"],
"dependencies":["advances/c1_eta_large_source/beta_shared_source_normalization.tex","advances/c1_eta_full_normal/full_normal_frontier.tex","baseline/advances/c1_common/common_remote.tex"],
"checks":["advances/revision13_c1_eta/check_joint_radial.py"],
"mechanism":"Join the entire radial scalar quotient with every first radial normal; an exact six-root syzygy and beta contact square give strict residue.",
"boundary_evidence":"The source forces h/sigma~1,D/sigma^2~1/2, excluding D=0 here. beta=0 and literal testing endpoints are included.",
"residual_complement":"M_beta unbounded: bounded h/sigma leaves only infinitesimal u at residual infinitesimal reciprocal w; h/sigma unbounded remains. L unit is separate.","acceptance":gates},
{"id":"C1.4.small_L_r_openings","parent_row":"C1.4","status":"proved_all_tests","proved_in_revision":13,
"scope":"Original native C1: x positive infinitesimal; eta,zeta,j0=eta+r-1 positive bounded units; arbitrary 0<r<1 and beta>=0. All independent tests/states.",
"proof":["advances/revision13_c1_small_l/r_opening_closure.tex"],
"dependencies":["advances/c1_small_interior/interior_closure.tex","advances/three_circuit/three_circuit_lift.tex","advances/c1_lsmall_eta_bounded/remote_reduction.tex"],
"checks":["advances/revision13_c1_small_l/check_r_openings.py"],
"mechanism":"Normalize the whole Y normal by sqrt(H0) and X normal by sqrt(beta+1/2); opening-cleared arrays preserve the complete circuit lift.",
"boundary_evidence":"r or 1-r may be infinitesimal; beta=0 included; D~1/(2j0)>0 follows from source.",
"residual_complement":"The actual-j theorem handles a separate remaining gap; eta infinitesimal and zeta unbounded are not covered.","acceptance":gates},
{"id":"C1.4.small_L_actual_j_opening","parent_row":"C1.4","status":"proved_all_tests","proved_in_revision":13,
"scope":"Original C1: x and actual j=eta*(1+x*h)-1+r positive infinitesimals; eta,zeta,r,1-r positive bounded units. Includes j0=0 or slightly negative, beta=0 and arbitrary j/x.",
"proof":["advances/revision13_c1_small_l/j_opening_closure.tex"],
"dependencies":["advances/three_circuit/three_circuit_lift.tex","advances/c1_lsmall_eta_bounded/remote_reduction.tex"],
"checks":["advances/revision13_c1_small_l/check_j_opening.py","advances/revision13_c1_small_l/check_j_reciprocal.py"],
"mechanism":"Center the whole D event: Nd=sqrt(D)*(R_D+j*u*W). The complete higher-angle remainder contains no D; polynomial contact lifting controls scalar and all normals.",
"boundary_evidence":"Dj~1/2; the estimate is Dj-1/2=O(x), never D-1/(2j)=O(x). D=0 is source-excluded.",
"residual_complement":"The simultaneous r,j opening is covered by HO. Together RO,JO,HO cover all eta,zeta-unit small-L sources.","acceptance":gates},
{"id":"C1.4.small_L_simultaneous_r_j_opening","parent_row":"C1.4","status":"proved_all_tests","proved_in_revision":13,
"scope":"Original physical native C1: x=k^2,r and actual j=eta*(1+x*h)-1+r positive infinitesimals; eta,zeta positive bounded units. Includes beta=0 and arbitrary independent x,r,j and testing rates.",
"proof":["advances/revision13_c1_small_l/simultaneous_r_j_closure.tex"],
"dependencies":["advances/revision13_c1_small_l/j_opening_closure.tex","advances/three_circuit/three_circuit_lift.tex","advances/c1_lsmall_eta_bounded/remote_reduction.tex"],
"checks":["advances/revision13_c1_small_l/check_simultaneous_r_j.py"],
"mechanism":"Combine the entire A,D events with harmonic weights H=A+D,K=AD/H. Retain uvX in the hard event, solve only through the pure-source unit e=1-r+j, and keep both uvZ and uvW as reciprocal soft roots.",
"boundary_evidence":"Ar~1/2,Dj~1/2; no x/r,x/j or r/j estimate. Seven source coquotients have only retained-unit zeta denominators. beta=0 retained; A,D zero excluded by the source.",
"residual_complement":"RO+JO+HO remove the whole eta,zeta-unit part of C14.3. The remaining C14.3 source types are zeta unbounded, or zeta unit with eta infinitesimal.","acceptance":gates},
{"id":"C2.W.HH.small_e_a_unit","parent_row":"C2.W.HH","status":"proved_all_tests","proved_in_revision":13,
"scope":"Exactly physical BS1/GR1: B,z,y,e=1-r,h=H/B positive infinitesimals; a=z/B,t=y/B,G/B,j,L/B positive bounded units; n>=0 and all original intersections; residue(t)>1. All independent projective tests/states.",
"proof":["advances/revision13_weak_local/centered_circuit_closure.tex"],
"dependencies":["advances/weak_small_gap_scale/boundary_scale_lemma.tex","advances/weak_small_gap_remote/remote_reduction.tex","advances/three_circuit/three_circuit_lift.tex"],
"checks":["advances/revision13_weak_local/check_centered_circuit.py"],
"mechanism":"Keep q_s=n*r^2+(m+1/2)*(1-r)^2 as one centered angular packet. (m-a^2*q_s)/B is jointly regular; weighted roots cancel every first-normal pole before the circuit lift.",
"boundary_evidence":"n=0, B/e infinitesimal or a unit, arbitrary h/e; no inverse of n or q_s. a must remain a positive unit.",
"residual_complement":"Other gaps and a-types remain. On the nice-A source with e infinitesimal, a infinitesimal or unbounded is not admitted.","acceptance":gates}]
evidence_by_id={
"C1.4.L_large_eta_large_bounded_beta_scale":{
"G1":"BE3-BE8 and JB3 give the actual shared source sphere and bounded coefficients, including both b,1-b openings.",
"G2":"JR4 joins the complete scalar and radial first-normal quotients; JR5/JB1 restore the whole reciprocal parent.",
"G3":"JR1 roots and JR6 syzygy use separated factors. JB uses pure-source or pure-testing multipliers; no mixed inverse.",
"G4":"JR5 prints both state normals and every quadratic coupling; the adjoining beta packet is allocated with the same original m reserve.",
"G5":"The beta-zero final Schur complement is (4t+3)/(2(1+t)^4); JB proves the bounded-M_beta extension at infinitesimal and unit u.",
"G6":"The complete bounded-u/infinitesimal-w proof joins the exact CE remote theorem, endpoint/sign and real-imaginary extensions.",
"G7":"beta=0 included; D/sigma^2~1/2 is source-derived, so D=0 cannot occur on this bounded-M_beta chart.",
"G8":"Root analytical audit of the scalar, all normals and beta extension; 36 focused exact assertions corroborate the printed identities.",
"G9":"The theorem is only the stated large-L,large-eta bounded-M_beta chart and exact symmetry images."},
"C1.4.small_L_r_openings":{
"G1":"RO opening-cleared products C(1-r),Ar and H0-normalized coefficients remain bounded at both r endpoints.",
"G2":"The unchanged IC complete scalar/normal identities are retained after the new weighted coordinate change.",
"G3":"The H0 and beta+1/2 square roots are positive pure source; circuit roots and ratios are separated.",
"G4":"RO weights the whole Y normal and all hard couplings, and retains the complete beta plus half-core X normal.",
"G5":"The strict scalar circuit, hard residues and reciprocal seven-root form are proved with opening-cleared coefficient arrays.",
"G6":"Both local ratio types join the original SB remote proof and all literal testing/sign/state endpoints.",
"G7":"Arbitrary positive rates of r and 1-r; beta=0. j0,eta,zeta remain units.",
"G8":"Root analytical audit of the normalized arrays and conductor bounds; 24 focused exact assertions.",
"G9":"Only the stated RO chart; the union with JO and HO is proved in a separate explicit corollary."},
"C1.4.small_L_actual_j_opening":{
"G1":"JO3 uses Dj-1/2=O(x), not a false unweighted D error; native opening-cleared denominators are units.",
"G2":"The Nd whole-event map, full scalar graph, all first normals and exact reciprocal remainder are printed and checked.",
"G3":"Only pure-source D and beta+1/2 roots and legal separated testing factors occur.",
"G4":"The entire D event is retained; the remaining higher-angle expression contains no D.",
"G5":"JO finite Taylor arrays meet the strict three-circuit lemma; the reciprocal seven-root diagonal is strictly positive.",
"G6":"Both infinitesimal testing-ratio charts join the unchanged SB remote theorem and its exact endpoints.",
"G7":"j/x is unrestricted; actual j>0 includes j0=0 and slightly negative j0. beta=0 retained.",
"G8":"Root analytical audit plus 25 source/scalar/normal checks and four reciprocal checks.",
"G9":"eta,zeta,r,1-r units and actual j infinitesimal; no simultaneous-r extension is hidden in JO."},
"C1.4.small_L_simultaneous_r_j_opening":{
"G1":"HO2: seven exact source coquotients have only retained-unit zeta denominators jointly at x=r=j=0.",
"G2":"HO5 full-event map, HO12 complete scalar, HO15-HO16 complete first normals and HO20 whole reciprocal remainder.",
"G3":"HO3-HO5 use positive pure-source harmonic weights; only the source unit e is inverted in the polynomial inverse.",
"G4":"HO6-HO8 control both divergent events; HO15-HO18 allocate every complete normal; HO20-HO23 exhaust all reciprocal terms.",
"G5":"HO14 strict scalar residues and the finite contact conductors; HO24 complete seven-root residue diag(1,1,1,1,1,1/2,1/2).",
"G6":"Bounded and unbounded v/u join SB, whose remote proof explicitly includes r0=j0=0,eta0=1; axes/signs and all states retained.",
"G7":"No comparisons of x,r,j or source/test rates; literal beta=0. A,D>0 and unbounded are derived.",
"G8":"Root and separate same-system analytical audits checked conductor bounds and every reciprocal term; 28 exact corroborating assertions.",
"G9":"Precisely the simultaneous infinitesimal r,j domain with unit eta,zeta; the explicit RO+JO+HO corollary gives the larger union."},
"C2.W.HH.small_e_a_unit":{
"G1":"BS exact slack constraint plus WC3 jointly regular source formulas, including n=0 and all allowed B/e,h/e.",
"G2":"WC complete scalar identity and every full-parent normal and reciprocal identity are restored exactly.",
"G3":"The positive q_s and nonnegative n square roots are pure source; neither n nor q_s is inverted.",
"G4":"WC first-normal factorization retains both q_s and n angular roots, all residual arrays and the entire hard block.",
"G5":"The centered difference (m-a^2 q_s)/B has positive-unit residue; strict circuit and full reciprocal Gram are proved without a source-Hessian lower bound.",
"G6":"Both local testing ratios join GR2-GR7, exact homogeneous endpoints, signs, complex states and the exact weak-event reflection.",
"G7":"n=0, B/e infinitesimal or unit and arbitrary h/e included. The source ratio a must remain a unit.",
"G8":"Root analytical review of all arrays and complete reciprocal allocation; 36 named assertions plus 21 finite source-regularity audits.",
"G9":"Exactly BS1/GR1 plus original intersections and symmetry images; infinitesimal or unbounded a is not imported."}}
for a in admissions:
 a["acceptance_evidence"]=evidence_by_id[a["id"]]
advances=[{"id":"R13."+str(i+1),"status":"proved_all_tests_subdomain","admission":a["id"],"proof":a["proof"],"result":a["scope"]} for i,a in enumerate(admissions)]
advances += [
{"id":"R13.R1","status":"proved_local_testing_reduction","proof":"advances/revision13_c1_eta/beta_positive_extension.tex","result":"L,eta unbounded; h/sigma bounded,M_beta unbounded: all unit-u tests covered at residual infinitesimal w, including D=0. Infinitesimal u remains."},
{"id":"R13.R2","status":"proved_source_bounds_only","proof":"advances/revision13_c1_small_l/eta_large_bounds.tex","result":"For small L,eta unbounded: S=sigma+L gives P/S~1,D=O(sigma^2/S),alpha=O(L),C,A unbounded,e^2=O(x/S) and an exact shared D,beta,m sphere. Full-parent testing allocation open."},
{"id":"R13.R3","status":"proved_source_partition_and_boundary_overlap","proof":"advances/revision13_source_overlap/source_overlap.tex","result":"e*P_n=(1+z)(H+y)(B+zr)+2r*delta*n. At n=0 C2 is literally C1 at the same contact. For n>0 formal C1 beta is negative; no physical C1 admission imported."}]
audit="advances/revision13_weak_local/frontier_audit.tex"
if (ROOT/audit).is_file():
 advances.append({"id":"R13.R4","status":"proved_remote_testing_reduction","proof":audit,"result":"On the nice-A source with e,a infinitesimal, exact source bounds imply GR1 and GR2-GR7 transfer. Only both-infinitesimal tests remain; no source-domain admission."})
advances.append({"id":"R13.R5","status":"proved_bounded_full_parent_reduction_not_SOS_admission","proof":"advances/revision13_c1_eta/followup_conductor/bounded_u_conductor.tex","checks":["advances/revision13_c1_eta/followup_conductor/check_bounded_u_conductor.py"],"result":"On C14.1a, Omega=(u^2-x)Z removes every x/u and x/u^2 denominator in the complete parent. The radial-kernel comparison model has an exact circuit, but its first radial normal and all full-parent corrections still need a finite conductor lift. An additional D=0 boundary zero prevents a strict cap on the old soft coordinates."})
progress={
"C14.1":"beta=0 and the larger bounded-M_beta source chart are closed for all tests. Bounded h/sigma with unbounded M_beta has all unit-u tests covered, including D=0. For infinitesimal u there, JU removes every coefficient pole but leaves an exact circuit/normal lifting obligation. Unbounded h/sigma remains.",
"C14.2":"Open in its exact original scope. The large-L proof is not imported at unit L.",
"C14.3":"RO, JO and HO together admit the entire eta,zeta-unit region, including all r and actual-j openings. Remaining: zeta unbounded with eta bounded; or zeta unit with eta infinitesimal.",
"C14.4":"Source-bound prerequisite completed by ES1-ES10 through all original openings and coefficient endpoints. Complete original-parent allocation for the residual infinitesimal-u tests remains open.",
"C14.5":"New local/remote joins are explicit. Their union with inherited domains still leaves the stated C14.1-C14.4 complement; the original row is open.",
"W.1":"BS1 removed in its exact scope. Other source-ratio and gap openings remain; the frontier audit gives an ordered residual partition.",
"W.2":"Complete scalar and full-parent certificate proved on BS1. Global polynomial-SOS obstruction preserved; SO1 remains tensor-admitted. Other source domains open.",
"W.3":"COMPLETED ON BS1: complete local parent, both soft directions, every first normal and hard coupling, n=0 and arbitrary B/e,h/e. The broad item remains open on other source-gap charts.",
"W.4":"On BS1 the joint q_s packet allocates its angular and normal remainders without a Hessian lower bound or physicality claim for a subtracted remainder. Other centered-packet domains open.",
"W.5":"COMPLETED ON BS1: WC joins GR2-GR7, axes, signs, complex states and exact reflected orientation. Other source charts prevent a whole-row closure."}
res_c1=[
{"id":"C14.1a","source":"L,eta unbounded; h/sigma bounded; M_beta unbounded","tests":"u,w=1/v infinitesimal at residual tests","missing":"Finite separated circuit/conductor lift of the JU11 first radial normal and every correction in the bounded exact JU3 parent, respecting the extra D=0 zero."},
{"id":"C14.1b","source":"L,eta unbounded; h/sigma unbounded","tests":"Inherited bounded u and infinitesimal w","missing":"Opening-uniform full-parent allocation on the shared source sphere."},
{"id":"C14.2","source":"L a positive unit; eta unbounded","tests":"Inherited residual testing complement","missing":"Full scalar and all-normal certificate through both sphere endpoints."},
{"id":"C14.3a","source":"L infinitesimal; eta bounded; zeta unbounded","tests":"Only u,v both infinitesimal","missing":"Contact-root lift retaining the large-zeta scale."},
{"id":"C14.3b","source":"L infinitesimal; zeta unit; eta infinitesimal","tests":"Only u,v both infinitesimal","missing":"Joint eta and source-gap opening frame."},
{"id":"C14.4","source":"L infinitesimal; eta unbounded; zeta noninfinitesimal","tests":"u infinitesimal; all original Bob angle types","missing":"Full native parent allocation from S=sigma+L bounds, retaining M and theta openings."}]
res_weak=[
{"id":"R1","shape":"t I","necessarily_unbounded":"C,D"},
{"id":"R2","shape":"t O","necessarily_unbounded":"C,A"},
{"id":"R3","shape":"t,h U; l I","necessarily_unbounded":"C"},
{"id":"R4","shape":"t,h,l U; j I","necessarily_unbounded":"D"},
{"id":"R5","shape":"t,h,l,j U; r I","necessarily_unbounded":"n"},
{"id":"R6","shape":"t,h,l,j,r U; g I","necessarily_unbounded":"m"},
{"id":"R7","shape":"t U; h,g I; exclude r,j both I","necessarily_unbounded":"A,m"},
{"id":"R8","shape":"t,g U; h,j I","necessarily_unbounded":"A,D"},
{"id":"R9","shape":"t,g,j U; h,e,a I","necessarily_unbounded":"A","testing_reduction":"WF4-WF7 verify every GR hypothesis. Only both-infinitesimal or zero local angles remain."},
{"id":"R10","shape":"t,g,j U; h,e I; a O","necessarily_unbounded":"A"}]
weak_dictionary={"types":{"I":"positive infinitesimal","U":"positive bounded unit","O":"positive unbounded"},"source":"Canonical reflected strong-C/weak-alpha II orientation","parameters":"a=z/B,t=y/B,h=H/B,l=1-h,e=1-r,g=G/B","constraints":["g=1-a*e+h*z>0","j=1+z*r-l/t>0","B-z*y*r>0",common],"proof":"advances/revision13_weak_local/frontier_audit.tex","rows":res_weak,"nonemptiness":"No row is asserted nonempty after all inherited exclusions."}
d["edition"]=edition; d["global_status"]="unfinished"
d["revision_12_current_revision_snapshot"]=d["current_revision"]
d["revision_13_advances"]=advances; d["completed_this_revision"]=admissions
d["source_complement_convention"]=common
d["remaining_domains"][0].update(domain="Original C1.4 outside inherited admissions and the new RO,JO,HO,bounded-M_beta source domains.",remaining_tests="See residual_frontier_revision_13.C1.4.",steps=[progress[x] for x in ["C14.1","C14.2","C14.3","C14.4","C14.5"]])
d["remaining_domains"][1].update(domain="Original weak-C HH reflected exactly to strong-C/weak-alpha II, outside WA/WE/small-r and WC BS1.",remaining_tests="The full BS1 chart is removed. The joint e,a-infinitesimal nice-A chart has only both-infinitesimal local tests left; other source charts retain their stated complements.",steps=[progress[x] for x in ["W.1","W.2","W.3","W.4","W.5"]])
for item in d["work_items"]: item["progress_revision_13"]=progress[item["id"]]
d["residual_frontier_revision_13"]={"C1.4":res_c1,"C2.W.HH":weak_dictionary}
d["difficulty_assessment"].update({"C14.1":progress["C14.1"],"C14.2":progress["C14.2"],"C14.3":progress["C14.3"],"C14.4":progress["C14.4"],"W.1-W.4":"First decisive BS1 target completely solved. Other source-gap openings remain; next nice-A chart has e,a both infinitesimal."})
for item in d["global_steps"]:
 if item["id"]=="U3": item.update(status="completed_for_derivative",scope="Revision-13 reconciliation and derivative package integrity refreshed. Original archive truncation remains recorded; full original ZIP recovery is not claimed.")
d["input_recovery_revision_13"]={"original_archive_complete":False,"reason":"Missing central directory; truncated inside a deep historical ZIP.","complete_crc_verified_members":644,"mathematical_tex_inputs_recovered":93,"original_direct_tex_inputs":94,"missing_direct_input":"reconciliation/checklist.tex (administrative; reconstructed)","unavailable_original_wrapper_files":["START_HERE.txt","FILE_MAP.json","CHECKLIST_HANDOFF.json","verify.py"],"preserved_original_root":"provenance/revision12_root/","recovery_report":"provenance/RECOVERY_REPORT.json","replacement_verifier_scope":"Derivative integrity and focused revision12/revision13 replay. No success claimed for the unavailable original verifier."}
receipts=[]
for f in sorted(ROOT.glob("advances/revision13_*/**/check*.py")):
 r=json.loads(f.with_suffix(".json").read_text())
 named=len(r.get("checks",{})); regular=len(r.get("source_regularities",{}))
 receipts.append({"script":str(f.relative_to(ROOT)),"receipt":str(f.with_suffix(".json").relative_to(ROOT)),"named_exact_checks":named,"source_regularity_audits":regular,"total":named+regular})
named=sum(x["named_exact_checks"] for x in receipts); regular=sum(x["source_regularity_audits"] for x in receipts); total=named+regular
d["current_revision"]={"new_whole_row_closures":0,"new_all_tests_source_theorems":len(admissions),"new_all_tests_subdomain_closures":len(admissions),"counting_note":"RO includes IC1; source theorems are not disjoint components or an SDP-size bound.","new_source_bounds_or_partition_lemmas":3,"new_partial_testing_reductions":2,"new_bounded_full_parent_reductions":1,"previous_recorded_checks":632,"old_suite_replayed":False,"revision12_assertions_replayed_this_run":20,"new_checker_scripts":len(receipts),"new_named_exact_checks":named,"new_source_regularity_audits":regular,"new_exact_checks":total,"new_receipts":receipts}
for old,new in zip(original_tasks,d["work_items"]):
 for key in ["task","completion_criterion","required_acceptance_gates"]: assert old[key]==new[key]
s.update(edition=edition,global_atlas_free_proof="unfinished",baseline="All completely recovered historical members retained; input truncation recorded in provenance.",new_completed_domains=[],new_completed_subdomains=admissions,new_whole_residual_row_closures=0,total_whole_original_rows_closed=4,terminal_residual_leaf_count=2,terminal_residual_leaf_ids=["C1.4","C2.W.HH"],remaining_global_gate="Close the exact residual complement, prove U1 exhaustion, then apply the verified finite-lift existence bridge.",evaluated_global_affine_pencil="not supplied",verification_scope=f"Same-system analytical review; {named} new named exact checks plus {regular} finite source regularity audits. Five new source theorems, no whole-row/global closure. Additionally 20 revision12 checks replayed; earlier 612 not replayed.",previous_recorded_exact_assertions=632,new_exact_assertions=total,total_recorded_exact_assertions=632+total,total_checker_scripts=39+len(receipts),total_admitted_subdomains_under_two_open_rows=12,admitted_subdomain_counting_note="Twelve registered theorem domains including IC1 now contained in RO; not twelve disjoint regions.",revision_13_advances=advances,input_recovery_revision_13=d["input_recovery_revision_13"],finite_lift_bridge_audit={"source":"Claus Scheiderer, Second-order cone representation for convex sets in the plane, Corollary 3.19","url":"https://arxiv.org/pdf/2004.04196v2.pdf","checked_in_this_run":True,"conclusion":"Universal tensor-SOS slack evaluation for closed convex semialgebraic K implies spectrahedral-shadow existence; no separate uniform root-count assumption. The universal Q222 hypothesis is still unproved."})
s["terminal_residual_leaf_count_scope"]="Legacy field counts the two original open rows, not the operational source partitions."
s["operational_C1_residual_leaves"]=len(res_c1)
s["weak_C2_residual_shape_rows"]=len(res_weak)
d["new_quantified_union_corollary"]={"scope":"Original native small-L C1.4 with x infinitesimal and eta,zeta positive bounded units, all original intersections retained.","status":"proved_all_tests_by_RO_JO_HO_union","proof":"advances/revision13_c1_small_l/simultaneous_r_j_closure.tex","counted_as_extra_admission":False,"exhaustion":"Actual j unit implies j0 unit: RO. Actual j infinitesimal implies 1-r unit: r unit is JO, r infinitesimal is HO."}
s["new_quantified_union_corollary"]=d["new_quantified_union_corollary"]
put("CHECKLIST.json",d); put("PROOF_STATUS.json",s)
put("ADMISSIONS_REVISION13.json",{"edition":edition,"common_intersection":common,"admissions":admissions,"other_advances":advances[len(admissions):],"review":"Same assistant system, not external refereeing.","global_status":"unfinished"})
put("CHECKLIST_HANDOFF.json",{"kind":"reconstructed derivative","authority":"Ten original tasks/criteria copied exactly from CRC-verified revision12 root CHECKLIST.json; missing original wrapper not claimed recovered.","original_work_items":original_tasks,"revision13_progress":progress,"acceptance_gates":d["acceptance_gates"]})
put("CHECK_REGISTRY.json",{"revision13":receipts,"revision12":[{"script":"advances/weak_small_gap_scale/check_boundary_scale.py","receipt":"advances/weak_small_gap_scale/check_boundary_scale.json","total":8},{"script":"advances/weak_small_gap_remote/check_remote.py","receipt":"advances/weak_small_gap_remote/check_remote.json","total":12}],"historical_assertions_not_replayed":612,"historical_all_suite_registry_reconstruction":"not claimed"})
put("FILE_MAP.json",{"kind":"revision13 derivative map","start":"START_HERE.txt","frontier":["CHECKLIST.md","CHECKLIST.json","PROOF_STATUS.json"],"admission_evidence":"ADMISSIONS_REVISION13.json","full_manuscript":"Q222_Analytical_Revision_2026-10-18.tex","new_results_report":"Q222_Revision13_Results.tex","new_proofs":{a["id"]:a["proof"] for a in admissions},"other_advances":advances[len(admissions):],"registry":"CHECK_REGISTRY.json","manifest":"MANIFEST.sha256","recovery":"provenance/RECOVERY_REPORT.json","preserved_revision12":"provenance/revision12_root/"})
lines=["# Q222: exact frontier after revision 13","","**Global finite-lift existence proof: unfinished.** C1.1, C1.5, C2.S.II_HH and C2.S.HI remain proved. Original rows C1.4 and C2.W.HH remain open. No evaluated global affine pencil is extracted.","","Root ledgers govern the current status. Historical frontier statements in preserved chapters describe their earlier revisions.","","## New all-tests source theorems","","| Admission | Exact source domain | Proof |","|---|---|---|"]
for a in admissions: lines.append("| "+a["id"]+" | "+a["scope"]+" | "+", ".join(a["proof"])+" |")
lines+=["",common,"","RO expands IC1 through both r openings; JO and HO close the remaining actual-j types when eta,zeta are units. These are five source theorems, not whole-row closures.","","## Smallest remaining C1 frontier","","| Leaf | Source | Tests left | Missing allocation |","|---|---|---|---|"]
for a in res_c1: lines.append("| "+" | ".join(a[k] for k in ["id","source","tests","missing"])+" |")
lines+=["","C14.3 is an exact ordered exhaustion: split zeta unbounded versus unit, then eta infinitesimal versus unit. With eta,zeta units, actual j is either a unit (RO) or infinitesimal. In the latter case 1-r is a unit; r a unit is JO, and r infinitesimal is HO. Thus eta,zeta units are fully covered. No comparison of j with x.","","## Weak-C2 frontier","","BS1/GR1 is entirely removed. See advances/revision13_weak_local/frontier_audit.tex for the ordered residual source partition. On its nice-A part, e infinitesimal leaves a=z/B infinitesimal or unbounded. The joint e,a-infinitesimal chart has only local both-infinitesimal tests left after source-checked GR transfer; its local WC extension is unproved.","","The global polynomial-SOS obstruction is preserved. Its SO1 family is already covered by the earlier tensor proof. A failed frame is not a counterexample to tensor SOS.","","## Original work items and unchanged criteria",""]
lines=lines[:-2]+["","Types: I = positive infinitesimal; U = positive bounded unit; O = unbounded. Put a=z/B, t=y/B, h=H/B, l=1-h, e=1-r, g=G/B. Every shape retains all original source conditions and prior exclusions; the rows are not assertions of nonemptiness.","","| Weak-C2 row | Ordered residual shape | Necessarily unbounded weights |","|---|---|---|"]
for row in res_weak: lines.append("| "+row["id"]+" | "+row["shape"]+" | "+row["necessarily_unbounded"]+" |")
lines += ["","## Original work items and unchanged criteria",""]
for item in d["work_items"]:
 lines+=["### "+item["id"]+" — "+item["status"],"","**Original task.** "+item["task"],"","**Completion criterion.** "+item["completion_criterion"],"","**Revision 13 progress.** "+item["progress_revision_13"],""]
lines+=["## Universal steps","","- **U1: blocked.** Residual C1.4 and weak-C2 branches prevent universal exhaustion.","- **U2: blocked by U1.** Corollary 3.19 was checked in the primary source. Its universal SOS hypothesis is sufficient for existence, but remains unproved here.","- **U3: refreshed.** Derivative ledgers, verifier, archive and PDFs are reconciled; input truncation is explicitly recorded.","","## Acceptance gates",""]
lines+=["- "+a for a in d["acceptance_gates"]]
lines+=["","## Verification and input integrity","",f"- New: **{named} named exact checks + {regular} finite source regularity audits**, in {len(receipts)} scripts.","- Revision12: 20 checks replayed. Earlier 612 assertions preserved without replay.","- Receipts corroborate algebra. Scope and positivity rely on the written proofs and same-system analytical review; no formal/external verification claim.","- Supplied ZIP truncated. 644 complete members CRC-verified. All 93 mathematical direct TeX inputs recovered; missing administrative reconciliation/checklist.tex regenerated.","- Missing original verifier/wrappers replaced by clearly marked derivative files. MANIFEST.sha256 verifies this package, not the unavailable tail of the original ZIP.","","## Reproduce","",chr(96)*3+"bash","python3 verify.py --integrity-only","python3 verify.py --revision13-only","python3 verify.py --revision12-only","pdflatex -interaction=nonstopmode -halt-on-error Q222_Analytical_Revision_2026-10-18.tex","pdflatex -interaction=nonstopmode -halt-on-error Q222_Analytical_Revision_2026-10-18.tex",chr(96)*3,"","Python 3 and SymPy required for replay. Default replay uses a temporary directory and never rewrites stored receipts. The original full historical verifier was not recovered and is not impersonated.",""]
(ROOT/"CHECKLIST.md").write_text("\n".join(lines))
(ROOT/"START_HERE.txt").write_text("Q222 revision 13 — reconstructed derivative, 19 October 2026\n\nRead CHECKLIST.md and PROOF_STATUS.json for current status.\nFive new all-tests source theorems are registered in ADMISSIONS_REVISION13.json.\nThe global proof remains unfinished: C1.4 and C2.W.HH have explicit residual branches.\nRead Q222_Revision13_Results.pdf for the new mechanism and frontier, then the full manuscript for all dependencies.\nRun python3 verify.py --integrity-only, then --revision13-only.\nCHECKLIST_HANDOFF.json preserves the original ten tasks and criteria exactly.\n\nINPUT LIMITATION: the supplied ZIP was truncated. 644 complete members were recovered and CRC-verified.\nOriginal wrappers/verifier are not claimed recovered. Original root ledgers and provenance are retained.\n")
(ROOT/"README.md").write_text("# Q222 revision 13\n\nStart with CHECKLIST.md. The global existence proof is **unfinished**, with five newly proved all-tests source domains and a smaller explicit frontier.\n\nADMISSIONS_REVISION13.json records theorem evidence, dependencies and gates. The full manuscript retains all recovered mathematical sources and adds revision13. Q222_Revision13_Results.pdf presents the principal new theorem and exact frontier.\n\nThis is a derivative of a truncated handoff. See provenance/RECOVERY_REPORT.json; original revision12 root files are under provenance/revision12_root/.\n\nRun python3 verify.py --integrity-only and python3 verify.py --revision13-only. SymPy 1.14.0 was used for the focused new computations; replay does not rewrite receipts.\n")
print(json.dumps({"admissions":len(admissions),"new_named_checks":named,"new_regularity_audits":regular,"scripts":len(receipts),"global_status":"unfinished"},indent=2))
