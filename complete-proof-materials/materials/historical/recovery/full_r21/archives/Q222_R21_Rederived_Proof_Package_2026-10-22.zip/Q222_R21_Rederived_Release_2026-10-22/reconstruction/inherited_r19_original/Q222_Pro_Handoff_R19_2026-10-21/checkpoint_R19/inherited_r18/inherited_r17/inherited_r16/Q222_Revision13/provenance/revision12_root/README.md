# Q222 analytical revision 12

**The global proof remains unfinished: four original rows are closed, and C1.4 and C2.W.HH remain open. Revision 12 adds a complete remote reduction, not an all-tests source admission.**

On the printed small-(1-r), z/B-unit weak-C2 source chart, every testing pair except u,v both infinitesimal or zero now has a full-parent tensor-SOS proof. A six-root homogeneous identity covers the formerly degenerate reciprocal-u axis without dividing by n or alpha, so literal n=0 is retained.

The exact source identity 2r Delta n = (1-r)Q - BK forces B/(1-r) bounded and shows that setting r=1 at B>0 leaves the nonnegative-source domain. This identifies a real constraint for the still-unproved local certificate. Other source charts and C1 obligations remain as printed in CHECKLIST.md. Earlier proofs and obstruction records are preserved; root ledgers supersede historical frontier statements.

## Reading order

1. Read the short idea, current frontier, and quantifiers at the start of the PDF.
2. Read the revision-12 source-scale lemma and remote reduction, then the revision-11 bounded-test proof and projective join, then the revision-10 boundary extension, then the three-circuit contact lift and five-root Gram. They explain how exact contact equations become finite square roots with bounded coefficients.
3. Follow the proof for the desired original row below. Every closure includes the full original state normals and the projective joins.
4. For remaining work, use CHECKLIST.md. A source slice, leading Gram, or exact reduction is not a whole-domain admission.

| Original row | Current status | Proof entry |
|---|---|---|
| C1.1 | Proved for all original tests | `advances/c1_small/q_unit_completion.tex`, `advances/c1_small/q_inf_local_completion.tex`, `advances/c1_small/q_inf_remote_completion.tex` |
| C1.4 | Open, narrowed | `CHECKLIST.md` |
| C1.5 | Proved for all original tests | `advances/c1_uh/uh_all_tests.tex`, `baseline/advances/c1_ui/ui_all_tests.tex`, `baseline/advances/c1_common/common_remote.tex` |
| C2.S.II_HH | Proved for all original tests | `advances/c2_strong_local/local_strong_ii.tex`, `advances/c2_strong_remote/strong_ii_remote.tex` |
| C2.S.HI | Proved for all original tests | `advances/hi/retained_contact_module.tex`, `advances/hi/full_hi_retained_contact_module.tex` |
| C2.W.HH | Open, narrowed | `CHECKLIST.md` |

## The proof dependency map

```mermaid
flowchart TD
  C["Original contact identities"] --> T["Three-term circuit and conductors"]
  C --> G["Five-root full-parent Gram"]
  T --> N["Complete small-L normals"]
  N --> I["C1 interior: all tests proved"]
  G --> R["Direct remote and endpoint proofs"]
  R --> W["Weak-C2 interior: all tests proved"]
  G --> S["Rescaled root and exact cancellation"]
  S --> E["z/B boundary: all tests proved"]
  E --> B
  G --> H["Normalize both growing state weights"]
  H --> J["Small r: all tests proved"]
  J --> B
  B --> S12["Physical source scale constraint"]
  S12 --> R12["Small-gap remote tests proved"]
  R12 --> L12["Both-infinitesimal local parent open"]
  W --> O["SO1 family removed"]
  I --> B["Remaining source boundaries"]
  W --> B
  B -. "Still required" .-> U["Universal exhaustion and finite-lift bridge"]
```

The remaining gaps concern the source boundaries outside the new admissions. Full-parent weighted control and exact coverage are still required there; symbolic identity checks do not replace those proofs.

## Reproduction

Run `python3 verify.py --integrity-only` for archive integrity, `python3 verify.py --revision12-only` for this revision's 20 new exact identities, or `python3 verify.py --with-sympy` for every listed script. Checkers run in temporary copies. Compile the root TeX twice with pdfLaTeX. The printed proofs use exact algebra and finite-dimensional arguments; numerical positivity tables are not premises.
