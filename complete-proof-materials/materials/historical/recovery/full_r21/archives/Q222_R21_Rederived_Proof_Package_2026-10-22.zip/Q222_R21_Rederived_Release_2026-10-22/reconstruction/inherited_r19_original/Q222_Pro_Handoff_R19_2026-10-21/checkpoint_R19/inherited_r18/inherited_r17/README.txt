Q222 — revision 17 analytical advances

Start with Q222_R17_Analytical_Advances.pdf for the new human-readable proofs, FRONTIER_R17.json for exact current coverage, and Q222_End_to_End_Checklist_R17.txt for every end-to-end obligation.

Whole new admissions: weak-C2 R5 and R8. Inherited whole admissions R9 and R10 remain valid. Several C1 and R4/R6/R7 subdomains are also admitted on their precise hypotheses. The global theorem remains OPEN: six C1 branches and six weak-C2 shapes retain residual domains. This package is not a completed finite-lift proof.

proofs/ contains new analytical sources, exact symbolic checkers, receipts and focused same-system reviews. definitions/ reproduces the complete source and parent identities. inherited_r16/ preserves the entire reconciled prior package and its R13-R16 dependencies. Old status statements are historical; FRONTIER_R17.json and the R17 checklist govern current coverage.

NEXT_AGENT_PROMPT.txt gives the exact continuation target and safeguards against replaying solved work. REVIEW_R17.txt records the root acceptance boundaries.

No numerical samples or tables establish a mathematical admission. The exact checkers corroborate identities; ordered-field bounds, legal tensor roots and the complete joins are the proof. The new source/state admissions do not silently close their residual complements.

Reproduction:
  python -m pip install -r requirements.txt
  python verify.py
  python verify.py --identities
  pdflatex -interaction=nonstopmode -halt-on-error Q222_R17_Analytical_Advances.tex
  pdflatex -interaction=nonstopmode -halt-on-error Q222_R17_Analytical_Advances.tex

The default verifier checks file integrity. --identities executes only new self-contained identity scripts; it can regenerate receipt timing fields, so perform the integrity check before that optional run. Inherited verification has its own instructions and was not replayed for this revision.
