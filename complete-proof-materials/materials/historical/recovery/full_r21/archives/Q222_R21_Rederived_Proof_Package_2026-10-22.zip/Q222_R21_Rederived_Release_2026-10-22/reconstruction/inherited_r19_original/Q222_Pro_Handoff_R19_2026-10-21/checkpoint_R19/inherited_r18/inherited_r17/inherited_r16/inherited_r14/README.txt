Q222 REVISION 14 - PARTIAL ANALYTICAL ADVANCE
20 October 2026

START: Q222_R14_Analytical_Advances.pdf
FRONTIER: Q222_End_to_End_Checklist_R14.txt and FRONTIER_R14.json

Three new full-parent TESTING-SUBCHART proofs: C14.3a (eta,j0 units, bounded v/u), C14.3b (bounded u/v), R9 (bounded v/u). The C14.1a JU8 comparison model also closes on normalized unit-Z states. NONE closes an entire remaining source branch. Six C1 branches and ten weak-C2 shapes still remain as whole-source obligations. The global theorem remains open.

This compact supplement is based on the reconciled Q222_Revision13 package. It does not overwrite or replace the 796-entry R13 source archive. The relevant unchanged R13 modules are included in inherited_reference with exact provenance; the complete R13 package remains the baseline for the upstream proof and global dependencies. The updated end-to-end checklist retains its full historical crosswalk and original acceptance gates.

Reproducibility:
  python verify.py             # verifies the package integrity only
  python verify.py --algebra   # runs only the four new symbolic checkers
Required for --algebra: Python 3 and SymPy (tested version in requirements.txt).
  pdflatex Q222_R14_Analytical_Advances.tex
Run the LaTeX command from this directory. It requires the standard packages listed in the preamble. The PDF contains the new arguments, not a claim of a complete global proof.

62 new exact checks passed. Previous algebra was not replayed. See REVIEW.txt for the precise scope of same-system focused cross-review. No external independent/formal verification is claimed.
