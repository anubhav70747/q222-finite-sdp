import json
from pathlib import Path
import sympy as s
p,v,k,W,X,Y,Z,n,m,C,A,D,al=s.symbols('p v k W X Y Z n m C A D al',real=True)
Dp,Dv=1+p*p,1+v*v
ramp=W-p*Y
Q=X-p*Z
P=v*Y-Z
M=p*v*W-p*X+v*Y-Z
J=W+v*X-p*Y-p*v*Z
core=2*(J**2+Dp*P**2+Dv*(p*X+Z)**2-Dp*Dv*Z**2)
checks={}
def chk(name,lhs,rhs=0):
    val=s.factor(lhs-rhs)
    checks[name]={'pass':val==0,'residual':str(val)}
chk('M_identity',M,Dp*P-p*Q+p*v*ramp)
chk('J_identity',J,ramp+v*Q)
chk('core_identity',core,2*J**2+2*Dp*P**2+2*Dv*(p*Q)**2-4*Dp*Dv*(p*Q)*P+4*Dp*Dv*p*(v*Q/k)*(k*Y)+2*Dp*Dv*(p*Z)**2)
er,eq,r,sy,sz,pp=s.symbols('er eq r sy sz pp',real=True)
mu,mc,ac,acap=s.symbols('mu mc ac acap',positive=True)
# C,D packets retained above a common positive real cap mu/k^2;
# m and alpha retained above positive real caps mc,acap.
gram_poly=(4*mu*Dv*er**2+4*mu*(er+eq)**2
    +4*mc*(Dp*pp-r+p*v*k*er)**2+4*acap*Dp*pp**2
    +4*ac*Dp*Dv*sy**2
    +2*k**2*(er+eq)**2+2*Dp*pp**2+2*Dv*r**2
    -4*Dp*Dv*r*pp+4*Dp*Dv*p*eq*sy+2*Dp*Dv*sz**2)
back={er:ramp/k,eq:v*Q/k,pp:P,r:p*Q,sy:k*Y,sz:p*Z}
full_core=(4*mu/k**2*Dv*ramp**2+4*mu/k**2*J**2+4*mc*M**2+4*acap*Dp*P**2+4*(ac*k**2)*Dp*Dv*Y**2+core)
chk('full_capped_parent_reconstruction',gram_poly.subs(back,simultaneous=True),full_core)
res=s.expand(gram_poly.subs({p:0,v:0,k:0}))
target=4*mu*(er**2+(er+eq)**2)+(4*mc+2)*(pp-r)**2+4*acap*pp**2+4*ac*sy**2+2*sz**2
chk('strict_residue_identity',res,target)
roots=[er,eq,pp,r,sy,sz]
G=s.hessian(res,roots)/2
chk('strict_gram_determinant',G.det(),1024*mu**2*ac*acap*(2*mc+1))
# Exact projective substitution from the original parent, p^2 F(1/p,v).
u=s.symbols('u',real=True)
Du=1+u*u
Mo=v*W-X+u*v*Y-u*Z
Jo=u*W+u*v*X-Y-v*Z
Fo=4*n*Du*Dv*X**2+4*m*Mo**2+4*C*Dv*(u*W-Y)**2+4*A*Du*Dv*Y**2+4*D*Jo**2+4*al*Du*(v*Y-Z)**2+2*(Jo**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)
Fp=4*n*Dp*Dv*X**2+4*m*M**2+4*C*Dv*ramp**2+4*A*Dp*Dv*Y**2+4*D*J**2+4*al*Dp*P**2+core
chk('projective_homogenization',p*p*Fo.subs(u,1/p),Fp)
report={'scope':'Fresh reconstruction of strong C2 UI testing endpoint u=infinity,v=0 only; not all-tests closure.','checks':checks,'passed':sum(x['pass'] for x in checks.values()),'total':len(checks),'all_pass':all(x['pass'] for x in checks.values())}
path=Path(__file__).with_suffix('.json');path.write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
if not report['all_pass']: raise SystemExit(1)
