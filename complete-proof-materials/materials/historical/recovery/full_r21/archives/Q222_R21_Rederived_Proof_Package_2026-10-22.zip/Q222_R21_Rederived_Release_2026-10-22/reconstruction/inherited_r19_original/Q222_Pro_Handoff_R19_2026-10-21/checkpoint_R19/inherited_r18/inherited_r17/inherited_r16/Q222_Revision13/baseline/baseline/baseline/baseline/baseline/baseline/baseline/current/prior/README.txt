Q222 — PHYSICALITY FORCES SOURCE ENTRY
Analytical coverage advance, 17 October 2026

START HERE
Read Q222_Analytical_Coverage_Advance.pdf (editable LaTeX source beside it).
This is a continuation of the contact–circuit–compensation supplement,
included unchanged in prior_core/ with its own sources and manifest.

WHAT IS NEW
1. In the exact positive C2 contact chart, physical sources with all four
   matching weights strong and both complementary weights weak now enter
   an existing radial all-tests certificate. No bound on the contact
   shape or angle, and no comparison of the two weak weights, is assumed.
   Matching probabilities force the actual angles to coalesce; an exact
   reflection and a positive source identity force radial entry.
2. A single weak C2 packet already gives radial entry when the two contact
   parameters a,c are bounded. Other former unit and small-gap hypotheses
   are derived. An exact physical asymmetric path proves that individual
   weak-product bounds and comparability cannot be inferred in general.
3. A physical test curve yields an exact square-root compensation bound.
   It is equivalent to positivity on that restricted test family only.
4. A weak C1 event forces the uniform C1 source entry on the specified
   actual-contact regime. The inherited sign entry and contact minor
   are explicit; complementary regimes are not asserted closed.
5. Homogeneous physical inequalities constrain the six remaining source
   families without assuming bounded normalized weights. These necessary
   inequalities are not all-tests certificates.

PROOF STATUS
This is not a complete atlas-free global proof. See PROOF_STATUS.json.
The new proofs import the previously proved uniform C1 and radial C2
certificates, supplied as source in inherited/. They do not replace the
full retained atlas, establish exhaustive positive-chart entry, or extract
a new global finite SDP pencil. Same-system agent reviews are included;
they are not external peer review.

REPRODUCIBILITY
  python3 verify.py
    Two suites, Python standard library only.
  python3 verify.py --with-sympy
    All five new suites; install requirements-optional.txt if needed.
No numerical sampling, archived coefficient census, or new Groebner basis
is needed for these new checks. The proofs are displayed in the PDF;
checkers audit identities rather than substitute for the deductions.
Run prior_core/verify.py separately to replay the earlier small supplement.
The saved verification/FRESH_CHECKS.json records the five fresh suites.

BUILD
  pdflatex -interaction=nonstopmode -halt-on-error Q222_Analytical_Coverage_Advance.tex
Run twice from this directory. Standard TeX Live article/AMS/TikZ packages
are required. The distribution omits build logs and temporary renderings.

PROVENANCE
The full earlier 61 MB global package is not duplicated here:
  Q222_Human_Computer_Assisted_Proof_Package.zip
  SHA-256 b03308de894eabba15510392a16855b4ee3117140d012a8de1314868bbe0591e
The prior structural supplement embedded under prior_core/ came from:
  Q222_Structural_Simplifications.zip
  SHA-256 0495f46c9605ff3e71cead0cff69bd009821b9a7e9d0bd570f146458c386dd29
Neither the full atlas nor those earlier checks were freshly replayed in
this continuation. MANIFEST.json hashes the distributed files; the nested
manifest retains the earlier supplement's provenance.
