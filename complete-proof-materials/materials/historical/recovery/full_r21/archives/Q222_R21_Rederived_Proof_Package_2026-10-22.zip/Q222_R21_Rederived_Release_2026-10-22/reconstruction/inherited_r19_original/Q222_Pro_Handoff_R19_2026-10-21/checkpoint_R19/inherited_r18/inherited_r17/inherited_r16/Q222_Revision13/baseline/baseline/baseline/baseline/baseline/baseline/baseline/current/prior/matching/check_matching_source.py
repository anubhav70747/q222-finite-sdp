#!/usr/bin/env python3
"""Exact source-reflection and compact matching-kernel identities; SymPy."""
from pathlib import Path
import json
import sympy as s
if not __debug__:raise SystemExit('Run without -O')
q,z,b,r,t=s.symbols('q z b r t',nonzero=True)
def Delta(q,z,b,r):return (1+z)*z*b*b+2*z*(1+z)*b*r+(1+z)*(1+q*z)*b+z*z*(1-q)*r*r+2*z*(1+q*z)*r+1+q*z
D=Delta(q,z,b,r);Dp=Delta(q,1/(q*z),q/b,q*z*r/b)
assert s.factor(Dp-D/(b*b*z*z))==0
h=b-q*t;g=(1+z)*b-(1-r+q*z*t);j=1+z*r-t
zp=1/(q*z);bp=q/b;rp=q*z*r/b;tp=(1-z*h)/b
assert s.factor(bp-q*tp-q*z*h/b)==0
assert s.factor((1+zp)*bp-(1-rp+q*zp*tp)-q*j/b)==0
assert s.factor(1+zp*rp-tp-g/b)==0
assert s.factor(1-rp-(b-q*z*r)/b)==0
assert s.factor(1-zp*(bp-q*tp)-q*t/b)==0
assert s.factor(bp-q*zp*rp-q*(1-r)/b)==0
checks=['Delta reflection','three gap reflections','three positive chart boundaries']
def src(q,z,b,r,t):
 h=b-q*t;g=(1+z)*b-(1-r+q*z*t);j=1+z*r-t
 ac=1+z*r;de=Delta(q,z,b,r);N=(1+z)*(b+r)*h+q*(g+j+r*t*(1+q*z));S=ac+q*z*t
 return [((b+r)*ac*S-r*de)/(2*r*de),(1+q*z)*(1-r)*ac*S/(2*g*de),ac*N/(2*q*t*de),q*ac*(b+r)*S/(2*h*de),(1+z)*(b+r)*(b-q*z*r)*S/(2*q*j*de),z*z*(b+r)*N/(2*(1-z*h)*de)]
ss=src(q,z,b,r,t);sp=src(q,zp,bp,rp,tp)
for i,j in enumerate([0,4,5,3,1,2]):
 assert s.factor(sp[i]-ss[j])==0
 checks.append('event reflection '+str(i))
cu,su,cv,sv,W,X,Y,Z=s.symbols('cu su cv sv W X Y Z')
Rm=cu*sv*W-cu*cv*X+su*sv*Y-su*cv*Z
Rd=su*cv*W+su*sv*X-cu*cv*Y-cu*sv*Z
M=s.Matrix([[s.diff(Rm,W),s.diff(Rm,Z)],[s.diff(Rd,W),s.diff(Rd,Z)]])
assert s.expand(M.det()-((su*cv)**2-(cu*sv)**2))==0
checks.append('compact matching kernel determinant')
report={'status':'PASS','checks':checks,'scope':'Polynomial/rational identities for reflection and kernel geometry; asymptotic inference is proved in the text, not sampled.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
