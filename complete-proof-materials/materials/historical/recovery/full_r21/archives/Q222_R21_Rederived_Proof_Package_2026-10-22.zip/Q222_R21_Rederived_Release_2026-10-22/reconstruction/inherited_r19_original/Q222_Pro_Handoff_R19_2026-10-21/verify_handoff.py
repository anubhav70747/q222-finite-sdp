from pathlib import Path
import hashlib,json,re,subprocess,sys
root=Path(__file__).resolve().parent
manifest=json.loads((root/'HANDOFF_SHA256.json').read_text())
actual={p.relative_to(root).as_posix() for p in root.rglob('*') if p.is_file() and p.name!='HANDOFF_SHA256.json' and '__pycache__' not in p.parts}
assert actual==set(manifest), 'File inventory mismatch'
for name,expected in manifest.items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==expected, 'Changed file: '+name
p=root/'checkpoint_R19'
subprocess.run([sys.executable,str(p/'verify.py')],check=True)
text=(p/'Q222_End_to_End_Checklist_R19.txt').read_text()
base=p/'inherited_r18/inherited_r17/inherited_r16/Q222_Revision13'
refs=sorted(set(re.findall(r'[A-Za-z0-9_./-]+\.(?:tex|json|txt|md|py|pdf)',text)))
for ref in refs: assert (p/ref).is_file() or (base/ref).is_file(), 'Missing checklist reference: '+ref
assert len(refs)==65
print(f'PASS: {len(manifest)} handoff file hashes and all 65 checklist references. Global theorem remains OPEN.')
