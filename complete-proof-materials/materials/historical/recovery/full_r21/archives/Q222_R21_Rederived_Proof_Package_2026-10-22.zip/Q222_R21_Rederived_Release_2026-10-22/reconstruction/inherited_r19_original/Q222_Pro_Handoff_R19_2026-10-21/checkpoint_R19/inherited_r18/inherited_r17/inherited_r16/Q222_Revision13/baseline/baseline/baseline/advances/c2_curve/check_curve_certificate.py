from pathlib import Path
import json
import sympy as s
x=s.symbols('x');Q=4+x-2*x*x
n=(8-5*x*x)/(16*(1+x)**2)
m=3*x*x*(3*x+4)/(16*(1+x)*Q)
C=al=(4-x)/(8*x)
A=x*(x+4)*(3*x+4)/(32*(2-x)*(1+x)**2)
D=(2-x)*(3*x+4)/(16*x*(1+x))
L=32*x*(2-x)*(1+x)**2*Q
weights={'H':L,'n':8*x*(2-x)*Q*(8-5*x*x),'m':24*x**3*(2-x)*(1+x)*(3*x+4),'C':16*(2-x)*(1+x)**2*Q*(4-x),'A':4*x*x*Q*(x+4)*(3*x+4),'D':8*(2-x)**2*(1+x)*Q*(3*x+4),'alpha':16*(2-x)*(1+x)**2*Q*(4-x)}
checks={name:s.cancel(weights[name]-4*L*coef)==0 for name,coef in [('n',n),('m',m),('C',C),('A',A),('D',D),('alpha',al)]}
# Recover all six original positive-chart coefficients, not just a residue.
b=1/x;rr=s.Rational(1,4);tt=s.Rational(1,2);ac=1+x*rr
h=b-tt;g=(1+x)*b-(1-rr+x*tt);j=1+x*rr-tt
delta=(1+x)*x*b*b+2*x*(1+x)*b*rr+(1+x)**2*b+2*x*(1+x)*rr+1+x
num=(1+x)*(b+rr)*(b+1-tt)-(1+x)*(1-rr)*tt
original={'n':((b+rr)*ac*(ac+x*tt)-rr*delta)/(2*rr*delta),'m':(1+x)*(1-rr)*ac*(ac+x*tt)/(2*g*delta),'C':ac*num/(2*tt*delta),'A':ac*(b+rr)*(ac+x*tt)/(2*h*delta),'D':(1+x)*(b+rr)*(b-x*rr)*(ac+x*tt)/(2*j*delta),'alpha':x*x*(b+rr)*num/(2*(1-x*h)*delta)}
for name,coefficient in [('n',n),('m',m),('C',C),('A',A),('D',D),('alpha',al)]:
 checks['original_source_'+name]=s.cancel(original[name]-coefficient)==0
for name,value,want in [('h',h,1/x-s.Rational(1,2)),('g',g,1/x+s.Rational(1,4)-x/2),('j',j,s.Rational(1,2)+x/4),('alpha_gap',1-x*h,x/2),('D_gap',b-x*rr,1/x-x/4)]:
 checks['positive_chart_gap_'+name]=s.cancel(value-want)==0
checks['all_degree_at_most_6']=all(s.degree(w,x)<=6 for w in weights.values())
endpoint={name:int(w.subs(x,0)) for name,w in weights.items()}
checks['endpoint_full_parent_weights']=endpoint=={'H':0,'n':0,'m':0,'C':512,'A':0,'D':512,'alpha':512}
checks['n_positive_interval_numerator']=s.Rational(8)-5*s.Rational(1,4)**2>0
checks['denominator_interval_lower_bound']=s.Rational(4)-2*s.Rational(1,4)**2>0
assert all(checks.values())
checks={name:bool(value) for name,value in checks.items()}
out={'status':'PASS: ALL-TESTS RATIONAL-CURVE CERTIFICATE DATA','checks':checks,'clearing_factor':str(s.factor(L)),'parameter_interval':'0<x<=1/4','degree_bound':6,'tensor_square_bound':2,'square_bound_independent_of_degree':True,'complex_state_uses_one_complete_scalar_polynomial':True,'endpoint_weights':endpoint,'proof_obligation':'Elementary real-closed univariate factorization is proved in rational_curve_tensor_sos.tex; physicality throughout the interval uses the unchanged positive C2 source and inherited stationary-contact/inertia theorem.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
