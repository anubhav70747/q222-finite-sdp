R17 WEAK SOURCE-GAP ADVANCE

NEW ADMISSIONS

1. Entire original R5 shape, all independent projective tests.
   Proof: r5_all_tests.tex
   Focused exact checks: check_r5_all_tests.py/json, PASS 20.
   Independent same-system review: ../matrix_mechanism/review_r5.tex
   Independent direct-Hessian checks:
   ../matrix_mechanism/review_r5_direct.py/json.

2. Original R6 with a=z/B bounded, equivalently 1-r a positive unit,
   all independent projective tests.
   Proof: r6_bounded_a_all_tests.tex
   Focused exact checks: check_r6_bounded_a.py/json, PASS 6.

3. Original R7 with a=z/B bounded, equivalently 1-r a positive unit,
   all independent projective tests. Every allowed r/j combination is covered.
   Proof: r7_bounded_a_all_tests.tex
   Focused exact checks: check_r7_bounded_a.py/json, PASS 18.
   The parallel weak_r8_small_r D gauge is independently reconstructed here
   against the entire WA matrix, exact syzygy and full four-state D event.

EXACT REMAINDER AFTER THESE ADMISSIONS

Use original source definitions t=y/B, h=H/B, l=1-h, a=z/B,
e=1-r, g=G/B, j=1+zr-l/t. U means positive bounded unit,
I positive infinitesimal, O positive unbounded.

R1: t I. Untouched by this directory.
R2: t O. Untouched by this directory.
R3: t,h U; l I. Untouched by this directory.
R4: t,h,l U; j I. Untouched by this directory.
R5: fully admitted; no remainder.
R6: t,h,l,j U; g I; a O, equivalently e I; r=1-e U.
R7: t U; h,g I; a O, equivalently e I; r=1-e U; j may be
    a positive unit or positive infinitesimal. The original exclusion of
    simultaneously infinitesimal r,j is automatic here because r is a unit.

For the R6 and R7 residual endpoints ae has residue 1, since
1-g=a(e-H) and aH=hz is infinitesimal. Every original physicality,
stationary-contact, coefficient-sign, strict-gap, positive-infinitesimal
TOTAL-scale condition and prior-admission exclusion remains intersected.
All original n>=0 values, INCLUDING LITERAL n=0, remain in these a-O
endpoints. No R10, physical-C1 or source-symmetry reduction is asserted.
Their entire independent testing domains remain unless an independently
cited prior admission applies. The endpoint statements do not assert
nonemptiness. R8 and C1 branches are outside this directory's task scope.

LEGALITY AND SCOPE

Every proved theorem retains all normal and hard terms, either sign,
literal projective endpoints and complex states. On the admitted R5 and
bounded-a R6/R7 domains, exact source relations force n>0, so their literal
n=0 intersection is empty rather than omitted. No source/testing rate
comparison or mixed inverse/radical occurs.

The key reusable identity R5.3 retains the full contact-zero centered-m
excess and leaves a bounded full-parent correction proportional to mg.
R7.3 supplies the parallel full D gauge modulo an explicitly zero root
syzygy, leaving Dj times an angular bounded matrix. Neither operation
transfers physicality to a capped source or loses radial/normal jets.

The three focused checkers are self-contained Python programs requiring
only SymPy and the standard library. They do not import exploratory code,
read historical receipts, run numerical sampling, or replay old suites.
For example, from this directory in the present shared environment:
PYTHONPATH=/workspace/scratch/f695f02f9e9c/.proof_dependencies python check_r5_all_tests.py
PYTHONPATH=/workspace/scratch/f695f02f9e9c/.proof_dependencies python check_r6_bounded_a.py
PYTHONPATH=/workspace/scratch/f695f02f9e9c/.proof_dependencies python check_r7_bounded_a.py
