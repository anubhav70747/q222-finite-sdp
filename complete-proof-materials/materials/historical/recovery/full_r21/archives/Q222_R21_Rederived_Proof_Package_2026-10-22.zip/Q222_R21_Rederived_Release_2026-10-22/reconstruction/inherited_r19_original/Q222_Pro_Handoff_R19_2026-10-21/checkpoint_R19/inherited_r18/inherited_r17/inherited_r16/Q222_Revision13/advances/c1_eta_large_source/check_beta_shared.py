"""Narrow exact corroboration of new eta-large source identities only."""
import sympy as s, json, time
from pathlib import Path
start=time.monotonic(); checks=[]
def ck(name, expr):
    num=s.fraction(s.cancel(expr))[0]
    ok=s.expand(num)==0
    checks.append({'name':name,'pass':ok})
    print(('PASS ' if ok else 'FAIL ')+name,flush=True)
    if not ok: raise AssertionError((name,s.factor(num)))
x,z,b,h,sg=s.symbols('x z b h sigma', nonzero=True)
r=b*z;th=1-h;K=1+x;R=1+x*r;M=R-x*z*th;J=1+x*h-sg*(1-r);e=x*h/sg
P=sg+K+sg*z*(1+b*x+2*x*h)+sg*b*x*x*h*z*z+x*x*h*th*z
H0=1+z-r;BB=P+x*z*(J-sg)
HH=R*H0+z*((1-r)*x*h*(2+x*r)-e*(2+x*(1+h+r*th))+K*e*e)
ND=K*(1+sg*z)*(1+sg*r)-J*P
NB=K*(1+sg*r)*(1+x*h*z)-th*P
D=ND/(2*J*P);beta=NB/(2*th*P)
ck('BE3 exact beta numerator',NB-h*BB+sg*H0)
ck('BE4 exact source budget',ND+x*NB-sg*sg*HH)
L,rr,eta=s.symbols('L r eta',nonzero=True)
zz=L/x;yy=L*eta;T=1+x*h;KK=1+x;RR=1+x*rr
Pd=1+2*x*h+rr*x*x*(h+zz)+x*zz+eta*x*(KK*zz+x*h*th)
B5=KK*(1+yy)*(rr+eta)-(eta*T-1+rr)*Pd
b1=-L*h*rr*x-L*h-L*rr+L-h*h*rr*x*x+h*h*rr*x-3*h*h*x-2*h*rr*x+h*x-3*h+1
a0=KK*rr+(1-rr)*(1+L+2*x*h+rr*x*L+rr*x*x*h)
ck('BE1 exact B5 input',B5+x*h*(KK*L+x*th*T)*eta*eta-x*b1*eta-a0)
ck('P equals sigma z Pd',P-sg*z*Pd.subs({L:1/z,rr:r,eta:1/sg}))
HHbar=RR*(1+L*(1-rr))+(1-rr)*x*h*(2+x*rr)-(x*h*eta)*(2+x*(1+h+rr*th))+KK*(x*h*eta)**2
ck('native form source budget',HH/z-HHbar.subs({L:1/z,rr:r,eta:1/sg}))
d2=2*P*J*D/(sg*sg*HH);b2=2*P*x*th*beta/(sg*sg*HH)
ck('source sphere',d2+b2-1)
ck('BE7 positive h split',h/sg-H0/BB-(sg/x)*HH/BB*b2)
kappa=K*(1+sg*r)*(1+sg*z)/(2*M*P)
m=kappa*x*x*z*h/sg;m0=kappa*x*x*z*H0/BB;m1=kappa*x*sg*z*HH/BB
ck('BE8 exact m split',m-m0-m1*b2)
C=K*(1+sg*r)*(1-e)*z/(2*(1-r)*P)
A=(z*(1+x*h)*(1-e)+(1-r)*(1+x*h*z))/(2*b*P*z)
alpha=(1+sg*r)*((x/sg)*R*h*(1+sg*z)+M*(1-e))/(2*(1-b)*P*z)
ck('BE9 opening cleared C',C*(1-r)/z-K*(1+sg*r)*(1-e)/(2*P))
ck('BE9 opening cleared A',A*r-(z*(1+x*h)*(1-e)+(1-r)*(1+x*h*z))/(2*P))
ck('BE9 opening cleared alpha',alpha*(1-b)*z-(1+sg*r)*(e*R*(1+sg*z)+M*(1-e))/(2*P))
u,w,W,X,Y,Z=s.symbols('u w W X Y Z');Du=1+u*u;Dw=1+w*w
Mw=W-w*X+u*Y-u*w*Z;Rw=u*W-Y;Jw=u*w*W+u*X-w*Y-Z;Bw=X+u*Z
Kw=Jw**2+Du*(Y-w*Z)**2+Dw*Bw**2-Du*Dw*Z*Z
# Coefficients are checked once, then all four-state entries are retained.
mm,mm0,mm1,dd,bb,cc,aa,ll,dd2,bb2,pp,jj,HHs,xx,ss,tt=s.symbols('m m0 m1 D beta C A alpha d2 b2 P J HH x sigma theta')
raw=4*mm*Mw**2+4*cc*Dw*Rw**2+4*aa*Du*Dw*Y*Y+4*dd*Jw**2+4*ll*Du*(Y-w*Z)**2+4*bb*Dw*Bw**2+2*Kw
normalized=4*mm0*Mw**2+4*mm1*bb2*Mw**2+4*cc*Dw*Rw**2+4*aa*Du*Dw*Y*Y+2*ss*ss*HHs/(pp*jj)*dd2*Jw**2+4*ll*Du*(Y-w*Z)**2+2*ss*ss*HHs/(pp*xx*tt)*bb2*Dw*Bw**2+2*Kw
repl={mm:mm0+mm1*bb2,dd:ss*ss*HHs*dd2/(2*pp*jj),bb:ss*ss*HHs*bb2/(2*pp*xx*tt)}
ck('BE10 entire four-state parent',raw.subs(repl)-normalized)
U0,U1,V0,V1=s.symbols('U0 U1 V0 V1')
ck('BE10 entire bihomogeneous parent',s.together((raw.subs(repl)-normalized).subs({u:U1/U0,w:V1/V0})*U0**2*V0**2))
Nx=s.symbols('Nx');t=u*u
qblock=(4*dd*t+4*bb+2*(1+t))*Nx*Nx+4*u*(-2*dd*(1+t*h)+2*bb*th-h*(1+t))*Nx*Z+(4*dd*(1+t*h)**2+4*bb*t*th*th+2*t*(1+t)*h*h)*Z*Z
wy=4*mm*(W+u*Y)**2+4*cc*(u*W-Y)**2+(4*(aa+ll)+2)*(1+t)*Y*Y
ck('BE11 complete normal slice',raw.subs({w:0,X:Nx-u*h*Z})-wy-qblock)
ck('BE12 h square split',x*h*h/(sg*sg)-e*H0/BB-HH*h/BB*b2)
cz=(4*D*(1+t*h)**2+4*beta*t*th*th+2*t*(1+t)*h*h)
liftz=2*HH/(P*J)*(1+t*h)**2*d2*sg*sg+2*HH*(th/P+(1+t)*h/BB)*b2*t/x*sg*sg+2*(1+t)*H0/BB*e*t/x*sg*sg
ck('BE12 exact positive normal lift',cz-liftz)
Ax=H0/BB*(x*z*(J-sg)/P-t)-H0/P
# First combine the two Ax terms using the separately checked sphere.
# Clear each budget denominator before expanding the remaining source identity.
cross_reduced=NB/P-h*(1+t)-sg*Ax-NB/BB*(x*z*(J-sg)/P-t)
ck('exact first normal cross lift',cross_reduced)
ck('literal D zero null direction',raw.subs({u:0,w:0,W:0,X:0,Y:0,Z:1,dd:0}))
out={'scope':'C14.1/C14.2 exact beta-shared source normalization and a normal-frame diagnostic; no admission','passed':len(checks),'checks':checks,'seconds':round(time.monotonic()-start,3)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(f'{len(checks)} exact assertions passed in {out["seconds"]} seconds')
