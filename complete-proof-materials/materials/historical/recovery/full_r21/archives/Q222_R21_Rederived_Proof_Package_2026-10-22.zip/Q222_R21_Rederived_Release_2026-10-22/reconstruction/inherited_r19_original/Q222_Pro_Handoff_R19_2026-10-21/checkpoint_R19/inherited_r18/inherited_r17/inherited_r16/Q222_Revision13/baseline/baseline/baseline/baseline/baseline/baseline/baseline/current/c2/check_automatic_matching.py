#!/usr/bin/env python3
"""Exact matching-floor witnesses and one-weak positive C2 escape."""
from pathlib import Path
import json
import sympy as s
if not __debug__:
    raise SystemExit('Run without -O: assertions are proof checks.')
u,v,W,X,Y,Z=s.symbols('u v W X Y Z')
lam,n,m,C,A,D,alpha,beta,d=s.symbols('lambda n m C A D alpha beta d')
Du,Dv=1+u*u,1+v*v
R2=v*W-X+u*v*Y-u*Z;R3=u*W-Y
R5=u*W+u*v*X-Y-v*Z;Ra=v*Y-Z;Rb=X+u*Z
F=4*lam*Du*(W+v*X)**2+4*n*Du*Dv*X*X+4*m*R2*R2
F+=4*C*Dv*R3*R3+4*A*Du*Dv*Y*Y+4*D*R5*R5+4*alpha*Du*Ra*Ra
H=2*(R5*R5+Du*Ra*Ra+Dv*Rb*Rb-Du*Dv*Z*Z)
F+=4*beta*Dv*Rb*Rb+d*H
# Exact Tsirelson scaling used in the chart-free small-angle entry proof.
L=Du*Dv
M=s.hessian(H,(W,X,Y,Z))/2
J=s.Matrix([[0,0,0,1],[0,0,-1,0],[0,-1,0,0],[1,0,0,0]])
assert J*J==s.eye(4)
assert ((M-L*s.eye(4))**2-L**2*s.eye(4)-4*u*v*L*J).applyfunc(s.expand)==s.zeros(4)
rt=s.sqrt(2)
witnesses={
 'D':((1,rt,1,0,0,rt),4*D-2*d+8*lam+12*C+16*alpha+24*beta),
 'm':((1,rt,1,0,0,1/rt),2*m-d+8*lam+12*C+4*alpha+6*beta),
 'n':((rt,1,-3,1,0,-2*rt),24*n-12*d+48*lam+144*C+96*alpha+72*beta),
 'A':((rt,1,2*rt,0,1,3),24*A-12*d+96*lam+72*C+48*alpha+144*beta)}
for name,(point,expected) in witnesses.items():
    actual=s.expand(F.subs(dict(zip((u,v,W,X,Y,Z),point)),simultaneous=True))
    assert s.simplify(actual-expected)==0,name
    leading=expected.coeff({'D':D,'m':m,'n':n,'A':A}[name])
    assert expected.coeff(d)==-leading/2
    assert max(expected.coeff(e)/leading for e in (lam,C,alpha,beta))==6
x=s.symbols('x',positive=True)
z=s.Integer(1);q=1/x;r=h=j=s.Rational(1,4);t=s.Integer(1)
b=1/x+s.Rational(1,4);g=1/x-s.Rational(1,4)
assert s.cancel(b-q*t-h)==0
assert s.cancel((1+z)*b-(1-r+q*z*t)-g)==0
assert s.cancel(1+z*r-t-j)==0
delta=((1+z)*z*b*b+2*z*(1+z)*b*r+(1+z)*(1+q*z)*b
       +z*z*(1-q)*r*r+2*z*(1+q*z)*r+1+q*z)
N=(1+z)*(b+r)*(b+q*(1-t))-q*(1+q*z)*(1-r)*t
ac=1+z*r;ss=ac+q*z*t
nw=((b+r)*ac*ss-r*delta)/(2*r*delta)
mw=(1+q*z)*(1-r)*ac*ss/(2*g*delta)
cw=ac*N/(2*q*t*delta)
aw=q*ac*(b+r)*ss/(2*h*delta)
dw=(1+z)*(b+r)*(b-q*z*r)*ss/(2*q*j*delta)
alw=z*z*(b+r)*N/(2*(1-z*h)*delta)
targets={'x2_Delta':(x*x*delta,4),'x2_N':(x*x*N,s.Rational(5,4)),
         'n':(nw,s.Rational(1,8)),'D':(dw,s.Rational(3,4)),
         'C_over_x':(cw/x,s.Rational(25,128)),
         'm_over_x':(mw/x,s.Rational(15,128)),
         'x_A':(x*aw,s.Rational(5,8)),
         'x_alpha':(x*alw,s.Rational(5,24))}
limits={}
for name,(expr,expected) in targets.items():
    actual=s.limit(s.cancel(expr),x,0,dir='+')
    assert actual==expected,(name,actual,expected)
    limits[name]=str(actual)
# Verify the one-weak family's actual full-parent stationary contact.
# Multiply its Z=1 state by a to avoid inverses of the formal square root.
aa=s.symbols('a')
contact={u:1,v:aa,W:b,X:-aa*r,Y:h,Z:aa}
coefs={lam:0,beta:0,d:1,n:nw,m:mw,C:cw,A:aw,D:dw,alpha:alw}
contact_checks=0
for expr in [F]+[s.diff(F,var) for var in (W,X,Y,Z,u,v)]:
    poly=s.Poly(s.expand(expr.subs(contact,simultaneous=True)),aa)
    by_parity=[s.Integer(0),s.Integer(0)]
    for (degree,),coefficient in poly.terms():
        by_parity[degree%2]+=coefficient*q**(degree//2)
    for remainder in by_parity:
        assert s.cancel(remainder.subs(coefs,simultaneous=True))==0
        contact_checks+=1
reflection={'b':q/b,'r':q*z*r/b,'h':q*z*h/b,'g':q*j/b,
            'j':g/b,'t':(1-z*h)/b}
for name,expected in [('b',1),('r',s.Rational(1,4)),('h',s.Rational(1,4)),
                      ('g',s.Rational(1,4)),('j',1),('t',0)]:
    assert s.limit(reflection[name],x,0,dir='+')==expected,name
assert s.cancel(reflection['t']-3*x/(4+x))==0
report={'status':'PASS','full_parent_floor_witnesses':list(witnesses),
        'core_matrix_identity':'(M-LI)^2=L^2 I+4uvL J, J^2=I',
        'normalized_core_bound':'H >= -2uv for u,v>0 and norm-one states',
        'universal_conclusion':'every matching e >= d/2-6T',
        'one_weak_escape_limits':limits,
        'one_weak_full_parent_contact_checks':contact_checks,
        'scope':'Automatic matching strength closes the whole two-weak positive C2 chart via the existing entry theorem; the one-weak escape is identified, not certified.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
