"""Exact leading C1 UI determinant; not a full-parent certificate."""
import sympy as s,json
from pathlib import Path
u,v,W,Y,Z,H,C,A,D,al,d=s.symbols('u v W Y Z H C A D al d')
U,T=s.symbols('U T',positive=True)
Du=1+u*u
f=4*H*v*v*(W+u*Y)**2+4*C*(u*W-Y)**2+4*A*Du*Y*Y+(4*D+2*d)*(u*W-Y-v*Du*Z)**2+4*al*Du*Z*Z-4*d*Du*v*Y*Z-2*d*Du*v*v*Z*Z
L=A*C*(D+d/2)*U+H*al*(A+C+D+d/2)/U+A*al*(C+D+d/2)/T+H*D*(A+C+d/2)*T/U+H*C*(D+d/2)*U*T+H*(A*D+2*C*D+A*d/2+C*d/2+D*d/2+d*d/4)*T+A*C*D-A*D*d/2+H*al*(C+D+d/2)-d*d*(A+C+D)/4-d**3/8
checks=[]
def check(name,expr):
    assert s.factor(expr)==0,name
    checks.append(name)
check('full three-state determinant Laurent factorization',(s.hessian(f,(W,Y,Z))/2).det()-64*Du*Du*u*u*v*v*L.subs({U:u*u,T:v*v}))
x,r,e=s.symbols('x r e',positive=True)
K=1+x;R=1+x*r;E=1-x*e;P4=K*E+x*(1-r);Pd=1+2*x+r*x*x;a=(1-r)/e;J=K-a
source={H:2*x*e/(R*E),C:2/a,A:2*e*e*P4/(K*r*(r+e)*E),D:2/(J*E)-2*e*Pd/(K*(r+e)*E),al:2*x*x*e*R/(K*E),d:4*e*Pd/(K*(r+e)*E)}
for name,expr in [('contact value',L),('contact U derivative',s.diff(L,U)),('contact T derivative',s.diff(L,T))]:
    check(name,s.factor(expr.subs({U:x,T:x*e})).subs(source))
# Hard D constraint: W=Y/u+v Du Z/u. Only C,A,H,al,d remain.
fd=s.expand(f.subs(W,Y/u+v*Du*Z/u))
LD=H*T*((C+A+d/2)/U+(2*C+A+d/2)+C*U)+H*al*(1+1/U)+A*C*(U+1)+A*al/T-A*d/2-d*d/4
check('corrected D-deleted Laurent (outer coefficients)', (s.hessian(fd,(Y,Z))/2).det()-16*Du*Du*v*v*LD.subs({U:u*u,T:v*v}))
# Exact two-event elimination, before taking the model limit.
h2,hb,rr,tt,nn,ll,gg=s.symbols('h2 hb rr tt nn ll gg')
pp=tt/rr;mm=rr-tt
original=4*h2/mm*((1-pp)*ll-nn)**2+4*hb/tt*(1+v*v)*(nn+pp*ll)**2
retained=4*h2*tt/(mm*rr)*nn**2+4*hb*mm/(tt*rr)*(1+v*v)*nn**2
remainder=4/rr*((h2+hb*(1+v*v))*nn**2+2*(hb*(1+v*v)-h2)*ll*nn+(h2*(1-pp)+hb*pp*(1+v*v))*ll**2)
check('exact m beta retained-packet reduction CL7',original-retained-remainder)
efull=1-x*e+tt*x*e*gg**2
h2full=2*x*e*(1-tt*gg**2)*(1+x*e*gg**2)/efull
hbfull=2*x*e*(1+(1-tt)*gg**2)/efull
check('exact bounded hbeta minus h2',hbfull-h2full-2*x*e*gg**2)
result={'status':'PASS','count':len(checks),'checks':checks,'scope':'Leading polynomial only. Full-state normal lift at arbitrary independent source/test rates remains open.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
