#!/usr/bin/env python3
"""Exact narrow checks for the weak-II support obstruction and source slice Gram."""
import json
from pathlib import Path
import sympy as s
z,y,H,L,r=s.symbols('z y H L r', positive=True)
B=H+L; h=H/B; ac=1+z*r; Sc=ac+L; T=B+z*r
G=B+z*(H+r-1); j=ac-L/y
Delta=z+(1+z)*B+(1+z)*B**2+2*z*(1+z)*B*r+z**3*r**2+2*z**2*r+y*((1+z)*B+z+z**2*r*(2-r))
Ms=(1+z)*T*(H+y)-z*(1+y)*(1-r)*L
n=(T*ac*Sc-r*Delta)/(2*r*Delta)
m=z*z*(1+y)*(1-r)*ac*Sc/(2*G*Delta)
C=ac*Ms/(2*L*Delta); A=y*ac*T*Sc/(2*H*Delta)
D=(1+z)*T*(B-z*y*r)*Sc/(2*y*j*Delta)
al=T*Ms/(2*(1-H)*Delta)
w01=m*B**2/z
w10=((C+D+s.Rational(1,2))*L**2+A*H**2)/y
w11=2*m*B*H+C*L**2+(A+al+s.Rational(1,2))*H**2
w20=A*z*H**2/y; w21=z*H**2*(m+A+al+s.Rational(1,2))
z00=al; z01=D*y
z10=z*(n*r*r+(m+s.Rational(1,2))*(1-r)**2+al)
z11=z*y*((n+s.Rational(1,2))*r*r+2*D*r)
z20=n*r*r*z*z; z21=z*z*y*(n+D+s.Rational(1,2))*r*r
b0=m*(1-r)+D*(1-h)+al*h+s.Rational(1,2)
b1=m*h*(1-r)+r*(D+s.Rational(1,2))*(1-h)+(al+s.Rational(1,2))*h
P0=w01+z00+z01; P2=w10+w11+z10+z11; P4=w20+w21+z20+z21
N0=2*B*b0; N1=2*B*z*b1; q=P4-N1/2
results={}
def check(name,expr):
    ok=s.factor(expr)==0
    print(name, ok, flush=True)
    results[name]=ok
    assert ok,name
check('source_contact_value',P0+P2+P4-N0-N1)
check('source_contact_first_u',2*P2+4*P4-N0-3*N1)
check('quartic_q_two_forms',q-(P0-N0/2))
check('quartic_middle',P2-(P0+P4-4*q))
# Independent block identities do not need a large determinant expansion.
bb,gg,hh,zz,yy,rr,ll,jj,aa=s.symbols('bb gg hh zz yy rr ll jj aa')
check('m_block_det',bb**2*hh**2-hh**2*(bb-gg)**2-hh**2*gg*(2*bb-gg))
check('D_block_det',yy**2-(zz*yy*rr-ll)**2-(yy*(1-zz*rr)+ll)*(yy*(1+zz*rr)-ll))
check('alpha_block_det',zz*hh**2-zz**2*hh**2*(1-hh)**2-zz*hh**2*(1-zz*(1-hh)**2))
qrem=z*(A*H**2*(1+y)/y+n*r*r*z*(1+y)+(H**2+z*y*r*r-r*L-H)/2)
check('cross_block_decomposition',q-(-m*H*(B-G)+D*z*r*(z*y*r-L)-al*z*H*(1-H)+qrem))
# One exact contact-admissible noncoercive source curve; global physicality is not certified.
eps=s.symbols('eps', positive=True)
sub={H:eps**2,L:eps-eps**2,z:eps/2,y:2*eps,r:s.Rational(9,10)}
def lim(expr):
    return s.limit(s.cancel(expr.subs(sub)),eps,0,dir='+')
expected={'n':s.Rational(1,27),'m':s.Rational(1,114),'C':s.Rational(19,20),
          'D':s.Rational(29,60),'eps_A':s.Rational(29,30),
          'alpha_over_B2':s.Rational(551,400),
          'P4_over_Bz':s.Rational(3,200),'b1':s.Rational(177,200)}
values={'n':n,'m':m,'C':C,'D':D,'eps_A':eps*A,'alpha_over_B2':al/B**2,
        'P4_over_Bz':P4/(B*z),'b1':b1}
curve={k:str(lim(v)) for k,v in values.items()}
for k,v in expected.items():
    assert lim(values[k])==v,(k,curve[k],v)
results['curve_coefficient_and_mass_limits']=True
curve_gaps={k:str(lim(v)) for k,v in {
    'H_over_eps2':H/eps**2,'L_over_eps':L/eps,'one_minus_H':1-H,
    'r':r,'one_minus_r':1-r,'G_over_eps':G/eps,'j':j,
    'B_minus_zyr_over_eps':(B-z*y*r)/eps,'Delta_over_eps':Delta/eps,
    'Ms_over_eps2':Ms/eps**2}.items()}
assert all(s.Rational(v)>0 for v in curve_gaps.values())
results['curve_all_original_strict_gaps']=True
assert expected['P4_over_Bz']<expected['b1']
results['separate_circuit_mass_inequality_fails']=True
out={'checks':results,'count':len(results),'curve_limits':curve,'curve_gap_limits':curve_gaps,
     'scope':'Separate-circuit support obstruction on the algebraically contact-admissible domain only; curve global physicality is unverified. Source-only quartic PSD requires preserved original physicality. No weak-II full tensor admission.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
