# Exact scale reduction for unbounded b at actual (Inf,unit) C2 contacts

This is a source-scale classification, not an all-tests certificate. Use the original positive rational C2 chart (now supplied globally by `c2_global_entry.md`), d=1, actual u=√x positive infinitesimal and v=k positive bounded unit. Set

B=xb, H=xh, L=x(b−h)=B−H, a²=k²/x, t=L/k².

Assume b is unbounded. The exact positive-chart inequalities give

0<H<1, 0<L<k²(1+xr), B=H+L.

Thus B,H,L are bounded, and B>0. Also B/x=b is unbounded, so x/B=1/b is infinitesimal. Put `S=1+xr+L` and `Ac=1+xr`; both are positive bounded units. The original g,j satisfy

g/b=1+(r−1)/b+H/b →1,
j=1+xr−L/k²>0 and j≤1+x.

Two exact rearrangements control every coefficient:

x²N=(1+x)(B+xr)(H+k²)−x(1+k²)(1−r)L,

Δ/b=(1+x)B+2x(1+x)r+(1+x)(1+k²)
      +(x²−k²x)r²/b+2x(1+k²)r/b+(1+k²)/b.

It follows that `xN/b = x²N/B` and `Δ/b` are positive bounded units, with respective residues H₀+k₀² and B₀+1+k₀². (Here H≤B makes the divided correction xL/B infinitesimal.)

Physical n≥0 is the exact inequality

r(Δ/b)≤(1+r/b)AcS.

Taking residues gives

r₀≤(1+L₀)/(1+k₀²+B₀),
1−r₀≥(k₀²+H₀)/(1+k₀²+B₀)>0.

Hence 1−r is a positive bounded unit, independently of how small r is.

The original coefficient formulas now give the following exact comparabilities: every omitted factor in `≈` is a positive bounded unit, with bounded reciprocal,

m≈b^−2,
C≈L^−1,
A≈H^−1,
D≈B/j,
α≈B/(1−H).

For example `CL=Ac(xN/b)/(2Δ/b)` is a positive bounded unit, while
`AH=k²Ac(1+r/b)S/(2Δ/b)` is another. For D and α divide by b and use `(b−k²r)/b→1`. For m use g/b→1 and the proved positive lower bound for 1−r.

This gives two exhaustive unbounded-b cases. If B is a positive bounded unit, the arbitrary-complementary-scale strong theorem applies. If B is infinitesimal, the homogeneous full-parent theorem in ../c2_unbounded/unbounded_b_small_B.tex applies, including n=0 and arbitrary B/sigma. Both cases are now closed. Together with the bounded-b opening admissions and global positive-chart entry, this covers every actual (I,U) C2 contact; reflection covers (U,H).
