# Focused audit of the weak-source C1 D-unit curvature

17 October 2026. Same-team analytical audit of `newton/WEAK_SOURCE_DUNIT_LOCAL_ADMISSION.md`, focused on the source units, source scales, and the two determinant-to-Schur normalization constants. This is not external verification.

Set `p=u_c^2`, `w=v_c^2`; `p` is positive infinitesimal and `w` is a positive unit. Source coefficients are nonnegative and bounded, `d,D` are positive units, and the source is physical. Every `t_i` is consequently a bounded positive unit. Retain the factors four in the determinant coefficients:

\[
\begin{aligned}
q_{01}&=4\alpha m t_5t_8,&q_{02}&=4mDt_5t_6,\\
q_{10}&=4\alpha A t_7t_3,&q_{12}&=4(\beta m t_1t_6+cDt_5t_2),\\
q_{21}&=4cAt_1t_4,&q_{22}&=4\beta ct_1t_2.
\end{aligned}
\]

## 1. Forced units, without an extra Q-unit hypothesis

Put `Q=q21+q22 w` and `N=q10/w`. Exact stationary balance is

\[
 q_{01}+q_{02}w=p^2Q,\qquad
 N=q_{02}w/p+q_{12}w+q_{22}pw.
\tag{1}
\]

Since `Q` is bounded, the first equality and `D` a unit imply `m=O(p^2)` and hence `m` weak. If `c` were weak, then `q12,q21,q22` would be weak, while `q01,q02` are already weak. The second equality then makes `q10` weak as well: its first summand is at most `pQ`, and all remaining summands are weak. This makes every outer determinant residue zero, contradicting the fixed-real-angle physical rank-zero exclusions in the companion covariance proof. Therefore `c` is a unit.

Now `c,D` units force `q12` unit. The nonnegative second equality in (1) forces `N` and `q10` units, hence `alpha,A` units. Thus `Q` is a unit as well. This proves

\[
 \boxed{\alpha,A,c,D,Q,N\text{ are positive units}.}\tag{2}
\]

Finally the undivided first equality gives the exact identity

\[
 \frac{m}{p^2}=\frac{Q}{4t_5(\alpha t_8+Dt_6w)}.
\tag{3}
\]

The denominator is a positive source-only unit. Thus `m/p^2` is a positive bounded unit. In original half-angle notation this is `m asymp u_c^4`, not `m asymp u_c^2`. The newton note uses `p=u_c^2` consistently.

## 2. Hard-state determinant really is a unit

At the residue edge `u=0` with `m=0`, the original C1 parent is

\[
 (4\beta+2d)(1+v^2)X^2+
 [4(c+A)+2d](1+v^2)Y^2+
 4D(Y+vZ)^2+4\alpha(vY-Z)^2.
\]

For unit `v` and (2), this is positive definite on `(X,Y,Z)`. Hence the original `XYZ` principal block at the actual source contact has a positive unit determinant. Its inverse and the normalization of the contact's unit W component are permitted pure-source operations.

## 3. Exact determinant-to-curvature constants

Write the cleared determinant as

\[
 \det P=16(1+U)^2(1+V)^2\,D(U,V),
\]

where on C1

\[
 D(U,V)=q_{01}V+q_{02}V^2+q_{10}U+hUV
       +q_{12}UV^2+q_{21}U^2V+q_{22}U^2V^2.
\]

At `U=p,V=w`, zero and stationarity imply

\[
 D_{UU}=2wQ,\qquad D_{vv}=8pN.\tag{4}
\]

The second derivative here is with respect to the half-angle `v`, with `V=v^2`; the first is with respect to the squared half-angle `U`. Derivatives of the positive prefactor vanish from the second-derivative formulas because `D` and its first derivatives vanish at contact. Therefore, with `A_hard` the original `XYZ` principal block,

\[
 \boxed{\frac{(\det P)_{UU}}{2\det A_{\rm hard}}
 =\frac{16(1+p)^2(1+w)^2 wQ}{\det A_{\rm hard}},}\tag{5}
\]

\[
 \boxed{\frac{(\det P)_{vv}}{2p\det A_{\rm hard}}
 =\frac{64(1+p)^2(1+w)^2 N}{\det A_{\rm hard}}.}\tag{6}
\]

Both are positive bounded units. These constants agree with the weighted roots `s=U-p`, `t=u(v-v_c)`. The first relaxed coefficient is a U-second derivative divided by two; the second needs the extra factor `p` because the testing opening multiplies the angle displacement in `t`.

## 4. Audit of the state crosses used for these limits

The parity transport produces

\[
 b_X=b_{X0}(v)+Ub_{X1}(v),\quad
 b_Y=u[g_{Y0}(v)+Ug_{Y1}(v)],\quad
 b_Z=u[g_{Z0}(v)+Ug_{Z1}(v)].
\]

All polynomial coefficients are bounded and `bX0=O(p)` coefficientwise. At contact `b=0`. Hence

\[
 b_{Y,U},b_{Z,U}=O(u_c),\qquad b_{X,v}=O(p),
\]

whereas `bX,U`, `bY,v/u_c`, `bZ,v/u_c` have bounded limits giving the claimed residue Gram crosses. Consequently the source Schur identities (5)--(6) do recover the two full residue block complements; they are not inferred from the two scalar Gram diagonal entries alone.

I also checked the exact scalar identity in Section 3 of the newton note analytically: expansion at `v_c`, followed by `f=f_U=f_v=0`, gives precisely its terms `Cs^2+Bust+rsj+a0j^2+(a1+a2U)t^2`. Its substitution `j=ut-s(v-v_c)` uses only bounded coefficients in the stated testing corner. No curvature gap or normalization error was found. The theorem's stated local testing scope must be retained.

The companion `WEAK_C1_DUNIT_CURVATURE_AUDIT.py` verifies (4)--(6) symbolically from the generic stationary determinant. It does not duplicate the complete parent expansion.
