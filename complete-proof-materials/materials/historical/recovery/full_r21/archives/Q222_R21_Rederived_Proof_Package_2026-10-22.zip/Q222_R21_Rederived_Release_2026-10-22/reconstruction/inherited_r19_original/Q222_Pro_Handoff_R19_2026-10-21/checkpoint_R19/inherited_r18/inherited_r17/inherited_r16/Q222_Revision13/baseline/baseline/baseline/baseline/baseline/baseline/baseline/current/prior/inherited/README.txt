INHERITED ANALYTICAL INPUTS

These source files are retained from the preceding human proof package.
DEPENDENCIES.json records the closure of explicit TeX labels and inputs.
The main continuation PDF describes which results it imports; inclusion
here does not freshly certify every historical claim or status statement.
Use the package-root PROOF_STATUS.json for the present frontier.

Core algebra: Q222_Pen_Paper_Companion.tex, section "The elementary
mechanism: positive residue pays for errors", proves the positive-residue,
strict bounded Gram, and pure-factor restoration lemmas.

C2 source and certificates: c2_unified.tex, c2_y_current.tex,
c2_radial_corner.tex, c2_radial_all_tests.tex, c2_uniform_all_tests.tex,
c2_matching_strength.tex; the old matching budget is also reproduced in
../prior_core/geometry/retained_frame_and_matching_budget.tex.

C1 source entry: C1_GLOBAL_SIGN_ENTRY.md, sections 6–7, equations 9–10.
C1 certificate: c1_uniform_all_tests.tex and c1_unbounded_e_w_unit.tex.
The continuation displays the contact minor and names its prerequisites.

Other included files resolve these modules' original cross-references.
