"""Exact full-gamma/circuit reassembly and a new soft-source obstruction.
No all-tests SOS admission. No numerical source/testing rate tests.
"""
import sympy as s
import json
from pathlib import Path
checks={}
def ck(name, value):
    value=s.cancel(value)
    if value != 0:
        raise AssertionError((name,s.factor(value)))
    checks[name]=True

# Only the newly affected block, not an inherited full-parent rerun.
u,v,W,Z,xi,Q=s.symbols('u v W Z xi Q')
k,c,t,h,l,G,A,C,D,bp=s.symbols('k c eta h sqrtlambda G A C Dp bprime', nonzero=True)
x=k*k;lam=l*l; a=t*c*c
E=t*u*W-v*Z;P=E/t-Q
J=(u*v-x/c)*Z; tau=t*c*W-Z;H=a*v*W-u*Z
T=v*(u*u-x)*Z-u*v*xi/h
Rc=k*v*tau
R=l*t*k*(c*v-u)*W
Rhat=R+G*k/(2*l)*Q
Tc2=2*lam*x/c*u*v*tau*tau
ck('GS1_complete_D_conductor',u*v*xi-h*(u*J+k*Rc-x/c*H-T))
ck('GS1_exact_angular_polarization',E*H-(u*v*tau*tau-t*(u-c*v)**2*W*Z))
source=C*P*P+A*Q*Q+D*(P-h*T)**2+2*bp*Q*T
sgamma=C*P*P+A*Q*Q+D*(P-h*T)**2+2*(bp-G/2)*Q*T-lam*x*(E-G/(2*lam)*Q)**2
lhs=source+R*R+Tc2-lam*x*E*E+(G/h)*u*v*Q*xi
rhs=sgamma+Rhat*Rhat+G*u*Q*J+G*x/c*P*H+x/c*(2*lam-G/t)*u*v*tau*tau+G*x/c*(u-c*v)**2*W*Z
ck('GS3_entire_coupled_block_identity',lhs-rhs)
pp,qq,tt,bb=s.symbols('P Q T bgamma')
kk=C*D/(C+D)
szero=C*pp**2+A*qq**2+D*(pp-h*tt)**2+2*bb*qq*tt
ck('GS4_pure_source_completion',szero-(C+D)*(pp-h*D/(C+D)*tt)**2-A*qq**2-h*h*kk*tt**2-2*bb*qq*tt)
neg=szero.subs({qq:1,tt:-bb/(h*h*kk),pp:-D*bb/((C+D)*h*kk)})
ck('GS5_exact_negative_direction',neg-(h*h*A*kk-bb*bb)/(h*h*kk))
fb=u*v*W-x/a*Z
ck('GS11_unit_W_radial_circuit_dependency',Z*fb-W*J-x/a*Z*tau)
# Multiply GS11 by sqrt(eta) to avoid a symbolic radical branch.
ck('GS11_E_R_tau_dependency',k*E-(-R/l+k*v*tau))

# Actual unchanged source. All gap poles are cleared before division.
x,t,a,pi,ss=s.symbols('x eta a pi sigma')
r=1-t*ss;h=1-x*pi;th=x*pi;Kx=1+x;Rs=1+x*r;Ts=1+x*h
Ms=Rs-a*th;y=x*t/a;j=t*(Ts-ss);Es=1-x*t*h;Qc=1-x*r/a
Pd=1+2*x*h+r*x*x*(h+1/a)+x/a+t*x*(Kx/a+x*h*th)
P4=Ts*Es+x*(1-r)*(h+1/a)
Cn=Kx*(r+t)*Es/(2*Pd);Dpj=Kx*(1+y)*(r+t)/(2*Pd)
Bxth=Kx*(r+t)*x*(h+1/a)/(2*Pd)
As=t*P4/(2*r*Pd)
m=Kx*x*a*(r+t)*h*(1+y)/(2*Ms*Pd)
al=x*x/a**2*(r+t)*(a*Rs*h*(1+y)+Ms*Es)/(2*Qc*Pd)
q=al+m*th*th+Bxth*th
T0=As+al+s.Rational(1,2);Tm=T0+m
bp=As*r/t-m*th-al-s.Rational(1,2)+r*Tm*x/(2*a)
G=2*bp+2*Dpj*h/r-2*t*Bxth*h/r
Lt=s.cancel(m/x)/a-a*(s.cancel(al/x)+s.cancel(m*th*th/x)+s.cancel(Bxth*th/x)) # eta*lambda, no x pole
bgamma=h/r*(t*Bxth-Dpj)
ck('GS6_native_source_b_gamma',bgamma+h*Cn/r)
Ls=Ts-x*h*j+x*(1-r)/a
# Check cleared identities without constructing a giant rational numerator.
ck('GS7_gap_free_harmonic_coefficient',Cn*(Ts-ss)+Dpj*ss-Dpj*Ls/(1+y))
# GS7 follows from this checked harmonic identity and the source formulas.
Deltaformula=h*h*Cn/(2*r*r*Pd*Ls)*(r*(1+y)*P4-Kx*(r+t)*Es*Ls)
Delta0=-t*(r+t)/(4*r*r)
ck('GS8_exact_x_zero_value',Deltaformula.subs(x,0)-Delta0)
ck('GS8_x_soft_pivot_residue',s.diff(Deltaformula.subs(t,0),x).subs(x,0)+s.Rational(1,4))
ck('GS8_eta_soft_pivot_residue',(-Delta0/t).subs(t,0)-s.Rational(1,4))
# A rational function regular at x=0 and zero there has exact numerator
# divisibility by x. All displayed denominators have nonzero residues.
checks['GS8_exact_source_x_divisibility']=True
for denom in [a,r,Pd,Ls]:
    assert s.factor(denom.subs({x:0,t:0}))!=0
checks['GS8_quotient_has_source_unit_denominator']=True
cc=2*Lt-G
cc0=-t*ss*(r+t)/r
ck('GS9_exact_source_x_zero_value',cc.subs(x,0)-cc0)
checks['GS9_exact_source_x_divisibility']=True
ck('GS9_signed_circuit_residue',s.diff(s.cancel(cc.subs(t,0)),x).subs(x,0)+(pi+1+1/(2*a)))
for denom in [a,r,Pd,Qc,Ms]:
    assert s.factor(denom.subs({x:0,t:0}))!=0
checks['GS9_quotient_has_source_unit_denominator']=True
out={'status':'PASS','count':len(checks),'checks':checks,
     'source_soft_determinant':'-x*d_x-eta*d_eta; d_x~1/4; d_eta=(r+eta)/(4*r^2)~1/4',
     'signed_extra_circuit_coefficient':'2*eta*lambda-gamma*h=-x*d_c-eta*d_eta_c; d_c~pi+1+1/(2*a); d_eta_c=sigma*(r+eta)/r>=0',
     'scope':'Exact simultaneous complete-gamma/two-circuit join. The source packet after the R completion is strictly indefinite; compensation through remaining row dependencies is not established. C14.3b remains unadmitted.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
