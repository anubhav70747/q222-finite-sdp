# Scoped review of the bounded-delta centered-A extension

Reviewer: `c1_scale_review`, a separate agent in the same system. This is an author-independent scoped review, not external peer review or formal verification.

## Outcome and domain

PASS for the stated C1 all-tests extension, conditional on the inherited native-source and outer-routing lemmas explicitly cited in the manuscript. No additional mathematical gap was found when delta is positive infinitesimal. The exact admitted domain is the unchanged physical native C1 parent with k, zeta, and r positive infinitesimals, eta a positive bounded unit, and e bounded below by a positive real number. It includes unbounded e, arbitrary positive opening rates, arbitrary k^2/r, and literal beta = 0. It does not admit infinitesimal e, unbounded eta, or a global source cover.

Reviewed `centered_a_bounded_delta.tex`, `scaled_centered_source.py`, and `check_scaled_centered_contact.py` against `oct18b_c1/centered_a_unit_e.tex`, `centered_a_outer.tex`, `bounded_e_all_tests.tex`, and the original `iconic_c1/source_definitions.tex` and `contact_conductor_proof.tex`.

## Complete parent and scaling

The original SD2–SD4 packet identity accounts for every original event and the complete signed core. Subtracting the centered positive square CA1 gives CA5 exactly. Multiplication of that entire remainder by delta^2, and substitution Mhat = delta M_B, Yhat = delta Y, What = delta W, gives CS1 term by term. N is not rescaled. In particular qB retains its N dependence, so the first-normal and hard-normal cross terms are not being discarded.

The changed B2 and Bb coefficients cancel delta^2 against Delta^2 through Delta = delta Q/K. Every other coefficient in CS1 uses only nonnegative powers of delta. Source denominators are positive units: E, K, Q, R, T, a, and the cancelled tilde-c3 and their finite products. The testing denominator is a power of Du, also a positive unit in the contact chart. None of delta, ell, k, M, J, or t is inverted in the bounded Gram.

Undoing the positive pure-coefficient factor delta^2 at the end multiplies SOS roots by the pure-coefficient inverse delta^{-1}. This is allowed in the full tensor product and does not introduce an unbounded Gram coefficient or a mixed inverse. The same distinction applies to restoration of the original retained packets, whose source-only opening ratios need not be bounded.

## Full rational remainder, beyond its finite truncation

The full ideal-membership argument remains valid without making delta a unit. Here is a direct check that is useful for the new case. At zero normals,

    qA = A0 Du,
    delta qB = B0 Du (1 - p u v w).

Both Yhat and u What therefore lie in (B0,C0) with bounded coefficients; the factor 1/E needed for delta u w is a permitted unit inverse. These statements give membership of every scalar term of CS1 in (A0,B0,C0)^2, except possibly the alpha constant. That constant is controlled by the exact identity

    alpha delta^2 / D0^2 = 2 a tilde(c_alpha) / tilde(c3).

The right side is bounded and has no delta or k inverse. Thus the complete scalar belongs to (A0,B0,C0)^2 + (D0^2), with no prohibited mixed D0 products. The signed-core cancellation is also exact:

    (v Yhat - delta)^2 - delta^2 Dv
      = v^2 Yhat^2 - 2 B0 Yhat - B0^2.

Differentiating the complete CS1 before setting the normals to zero proves that both full first normals belong to (A0,B0,C0). For example, the Mhat derivative of the core contains v(v Yhat - delta), which is in this ideal, and the N derivatives of What and Yhat contain delta u v. All derivative coefficients remain bounded.

The original contact and full stationarity identities, together with exact contact vanishing of all retained squares, give the required scalar second-order and normal first-order contact conditions. Clear only the displayed finite unit denominators. The inherited conductor is polynomial: its domain cancellations establish zero identities, and its construction forms coefficients by monic division only. It never forms the inverse of delta or of the contact-gradient determinant. It consequently works over the present coefficient ring with delta merely bounded.

The contact substitutions preserve weights (delta,k,E,ell,t,u,w,v) = (0,1,0,1,0,1,1,2). Weight zero for delta does not assert that delta is a unit. The displayed low-weight polynomial itself has the necessary raw and contact memberships. Subtracting it therefore preserves those memberships for the rational remainder. Scalar corrections start at weight seven, whereas soft-root products have weights at most six; normal corrections start at weight four, whereas their soft roots have weights at most three. The conductor construction preserves the resulting positive coefficient weights. These coefficients have zero residue even when delta is infinitesimal.

## Exact replay and strictness

The scaled contact checker completed successfully. It verifies the exact finite coefficient collection through the displayed weights, all complete first normals to the required weights, the hard-block residue, polynomial monic lifts of those finite collections, the absence of forbidden negative exponents in those lifts, and the coupled determinant. Its output is

    scalar Gram = diag-block(4(E+4)/E^2, [[8/E,-8/E],[-8/E,8/E]], 8/E),
    q1^2 coefficient = 16/E,
    N normal = 0,
    Mhat normal = 8(E+2)x/E,
    hard block = diag(16/E, 4(E^2+4)/E).

The coupled (Mhat,x) determinant is exactly 256/E^3 > 0. The unchanged separated two-pairing circuit makes the other soft directions strict. Neither the residue Gram nor its strictness requires a positive residue of delta.

The inherited outer checker was also rerun successfully: 30 recorded exact checks, including the selected full-parent identity, both complete centered-root allocations, and their determinants. These exact algebra checks corroborate the proof; they do not themselves establish coverage or check every higher rational term.

## Outer charts and boundary join

In CAO2, m/d is e^2 times a positive unit divided by the bounded positive opening M. A positive real lower bound for e therefore supplies precisely the lower bound required by the old clipping argument. For unbounded e the ratio m/d is unbounded, which strengthens that premise. The other ratios, Ar, d, and the D dichotomy depend on k,zeta,r,eta and the bounded openings, whose stated residues remain unchanged.

The original outer routing BE2–BE4 only uses these lower bounds and the inherited noncommuting-residue admission. Its projective-infinity and zero-axis identities do not use delta^{-1}. The subsequent exact centered-A identity CAO6 depends on H = sqrt(A)(Y-r uW), h = A^{-1/2}, Ar, and the selected real caps; it also contains no delta or e. Therefore its ordinary-u and unit-w strict Grams remain valid. The maximal-coordinate state argument and sign gauges leave exactly the positive infinitesimal u,v,w contact chart treated by CS1–CS4. Complex states split into their real and imaginary evaluations. Literal beta = 0 is retained; the source D lower bound rules out literal D = 0 on this admitted slice rather than silently routing it elsewhere.

## Editorial corrections requested from the author

Two descriptions should be made precise before packaging:

1. The finite checker verifies the complete lifts of the displayed low-weight collection. The full higher rational remainder is justified by the general membership, conductor, and weight argument above, not by a finite replay label.
2. The `scaled_centered_source.py` module description should not call delta a positive unit. Only E can occur with negative exponents in the scaled calculation; delta is a positive bounded element.

These are documentation corrections, not additional unproved mathematical requirements. Subject to them, admitting the former C1.2 leaf is supported by this scoped review.
