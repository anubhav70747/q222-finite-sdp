# C2 finite pitchfork: unbounded complementary coefficients

Status: research checkpoint, **no new all-tests admission** beyond the audited theorems `c2_two_large_events_pitchfork.tex` and `c2_three_large_events_pitchfork.tex`.

## Domain and notation

Set d to a positive bounded unit by a pure coefficient scaling. Let C/d and alpha/d be bounded below by positive real constants, but possibly unbounded. Keep a physical C2 source, lambda=beta=0, n,m,A,D nonnegative, and an actual finite stationary zero with u_c=k positive infinitesimal and v_c=a a positive bounded unit. The parent and amplitudes are (TD1).

## Established necessary source reduction

Capping C,alpha at positive bounded units in the initial hard-block estimate, and retaining the nonnegative excesses, gives W_c nonzero, and after W_c=1,

    X_c,Y_c,Z_c = O(k),       m = O(k^2).

Put y=Y_c/k, z=Z_c/k, x_1=X_c/k and j=J_c/k. These are bounded. Every positive event packet is O(k^2), because the bounded capped parent is bounded below by -B k^2 and its complementary retained packets are nonnegative. Therefore

    A y^2, D j^2, C(1-y)^2, alpha(a y-z)^2

are bounded. Also j=1-y-a z+a X_c.

1. **If C is unbounded, both A and D are bounded.**

   C(1-y)^2 bounded implies y has residue one. Thus A y^2 bounded forces A bounded. If D were unbounded, j would be infinitesimal and hence z infinitesimal. In the signed core,

       H/(2k^2) = j^2 + (1+k^2)(a y-z)^2
                  +(1+a^2)(x_1+Z_c)^2
                  -(1+k^2)(1+a^2)z^2,

   the residue would then equal a_bar^2+(1+a_bar^2)x_1_bar^2>0. This contradicts H<=0 at the physical zero, since every event packet is nonnegative.

2. **If alpha is unbounded, A is bounded.**

   Otherwise A y^2 bounded gives y infinitesimal and alpha(a y-z)^2 bounded gives z infinitesimal. Then j has residue one. The same signed-core formula has residue 1+(1+a_bar^2)x_1_bar^2>0, again impossible.

These are necessary conditions only. They make the remaining finite-pitchfork scale alternatives substantially smaller:

- C and alpha bounded units: the new audited three-large-event theorem covers n,A,D without upper bounds.
- C unbounded: A,D bounded; alpha may be bounded or unbounded.
- C a bounded unit and alpha unbounded: A bounded; D may be unbounded.

The last two alternatives are **not proved all-tests domains** in this checkpoint. No claim that A,D are bounded below is included here.

## Candidate next hard-coordinate choices, not completed proofs

For C unbounded, A,D bounded, a plausible graph keeps the three amplitudes X, r=uW-Y, p=vY-Z. Use source-normalized constants x=X_c/k^2, r_0=r_c/k and p_0=p_c/k, and graph

    X=x u^2 W,  r=r_0 uW,  p=p_0 uW,
    Y=(1-r_0)uW,  Z=[v(1-r_0)-p_0]uW.

Its scaled hard normals would be sqrt(d+2n) X, sqrt(C) r and sqrt(alpha) p. Required, not yet established here: bounded (d+2n)x, C r_0, alpha p_0; a positive-unit m/k^4; strict residue after the full scalar and first-normal division; all independent testing residues, not just v~a.

For C bounded and alpha unbounded, A bounded, a plausible graph keeps X,J,p. With graph J=j_0 uW, p=p_0 uW and X=xu^2W, solve

    Y=u[1-j_0+v p_0+xu^2v]W/(1+v^2),
    Z=vY-p_0 uW.

The inverse 1/(1+v^2) is pure testing and bounded on finite testing charts. Candidate hard normals use sqrt(d+2n), sqrt(D), sqrt(alpha); a positive lower bound for D would have to be proved before using 1/sqrt(D). The coupled state Y,Z equations have flux matrix proportional to [[-1,a],[-a,-1]], whose determinant 1+a^2 is a coefficient unit. This suggests bounding D j_0 and alpha p_0 jointly once the other packet coefficients are bounded. It is not a finished full-parent certificate.

The remaining proof tasks are scale entry from the original Laurent stationary equations, whole-parent normal membership, residue strictness, and the all-tests dispatch. No atlas replay or numerical test was run for these candidates.
