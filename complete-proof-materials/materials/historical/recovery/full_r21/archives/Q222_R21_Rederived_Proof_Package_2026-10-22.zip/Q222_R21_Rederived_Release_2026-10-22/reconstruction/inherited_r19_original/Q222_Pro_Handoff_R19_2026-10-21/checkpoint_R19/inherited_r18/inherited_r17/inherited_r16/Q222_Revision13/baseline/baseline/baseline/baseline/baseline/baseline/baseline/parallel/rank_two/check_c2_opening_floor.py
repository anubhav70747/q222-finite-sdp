#!/usr/bin/env python3
"""Exact symbolic C2 opening-floor checks; requires SymPy."""
from pathlib import Path
import json
import sympy as s
u,v,n,m,c,A,D,alpha,d=s.symbols('u v n m c A D alpha d')
Du,Dv=1+u*u,1+v*v
eX=s.Matrix([0,1,0,0]);eY=s.Matrix([0,0,1,0]);eZ=s.Matrix([0,0,0,1])
eM=s.Matrix([v,-1,u*v,-u]);eD=s.Matrix([u,u*v,-1,-v])
ec=s.Matrix([u,0,-1,0]);ea=s.Matrix([0,0,v,-1]);eb=s.Matrix([0,1,0,u])
P=4*n*Du*Dv*eX*eX.T+4*m*eM*eM.T+4*c*Dv*ec*ec.T
P+=4*A*Du*Dv*eY*eY.T+(4*D+2*d)*eD*eD.T
P+=(4*alpha+2*d)*Du*ea*ea.T+2*d*Dv*eb*eb.T-2*d*Du*Dv*eZ*eZ.T
psi=s.Matrix([1,0,0,1]);chi=s.Matrix([0,1,-1,0]);V=s.Matrix.hstack(psi,chi)
Q=V.T*P.subs(v,u)*V
q=n+m+A+D;w=c+alpha
expected=4*Du*s.Matrix([[c*u*u+alpha,u*(w+d)],
                         [u*(w+d),(q+d)*Du+c+alpha*u*u]])
assert all(s.expand(x)==0 for x in Q-expected)
poly=c*(q+d+alpha)*u**4+(w*(q-d)-2*c*alpha-d*d)*u*u+alpha*(q+d+c)
assert s.expand(Q.det()-16*Du**2*poly)==0
assert s.factor(Q.subs(u,1).det()-64*(2*w*q-d*d))==0
P0=P.subs({c:0,alpha:0})
L1=4*A*n*u*u-(4*A*n+2*d*(A+n)+d*d)*v*v
L2=(4*D*m+2*d*(D+m)+d*d)*u*u-4*D*m*v*v
assert s.factor(P0.det(method='domain-ge')-16*Du**2*Dv**2*L1*L2)==0
receipt={'status':'PASS','arithmetic':'exact symbolic polynomial identities',
 'checks':['full equal-angle two-state compression','radial quadratic coefficients',
           'unit-angle opening floor','full determinant of doubly absent face'],
 'necessary_condition':'2*(c+alpha)*(n+m+A+D)>=d**2',
 'global_sufficiency_claimed':False}
Path(__file__).with_name('C2_OPENING_CHECK_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt))
