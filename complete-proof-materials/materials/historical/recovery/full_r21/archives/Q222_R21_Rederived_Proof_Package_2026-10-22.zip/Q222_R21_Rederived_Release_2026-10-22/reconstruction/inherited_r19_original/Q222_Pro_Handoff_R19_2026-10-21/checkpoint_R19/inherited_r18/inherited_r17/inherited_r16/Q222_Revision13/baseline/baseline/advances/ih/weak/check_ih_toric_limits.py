"""Exact radial obstruction for the proposed unrestricted IH Gram."""
from pathlib import Path
import sympy as s,json
ns={}
exec(Path(__file__).with_name('check_ih_source.py').read_text().split("e=s.symbols('e',positive=True)")[0],ns)
z,y,H,L,R=[ns[k] for k in ['z','y','H','L','R']]
B=H+L;r=R/z;e=s.symbols('e',positive=True)
n,m,C,A,D,al=[ns['weights'][name] for name in ['n','m','C','A','D','alpha']]
N=4*n+2
K=4*A*H**2+8*D*H*r+4*al*(1-H)**2+4*m*(H+r-1)**2+2*(H+r-1)**2+4*n*r*r
k=s.factor(K-4*B*B*m/z**2+8*z*n*r*r+8*A*H*H/y)
sub={z:e**2,y:e**-4,H:s.Rational(1,2),L:1/e-s.Rational(1,2),R:e**8/4}
checks=[];leading={}
quantities={'k':(k,e**3),'r2N':(r*r*N,e**9/2),'cross_squared':(k*k/(B*B*r*r*N),2/e),'k_Br':(k/(B*r),4/e**2)}
for name,(expr,expected) in quantities.items():
 val=s.factor(expr.subs(sub));assert s.factor(val.as_leading_term(e)-expected)==0,name
 checks.append('unbounded-radial family '+name);leading[name]=str(expected)
Dt=ns['Dt']
assert s.factor(k.subs(R,0)-2*H*B*(L+1)/Dt.subs(R,0))==0
checks.append('nonzero exact formal r-zero k term')
G=ns['G']
gaps={'r':r,'1-r':1-r,'h':H/z,'t':L/y,'g':G/z,'j':1+R-L/y,'1-zh':1-H,'b-y*r':(B-y*R)/z,'n':n}
for name,expr in gaps.items():
 leading_gap=s.factor(expr.subs(sub)).as_leading_term(e)
 assert leading_gap.as_coeff_Mul()[0]>0,(name,leading_gap)
 checks.append('physical obstruction source '+name)
result={'status':'PASS','count':len(checks),'checks':checks,'leading':leading,'scope':'Exact failure of boundedness for the initial unrestricted IH Gram. The exact rational curve is separately all-tests admitted by cor:rational-physical-source-curve; this is a method obstruction, not an SOS counterexample.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
