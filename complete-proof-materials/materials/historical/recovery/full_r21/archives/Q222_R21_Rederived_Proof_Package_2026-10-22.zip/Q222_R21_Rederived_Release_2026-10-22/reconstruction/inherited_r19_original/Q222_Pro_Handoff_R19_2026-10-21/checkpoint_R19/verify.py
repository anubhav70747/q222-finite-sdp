"""Verify this checkpoint; optionally rerun only its 41 new exact assertions."""
from pathlib import Path
import argparse, hashlib, json, shutil, subprocess, sys, tempfile

ROOT = Path(__file__).resolve().parent

def digest(p):
    with p.open('rb') as f:
        return hashlib.file_digest(f, 'sha256').hexdigest()

def check_integrity():
    manifest = json.loads((ROOT/'MANIFEST_SHA256.json').read_text())
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*')
              if p.is_file() and p.name != 'MANIFEST_SHA256.json' and '__pycache__' not in p.parts}
    expected = set(manifest['files'])
    assert actual == expected, {'missing': sorted(expected-actual), 'extra': sorted(actual-expected)}
    for name, sha in manifest['files'].items():
        assert digest(ROOT/name) == sha, 'Changed file: '+name
    f = json.loads((ROOT/'FRONTIER_R19.json').read_text())
    assert f['revision'] == 19 and f['global_theorem'] == 'OPEN'
    assert f['open_C1'] == ['C14.1a','C14.1b','C14.4']
    assert f['open_weak_C2'] == ['R1','R2','R3','R4','R6','R7']
    assert f['C1']['C14.2']['status'] == 'ALL TESTS AND STATES'
    assert f['C1']['C14.2']['remaining'] == 'None within C14.2.'
    refs = []
    def walk(v, key=''):
        if isinstance(v,dict):
            for k,x in v.items(): walk(x,k)
        elif isinstance(v,list):
            for x in v: walk(x,key)
        elif isinstance(v,str) and (key == 'evidence' or key == 'report'):
            refs.append(v)
    walk(f)
    for ref in refs: assert (ROOT/ref).is_file(), 'Missing frontier dependency: '+ref
    receipt = json.loads((ROOT/'VERIFICATION_R19.json').read_text())
    assert receipt['count'] == sum(x['count'] for x in receipt['scripts']) == 41
    for row in receipt['scripts']:
        p = ROOT/row['script']
        assert p.is_file()
        recorded = json.loads(p.with_suffix('.json').read_text())
        assert recorded['status'] == row['status'] == 'PASS'
        assert recorded['count'] == row['count']
        assert len(recorded['checks']) == row['count'] and all(recorded['checks'].values())
    print(f'PASS: {len(expected)} file hashes; {len(refs)} frontier references; C14.2 closed, global theorem OPEN.')
    return receipt

def rerun_identities(receipt):
    with tempfile.TemporaryDirectory(prefix='q222-r19-') as temp:
        dest = Path(temp)
        for row in receipt['scripts']:
            src = ROOT/row['script']; target = dest/row['script']
            target.parent.mkdir(parents=True,exist_ok=True)
            shutil.copy2(src,target)
            result = subprocess.run([sys.executable,str(target)],capture_output=True,text=True)
            if result.returncode:
                raise RuntimeError(row['script']+'\n'+result.stdout+'\n'+result.stderr)
            new = json.loads(target.with_suffix('.json').read_text())
            assert new['status'] == 'PASS' and new['count'] == row['count']
            assert len(new['checks']) == row['count'] and all(new['checks'].values())
            print(f"PASS: {row['script']} ({row['count']} exact assertions)")
    print('PASS: all 41 focused exact assertions. Analytical scope and boundedness arguments remain required.')

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--identities',action='store_true',help='Needs SymPy; runs in a temporary copy.')
    args = parser.parse_args()
    receipt = check_integrity()
    if args.identities: rerun_identities(receipt)
