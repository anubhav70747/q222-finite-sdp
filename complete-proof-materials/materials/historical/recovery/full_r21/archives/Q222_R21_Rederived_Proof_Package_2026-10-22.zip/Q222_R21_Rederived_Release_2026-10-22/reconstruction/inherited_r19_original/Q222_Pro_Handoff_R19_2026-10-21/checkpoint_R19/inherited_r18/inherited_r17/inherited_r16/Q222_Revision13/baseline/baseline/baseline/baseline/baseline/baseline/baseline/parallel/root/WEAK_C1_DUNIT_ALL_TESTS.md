# All independent tests for the one-weak-source C1 D-unit branch

## Theorem

Let the bounded, nonnegative, normalized original C1 source be physical. Assume d,D have positive residues and an actual stationary zero contact has uc>0 infinitesimal, vc>0 a finite unit. Then the full original parent at every independent testing angle pair and state is a finite tensor sum of squares. Literal beta=0 is included. This theorem uses the exact local weighted construction in `newton/WEAK_SOURCE_DUNIT_LOCAL_ADMISSION.md` and extends its testing quantifier completely.

The source hypotheses force c,A,alpha,D to be positive units, m/uc^4 to be a positive bounded unit, and the residue state kernel at u=0 to be W. These forced units and the local weighted proof are independently checked in `rank_two/WEAK_C1_DUNIT_CURVATURE_AUDIT.md`.

## 1. Exact residue determinant

Put p=uc^2, w=vc^2, and write bars for real residues. The outer stationarity equations imply

    bar(q01)=bar(q02)=0,
    bar(q10)=bar(q12)*bar(w)^2,
    bar(q11)=-2*bar(q12)*bar(w).

For the last equality use the exact contact equation for the cleared determinant D(p,w)=0 divided by the positive pure-source p. The terms q01/p and q02/p are O(p), since m=O(p^2). Every other term containing p tends to zero. Thus the full real-residue determinant polynomial is exactly

    bar(D)(U,V)=U*bar(q12)*(V-bar(w))^2
               +U^2*V*[bar(q21)+bar(q22)*V].                 (1)

Here bar(q12),bar(q21)>0. This is a fixed real polynomial identity, not an asymptotic expansion of independent variables.

## 2. Testing u infinitesimal: a bounded four-feature baseline away from vc

Retain the exact nonnegative original m event packet separately. Set m=0 only in the remaining baseline. Every occurrence of W in that baseline has a factor u, so there is an exact polynomial Gram

    F_baseline=eta^T H(u,v) eta,
    eta=(X,Y,Z,uW).

Its coefficients are bounded in the finite v chart. Replacing W by eta4/u is only a way to identify the polynomial coefficients: no u inverse occurs in H, and the identity is valid at u=0. The state congruence gives the polynomial identity det P_baseline=u^2 det H. The real-residue baseline equals the real-residue full parent since m is weak. From (1), at testing u of zero residue,

    det bar(H)(0,v)=16(1+v^2)^2 bar(q12)*(v^2-bar(w))^2.     (2)

The XYZ hard block has positive-definite residue for every real finite v, by the exact u=0 edge square form and the positive-unit alpha,D pivots. Thus H has positive-definite residue whenever the testing v residue differs from the signed contact residues. The signs reduce by the exact full-parent sign conjugation, so only positive vc is needed.

At testing v of zero residue, (2) is strictly positive because q10 is a unit. In the reciprocal v chart, its leading term is 16 bar(q12)>0, so H is also strict at v infinity. These are direct strict bounded Grams, and the retained m event restores the original parent.

If v has the same positive real residue as vc, the local weighted theorem supplies the complete full-parent five-feature Gram on

    (hX,hY,hZ,(u^2-p)W,u(v-vc)W).

No rate comparison between u and uc is required. This covers every test with u of zero residue.

## 3. Ordinary testing u and the other projective boundaries

For ordinary nonzero testing u,v, (1) is strictly positive because q21 is a unit. The three positive hard directions imply strict state positivity. For ordinary u and v=0 or infinity, the explicit edge square forms are strict using c,A,alpha,D. The same is true for u infinity and ordinary v.

At corner (infinity,0), the C1 source-only corner stiffnesses are

    4alpha[d+2(m+beta)]/[d+2(m+alpha+beta)],
    4c(d+2D)/[d+2(c+D)],

both positive units even though m is weak. Thus the exact finite five-feature corner argument applies.

At corner (infinity,infinity), a unit beta gives a strict state matrix. If beta is weak, retain its original positive event separately and set beta=0 in the local baseline. The C1 corner stiffnesses are then

    4Dd/(d+2D),
    4A[d+2(m+alpha)]/[d+2(m+A+alpha)],

again positive units. The hard three-state block is strict. No global physicality of this baseline is needed.

Every projective testing regime is now included. Homogeneity restores arbitrary states and pure-testing factors restore projective charts and the normalized physical matrix B. This proves the theorem.

## Scope

The result closes one complete one-weak-source family, rather than merely a matching testing neighborhood. Weak D, two degenerating source angles, and normalized d of zero residue remain outside the new shortcut. The original retained global analytical proof is unchanged; this result is a new replacement terminal within it, not an extracted global affine pencil.
