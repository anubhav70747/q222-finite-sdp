#!/usr/bin/env python3
"""Verify the delivered R21 recovery package, with an optional exact replay.

The restored earlier checkpoint and these new scoped arguments do not replace
the missing completed late-R21 release.  PASS here means the checks explicitly
listed below passed, not that the missing global proof has been reconstructed.
"""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import time
from concurrent.futures import ThreadPoolExecutor

HERE=Path(__file__).resolve().parent
BASE=HERE/'reconstruction/salvaged_checkpoint/Q222_Recovery_Continuation_R21_2026-10-21'
SUITES=[
 ('actual source and scalar', 'c144/rederived/check_r1_qo_compact_source.py',44),
 ('small normal budgets', 'c144/rederived/check_r1_qo_small_normal_budgets.py',6),
 ('full local R1 conductor', 'weak_c2/check_fn_reconstruction.py',43),
 ('structural R2 source entry', 'weak_c2/check_r2_source_entry_reconstruction.py',17),
 ('full-state/sign/projective join', 'root_rederived/check_full_state_sign_join_REDERIVED.py',24),
 ('physical complete-parent normalization', 'root_rederived/check_physical_parent_REDERIVED.py',12),
]

def digest(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda:stream.read(1024*1024),b''):
            h.update(block)
    return h.hexdigest()

def check_manifest():
    manifest=json.loads((HERE/'MANIFEST_SHA256.json').read_text())
    bad=[]
    for rel,record in manifest['files'].items():
        p=Path(rel)
        if p.is_absolute() or '..' in p.parts:
            raise AssertionError('Unsafe manifest member: '+rel)
        target=HERE/p
        if (not target.is_file() or target.is_symlink()
            or target.stat().st_size!=record['bytes']
            or digest(target)!=record['sha256']):
            bad.append(rel)
    if bad:
        raise AssertionError('Missing or mismatched files: '+json.dumps(bad,indent=2))
    status=json.loads((HERE/'RECOVERY_STATUS.json').read_text())
    assert status['late_release_status']=='PARTIAL_RECONSTRUCTION',status
    print(f"PASS {len(manifest['files'])} delivered reconstruction-file hashes")

def check_saved_checkpoint():
    env=dict(os.environ)
    env['PYTHONDONTWRITEBYTECODE']='1'
    result=subprocess.run([sys.executable,str(BASE/'checkpoint_R21/verify.py')],
                          cwd=BASE,capture_output=True,text=True,env=env)
    print(result.stdout.rstrip())
    if result.stderr:
        print(result.stderr.rstrip(),file=sys.stderr)
    if result.returncode:
        raise RuntimeError('Earlier checkpoint verification failed')
    if 'Global theorem remains OPEN' not in result.stdout:
        raise AssertionError('Expected earlier checkpoint scope message missing')

def quick_replay():
    if importlib.util.find_spec('sympy') is None:
        raise RuntimeError('Quick replay needs SymPy. Install requirements-replay.txt first.')
    import sympy
    print('Exact replay using SymPy '+sympy.__version__)
    env=dict(os.environ)
    env['PYTHONDONTWRITEBYTECODE']='1'
    with tempfile.TemporaryDirectory(prefix='q222_r21_replay_') as directory:
        copied=Path(directory)/'restored_context'
        shutil.copytree(HERE/'reconstruction/restored_context',copied,
                        ignore=shutil.ignore_patterns('__pycache__','*.pyc','validation'))
        def run(suite):
            name,rel,expected=suite
            script=copied/rel
            start=time.monotonic()
            result=subprocess.run([sys.executable,str(script)],cwd=script.parent,
                                  capture_output=True,text=True,env=env,timeout=180)
            if result.returncode:
                raise RuntimeError(name+' failed:\n'+result.stdout+'\n'+result.stderr)
            receipt=json.loads(script.with_suffix('.json').read_text())
            count=receipt.get('assertion_count',receipt.get('count',receipt.get('checks')))
            if not isinstance(count,int):
                raise AssertionError(name+' has no integer assertion count')
            assert receipt['status']=='PASS' and count==expected,(name,receipt)
            return {'name':name,'script':rel,'status':'PASS','assertions':count,
                    'elapsed_seconds':round(time.monotonic()-start,3)}
        with ThreadPoolExecutor(max_workers=3) as pool:
            records=list(pool.map(run,SUITES))
        for record in records:
            print('PASS replay '+record['name']+' ('+str(record['assertions'])+' scoped exact assertions)')
        print('The six groups overlap; their assertion counts are not a completeness total.')

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--replay',choices=['quick'],help='Run the six fresh exact suites in a temporary copy')
    args=parser.parse_args()
    check_manifest()
    check_saved_checkpoint()
    if args.replay:
        quick_replay()
    print('PASS: package integrity and the requested scoped checks.')
    print('SCOPE: partial reconstruction of the late release; the missing whole-row/global proofs remain missing.')

if __name__=='__main__':
    main()
