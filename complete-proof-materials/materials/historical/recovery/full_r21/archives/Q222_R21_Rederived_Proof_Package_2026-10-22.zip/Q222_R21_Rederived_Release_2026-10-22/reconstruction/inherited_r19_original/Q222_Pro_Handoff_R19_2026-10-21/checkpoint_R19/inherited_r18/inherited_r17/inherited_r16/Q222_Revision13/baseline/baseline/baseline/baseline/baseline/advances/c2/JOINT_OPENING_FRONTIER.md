# Joint C2 opening: exact scalar reduction, full-normal obstruction

Status: proved scalar reduction and exact algebraic identities; **not a
full-parent tensor-SOS theorem**. No source-coverage closure is claimed.

Use the exact single-angle source in the current package, with k,b units,
x>0 infinitesimal, r,g>0 infinitesimal. Then b0=1, and both n and m can
be unbounded at unrelated rates. For this note assume additionally that
h and b-h are units. The identities below require a finite nonzero
testing angle v; testing u is near the zero residue axis.

Put U=u² and B=1+g-r=b+xh. In the state chart Z=1 use

    Xg=-r u,
    Yg=h U/v,
    Wg=u(B-h U)/v.

This is an exact-contact graph: at u=√x,v=k it equals the original
contact. The original positive m amplitude is exactly

    M=vW-X+uvY-u = g u.

Thus the large n,m packets contribute 4nr²DuDv u² and 4mg²u² to
the whole graph scalar. The source identities nr=O(1), mg=O(1) prove
these have bounded coefficients. The graph uses only the pure testing
unit inverse 1/v. It avoids the mixed inverse 1/(1+ηu²).

Let K=k0>0. At the joint source residue, Δ0=2(1+K²), and

    (xC)0 = K²/[4(1+K²)(1-h0)],
    (xA)0 = K²/[4(1+K²)h0],
    (D/x)0 = 1/[4K²(1+K²)],
    (α/x)0 = K²/[4(1+K²)].

The leading weighted scalar is

    q(v) U²/x - 2U + e(v)x,
    q(v)=K²(1+v²)/[(1+K²)v²],
    e(v)=(v²/K²+K²)/(1+K²).

The entire coefficient -2 of U comes from the original signed core;
it is independent of h. The complementary C,A packets combine to q.
Exactly,

    q(v)e(v)-1 = (v²-K²)²/[v²(1+K²)²].

Consequently the leading scalar Gram on (U/√x,√x) is strictly positive
away from v=±K. At either matched angle it has a single contact direction,
and the displayed square supplies positive transverse curvature. This is
the sharp scalar organizing identity for the joint degeneration.

The missing full-normal step is concrete. If the original strong packets
are normalized by

    EX=√n(X+r uZ),
    EM=√m(M-g uZ),
    EY=√(C+A)(Y-hu²Z/v),

then exact elimination gives

    X=Xg+EX/√n,
    Y=Yg+EY/√(C+A),
    W=Wg+(EX/√n+EM/√m)/v-u EY/√(C+A).

The positive C packet now has hard coefficients proportional to
C u²/n and C u²/m. These are not known to be bounded in the independent
tensor rings: the hypotheses allow n,m to grow more slowly than 1/x,
and no source/test infinitesimal comparison is permitted. Therefore the
scalar identity alone does not establish a strict bounded full Gram.
One must retain or recenter these positive C contributions, or build an
adapted joint hard frame, and prove bounded lifts of all first normals.
Arbitrarily small h or b-h introduce an additional positive-packet
scaling issue and have not been resolved by this note.

A second exact hard frame, useful for a repair, is

    H=n+m, ξ=m/H, S=nm/H,
    T=vW+uvY-(1+g-r)uZ,
    E=√H[X+r uZ-ξ T], J=√S T.

Then

    X=-r uZ+E/√H+ξJ/√S,
    M=g uZ-E/√H+(1-ξ)J/√S.

The n,m packet block on E,J is bounded and strictly positive on finite
v-unit charts; its couplings to uZ contain controlled factors nr/√H,
mg/√H and √S(g-r). This frame isolates the stiff current directly.
Its coupling to the C,A normal still needs the same boundedness repair.

This note is retained to avoid restarting the joint case or mistaking
its completed scalar reduction for the required whole-parent certificate.
