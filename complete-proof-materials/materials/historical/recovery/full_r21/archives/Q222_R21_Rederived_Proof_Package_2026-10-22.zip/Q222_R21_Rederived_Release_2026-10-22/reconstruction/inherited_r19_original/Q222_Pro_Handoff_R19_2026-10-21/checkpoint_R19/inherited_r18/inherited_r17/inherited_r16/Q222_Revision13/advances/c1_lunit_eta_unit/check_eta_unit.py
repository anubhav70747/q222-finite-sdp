#!/usr/bin/env python3
"""Exact leading all-normal blocks for the C1 L-unit eta-unit strip."""
import json
from pathlib import Path
import sympy as s
checks={}
def ck(name,expr):
    val=s.factor(s.cancel(s.together(expr)))
    if val!=0: raise AssertionError((name,val))
    checks[name]=True

B,e,r,v,P,Y,Z,et,ze,T=s.symbols('B eta rho v P Y Z etaN zetaN T')
y=B*e; V=v*v; den=1+B+y; P4=1+B*(1-r); S=B*r+y
j=(e-1+r)/e; t=(1-r)/e
C=(r+e)/(2*(1-r)*den)
A=e*P4/(2*r*den)
D=P4/(2*j*e*den)
al=B*B*(r+e)/(2*(1-B*r)*den)
f=4*C*(1+V)*(P-Y)**2+4*A*(1+V)*Y*Y+(4*D+2)*(P-Y-v*Z)**2+(4*al+2)*(v*Y-Z)**2-2*(1+V)*Z*Z
etaN=Y-r*P; zetaN=Z-v*P/B; TT=(V-y)*P
sos=4*D/B**2*(TT+B*etaN+B*v*zetaN)**2+4*al*(zetaN-v*etaN)**2+4*(C+A+s.Rational(1,2))*(1+V)*etaN**2
for mon,coef in s.Poly(s.expand(f-sos),P,Y,Z).terms():
    ck('exact_boundary_three_square_'+str(mon),coef)

N,Rh,ec,astar,alstar=s.symbols('N Rh ell_cap A_cap alpha_cap')
k=s.symbols('k',positive=True)
Cg,Dg,Ag,alg,yg=s.symbols('C_g D_g A_g alpha_g y_g')
q=Dg/(Cg+Dg); gam=yg*Cg*Dg/(Cg+Dg); ell=yg*(Cg+Dg)
etaR=k*(N+q*Rh)
tr=-B*(k*Rh+v*ze)
leading=4*Dg/B**2*(tr+B*etaR+B*v*ze)**2+4*alg*(ze-v*etaR)**2+4*(Cg+Ag+s.Rational(1,2))*(1+V)*etaR**2
kept=4*(ell-ec)*N*N+4*Cg*V*etaR**2+4*(Ag-astar)*(1+V)*etaR**2+4*(alg-alstar)*(ze-v*etaR)**2
target=4*ec*N*N+4*gam*Rh*Rh+4*(astar+s.Rational(1,2))*(1+V)*etaR**2+4*alstar*(ze-v*etaR)**2
for mon,coef in s.Poly(s.expand(leading-kept-target).subs(k*k,yg),N,Rh,ze).terms():
    ck('all_three_normals_after_caps_'+str(mon),coef)

rg,tau,mu,bcap,xi,R=s.symbols('r_geometry tau mu beta_cap xi R')
tau0=S/(2*den)-(1-rg)/2
mu0=S*rg*(1+y)/(2*B*B*den)
dR=4/B**2*(mu0*B*B+(rg*rg/2-tau0*(1+rg))*(1+V))+4*bcap*(1+V)/B**2
cross=4*(1+V)*P4/(B*den)+8*bcap*(1+V)/B
xx=2*(1+V)*(1+2*bcap)
M=s.Matrix([[xx,cross/2],[cross/2,dR]])
ck('explicit_R_diagonal',dR-2/B**2*(P4*(1+V)/den-S*rg*(V-y)/den+2*bcap*(1+V)))
onker=s.factor(xx/B**2-cross/B+dR)
ck('positive_cap_kernel',onker-2*S/(B**2*den)*(1+rg*y+(1-rg)*V))

# If beta is bounded, retain it all.  The native source relation gives
# theta(2 beta+1)=S/den, and r_geometry=1-theta.
bet=s.symbols('beta',nonnegative=True)
rg_b=1-S/(den*(1+2*bet))
ck('bounded_beta_full_two_by_two_det',M.det().subs({bcap:bet,rg:rg_b})-4*S/den*(1+V)/B**2*(1+2*bet)*rg_b*(1+y))

# The coefficient assertions used in contact-ideal allocation are checked
# directly from the general bounded local remainder with an A cap.
u,W,z,kk,Bb,tt,rr=s.symbols('u W z k B_b t_b r_b')
cv,dv0,gg,qq,mm,AA,AH,SS,TA,AC,AL,EC,BC=s.symbols('c d g q mu A AH sigma tau A_cap alpha_cap ell_cap beta_cap')
yy=kk*kk; HH=Bb-yy*tt; ac=1+z*rr;jj=ac-tt;sc=ac/Bb
U0,V0=s.symbols('U V')
Kn=u*kk*W;Qn=u*xi-ze
eta2=kk*(N+qq*Rh)
X2=-z*rr*v/Bb*W+xi;Y2=HH*u/Bb*W+eta2;Z2=u*v/Bb*W+ze
Du=1+u*u;Dv=1+v*v
Mm=v*W-X2+u*v*Y2-u*Z2;Jj=u*W+u*v*X2-Y2-v*Z2
core=2*(Jj*Jj+Du*(v*Y2-Z2)**2+Dv*(X2+u*Z2)**2-Du*Dv*Z2*Z2)
betaR=xi+u*ze+v*(u*u-z)*W/Bb
G=(4*EC*N*N+4*gg*Rh*Rh+8*(dv0-cv)/Bb*Kn*N-8*gg*sc*Kn*Rh
 +4*(cv*tt+dv0*jj)/Bb**2*Kn*Kn+4*cv*tt/Bb**2*v*v*Kn*Kn-8*cv/Bb*v*v*Kn*(N+qq*Rh)
 +4*AL*Du*(v*eta2-ze)**2+4*SS*Du*((1-HH)*u*u*v*v/Bb**2*W*W-2*u*v/Bb*W*(v*eta2-ze))
 +4*z*z*mm*Mm*Mm+4*AC*Du*Dv*eta2*eta2+8*AH/Bb*Du*Dv*u*W*eta2+4*AH*HH/Bb**2*Du*Dv*u*u*W*W+core
 +4*BC*Dv*betaR*betaR+8*TA*z/Bb*Dv*v*W*(xi+u*ze)+4*TA*z/Bb**2*Dv*v*v*(2*u*u-z*(1+rr))*W*W)
G=s.expand(G)
qsrc=dv0*tt/(cv*jj+dv0*tt);gsrc=cv*dv0/(cv*jj+dv0*tt)
ellsrc=cv/tt+dv0/jj
rhact=v*Qn/kk-sc*u*(v*v-yy)*W/kk
Cw=cv/(yy*tt);Dw=dv0/(yy*jj);Aw=AH/HH;alw=SS/(1-HH);bw=TA/(1-rr)
Ffull=4*z*z*mm*Mm*Mm+4*Cw*Dv*(u*W-Y2)**2+4*Aw*Du*Dv*Y2*Y2+4*Dw*Jj*Jj+4*alw*Du*(v*Y2-Z2)**2+4*bw*Dv*(X2+u*Z2)**2+core
packets=4*(ellsrc-EC)*N*N+4*Cw*v*v*eta2*eta2+4*(Aw-AC)*Du*Dv*eta2*eta2+4*(alw-AL)*Du*(v*eta2-ze)**2+4*(bw-BC)*Dv*betaR*betaR
ck('full_original_parent_all_five_retained_packets',(Ffull-packets-G).subs({qq:qsrc,gg:gsrc,Rh:rhact}))
rho=s.cancel(G.coeff(Rh,1).coeff(W,1)/(u*kk))
Gg=s.expand(G-u*kk*rho*Rh*W+rho*(u*v*W*Qn-sc*u*u*(v*v-yy)*W*W))
def even(expr,pu=0,pv=0,pk=0):
    pp=s.Poly(s.cancel(expr/(u**pu*v**pv*kk**pk)),u,v)
    ans=0
    for (ii,jj0),coef in pp.terms():
        assert ii%2==0 and jj0%2==0
        ans+=coef*U0**(ii//2)*V0**(jj0//2)
    return s.expand(ans)
px=even(Gg.coeff(xi,1).coeff(W,1),pv=1)
pz=even(Gg.coeff(ze,1).coeff(W,1),pu=1,pv=1)
pn=even(Gg.coeff(N,1).coeff(W,1),pu=1,pk=1)
phi=even(Gg.coeff(W,2))
ck('xi_support_U_z',px.subs({U0:0,z:0}))
ck('xi_first_z_coefficient',s.diff(px,z).subs({U0:0,z:0})-(1+V0)/Bb*(-4*rr+8*TA-8*BC))
assert s.degree(s.diff(px,U0).subs({U0:0,z:0}),V0)<=1
checks['xi_first_U_coefficient_affine_in_V']=True
assert s.degree(phi,U0)<=2
checks['scalar_U_degree_at_most_two']=True
ck('new_scalar_constant',phi.subs(U0,0)-4*z*z/Bb**2*V0*(mm*(Bb+z*rr)**2+(rr*rr/2-TA*(1+rr)+BC)*(1+V0)))

# Native opening-cleared source products with eta retained as a unit.
xs,th=s.symbols('x_source theta')
an=(1-r)/e;hn=1-th;Kn=1+xs;Rn=1+xs*r;Tn=1+xs*hn
Mn=Rn-th*xs/B;Jn=Tn-an;En=1-xs*e*hn
Pd=1+2*xs*hn+r*xs*xs*(hn+B/xs)+B+e*xs*((1+xs)*B/xs+xs*hn*th)
P4n=Tn*En+xs*(1-r)*(hn+B/xs)
Pal=Rn*hn*(1+y)+(B/xs)*Mn*En
B5=Kn*(1+y)*(r+e)-e*Jn*Pd
Bbet=Kn*xs*(r+e)*(hn+B/xs)-th*Pd
products={
 'Cyt':(B*Kn*(r+e)*En/(2*Pd),S/(2*den)),
 'Dyj':(B*B5/(2*Pd),B*P4/(2*den)),
 'm_over_z_squared':(Kn*(r+e)*hn*(1+y)/(2*Mn*B*Pd),S*(1-th)*(1+y)/(2*B*B*den)),
 'alpha_complement':(xs*B*(r+e)*Pal/(2*Pd),B*S/(2*den)),
 'A_times_H':(y*P4n/(2*Pd),y*P4/(2*den)),
 'beta_times_theta':(Bbet/(2*Pd),S/(2*den)-th/2)}
for name,(expr,want) in products.items():
    ck('native_source_'+name,s.cancel(expr).subs(xs,0)-want)

result={'status':'all_exact_checks_passed','checks':checks,'count':len(checks),
 'scope':'Exact boundary all-state factorization, capped three-normal block, complete xi/R block positivity identities, and bounded local remainder support for C1 L-unit eta-unit. Accompanying proof supplies contact divisions and all-test joins.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
Path(__file__).with_name('extracted_coefficients.txt').write_text('\n\n'.join(['rho = '+str(s.factor(rho)),'P_xi = '+str(s.factor(px)),'P_zeta = '+str(s.factor(pz)),'P_N = '+str(s.factor(pn)),'phi = '+str(s.collect(phi,U0))])+'\n')
print(json.dumps({'status':result['status'],'count':len(checks)}))
