# Uniform C1 angular conditioning and exact small-angle rates

Date: 2026-10-17. This is a new analytical reduction for actual C1 contacts. No mixed denominator is inverted.

## 1. The covariance never loses shape after source-only diagonal scaling

Use C1 `lambda=n=0`, let `U=uc^2,V=vc^2>0`, and write its six outer Laurent masses at an actual stationary zero as

    a=q01/U, b=q02 V/U, c0=q10/V,
    d0=q12 V, e=q21 U, f=q22 U V.

The two stationarity equations are exactly

    a+b=e+f=:M,
    c0=b+d0+f=:N.

The logarithmic Hessian (with no extra scalar normalization) is therefore

    C = [[2M, f-b], [f-b, 2N]].

Every displayed mass is a nonnegative element of the source field. Whenever `M,N>0`,

    |f-b|<=M,   |f-b|<=N,
    (f-b)^2<=MN,
    det(C)>=3MN.

The first inequality follows from `b,f<=M`; the second from `b+f<=N`. Therefore the legal source-only congruence

    R=diag((2M)^(-1/2),(2N)^(-1/2))

gives

    R C R = [[1,rho],[rho,1]],  |rho|<=1/2,
    R C R >= (1/2) I.

This is uniform over **all source-angle rates**, including one or both infinitesimal or unbounded source angles. Both scaling factors belong entirely to the real closed source field. It is substantially stronger than merely proving nonsingularity at finite unit angles.

For a physical C1 source with `d>0` and a positive actual contact, `M,N` cannot vanish. If one vanished, stationary balance would leave a vertical or horizontal antipodal pair, or no outer support. The product relations for the C1 coefficients rule out the single-pair possibilities exactly as in Section 3 of FINITE_UNIT_COVARIANCE.md. The all-zero possibility is excluded by the same integer witnesses, now over the source field itself rather than only in residue. Thus the uniform scaling applies to every positive actual C1 contact of this kind.

This lemma controls the scalar angular Hessian only. It does not assert that a full-parent root module has bounded coefficients after this scaling; that is a separate exact remainder/normal-division assertion.

## 2. Exact rate equations for a small actual Alice angle

Keep the positive source quantities `t_i` from the locked determinant formula. The two stationary equations, without division by any opening, are

    m t5 (alpha t8 + D t6 V)
       = U^2 c t1 (A t4 + beta t2 V),                 (A)

    alpha A t7 t3
       = V^2 [m D t5 t6/U + beta m t1 t6
                      + c D t5 t2 + beta c t1 t2 U]. (B)

Here the original event coefficient `c` is distinct from the mass `c0` above. These equations follow directly from the original nonnegative outer coefficients, so there is no cancellation between positive terms.

If the source is normalized and `res(d)>0`, every `t_i` is a bounded positive unit. If also `vc` is a finite positive unit, (A)-(B) give the exact order relations

    m (alpha+D) asymp U^2 c(A+beta),

    alpha A asymp mD/U + beta m + cD + beta c U.

The notation `asymp` means that the ratio is bounded above and below by positive real constants when both sides are nonzero; it follows because all omitted positive `t_i,V` factors are units. Literal zeros remain governed by the undivided equations (A)-(B).

In particular, each nonnegative summand on the right of (B) is bounded by a unit multiple of `alpha A`. These are forced source rate relations, rather than arbitrary chart choices. For example,

    mD <= (positive unit) U alpha A,
    cD <= (positive unit) alpha A,
    beta c U <= (positive unit) alpha A.

They should be used before introducing independent opening parameters in a small-source-angle normal form.

## 2a. One weak source angle has a unit quartic curvature and a rank-three hard block

Assume `uc` weak, `vc` a positive unit, and normalized `d` a positive unit, without imposing a D-unit condition yet. Put `p=uc^2,w=vc^2` and `Q=q21+q22 w`. Then Q is a positive unit. To prove it, U-stationarity makes `q01,q02` weak, while V-stationarity gives `res(q10)=res(w^2 q12)`. If Q were weak, the only possible nonzero residue outer support would be the vertical pair. The C1 pair products exclude that pair, and the physical integer witnesses exclude empty support. Hence Q cannot be weak.

For the determinant polynomial `D(U,V)=sum qij U^i V^j`, this implies

    D_UU(p,w)=2w Q

has positive unit residue. Thus the correct source quartic angle coordinate is `u^2-uc^2`, rather than `u-uc` with its vanishing curvature.

The full original residue parent at `u=0` has exactly one kernel coordinate. Indeed the d-core gives strict X,Y energy. A unit m fills W through `m(vW-X)^2`; a unit D or alpha fills Z through `D(Y+vZ)^2` or `alpha(vY-Z)^2`. Both m and D+alpha strong would make the matrix positive definite, incompatible with an actual weak-u contact. Neither strong would leave the W,Z plane in the kernel. But the original derivative P_u restricted to that plane has off-diagonal `-2d vc` and zero diagonal; this is nonzero and indefinite. A matrix PSD for both signs of real u cannot have a nonzero first derivative on its kernel. Therefore exactly one alternative occurs:

    m weak, D+alpha unit: kernel W and a residue-PD XYZ block;
    m unit, D+alpha weak: kernel Z and a residue-PD WXY block.

This argument uses physical positivity of the residue source for all signed real angles; it does not infer rank from determinant alone. A projective contact state can first be normalized to norm one in Kc, so that its nonzero residue proves incompatibility with a positive definite residue parent.

In the first alternative with D unit, the complete weighted five-root admission is proved in WEAK_SOURCE_DUNIT_LOCAL_ADMISSION.md. In the second alternative, the source equations also force c,A to be units, `alpha` to have exactly scale `p^2`, `D=O(p^3)` and `beta=O(p^2)`. For these last rate statements: Q unit forces c and A+beta strong; V-stationarity rules out beta strong because alpha is weak and m strong, hence A is strong. U-stationarity gives `alpha+D` exactly scale p^2, while the positive summand `mD/p` in V-stationarity implies `D<=unit*p*alpha`. Thus alpha itself has scale p^2 and the displayed D,beta bounds follow. No full-parent admission is claimed for that second alternative here.

## 3. A useful two-weak-angle invariant

If `U,V` are both weak while the normalized source coefficients are bounded, the exact equations yield

    M=U(q21+q22 V),
    N=(q02 V/U)+q12 V+q22 U V.

Both are positive but may be infinitesimal with unrelated rates. The same diagonal scaling from Section 1 still produces the uniform residue eigenvalue lower bound `1/2`. Thus two weak source angles do not create an additional C1 covariance *shape* degeneracy; they change only its two source-owned scales.

The first expression makes `M` weak. For the second, stationarity bounds `q02 V/U<=M`; the remaining terms are weak, so `N` is weak as well. Their ratio can remain arbitrary. No comparison with the independent testing-angle rates is made.

## 4. Relabeling cannot turn a commuting limit into an ordinary angle

For two binary projective qubit observables at Alice, the norm of their commutator is `2|sin(a)|`; similarly at Bob. Outcome flips and setting permutations preserve these magnitudes, while party exchange only swaps them. Equivalently, the half-angle transformations send `u` among signed `u` and signed `1/u`; they turn a weak angle into a weak or infinite angle, not a unit angle. Local changes of qubit basis also preserve the angle between the two observables.

Consequently a weak source noncommutativity cannot be removed by CHSH relabeling. The rate normalization in Section 1 is a genuine additional operation, with pure source factors, rather than a disguised symmetry argument.

## 5. Precise remaining issue

The new scaling removes angular covariance degeneration at the source contact. Extending the finite-interior full-parent argument still requires a legal contact-root frame whose exact scalar and state-normal remainders have bounded coefficients after the source scales are absorbed into roots. A Taylor Hessian bound alone does not establish that fact when the contact collides with `u=0` or `v=0`. In particular a factor `u+uc` can have zero residue there; dividing by it as a mixed positive element is not licensed.

These observations reduce the small-source-angle target to weighted exact root division, rather than an additional search for angular curvature or an attempt to regularize the source angles by relabeling.
