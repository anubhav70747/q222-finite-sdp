"""Focused independent review checks for root CF1--CF5 only."""
import json
from pathlib import Path
import sympy as s

checks={}
def ck(name,expr):
    v=s.cancel(expr)
    assert v==0,(name,v)
    checks[name]=True
    print('PASS '+name)

x,z,b,h,sigma=s.symbols('x z b h sigma')
r=b*z; Q=1-b; theta=1-h; H0=1+z-r
K=1+x; Rg=1+x*r; M=Rg-x*z*theta
P=sigma+K+sigma*z*(1+b*x+2*x*h)+sigma*b*x*x*h*z*z+x*x*h*theta*z
Nk=s.expand(K*(1+sigma*r)*(1+sigma*z)-M*P)
Fs=s.cancel((Nk-Nk.subs(sigma,0))/sigma)
ck('source_kappa_sigma_residue',Fs.subs({x:0,sigma:0})-(r-1))
ak0=2*h*(r-1); lambda00=-2*theta*H0
ck('source_KA_residue',ak0-lambda00-2*(H0-h*(H0+1-r)))
chi0=8*((H0/2)*b+Q/2)-4*h+4*z*((h-Q)**2+h*theta)
ck('source_chi_residue',chi0-4*(H0-h*(1+z-2*r)))

q,x,sigma,lam,hh,u,w,f,Z=s.symbols('q x sigma lam hh u w f Z',nonzero=True)
z=q*q; h=hh*hh; W=f*Z; ss=x/sigma; Lh=lam*sigma/h
R=w*Z/q-u*q*W; A=q*(u*u-x)*W
Gamma=sigma*Z-u*w*W; Pb=u*Z-x/sigma*w*W
Uh=hh*u*Z; Qsq=lam*x/sigma*(u*w*W)**2; Msq=lam*x*x*q*q*W*W
scalar=lam*sigma*Pb*Pb+lam*x/sigma*(u*u-x)*(w*w-sigma*z)*W*W
cf3=Lh*((1-ss*z*f*f)*Uh-hh*ss*q*f*R)**2+Qsq+Msq-Lh*ss*z*f*f*Uh*Uh-Lh*ss*ss*(hh*q*f*R+z*f*f*Uh)**2
ck('full_scalar_CF3',scalar-cf3)
Bf=(sigma-x*z*f*f)/hh
ck('u_Gamma_CF4',u*Gamma-Bf*Uh+u*q*f*A+u*u*q*f*R)
ck('w_Gamma_CF4',q*w*Gamma-q*z*f*Bf*Uh+u*z*z*f*f*A-z*(sigma-u*f*w-u*u*z*f*f)*R)
# CF5 uses M_lambda/sqrt(lambda)=xqW, avoiding an unnecessary radical.
ck('angular_CF5',A-q*f*u/hh*Uh+x*q*W)
Path(__file__).with_suffix('.json').write_text(json.dumps({'status':'PASS','count':len(checks),'checks':checks},indent=2)+'\n')
print(str(len(checks))+' focused checks passed')
