#!/usr/bin/env python3
"""Exact finite-support and integer energy checks; standard library only."""
from itertools import combinations
from pathlib import Path
import json

edges = [
    ('lambda','alpha'),('lambda','D'),('alpha','m'),('m','D'),
    ('alpha','A'),('lambda','n'),('beta','m'),('c','D'),
    ('n','A'),('beta','n'),('c','A'),('beta','c')]
rows={
    'n':(0,1,0,0),'m':(1,-1,1,-1),'c':(1,0,-1,0),
    'A':(0,0,1,0),'D':(1,1,-1,-1),
    'alpha':(0,0,1,-1),'beta':(0,1,0,1)}
tables={
 'C1': [
   (('c','m'),(1,0,1,2),-2),
   (('A','m'),(2,-1,0,3),-6),
   (('alpha','c'),(1,0,1,1),-1),
   (('A','D','beta'),(2,-1,0,1),-2),
   (('D','alpha','beta'),(3,-1,1,1),-4)],
 'C2': [
   (('A','m'),(2,-1,0,3),-6),
   (('A','D'),(2,-1,0,1),-2),
   (('c','m','n'),(1,0,1,2),-2),
   (('alpha','c','n'),(1,0,1,1),-1),
   (('D','alpha','n'),(2,0,1,1),-2)]}
universes={'C1':('m','c','A','D','alpha','beta'),
           'C2':('n','m','c','A','D','alpha')}
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def K(x):
 W,X,Y,Z=x
 return (W+X-Y-Z)**2+2*(Y-Z)**2+2*(X+Z)**2-4*Z*Z

receipt={}
for family,U in universes.items():
 supports=[frozenset(S) for k in range(len(U)+1) for S in combinations(U,k)
           if all(not frozenset(e)<=frozenset(S) for e in edges)]
 maximal={S for S in supports if not any(S<T for T in supports)}
 expected={frozenset(S) for S,w,k in tables[family]}
 assert maximal==expected,(family,maximal,expected)
 for S,w,k in tables[family]:
  assert all(dot(rows[i],w)==0 for i in S)
  assert K(w)==k<0
 receipt[family]={'independent_supports':len(supports),
                  'maximal_supports':len(maximal),
                  'all_event_kernel_and_energy_checks':True}

# Direct exhaustive combinatorics for nonzero balanced rank-one supports.
# An exponent set spans a line and balances with positive masses iff it is
# precisely one of the four antipodal pairs on this grid.
outer={
 (-1,-1):(('lambda','alpha'),),
 (-1,0):(('lambda','D'),('alpha','m')),
 (-1,1):(('m','D'),),
 (0,-1):(('alpha','A'),('lambda','n')),
 (0,1):(('beta','m'),('c','D')),
 (1,-1):(('n','A'),),
 (1,0):(('beta','n'),('c','A')),
 (1,1):(('beta','c'),)}
rank_one={}
for family,U in universes.items():
 found=[]
 for k in range(1,len(U)+1):
  for S in combinations(U,k):
   S=frozenset(S)
   active={v for v,terms in outer.items() if any(set(p)<=S for p in terms)}
   if len(active)==2 and all((-x,-y) in active for x,y in active):
    found.append(sorted(S))
 if family=='C1':assert found==[]
 else:assert found==[['A','D','m','n']]
 rank_one[family]=found
receipt['balanced_rank_one_source_supports']=rank_one
receipt['scope']='Exact support census and integer identities only; analytical rank/PSD arguments are in FINITE_UNIT_COVARIANCE.md.'
out=Path(__file__).with_name('FINITE_UNIT_COVARIANCE_CHECKS.json')
out.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
