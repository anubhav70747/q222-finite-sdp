"""Exact source-bound contact/conductor proof. Standard library, no Groebner.

The only divisions are geometric-sum divisions by monic contact differences
and exact removal of displayed monomial factors. No parameter is inverted.
"""
if not __debug__:
    raise SystemExit('Run without -O: assertions are proof checks.')
from pathlib import Path
import json,time
from arithmetic import add_into,subtract
from source_from_formulas import Poly,variables,reconstruct_source,native_coquotients
HERE=Path(__file__).resolve().parent
start=time.perf_counter();checks=[]
def eq(name,p,q):
    assert not (p-q).terms,name
    checks.append(name)
d,k,b,a,t,u,w,v=variables(8)
zero=0*d;one=zero+1
W=(2,2,6,0,0,2,4,18)
def weight(p):return min((sum(x*y for x,y in zip(m,W))for m in p.terms),default=None)
def contact(p):
    out={}
    for m,c in p.terms.items():
        de,ke,be,ae,te,ue,we,ve=m
        n=(de+we+ve,ke+ue+we+2*ve,be+2*ve,ae,te,0,0,0)
        out[n]=out.get(n,0)+c
        if not out[n]:del out[n]
    return Poly(out,8)
def derivative(p,i):
    return Poly({m[:i]+(m[i]-1,)+m[i+1:]:c*m[i]for m,c in p.terms.items()if m[i]},8)
contact_roots=(u-k,w-d*k,v-d*k*k*b*b)
contact_monomials=((0,1,0,0,0,0,0,0),(1,1,0,0,0,0,0,0),(1,2,2,0,0,0,0,0))
def monic_split(p):
    """p = p(contact) + (u-k)Tu + (w-d*k)Tw + (v-d*k*k*b*b)Tv."""
    remainder=dict(p.terms);quotients=[]
    for i,cm in zip((5,6,7),contact_monomials):
        quotient={};next_remainder={}
        for m,c in remainder.items():
            n=m[i];base=list(m);base[i]=0
            final=tuple(x+n*y for x,y in zip(base,cm))
            next_remainder[final]=next_remainder.get(final,0)+c
            if not next_remainder[final]:del next_remainder[final]
            for j in range(n):
                mm=list(base);mm[i]=n-1-j
                mm=tuple(x+j*y for x,y in zip(mm,cm))
                quotient[mm]=quotient.get(mm,0)+c
                if not quotient[mm]:del quotient[mm]
        quotients.append(Poly(quotient,8));remainder=next_remainder
    eq('monic contact division',p,Poly(remainder,8)+sum((r*q for r,q in zip(contact_roots,quotients)),zero))
    return Poly(remainder,8),quotients
A=w*v;B=d*v;C=d*b*b*u*w;D0=d*d*k**3*b*b
x=B-C;y=A-k*C;z=u*B-k*C;h=k*C-D0
rr=[x,y,z,h]
q1square=(w*v)*(d*u*v)+(k*C)*D0-2*(k*C)*(k*B)
star=y+z-h-2*k*x

def conductor_lift(p):
    rem,(Tu,Tw,Tv)=monic_split(p)
    assert not rem.terms,'contact vanishing required'
    ans=[-u*Tu-w*Tw-b*b*k*w*Tv,d*Tw+d*k*b*b*Tv,Tu+b*b*w*Tv]
    eq('contact conductor multiplication',C*p,sum((r*f for r,f in zip(rr,ans)),zero))
    return ans

eq('u conductor',C*(u-k),z-u*x)
eq('w conductor',C*(w-d*k),d*y-w*x)
eq('v conductor',C*(v-d*k*k*b*b),b*b*(w*z+d*k*y-k*w*x))
eq('cross circuit repair',k*C*star,q1square-y*z)
eq('second-order relation',star,(v-d*k*k*b*b)*(w-d*k+d*(u-k))-d*k*b*b*(u-k)*(w-d*k))
# Jacobian determinant is cancelled only to prove zero evaluations.
J=[[contact(derivative(r,i))for i in (5,6,7)]for r in rr[:3]]
det=J[0][0]*(J[1][1]*J[2][2]-J[1][2]*J[2][1])-J[0][1]*(J[1][0]*J[2][2]-J[1][2]*J[2][0])+J[0][2]*(J[1][0]*J[2][1]-J[1][1]*J[2][0])
eq('nonzero contact Jacobian determinant',det,-d**4*k**4*b**4)

def monomial_decompose(p,generators):
    """Exact membership in a displayed monomial ideal, with polynomial quotients."""
    mons=[];out=[{}for _ in generators]
    for gen in generators:
        assert len(gen.terms)==1
        (m,c),=gen.terms.items();assert c==1;mons.append(m)
    for m,c in p.terms.items():
        for j,n in enumerate(mons):
            if all(s>=r for s,r in zip(m,n)):
                out[j][tuple(s-r for s,r in zip(m,n))]=c;break
        else:raise AssertionError(('outside displayed monomial ideal',m))
    qs=[Poly(x,8)for x in out]
    eq('displayed monomial decomposition',p,sum((q*g for q,g in zip(qs,generators)),zero))
    return qs

def linear_lift(p):
    RA,RB,RC=monomial_decompose(p,[A,B,C])
    S=k*RA+RB+RC
    eq('first-normal contact',contact(p),zero)
    assert not contact(S).terms
    ans=conductor_lift(S)
    ans[0]+=RB;ans[1]+=RA
    eq('complete first-normal lift',p,sum((r*q for r,q in zip(rr,ans)),zero))
    return ans

def square_lift(p):
    pairs=[(i,j)for i in range(3)for j in range(i,3)]
    mons=[A,B,C]
    coeffs=monomial_decompose(p,[mons[i]*mons[j]for i,j in pairs]+[D0*D0])
    rho=coeffs[-1];cs=[k,one,one];rs=[y,x,zero]
    S=k*k*rho;H=[zero,zero,zero,-2*k*rho]
    terms=[(3,3,rho)]
    index=[1,0,None]
    for (i,j),f in zip(pairs,coeffs):
        S+=f*cs[i]*cs[j]
        if index[i] is not None:H[index[i]]+=f*cs[j]
        if index[j] is not None:H[index[j]]+=f*cs[i]
        if index[i] is not None and index[j] is not None:terms.append((index[i],index[j],f))
    Q=sum((f*rr[i]*rr[j]for i,j,f in terms),zero)
    eq('first square decomposition',p,Q+C*sum((r*f for r,f in zip(rr,H)),zero)+C*C*S)
    eq('scalar contact',contact(p),zero)
    for i in (5,6,7):eq('scalar first derivative at contact',contact(derivative(p,i)),zero)
    assert not contact(S).terms
    lift=conductor_lift(S)
    for i in range(3):H[i]+=lift[i]
    rhoc=contact(rho);lam=2*k*rhoc
    syz=[-2*k,one,one,-one]
    remainders=[Hi-lam*ai for Hi,ai in zip(H,syz)]
    # These four zero evaluations are forced by the determinant calculation;
    # check directly too. No determinant quotient is ever formed.
    for remainder in remainders:assert not contact(remainder).terms
    terms.append((1,2,-2*rhoc))
    for i,remainder in enumerate(remainders):
        for j,f in enumerate(conductor_lift(remainder)):terms.append((i,j,f))
    result=sum((f*rr[i]*rr[j]for i,j,f in terms),zero)+2*rhoc*q1square
    eq('complete scalar square lift',p,result)
    return [f for i,j,f in terms]+[2*rhoc]

source=reconstruct_source()
E0=Poly(subtract(source['scalar_terms'],source['leading_terms']),8)
L1,L2=(Poly(p,8)for p in source['linears_terms'])
coeffs={'E0':square_lift(E0),'L1':linear_lift(L1),'L2':linear_lift(L2)}
result={'status':'PASS: complete source-bound analytical lifts, no Groebner discovery or certificate',
 'checks':len(checks),'check_names':checks,
 'target_terms':{'E0':len(E0.terms),'L1':len(L1.terms),'L2':len(L2.terms)},
 'minimum_target_weights':{n:weight(p)for n,p in [('E0',E0),('L1',L1),('L2',L2)]},
 'minimum_constructed_coefficient_weights':{n:min(weight(p)for p in ps if p.terms)for n,ps in coeffs.items()},
 'coefficient_polynomial_counts':{n:sum(bool(p.terms)for p in ps)for n,ps in coeffs.items()},
 'expanded_coefficient_terms':{n:sum(len(p.terms)for p in ps)for n,ps in coeffs.items()},
 'inversions':'none; all exponents nonnegative, including a,t',
 'seconds':time.perf_counter()-start}
assert all(v>0 for v in result['minimum_constructed_coefficient_weights'].values())
(HERE/'analytical_lift_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
