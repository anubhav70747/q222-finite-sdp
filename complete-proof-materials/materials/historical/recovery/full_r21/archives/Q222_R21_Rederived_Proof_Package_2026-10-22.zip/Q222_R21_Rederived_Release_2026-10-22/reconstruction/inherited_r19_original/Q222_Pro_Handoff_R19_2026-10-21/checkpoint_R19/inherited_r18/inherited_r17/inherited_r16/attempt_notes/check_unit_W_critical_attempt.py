"""Focused exact audit of the proposed C14.3b unit-W critical-wall transfer."""
import sympy as s,json
from pathlib import Path
C,A,D=s.symbols('C A D');Ac=(2*C+2*D+1)/(8*C*D-4*D-2)
checks={}
def ck(name,f):
 assert s.cancel(f)==0,(name,s.factor(f));checks[name]=True
ck('critical_A_exact',8*Ac*C*D-4*Ac*D-2*Ac-2*C-2*D-1)
x,t,a,pi,sg=s.symbols('x eta a pi sigma');r=1-t*sg;h=1-x*pi;th=x*pi
K=1+x;R=1+x*r;T=1+x*h;Ms=R-a*th;y=x*t/a;j=t*(T-sg);Es=1-x*t*h
Pd=1+2*x*h+r*x*x*(h+1/a)+x/a+t*x*(K/a+x*h*th)
P4=T*Es+x*(1-r)*(h+1/a)
Cn=K*(r+t)*Es/(2*Pd)
Dn=K*(1+y)*(r+t)/(2*Pd)-j/2
As=t*P4/(2*r*Pd);ms=K*x*a*(r+t)*h*(1+y)/(2*Ms*Pd)
denwall=8*Cn*Dn-4*Dn*(1-r)-2*(1-r)*j
numwall=2*Cn*j+2*Dn*(1-r)+(1-r)*j-As*denwall
# Remove the explicit eta factor first, then divide by x via its exact
# zero at x=0. Every remaining rational denominator is a source unit.
core=2*Cn*(T-sg)+2*Dn*sg+t*sg*(T-sg)-P4/(2*r*Pd)*denwall
ck('exact_x_divisibility_of_eta_cleared_defect',core.subs(x,0))
res=s.factor(s.diff(core,x).subs({x:0,t:0})/denwall.subs({x:0,t:0}))
ck('critical_deficit_normalized_residue',res-(3+2/a)/2)
den=s.factor(denwall.subs({x:0,t:0}))
assert den!=0
checks['critical_deficit_no_gap_poles']=True
# The contact packet ratio is the preceding normalized defect times
# K(1+y)r^2*a / [(m/x) M_s^2]; all factors are source units.
contactres=s.factor(res*(K*(1+y)*r*r*a/(K*a*(r+t)*h*(1+y)/(2*Ms*Pd)*Ms*Ms)).subs({x:0,t:0}))
ck('contact_deficit_to_m_packet_ratio',contactres-(3+2/a))
# Direct W-based conductor, which exposes the unbounded eta-normalized row.
u,v,W,Z,xi,E,P=s.symbols('u v W Z xi E P',nonzero=True)
Qt=E/t-P
claim=v*xi/(t*W)*E*E/t+v*v*Z/(t*t*W)*E*xi-u*v*P*xi
ck('unit_W_direct_conductor',(u*v*Qt*xi-claim).subs(E,t*u*W-v*Z))
out={'status':'PASS','count':len(checks),'checks':checks,'critical_deficit_residue':str(res),'contact_correction_to_m_packet_residue':str(contactres),'normalized_denominator_at_corner':str(den),'scope':'Exact obstruction to transferring the R10 uncentered critical-wall Inf-Gram argument to the C14.3b unit-W contact chart. Does not disprove or close that chart.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
