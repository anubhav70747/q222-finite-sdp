"""Exact original-source checks for the directed weak-C HI/HU exclusion."""
from pathlib import Path
import json
import sympy as s
q,y,r,H,T,R,B,L=s.symbols('q y r H T R B L')
z=1/q;a2=y*q;b=y*r+q*T;h=q*H;t=r/q+(T-H)/y
Ac=1+z*r;Sc=Ac+a2*z*t
g=(1+z)*b-(1-r+a2*z*t);j=Ac-t
Delta=(1+z)*z*b*b+2*z*(1+z)*b*r+(1+z)*(1+a2*z)*b+z*z*(1-a2)*r*r+2*z*(1+a2*z)*r+1+a2*z
Num=(1+z)*(b+r)*(b+a2*(1-t))-a2*(1+a2*z)*(1-r)*t
n=((b+r)*Ac*Sc-r*Delta)/(2*r*Delta)
C=Ac*Num/(2*a2*t*Delta)
checks=[]
def eq(label,lhs,rhs=0):
    assert s.factor(lhs-rhs)==0,label
    checks.append(label)
eq('original h identity',b-a2*t,h)
eq('exact g gap',g,H+(1+y)*r-1+q*T)
eq('exact j gap',j,(H+y-T)/y)
Q=s.cancel(q*q*Delta)
Pp=H*T*q*q+H*T*q*r+H*q*r*(y+1)+T*T*q*q*r
Pp+=T*q*q*r*(y+1)+2*T*q*r*r*(y+1)+q*r*r*y*(y+1)
P=r*r*(1+y)*(H+y*r)-T*q*r*(y+2)-q*q*(T*T+T)+Pp
eq('exact n sign formula',n,-q*P/(2*r*Q))
assert all(coef>0 for _,coef in s.Poly(s.expand(Pp),q,y,r,H,T).terms())
checks.append('discarded Pplus coefficients strictly positive')
eq('bounded-R Delta form',Delta.subs(r,q*R),
   ((1+q)*(B*B+2*B*R+(1+y)*B)+(1-y*q)*R*R+2*(1+y)*R+1+y).subs(B,y*R+T))
Nq=(1+q)*(B+R)*(H+y)-(1+y)*(1-q*R)*(B-H)
eq('bounded-R source numerator',Num.subs(r,q*R)/q,Nq.subs(B,y*R+T))
eq('source numerator residue',Nq.subs({q:0,H:1},simultaneous=True),(1+y)*(1+R))
eq('original C reconstruction',C.subs(r,q*R),
   ((1+R)*Nq/(2*(B-H)*Delta.subs(r,q*R))).subs(B,y*R+T))
result={'status':'PASS','count':len(checks),'checks':checks,
        'scope':'Original-source identities supporting n>=0 exclusion of weak C at actual HI/HU; all-tests closure is by source emptiness, not scalar positivity.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
