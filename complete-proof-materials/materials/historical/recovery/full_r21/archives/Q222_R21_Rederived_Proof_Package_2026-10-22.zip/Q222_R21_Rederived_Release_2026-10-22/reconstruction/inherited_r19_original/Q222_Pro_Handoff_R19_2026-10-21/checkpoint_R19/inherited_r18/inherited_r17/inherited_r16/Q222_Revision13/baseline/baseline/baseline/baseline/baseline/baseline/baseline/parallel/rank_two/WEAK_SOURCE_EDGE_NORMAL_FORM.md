# The next weak-source edge problem has one soft state, not two

17 October 2026. Scope: original C2 parent, `lambda=beta=0`, nonnegative normalized source coefficients, CHSH coefficient `d` of positive residue. This identifies the next small normal form; it does not prove admission of that weak-source regime.

## 1. A second physical opening floor

Let `rho=d+n+m+c+A+D+alpha>0`. Every physical source satisfies

\[
 \boxed{D+\alpha\ge \frac{d^2}{36\rho}.}\tag{1}
\]

The constant 36 is a convenient explicit bound, not an optimality claim.

For the proof test the exact original parent at `v=1` and the state

\[
 (W,X,Y,Z)=(u,0,0,1).
\]

Writing `U=u^2` and `s=D+alpha`, the full energy is exactly

\[
 4s+(4\alpha-8D-2d)U+(4D+8c+2d)U^2.\tag{2}
\]

The four channels `n,m,A` and the omitted channels contribute zero here; the formula retains every core term. Since `alpha<=s` and `4D+8c+2d<=8rho`, physicality implies

\[
 0\le F\le4s(1+U)-2dU+8\rho U^2.
\]

Choose the source-field angle `U=d/(8rho)` when `d>0`. Physicality is quantified over all source-field angles, so this choice is legal and does not mix the two tensor roles. Since `U<=1/8`,

\[
 0\le\frac92s-\frac{d^2}{8\rho},
\]

which is (1). For `d=0` the conclusion is immediate. The test does not divide by an opening. Alternatively, the exact source-only necessary condition from nonnegativity of the quadratic (2) is

\[
 4\alpha-8D-2d+
 4\sqrt{(D+\alpha)(4D+8c+2d)}\ge0.
\]

## 2. Consequence for a source contact approaching one commuting edge

Suppose the actual source contact has `u_c` infinitesimal and `v_c` a finite nonzero unit, with `d` a positive unit and `rho=1`. At `u=0`, the exact parent is

\[
\begin{aligned}
F={}&4m(vW-X)^2+(4n+2d)(1+v^2)X^2\\
&+[4(c+A)+2d](1+v^2)Y^2+4D(Y+vZ)^2
       +4\alpha(vY-Z)^2.
\end{aligned}\tag{3}
\]

The core gives strict hard floors in `X,Y`. By (1), `D+alpha` is a positive unit, so the `Y,Z` block has positive definite residue for unit `v`. The `W,X` block has positive definite residue unless `m` is weak. Since a normalized contact state has nonzero residue in the kernel of the contact parent, it follows that

\[
 \boxed{m\text{ is weak, and the residue state kernel is exactly }\mathbb RW.}\tag{4}
\]

Thus the entire one-edge weak-source problem has three hard state normals. The two-soft-state scenario is excluded by physicality itself. A rank-two core-kernel problem can still occur when both source measurements approach commuting endpoints; it has not been excluded here.

## 3. The smallest remaining analytical operator

At the physical residue face `m=0`, introduce four state/angle normals. In this paragraph all source coefficients are their residue values (or coefficients of an exactly physical source on that face). An actual weak nonzero `m` is not silently set to zero while retaining its other unmodified coefficients.

\[
 \eta=(X,Y,Z,q)^T,\qquad q=uW.
\]

The leading operator at the edge is a four by four symmetric matrix polynomial in the single remaining angle `v`:

\[
\begin{aligned}
\eta^TL_W(v)\eta={}&(4n+2d)(1+v^2)X^2\\
&+[4(c+A)+2d](1+v^2)Y^2+4D(Y+vZ)^2
       +4\alpha(vY-Z)^2\\
&+[4c(1+v^2)+4D+2d]q^2\\
&-2[4c(1+v^2)+4D+2d]qY-2(4D+2d)vqZ.
\end{aligned}\tag{5}
\]

This is the exact degree-two homogeneous part of the full `m=0` parent after fixing `W=1`, in small variables `(X,Y,Z,u)`, with `q=u`. It has degree at most two in `v`. Physicality of the residue source makes `L_W(v)` PSD for every real `v`: otherwise substituting a sufficiently small common scale into these four normals would make the original parent negative. The hard three by three state block is positive definite at every finite nonzero `v` by (1).

Consequently the univariate matrix factorization theorem applies source-only to this jet: it has a five by four polynomial Gram factor of degree at most one. Evaluation in the independent testing field is legal and requires only the eight features `eta_i,v eta_i`. This gives a structured exact factorization of the leading normal operator, not of the full perturbed parent.

The remaining weighted-division question is now precise: when the scalar Schur curvature of `L_W` vanishes at the source unit angle `v_c`, do the full higher terms and the weak original `m` packet admit a bounded Gram representation in the source-owned contact frame, uniformly in the relative rates of `m`, `u_c`, and `v-v_c`? The answer is not inferred from the jet factorization. The useful next calculation is therefore a scalar transverse opening around a univariate PSD jet with three hard states, rather than a general two by two mixed Schur inverse.

The checker `WEAK_SOURCE_EDGE_NORMAL_FORM.py` verifies the exact test energy (2), the edge factorization (3), and the full quadratic jet (5). The source-only univariate factorization statement uses the same Hanselka--Sinn theorem already verified in the base package; it is not separately recomputed numerically.
