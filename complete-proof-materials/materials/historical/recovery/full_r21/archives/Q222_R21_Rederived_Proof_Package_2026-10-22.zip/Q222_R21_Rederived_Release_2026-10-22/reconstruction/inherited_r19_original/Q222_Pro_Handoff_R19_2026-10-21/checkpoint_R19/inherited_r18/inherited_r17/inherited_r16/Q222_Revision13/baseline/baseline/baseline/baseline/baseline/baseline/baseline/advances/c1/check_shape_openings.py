"""Small exact identities for arbitrary_shape_openings.tex; Python standard library only.

No Groebner basis, numerical positivity test, expanded archive, or external
source file is used. The analytical proof supplies the bounded-Gram lemma.
"""
if not __debug__:
    raise SystemExit('Run without -O: assertions are proof checks.')
from fractions import Fraction as Q
from pathlib import Path
from itertools import permutations
import json
import time

started = time.perf_counter()
checks = []

class P:
    def __init__(self, terms, n):
        self.p = {m:c for m,c in terms.items() if c}
        self.n = n
    def lift(self, q):
        if isinstance(q, P):
            assert q.n == self.n
            return q
        return P({(0,)*self.n:q},self.n)
    def __add__(self, q):
        q=self.lift(q); out=dict(self.p)
        for m,c in q.p.items():out[m]=out.get(m,0)+c
        return P(out,self.n)
    __radd__=__add__
    def __neg__(self):return P({m:-c for m,c in self.p.items()},self.n)
    def __sub__(self,q):return self+-self.lift(q)
    def __rsub__(self,q):return self.lift(q)+-self
    def __mul__(self,q):
        q=self.lift(q);out={}
        for m,c in self.p.items():
            for r,d in q.p.items():
                t=tuple(x+y for x,y in zip(m,r));out[t]=out.get(t,0)+c*d
        return P(out,self.n)
    __rmul__=__mul__
    def __pow__(self,e):
        assert isinstance(e,int) and e>=0
        out=self.lift(1);p=self
        while e:
            if e&1:out=out*p
            p=p*p;e//=2
        return out
    def diff(self,i):
        out={}
        for m,c in self.p.items():
            if m[i]:
                r=list(m);r[i]-=1;out[tuple(r)]=c*m[i]
        return P(out,self.n)
    def sub(self, replacements):
        vs=variables(self.n);vs=[self.lift(replacements.get(i,p)) for i,p in enumerate(vs)]
        powers=[{0:self.lift(1)} for _ in vs]
        out=self.lift(0)
        for m,c in self.p.items():
            term=self.lift(c)
            for i,e in enumerate(m):
                if e not in powers[i]:powers[i][e]=vs[i]**e
                term=term*powers[i][e]
            out=out+term
        return out

def variables(n):
    return [P({tuple(int(i==j) for i in range(n)):1},n) for j in range(n)]
def zero(name,p):
    assert not p.p,(name,len(p.p))
    checks.append(name)
def determinant(A):
    n=len(A);out=A[0][0].lift(0)
    for perm in permutations(range(n)):
        sign=(-1)**sum(perm[i]>perm[j] for i in range(n) for j in range(i+1,n))
        term=A[0][0].lift(sign)
        for i,j in enumerate(perm):term=term*A[i][j]
        out=out+term
    return out

def coefficient(poly,i,e):
    out={}
    for mon,c in poly.p.items():
        if mon[i]==e:
            r=list(mon);r[i]=0;out[tuple(r)]=c
    return P(out,poly.n)

def allocate(name,poly,roots,small):
    mons=[]
    for root in roots:
        assert len(root.p)==1
        (mon,c),=root.p.items();assert c==1
        mons.append(mon)
    pairs=[tuple(a+b for a,b in zip(r,s)) for i,r in enumerate(mons) for s in mons[i:]]
    for mon,c in poly.p.items():
        assert any(all(x>=y for x,y in zip(mon,pair)) and
                   (not small or any(mon[i]>pair[i] for i in small))
                   for pair in pairs),(name,mon,c)
    checks.append(name)

# The four retained-packet subtractions, with all denominators cleared.
p,h,N,L,qA,qB=variables(6)
zero('first retained packet',((1-p)*qA-N)**2-p*N*N-(1-p)*(N*N-2*qA*N+(1-p)*qA*qA))
zero('second retained packet',(N+p*qA)**2-(1-p)*N*N-p*(N*N+2*qA*N+p*qA*qA))
zero('third retained packet',(L+h*qB)**2-(1-h)*L*L-h*(L*L+2*qB*L+h*qB*qB))
zero('fourth retained packet',((1-h)*qB-L)**2-h*L*L-(1-h)*(L*L-2*qB*L+(1-h)*qB*qB))

# All source coefficient errors E_i have zero residue. No restriction on
# the bounded parameters p,h occurs in this entire polynomial calculation.
N,L,u,w,v,Z,eta,p,h,k,Delta,E2,Eb,E3,E5,E4,Ea,Ed=variables(18)
Du=1+u*u;Dv=1+v*v;K=1+k*k;H=8*K*K
H2=H+E2;Hb=H+Eb;H3=H+E3;H5=H+E5
B4=8*Delta*Delta*K**3+E4
Ba=8*Delta**4*k**6*K**3+Ea
Bd=8*Delta*Delta*K**4+Ed
qA=Du*v*w
X=N+p*Du*v*w-u*Z
qB=v*(Du*Z-u*N-p*u*Du*v*w)
Wnum=Du*w+u*(L+h*qB)
Ynum=Du*u*w-(L+h*qB)
zero('inverse coordinate qA',Du*qA-v*(Wnum+u*Ynum))
zero('inverse coordinate qB',qB-v*(Z-u*X))
zero('inverse coordinate N',N-X-u*Z+p*qA)
zero('inverse coordinate L',Du*L-u*Wnum+Ynum+Du*h*qB)
zero('inverse coordinate w',Wnum+u*Ynum-Du*Du*w)

Ghat=Du*(H2*(N*N-2*qA*N+(1-p)*qA*qA)+Hb*Dv*(N*N+2*qA*N+p*qA*qA))
Ghat+=Du*Delta*Delta*(H3*Dv*(L*L+2*qB*L+h*qB*qB)+H5*(L*L-2*qB*L+(1-h)*qB*qB))
Ghat+=B4*eta*eta*Dv*Ynum*Ynum+Ba*eta*eta*(v*Ynum-Du*Z)**2
Ghat+=Bd*eta*((v*Ynum-Du*Z)**2-Dv*Du*Du*Z*Z)
leading=2*H*Du*N*N+2*Delta*Delta*H*Du*L*L
leading+=H*Du**3*(v*w)**2+Delta*Delta*H*Du**3*(v*Z)**2
leading+=8*Delta*Delta*K**3*Du**2*(eta*u*w)**2
leading+=8*Delta**4*k**6*K**3*Du**2*(eta*Z)**2
leading-=16*Delta*Delta*K**4*Du**2*u*v*w*eta*Z
roots=[N,L,v*w,v*Z,eta*w,eta*Z]
allocate('bounded six-root entire remainder Gram',Ghat,roots,[])
allocate('all omitted Gram coefficients have zero residue',Ghat-leading,roots,[4,6]+list(range(11,18)))

# This formal eta coefficient records a Gram residue, never an assertion
# that actual testing/source ratios such as v/eta are bounded.
model=Ghat.sub({i:0 for i in range(11,18)}).sub({0:eta*N,1:eta*L,4:eta*v})
Sn=Delta*Delta*K*u*u*w*w+Delta**4*k**6*K*Z*Z
Sn+=Du*v*v*(w*w+Delta*Delta*Z*Z)-2*Delta*Delta*K*K*u*v*w*Z
expected=16*K*K*Du*N*N+16*Delta*Delta*K*K*Du*L*L+8*K*K*Du*Du*Sn
zero('shape-free leading model',coefficient(model,6,2)-expected)
zero('matched-angle scalar squares',Sn.sub({2:k})-Delta*Delta*K*(v*Z-k*w)**2-K*(v*w-Delta*Delta*k**3*Z)**2)
zero('state root relation',w*(v*Z-k*w)-Z*(v*w-Delta*Delta*k**3*Z)-k*(Delta*Delta*k*k*Z*Z-w*w))
zero('angular capacity factorization',(1+u*u)*(u+k**3)**2-K**3*u*u-(u-k)**2*(k**4+2*k**3*u+2*k*u+u*u))

contact={2:k,3:Delta*k,4:Delta*k*k,5:1}
zero('leading scalar value at contact',Sn.sub(contact))
for i,name in [(4,'nu'),(3,'w'),(2,'u')]:
    zero('leading scalar first derivative '+name,Sn.diff(i).sub(contact))
HM=[[K*K,K*k*(k*k-1),K*Delta*k*(k*k-1)],
    [K*k*(k*k-1),k*k*K*K,Delta*k*k*(k**4+1)],
    [K*Delta*k*(k*k-1),Delta*k*k*(k**4+1),Delta*Delta*k*k*K*K]]
indices=[4,3,2]
for i in range(3):
    for j in range(i,3):
        zero('scalar half-Hessian %d%d'%(i+1,j+1),Q(1,2)*Sn.diff(indices[i]).diff(indices[j]).sub(contact)-Delta*Delta*HM[i][j])
zero('scalar Hessian principal minor 1',HM[0][0]-K*K)
zero('scalar Hessian principal minor 2',determinant([r[:2] for r in HM[:2]])-4*k**4*K*K)
zero('scalar Hessian principal minor 3',determinant(HM)-12*Delta*Delta*k**8*K*K)

for mon,c in Ghat.p.items():
    ndegree=mon[0]+mon[1]+mon[4]
    assert ndegree>=2 or ndegree+mon[6]>=2
checks.append('full weighted normal ideal inclusion')
G19=P({mon+(0,):c for mon,c in Ghat.p.items()},19)
vs=variables(19)
translated=G19.sub({4:vs[4]+vs[6]*vs[18]})
for mon,c in translated.p.items():
    ndegree=mon[0]+mon[1]+mon[4]
    assert ndegree>=2 or ndegree+mon[6]>=2
checks.append('generic eta-sized contact shift preserves inclusion')

# Capped full-parent endpoint allocations, with arbitrary bounded positive
# weak coquotients, independent of shape units or normalized event size.
mu,A2,al2,d1,eta,u,v,W,Z,x,y=variables(11)
Du=1+u*u;Dv=1+v*v;Y=u*W-y
F=4*mu*(v*(Du*W-u*y)-x)**2+4*mu*Dv*y*y+4*eta*eta*A2*Du*Dv*Y*Y
F+=(4*mu+2*eta*d1)*(y+v*(u*x-Du*Z))**2
F+=4*eta*eta*al2*Du*(v*Y-Z)**2+(4*mu+2*eta*d1)*Dv*x*x
F+=2*eta*d1*Du*((v*Y-Z)**2-Dv*Z*Z)
lead=4*mu*((v*Du*W-x)**2+x*x+y*y+(y-v*Du*Z)**2)
lead+=4*A2*Du*(eta*u*W)**2+4*al2*Du*(eta*Z)**2
allocate('capped Alice-zero whole-parent Gram',F,[x,y,v*W,v*Z,eta*u*W,eta*Z],[])
allocate('capped Alice-zero omitted coefficients vanish',F-lead,[x,y,v*W,v*Z,eta*u*W,eta*Z],[4,5,6])
q=u;XX=W;YY=Z
FR=4*mu*(v*((1+q*q)*YY+q*y)-x)**2+4*mu*Dv*y*y
FR+=4*eta*eta*A2*(1+q*q)*Dv*YY*YY
FR+=(4*mu+2*eta*d1)*(y+v*((1+q*q)*XX-q*x))**2
FR+=4*eta*eta*al2*(1+q*q)*(v*YY-x+q*XX)**2+(4*mu+2*eta*d1)*Dv*x*x
FR+=2*eta*d1*(1+q*q)*((v*YY-x+q*XX)**2-Dv*(x-q*XX)**2)
LR=4*mu*((v*YY-x)**2+x*x+y*y+(y+v*XX)**2)
LR+=4*A2*(eta*YY)**2+4*al2*(eta*q*XX)**2
allocate('capped reciprocal Alice whole-parent Gram',FR,[x,y,v*YY,v*XX,eta*YY,eta*q*XX],[])
allocate('capped reciprocal Alice omitted coefficients vanish',FR-LR,[x,y,v*YY,v*XX,eta*YY,eta*q*XX],[4,5,6])

out={'status':'PASS','checks':len(checks),'identities':checks,
     'seconds':time.perf_counter()-started,
     'method':'standard-library exact sparse rational polynomial arithmetic; no source-rate split or Groebner step',
     'scope':'all positive a,t,M,J openings with ordinary unit k,s and infinitesimal eta; native source definitions and strict bounded-Gram lemma inherited explicitly'}
Path(__file__).with_name('shape_openings_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))

