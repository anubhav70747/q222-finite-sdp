# Current residual source tree

All open domains are intersected with original physicality, positive infinitesimal delta_tot, and the complement of every proved admission and exact symmetry image. A listed residual domain need not be nonempty.

The printed checklist and root CHECKLIST.json give the exact completion gates. All actual C2 IU,UH,UU contacts are now closed.

- C1.1: k,zeta infinitesimal; eta unbounded
- C1.2: k,zeta infinitesimal; eta bounded unit; r infinitesimal; e unbounded
- C1.3: k,zeta infinitesimal; eta bounded unit; e infinitesimal; any 0<r<1
- C1.4: k infinitesimal; zeta noninfinitesimal; eta arbitrary positive
- C1.5: k bounded unit; eta or zeta noninfinitesimal
- C2.W.IH: IH
- C2.W.HI: HI
- C2.W.HU: HU
- C2.W.HH: HH
- C2.S.II_HH: II_HH
- C2.S.IH: IH
- C2.S.UI_HU: UI_HU
- C2.S.HI: HI

13 is a finite conditional partition, not 13 proved nonempty obstructions and not a percentage of completion.
