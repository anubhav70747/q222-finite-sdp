# Same-system review: C1 UI remote complement

The recovered proof originally omitted testing u infinitesimal and v projectively infinite. This was a genuine exhaustion gap: CR5 assumed u a unit, and its Z pivot vanishes when u has zero residue. The proof and checker now contain the exact CR5a replacement. With w=1/v, EQ=(W+uY)/g, EB=(X+uZ)/g, U=uZ and T=gwZ, the five-root selected residue is

4 mu EQ^2 + 4 nu EB^2 + 2 Y^2 + 2 U^2 + 4 b T^2.

The exact bounded core is printed in CR5a and checked against the original homogeneous core. There is no division by u or w, so literal endpoints are retained. Together with CR5--CR13 and the inherited unit/unit admission, the complement now exhausts every testing pair except the explicitly stated ordinary/small strip.

The source assertion CR1 follows directly from NC2--NC4 and NI7. In the chosen native orientation zeta=g^2, write x=k^2. The exact scaled weights are

- g^2 m/d = K x (r+eta) h (1+y) / (2 M P_d).
- g^2 beta/d = K x (r+eta) G / (2 t P_d) - g^2/2.
- C/d = K (r+eta) E / (2 (1-r) P_d).
- A/d = eta P_4 / (2 r P_d).
- alpha/(d g^2) = x^2 (r+eta) P_alpha / (2 Q P_d).

Here x, eta, h, G, E, Q, P_d, P_4, P_alpha and r+eta are positive units by NI7. The positive factors M,t,r,1-r in denominators are bounded, though they may be infinitesimal. Thus all five weights are strong; alpha/(d g^2) is actually a unit. The subtractive term g^2/2 in the beta expression is infinitesimal and cannot remove its positive lower bound. The reflected representative's E is a unit by the exact stabilizer expression E'=h(1+y)/G. No unsupported assumption k<=1 is reintroduced after reflection.

Every finite cap is therefore justified by the original source. D is retained in full and may be exactly zero. The parent uses the exact gauges separately in u and v, and the core formulas are homogeneous at every projective endpoint.

Scope: this is a same-system mathematical review, not an independent external verification. It certifies the repaired remote complement. It does not close the remaining ordinary/small testing strip or the actual UH source subcase of C1.5.
