"""Verify packaged bytes, not the validity of mathematical arguments."""
from pathlib import Path
import hashlib,json
root=Path(__file__).resolve().parent
records=json.loads((root/"MANIFEST_R16.json").read_text())["files"]
bad=[]
for record in records:
    path=root/record["path"]
    if not path.is_file() or hashlib.sha256(path.read_bytes()).hexdigest()!=record["sha256"]:
        bad.append(record["path"])
if bad:
    raise SystemExit("Integrity failure: "+repr(bad))
print(f"PASS: {len(records)} packaged files match their SHA-256 hashes.")
