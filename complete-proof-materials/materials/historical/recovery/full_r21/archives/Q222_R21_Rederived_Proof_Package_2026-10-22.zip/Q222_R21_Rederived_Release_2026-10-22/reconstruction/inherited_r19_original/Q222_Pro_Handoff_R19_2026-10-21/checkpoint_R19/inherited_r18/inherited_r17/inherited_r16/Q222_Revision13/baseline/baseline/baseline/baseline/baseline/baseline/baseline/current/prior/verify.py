#!/usr/bin/env python3
"""Replay the five new exact identity suites, without numerical sampling."""
from pathlib import Path
import argparse, json, os, subprocess, sys, time
if not __debug__:
    raise SystemExit('Run without -O: exact checks use assertions.')
root = Path(__file__).resolve().parent
ap = argparse.ArgumentParser()
ap.add_argument('--with-sympy', action='store_true', help='include three symbolic C2 and budget suites')
args = ap.parse_args()
jobs = ['c1/check_entry_identities.py', 'cover/check_compressions.py']
if args.with_sympy:
    jobs += ['c2/check_weak_packet_entry.py', 'matching/check_matching_source.py', 'budget/check_weighted_budget.py']
reports = []
for job in jobs:
    start = time.monotonic()
    env = os.environ.copy()
    env.pop('PYTHONOPTIMIZE', None)
    proc = subprocess.run([sys.executable, str(root / job)], cwd=root, env=env, text=True, capture_output=True)
    reports.append({'script': job, 'exit_code': proc.returncode, 'seconds': round(time.monotonic() - start, 3)})
    print(('PASS ' if proc.returncode == 0 else 'FAIL ') + job, flush=True)
    if proc.returncode:
        print(proc.stdout)
        print(proc.stderr, file=sys.stderr)
out = {'status': 'PASS' if all(r['exit_code'] == 0 for r in reports) else 'FAIL',
       'with_sympy': args.with_sympy, 'suites': reports,
       'scope': 'New exact algebraic identities and source checks only. Inherited theorems and the retained global atlas are not freshly replayed by this script.'}
(root / 'verification').mkdir(exist_ok=True)
(root / 'verification' / 'FRESH_CHECKS.json').write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps(out, indent=2))
raise SystemExit(0 if out['status'] == 'PASS' else 1)
