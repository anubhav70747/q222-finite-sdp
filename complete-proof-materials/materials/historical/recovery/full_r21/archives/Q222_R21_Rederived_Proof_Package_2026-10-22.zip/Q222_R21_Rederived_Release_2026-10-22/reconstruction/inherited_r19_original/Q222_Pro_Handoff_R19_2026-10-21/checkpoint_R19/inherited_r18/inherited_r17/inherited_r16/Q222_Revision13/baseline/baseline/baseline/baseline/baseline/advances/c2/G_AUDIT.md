# Scoped review of the last C2 opening with bounded n

**Verdict: PASS for the stated domain: k,b are positive bounded units, x is positive infinitesimal, the original openings are positive, n is nonnegative, the original source is physical, and at least one of r,g is a bounded unit.** The newly reviewed case is g infinitesimal and r a unit. The existing three-opening theorem supplies g a unit, including r infinitesimal. The joint r,g infinitesimal domain is excluded.

This is a separate-agent review within the same assistant system, not an external or formal verification. I read the complete candidate `c2_last_opening.tex`, the reviewed three-opening extension and audit, the baseline `general_single_angle.tex`, and the author's new checker. I reconstructed the original full C2 parent independently and executed four exact polynomial checks: the entire X first normal, the entire triangular Y first normal, and the two cancellations of m from the mixed and Y hard coefficients. All four passed; see `check_g_audit_normals.py` and `g_audit_checks.json`. The prose proof and the scoped arguments below are the mathematical basis of the verdict. There was no numerical sampling, atlas replay, or global source-classification audit.

## 1. Source entry and remaining denominators

Since k,b are units, 0<r<1 and 0<h<b, g=b−1+r+xh is bounded. The only new case after the previous theorem is therefore g positive infinitesimal. The hypothesis that at least one of r,g is a unit makes r a unit in that case. At residue, b_0+r_0=1, so 0<b_0<1 and 1−r is a unit. The original formula for n has unit denominator r Delta, making n bounded, including n=0.

The identity

`mg=(1+k^2)(1−r) A_c S_c/(2 Delta)`

is exact and has positive unit residue. Thus m is unbounded and 1/sqrt(m) is infinitesimal. The previous n>=0 argument still gives b−k^2 r a positive unit, hence D/x and alpha/x positive units. The complementary-opening cancellation identities CO1 still hold. In particular H=x(C+A) is bounded below, and 1/sqrt(H) is bounded even when H is unbounded. All inverses and square roots used as coefficients are pure coefficient or pure testing operations. No mixed denominator is inverted.

## 2. The original m amplitude determines the triangular hard normal

The exact-contact graph is

`Y_g=eta uW`, `X_g=v(1+eta u^2)W−(1+g)uZ`, with `eta=h/b`.

It gives X_g=−rho r at the original contact. More importantly, the complete original m amplitude satisfies M|g=g uZ. With

`E_M=sqrt(m)[X−X_g−uv(Y−Y_g)]`, `E_Y=sqrt(C+A)(Y−Y_g)`,

the identity M=g uZ−E_M/sqrt(m) is exact. Thus the unbounded packet contributes no E_Y term and gives exactly the hard pivot 4 on E_M. Its scalar coefficient is 4mg^2, which is bounded, and its first-normal coefficient before normalization is −8mg uZ, also bounded. This is a full-parent cancellation, not a Schur complement inferred only at contact.

For explicit verification, set

`H_v=1−eta+v^2(1+eta u^2)`.

Direct differentiation of the full parent gives

`F_X|g=vW A_X+uZ B_X`,

where

`A_X=(8n D_uD_v+4D_v)(1+eta u^2)+(8D+4)u^2 H_v`,

`B_X=−8n D_uD_v(1+g)−8mg−(8D+4)v^2[1+(1+g)u^2]−4gD_v`.

All coefficients are bounded. Consequently division by sqrt(m) gives zero-residue coefficients on V=vW and B=uZ.

For the Y direction, the complete relevant derivative is G_Y=F_Y+uv F_X. The m packet cancels identically before graph substitution. Exactly,

`G_Y|g=8D_v[A eta D_u−C(1−eta)]uW+uW e_w+[u^2 e_z+8v(D−alpha)]Z`,

with

`e_w=(8D+4)(u^2v^2−1)H_v+(8alpha+4)D_u v^2 eta+8n v^2D_uD_v(1+eta u^2)+4v^2D_v(1+eta u^2)`,

`e_z=v{(8D+4)[1+g−v^2−(1+g)u^2v^2]−(8alpha+4)−8nD_uD_v(1+g)−4gD_v}`.

These residual coefficients are bounded. The two apparently large linear products in the first term reduce to T_A/b and T_C/b after multiplying by x, and their residues agree. This establishes the old CO5 form, now for the triangular derivative, with all the stated boundedness and zero-residue properties.

The exact hard entries transform to H_XX/m, `(H_XY+uv H_XX)/(sqrt(m)sqrt(C+A))`, and `(H_YY+2uvH_XY+u^2v^2H_XX)/(C+A)`. The unbounded m terms cancel from the last two numerators. The remaining packet weights are bounded except C,A, whose contribution is exactly `4D_v[1+A u^2/(C+A)]`. Hence the hard block has bounded coefficients and residue diag(4,4D_v) along the finite u=0 residue axis.

## 3. Five Laurent terms suffice for both uniqueness and strictness

Expanding the determinant of the weighted leading scalar gives precisely CG7:

`D/[(1+z)sz]=2Q(nu−1)s/z+2Q nu s+2nu E_2 z/s+2nu E_0/s+Q E_0/z+Q E_2−4nu`.

Here nu=2n_0+1>=1. All nonconstant coefficients except the first are strictly positive. After z=k_0^2 t, exact stationary contact gives c=a+e and b=d+e in the ordered coefficients of s/t,s,t/s,1/s,1/t. The zero value fixes the constant. The resulting identity is exactly

`a(s/t+t/s−2)+d(s+1/s−2)+e(t/s+s+1/t−3)`.

The reverse three-cycle has positive coefficient e. Its three terms have product one, and equality forces s=t=1. In logarithmic coordinates its Hessian is `[[2,−1],[−1,2]]`, which is positive definite. Thus this single term already proves the unique positive-quadrant zero and strict two-variable contact Hessian. Neither assertion relies on the possibly absent first reciprocal pair. This handles n_0=0 as well as n_0>0.

At v_0=0,n_0>0, the cross term is moved from BV to vPE using the exact identity BV=vPE; its residue then vanishes. The remaining scalar-root pivots are positive. At nonzero remote v, the baseline cross-term split applies with the new Laurent identity. These are global scalar arguments on their domains, not extrapolations from the contact Hessian.

## 4. Matched contact restores the entire normals

On the graph, C,A enter the scalar only through CO1 and m enters only through mg^2. Hence both Q_b and B_b in `f=p^2 Q_b/x+B_b` are coefficientwise bounded. Finite monic differences in u^2,W^2,uW and v retain this property. The baseline four exact conductors R,S,U,T therefore give a bounded soft Gram; the strict three-variable Hessian follows from the just-proved Laurent identity and the completed state square. The baseline exact zero used to split the angular reserve then gives the strict four-root Gram.

For the E_M first normal, the bounded functions in `uA_1+WB_1` have a common factor 1/sqrt(m). This factor survives every monic quotient. Exact normal contact gives `(A_1+kappa B_1)_c=0`. Differences in u^2 and uW produce coefficients containing u^2,uW or u rho; the v−k quotient retains 1/sqrt(m). Thus every coefficient in the R,S,U,T lift has zero residue, with no division by a testing infinitesimal.

For E_Y, the explicit triangular derivative in Section 2 gives exactly the baseline representation `R B_2+rho E_2'`, subsequently divided by sqrt(H). B_2 and E_2' have identically zero leading functions, and exact normal contact makes E_2' vanish at contact. The same finite monic contact differences yield the required zero-residue lift. The quadratic hard block was checked in Section 2. Accordingly the full-parent matched Gram, including both hard normals, is strict.

## 5. The remote n_0=0 double-zero corner

The replacement graph uses

`H_c=4m+4n+2`, `xi=4m/H_c`, `zeta=(4m+2)/H_c`, `eta_c=C/(C+A)`,

`Y_g=eta_c uW`, `X_g=xi v(1+eta_c u^2)W−zeta uZ`.

The factor 1+eta_c u^2 is necessary here to keep the original m amplitude bounded after multiplication by m. Indeed m(1−xi)=m(4n+2)/H_c and m(zeta−1)=−4mn/H_c are bounded. Both are pure coefficient expressions. The triangular hard normals cancel m from the Y direction exactly as before.

The epsilon reserve `epsilon=4alpha+4n zeta` is positive and infinitesimal when n_0=0. Since zeta is a positive unit and alpha/x is a positive unit, both n/epsilon and x/epsilon are bounded, including literal n=0. The exact scalar Z coefficient CG10 follows from `4n zeta^2+(4m+2)(1−zeta)^2=4n zeta`. Its remaining u^2v^2 coefficient has residue 2. The W coefficients on P,V have residues Q,2, and the cross term is a bounded multiple of vPE. Consequently the five scalar-root pivots are precisely the positive entries (Q,2,E_0,1,2).

The full X derivative at v=0 has Z coefficient −8n zeta u^3. Dividing by sqrt(H_c) and expressing it on sqrt(epsilon)uZ is bounded with zero residue, because n/sqrt(epsilon)=(n/epsilon)sqrt(epsilon) is infinitesimal. The remaining Z coefficient has a factor uv^2; the W coefficient has a factor v and bounded coquotient. Their hard normalization gives the required zero residues. The triangular Y derivative retains the exact large-packet cancellation and the CO6 harmonic identity, so its P,T,E lift likewise has zero-residue coefficients after division by sqrt(H). The hard residue is diag(1,4). This covers the literal n=0 corner without dropping a coordinate or packet.

## 6. Outer charts, changes made, and scope

The outer identities permit C,A to be capped at sigma/x with sigma=min(1,xC,xA), retaining the nonnegative excess packets. They also permit m to be capped at min(m,1), which is a positive unit here; its full nonnegative excess remains as the original m square. The displayed outer pivots stay positive, and the reciprocal-Bob chart retains its D/x pivot. No physicality claim about the capped source is needed: the argument uses exact packet identities and explicit strict residue Grams. The inherited noncommuting-residue theorem is used only for the original physical source.

I corrected three typography mistakes in the candidate: `−8mg,uZ`, `sqrt(epsilon),uZ`, and `E,8v(D−alpha)` are multiplications, and are now typeset with thin spaces. These changes do not alter the mathematics.

The final scoped coverage is the union of the reviewed g-unit theorem and the new g-infinitesimal/r-unit theorem. Positive arbitrarily small h or b−h are allowed; literal zero openings are not. No relative comparison of source and testing infinitesimals is assumed. Joint r,g infinitesimal, nonunit k or b, other C2 source charts, and the global analytical source-exhaustion/final finite-lift join remain outside this review.
