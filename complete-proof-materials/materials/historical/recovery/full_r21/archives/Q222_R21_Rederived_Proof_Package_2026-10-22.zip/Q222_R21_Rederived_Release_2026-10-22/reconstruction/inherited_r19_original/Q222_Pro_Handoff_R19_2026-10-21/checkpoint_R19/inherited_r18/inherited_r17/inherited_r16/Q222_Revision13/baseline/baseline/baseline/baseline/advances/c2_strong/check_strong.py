"""Small exact identities for the strong C2 complementary-scale completion.

No atlas or numerical positivity premise. Run with SymPy available.
Ordered-field estimates and all-tests arguments are in the companion TeX.
"""
from pathlib import Path
import json
import time
import sympy as s

started = time.perf_counter()
checks = []

def zero(name, expr):
    value = s.cancel(expr)
    assert value == 0, (name, value)
    checks.append(name)

def shape(name, expr, min_power, parity):
    numerator, denominator = s.fraction(s.cancel(expr))
    assert not denominator.has(u), (name, denominator)
    poly = s.Poly(s.expand(numerator), u)
    assert all(e[0] >= min_power and e[0] % 2 == parity
               for e, coeff in poly.terms()), name
    checks.append(name)

d,n,m,C,A,D,al,u,v,W,X,Y,Z = s.symbols('d n m C A D al u v W X Y Z')
x,r0,p0,j0,eta,beta = s.symbols('x r0 p0 j0 eta beta')
Du, Dv = 1+u*u, 1+v*v
r = u*W-Y
p = v*Y-Z
J = u*W+u*v*X-Y-v*Z
R2 = v*W-X+u*p
B = X+u*Z
H = 2*(J*J+Du*p*p+Dv*B*B-Du*Dv*Z*Z)
F = d*H+4*n*Du*Dv*X*X+4*m*R2*R2+4*C*Dv*r*r+4*A*Du*Dv*Y*Y+4*D*J*J+4*al*Du*p*p
FX,FY,FZ = [s.diff(F,t) for t in (X,Y,Z)]
zero('full X state equation', FX/4-(Dv*(d+2*n*Du)*X+(d+2*D)*u*v*J+d*u*Dv*Z-2*m*R2))
zero('full Y state equation', FY/4-(-(d+2*D)*J+(d+2*al)*v*Du*p-2*C*Dv*r+2*A*Du*Dv*Y+2*m*u*v*R2))
zero('full Z state equation', FZ/4-(-(d+2*D)*v*J-(d+2*al)*Du*p+d*u*Dv*B-d*Du*Dv*Z-2*m*u*R2))
qJ = 4*((d+2*D)*J+2*C*r-2*A*Du*Y-d*u*v*B+d*v*Du*Z)
qP = 4*((d+2*al)*Du*p-2*C*v*r+2*A*v*Du*Y+2*m*u*R2-d*u*B+d*Du*Z)
zero('entire adapted J/r normal', -(FY+v*FZ)/Dv-qJ)
zero('entire adapted p normal for case II', (v*FY-FZ)/Dv-qP)

graphs = {
    'I': {W:1, X:x*u*u, Y:(1-r0)*u, Z:(v*(1-r0)-p0)*u},
    'II': {W:1, X:x*u*u, Y:u*(1-j0+v*p0+x*u*u*v)/Dv,
           Z:v*u*(1-j0+v*p0+x*u*u*v)/Dv-p0*u},
}
for branch,g in graphs.items():
    sub=lambda e: s.cancel(e.subs(g, simultaneous=True))
    phi=sub(F)
    zero(branch+' graph X', sub(X)-x*u*u)
    zero(branch+' graph p', sub(p)-p0*u)
    zero(branch+' entire graph R2', sub(R2)-(v+(p0-x)*u*u))
    shape(branch+' entire graph scalar', phi-4*m*v*v, 2, 0)
    if branch=='I':
        normals=(FX, -(FY+v*FZ), -FZ)
        zero('I graph r',sub(r)-r0*u)
        zero('I C graph packet',s.diff(phi,C)-4*Dv*r0*r0*u*u)
        zero('I C normal packet',s.diff(sub(normals[1]),C)-8*Dv*r0*u)
        zero('I alpha absent from r normal',s.diff(sub(normals[1]),al))
    else:
        normals=(FX+u*v*(FY+v*FZ)/Dv, -(FY+v*FZ)/Dv, (v*FY-FZ)/Dv)
        zero('II graph J',sub(J)-j0*u)
        zero('II D graph packet',s.diff(phi,D)-4*j0*j0*u*u)
        zero('II D normal packet',s.diff(sub(normals[1]),D)-8*j0*u)
        zero('II D absent from X normal',s.diff(sub(normals[0]),D))
        zero('II alpha absent from X normal',s.diff(sub(normals[0]),al))
        zero('II alpha absent from J normal',s.diff(sub(normals[1]),al))
        zero('II D absent from p normal',s.diff(sub(normals[2]),D))
    shape(branch+' entire X first normal',sub(normals[0])+8*m*v,2,0)
    shape(branch+' entire second first normal',sub(normals[1]),1,1)
    shape(branch+' entire third first normal',sub(normals[2]),1,1)
    zero(branch+' n graph packet',s.diff(phi,n)-4*x*x*u**4*Du*Dv)
    zero(branch+' alpha graph packet',s.diff(phi,al)-4*Du*p0*p0*u*u)
    zero(branch+' n X-normal packet',s.diff(sub(normals[0]),n)-8*x*u*u*Du*Dv)
    zero(branch+' alpha p-normal packet',s.diff(sub(normals[2]),al)-8*Du*p0*u)

# Two exact inverse-coordinate packet identities and entire outer Grams.
outer_I={Y:u*W-eta, Z:v*(u*W-eta)-beta}
outer_II={Y:(u*W+u*v*X+v*beta-eta)/Dv,
          Z:v*(u*W+u*v*X+v*beta-eta)/Dv-beta}
for branch,substitution in [('I',outer_I),('II',outer_II)]:
    outer=s.cancel(F.subs({m:0,n:0}).subs(substitution,simultaneous=True))
    numerator,denominator=s.fraction(outer)
    assert not denominator.has(W,X,eta,beta,u)
    for powers,coefficient in s.Poly(s.expand(numerator),W,X,eta,beta,u).terms():
        assert powers[4]>=powers[0],(branch,powers)
    checks.append(branch+' entire outer form is quadratic in X,eta,beta,uW')
    if branch=='I':
        zero('I retained C amplitude',s.diff(outer,C)-4*Dv*eta*eta)
    else:
        zero('II retained D amplitude',s.diff(outer,D)-4*eta*eta)
    zero(branch+' retained alpha amplitude',s.diff(outer,al)-4*Du*beta*beta)

# Exact boundary Schur calculation; v remains a formal real variable here.
y,z=s.symbols('y z')
lead=s.Poly(s.expand(F.subs({m:0,W:1,X:0,Y:y*u,Z:z*u},simultaneous=True)),u).coeff_monomial(u*u)
ss=4*(C+A)+2*d
b11=ss*Dv+4*D+4*al*v*v
b12=4*v*(D-al)
b22=4*D*v*v+4*al
l1=-4*C*Dv-(4*D+2*d)
l2=-(4*D+2*d)*v
cc=4*C*Dv+4*D+2*d
zero('entire boundary form',lead-(b11*y*y+2*b12*y*z+b22*z*z+2*l1*y+2*l2*z+cc))
det=s.expand(b11*b22-b12*b12)
zero('factored positive hard determinant',det-4*Dv*(ss*(D*v*v+al)+4*D*al*Dv))
Q10=4*al*A*(d+2*(C+D))
Q12=4*C*D*(d+2*(al+A))
Q0=8*A*C*D+8*A*C*al-4*A*D*d-2*A*d*d-2*C*d*d-4*C*d*al-2*D*d*d-4*D*d*al-d**3-2*d*d*al
num=det*cc-(b22*l1*l1-2*b12*l1*l2+b11*l2*l2)
zero('exact Schur quartic numerator',num-8*Dv*(Q10+Q0*v*v+Q12*v**4))
hard=b11*y*y+2*b12*y*z+b22*z*z
zero('I hard form explicit two pivots',hard.subs({y:-eta,z:-v*eta-beta},simultaneous=True)-4*C*Dv*eta*eta-4*al*beta*beta-((4*A+2*d)*Dv*eta*eta+4*D*(Dv*eta+v*beta)**2))
zero('II hard form explicit two pivots',hard.subs({y:(v*beta-eta)/Dv,z:(-beta-v*eta)/Dv},simultaneous=True)-4*D*eta*eta-4*al*beta*beta-ss*(v*beta-eta)**2/Dv)
zero('endpoint finite hard determinant',det.subs(v,0)-4*al*(ss+4*D))
zero('endpoint reciprocal hard determinant',s.Poly(det,v).coeff_monomial(v**4)-4*D*(ss+4*al))
physical_test=s.expand(F.subs({W:1,X:0,Y:u,Z:v*u},simultaneous=True))
zero('physicality test kills arbitrary C alpha n',physical_test-(-2*d*u*u*v*v+4*m*v*v+4*A*Du*Dv*u*u+4*D*u*u*v**4))

report={
    'status':'PASS','count':len(checks),'checks':checks,
    'seconds':round(time.perf_counter()-started,3),
    'arithmetic':'exact symbolic identities only',
    'scope':'full state derivatives; both full graphs and all first-normal shapes; original large packet amplitudes; exact real boundary Schur quartic; full outer coordinate forms; endpoint determinants; physicality exclusion',
    'not_claimed':'formal proof of ordered-field estimates or global coverage; no atlas replay'
}
Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
