# Strong C2 UI: bounded remainder and homogeneous lifting mechanism

Status: exact reductions and a reusable leading completion. The local positivity gate below is now proved in `local_ui_certificate.tex` and has received a scoped separate-agent review. **No new all-tests source admission.** The local theorem applies only to independent tests whose ordinary angle matches the actual source residue and whose second angle is infinitesimal; the outer-chart join remains open.

## Source domain and bounds

Use the original canonical C2 source with d = 1, actual u_c = a a positive bounded unit, actual v_c = k a positive infinitesimal, and C, alpha bounded below by positive real numbers. Put z = a^2, epsilon = k^2/z, and use the unchanged source chart b,r,t,h,g,j. Thus

    h = b - epsilon t,
    Ac = 1 + z r,
    j = Ac - t,
    g = (1+z)b - 1 + r - epsilon z t,
    S = Ac + epsilon z t.

The source inequalities imply t,h,b bounded, Delta a positive bounded unit, and b+r a positive bounded unit. If h were infinitesimal, b and the positive source numerator N would be infinitesimal, while 1-zh would be a unit; alpha would be weak. Thus h and b are units. The exact n-numerator at r = 1 is -z(epsilon+h)(b+1)(z+1); n >= 0 therefore forces 1-r to be a unit. The original source formulas now give

    m g,   A/epsilon,   epsilon C t,
    epsilon D j,   alpha(1-zh)

positive bounded units, and nr bounded. In particular m is strong, A is weak, and k^2 CD/(C+D) is a positive bounded unit, since t+j = Ac is a unit.

Normalize the actual state by W_c = 1 and define bounded pure-source quantities

    x = -r/b,
    rho = t/(ab),
    sigma = -j/(ab),
    s = sigma-rho = -Ac/(ab),
    mu = g/b,
    pi = (zh-1)/(ab).

The contact has X_c = kx, Z_c = k/(ab), Y_c = a-rho k^2, r_amp,c = rho k^2, J_c = sigma k^2, M_c = mu k, p_c = pi k, and Q_c = s k, where Q = uX-Z. Moreover nx, m mu, alpha pi, C rho k^2, and D sigma k^2 are bounded.

One additional cancellation is exact, rather than only asymptotic:

    Ct-Dj = [(1+z)(b+r){Ac j-z t(b-epsilon z r)}
             -Ac(1+epsilon z)(1-r)t]/(2 Delta).

Consequently C rho + D sigma = (Ct-Dj)/(ab) is bounded for arbitrary positive t and j, including infinitesimal openings.

## Exact full-parent packet reduction

Let L = C+D, q = D/L, H = CD/L, and tau = (C rho+D sigma)/L. These are pure-coefficient quantities. The exact original C/D identity is

    C(1+v^2)r_amp^2 + D J^2
      = L(r_amp+q vQ)^2 + H v^2 Q^2 + C v^2 r_amp^2.

Retain the following nonnegative squares, with their displayed factor 4:

    4L(r_amp+q vQ-tau k^2 W)^2,
    4H(vQ-s k^2 W)^2,
    4C v^2(r_amp-rho k^2 W)^2.

Every root vanishes at the exact contact. Their subtraction leaves precisely

    8L tau k^2 W(r_amp+q vQ) - 4L tau^2 k^4 W^2
    + 8H s k^2 vWQ - 4H s^2 k^4 W^2
    + 8C rho k^2 v^2 W r_amp - 4C rho^2 k^4 v^2 W^2.

All displayed coefficients are bounded: L tau is bounded, 1/L is bounded, k^2H is a unit, and C rho k^2 is bounded. This is the reason to center at the constant source amplitudes k^2W rather than at v^2W.

Choose bounded pure-source caps 0 <= n_* <= n and positive bounded units m_* <= m and alpha_* <= alpha. Also retain

    4(n-n_*) Du Dv (X-xvW)^2,
    4(m-m_*) (M-mu vW)^2,
    4(alpha-alpha_*) Du (p-pi vW)^2.

The corresponding remainders are, respectively,

    4n_* Du Dv X^2 + 8(n-n_*)x vW Du Dv X
                            - 4(n-n_*)x^2 v^2 W^2 Du Dv,
    4m_* M^2 + 8(m-m_*)mu vWM - 4(m-m_*)mu^2 v^2 W^2,
    4alpha_* Du p^2 + 8(alpha-alpha_*)pi vW Du p
                            - 4(alpha-alpha_*)pi^2 v^2 W^2 Du.

They have bounded coefficients by the source product bounds. Keeping the unchanged signed core and the original weak A term gives an exact bounded polynomial remainder G. All retained packets and their first derivatives vanish at contact, so G has exact zero value and all first derivatives there. This construction accounts for the entire parent and every normal; it does not prove that G itself is nonnegative.

## Bounded homogeneous lift near u = a

Use the graph and ordinary normals

    E_X = X-xvW,
    E_Z = Z-(ux-s)vW,
    E_r = r_amp-rho k^2 W,
    Q_N = u E_X-E_Z.

The state inverse is polynomial, and Q = s vW+Q_N exactly. Define tensor roots

    R_h = [vQ-s k^2 W]/k,
    R = (v^2-k^2)W/k,
    S_u = v(u-a)W,
    T_u = k(u-a)W.

The decisive identities are

    kR = (k R_h-v Q_N)/s,
    R T_u = (R_h T_u-S_u Q_N)/s,
    S_u^2-T_u^2 = ((u-a)/s)(R_h T_u-S_u Q_N).

Only the pure-source unit s is inverted. The second identity avoids introducing v/k as a Gram coefficient. The final identity permits redistribution between the two angular square coefficients; its other coefficients vanish in residue when u-a is infinitesimal.

In the scalar of G, parity and its original degree show membership in (k^2,v^2). Exact contact and angular stationarity allow Taylor division in u-a and v^2-k^2. The resulting terms have the form

    (u-a)^2[k^2 A0+v^2 A1]W^2
    + (u-a)(v^2-k^2)B W^2
    + (v^2-k^2)^2 C0 W^2,

with bounded coquotients. The identities above allocate these on (R_h,S_u,T_u,E_X,E_Z), with no mixed inverse. The first E_X and E_Z normals are odd in v, so their contact-vanishing coefficients have the form v[(u-a)L0+(v^2-k^2)L1]; they lift on the same roots. The E_r normal belongs to (k^2,v^2), and its contact-vanishing Taylor division similarly gives k T_u, v S_u, and kR terms. The exact state degree is two, so the remaining hard block is the entire quadratic normal block.

This establishes the algebraic route to a bounded local Gram. The cap choice, complete angular Schur sum, and uniform local positivity are proved separately in `local_ui_certificate.tex`, using the pole-free source products and strict angular determinant. The reciprocal contact lemma alone should not be substituted for that full local argument.

## Remaining gates

1. Completed locally in `local_ui_certificate.tex`: the complete residue Gram, positive angular Schur sum, and large-weight cap argument cover every allowed source scale, including n=0.
2. Join the local u≈a, v infinitesimal construction to all independent angles and states. In particular, the strong m,C,D,alpha selection has a state kernel along v=0 with Y=uW,X=Z=0, and another along u=infinity with W=X=0,Z=vY. Neither axis can be dismissed by a generic strict state-residue argument.
3. Include literal endpoints, n=0, arbitrary source openings, complex states, and the reflected HU source orbit; obtain a scoped review before adding an admission.

The exact checker supplied here establishes the reciprocal completion and the parallel C/D identity. Its PASS result is not a certificate for these remaining gates.
