Q222 REVISION 18 - THE RETAINED-SQUARE MILESTONE

Read Q222_R18_Retained_Square_Milestone.pdf first.
Then read Q222_End_to_End_Checklist_R18.txt and FRONTIER_R18.json.

New whole closures: C14.3a and C14.3b. Original operational item C14.3 is complete.
Whole weak-C2 admissions inherited: R5, R8, R9, R10.
The global finite affine SDP-lift theorem remains OPEN.

The complete preceding checkpoint is preserved under inherited_r17/.
Historical status sentences there refer to their original revision.
The R18 frontier and checklist govern current status; no old proof's
mathematical scope has been enlarged without a new stated argument.

The key analytical step is CJ4-CJ8: use the already-retained completed
J square as an exact conductor for the formerly uncontrolled normal.
It works without comparing source and testing rates.

Verification: python verify.py checks file hashes and current scope.
Optional: install requirements.txt and run python verify.py --identities.
The optional command checks new identities only, not historical tests.
Same-system separate-agent review is not external/formal verification.
No numerical table is used as a proof premise.
