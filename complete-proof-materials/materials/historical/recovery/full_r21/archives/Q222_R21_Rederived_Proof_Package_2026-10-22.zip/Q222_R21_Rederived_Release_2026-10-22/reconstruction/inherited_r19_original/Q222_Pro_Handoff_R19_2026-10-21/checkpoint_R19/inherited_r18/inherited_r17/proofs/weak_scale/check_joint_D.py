"""Focused new R8 joint-D normalization and paired-D stress checks.

No historical suite is run.  The R15/R16 coupled parent identity is an
inherited input; the entire D channel and new residue are reconstructed.
"""
import json
from pathlib import Path
import sympy as s

checks = {}
def ck(name, expression):
    assert s.cancel(expression) == 0, (name, s.factor(expression))
    checks[name] = True
    print("PASS", name, flush=True)

u,v,E,Ny,xi,Z,RD,Fv,J,Q,R,MD=s.symbols('u v E Ny xi Z RD Fv J Q R MD')
a,r,bh,n,m,C,Ah,D,al,t,x,lam,mu,cf,sigma,dinv,dj=s.symbols(
    'a r bh n m C Ah D alpha t x lambda mu cF sigma dinv dj')
h=bh**2;l=1-h;U=u*u;V=v*v;Du=1+U;Dv=1+V
W=(v*Z+E)/(t*u);Y=h*(v*Z+E)/t+bh*Ny;X=xi-r*u*Z
Rm=v*W-X+u*v*Y-u*Z
Devent=u*W+u*v*X-Y-v*Z
F=n*Du*Dv*X**2+m*Rm**2+C*Dv*(u*W-Y)**2+(Ah/h)*Du*Dv*Y**2+(D+s.Rational(1,2))*Devent**2+(al+s.Rational(1,2))*Du*(v*Y-Z)**2+Dv*(X+u*Z)**2/2-Du*Dv*Z**2/2
q=n*r*r+(m+s.Rational(1,2))*(1-r)**2+al
hard_source=s.Poly(s.cancel(F-q*(a*v*W-u*Z-a*xi)**2-n*(r*(a*V/t-U)*Z+u*xi)**2-(m-a*a*q)*(v*E/(t*u)-xi)**2), E,Ny,xi)
H0=sum(hard_source.coeff_monomial(z*z2)*z*z2 for i,z in enumerate((E,Ny,xi)) for z2 in (E,Ny,xi)[i:])

b2=2*m*h+C*l*l+Ah*h+(al+s.Rational(1,2))*h*h
b4=h*h*(m+al+s.Rational(1,2))+Ah*h
e1=m*h*(1-r)+r*(D+s.Rational(1,2))*l+(al+s.Rational(1,2))*h
d4=(n+D+s.Rational(1,2))*r*r
aE=2*Ah*h/t**2-2*e1/t;bE=2*b2/t**2;cE=2*b4/t**2
aY=2*(Ah/t-m*(1-r)+r*(D+s.Rational(1,2))-al-s.Rational(1,2))
bY=2*(-C*l+Ah+m+(al+s.Rational(1,2))*h)/t
cY=2*(Ah+h*(m+al+s.Rational(1,2)))/t
x3=2*((D+s.Rational(1,2))*(l/t-1)+(1-r)/2-n*r*(1+a/t)-m*h/t)
x5=-2*r*(n+D+s.Rational(1,2))
P=Q**2+R**2+lam*J**2+d4*RD**2+(cf+b4*x/t**2)*Fv**2+(b4/t**2)*v*RD*Fv+H0-lam*x*E**2-mu*xi**2-2*sigma*Q*xi+E*((aE+cE*V)*RD+(bE+cE*x)*v*Fv)+bh*Ny*((aY+cY*V)*RD+(bY+cY*x)*v*Fv)+xi*(x5*u*v*RD+u*(x3+x5*x)*Fv)
j=1+x*r-l/t
LD=l*E/t-r*RD-bh*Ny+u*v*xi
ck('original_event_contact_center', Devent-(LD-j*v*Z).subs(RD,v*(U-x)*Z))
ck('entire_D_channel',s.diff(P,D)-LD**2+2*j*u*Fv*xi)
P0=s.cancel(P.subs(D,0))
ck('exact_joint_D_remainder',P-(D*LD**2+P0-2*D*j*u*Fv*xi))
assert not s.denom(P0).has(u,v,D)
checks['joint_remainder_no_D_or_test_angle_pole']=True

newP=MD**2+(P0-2*dj*u*Fv*xi).subs(E,t/l*(dinv*MD+r*RD+bh*Ny-u*v*xi))
corner={u:0,v:0,bh:0,dinv:0,t:1,x:0,al:0}
unit_r_expected=MD**2+r*r*(C+n)*RD**2+Ah*Ny**2+(n+s.Rational(1,2)-mu)*xi**2+cf*Fv**2+lam*J**2+R**2+Q**2-2*sigma*Q*xi
ck('joint_D_full_Gram_residue',s.cancel(newP).subs(corner)-unit_r_expected)
ck('small_e_joint_D_residue',unit_r_expected.subs({r:1,n:0,C:s.Rational(1,2),Ah:s.Rational(1,2),lam:s.Rational(1,2)})-(MD**2+(RD**2+Ny**2+J**2)/2+(s.Rational(1,2)-mu)*xi**2+cf*Fv**2+R**2+Q**2-2*sigma*Q*xi))

# The pure-source bounded-a Schur margin, using OP2 and q >= alpha+e^2/2.
A0=s.symbols('A0',nonnegative=True)
ck('bounded_a_Schur_margin',s.Rational(1,2)-A0**2/(2*(1+A0)*(2+A0))-(2+3*A0)/(2*(1+A0)*(2+A0)))

# Entire paired-D replacement, including both inherited normals.
MB,qB,beta,h1,delta=s.symbols('MB qB beta h1 delta')
ck('paired_D_packet_replacement',delta*((MB-beta*qB)**2-(1-beta)*MB**2)-delta*beta*(MB**2-2*MB*qB+beta*qB**2))
Theta,Sc,PD,PK,K,h0,t0,j0,ca=s.symbols('Theta Sc PD PK K h0 t0 j0 ca')
delta_pair=Theta/(K*(h0+t0))*(Sc*PD/(t0*j0)-PK)
etaD=Theta*(Sc*PD/t0-j0*PK)/(K*(h0+t0)*ca)
ck('opening_free_paired_D_coefficient',delta_pair*j0/ca-etaD)
N,wt,p=s.symbols('N wt p')
qb=v*(Du-u*N-p*u*Du*v*wt)
stress=s.Poly(s.expand(MB**2-2*MB*qb+beta*qb**2),N,MB)
assert stress.total_degree()==2
checks['paired_D_stress_full_normal_degree_two']=True
scalar=stress.coeff_monomial(1)
normalN=stress.coeff_monomial(N);normalM=stress.coeff_monomial(MB)
assert s.cancel(scalar/v**2).is_polynomial(u,v,wt,p,beta)
assert s.cancel(normalN/v).is_polynomial(u,v,wt,p,beta)
assert s.cancel(normalM/v).is_polynomial(u,v,wt,p,beta)
checks['paired_D_scalar_and_both_normal_support']=True
for co in stress.coeffs():
    assert s.diff(co,wt).subs(p,0)==0
checks['paired_D_all_testing_w_dependence_has_p']=True

# Bounded-a source face: no j denominator enters lambda or cF.
Bs,aa,rr,hs,ts=s.symbols('Bs aa rr hs ts');ee=1-rr
cas=1+aa*Bs*rr;scs=1+Bs*(1-hs+aa*rr);gs=1-aa*ee+hs*aa*Bs
des=aa+(1+aa*Bs)+(1+aa*Bs)*Bs+2*aa*Bs*(1+aa*Bs)*rr+aa**3*Bs**2*rr**2+2*aa**2*Bs*rr+ts*Bs*(1+aa+aa*Bs+aa**2*Bs*rr*(2-rr))
ms=(1+aa*Bs)*(1+aa*rr)*(hs+ts)-aa*(1+ts*Bs)*ee*(1-hs)
ns=((1+aa*rr)*cas*scs-rr*des)/(2*rr*des)
mm=aa**2*(1+ts*Bs)*ee*cas*scs/(2*gs*des)
cs=cas*ms/(2*(1-hs)*des)
ahs=ts*cas*(1+aa*rr)*scs/(2*des)
als=Bs**2*(1+aa*rr)*ms/(2*(1-hs*Bs)*des)
qs=ns*rr**2+(mm+s.Rational(1,2))*ee**2+als
lams=s.cancel((mm-aa**2*qs)/(ts*aa**2*Bs))
cfs=s.cancel((2*mm*hs+cs*(1-hs)**2+ahs*hs+(als+s.Rational(1,2))*hs**2-aa**2*ns*rr**2)/ts**2)
ck('bounded_a_lambda_source_residue',lams.subs({Bs:0,hs:0,ts:1})-rr*(1+aa*rr)/(2*(1+aa)))
ck('bounded_a_cF_source_residue',cfs.subs({Bs:0,hs:0,ts:1})-(1+aa*rr)*(1-aa*(1-rr))/(2*(1+aa)))
assert not s.denom(lams).subs({Bs:0,hs:0,ts:1,aa:0})==0
checks['lambda_regular_at_a_zero']=True

# New full remote determinant after exact D/A normalization, u a unit.
ar,rr,Ut,Vt=s.symbols('ar rr Ut Vt');ee=1-rr;gg=1-ar*ee
nn=ee/(2*rr*(1+ar));mm=ar**2*ee/(2*gg*(1+ar))
cc=(1+ar*(2*rr-1))/(2*(1+ar));Dt=(1+Ut)*(1+Vt)
XX=nn*Dt+mm*(1+Vt)**2+cc*(1+Vt)*Ut*Vt+(1+Vt)/2
XZ_times_u=-mm*(1+Vt)*(Vt-Ut)-cc*(1+Vt)*Ut*Vt+Ut*(1+Vt)/2
ZZ=mm*(Vt-Ut)**2/Ut+cc*(1+Vt)*Vt+(Ut-Vt)/2
bracket=ee*(Ut-ar*Vt)**2+rr*(1+2*ar*rr-ar)*Ut**2*Vt+gg*(1+2*ar*rr-ar)*Ut*Vt**2
target=Dt*(1+ar*rr)*bracket/(4*rr*(1+ar)**2*gg)
ck('remote_full_two_state_determinant',Ut*XX*ZZ-XZ_times_u**2-target)
ck('remote_small_r_normalized_determinant',s.cancel(target/nn).subs(rr,0)-Dt*((Ut-ar*Vt)**2+(1-ar)**2*Ut*Vt**2)/(2*(1+ar)*(1-ar)))

# Source critical-wall denominator at the new t0=1 boundary.
ss,ww,zz,hh,tt=s.symbols('ss ww zz hh tt');bb=ww*zz;xx=ss*bb;BB=ss**2*bb;r0=1-ss*ww
ca0=1+xx*r0;sc0=1+BB*(1-hh)+ss*bb*r0
g0=1-ww+hh*xx;JJ=tt*ca0-(1-hh)
dp=s.expand(1+ss+ss**2*bb+ss**3*bb+ss**4*bb**2+2*ss**2*bb*r0+2*ss**3*bb**2*r0+ss**2*bb**2*r0**2+2*ss*bb*r0+tt*ss**3*bb+tt*ss**2*bb+tt*ss**4*bb**2+tt*ss**3*bb**2*r0*(2-r0))
ms0=(1+xx)*(ss+r0)*(hh+tt)-ss*ww*(1+tt*BB)*(1-hh)
NC=ca0*ms0;DC=2*(1-hh)*dp
NA=tt*ca0*(ss+r0)*sc0;DA=2*dp
ND=(1+xx)*(ss+r0)*(1-tt*xx*r0)*sc0;DD=2*JJ*dp
Nm1=(1+tt*BB)*ca0*sc0
Pwall=(hh*DA+2*NA)*(DD+2*ND)*DC-2*NC*(4*NA*ND-hh*DA*DD)
Qwall=2*(4*NA*ND-hh*DA*DD)*DC
ck('critical_wall_s_divisibility_at_new_opening',Pwall.subs(ss,0))
ck('critical_wall_w_divisibility_at_new_opening',Pwall.subs(ww,0))
ck('critical_wall_denominator_at_t_one',(Qwall*Nm1).subs({ss:0,hh:0,tt:1})-16)

payload={'status':'PASS','count':len(checks),'checks':checks,
 'scope':'New exact joint-D channel, full normalized Gram residue, bounded-a source and Schur arithmetic, paired-D thin stress/support, complete remote determinant, and critical-wall denominator at t0=1. Source inequalities, conductor application, and all-tests routing are proved in joint_D_R8_closure.tex.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
