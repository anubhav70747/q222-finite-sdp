#!/usr/bin/env python3
"""Build both revision-13 TeX entrypoints from preserved source; no old math edited."""
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
old=(ROOT/"provenance/revision12_root/Q222_Analytical_Revision_2026-10-18.tex").read_text()
preamble=old.split(r"\begin{document}",1)[0]
preamble=preamble.replace("revision 12","revision 13")
preamble=preamble.replace("A moving zero becomes a finite circuit","Centered packets resolve moving source boundaries")
preamble=preamble.replace("Q222: exact reductions and the remaining proof obligations","Q222: new analytical certificates and the exact frontier")
quant=old[old.index(r"\section{Quantifiers, normalization and the original parent}"):old.index(r"\input{advances/weak_small_gap_scale/")]
history=old[old.index(r"\section{The short idea}"):old.index(r"\input{reconciliation/checklist.tex}")]
history=history.replace(r"\section{The short idea}",r"\section{Preserved mechanisms from revisions 7--12}"+"\n"+r"\noindent These paragraphs record earlier progress chronologically. Their statements about what remained open are historical; Section~\ref{sec:r13-frontier} governs the present frontier."+"\n",1)
rest=old[old.index(r"\input{advances/weak_small_gap_scale/"):old.rindex(r"\end{document}")]
abstract=r"""\begin{abstract}
Revision 13 proves five new all-tests source theorems for the original
four-state Q222 parent. A centered angular packet closes the weak-C2
small-$(1-r)$, $z/B$-unit chart left open in revision 12, including
$n=0$ and arbitrary allowed source-scale rates. A joint radial and
first-normal allocation closes the large-$L$, large-$\eta$ C1 chart
with bounded $\beta(1-h)\eta^2$, including beta zero.
Three weighted small-$L$ C1 theorems together cover the entire
unit-$\eta,\zeta$ source region, including both $r$ openings,
the actual-$j$ opening and their simultaneous degeneration.
Every theorem restores all state normals, hard couplings and
independent projective testing charts. Additional source and remote
reductions narrow the remaining frontier.
The proofs are finite algebraic identities and strict bounded-residue
Gram arguments; focused exact computations corroborate them.
The full finite-SDP-lift existence theorem is still unfinished on
the explicitly printed residual source/test domains.
No evaluated global affine pencil is supplied.
\end{abstract}
"""
new_inputs=[
"revision13/bridge_status.tex",
"advances/revision13_weak_local/centered_circuit_closure.tex",
"revision13/c1_notation.tex",
"advances/revision13_c1_small_l/r_opening_closure.tex",
"advances/revision13_c1_small_l/j_opening_closure.tex",
"advances/revision13_c1_small_l/simultaneous_r_j_closure.tex",
"advances/revision13_c1_eta/joint_radial_beta_zero.tex",
"advances/revision13_c1_eta/beta_positive_extension.tex",
"advances/revision13_c1_eta/followup_conductor/bounded_u_conductor.tex",
"advances/revision13_c1_small_l/eta_large_bounds.tex",
"advances/revision13_source_overlap/source_overlap.tex",
"advances/revision13_weak_local/frontier_audit.tex"]
main=preamble+r"\begin{document}\maketitle"+"\n"+abstract+r"\input{reconciliation/checklist.tex}"+"\n"+quant
main+="\n".join(r"\input{"+x+"}" for x in new_inputs)
main+="\n"+r"\clearpage"+"\n"+history+"\n"+rest+r"\end{document}"+"\n"
(ROOT/"Q222_Analytical_Revision_2026-10-18.tex").write_text(main)
report_pre=preamble.replace("Centered packets resolve moving source boundaries","Q222: five new source theorems").replace("Q222: new analytical certificates and the exact frontier","The small-gap proof and the remaining frontier")
report=r"""\begin{document}\maketitle
\begin{abstract}
This report gives the revision-13 frontier, the full new centered-packet
weak-C2 local proof, its finite contact-lift mechanism and exact remote
join, together with the quantitative C1 advances. The companion full
manuscript contains all C1 derivations and all recovered historical
source modules. The original C1.4 and weak-C2 rows remain open:
these new results do not establish the global finite-lift theorem.
\end{abstract}
\input{reconciliation/checklist.tex}
"""
report+=quant
report_inputs=[
"revision13/bridge_status.tex",
"revision13/c1_notation.tex",
"revision13/c1_results_digest.tex",
"revision13/weak_notation.tex",
"baseline/baseline/baseline/baseline/baseline/baseline/baseline/current/bridge/strict_gram.tex",
"advances/three_circuit/three_circuit_lift.tex",
"advances/weak_small_gap_scale/boundary_scale_lemma.tex",
"advances/revision13_weak_local/centered_circuit_closure.tex",
"advances/weak_small_gap_remote/remote_reduction.tex",
"advances/revision13_weak_local/frontier_audit.tex"]
report+="\n".join(r"\input{"+x+"}" for x in report_inputs)
report+=r"""
\clearpage
\section{Inherited identities used in the remote join}
The following original modules are reproduced for the exact full-parent
identities used by GR. Their source-domain admissions retain their
original hypotheses. GR and WF reuse the algebra only after checking
the coefficient hypotheses on the new chart. In particular this is
not an import of the old local WA certificate at small $1-r$.
\input{advances/weak_A/five_root_remote.tex}
\input{advances/weak_A_boundary/extension.tex}
\clearpage
\section{Reproducibility and dependency map}
\begin{center}
\small
\begin{tabular}{p{.20\linewidth}p{.64\linewidth}}
\toprule
Result & Required proof ingredients\\
\midrule
WC all tests & BS exact source bound; WC scalar and every normal;
finite three-circuit lift; GR remote and projective joins.\\[3pt]
JR/JB all tests & BE source sphere and actual contact jets;
joint six-root identity; exact beta square; CE remote joins.\\[3pt]
RO all tests & Native coefficient formulas; opening-cleared strong
weights; IC scalar/normal identities; finite circuit; SB remote join.\\[3pt]
JO all tests & Native actual-$j$ formulas; full $D$-event normal;
finite polynomial contact lift; exact reciprocal remainder; SB join.\\[3pt]
HO all tests & Harmonic whole-$A,D$ frame; opening-cleared source
bounds; complete scalar and normals; both reciprocal soft directions;
SB remote join.\\[3pt]
Global existence & All remaining source/test leaves; exact U1
exhaustion; only then Scheiderer's Corollary 3.19.\\
\bottomrule
\end{tabular}
\end{center}
Run \texttt{python3 verify.py --integrity-only} for the complete
derivative manifest and source dependencies, and
\texttt{python3 verify.py --revision13-only} for the new exact checks.
The verifier copies each focused script into a temporary directory;
stored receipts are not rewritten. Python 3 and SymPy are required.
\texttt{--revision12-only} replays only the 20 checks from that revision.
No reconstructed command pretends to replay the unavailable original
full 39-script registry.

The full source archive includes all recovered mathematical modules,
the original ten checklist tasks and criteria, original revision-12
root files, a recovery report, both TeX entrypoints and PDFs,
the new exact scripts and receipts, and a fresh SHA-256 manifest.
Same-system review and symbolic checks are distinguished from
external refereeing and formal verification.
\end{document}
"""
(ROOT/"Q222_Revision13_Results.tex").write_text(report_pre+report)
print("Both TeX entrypoints regenerated from preserved revision-12 source.")
