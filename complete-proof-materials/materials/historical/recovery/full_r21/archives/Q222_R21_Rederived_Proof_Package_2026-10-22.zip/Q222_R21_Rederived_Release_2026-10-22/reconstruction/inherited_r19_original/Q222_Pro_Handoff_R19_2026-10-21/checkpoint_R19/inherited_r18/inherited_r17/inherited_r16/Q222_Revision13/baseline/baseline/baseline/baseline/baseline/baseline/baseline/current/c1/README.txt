REGULAR ORDINARY-ANGLE C1 SOURCE: AN ANALYTICAL ALL-TESTS CERTIFICATE

Read ordinary_angle.tex. Run:

    python check_ordinary_angle.py

The checker is self-contained and uses only Python's standard library.
It rejects optimized Python because assertions perform exact proof checks.
The report ordinary_angle_checks.json records the actual executed status,
identity list, and timing. The first run passed 38 checks in about 0.03 s.

Exact advance
-------------
For the original native C1 source, k, s=g/f, a, t, M, J are positive
bounded units, eta=f^2 is positive infinitesimal, and zeta=g^2=s^2 eta.
The theorem proves tensor SOS at ALL independent projective tests and
all real/complex states. It includes the previously exhibited obstruction
to small-k source entry: k=s=1, a=t=1/2, eta infinitesimal.

Four event weights m,c,D,beta are units, the signed coefficient d has
scale eta, and A,alpha have scale eta^2. Two elementary square completions
produce a scalar S. Its angular capacity factorization singles out only
the actual Alice contact. A short state-root relation closes unmatched
states there. The remaining exact contact uses five weighted roots and
finite monic Taylor division; its Hessian has positive principal minors
K, 4k^4, 12s^2 k^6/K. No source/test rate comparison occurs.

Proof and checker boundary
--------------------------
The proof uses the existing strict bounded residue Gram lemma and the
native C1 source formulas/contact balances (printed in the source appendix
of the base package). It explicitly retains the complete original parent.
The checker independently reconstructs all six native polynomial balances,
all seven coquotient residues, the four-square completion, capacity and
state identities, Hessian and minors, and finite/reciprocal-chart monomial
Gram allocations. It does not import an expanded polynomial archive or
an external result file. It performs no Groebner calculation and no
floating-point positivity experiment. The finite weighted Taylor argument
and projective exhaustion are given in prose, rather than delegated to
a machine PASS label.

Remaining scope
---------------
This is not an exhaustive C1 source cover or a whole-global Q222 proof.
It does not cover nonunit state ratio s, nonunit a,t,M,J, non-small eta
or zeta, or the remaining small-k unit/unbounded-eta rows. Original-source
entry for a physical canonical contact uses the already stated native
transport and selected nonzero contact minor, on exactly its inherited
domain. No claim about source faces outside that domain is added.
