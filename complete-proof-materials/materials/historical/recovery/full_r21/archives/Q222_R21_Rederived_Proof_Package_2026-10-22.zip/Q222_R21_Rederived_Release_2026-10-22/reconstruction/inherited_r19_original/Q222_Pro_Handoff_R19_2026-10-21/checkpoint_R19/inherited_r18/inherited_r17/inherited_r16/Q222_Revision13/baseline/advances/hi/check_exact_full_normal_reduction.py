"""Narrow exact checker for H6.1--H6.9, not an HI coverage proof."""
import json
from pathlib import Path
import sympy as s
p,v,q,y,R,E,t=s.symbols('p v q y R E t')
x,Y,U,V=s.symbols('x Y U V')
H=1-q*E; B=H+y*t; K=B+R-E; j=1+R-t; S=1+R+y*t
Delta=(1+q)*(B**2+2*B*R+(1+y)*B)+(1-y*q)*R**2+2*(1+y)*R+1+y
N=(1+q)*(B+R)*(H+y)-(1+y)*(1-q*R)*y*t
a=(1+R)*(B+R)*S/(2*H*Delta)
mu=(1+y)*(1-q*R)*(1+R)*S/(2*Delta)
cc=(1+R)*N/(2*Delta)
dd=(1+q)*(B+R)*(B-y*R)*S/(2*Delta)
aa=(B+R)*N/(2*Delta)
nn=((B+R)*(1+R)*S-R*Delta)/(2*R*Delta)
m,C,D,al,A,n,ac=s.symbols('m C D al A n ac')
source={m:mu/(q*K),C:cc/(y*t),D:dd/(y*j),al:aa/(q*E),A:q*y*a,n:nn,ac:a}
Dp=1+p*p; Dv=1+v*v; dc=(1+q)*(1+y)
W=B/H*p*Y+U; Z=v*Y/H+V; X=x-R/H*p*v*Y
J=W+v*X-p*Y-p*v*Z; M=p*v*W-p*X+v*Y-Z
LC=U; LD=J+y*j/H*p*Y; LM=M-q*K/H*v*Y; LA=V
F=4*n*Dp*Dv*X**2+4*m*M**2+4*C*Dv*(W-p*Y)**2+4*A*Dp*Dv*Y**2+(4*D+2)*J**2+(4*al+2)*Dp*(v*Y-Z)**2+2*Dv*(p*X+Z)**2-2*Dp*Dv*Z**2
hard=4*m*LM**2+4*C*Dv*U**2+4*D*LD**2+4*al*Dp*V**2
dp=p*p-q; dv=v*v-y; dt=p*p*v*v-q*y; d=Dp*Dv-dc; eta=H-R*(q+y+q*y)
soft=(4*n*Dp*Dv+2*(p*p+v*v+p*p*v*v))*x*x-8*ac*p*v*d*x*Y+4*ac/H*(R*dt*d+eta*dp*dv)*Y*Y
remainder=2*U*U-4*p*v*U*V+2*V*V+4*U*(v*x-2*ac*(1+q)*p*dv*Y)+4*V*(p*x-2*ac*(1+y)*v*dp*Y)+soft
checks={}
checks['H6_1_D_normal']=s.factor(LD-(U-p*v*V+v*x-(1+R)/H*p*dv*Y))==0
checks['H6_1_m_normal']=s.factor(LM-(p*v*U-V-p*x+(B+R)/H*v*dp*Y))==0
coeffs=s.Poly(s.expand(F-hard-remainder),U,V,x,Y)
for exps,coeff in coeffs.terms():
    checks['H6_2_parent_coefficient_'+'_'.join(map(str,exps))]=s.factor(coeff.subs(source))==0
ld=2*ac*H*(1+q)/(1+R); lm=2*ac*H*(1+y)/(B+R)
checks['H6_3_D_allocation']=s.factor(v*x-2*ac*(1+q)*p*dv*Y-ld*(LD-U+p*v*V)-(1-ld)*v*x)==0
checks['H6_3_m_allocation']=s.factor(p*x-2*ac*(1+y)*v*dp*Y+lm*(LM-p*v*U+V)-(1-lm)*p*x)==0
allocated=(2-4*ld)*U*U+(2-4*lm)*V*V+4*(ld+lm-1)*p*v*U*V+4*ld*U*LD-4*lm*V*LM+4*(1-ld)*v*U*x+4*(1-lm)*p*V*x+soft
checks['H6_4_allocated_remainder']=s.factor(remainder-allocated)==0
checks['H6_5_source_a_n_relation']=s.factor(2*a*H-R*(2*nn+1))==0
rho=s.symbols('rho')
fs=2*n*R*(R+3)+R-1
fr=2*n*rho*(rho+3)+rho-1
checks['H6_6_difference_factor']=s.factor(fs-fr-(R-rho)*(2*n*(R+rho+3)+1))==0
checks['H6_6_source_error']=s.factor(fs.subs(n,nn)-(2*a*H*(R+3)-(R+1)**2))==0
ap,bv=s.symbols('ap bv')
geo=R*ap*ap*bv*bv+R*(2*y+1)*ap*ap*bv+R*y*(1+y)*ap*ap+R*(2*q+1)*ap*bv*bv+(H+R*q*y)*ap*bv+R*q*(1+q)*bv*bv
checks['soft_geometric_factorization']=s.factor(R*dt*d+eta*dp*dv-geo.subs({ap:dp,bv:dv}))==0
checks['lambda_D_source_form']=s.factor(ld.subs(ac,a)-(1+q)*(B+R)*S/Delta)==0
checks['lambda_m_source_form']=s.factor(lm.subs(ac,a)-(1+y)*(1+R)*S/Delta)==0
cstar,dstar,mstar,astar,j0,t0,E0,K0=s.symbols('cstar dstar mstar astar j0 t0 E0 K0')
C0=cstar/(y*t0); D0=dstar/(y*j0); M0=mstar/(q*K0); Al0=astar/(q*E0)
checks['H6_7_CD_harmonic']=s.factor(y*C0*D0/(C0+D0)-cstar*dstar/(cstar*j0+dstar*t0))==0
checks['H6_7_malpha_harmonic']=s.factor(q*M0*Al0/(M0+Al0)-mstar*astar/(mstar*E0+astar*K0))==0
w,xi,et,ze=s.symbols('w xi et ze')
parity={U:0,V:0,x:R/B*v*dp*w,Y:H*p/B*w}
Wg=p*p*w; Xg=-q*R*v/B*w; Yg=H*p/B*w; Zg=p*v/B*w
checks['H6_8_C_alpha_graph']=s.factor(Wg-B/H*p*Yg)==0 and s.factor(Zg-v*Yg/H)==0
checks['H6_8_x_graph']=s.factor(Xg+R/H*p*v*Yg-R/B*v*dp*w)==0
checks['H6_8_change_determinant']=s.Matrix([[p*p,0,0,0],[-q*R*v/B,1,0,0],[H*p/B,0,1,0],[p*v/B,0,0,1]]).det()==p*p
checks['H6_8_m_graph']=s.factor(LM.subs(parity)-p*v*dp*w)==0
checks['H6_8_D_graph']=s.factor(LD.subs(parity)-(R*y*dp-(p*p+q*R)*dv)/B*w)==0
# Here x, U, V are centered coordinates; for w=0 use the raw parent directly.
J0=v*xi-p*et-p*v*ze; M0=-p*xi+v*et-ze
F0=4*n*Dp*Dv*xi**2+4*m*M0**2+4*C*Dv*p*p*et*et+4*A*Dp*Dv*et*et+(4*D+2)*J0**2+(4*al+2)*Dp*(v*et-ze)**2+2*Dv*(p*xi+ze)**2-2*Dp*Dv*ze**2
Q0=(4*m+2)*(p*xi+ze-v*et)**2+(4*n*Dp*Dv+2*Dp*v*v)*xi*xi+(4*C*Dv*p*p+4*A*Dp*Dv+2*p*p*Dv)*et*et+4*D*J0**2+4*al*Dp*(v*et-ze)**2
checks['H6_9_entire_three_normal_SOS']=s.expand(F0-Q0)==0
out={'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'scope':'Exact original-parent normal reduction and source identities H6.1--H6.9 only. No bounded soft Gram, new HI admission, or global closure is asserted.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
assert all(checks.values())
