"""New exact checks for JU1--JU11 only; no baseline replay.

The previously verified JR5/JB1 full-parent identity and original contact
jets are imported facts. This checker verifies its complete root change,
the bounded normalization, and the circuit model, but proves no new SOS
admission or full-parent circuit lift.
"""
import json
import time
from pathlib import Path
import sympy as s

start = time.monotonic()
checks = []

def ck(name, expression):
    numerator = s.fraction(s.cancel(expression))[0]
    passed = s.expand(numerator) == 0
    checks.append({"name": name, "pass": bool(passed)})
    print(("PASS " if passed else "FAIL ") + name, flush=True)
    if not passed:
        raise AssertionError((name, s.factor(numerator)))

x,z,sg,h,b,t,xi = s.symbols("x z sigma h b t xi")
u,w,q,W,X,Y,Z = s.symbols("u w q W X Y Z")
Nx,Ny,Gam,R,At,V,Omega = s.symbols("Nx Ny Gamma R Atheta V Omega")
m,C,D,bt,p,l,mu,ac,lc = s.symbols("m C D btheta p l mu astar lstar")
Q=1-b; th=1-h; abeta=bt*th; g=h-Q; Du=1+t; Dw=1+xi; de=t-x

Ax=-4*h*(2*D+1)/sg
A=4*mu+2*h*h*(2*D+1)*t/sg
Bx=8*mu*x
Ay=8*(p-l)+4*z*((1+2*m)*g+2*D*h+2*p*sg)
S=2*(h*h*(2*D+1)*(t+x)+4*D*h-2*b*p*sg*sg*z+2*abeta+h*h)/sg**2
Z0=(4*D+2*t*(4*D*h+2*abeta+h*h)+2*t*t*h*h*(2*D+1))/sg**2
Zx=-4*u*(2*D-2*bt+h+t*h*(2*D+1))/sg

Az=4*((h*h/sg)*(2*D+1)*(t+x)+2*D*h/sg*(2-sg)
       +2*(p*b+l*Q)+h*h/sg-h
       +z*(4*D*b*h+2*p*b*sg+(1+2*m)*g*g))
Az+=8*abeta*(1+sg*z)/sg
sigB=2*h*h*(2*D+1)*(t+x)/sg+8*D*h*(1-sg)/sg+8*(p*b+l*Q)
sigB+=2*h*h/sg-4*h+4*abeta/sg
sigB+=4*z*(4*D*b*h+3*p*b*sg+(1+2*m)*g*g+2*abeta)

k0=2*b*((2*C+1)*b+4*D+4*p*sg+2*(2*C+2*D+1)*sg*(b*z-1))
k1=2*(1+2*m)*g*g+8*D*h*b+8*p*b*sg+4*abeta
k2=2*b*b*(2*C+2*D+1)
Kr=k0+k1*t+k2*xi
Rx=-4*(2*D*b+(1+2*m)*g-2*bt)
Ry=4*(t*(2*D*h+2*p*sg+(1+2*m)*g)+b*(2*C+2*D+1)*(xi+sg*z)
      +(2*C+1)*(b-sg)+2*D*(1-sg)+2*p*sg)
Er=2*(C+D)*(b*z-1)+2*p+b*z-1
Rg=-4*(Er+2*p*t)
cG=4*Du*(p*b*Dw+l*Q)
cN=8*Du*(p*Dw-l)
Hx=2*(1+t+xi)+4*D*t+4*m*xi
Hy=4*Du*(ac*Dw+lc)+4*m*t*z+4*C*z*Dw+(4*D+2)*xi*z+2*Du*z

common=Hx*Nx**2+Hy*Ny**2+(cG+z*Kr)*R**2+A*At**2
common+=-4*u*q*w*(2*m+2*D+1)*Nx*Ny+q*w*Rg*Ny*Gam+q*w*b*Rg*R*Gam
common+=u*q*w*Rx*Nx*R+(cN+z*Ry)*Ny*R+q*w*Bx*Nx*At+u*Ay*Ny*At
common+=u*sigB*At*R
G=common+Z0*Gam**2+Zx*Nx*Gam+u*Ax*Nx*V+S*Gam*V

zt=(4*D+2*x*(4*D*h+2*abeta+h*h)+2*x*x*h*h*(2*D+1))/sg**2
zt+=4*b*p*z*de
zxt=-4*u*(2*D-2*bt+h+x*h*(2*D+1))/sg
st=sg*S
axt=-4*u*h*(2*D+1)
GOm=common+zt*Gam**2+zxt*Nx*Gam+axt*Nx*Omega+st*Gam*Omega

roots={Gam:sg*Z-u*w*W,R:w*Z/q-u*q*W,
       At:q*(u*u-x)*W,V:u*w*(u*u-x)*W,Omega:(u*u-x)*Z}
ts={t:u*u,xi:w*w,z:q*q}
ck("JU1 exact linear V-to-Omega root change through zero tests",
   (V-sg*Omega+de*Gam).subs(ts).subs(roots))
ck("JU1 exact beta-contact root conductor through zero tests",
   (t*Gam+V-x*Gam-sg*Omega).subs(ts).subs(roots))
ck("JU1 exact quadratic Omega conductor through zero tests",
   (sg*Omega**2-t*At**2-u*de*At*R-de*Omega*Gam).subs(ts).subs(roots))
ck("JU2 exact Gamma diagonal pole cancellation",zt-Z0+de*S)
ck("JU2 exact X-Gamma first-normal cancellation",zxt-Zx+u*Ax*de)
ck("JU2 exact X-Omega first-normal coefficient",axt-u*sg*Ax)
ck("JU4 explicit bounded complete radial-angular coefficient",sigB-Az+sg*S)
ck("JU3 ENTIRE generic JR/JB form after root change, both normals kept",
   G.subs(V,sg*Omega-de*Gam)-GOm)
ck("JU5 bounded two-source-product allocation of the beta pole",
   (4*abeta/sg**2*Gam*(t*Gam+V)).subs(V,sg*Omega-de*Gam)
       -4*x*abeta/sg**2*Gam**2-4*abeta/sg*Gam*Omega)

# Normalize only the four pure-source products proved bounded in BE/JB.
H,dd,tau0,cv,cC = s.symbols("H d_source tau_source c_source cC")
zt_norm=(4*dd+4*th*cv+8*x*D*h/sg**2+2*x*h*h/sg**2
         +2*x*x*h*h*(2*D+1)/sg**2+4*b*p*z*de)
ck("JU6 exact bounded-source-product normalization",
   zt_norm.subs({dd:D/sg**2,cv:x*bt/sg**2})-zt)
GN=GOm+(zt_norm-zt)*Gam**2
GN=s.cancel(GN.subs({h:sg*H,D:sg**2*dd,bt:sg*tau0,C:z*cC,m:mu*x*x*z}))
GN=s.expand(GN).subs({x:0,z:0,sg:0,t:0,xi:0,u:0,w:0,q:0,
                     p:s.Rational(1,2),l:s.Rational(1,2),
                     ac:s.Rational(1,4),lc:s.Rational(1,4),mu:H/2})
GN=GN.subs({cv:s.Rational(1,2)-dd,H:1+2*tau0})
expected=2*(Nx**2+Ny**2+R**2+Gam**2)+2*(1+2*tau0)*At**2+4*tau0*Gam*Omega
ck("JU6 every full-parent residue entry including both b,Q openings",GN-expected)
ck("JU6 free Gamma-Omega determinant (obstruction only)",
   s.det(s.Matrix([[2,2*tau0],[2*tau0,0]]))+4*tau0**2)

ks,MB,MBbar,eps,c,tau,PP,HH,b0sq,J = s.symbols(
    "kappa_s Mbeta Mbar epsilon c tau P Hsource b0sq J")
ck("JU7 exact shared-source sphere normalization",
   (x*MBbar-b0sq/2).subs({MBbar:PP*bt/(HH*sg**2),b0sq:2*PP*x*bt/(sg**2*HH)}))
ck("JU8 exact pole-free comparison model",
   ((1-2*x*MBbar)*Gam**2+2*MBbar*Gam*(t*Gam+V)
    -Gam**2-2*sg*MBbar*Omega*Gam).subs(V,sg*Omega-de*Gam))
errS=(2*h*h*(2*D+1)*(t+x)+8*D*h+2*h*h)/sg-4*b*p*sg*z-4*bt*h/sg
ck("JU9 exact stronger sigma-order Gamma-Omega correction",st-4*bt/sg-errS)

a,ss,E = s.symbols("a s E")
F=(1+2*tau)*(a-c)**2*ss+(1-2*c)*(tau-a*ss)**2
F+=2*a*(tau-a*ss)*(tau-c*ss)
circuit=2*c*(a*ss)**2+2*a*tau**2+2*c*c*tau*ss-6*c*tau*(a*ss)
decomp=(1-2*c)*(a*ss-tau)**2+ss*(a-c)**2+circuit
ck("JU10 exact three-term radial-kernel circuit",F-decomp)
ck("JU10 exact positive-monomial geometric-mean product",
   (2*c*(a*ss)**2)*(2*a*tau**2)*(2*c*c*tau*ss)-(2*c*tau*a*ss)**3)
r1,r2,r3=s.symbols("rho1 rho2 rho3")
rr=[r1,r2,r3]; gc=r1*r2*r3
cb=sum(v**6 for v in rr)-3*gc**2-sum((v**3-gc)**2 for v in rr)
cb-=sum(gc*rr[ell]*(rr[i]-rr[j])**2
        for i in range(3) for j in range(i+1,3) for ell in range(3))
ck("JU10b exact finite cubic-radical identity after separated factors",cb)
model=R**2+(1+2*tau)*At**2+Gam**2+2*tau*Omega*Gam
kernel=model.subs({R:0,At:eps*(a-c)*E,Gam:eps*(tau-a*ss),Omega:eps*(a-c)})
ck("JU10 exact restriction of the model on R=0",kernel.subs(E**2,ss)-eps**2*F)
expanded=model.subs({At:(t-x)*E,Gam:sg-t*E**2-u*E*R,Omega:t-x})
first=(1+t*E**2)*R**2-2*u*E*(sg-t*E**2+tau*(t-x))*R
kernel_physical=eps**2*F.subs({a:t/eps,ss:E**2,c:x/eps,tau:sg/eps})
ck("JU11 complete first radial normal of the circuit model",
   s.expand(expanded-first-kernel_physical.subs(eps,sg/tau)).subs(u**2,t))
zeroZ=model.subs(roots).subs(Z,0)
zeroZremainder=u*u*W*W*(q*q+(1+2*tau)*q*q*(u*u-2*x)+w*w)
ck("JU10c exact Z=0 model remainder vanishes on uW=0",
   zeroZ-(1+2*tau)*q*q*x*x*W*W-zeroZremainder)

end=GOm.subs({u:0,t:0,w:0,xi:0,Nx:0,Ny:0,R:0,At:0,Gam:sg*Z,Omega:-x*Z})
ck("exact additional D=0 boundary contact of the entire parent",end-4*D*Z**2)

output={
    "scope":"Exact bounded full-parent reduction on C14.1 with H bounded, Mbeta unbounded and u,w infinitesimal. No new SOS admission.",
    "imported_dependencies":["verified JR5/JB1 entire-parent identity", "six original source contact jets", "BE shared source sphere and bounded products"],
    "missing_lemma":"Finite bounded circuit/conductor allocation of JU11 and every JU3 correction, preserving the D=0 endpoint contact.",
    "checks":checks,"passed":len(checks),"seconds":round(time.monotonic()-start,3)
}
Path(__file__).with_suffix('.json').write_text(json.dumps(output,indent=2)+'\n')
print(f'{len(checks)} new exact assertions passed in {output["seconds"]} seconds',flush=True)
