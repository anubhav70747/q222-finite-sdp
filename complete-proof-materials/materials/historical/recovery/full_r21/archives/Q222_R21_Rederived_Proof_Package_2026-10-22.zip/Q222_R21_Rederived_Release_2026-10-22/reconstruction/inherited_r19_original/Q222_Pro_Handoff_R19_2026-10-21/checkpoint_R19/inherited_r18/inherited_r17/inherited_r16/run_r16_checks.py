"""Optional replay of R16 exact checks only; requires SymPy."""
from pathlib import Path
import subprocess,sys
root=Path(__file__).resolve().parent
checkers=['proofs/r10/check_r10_advance.py', 'proofs/r10/check_thin_stress.py', 'proofs/r10/check_thin_full_support.py', 'proofs/root/r10_unit_W_exact.py', 'proofs/joint_frame/check_joint_frame.py', 'proofs/small_eta/check_joint_reassembly.py', 'proofs/small_eta/check_z_unit_closure.py', 'proofs/small_eta/check_circuit_remainder_source.py']
for checker in checkers:
    subprocess.run([sys.executable,str(root/checker)],cwd=root,check=True)
print("R16 exact checks passed. This does not certify the global theorem.")
