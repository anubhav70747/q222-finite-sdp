"""Exact new identities only; imports no numerical or all-parent claim."""
import json
import pathlib
import sympy as s
u,E,R,c,tau,eps=s.symbols('u E R c tau eps', nonnegative=True)
x=c*eps; sig=tau*eps; t=u*u; Delta=t-x
K=sig-t*E*E; A=Delta*E; Gamma=K-u*E*R
model=R*R+(1+2*tau)*A*A+Gamma*Gamma+2*tau*Delta*Gamma
C=2*c*t*t*E**4+2*sig*tau*t+2*tau*x*x*E*E-6*tau*x*t*E*E
rhs=(1+u*u*E*E)*R*R-2*(u*E*K+tau*u*A)*R+(1-2*c)*K*K+A*A+C
checks={}
checks['complete_model_radial_identity']=s.expand(model-rhs)==0
# Parametrize positive radical factors so no symbolic sign simplification is hidden.
r,p,e=s.symbols('r p e', nonnegative=True)
sub={c:r*r/2,tau:p*p/2,eps:e*e}
xx=r*r*e*e/2; ss=p*p*e*e/2
A1=r*u*u*E*E; A2=p*p*e*u/s.sqrt(2); A3=p*xx*E; G=p*r*e*u*E/s.sqrt(2)
d1=A1-G; d2=A2-G; d3=A3-G
checks['circuit_product']=s.expand(A1*A2*A3-G**3)==0
checks['circuit_polynomial']=s.expand((A1*A1+A2*A2+A3*A3-3*G*G)-C.subs(sub))==0
normal_rhs=E*e/s.sqrt(2)*d2-u*E/r*d1+u*E/r*d3
checks['unit_c_radial_normal']=s.simplify(normal_rhs-u*E*(ss-u*u*E*E))==0
checks['unit_c_conductor']=s.expand(G*(u-r*e/s.sqrt(2))+u*d3)==0
checks['endpoint_model_zero']=s.simplify(model.subs({c:s.Rational(1,2),u:0,E:0,R:0}))==0
# Cubic-root identity, parameterized by the three nonnegative cube roots.
a,b,d=s.symbols('a b d',nonnegative=True)
g=a*b*d
cubic_rhs=sum((v**3-g)**2 for v in (a,b,d))+sum(g*l*(v-w)**2 for v,w in ((a,b),(a,d),(b,d)) for l in (a,b,d))
checks['finite_cubic_sos']=s.expand(cubic_rhs-(a**6+b**6+d**6-3*g*g))==0
assert all(checks.values()), checks
report={'status':'all new exact identities passed','assertions':len(checks),'checks':checks,
        'scope':'JU8 comparison model, C14.1a, normalized real testing state Z unit; not full parent; no source branch admitted',
        'unverified_by_script':'boundedness arguments and bounded-Gram theorem are mathematical proof/imports; full JU3 correction allocation remains open'}
pathlib.Path(__file__).with_suffix('.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
