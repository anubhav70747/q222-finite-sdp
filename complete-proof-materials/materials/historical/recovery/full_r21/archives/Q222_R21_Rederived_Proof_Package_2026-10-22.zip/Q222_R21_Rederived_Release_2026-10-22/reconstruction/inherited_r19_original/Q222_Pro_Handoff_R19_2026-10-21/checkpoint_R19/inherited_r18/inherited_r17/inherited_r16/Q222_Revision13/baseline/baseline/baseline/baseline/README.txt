Q222: Center the square, preserve the contact -- 18 October 2026, revision 3

Start with Q222_Analytical_Revision_2026-10-18.pdf. CHECKLIST.json and
PROOF_STATUS.json at this root are authoritative. The exact preceding
298-file delivered package is preserved under baseline/.

Five further all-tests results are proved on their stated domains. Together
the new C1 theorems close unit eta,e at every positive r; the new C2 results
and source reductions close all actual angle types IU, UH, UU. I means
positive infinitesimal, U positive bounded unit, H positive unbounded.

The global atlas-free proof remains UNFINISHED. The exhaustive conditional
frontier has five C1 scale leaves and eight C2 angle/event leaves. They are
not all claimed nonempty. The physical strong II family and the exact failed
bounded-Gram step are retained in advances/frontier/ as a frontier note,
not an additional certificate.

Correction: the prior infinity-infinity C1 frontier omitted 2d q^2. Its
critical equality was false; the corrected determinant is 4A(4m+2d)>0.
Historical copies remain unchanged; the new correction supersedes them.

Reproduction:
  python3 verify.py --integrity-only
  python3 verify.py
  python3 verify.py --with-sympy
The latter requires SymPy. Checks execute in a temporary copy and do not
modify packaged receipts. They corroborate exact algebra, not universal
source/test exhaustion. No numerical positivity sample or new atlas replay
is used. Separate-agent reviews are same-system reviews, not external peer
review or formal verification.

Build the root TeX manuscript twice with pdflatex (standard TeX Live,
including lmodern, mathrsfs, microtype, TikZ, hyperref, xurl). Typesetting-only
line breaks and bookmark text can differ from frozen analysis copies.
