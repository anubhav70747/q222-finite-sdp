#!/usr/bin/env python3
"""Check delivered hashes and replay only the new exact algebra checks."""
from pathlib import Path
import argparse, hashlib, json, os, shutil, subprocess, sys, tempfile, time

root=Path(__file__).resolve().parent
ap=argparse.ArgumentParser()
ap.add_argument('--integrity-only',action='store_true')
ap.add_argument('--with-sympy',action='store_true')
ap.add_argument('--revision12-only',action='store_true',help='Replay only the two revision-12 scripts')
ap.add_argument('--revision11-only',action='store_true',help='Replay only the four revision-11 scripts')
ap.add_argument('--revision10-only',action='store_true',help='Replay only the two revision-10 scripts')
ap.add_argument('--revision9-only',action='store_true',help='Replay only the revision-9 scripts')
ap.add_argument('--revision8-only',action='store_true',help='Replay only the four revision-8 scripts')
args=ap.parse_args()
manifest=root/'MANIFEST.json'
if manifest.exists():
    entries=json.loads(manifest.read_text())['files']
    for d in entries:
        p=root/d['path']
        if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=d['sha256']:
            raise SystemExit('Integrity failure: '+d['path'])
    print('Integrity PASS:',len(entries),'files')
elif not (args.with_sympy or args.revision8_only or args.revision9_only or args.revision10_only or args.revision11_only or args.revision12_only):
    raise SystemExit('No delivered manifest found.')
if not (args.with_sympy or args.revision8_only or args.revision9_only or args.revision10_only or args.revision11_only or args.revision12_only): raise SystemExit(0)

catalog=json.loads((root/'verification/CHECK_RUNS.json').read_text())
scripts=catalog['revision12_scripts' if args.revision12_only else ('revision11_scripts' if args.revision11_only else ('revision10_scripts' if args.revision10_only else ('revision9_scripts' if args.revision9_only else ('revision8_scripts' if args.revision8_only else 'scripts'))))]
results=[]
with tempfile.TemporaryDirectory(prefix='q222-check-') as tmp:
    work=Path(tmp)
    shutil.copytree(root/'advances',work/'advances')
    for rel in scripts:
        p=work/rel; started=time.monotonic()
        r=subprocess.run([sys.executable,str(p)],cwd=work,text=True,capture_output=True)
        if r.returncode:
            raise SystemExit('Exact check failed: '+rel+'\n'+r.stdout+'\n'+r.stderr)
        receipt=p.with_suffix('.json')
        d=json.loads(receipt.read_text())
        checks=d.get('checks',[])
        if isinstance(checks,dict):
            assert all(v is True for v in checks.values()),(rel,checks)
        elif isinstance(checks,list):
            assert all(x.get('passed',x.get('pass',True)) is True for x in checks),(rel,checks)
        if 'all_pass' in d:
            assert d['all_pass'] is True,(rel,d)
        count=len(checks)+int(d.get('base_checks',0))
        if rel.endswith('/derive.py'):
            assert d['parity_matrix_identity'] and d['common_state_pair_identities']
            count=3
        results.append({'script':rel,'status':'PASS','exact_assertions':count,
            'seconds':round(time.monotonic()-started,3),
            'sha256':hashlib.sha256((root/rel).read_bytes()).hexdigest()})
        print('PASS',rel,count)
record={'status':'PASS','total_exact_assertions':sum(x['exact_assertions'] for x in results),
        'scope':'Only listed exact algebra assertions, not numerical positivity, formal proof, or global exhaustion.',
        'scripts':results}
if os.environ.get('Q222_WRITE_REPLAY')=='1':
    suffix=next((str(v) for v in [12,11,10,9,8] if getattr(args,'revision'+str(v)+'_only')),None)
    target='verification/REVISION'+suffix+'_CHECK_REPLAY.json' if suffix else 'verification/ALL_CHECK_REPLAY.json'
    (root/target).write_text(json.dumps(record,indent=2)+'\n')
print(json.dumps(record,indent=2))
