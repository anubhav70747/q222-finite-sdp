"""Exact endpoints, retained D square, C cap and strict residue blocks."""
from pathlib import Path
import json
import sympy as s
u,w,W,Z,z,y,B,H,r,n,m,C,A,D,al,k=s.symbols('u w W Z z y B H r n m C A D al k', real=True)
# Positive symbols make pure-source radical simplifications exact.
B=s.Symbol('B',positive=True);H=s.Symbol('H',positive=True)
R0=(u*W-B*w*Z)/s.sqrt(B);R1=(z*W-B*u*w*Z)/s.sqrt(B)
R2=u*w*W-B/y*Z;T=(u*u-z)*Z;E=s.sqrt(B*H)*(w*w-1/y)*Z
G=(4*B*C-k*z/B)*R0**2+4*B*m/z**2*R1**2+2*(2*C+2*D+1)*R2**2+r*r*(4*n*w*w+2*(2*D+2*n+1))*T*T+H/B*(4*A*u*u+2*(2*A+2*C+2*D+1))*E*E+k*u/B*R0*R1+(-4*r*(2*D+1)+k/B)*R2*T-4*s.sqrt(H/B)*(2*C+2*D+1)*R2*E
checks=[]
def ck(name,expr):
    assert s.factor(s.expand(expr))==0,(name,s.factor(expr));checks.append(name)
rho=B/y;TR=rho*T
ck('scaled rho conductor',TR*TR+(u*u-z)*TR*R2-rho*u*(z*R0-u*R1)*(u*R0-R1))
e=1+z*r-rho+H/y; Q=R2-r*T-s.sqrt(H/B)*E
Jg=u*w*W-r*u*u*Z-H*w*w*Z-Z
ck('D shifted graph root',Q-Jg-e*Z)
kap=k-8*D*H*r
new=(4*B*C-kap*z/B)*R0**2+4*B*m/z**2*R1**2+2*(2*C+1)*R2**2+r*r*(4*n*w*w+4*n+2)*T*T+H/B*(4*A*(1+u*u)+4*C+2)*E*E+kap*u/B*R0*R1+(-4*r+kap/B)*R2*T-4*s.sqrt(H/B)*(2*C+1)*R2*E
ck('D shifted exact scalar removal',G-4*D*Q*Q-new)
ck('local root relation',s.sqrt(H)*R2-s.sqrt(B*H)*w*R0-s.sqrt(B)*E)
# The full C Gram part includes the Y normal; use an algebraic eta with eta²=H(1-H)/B.
EY,eta=s.symbols('EY eta')
U1=s.sqrt(B)*R0-eta*EY;U2=R2-s.sqrt(H/B)*E-w*eta*EY
Cg=4*B*R0*R0+4*(R2-s.sqrt(H/B)*E)**2
# Its full first normal as read from IC12, before dividing by E_Y.
Cnormal=-8*s.sqrt(B)*eta*(1+w*w)*R0*EY-8*w*eta*(B-H)/s.sqrt(B*H)*E*EY
Cquad=4*eta*eta*(1+w*w)*EY*EY
ck('full C packet including Y normal',4*(U1*U1+U2*U2)-Cg-Cnormal-Cquad)
cc,L,ss=s.symbols('cc L ss',positive=True)
# Residue entries after replacing AH and alpha(1-H), no unbounded A or alpha retained.
bb=H+L
normal=(4*cc*H*(1-H)+2*(1+L)*(1-H)+2*bb*H+2*H*(1-H))/bb
ck('strong R0-EY determinant',4*bb*cc*normal-16*cc*cc*H*(1-H)-8*cc*(1+L))
aa=2*(2*cc+1)
ck('strong R2-E determinant',aa*(2*(1+L)+H*aa)/bb-aa*aa*H/bb-2*aa*(1+L)/bb)
expr=(B*B*ss+B*H*ss+B*H-B*ss-H*H+H)/(B*B)-2*ss
ck('strong R2-Trho coupling',expr-(1+B-H)/B*(H/B-ss))
ck('weak rho0 block determinant',2*(1+2*ss)-ss**2-(2+4*ss-ss**2))
nu=s.symbols('nu')
ck('weak rho1 T pivot',2*r*r+r*r*(nu/r)-3*r*r+1-(1+r*nu-r*r))
result={'status':'PASS','count':len(checks),'checks':checks,'scope':'Exact local endpoint and cap identities; full underlying IC7 and IC11/12 have a separate fresh replay.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
