from pathlib import Path
import sympy as s,json
z,y,H,L,R=s.symbols('z y H L R', positive=True)
B=H+L
G=B+R-z*(1-H); S=1+R+L
Dt=(1+z)*B**2+2*(1+z)*B*R+(1+z)*(1+y)*B+(z-y)*R**2+2*z*(1+y)*R+z*(1+y)
Nh=(1+z)*(B+R)*(H+y)-(1+y)*(z-R)*L
weights={'n':(z*(B+R)*(1+R)*S-R*Dt)/(2*R*Dt),'m':z*(1+y)*(z-R)*(1+R)*S/(2*G*Dt),'C':(1+R)*Nh/(2*L*Dt),'A':y*(1+R)*(B+R)*S/(2*H*Dt),'D':(1+z)*(B+R)*(B-y*R)*S/(2*(y*(1+R)-L)*Dt),'alpha':(B+R)*Nh/(2*(1-H)*Dt)}
a2=y/z;b=B/z;r=R/z;t=L/y;h=H/z;g=G/z;j=1+R-L/y
Ac=1+z*r;Sc=Ac+a2*z*t
Delta=(1+z)*z*b*b+2*z*(1+z)*b*r+(1+z)*(1+a2*z)*b+z*z*(1-a2)*r*r+2*z*(1+a2*z)*r+1+a2*z
Num=(1+z)*(b+r)*(b+a2*(1-t))-a2*(1+a2*z)*(1-r)*t
original={'n':((b+r)*Ac*Sc-r*Delta)/(2*r*Delta),'m':(1+a2*z)*(1-r)*Ac*Sc/(2*g*Delta),'C':Ac*Num/(2*a2*t*Delta),'A':a2*Ac*(b+r)*Sc/(2*h*Delta),'D':(1+z)*(b+r)*(b-a2*z*r)*Sc/(2*a2*j*Delta),'alpha':z*z*(b+r)*Num/(2*(1-z*h)*Delta)}
checks=[]
def eq(label,l,r=0):
 assert s.factor(l-r)==0,label
 checks.append(label)
eq('H,L,R source denominator',z*Delta,Dt)
eq('H,L,R source numerator',z*z*Num,Nh)
for name in weights:eq('original '+name,original[name],weights[name])
eq('positive numerator identity',Nh,(1+z)*(B+R)*H+y*G+z*(y*(1+R)-L)+R*L*(1+y))
e=s.symbols('e',positive=True)
subs={z:e**2,y:e**-4,H:s.Rational(1,2),L:1/e-s.Rational(1,2),R:e**5/4}
family={name:s.factor(v.subs(subs)) for name,v in weights.items()}
limits={}
scales={'n':1,'m':e**5,'C':e,'A':1/e,'D':e**6,'alpha':1/e}
expect={'n':s.Rational(3,2),'m':s.Rational(1,2),'C':s.Rational(1,2),'A':1,'D':s.Rational(1,2),'alpha':1}
for name,weight in family.items():
 lead=s.limit(weight/scales[name],e,0,dir='+'); assert lead==expect[name],(name,lead)
 checks.append('IH family leading '+name);limits[name]=str(lead)
# Every source gap is positive by a positive leading coefficient at e=0.
gaps={'z':z,'y':y,'r':R/z,'1-r':1-R/z,'h':H/z,'t':L/y,'g':G/z,'j':1+R-L/y,'1-zh':1-H,'b-y*r':(B-y*R)/z}
for name,v in gaps.items():
 f=s.factor(v.subs(subs));lead=f.as_leading_term(e); assert lead.as_coeff_Mul()[0]>0,(name,lead)
 checks.append('IH family gap '+name)
# At the actual contact the positive Z=0 signed core gives transverse inertia;
# exact source stationarity plus inherited Laurent convexity proves physicality.
result={'status':'PASS','count':len(checks),'checks':checks,'family':{k:str(v) for k,v in family.items()},'normalized_leading':limits,'scope':'Exact source identities and IH curve. This exact rational curve is separately all-tests admitted by cor:rational-physical-source-curve; no generic multiparameter IH admission is claimed.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
