"""Only the new complete C-dependent SP6 block and its conductor."""
import json
from pathlib import Path
import sympy as s
C,z,q,b,r,sigma,u,w,W,Z,Ny,R,Gamma=s.symbols('C z q b r sigma u w W Z Ny R Gamma')
Dw=1+w*w
# All displayed affine-C entries of the complete SP/JR matrix.
Hy_C=4*z*Dw
Kr_C=4*b*b*Dw+8*b*sigma*(r-1)
Ry_C=8*(b*Dw+sigma*(r-1))
Rgamma_C=-8*(r-1)
actual=C*(Hy_C*Ny*Ny+z*Kr_C*R*R+z*Ry_C*Ny*R+q*w*Rgamma_C*(Ny+b*R)*Gamma)
target=4*C*z*Dw*(Ny+b*R)**2+8*C*(r-1)*(Ny+b*R)*(z*sigma*R-q*w*Gamma)
checks={}
def ck(name,x):
    assert s.expand(x)==0,name
    checks[name]=True;print('PASS '+name)
ck('entire_affine_C_block',actual-target)
conductor=z*sigma*((w*Z-u*z*W)/q)-q*w*(sigma*Z-u*w*W)-q*u*(w*w-sigma*z)*W
ck('centered_C_radial_conductor',s.cancel(conductor).subs(z,q*q).expand())
payload={'status':'PASS','count':len(checks),'checks':checks,'scope':'Exact full C-dependent block extraction only; no positivity claim for the remaining reciprocal two-small-angle corner.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
print(str(len(checks))+' focused checks passed')
