SHORT EXACT C1 CONTACT-CONDUCTOR PROOF
====================================

Entry text: contact_conductor_proof.tex
Self-contained source appendix: source_definitions.tex
Entry checker: check_analytical_lift.py
Run: python3 check_analytical_lift.py
Requires Python standard library only. Do not use -O.

This directory is self-contained for the exact algebra check. The two helper
files arithmetic.py and source_from_formulas.py are copied from the previously
verified explicit supplement; no old certificate, Groebner basis, generated
source JSON, or symbolic-algebra package is read. source_from_formulas.py
reconstructs the complete scalar and both first normals from the seven short
original coquotients. The new checker uses exact sparse polynomial arithmetic,
monomial membership in explicitly displayed monomial ideals, and the geometric
sum formula for monic contact division. Every final identity is multiplied back.

Main analytical result
----------------------
In R=Q[d,k,b,a,t][u,w,v], put A=wv, B=dv, C=db^2uw,
D0=d^2k^3b^2, J=(u-k,w-dk,v-dk^2b^2), M=(A,B,C),
x=B-C, y=A-kC, z=uB-kC, h=kC-D0,
and q=a1*a2-a3*a4, with the original four circuit monomials.
Then M intersect J is contained in (x,y,z), and
  (M^2 + (D0^2)) intersect J^2 is contained in (x,y,z,h,q)^2.

The proof uses only three exact contact conductors C*J subset (x,y,z),
two monic contact divisions, the primitive four-root gradient relation,
and k*C*(y+z-h-2*k*x)=q^2-y*z. The contact Jacobian determinant is
nonzero but may be infinitesimal. It is cancelled only in an integral domain
to infer a zero polynomial evaluation. No inverse is introduced in any lift.

The restriction to M^2+(D0^2) is essential: C*(y+z-h-2*k*x) is an explicit
counterexample to the unrestricted claim using (A,B,C,D0)^2. The actual source
has the restricted form, displayed as five factored scalar terms in the text.
The complete normals lie in M, vanish at contact, and need only x,y,z.

Execution
---------
Full source reconstruction and 33 exact checks completed in 13.135689 seconds
on the first run. See analytical_lift_checks.json for the executed report.
Targets: E0 46,429 terms; L1 15,346 terms; L2 14,228 terms.
Minimum target weights: 56,42,32. Minimum constructed coefficient weights:
12,20,12. The construction uses 17 nonzero scalar pair coefficients and 3
coefficients for each complete normal. It does not serialize the expanded
coefficient polynomials: the finite geometric-sum algorithm constructs them
and multiplies all identities back on each run. Expanded coefficient term
counts on that run were 382,314 / 67,298 / 53,226, respectively.

Scope
-----
This replaces the earlier 252-node finite membership certificate by a short
analytical mechanism for the same full source component. The strict-residue
Gram conclusion also uses the existing C1 hard-normal block, source entry,
positive retained packets and normalization restoration. It does not assert
whole-global source coverage. The proof can be combined with the parent's
six-soft-root positive circuit decomposition (eight roots including the two
hard normals). That root compression is separate from this checker.

Exploratory record
------------------
check_conductors.py and conductor_checks.json contain the initial six tiny
source/conductor identities. probe_factorization.py and factor_probe.json
record a bounded, unsuccessful common-conductor-factor route; they require
SymPy and are not part of the proof checker. probe_contact.py was the first
successful direct source contact check. The decisive proof is not based on
that exploratory factorization. No new Groebner computation was performed.

Native contact and conservative weight proof
------------------------------------------
source_definitions.tex now supplies all original source definitions, six short
native balances proving contact and full stationarity, and a factored weight
argument giving E0 at least52, L1 at least42 and L2 at least32. Hence the
human proof gives correction bounds8,20,10 without expanding the full source.
check_native_contact.py confirms the six native balances using standard-library
exact arithmetic; the executed run took0.004609 seconds. These identities and
the displayed derivative formulas prove CC7 analytically. No expanded-source
checker result is used as a premise in that proof.
