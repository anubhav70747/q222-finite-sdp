"""One exact radial extraction and the next full-source scalar coefficient."""
import sympy as s,json,time
from pathlib import Path
start=time.monotonic();checks={}
def ck(name,expr):
    ok=s.expand(s.fraction(s.cancel(expr))[0])==0
    checks[name]=bool(ok);print(('PASS ' if ok else 'FAIL ')+name,flush=True)
    if not ok:raise AssertionError(name)
u,w,q,W,Z,x,z,t,xi,sg,h,b=s.symbols('u w q W Z x z t xi sigma h b')
m,C,D,ab,lq=s.symbols('m C D ab lq');Q=1-b;th=1-h
Gamma=sg*Z-u*w*W;Rh=w*Z/q-u*q*W;Zw=b*w*Gamma/sg
ck('BR1 exact radial extraction',2*(b*q*Rh-Zw)**2-2*b*b/sg**2*u*u*(w*w-sg*q*q)**2*W*W)
cg=4*(1+t)*(ab*b*(1+xi)+lq*Q)
T=1+t*h+b*xi;Jf=1-T/sg;M0=1+t*(h-Q)*xi/sg;Rf=1-b*xi/sg
# Complete scalar polynomial on literal beta=0; all original weights retained.
phi=4*m*M0*M0+4*C*(1+xi)*t*Rf*Rf+cg*t*(2*xi/sg-z)+4*D*t*xi*Jf*Jf
phi+=2*(t*xi*Jf*Jf+(1+t)*t*Q*Q*xi*xi/sg**2+(1+xi)*t*t*th*th*xi/sg**2-(1+t)*(1+xi)*t*xi/sg**2)
rem=phi-2*b*b/sg**2*t*(xi-sg*z)**2
coefficient=s.Poly(s.expand(rem),t,xi).coeff_monomial(t*t*xi*xi)
k22=2*(1+2*m)*(h-Q)**2/sg**2+8*D*h*b/sg**2+8*ab*b/sg
ck('BR3 next exact full-source coefficient',coefficient-k22)
ck('BR2 extraction leaves all non-scalar terms unchanged',phi-rem-2*b*b/sg**2*t*(xi-sg*z)**2)
out={'scope':'C14.1 beta=0: exact first radial extraction and surviving pure-source coefficient only; no admission','checks':checks,'passed':len(checks),'seconds':round(time.monotonic()-start,3)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
print(str(len(checks))+' exact assertions passed',flush=True)
