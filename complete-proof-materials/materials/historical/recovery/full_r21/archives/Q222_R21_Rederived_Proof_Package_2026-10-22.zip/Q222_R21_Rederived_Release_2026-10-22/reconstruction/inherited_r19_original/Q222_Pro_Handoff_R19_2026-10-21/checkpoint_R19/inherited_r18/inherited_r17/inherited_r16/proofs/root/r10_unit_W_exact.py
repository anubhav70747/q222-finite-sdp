import sympy as s,json
from pathlib import Path
p,b,w,h,t,z=s.symbols('p b w h t z');x=p*b;B=p*p*b;r=1-p*w
ca=1+x*r;Sc=1+B*(1-h)+p*b*r;g=1-w+h*x;J=t*ca-(1-h)
aa=1/p
DP=s.expand(p*(aa+(1+aa*B)+(1+aa*B)*B+2*aa*B*(1+aa*B)*r+aa**3*B**2*r*r+2*aa*aa*B*r+t*B*(1+aa+aa*B+aa*aa*B*r*(2-r))))
# pM after multiplying the source M expression by p.
PM=(1+x)*(p+r)*(h+t)-p*w*(1+t*B)*(1-h)
Nc=ca*PM;Dc=2*(1-h)*DP
Na=t*ca*(p+r)*Sc;Da=2*DP
Nd=(1+x)*(p+r)*(1-t*x*r)*Sc;Dd=2*J*DP
Nm=w*(1+t*B)*ca*Sc;Dm=2*g*DP
num=s.expand(((h*Da+2*Na)*(Dd+2*Nd)*Dc-2*Nc*(4*Na*Nd-h*Da*Dd)).subs(b,w*z))
print('poly expanded',len(s.Poly(num,p,w,h,t,z).terms()),flush=True)
quot,rem=s.div(num,p*w,p,w,h,t,z)
assert rem==0, s.factor(rem)
den=(2*(4*Na*Nd-h*Da*Dd)*Dc).subs(b,w*z)
unitden=s.cancel(den*(Nm/w).subs(b,w*z))
unitnum=s.expand(quot*Dm.subs(b,w*z))
print('corner den',s.factor(unitden.subs({p:0,h:0})),flush=True)
print('corner num',s.factor(unitnum.subs({p:0,h:0})),flush=True)
out={'status':'PASS','source_ratio':'(Ccrit-C)/m = p * unitnum/unitden; b=w*z, z bounded','denominator_at_p_h_zero':str(s.factor(unitden.subs({p:0,h:0}))), 'numerator_residue':str(s.factor(unitnum.subs({p:0,h:0}))), 'exact_polynomial_division':True,'count':1}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
