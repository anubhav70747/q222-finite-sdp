#!/usr/bin/env python3
"""Focused exact checks of R17 R5 source entry, full-event extraction and join.
Positivity and universal tensor quantifiers are proved in r5_all_tests.tex.
"""
import sympy as s
import json
from pathlib import Path
out={}
def ck(name,expr):
    if isinstance(expr,s.MatrixBase):
        expr=list(expr)
    else: expr=[expr]
    for e in expr:
        assert s.cancel(e)==0,(name,s.factor(e))
    out[name]=True
u,v,W,X,Y,Z,xi,eta,R1,R2,T=s.symbols('u v W X Y Z xi eta R1 R2 T')
a,B,h,r,g,t,n,m,C,A,D,al,K=s.symbols('a B h r g t n m C A D al K')
U=u*u;V=v*v;half=s.Rational(1,2);Du=1+U;Dv=1+V
M=v*W-X+u*v*Y-u*Z;J=u*W+u*v*X-Y-v*Z
F=n*Du*Dv*X**2+m*M**2+C*Dv*(u*W-Y)**2+A*Du*Dv*Y**2+D*J**2+al*Du*(v*Y-Z)**2+half*(J**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z**2)
gactual=1-a*(1-r-h*B)
Rmc=-xi+u*v*eta+(1-g)*R2+h*u*T
rs={xi:X+r*u*Z,eta:Y-h*u*W,R2:v*W-u*Z/a,T:u*v*W-B*Z,g:gactual}
ck('centered_m_row_full_states',Rmc.subs(rs,simultaneous=True)-(M-gactual*v*W))
ck('exact_event_excess_identity',m*M**2-(m-K)*(M-g*v*W)**2-(K*M**2+2*(m-K)*g*v*W*M-(m-K)*g**2*v*v*W*W))
# Independent reconstruction of dG/dm from every WA entry, all other
# actual source coefficients held fixed. Relation qy_m=a(1-r-hB)=1-g.
Dm=s.zeros(5)
Dm[0,0]=1;Dm[1,1]=U*V;Dm[0,1]=Dm[1,0]=-u*v
Dm[0,3]=Dm[3,0]=-1;Dm[0,4]=Dm[4,0]=-h*u
Dm[1,3]=Dm[3,1]=u*v*(1-g)
Dm[1,4]=Dm[4,1]=v*(g+h*U)
Dm[3,3]=1;Dm[3,4]=Dm[4,3]=h*u;Dm[4,4]=h*h*U
lm=s.Matrix([-1,u*v,0,1-g,h*u]);Hm=s.zeros(5)
Hm[0,3]=Hm[3,0]=-1;Hm[1,4]=Hm[4,1]=v;Hm[3,3]=2-g;Hm[3,4]=Hm[4,3]=h*u
ck('entire_WA_m_matrix_cancellation',Dm-lm*lm.T-g*Hm)
# Direct WA coefficients verify that the above derivative is full.
k=1/t;ell=1/a
p0=(D+r*(n+half))/k;p1=r*(n+D+half)/k;q1=(n*r+B*p1)/ell
fx=-m*h+(D+half)*(1-h)-p0-q1
py=-(C+D+half)*(1-h)+A*h;pyp=A*h
kv=-C*(1-h)+A*h+m+(al+half)*h;kuv=h*(A+m+al+half)
kz=-m*(1-r)+r*(D+half)-al-half
qy=(-kz-k*pyp-B*kuv)/ell;fy=kv-qy
b2=2*m*h+C*(1-h)**2+(A+al+half)*h*h
b4=h*h*(m+A+al+half);c4=n*r*r;d4=(n+D+half)*r*r
fs=(b2-c4/ell**2-al/B**2-B*d4/(k*ell**2))/2
gamma=b4+d4/(k*ell)
Gm=s.zeros(5)
Gm[0,0]=n*Du*Dv+m+(D+half)*U*V+half*Dv
Gm[1,1]=A*Du*Dv+C*Dv+D+half+m*U*V+(al+half)*Du*V
Gm[0,1]=Gm[1,0]=-u*v*(m+D+half)
Gm[0,2]=Gm[2,0]=u*v*(p0+p1*U);Gm[0,3]=Gm[3,0]=-m+q1*U;Gm[0,4]=Gm[4,0]=u*(fx-p1*U)
Gm[1,2]=Gm[2,1]=py+pyp*U;Gm[1,3]=Gm[3,1]=u*v*qy;Gm[1,4]=Gm[4,1]=v*(fy+kuv*U)
Gm[3,3]=m;Gm[3,4]=Gm[4,3]=u*fs;Gm[4,4]=al/B**2+gamma*U
ck('all_WA_m_entries_accounted',Gm.diff(m)-Dm.subs(g,gactual))
# Joint source residues at B=r=0; n replaced by nr before substitution.
ca=1+a*B*r; Sc=1+B*(1-h+a*r)
Delta=a+(1+a*B)+(1+a*B)*B+2*a*B*(1+a*B)*r+a**3*B**2*r*r+2*a*a*B*r+t*B*(1+a+a*B+a*a*B*r*(2-r))
j=ca-(1-h)/t; Mstar=(1+a*B)*(1+a*r)*(h+t)-a*(1+t*B)*(1-r)*(1-h)
N=((1+a*r)*ca*Sc-r*Delta)/(2*Delta)
AA=t*ca*(1+a*r)*Sc/(2*h*Delta)
CC=ca*Mstar/(2*(1-h)*Delta)
DD=(1+a*B)*(1+a*r)*(1-a*t*B*r)*Sc/(2*t*j*Delta)
alstar=(1+a*r)*Mstar/(2*(1-h*B)*Delta)
mu=(1+t*B)*(1-r)*ca*Sc/(2*gactual*Delta)
res={B:0,r:0}
A0=t/(2*h*(1+a));C0=(h+t-a*(1-h))/(2*(1-h)*(1+a));D0=1/(2*(1+a)*(t-1+h));m0=a*a/(2*(1-a*a));al0=(h+t-a*(1-h))/(2*(1+a))
ck('source_nr_residue',N.subs(res)-1/(2*(1+a)))
ck('source_A_C_D_alpha_residues',s.Matrix([AA.subs(res)-A0,CC.subs(res)-C0,DD.subs(res)-D0,alstar.subs(res)-al0]))
ck('source_mu_residue',mu.subs(res)-1/(2*(1-a*a)))
ck('source_mg_endpoint',(gactual*a*a*mu).cancel().subs({B:0,r:0,a:1})-s.Rational(1,4))
S=C+D+half
ck('complete_eta_R1_block_determinant',(A+S)*(S*(1-h)**2+A*h*h)-(-S*(1-h)+A*h)**2-A*S)
# Three-state finite-remote determinant: compute in P=uW-Y variables,
# multiplying the congruence determinant U to avoid any inverse roots.
UU,VV=s.symbols('UU VV')
c=C*(1+VV)+D+half;b=(1+UU)*(A*(1+VV)+VV/2);d=D*VV+UU/2;pv=D+half;yv=(1+UU)/2
base=UU*(c*b*d-b*pv*pv*VV-c*yv*yv*VV)
adj=VV*(b*d-yv*yv*VV)+(1+UU)**2*VV*(c*d-pv*pv*VV)+UU*UU*c*b+2*(1+UU)*pv*yv*VV*VV-2*UU*b*pv*VV-2*UU*(1+UU)*c*yv*VV
poly=s.Poly(s.expand(base+m*adj),UU,VV)
source={A:A0,C:C0,D:D0,m:m0}
coeff={ex:s.factor(co.subs(source)) for ex,co in poly.terms()}
det=sum(co*UU**ex[0]*VV**ex[1] for ex,co in coeff.items())
den=8*h*(1-a)*(1+a)**3*(1-h)*(t-1+h)
target=(1+UU)*(1+VV)/den*((h+t)*(t*UU-a*VV)**2+(h+t-a*(1-h))*(t*(t-1+h)*UU**2*VV+(h+(1-a)*t)*UU*VV**2))
ck('finite_remote_determinant_factorization',det-target)
limit_target=(1+UU)*(1+VV)/(16*h*(1-h)*(t-1+h))*((h+t)*(t*UU-VV)**2+(h+t-(1-h))*(t*(t-1+h)*UU**2*VV+h*UU*VV**2))
ck('unbounded_m_kernel_determinant',s.cancel(target/m0).subs(a,1)-limit_target)
# Exact exceptional finite-axis 3-state determinant.
R=s.symbols('R')
axis=C*(1+V)*(R-Y)**2+A*(1+V)*Y**2+D*(R-Y-v*Z)**2+half*((R-Y)**2+V*Y**2-2*v*R*Z)
axisG=s.hessian(axis,(R,Y,Z))/2
axisdet=s.factor(axisG.det()).subs({A:A0.subs(a,0),C:C0.subs(a,0),D:D0.subs(a,0)})
ck('small_a_first_axis_full_residue',axisdet-V**2*(h+t)**2*(1+V)/(8*h*(1-h)*(t-1+h)))
# Homogeneous chart full-parent identities and residues with nX^2 retained.
p,q,P,Q,NX,muS,Ss=s.symbols('p q P Q NX muS Ss')
Fpq=s.expand(p*p*q*q*F.subs({u:1/p,v:1/q}))
corepq=half*((q*W+X-p*q*Y-p*Z)**2+(1+p*p)*(Y-q*Z)**2+(1+q*q)*(p*p*X*X+2*p*X*Z-p*p*Z*Z))
packpq=n*(1+p*p)*(1+q*q)*X*X+m*(p*W-p*q*X+Y-q*Z)**2+C*(1+q*q)*(W-p*Y)**2+A*(1+p*p)*(1+q*q)*Y*Y+D*(q*W+X-p*q*Y-p*Z)**2+al*(1+p*p)*(Y-q*Z)**2
ck('double_reciprocal_entire_parent',Fpq-corepq-packpq)
# Verify lifted core by substituting roots before expansion.
corelift=half*((q*W+X-p*q*Y-P)**2+(1+p*p)*(Y-Q)**2+(1+q*q)*(p*p*X*X+2*X*P-P*P))
ck('double_reciprocal_lift_exact',corepq-corelift.subs({P:p*Z,Q:q*Z}))
# Strict residues: remove n packet, take X=0, al=0, projective boundaries.
rest=F-n*Du*Dv*X*X
up=s.cancel(p*p*rest.subs(u,1/p)).subs({p:0,X:0,al:0})
ck('single_u_reciprocal_residue',up-((C*(1+V)+D+half)*W*W+A*(1+V)*Y*Y+(m+half)*(v*Y-Z)**2))
vq=s.cancel(q*q*rest.subs(v,1/q)).subs({q:0,X:0,al:0})
ck('single_v_reciprocal_residue',vq-(m*(W+u*Y)**2+C*(u*W-Y)**2+(A+half)*(1+U)*Y*Y+D*Z*Z))
doublelift=m*(p*W-p*q*X+Y-Q)**2+C*(1+q*q)*(W-p*Y)**2+A*(1+p*p)*(1+q*q)*Y*Y+D*(q*W+X-p*q*Y-P)**2+al*(1+p*p)*(Y-Q)**2+corelift
ck('double_reciprocal_complete_residue',doublelift.subs({p:0,q:0,X:0,al:0})-(C*W*W+A*Y*Y+D*P*P+(m+half)*(Y-Q)**2))
# Original small-a root identities (same exact events as WE8/WE10).
Faxis=n*Du*Dv*X*X+muS*(v*Ss-a*X+a*u*v*Y-a*u*Z)**2+C*Dv*(R-Y)**2+A*Du*Dv*Y*Y+D*(R+u*v*X-Y-v*Z)**2+al*Du*(v*Y-Z)**2+half*((R+u*v*X-Y-v*Z)**2+Du*(v*Y-Z)**2+Dv*(X+u*Z)**2-Du*Dv*Z*Z)
ck('small_a_axis_entire_parent',Faxis.subs({Ss:a*W,R:u*W,muS:m/a**2})-F)
axisres=(Faxis-n*Du*Dv*X*X).subs({u:0,a:0,X:0,al:0})
ck('small_a_finite_axis_complete_residue',axisres-(muS*V*Ss*Ss+axis))
qaxis=s.cancel(q*q*(Faxis-n*Du*Dv*X*X).subs(v,1/q)).subs({q:0,u:0,a:0,X:0,al:0})
ck('small_a_reciprocal_axis_complete_residue',qaxis-(muS*Ss*Ss+C*(R-Y)**2+(A+half)*Y*Y+D*Z*Z))
payload={'status':'PASS','count':len(out),'checks':out,'scope':'Focused identities corroborating the complete R5 all-tests proof. No numerical sampling or historical-suite replay; positivity and universal separated-tensor joins are analytical.'}
Path(__file__).with_suffix('.json').write_text(json.dumps(payload,indent=2)+'\n')
print(json.dumps(payload,indent=2))
