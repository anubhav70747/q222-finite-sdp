from pathlib import Path
import json,time
import sympy as s
start=time.perf_counter()
k,u,v,U,V,ex,em,ep,pw,W=s.symbols('k u v U V ex em ep pw W')
x=k*k
n=(8-5*x*x)/(16*(1+x)**2)
m=3*x*x*(3*x+4)/(16*(1+x)*(4+x-2*x*x))
C=al=(4-x)/(8*x)
A=x*(x+4)*(3*x+4)/(32*(2-x)*(1+x)**2)
D=(2-x)*(3*x+4)/(16*x*(1+x))
Du,Dv=1+u*u,1+v*v
a=1+x/4
aUV=a
r=x*u*W/2+k*em-k*pw/2
J=-(x/2+x*x/4)*u*W+k*em+k*pw/2
p=-x*u*v*W/2+k*ep
X=ex-x*v*W/4
Y=u*W-r
Z=v*Y-p
B=X+u*Z
Rm=v*W-X+u*p
F=2*(J*J+Du*p*p+Dv*B*B-Du*Dv*Z*Z)+4*n*Du*Dv*X*X+4*m*Rm*Rm+4*C*Dv*r*r+4*A*Du*Dv*Y*Y+4*D*J*J+4*al*Du*p*p
hard=[ex,em,ep,pw]
zero_hard={z:0 for z in hard}
F0=s.cancel(F.subs(zero_hard).subs(W,1))
def uv(expr):
 expr=s.cancel(expr);num,den=s.fraction(expr)
 def conv(p):
  poly=s.Poly(s.expand(p),u,v)
  assert all(e[0]%2==e[1]%2==0 for e,c in poly.terms()),expr
  return sum(c*U**(e[0]//2)*V**(e[1]//2) for e,c in poly.terms())
 return s.cancel(conv(num)/conv(den))
phi0=uv(F0)
bbase=s.cancel(phi0.subs(V,x)/(x*(U-x)**2));assert not bbase.has(V)
cV=s.cancel((phi0.subs(U,0)/(x*x*V)-bbase.subs(U,0))/(V-x))
b=s.cancel(bbase+(V-x)*cV)
ell=s.cancel((b*V*(U-x)**2-phi0)/(aUV*U*(V-x)))
assert not s.denom(ell).has(V)
LW=u*ell.subs({U:u*u,V:v*v})
g=[-u*v,-k*v*v,-k*v,k*(1+v*v/2)]
gW=a*u*(v*v-x)
G=sum(c*z for c,z in zip(g,hard))+gW*W
Li=[];hi=[];details={}
for i,z in enumerate(hard):
 old=s.diff(F,z).subs(zero_hard).subs(W,1)
 row=s.cancel(old+LW*g[i])
 parity=[v,u,u*v,u][i]
 f=uv(s.cancel(row/parity))
 assert s.cancel(f.subs({U:x,V:x}))==0,(z,'contact',s.factor(f.subs({U:x,V:x})))
 if i==0:
  BX=s.cancel(f.subs(U,x)/(V-x))
  AX=s.cancel((f-f.subs(U,x))/(U-x))
  L=-u*v*BX.subs(V,v*v)/(a*x)
  hh=(AX-(V-x)*BX/x).subs({U:u*u,V:v*v})
  details[str(z)]={'B_over_x':s.factor(BX/x)}
 elif i in (1,3):
  AA=s.cancel(f.subs(V,x)/(U-x))
  BB=s.cancel((f-f.subs(V,x))/(V-x))
  L=-BB.subs({U:u*u,V:v*v})/a
  hh=u*AA.subs(U,u*u)/v
  details[str(z)]={'A_over_x':s.factor(AA/x)}
 else:
  AA=s.cancel(f.subs(V,x)/(U-x))
  BB=s.cancel((f-f.subs(V,x))/(V-x))
  L=-v*BB.subs({U:u*u,V:v*v})/a
  hh=u*AA.subs(U,u*u)
 Li.append(s.cancel(L));hi.append(s.cancel(hh))
 assert s.cancel(row+Li[-1]*gW-v*(u*u-x)*hi[-1])==0,(z,'division')
H=s.zeros(4)
for i in range(4):
 for j in range(i,4):
  e=s.diff(F,hard[i],hard[j])/2+(g[i]*Li[j]+g[j]*Li[i])/2
  H[i,j]=H[j,i]=s.cancel(e)
btest=b.subs({U:u*u,V:v*v})
Gram=H.row_join(s.Matrix(hi)/2).col_join(s.Matrix([*(h/2 for h in hi),btest]).T)
# Every coefficient must be a rational function whose denominator is a source unit.
ratio=s.symbols('ratio',positive=True)
regular=[]
for i in range(5):
 for j in range(i,5):
  ee=s.cancel(Gram[i,j].subs(u,ratio*v));den=s.denom(ee)
  assert not den.has(v,ratio),(i,j,'non-source denominator',s.factor(ee))
  assert den.subs(k,0)!=0,(i,j,s.factor(ee))
  regular.append((i,j))
res=Gram.subs(u,ratio*v).applyfunc(s.cancel).subs({k:0,v:0}).applyfunc(s.factor)
print('RES',res,flush=True)
print('DET',s.factor(res.det()),flush=True)
print('SCHUR',s.factor(res[4,4]-(res[:4,4].T*res[:4,:4].inv()*res[:4,4])[0]),flush=True)
Q=v*(u*u-x)*W
roots=s.Matrix([*hard,Q])
identity=s.cancel(F+G*(LW*W+sum(c*z for c,z in zip(Li,hard)))-(roots.T*Gram*roots)[0])
assert identity==0
out={'status':'PASS: LOCAL u/v BOUNDED DOUBLE-CORNER TESTS ONLY','exact_full_parent_identity':True,'all_15_gram_entries_bounded_for_bounded_u_over_v':True,'residue_gram':[[str(e) for e in row] for row in res.tolist()],'residue_schur':str(s.factor(res[4,4]-(res[:4,4].T*res[:4,:4].inv()*res[:4,4])[0])),'seconds':round(time.perf_counter()-start,2)}
Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2)+'\n')
Path(__file__).with_name('halfcorner_witness_gram_data.txt').write_text('\n'.join(['b='+str(s.factor(b)),'ell='+str(s.factor(ell))]+['L'+str(i)+'='+str(s.factor(e)) for i,e in enumerate(Li)]+['h'+str(i)+'='+str(s.factor(e)) for i,e in enumerate(hi)]+['G'+str(i)+str(j)+'='+str(s.factor(Gram[i,j])) for i in range(5) for j in range(i,5)])+'\n')
print(json.dumps(out,indent=2))
