"""Exact centered-packet identities for the joint C2 finite-axis repair.

This checks the whole-parent recentering and its relevant residue arrays;
it does not by itself certify the monic conductor lifting argument.
"""
from pathlib import Path
import json
import sympy as s

u,v,W,X,Y,Z=s.symbols('u v W X Y Z')
x,k,b,r,g,h=s.symbols('x k b r g h')
n,m,C,A,D,alpha=s.symbols('n m C A D alpha')
nr,mg,tc,ta,cd,ca=s.symbols('nr mg tc ta cd ca')
Nc,Mc=s.symbols('Nc Mc', nonnegative=True)
Du,Dv=1+u*u,1+v*v
M=v*W-X+u*v*Y-u*Z
J=u*W+u*v*X-Y-v*Z
F=(4*n*Du*Dv*X**2+4*m*M**2+4*C*Dv*(u*W-Y)**2
   +4*A*Du*Dv*Y**2+(4*D+2)*J**2+(4*alpha+2)*Du*(v*Y-Z)**2
   +2*Dv*(X+u*Z)**2-2*Du*Dv*Z**2)
Qn=X+r*u*Z
Qm=M-g*u*Z
Fred=s.expand(F-4*(n-Nc)*Du*Dv*Qn**2-4*(m-Mc)*Qm**2)
checks=[]
def eq(label,lhs,rhs=0):
    assert s.factor(lhs-rhs)==0,label
    checks.append(label)

eq('exact whole-parent centered restoration',F,
   Fred+4*(n-Nc)*Du*Dv*Qn**2+4*(m-Mc)*Qm**2)
bounded=s.expand(Fred.subs({n:nr/r,m:mg/g}))
assert s.denom(s.together(bounded))==1
checks.append('all recentered n,m coefficients polynomial in nr,mg,r,g')
weights={C:tc/(x*(b-h)),A:ta/(x*h),D:x*cd,alpha:x*ca}
weighted=s.expand(bounded.subs(weights))
graph={X:-r*u*Z,Y:h*u*W/b}
fg=s.expand(weighted.subs(graph,simultaneous=True))
fww=fg.coeff(W,2);fzz=fg.coeff(Z,2);fwz=fg.coeff(W).coeff(Z)
q=s.cancel(x*(fww-fww.subs(u,0))/u**2)
bs=s.cancel((fzz-fzz.subs(u,0))/u**2)
cs=s.cancel(fww.subs(u,0)/v**2)
es=s.cancel(fzz.subs(u,0)/x)
gs=s.cancel(fwz/(u*v))
dk=1+k*k
lead={x:0,r:0,g:0,u:0,b:1,tc:k*k/(4*dk),ta:k*k/(4*dk),
      nr:1/(4*dk),mg:s.Rational(1,4),cd:1/(4*k*k*dk),ca:k*k/(4*dk)}
for label,lhs,rhs in [
 ('scalar q',q,k*k*Dv/dk),('scalar B diagonal',bs,4*Mc),
 ('scalar V diagonal',cs,4*Mc),('scalar E diagonal',es,(v*v/k**2+k*k)/dk),
 ('scalar BV cross',gs,-8*Mc-2)]:
    eq(label,lhs.subs(lead,simultaneous=True),rhs)
    den=s.factor(s.denom(lhs))
    assert den.subs({r:0,g:0,h:0,x:0})!=0
    assert den.subs({r:0,g:0,h:b,x:0})!=0
    checks.append(label+' has no opening or rate denominator')

lx=s.expand(s.diff(weighted,X).subs(graph,simultaneous=True))
ax=s.cancel(lx.coeff(W)/v)
bx=s.cancel(lx.coeff(Z)/u)
eq('full X normal V residue',ax.subs(lead,simultaneous=True),-8*Mc)
eq('full X normal B residue',bx.subs(lead,simultaneous=True),8*Mc+2-2*Dv/dk)
hxx=s.diff(weighted,X,2)/2
eq('full X hard residue',hxx.subs(lead,simultaneous=True),(4*Nc+2)*Dv+4*Mc)

ly=s.expand(s.diff(weighted,Y).subs(graph,simultaneous=True))
B2=8*Dv*(ta*Du-tc)/b
yr=s.expand(ly-u*W*B2/x)
ew=s.cancel(yr.coeff(W)/u)
ez=s.cancel((yr.coeff(Z)-8*v*x*(cd-ca))/u**2)
eq('entire Y normal identity',ly,u*W*B2/x+u*W*ew+u*u*Z*ez+8*v*x*(cd-ca)*Z)
eq('entire Y constant normal',yr.coeff(Z).subs(u,0),8*v*x*(cd-ca))
for label,expr in [('Y ew',ew),('Y ez',ez)]:
    den=s.factor(s.denom(expr))
    assert den.subs({r:0,g:0,h:0,x:0})!=0
    assert den.subs({r:0,g:0,h:b,x:0})!=0
    checks.append(label+' bounded at all opening boundaries')
eq('Y large coefficient identically zero leading function',B2.subs(lead,simultaneous=True))
eq('Y entire P coefficient zero leading function',(B2+x*ew).subs(lead,simultaneous=True))
hxy=s.diff(weighted,X,Y)/2
for weight in (tc,ta):
    eq('no large C,A in mixed hard coefficient '+str(weight),s.diff(hxy,weight))
hyy=s.diff(weighted,Y,2)/2
eq('Y hard remainder contains no C',s.diff(hyy-4*Dv*(C+A*Du).subs(weights),tc))
eq('Y hard remainder contains no A',s.diff(hyy-4*Dv*(C+A*Du).subs(weights),ta))

# Exact graph-current conductor lift.  Here Z=1 and g=b-1+r+xh.
rho=s.symbols('rho')
kap=b/k;eta=h/b
RR=(u*W-kap*x)/rho
SS=u-W/kap
UU=rho*(v-k)
TT=u*(v-k)
cg=s.expand(Qm.subs(graph,simultaneous=True).subs(Z,1).subs(g,b-1+r+x*h))
lift=-v*kap*SS+kap*TT+eta*u*v*rho*RR+eta*u*kap*rho*UU
eq('exact centered m current conductor lift',cg,lift.subs(rho*rho,x))

delta=2/dk**2
a=2*(k*k-1)/dk
eq('R,U Schur margin after conductor zero',1/k**2-delta-a*a/(4*k*k),2/dk**2)
eq('T,X determinant with zero n cap',delta*2*dk-(2*k/dk)**2,4/dk**2)
eq('finite-angle scalar determinant',(k*k*Dv/dk)*((v*v/k**2+k*k)/dk)-v*v,(v*v-k*k)**2/dk**2)
out={'result':'PASS','checks':checks,'number_of_checks':len(checks),
     'scope':'Whole-parent recentering, bounded scalar coefficients, complete X/Y-normal identities and residues, hard-block large-weight isolation, exact current lift, and strict matched residue determinants. The analytical monic lifts and inherited all-tests joins are reviewed separately in AUDIT_PACKET_REPAIR.md.'}
Path(__file__).with_name('packet_repair_checks.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
