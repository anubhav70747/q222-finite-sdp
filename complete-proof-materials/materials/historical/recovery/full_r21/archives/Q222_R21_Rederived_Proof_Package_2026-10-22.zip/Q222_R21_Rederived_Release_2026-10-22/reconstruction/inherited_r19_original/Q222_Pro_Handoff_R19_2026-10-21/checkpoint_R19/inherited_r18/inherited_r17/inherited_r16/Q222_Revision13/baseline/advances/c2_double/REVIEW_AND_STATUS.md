# C2 double-corner reduction — revision 6 working module

Quantified result: a common exact actual-II source/full-parent reduction,
not an all-tests admission. Both `C2.W.HH` and `C2.S.II_HH` stay open.

The exact C2 reflection takes the directed weak-C HH leaf to **strong-C,
weak-alpha II**. On every positive II source, alpha is weak exactly when
`B = H + L` is infinitesimal, and strong exactly when B is a positive unit.
The unit face automatically has unbounded C. Reflection labels are retained.

`common_ii_reduction.tex` provides:

- The source-face proof, retaining n = 0 and arbitrary openings.
- A determinant-one state graph with all three normals.
- An exact SOS for the entire hard state-normal quadratic.
- Every first-normal polynomial in the angular ideal `(U-z, V-y)`.
- A nine-support exact scalar contact-ideal formula, valid on both faces.
- Actual-contact centered packets removing all unbounded coefficients on
  the B-unit face, leaving a bounded full-parent remainder.

The remainder has bounded pure-source polynomial coefficients, and thus
bounded tensor coefficients at bounded affine tests. The graph increases
testing degree; its higher-degree homogenization at a literal projective
endpoint cannot stand in for the original endpoint parent. Endpoint joins
remain explicitly open.

The scalar identity is explicitly **not** treated as a certificate of the
whole parent. The mixed angular term and all first-normal couplings must be
allocated together. On the B-infinitesimal face, `1/B` and `m B²/z²` are not
declared bounded. No relative source/testing rate is assumed.

Same-system review: the root agent relayed the HI agent's review on
19 October 2026. The review found the reduction consistent and requested
that the undefined `p²` in DI9 be written as `(vY-Z)²`; this was corrected.
The source proof now also prints the inherited exact positive decomposition
`M = (1+z)(B+zr)H + yG + yzj + zrL(1+y)` so its lower bound is explicit.
This is a collaborating-agent analytical review, not independent external
verification.

`check_common_ii.py` completed **22 exact identities**. These include the
full normal decomposition, all three ideal factorizations, the angular
contact identity, seven Laurent coefficients, E(1), **all three original
source state-kernel equations**, **the original source graph value and both
angular derivatives**, and the bounded-remainder algebra. The six source
substitutions all completed after clearing their common denominator term
by term. Two earlier unoptimized runs were interrupted; neither is used as
evidence. `check_common_ii.json` records the completed optimized run.

Run with the session's available proof dependency path:

```sh
PYTHONPATH=/workspace/scratch/f695f02f9e9c/.proof_dependencies "$CODEX_PRIMARY_RUNTIME_PYTHON" analysis_atlas/oct19_r6_c2_double/check_common_ii.py
```

The checker certifies identities. Source bounds and the quantified scope
are supplied by the analytical text. No checklist completion follows from
the checker alone.
