# All testing regimes for the finite-unit-source C2 stratum

17 October 2026. Exact source channel convention: equation (1) of `base/PHYSICAL_PROOF.tex`, with `lambda=beta=0`. This note supplies the projective-boundary part of the finite-unit-source theorem. Its combination with `graph/FINITE_UNIT_MOVING_FRAME_THEOREM.md` covers every independent testing angle pair for this source stratum, including all normalized real testing states. Sources with an angle or the CHSH coefficient of zero residue are outside this theorem.

## Theorem and assumptions

Let `Kc,Kt` be independent real closed extensions of the real base. Normalize the nonnegative C2 coefficients so

\[
 d+n+m+c+A+D+\alpha=1.
\]

Assume physical validity at every angle and the existence of a stationary contact with positive finite-unit source angles `u_c,v_c`, while `d` is a positive unit. Then the original normalized parent

\[
 B_c(u,v)=P_c(u,v)/[(1+u^2)(1+v^2)]
\]

evaluated on every independent testing angle pair and normalized real testing state is a tensor sum of squares. There is no division by a mixed scalar. This is a theorem for this source stratum, not for all C1/C2 sources and not an evaluated global affine pencil.

The interior-testing proof is the source-only contact-frame theorem in the companion graph note. Below are complete proofs at all remaining testing residues.

## 1. Stationary balance forces five strong events

The nonzero outer determinant coefficients for C2 have the following positivity patterns; positive bounded factors omitted here do not change which coefficients have positive residue at finite-unit source angles:

| Exponent | Coefficient positive-residue condition |
|---|---|
| `(-1,0)` | `alpha*m` positive unit |
| `(-1,1)` | `m*D` positive unit |
| `(0,-1)` | `alpha*A` positive unit |
| `(0,1)` | `c*D` positive unit |
| `(1,-1)` | `n*A` positive unit |
| `(1,0)` | `c*A` positive unit |

At a finite-unit stationary contact their residue masses are nonnegative, balance to zero, and have rank-two covariance. The companion graph note proves this covariance statement, including exclusion of rank-zero and rank-one cases. Its only potentially balanced rank-one support is the diagonal pair `(-1,1),(1,-1)` with `c,alpha` weak, excluded by the two-state physical inequality

\[
 2(c+\alpha)(n+m+A+D)\ge d^2.
\]

This gives the stronger support conclusion

\[
 \boxed{c,\alpha,m,A,D\text{ are all positive units; only }n\text{ may be weak}.}\tag{1}
\]

Indeed if `alpha` is weak, balance of the sum of the two exponent coordinates forces the masses at `(0,1),(1,0)` to be weak as well; all remaining mass lies on the diagonal pair and covariance has rank at most one. If `c` is weak, the same sum forces the masses at `(-1,0),(0,-1)` weak, again leaving only the diagonal pair. Hence `c,alpha` are units. If `m` is weak, the only remaining positive first-coordinate mass must vanish by first-coordinate balance, forcing `A` weak, and second-coordinate balance then forces `D` weak, contradicting nonzero covariance. If `A` is weak, second-coordinate balance forces `D` weak, then first-coordinate balance forces `m` weak. Thus `m,A` are units. Finally `(0,-1)` now has positive mass, so second-coordinate balance requires `(0,1)` or `(-1,1)` positive, forcing `D` a unit.

## 2. Exact projective charts and corner matrices

Let `P=P_c(u,v)`. In the four charts use

\[
 P_{00}(u,v)=P(u,v),\quad
 P_{01}(u,b)=b^2P(u,1/b),\quad
 P_{10}(a,v)=a^2P(1/a,v),\quad
 P_{11}(a,b)=a^2b^2P(1/a,1/b).
\]

Each is a polynomial matrix, and in each chart `B` is that matrix divided by the positive pure-testing denominator `(1+first^2)(1+second^2)`. The corner matrices in state order `(W,X,Y,Z)` are

\[
\begin{array}{c|l}
00&\operatorname{diag}\bigl(0,\;4(n+m)+2d,\;4(c+A+D)+2d,\;4\alpha\bigr),\\
01&\operatorname{diag}\bigl(4m,\;4n+2d,\;4(c+A+\alpha)+2d,\;4D\bigr),\\
10&\operatorname{diag}\bigl(4(c+D)+2d,\;4n,\;4A,\;4(m+\alpha)+2d\bigr),\\
11&\operatorname{diag}\bigl(4c,\;4(n+D)+2d,\;4(m+A+\alpha)+2d,\;0\bigr).
\end{array}\tag{2}
\]

By (1), the residue ranks are respectively `3,4,3 or 4,3`. The only residue kernel states are `W`, optionally `X` when `n` is weak, and `Z`. There are no two-dimensional state-kernel corner cases in this source stratum.

## 3. The three kernel neighborhoods have strict quadratic Grams

These are exact local polynomial statements. Testing states outside the displayed residue kernel already have strictly positive residue and are covered by the strict bounded-Gram lemma. Inside the residue kernel, divide by its unit state amplitude, a permitted pure-testing factor.

### Corner 00: fix W=1

The five small variables are `(X,Y,Z,u,v)`. Define

\[
 p=4m,\quad q=4(c+D)+2d,\quad
 r_X=p+4n+2d,\quad r_Y=q+4A.
\]

The degree-two homogeneous part of the entire parent is

\[
 Q_{00}=r_XX^2+r_YY^2+4\alpha Z^2+q u^2+p v^2-2p vX-2q uY.
\]

Its source-only completion is

\[
\begin{aligned}
 Q_{00}={}&r_X(X-pv/r_X)^2+r_Y(Y-qu/r_Y)^2+4\alpha Z^2\\
 &+\frac{p(4n+2d)}{r_X}v^2+\frac{4Aq}{r_Y}u^2.
\end{aligned}\tag{3}
\]

Every coefficient is a positive unit and both displayed inverses are pure source. Thus its five by five Gram has positive definite real residue.

### Corner 11: fix Z=1

The five small variables are `(W,X,Y,a,b)`. Define

\[
 p=4D,\quad q=4(m+\alpha)+2d,\quad
 r_X=p+4n+2d,\quad r_Y=q+4A.
\]

The degree-two homogeneous part is

\[
 Q_{11}=4cW^2+r_XX^2+r_YY^2+p a^2+q b^2-2p aX-2q bY,
\]

with positive source-only completion

\[
\begin{aligned}
 Q_{11}={}&4cW^2+r_X(X-pa/r_X)^2+r_Y(Y-qb/r_Y)^2\\
 &+\frac{p(4n+2d)}{r_X}a^2+\frac{4Aq}{r_Y}b^2.
\end{aligned}\tag{4}
\]

Again the Gram has strictly positive residue.

### Corner 10 with n weak: retain its original event, then fix X=1

The exact original `n` packet is

\[
 4n(1+a^2)(1+v^2)X^2,
\]

which is already a separated tensor square. Subtract only this packet for the local argument. The remaining polynomial vanishes to second order at the corner kernel. In variables `(W,Y,Z,a,v)` its quadratic part is

\[
 \boxed{Q_{10}=(4m+2d)(a+Z)^2+4\alpha Z^2+4cW^2
                  +4AY^2+(4D+2d)(W+v)^2.}\tag{5}
\]

The five linear forms are independent, and all weights are positive units. This gives the required positive definite residue without assuming that subtraction preserves global physicality. It does not need to preserve physicality: only the explicit local polynomial identity and its strict quadratic Gram are used. If `n` is a unit, the whole corner matrix is already strictly positive.

### Why quadratic parts suffice here

In each case the remaining exact polynomial has no terms of degree below two in its five small pure-testing variables `z`. Distribute each higher monomial among two of its factors. This gives an exact identity

\[
 F=z^T(Q_0+\Delta)z,
\]

where `Q_0` is the displayed bounded source Gram, and every entry of `Delta` is bounded with infinitesimal residue. The source normalization bounds every coefficient. Since `res(Q_0)` is positive definite, the strict bounded-Gram lemma applies directly. This is a full exact tensor-SOS identity, not a Taylor approximation: the higher terms stay in `Delta`. No mixed square root, inverse, asymptotic truncation, or comparison of independent source/test rates is used.

## 4. All four open projective edges are strictly positive

Literal testing axes have the following exact original-parent square forms. Write `Du=1+u^2`, `Dv=1+v^2`.

At `u=0`,

\[
\begin{aligned}
F={}&4m(vW-X)^2+(4n+2d)D_vX^2\\
&+[4(c+A)+2d]D_vY^2+4D(Y+vZ)^2+4\alpha(vY-Z)^2.
\end{aligned}\tag{6}
\]

At `v=0`,

\[
F=[4(c+D)+2d](uW-Y)^2+4AD_uY^2
    +4nD_uX^2+(4m+2d)(X+uZ)^2+4\alpha D_uZ^2.\tag{7}
\]

At `u=infinity` in chart 10,

\[
F_{10}=4cD_vW^2+(4D+2d)(W+vX)^2+4nD_vX^2
             +4AD_vY^2+[4(m+\alpha)+2d](vY-Z)^2.\tag{8}
\]

At `v=infinity` in chart 01,

\[
\begin{aligned}
F_{01}={}&4m(W+uY)^2+4c(uW-Y)^2+[4(A+\alpha)+2d]D_uY^2\\
&+(4n+2d)D_uX^2+4D(uX-Z)^2.
\end{aligned}\tag{9}
\]

When the other chart angle is a nonzero finite unit, these forms are positive definite with positive real residue by (1). Consequently any independent testing pair whose residue is in an open projective edge, and any normalized state, has strictly positive residue; the strict bounded-Gram lemma covers its neighborhood. The only failures of strict state positivity at edge endpoints are precisely the corners already handled in (3)--(5).

## 5. Exhaustive dispatch of testing regimes

Every projective testing angle has finite bounded chart coordinate. Its residue is either a nonzero finite real number or zero at one endpoint. Thus the possibilities are:

| Independent testing residue | Exact admission |
|---|---|
| Both angles nonzero and finite | Companion interior source-only contact-frame theorem |
| Exactly one projective endpoint, other angle nonzero finite | Strict edge residue from (6)--(9) |
| Corner 01 | Strict state residue from (2) |
| Corner 00 | Strict five-normal Gram (3) |
| Corner 11 | Strict five-normal Gram (4) |
| Corner 10, n unit | Strict state residue from (2) |
| Corner 10, n weak | Retain exact n event, then strict five-normal Gram (5) |

Signed angles cause no extra cases. Explicitly, for `sigma_u,sigma_v` in `{1,-1}`,

\[
 P(\sigma_u u,\sigma_v v)=S^TP(u,v)S,
 \qquad S=\operatorname{diag}(1,\sigma_v,\sigma_u,\sigma_u\sigma_v).
\]

Every event row transforms up to an overall row sign; the core has the same conjugation. Thus the positive interior-angle theorem transfers exactly, while the displayed boundary identities and strict quadratic forms already allow either sign of each small chart angle. This completes all-testing coverage for the finite-unit-source C2 theorem stated at the start.

## Reproduction and scope

`ALL_TEST_C2.py` verifies all four corner matrices, all four edge identities, and the three full quadratic jets and source completions by exact symbolic polynomial arithmetic. The complete local identities retain higher terms as an infinitesimal Gram perturbation, so no numerical checks are needed. The stationary support and interior-testing components are supplied by the companion graph proof, not silently reproved by these corner checks. Sources whose contact approaches a projective endpoint or whose normalized `d` has zero residue remain outside this result.
