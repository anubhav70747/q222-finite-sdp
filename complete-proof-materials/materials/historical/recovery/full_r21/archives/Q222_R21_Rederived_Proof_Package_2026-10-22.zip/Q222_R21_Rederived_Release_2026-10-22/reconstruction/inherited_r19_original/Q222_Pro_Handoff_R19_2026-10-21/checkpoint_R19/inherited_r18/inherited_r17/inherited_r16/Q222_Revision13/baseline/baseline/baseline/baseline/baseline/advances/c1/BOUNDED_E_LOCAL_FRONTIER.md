# Bounded e: local continuation only

Established exact algebra, not an all-tests theorem:

When e is a positive bounded unit, delta is a unit, k,zeta are
infinitesimal, and eta,r are units, use weights
`(delta,k,b,a,t,u,w,v)=(0,1,0,0,0,1,1,2)`.
The same exact reconstruction gives

`E0_le6 = 8 rho T4 - 8(rho+b²) k² x²`,
`L1_le3 = 0`, and `L2_le3 = 16 b² x`.

The source/checker script is `probe_unit_eta_delta_unit.py`. This is a
small contact-conductor module for the small-u,v,w, Z-unit chart.
Its strict reference Gram is the same as in the e-unbounded theorem.
The ordinary finite-u, small-v,w, Z-unit chart has the same raw
monomial residue Gram. These statements do not claim all tests.

A concrete outer obstruction to a naive join occurs at the infinity-
infinity, Z-unit testing ray. If beta/d is infinitesimal, its leading
quadratic soft form in Y and q=1/v, after the positive W/X normals,
contains

`(2d+4m+4A)Y² -(8m+4d)qY +4m q²`.

Its determinant is `4(4mA-2md-d²)`. At the leading beta-zero source
relation `e²=t eta/H`, with `M=1-t`, its sign is the sign of
`eta(a+t)-1`. Physicality rules out a negative leading determinant;
the equality case remains a genuine critical corner to analyze.
Thus positive lower bounds on m,C,A,D relative to d do not, by
themselves, justify a strict all-corner join.

If a,t,M,J are positive units and e,eta,r are units, every native event
coefficient is bounded and d is a positive unit (the normalization is
C=2). Consequently total-normalized d has positive residue, and the
inherited complete positive-d theorem already covers this source.
Any genuinely new bounded-e work must therefore involve a singular
opening a,t,M,J, after subtracting all other inherited admissions.

No global coverage status is changed by these local calculations.
